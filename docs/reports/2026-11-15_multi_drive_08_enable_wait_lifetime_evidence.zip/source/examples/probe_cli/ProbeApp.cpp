// SPDX-License-Identifier: MIT
#include "ProbePlatform.h"
#include "ProbeApp.h"
#include "RuntimeWitness.h"
#include "OwnerWatchdog.h"
#include <MotorControlRS/profiles/ess_rs/Discovery.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_heap_caps.h>
#include <esp_timer.h>
#include <esp_attr.h>
#include <new>
#include <cstring>
#include <algorithm>
#include "ProbeConsole.h"
#include "DebugSession.h"
#include "StateCache.h"
#include <MotorControlRS/profiles/ess_rs/Actions.h>
#include <MotorControlRS/profiles/ess_rs/Position.h>
#include <MotorControlRS/profiles/ess_rs/Velocity.h>
#include <MotorControlRS/profiles/ess_rs/DriverSettings.h>
#include <MotorControlRS/profiles/ess_rs/Segments.h>
#include <MotorControlRS/profiles/ess_rs/ControlSettings.h>
#include <MotorControlRS/profiles/ess_rs/Tuning.h>
#include <MotorControlRS/profiles/ess_rs/Registers.h>
#include <MotorControlRS/profiles/ess_rs/Homing.h>
#include "../common/EssRtuValidator.h"
#include "../common/Esp32S3Uart.h"
#if MOTORCONTROLRS_LOAD_FIXTURE
#include "Esp32Load.h"
#endif
using namespace MotorControlRSExample;
namespace ESS = MotorControlRS::ESS_RS;
using MotorControlRS::ReadState;
using MotorControlRS::ReadEventKind;
namespace {
constexpr uint32_t BAUD = 115200;
constexpr uint32_t REQUEST_US = 500000, RECOVER_US = 500000, RECOVERY_BUDGET_US = 2000000;
constexpr uint32_t NORMAL_STOP_US = 2000000 + 2 * REQUEST_US, NORMAL_STOP_POLL_US = 50000;
// Move and home completion polls once RUNNING was reported. 64 of them cover the
// largest ApplicationOptions::moveTimeoutMs; polls spent before RUNNING reduce this.
constexpr uint32_t RUNNING_POLL_US = 500000;
// Nominal application ceiling shared with position policy, not a vendor range or
// measured homing speed. Exact native-word qualification remains required.
constexpr uint32_t HOME_MAX_COMMAND_RATE = 50000;
static_assert(static_cast<uint64_t>(ESS::ACTION_MAX_POLLS) * RUNNING_POLL_US >= 30000000, "polls must cover the largest move timeout");
// Every stop deadline is fixed at admission and never renewed. This allowance
// lets an in-flight transaction settle and one bounded recovery finish while a
// never-transmitted stop still has its own request budget.
constexpr uint32_t STOP_RECOVERY_US = REQUEST_US + RECOVERY_BUDGET_US;
// Bench, 3 November 2026: firmware 0x0029 echoed and ignored starts sent up to
// 0.6 s after an enable frame, with no status bit showing readiness. Not documented.
constexpr uint32_t ENABLE_SETTLE_US = 1000000;
constexpr std::size_t ENABLE_WAIT_SLOTS = 248; // Unicast 1..247; slot 0 is unused.
constexpr std::size_t REQUEST_CAPACITY = 8, ORDINARY_PENDING = 4, STOP_RECORDS = 2, OUTPUT_LINES = 8;
constexpr std::size_t STOP_ESCALATIONS = 2;
// Drive-group pools, sized from Probe::GROUP_CAPACITY. One move record per
// member, beside the ordinary results, so every member holds its move while
// ordinary reads keep their eight. One stop and one escalation per member, beside
// the four records of explicit `stop`. The owner's result and urgent quotas
// cover every pool, so no pool can starve another. The ordinary queue stays
// ORDINARY_PENDING deep: member polls are admitted oldest-eligible first, so the
// queue delays a member's poll by a few transactions and never starves it.
constexpr std::size_t GROUP_MOVE_RECORDS = Probe::GROUP_CAPACITY;
constexpr std::size_t GROUP_STOP_RECORDS = 2 * Probe::GROUP_CAPACITY;
constexpr std::size_t URGENT_RECORDS = STOP_RECORDS + STOP_ESCALATIONS + GROUP_STOP_RECORDS;
constexpr std::size_t STOP_ESCALATION_FIRST = REQUEST_CAPACITY + 1 + STOP_RECORDS;
constexpr std::size_t GROUP_STOP_FIRST = STOP_ESCALATION_FIRST + STOP_ESCALATIONS;
constexpr std::size_t GROUP_MOVE_FIRST = GROUP_STOP_FIRST + GROUP_STOP_RECORDS;
constexpr std::size_t RECORD_COUNT = GROUP_MOVE_FIRST + GROUP_MOVE_RECORDS;
constexpr std::size_t RESULT_SLOTS = REQUEST_CAPACITY + GROUP_MOVE_RECORDS + URGENT_RECORDS;
DRAM_ATTR Esp32S3Uart uart; // Internal driver/ISR state; App storage is PSRAM.
#if MOTORCONTROLRS_LOAD_FIXTURE
DRAM_ATTR Esp32Load loadFixture;
bool fixtureReady = false;
uint64_t nextServiceUs = 0;
#endif
bool platformReady = false;
// Declared board topology plus the runner's physical-TX/DE/RX interval checks
// excludes local transmit echo. This is a wiring contract, not an independently
// measured electrical timing qualification. Alternate topologies may retain
// UNKNOWN FC06 execution and still use read-only action/move observations.
bool writeResponseConfirmed = false;
uint64_t nowUs() { return static_cast<uint64_t>(esp_timer_get_time()); }
Rtu::Storage storage(uint8_t* tx, uint8_t* rx, Rtu::Trace* trace) {
    Rtu::Storage s; s.tx = tx; s.txCapacity = 32; s.rx = rx; s.rxCapacity = 64;
    s.trace = trace; s.traceCapacity = 128; return s;
}
Rtu::Timing timing() {
    HostTiming t; hostTiming(HostTuple(), t);
    return t.runner;
}
Rtu::BusStorage busStorage(Rtu::PendingSlot* p, Rtu::ResultSlot* r, Rtu::ProducerSlot* producers) {
    Rtu::BusStorage s; s.pending = p; s.pendingCapacity = ORDINARY_PENDING + URGENT_RECORDS;
    s.results = r; s.resultCapacity = RESULT_SLOTS; s.producers = producers; s.producerCapacity = 1;
    s.urgentPendingCapacity = s.urgentResultCapacity = URGENT_RECORDS; return s;
}
struct App;
Probe::Host host(App*);
void recycleInteractiveResults(void* context);
MotorControlRS::ActiveSerialTuple communicationTuple(const HostTuple&);
struct App {
    ApplicationOptions options;
    uint64_t observationAgeUs() const { return static_cast<uint64_t>(options.observationMaxAgeMs) * 1000; }
    uint8_t tx[32] = {}, rx[64] = {}, viewTx[8] = {};
    Rtu::Trace trace[128];
    Rtu::PendingSlot pending[ORDINARY_PENDING + URGENT_RECORDS];
    Rtu::ResultSlot results[RESULT_SLOTS];
    Rtu::ProducerSlot producers[1];
    Probe::HostSnapshot serial;
    ESS::CommunicationContext commissioning, commissioningPrepared;
    ESS::CommunicationPrerequisites commissioningPrerequisites; // Exact supplied fixture/effects evidence; unavailable by default.
    Rtu::RequestId commissioningRequest;
    uint64_t commissioningLease = 0;
    uint32_t commissioningConfirmedGeneration = 0, commissioningRequestBinding = 0;
    bool commissioningInvalidated = false, commissioningResponseQualified = false;
    ESS::PersistenceContext persistence, persistencePrepared;
    Probe::DiscoveryScan discovery;
    MotorControlRS::ESS_RS::PreparedProbe discoveryPrepared;
    ESS::ReadContext discoveryIdentity;
    Rtu::RequestId discoveryRequest;
    bool discoveryIdentityPending = false, discoveryOriginalKnown = false;
    ESS::PersistencePrerequisites persistencePrerequisites, persistenceBaseline;
    ESS::PersistenceVerification persistenceVerification;
    ESS::ReadContext persistenceReads[3];
    Rtu::RequestId persistenceRequest, persistenceReadRequest;
    MotorControlRS::ReadTarget persistenceReadTarget;
    uint64_t persistenceReadDeadline = 0;
    uint32_t persistenceReadOperation = 0, persistenceSnapshotSerialGeneration = 0,
        persistenceSnapshotBinding = 0, persistenceConfirmedGeneration = 0;
    uint8_t persistenceReadIndex = 0, persistenceInvocations = 0, persistenceVerificationAttempts = 0;
    bool persistenceCapture = false, persistenceAfter = false, persistenceBaselineKnown = false,
        persistenceSnapshotFailed = false, persistenceInvalidated = false,
        persistenceParentSession = false, persistenceFinished = false;
    Rtu::Runner runner;
    Rtu::BusOwner owner;
    Probe::Console console;
    // One context selection; reservations, consumers and evidence remain independent.
    enum class OperationKind : uint8_t { EMPTY, TRANSACTION, TYPED_READ, ACTION, MOVE, VELOCITY, DRIVER, HOME };
    struct Record {
        OperationKind kind = OperationKind::EMPTY;
        uint32_t operationId = 0, commandId = 0;
        HostTuple serialTuple;
        uint32_t serialGeneration = 0;
        uint8_t address = 0;
        Rtu::RequestId requestId;
        uint64_t deliveredUs = 0;
        uint64_t deadlineUs = 0;
        bool observed = false, delivered = false, captureRead = false, interactive = false;
        bool monitored = false, simpleChild = false, programmaticRead = false;
        bool cancelContinuation = false; ///< Cancel the operation after its current frame settles.
        uint8_t broadcastFrame = 0; ///< 1 + Probe::BroadcastFrame for a fixture broadcast; 0 otherwise.
        ESS::ReadContext read;
        bool axisReserved = false, effectsInvalidated = false, interruptedByStop = false;
        bool motionUnresolved = false; // Our possible movement, until a later checked stop; not historical outcome.
        bool discoveryStop = false; ///< Urgent stop waits for the scan's original tuple.
        bool stopHeld = false; ///< Never-transmitted stop waiting for one bounded recovery.
        uint64_t stopRecoveryId = 0; ///< The one recovery this held stop waited for.
        uint32_t stopRecoveryOperationId = 0;
        Rtu::RecoveryResult stopRecoveryResult; ///< Copied terminal recovery; later recovery cannot replace it.
        bool stopBeforeRecoveryKnown = false;
        Rtu::Completion stopBeforeRecovery; ///< Settled zero-byte attempt, copied before owner release.
        ESS::ActionContext action;
        bool programmaticAction = false, stopEscalation = false;
        uint32_t replacedOperationId = 0, releaseAfterStopId = 0;
        ReleaseAfterStopPrerequisites releasePrerequisites;
        bool programmaticMove = false;
        ESS::MoveContext move;
        ESS::StoredPositionQualification storedPosition; ///< Original admission provenance; qualified only after its checked trigger.
        MoveRelation moveRelation;
        bool interruptWaiting = false; ///< Reserved result, no bus request until old work settles.
        ESS::VelocityContext velocity;
        uint32_t configurationGeneration = 0;
        uint32_t driverEffects = 0;
        ESS::DriverContext driver;
        bool singleSettingSession = false, programmaticSettings = false;
        uint16_t requestedSetting = 0; ///< Frozen across prior read and update.
        ESS::HomeContext home;
        bool programmaticHome = false;
        bool groupChild = false; ///< Owned by a group operation; its group line reports it.
        bool groupWaiting = false; ///< Prepared group member move, before its turn in the start order.
        bool triggerTxComplete = false; ///< Start write physical TX evidence, copied from the owner.
        uint64_t triggerTxEndUs = 0;
        uint32_t triggerTxUncertaintyUs = 0;
    } records[RECORD_COUNT]; // Ordinary, monitor, stop, stop-escalation, group stop and group move reservations.
    Probe::StateCache stateCache;
    Probe::MonitorSnapshot monitorState;
    struct Recovery {
        uint32_t operationId = 0, commandId = 0;
        HostTuple serialTuple;
        uint32_t serialGeneration = 0;
        uint64_t id = 0, deadlineUs = 0;
        bool delivered = false, prepared = false;
        bool automatic = false; ///< Started by a held stop; no command correlation or report.
        Rtu::RecoveryResult retained; ///< Copied when an automatic recovery displaces this result.
    } recovery, recoveryDisplaced;
    struct Line { char text[Probe::OUTPUT_CAPACITY + 1]; std::size_t size = 0, offset = 0; } output[OUTPUT_LINES];
    std::size_t outputHead = 0, outputCount = 0;
    uint32_t nextOperationId = 1, latestOperationId = 0, cacheOperationId = 0, modelOperationId = 0;
    uint64_t stopEvidenceOverwritten = 0; ///< Delivered failed stop results replaced by a newer explicit stop.
    struct UsbStall {
        uint64_t progressUs = 0, startedUs = 0, longestUs = 0;
        uint32_t count = 0, nudges = 0;
        bool active = false, nudged = false;
        Platform::ConsoleUsbSample sample;
    } usbStall;
    uint64_t outputBlocked = 0, outputShortWrites = 0, inputBytes = 0, inputLines = 0;
    uint64_t observedEarliestUs = 0, observedLatestUs = 0, deliveredUs = 0, recoveryGuardUntilUs = 0;
    uint8_t address = 1, modelAddress = 0;
    uint16_t model = 0;
    bool known = false, ok = false, modelKnown = false, codecChecked = false;
    MotorControlRS::Status codec;
    ESS::IdentityObservation identity;
    ESS::ConfigObservation configuration;
    ESS::DriverObservation driverSettings;
    ESS::DriverObservation ioSettings;
    ESS::DriverObservation controlSettings;
    ESS::DriverObservation tuningSettings[4]; // One baseline per actual group; old results retain their own context.
    ESS::DriverObservation segmentSettings; // One bounded record baseline; selecting another replaces this cache only.
    MotorControlRS::InputWiring inputWiring[4];
    MotorControlRS::InputWiring outputWiring[2];
    ESS::DriverObservation driverObserved; // Scratch for whole-read publication/effects comparison.
    ESS::DriverPrerequisites driverPrerequisites; // PSRAM scratch; no large stack copies.
    bool driverInputsQualified = false; // Explicit commissioning evidence, no console bypass.
    MotorControlRS::AxisConfig axis;
    bool commandPolarityKnown = true; // Host declaration; invalidated by possible device-direction changes.
    MotorControlRS::AxisReference coordinateReference; // Qualified command-coordinate evidence; never inferred from an unsigned/raw zero.
    struct EnableWait {
        MotorControlRS::ReadTarget target;
        HostTuple serialTuple;
        uint32_t serialGeneration = 0, operationId = 0;
        uint64_t observedUs = 0, untilUs = 0;
        MotorControlRS::ActionExecution execution = MotorControlRS::ActionExecution::NOT_TRANSMITTED;
        ESS::ActionEvidence write;
    } enableWaits[ENABLE_WAIT_SLOTS]; // Per physical address on this App's bus; never cleared by host rebinding.
    bool bootOriginPending = true; // RAM-only, consumed once before the first simple move.
    bool bootCoordinates = false; // Explicit standalone feedback/command coordinate convention.
    bool simpleEndpointKnown = false;
    bool motionObservationPending = false; // Our terminal move/stop still needs a stationary feedback baseline.
    int64_t simpleEndpoint = 0;
    uint32_t simpleEndpointGeneration = 0;
    PositionClearQualification positionClearQualification;
    Probe::DebugSession debug;
    struct MotionProfileState {
        Probe::MotionProfileView view;
        ESS::RawConfig configuration;
        Rtu::RequestId request;
        uint32_t bindingGeneration = 0;
    } motionProfile;
    struct SimpleMotionSession {
        Probe::SimpleMotionView view;
        Probe::SimpleMotionSettings desired;
        MotionProfileState settingsProfile; ///< Read-only display snapshot; never owns restoration or staging state.
        MotorControlRS::PositionRequest position;
        uint32_t bindingGeneration = 0, serialGeneration = 0;
        uint64_t deadlineUs = 0;
        bool admitting = false, cancelled = false;
    } simple;
    // Remembered checked parameters, separate from the preserved raw readback.
    uint16_t rememberedMoveWords[5] = {};
    uint32_t rememberedMoveGeneration = 0, rememberedMoveBinding = 0, rememberedMoveSerial = 0;
    ESS::MovePrerequisites movePrerequisites; // Supplied commissioning evidence; false until verified.
    bool positionStartSpeedRelationRequired = false; // Preserve the pre-setting startup policy; never reset by reads/recovery.
    PositionStartSpeedRelation positionStartSpeedRelation;
    ESS::HomePrerequisites homePrerequisites; // Explicit method/active-auxiliary/native/reference qualification.
    ESS::VelocityPrerequisites velocityPrerequisites; // Independent commissioning evidence, initially unqualified.
    ESS::VelocityParametersObservation velocityParameters; // Checked observation, never desired/staged values.
    ESS::HomingParametersObservation homingParameters; // Raw observation is separate from home qualification.
    uint32_t bindingGeneration = 1;
    uint8_t actionConflicts[32] = {}; ///< Physical address conflicts survive result release and host recovery.
    uint8_t knownTargets[32] = {}; ///< Checked physical addresses, independent of the latest passive observation.
    uint8_t startSpeedWritten[32] = {}; ///< Possible start-speed writes this boot, by address (RAM only).
    MotorControlRS::ReadTarget communicationTarget;
    uint64_t communicationEarliestUs = 0, communicationLatestUs = 0;
    bool communicationKnown = false;
    MotorControlRS::ESS_RS::FrameError frameError = MotorControlRS::ESS_RS::FrameError::NONE;
    // One staged move without a start (PositionStageApp.h). The selected axis has
    // one session; each group member has its own.
    struct StageSession {
        Probe::PositionStageView view;
        Rtu::RequestId request;
        uint8_t phase = 0; ///< 0 none, 1 FC10 write, 2 FC03 readback.
        bool applied = false; ///< Success already published as a stored-word witness.
        uint8_t tx[32] = {};
    } stage;
    ESS::MoveContext stagePrepared; ///< Scratch for the selected-axis stage words; no stack copy.
    // Drive group (multi-drive 02). A host selection only: each member keeps its
    // own facts, separate from the selected axis, and never changes the drive.
    struct GroupMember {
        uint8_t address = 0;
        MotorControlRS::AxisConfig axis; ///< Own target and configuration generation; no host scale.
        ESS::IdentityObservation identity;
        ESS::ConfigObservation configuration;
        MotionProfileState profile; ///< Checked 0x0020/6 readback of this member.
        Probe::StateCache state;
        MotorControlRS::InputWiring inputWiring[4] = {}, outputWiring[2] = {};
        bool startSpeedRelationRequired = false; ///< A possible start-speed write reached this drive.
        StageSession stage;
        // Stored-word witness, as rememberedMoveWords for the selected axis: the
        // checked staged words a USE_STORED start may rely on.
        bool storedKnown = false;
        uint16_t storedWords[5] = {};
        uint32_t storedGeneration = 0, storedBinding = 0, storedSerial = 0;
    };
    struct GroupOperation {
        Probe::GroupResult result;
        HostTuple serialTuple;
        uint32_t serialGeneration = 0;
        uint32_t childId = 0; ///< Current read of a set or read sequence.
        uint8_t next = 0, phase = 0; ///< Member in progress; set: declaration read, staged move: 0 stage, 1 start.
        bool startsDone = false; ///< Every start resolved; ordinary work may run while members move.
        bool startsEnded = false, policyApplied = false, delivered = false, programmatic = false, interactive = false;
    };
    struct Group {
        GroupMember members[Probe::GROUP_CAPACITY];
        uint8_t count = 0; ///< Member slots of the declared or pending group.
        bool declared = false; ///< Every member joined with checked identity and configuration.
        uint32_t declaration = 0;
        GroupOperation set, read, move, stops[Probe::GROUP_STOP_OPERATIONS];
        Probe::GroupView view; ///< Scratch for synchronous show/status formatting.
        // Task-context scratch: nothing sized by the capacity lives on the loop stack.
        Probe::GroupCommand command; ///< Public API requests.
        MotorControlRS::InputWiring keptInputs[Probe::GROUP_CAPACITY][4], keptOutputs[Probe::GROUP_CAPACITY][2];
        uint32_t stopIds[Probe::GROUP_CAPACITY];
        Probe::Action stopAdmissions[Probe::GROUP_CAPACITY];
    } group;
    explicit App(const ApplicationOptions& supplied = ApplicationOptions()) : options(supplied), runner(uart.port(), storage(tx, rx, trace), timing()),
        owner(runner, busStorage(pending, results, producers)), console(host(this)) {
        hostTiming(serial.active, serial.timing);
        serial.original = serial.requested = serial.active;
        serial.activeKnown = platformReady;
        serial.actualBaud = platformReady ? uart.stats().actualBaud : 0;
        const uint32_t bauds[] = {9600, 19200, 38400, 115200};
        for (uint8_t i = 0; i < 4; ++i) {
            HostTuple candidate; candidate.baud = bauds[i];
            if (Esp32S3Uart::supports(candidate)) serial.supportedBauds[i] = bauds[i];
            serial.supportedFormats[i] = true;
            candidate.format = static_cast<HostFormat>(i);
            for (auto baud : bauds) {
                candidate.baud = baud;
                serial.supportedFormats[i] = serial.supportedFormats[i] && Esp32S3Uart::supports(candidate);
            }
        }
        axis.target.id = axis.target.address = 1; axis.target.generation = bindingGeneration;
        axis.units = options.positionUnits;
        const auto& commandScale = axis.units.commandStepsPerMotorTurn;
        simple.desired.scaleKnown = commandScale.numerator != 0;
        simple.desired.stepsPerTurn = MotorControlRS::Rational(commandScale.numerator, commandScale.denominator);
        persistencePrerequisites.maxAgeUs = observationAgeUs();
        axis.supportedRelativeBases = 1;
        // Application bench declaration: only power/RS485, no terminal wiring.
        for (auto& wiring : inputWiring) wiring = MotorControlRS::InputWiring::UNCONNECTED;
        for (auto& wiring : outputWiring) wiring = MotorControlRS::InputWiring::UNCONNECTED;
    }
};
App* app = nullptr;
void clearRecord(App::Record& record) {
    // Construct in its caller-owned PSRAM slot. A value-assignment temporary
    // would put the complete retained read/action/move contexts on the stack.
    record.~Record();
    new (&record) App::Record();
}
App::GroupMember* groupMember(App& a, uint8_t address) {
    for (uint8_t i = 0; i < a.group.count; ++i) if (a.group.members[i].address == address) return &a.group.members[i];
    return nullptr;
}
const App::GroupMember* groupMember(const App& a, uint8_t address) {
    return groupMember(const_cast<App&>(a), address);
}
// Configuration generation that a record's own target uses: the member's for a
// group child, otherwise the selected axis.
uint32_t recordGeneration(const App& a, const App::Record& record) {
    if (!record.groupChild) return a.axis.generation;
    const auto* member = groupMember(a, record.address);
    return member ? member->axis.generation : 0;
}
// Expire cached state of this address in the selected cache and the member cache.
void invalidateObservations(App& a, uint8_t address, uint64_t now, bool validOnly = false) {
    for (auto& block : a.stateCache.blocks)
        if ((!validOnly || block.valid) && block.value.target.address == address) block.invalidatedUs = now;
    if (auto* member = groupMember(a, address))
        for (auto& block : member->state.blocks) block.invalidatedUs = now;
}
// A possible configuration or profile change of a member drive: its prepared
// moves, profile binding and cached state expire. Fresh reads are required.
// Anything that may have written 0x0021..0x0025 of this drive ends the stored-word
// witnesses: the selected axis's remembered words and the member's staged words.
void storedWordsChanged(App& a, uint8_t address) {
    if (address == a.axis.target.address) a.rememberedMoveGeneration = 0;
    if (auto* member = groupMember(a, address)) member->storedKnown = false;
}
void invalidateMemberConfiguration(App& a, uint8_t address, uint64_t now) {
    auto* member = groupMember(a, address);
    if (!member) return;
    member->storedKnown = false;
    member->configuration.operationId = 0;
    member->axis.generation = !member->axis.generation || member->axis.generation == UINT32_MAX ? 0 : member->axis.generation + 1;
    for (auto& block : member->state.blocks) block.invalidatedUs = now;
}
// Rebinding, recovery, a host tuple change or a broadcast: every member's facts
// expire. Members stay listed; a new group set reads them again.
void invalidateGroupFacts(App& a, uint64_t now) {
    for (uint8_t i = 0; i < a.group.count; ++i) {
        auto& member = a.group.members[i];
        member.identity.operationId = 0;
        invalidateMemberConfiguration(a, member.address, now);
    }
}
// A group set, read or start sequence admits no other ordinary bus work; only
// urgent stops interleave. Starts already resolved release the bus.
bool groupSequencing(const App& a) {
    const auto& g = a.group;
    return g.set.result.pending || g.read.result.pending ||
        (g.move.result.pending && !g.move.policyApplied && (g.move.result.aborted || !g.move.startsDone));
}
bool emit(void* context, const char* text, std::size_t size) {
    App& a = *static_cast<App*>(context);
    if (size > Probe::OUTPUT_CAPACITY || a.outputCount == OUTPUT_LINES) { ++a.outputBlocked; return false; }
    App::Line& line = a.output[(a.outputHead + a.outputCount) % OUTPUT_LINES];
    std::memcpy(line.text, text, size); line.text[size] = '\n'; line.size = size + 1; line.offset = 0;
    ++a.outputCount; return true;
}
// Output queued with no accepted byte: the host is not draining USB, or a wakeup was lost.
void watchUsbOutput(App& a, bool progress) {
    auto& stall = a.usbStall;
    const uint64_t now = nowUs();
    if (progress || !a.outputCount) {
        if (stall.active) stall.longestUs = std::max(stall.longestUs, now - stall.startedUs);
        stall.active = stall.nudged = false; stall.progressUs = now;
        return;
    }
    if (!stall.active && now - stall.progressUs > 300000) {
        stall.active = true; stall.startedUs = stall.progressUs; ++stall.count;
        Platform::sampleConsole(stall.sample);
    }
    if (stall.active && !stall.nudged && now - stall.startedUs > 1000000) {
        stall.nudged = true;
        if (Platform::nudgeConsole()) ++stall.nudges;
    }
}
void drainOutput(App& a) {
    if (!a.outputCount) { watchUsbOutput(a, false); return; }
    RuntimeWitness::mark(RuntimeWitness::OUTPUT_SPACE);
    const int available = Platform::writableConsole();
    if (available <= 0) { ++a.outputBlocked; return; }
    App::Line& line = a.output[a.outputHead];
    const std::size_t count = std::min(std::size_t(64), std::min(line.size - line.offset, static_cast<std::size_t>(available)));
    RuntimeWitness::mark(RuntimeWitness::OUTPUT_WRITE);
    const std::size_t written = Platform::writeConsole(reinterpret_cast<const uint8_t*>(line.text + line.offset), count);
    if (written < count) ++a.outputShortWrites;
    line.offset += written;
    if (line.offset == line.size) { a.outputHead = (a.outputHead + 1) % OUTPUT_LINES; --a.outputCount; }
    watchUsbOutput(a, written > 0);
}
App::Record* findRecord(App& a, uint32_t operation) {
    for (auto& record : a.records) if (record.operationId && record.operationId == operation) return &record;
    return nullptr;
}
const App::Record* findRecord(const App& a, uint32_t operation) {
    for (const auto& record : a.records) if (record.operationId && record.operationId == operation) return &record;
    return nullptr;
}
bool sequenced(const App::Record& record) {
    switch (record.kind) {
    case App::OperationKind::ACTION: case App::OperationKind::MOVE:
    case App::OperationKind::VELOCITY: case App::OperationKind::DRIVER:
    case App::OperationKind::HOME: return true;
    case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION:
    case App::OperationKind::TYPED_READ: return false;
    }
    return false;
}
bool terminal(const App& a, const App::Record& record) {
    switch (record.kind) {
    case App::OperationKind::EMPTY: return false;
    case App::OperationKind::TRANSACTION: return a.owner.result(record.requestId) != nullptr;
    case App::OperationKind::TYPED_READ: return record.read.state != ReadState::ACTIVE;
    case App::OperationKind::ACTION: return record.action.state != MotorControlRS::ActionState::ACTIVE;
    case App::OperationKind::MOVE: return record.move.state != MotorControlRS::ActionState::ACTIVE;
    case App::OperationKind::VELOCITY: return record.velocity.state != MotorControlRS::ActionState::ACTIVE;
    case App::OperationKind::DRIVER: return record.driver.state != ReadState::ACTIVE;
    case App::OperationKind::HOME: return record.home.state != MotorControlRS::ActionState::ACTIVE;
    }
    return false;
}
bool resultPending(const App& a, const App::Record& record) {
    // Cancellation can finish the action before its attached recovery settles.
    return !terminal(a, record) || (record.stopRecoveryId && !record.stopRecoveryResult.id);
}
bool axisReserved(const App& a, uint8_t address = 0, bool includeHistory = true) {
    if (a.simple.view.pending && !a.simple.admitting && (!address || address == a.simple.view.address)) return true;
    // A staging write without a start still owns its drive until it settles.
    if (a.stage.view.pending && (!address || a.stage.view.target.address == address)) return true;
    for (uint8_t i = 0; i < a.group.count; ++i)
        if (a.group.members[i].stage.view.pending && (!address || a.group.members[i].address == address)) return true;
    if ((a.motionProfile.view.pending || a.motionProfile.view.restoreUnsettled) &&
        (!address || a.motionProfile.view.address == address)) return true;
    // Recovery changes correlation generation, not the physical target's uncertainty.
    if (includeHistory && address) {
        if (a.actionConflicts[address / 8] & (1U << (address % 8))) return true;
    } else if (includeHistory) for (const auto value : a.actionConflicts) if (value) return true;
    for (const auto& record : a.records)
        if (record.axisReserved && (includeHistory || !terminal(a, record)) && (!address || record.address == address)) return true;
    return false;
}
bool acting(const App& a) {
    if (a.simple.view.pending && !a.simple.admitting) return true;
    if (a.stage.view.pending) return true;
    for (const auto& record : a.records)
        if (sequenced(record) && !terminal(a, record)) return true;
    return false;
}
bool reading(const App& a) {
    for (const auto& record : a.records)
        if (record.operationId && record.kind == App::OperationKind::TYPED_READ && record.read.state == ReadState::ACTIVE) return true;
    return false;
}
// Raw observations keep their original transport generation. Only derived host
// coordinates are invalidated; exhaustion disables preparation instead of wrap.
void invalidateAxis(App& a, const App::Record* changing = nullptr, uint64_t sampled = 0) {
    a.bootOriginPending = false; // Loss of knowledge must never silently select a new zero.
    a.bootCoordinates = false;
    a.motionObservationPending = false;
    a.simpleEndpointKnown = false;
    if (!sampled) sampled = nowUs();
    if (!MotorControlRS::invalidateAxisReference(a.axis, a.coordinateReference)) a.axis.generation = 0;
    a.axis.target.generation = a.bindingGeneration;
    for (auto& record : a.records) if (&record != changing && !record.stopHeld &&
        !(record.groupChild && record.address != a.axis.target.address) &&
        (record.kind == App::OperationKind::MOVE || record.kind == App::OperationKind::VELOCITY || record.kind == App::OperationKind::HOME ||
         (record.kind == App::OperationKind::DRIVER && record.driver.kind == ESS::DriverKind::UPDATE) ||
         (record.kind == App::OperationKind::TYPED_READ && record.read.kind == ESS::ReadKind::STATE)) && !terminal(a, record)) {
        record.cancelContinuation = true;
        if (record.kind == App::OperationKind::HOME) ESS::revokeHome(record.home);
        if (record.requestId.owner) a.owner.cancelUnsent(record.requestId, sampled);
    }
}
bool coordinateKnowledge(const App& a) {
    return a.axis.originKnown || a.axis.encoderOriginKnown || a.axis.softLimitsKnown || a.coordinateReference.nativeKnown;
}
void invalidateMotionObservations(App& a, uint8_t address) {
    // Motion changes current position, not the fixed counter-to-host offset.
    // Keep raw history; require new observations before preparing another move.
    if (address == a.axis.target.address) {
        a.coordinateReference.nativeKnown = false;
        a.simpleEndpointKnown = false;
        a.motionObservationPending = true;
    }
    invalidateObservations(a, address, nowUs());
}
bool triggeredMotion(const App& a, uint8_t address) {
    for (const auto& record : a.records) {
        if (record.address != address) continue;
        // A locally cancelled operation can still be moving until a checked
        // stop resolves the interlock. Do not mistake that for external motion.
        if (terminal(a, record) && !record.motionUnresolved) continue;
        switch (record.kind) {
        case App::OperationKind::VELOCITY:
            if (record.velocity.triggerEvidence.txAccepted ||
                (record.velocity.phase == ESS::VelocityPhase::TRIGGER && record.requestId.owner && a.owner.txAccepted(record.requestId))) return true;
            break;
        case App::OperationKind::HOME:
            if (record.home.triggerEvidence.txAccepted ||
                (record.home.phase == ESS::HomePhase::TRIGGER && record.requestId.owner && a.owner.txAccepted(record.requestId))) return true;
            break;
        case App::OperationKind::MOVE:
            if (record.move.triggerEvidence.txAccepted ||
                (record.move.step == record.move.triggerStep && record.requestId.owner && a.owner.txAccepted(record.requestId))) return true;
            break;
        case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION: case App::OperationKind::TYPED_READ:
        case App::OperationKind::ACTION: case App::OperationKind::DRIVER: break;
        }
    }
    return false;
}
void serviceCoordinates(App& a, uint64_t now) {
    if (!coordinateKnowledge(a)) return;
    const auto& reference = a.coordinateReference;
    if (reference.nativeKnown && (now < reference.observedUs ||
        (reference.maximumAgeUs && now - reference.observedUs > reference.maximumAgeUs))) {
        // The last position sample expires; the fixed counter-to-host offset
        // does not. A later move obtains fresh state before using this origin.
        a.coordinateReference.nativeKnown = false;
        a.simpleEndpointKnown = false;
    }
    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
    // A status captured during our search cannot erase a newer correlated
    // stationary reference. Overlapping/newer bounds still invalidate it.
    const bool relevantMotion = !reference.nativeKnown || motion.observedLatestUs >= reference.observedUs;
    if (relevantMotion && Probe::fresh(motion, a.axis.target, now, a.observationAgeUs()) &&
        (motion.value.released || (motion.value.running && !a.motionObservationPending && !triggeredMotion(a, a.axis.target.address))))
        invalidateAxis(a);
}
MotorControlRS::AxisReference axisReference(const App& a) {
    using namespace MotorControlRS;
    AxisReference evidence = a.coordinateReference;
    if (!Probe::sameTarget(evidence.target, a.axis.target) ||
        evidence.configurationGeneration != a.axis.generation) evidence = AxisReference();
    evidence.target = a.axis.target; evidence.configurationGeneration = a.axis.generation;
    evidence.nowUs = nowUs();
    if (!evidence.nativeKnown) evidence.maximumAgeUs = a.observationAgeUs();
    evidence.idle = !a.owner.active() && !a.owner.pending() && !a.owner.recovering() &&
        !a.owner.needsRecovery() && !uart.needsRecovery() && !reading(a) && !a.monitorState.settings.enabled &&
        !axisReserved(a, a.axis.target.address);
    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
    evidence.stationary = false;
    if (Probe::fresh(motion, a.axis.target, evidence.nowUs, evidence.maximumAgeUs)) {
        if (!evidence.nativeKnown) {
            evidence.observedUs = motion.observedEarliestUs;
            evidence.source = ScaleSource::READBACK;
        }
        evidence.stationary = !motion.value.running && !motion.value.released && !motion.value.alarmFlag && motion.value.rawAlarm == 0;
    }
    // ESS pair signedness and its exact command relation remain unresolved.
    // A zero raw position is insufficient evidence for nativeKnown or an origin.
    return evidence;
}
MotorControlRS::Status axisCommand(void* context, const Probe::AxisCommand& command, Probe::AxisView& view) {
    using namespace MotorControlRS;
    App& a = *static_cast<App*>(context);
    view.commandPolarityKnown = a.commandPolarityKnown;
    if (command.kind == Probe::AxisCommandKind::QUERY) { view.configuration = a.axis; return Ok(); }
    if (a.owner.commissioningOwned() || a.discovery.owned) return Status(Err::INVALID_CONFIG, 0, "bus session owns the endpoint");
    if (a.simple.view.pending && !a.simple.admitting) return Status(Err::INVALID_CONFIG, 0, "simple move owns the axis");
    const AxisReference evidence = axisReference(a);
    if (command.kind == Probe::AxisCommandKind::PREPARE) {
        if (!a.commandPolarityKnown && command.position.frame != CoordinateFrame::NATIVE)
            return Status(Err::INVALID_CONFIG, 0, "host polarity requires reconciliation");
        PositionRequest request = command.position; request.configurationGeneration = a.axis.generation;
        const Status status = preparePosition(request, a.axis, evidence.nativeKnown ? &evidence : nullptr, view.prepared);
        if (status) view.configuration = a.axis;
        return status;
    }
    if (command.kind == Probe::AxisCommandKind::ORIGIN) {
        const Status status = setAxisOrigin(a.axis, command.value.numerator, evidence);
        if (status) {
            a.coordinateReference = evidence;
            a.coordinateReference.configurationGeneration = a.axis.generation;
            view.configuration = a.axis;
        }
        return status;
    }
    AxisConfig candidate = a.axis;
    UnitScale* scale = nullptr;
    switch (command.field) {
    case Probe::AxisField::COMMAND_SCALE: scale = &candidate.units.commandStepsPerMotorTurn; break;
    case Probe::AxisField::GEAR: scale = &candidate.units.motorTurnsPerLoadTurn; break;
    case Probe::AxisField::FULL_STEP_SCALE: scale = &candidate.units.fullStepsPerMotorTurn; break;
    case Probe::AxisField::LEAD: scale = &candidate.units.millimetresPerLoadTurn; break;
    case Probe::AxisField::ENCODER_SCALE: scale = &candidate.units.encoder.countsPerUnit; break;
    case Probe::AxisField::ENCODER_ID: candidate.units.encoder.sourceId = static_cast<uint32_t>(command.value.numerator); break;
    case Probe::AxisField::ENCODER_BASIS: candidate.units.encoder.basis = command.encoderBasis; break;
    case Probe::AxisField::ENCODER_POLARITY: candidate.units.encoder.polarity = static_cast<int8_t>(command.value.numerator); break;
    case Probe::AxisField::POLARITY: candidate.units.commandPolarity = static_cast<int8_t>(command.value.numerator); break;
    case Probe::AxisField::POSITION_UNIT: candidate.units.settings.position = command.positionUnit; break;
    case Probe::AxisField::VELOCITY_UNIT: candidate.units.settings.velocity = command.velocityUnit; break;
    case Probe::AxisField::ACCELERATION_UNIT: candidate.units.settings.acceleration = command.accelerationUnit; break;
    case Probe::AxisField::NATIVE_LIMITS:
        candidate.nativeMinimum = command.value.numerator; candidate.nativeMaximum = command.secondValue.numerator; break;
    case Probe::AxisField::SOFT_LIMITS:
        candidate.softLimitsKnown = !command.clear;
        candidate.softMinimum = command.value.numerator; candidate.softMaximum = command.secondValue.numerator; break;
    case Probe::AxisField::RELATIVE_BASES: candidate.supportedRelativeBases = static_cast<uint8_t>(command.value.numerator); break;
    }
    if (scale) *scale = command.clear ? UnitScale() :
        UnitScale(static_cast<uint32_t>(command.value.numerator), static_cast<uint32_t>(command.value.denominator), ScaleSource::ASSUMED);
    const Status status = configureAxis(a.axis, candidate, evidence, &a.coordinateReference);
    if (status) {
        if (command.field == Probe::AxisField::COMMAND_SCALE) {
            // The explicit axis API is authoritative for future simple moves.
            // Keep admitted/retained session settings unchanged.
            const auto& commandScale = a.axis.units.commandStepsPerMotorTurn;
            a.simple.desired.scaleKnown = commandScale.numerator != 0;
            a.simple.desired.stepsPerTurn = Rational(commandScale.numerator, commandScale.denominator);
        }
        if (command.field == Probe::AxisField::POLARITY) a.commandPolarityKnown = true;
        view.commandPolarityKnown = a.commandPolarityKnown;
        view.configuration = a.axis;
    }
    return status;
}
void snapshot(void* context, Probe::Snapshot& s) {
    App& a = *static_cast<App*>(context);
    s = Probe::Snapshot();
    s.staleAfterMs = a.options.observationMaxAgeMs;
    s.bindingGeneration = a.bindingGeneration;
    s.nowUs = nowUs(); s.stateCache = &a.stateCache; s.monitorState = a.monitorState;
    s.communicationKnown = a.communicationKnown;
    s.communicationTarget = a.communicationTarget;
    s.communicationEarliestUs = a.communicationEarliestUs;
    s.communicationLatestUs = a.communicationLatestUs;
    s.cachedIdentityId = a.identity.operationId; s.cachedIdentityAddress = a.identity.target.address;
    s.cachedIdentityGeneration = a.identity.target.generation;
    s.cachedConfigId = a.configuration.operationId; s.cachedConfigAddress = a.configuration.target.address;
    s.cachedConfigGeneration = a.configuration.target.generation;
    s.address = a.axis.target.address; s.probeAddress = a.address; s.baud = a.serial.activeKnown ? a.serial.active.baud : 0; s.responseTimeoutUs = a.serial.timing.responseTimeoutUs;
    s.serial = a.serial;
    RuntimeWitness::mark(RuntimeWitness::SNAPSHOT);
    s.previousRuntimeValid = RuntimeWitness::previous.magic == RuntimeWitness::MAGIC;
    s.previousRuntimeStage = RuntimeWitness::previous.stage;
    s.previousRuntimeUptimeMs = RuntimeWitness::previous.uptimeMs;
    s.previousRuntimeLoops = RuntimeWitness::previous.loops;
    s.previousRuntimeInputLines = RuntimeWitness::previous.inputLines;
    s.previousRuntimeOutputQueued = RuntimeWitness::previous.outputQueued;
    s.previousRuntimeOutputBlocked = RuntimeWitness::previous.outputBlocked;
    s.ownerWatchdog = OwnerWatchdog::subscribed;
    s.ownerWatchdogError = OwnerWatchdog::error;
    s.ownerWatchdogTimeoutMs = OwnerWatchdog::TIMEOUT_MS;
    s.resetReason = OwnerWatchdog::resetReason;
    s.usbStallCount = a.usbStall.count; s.usbStallNudges = a.usbStall.nudges;
    s.usbStallLongestUs = a.usbStall.longestUs; s.usbStallActive = a.usbStall.active;
    s.usbInterruptRaw = a.usbStall.sample.interruptRaw; s.usbInterruptEnable = a.usbStall.sample.interruptEnable;
    s.usbInFifoState = a.usbStall.sample.inFifoState; s.usbEndpoint = a.usbStall.sample.endpoint;
    s.usbConnected = a.usbStall.sample.connected;
    s.ownerCompletedLoops = OwnerWatchdog::completedLoops;
    s.ownerWatchdogFeedUs = OwnerWatchdog::lastFeedUs;
    s.replyGapUs = a.serial.timing.replyGapUs; s.gap15Us = a.serial.timing.runner.gap15Us; s.gap35Us = a.serial.timing.runner.gap35Us;
    s.uptimeMs = nowUs() / 1000; s.ready = platformReady && a.serial.activeKnown && !a.serial.blocked; s.timingQualified = false;
    s.writeResponseConfirmed = writeResponseConfirmed; s.axisReserved = axisReserved(a);
    s.busy = a.discovery.owned || a.owner.commissioningOwned() || a.owner.active() || a.owner.pending() || a.owner.recovering() || reading(a) || acting(a);
    s.recoveryRequired = a.serial.blocked || a.owner.needsRecovery() || uart.needsRecovery();
    s.phase = a.runner.phase(); s.transport = a.runner.result().reason; s.transmitEnabled = a.runner.transmitEnabled();
    s.codecChecked = a.codecChecked; s.codec = a.codec; s.frameError = a.frameError;
    s.probeKnown = a.known; s.probeOk = a.ok; s.rawModel = a.model;
    s.modelKnown = a.modelKnown; s.modelAddress = a.modelAddress;
    s.modelOperationId = a.modelKnown ? a.modelOperationId : 0;
    s.ageMs = a.modelKnown && a.observedEarliestUs ? (nowUs() - a.observedEarliestUs) / 1000 : 0;
    s.observedEarliestUs = a.observedEarliestUs; s.observedLatestUs = a.observedLatestUs;
    s.deliveredUs = a.deliveredUs; s.recoveryGuardUntilUs = a.recoveryGuardUntilUs;
    s.operationId = a.latestOperationId; s.pending = a.owner.pending(); s.pendingCapacity = ORDINARY_PENDING; s.resultCapacity = REQUEST_CAPACITY;
    for (const auto& record : a.records) if (record.operationId && !record.monitored) {
        if (terminal(a, record)) ++s.retained; else ++s.reserved;
    }
    s.outputQueued = a.outputCount; s.outputBlocked = a.outputBlocked; s.outputShortWrites = a.outputShortWrites;
    s.inputBytes = a.inputBytes; s.inputLines = a.inputLines; s.stats = a.runner.stats();
    s.inputDropped = a.console.inputDropped();
    s.stopEvidenceOverwritten = a.stopEvidenceOverwritten;
    s.automaticRecoveryOperationId = a.recovery.automatic ? a.recovery.operationId : 0;
    RuntimeWitness::mark(RuntimeWitness::CAPTURE_STATS);
    s.timerCapture = uart.stats().timer;
    for (const auto& record : a.records) if (record.operationId && !terminal(a, record)) {
        if (!s.deadlineUs || record.deadlineUs < s.deadlineUs) s.deadlineUs = record.deadlineUs;
    }
    if (a.owner.recovering() && (!s.deadlineUs || a.recovery.deadlineUs < s.deadlineUs))
        s.deadlineUs = a.recovery.deadlineUs;
    if (a.discovery.owned && (!s.deadlineUs || a.discovery.deadlineUs < s.deadlineUs))
        s.deadlineUs = a.discovery.deadlineUs;
    const auto capture = uart.stats(); s.maxPollGapUs = capture.maxGapUs; s.captureFaults = capture.faults; s.rxErrors = capture.rxErrors;
    s.cacheOffSupported = Esp32S3Uart::CACHE_OFF_SUPPORTED;
    s.sampleGapLimitUs = capture.timer ? capture.sampleGapLimitUs : 0;
    s.sampleGapExceeded = capture.sampleGapExceeded;
    s.cacheInterrupted = capture.cacheInterrupted;
    s.memoryValid = true;
    RuntimeWitness::mark(RuntimeWitness::HEAP_STATS);
    s.internalFree = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s.internalMin = heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s.internalLargest = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
    s.psramFree = heap_caps_get_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    s.psramMin = heap_caps_get_minimum_free_size(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    s.psramLargest = heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    RuntimeWitness::mark(RuntimeWitness::STACK_STATS);
    s.stackFreeBytes = uxTaskGetStackHighWaterMark(nullptr);
    RuntimeWitness::mark(RuntimeWitness::CONSOLE);
}
MotorControlRS::Status checkProbe(const Rtu::Expectation& e, const uint8_t* bytes, std::size_t size) {
    uint16_t model = 0; return MotorControlRS::ESS_RS::parseProbe(bytes, size, e.address, model);
}
Probe::Action startRead(void* context, uint32_t commandId, uint8_t address, uint32_t& operationId, bool captureRead) {
    App& a = *static_cast<App*>(context);
    if (a.owner.commissioningOwned() || a.discovery.owned || groupSequencing(a)) return Probe::Action::BUSY;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    const uint64_t sampled = uart.sample();
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    App::Record* record = nullptr;
    for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    uint8_t bytes[8]; Rtu::BusRequest request;
    const uint16_t first = captureRead ? Probe::CAPTURE_FIRST : 0;
    const uint16_t count = captureRead ? Probe::CAPTURE_WORDS : 1;
    request.wire.bytes = bytes;
    if (captureRead) request.wire.length = ESS::buildReadRegisters(address, first, count, bytes, sizeof(bytes));
    else {
        MotorControlRS::ESS_RS::PreparedProbe prepared;
        MotorControlRS::ReadTarget target; target.id = address; target.address = address; target.generation = a.bindingGeneration;
        if (!MotorControlRS::prepareProbe(prepared, MotorControlRS::DriveProfile::ESS_RS, target,
                a.nextOperationId, sampled, sampled + REQUEST_US, communicationTuple(a.serial.active))) return Probe::Action::INVALID;
        std::memcpy(bytes, prepared.bytes, prepared.length); request.wire.length = prepared.length;
    }
    request.wire.replyLength = MotorControlRS::ESS_RS::expectedReadRegistersLen(count);
    request.wire.responseTimeoutUs = a.serial.timing.responseTimeoutUs;
    request.wire.replyGapUs = a.serial.timing.replyGapUs; // Only the default bench tuple has a reviewed first-reply override.
    request.wire.deadlineUs = sampled + REQUEST_US;
    request.expected.address = address; request.expected.function = 3; request.expected.first = first; request.expected.count = count;
    request.expected.target = address; request.expected.targetGeneration = a.bindingGeneration;
    request.validator = Rtu::essValidator();
    if (!captureRead) request.validator.checkReply = checkProbe;
    Rtu::RequestId id;
    switch (a.owner.admit(request, sampled, id)) {
    case Rtu::BusAdmission::ACCEPTED: break;
    case Rtu::BusAdmission::QUEUE_FULL: return Probe::Action::QUEUE_FULL;
    case Rtu::BusAdmission::RESULTS_FULL: return Probe::Action::RESULTS_FULL;
    case Rtu::BusAdmission::IDS_EXHAUSTED: return Probe::Action::IDS_EXHAUSTED;
    default: return Probe::Action::FAILED;
    }
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->requestId = id; operationId = a.latestOperationId = record->operationId;
    record->deadlineUs = request.wire.deadlineUs;
    record->kind = App::OperationKind::TRANSACTION; record->captureRead = captureRead;
    return Probe::Action::OK;
}
Probe::Action probe(void* context, uint32_t commandId, uint8_t address, uint32_t& operationId) {
    return startRead(context, commandId, address, operationId, false);
}
Probe::Action captureRead(void* context, uint32_t commandId, uint8_t address, uint32_t& operationId) {
    return startRead(context, commandId, address, operationId, true);
}
// Multi-drive 01 bench fixture: exactly these reviewed address-0 FC06 frames.
// It is not a production API, a raw-frame command or a wider isValidAddress.
// No reply is accepted as confirmation. Each drive needs separate unicast
// checks; received bytes fault the trial. Nothing resends a broadcast.
constexpr uint32_t BROADCAST_WINDOW_US = 200000;
constexpr std::size_t BROADCAST_FRAME_COUNT = 5;
const uint8_t BROADCAST_FRAMES[BROADCAST_FRAME_COUNT][8] = {
    {0x00, 0x06, 0x00, 0x21, 0x01, 0x2C, 0xD8, 0x5C}, // 0x0021 acceleration time = 300 ms
    {0x00, 0x06, 0x00, 0x21, 0x01, 0x2D, 0x19, 0x9C}, // 0x0021 acceleration time = 301 ms
    {0x00, 0x06, 0x00, 0x27, 0x00, 0x01, 0xF9, 0xD0}, // 0x0027 relative position start
    {0x00, 0x06, 0x00, 0x27, 0x01, 0x00, 0x39, 0x80}, // 0x0027 stop normal
    {0x00, 0x06, 0x00, 0x27, 0x02, 0x00, 0x39, 0x70}, // 0x0027 stop fast
};
#if MOTORCONTROLRS_LOAD_FIXTURE
bool listedBroadcast(const Rtu::Expectation& e, const Rtu::Request& r) {
    if (e.address != 0 || e.function != 6 || e.count != 1 || !r.bytes || r.length != 8 || r.replyLength ||
        r.silenceUs != BROADCAST_WINDOW_US) return false;
    for (const auto& frame : BROADCAST_FRAMES)
        if (std::memcmp(r.bytes, frame, sizeof(frame)) == 0)
            return e.first == static_cast<uint16_t>(frame[2] << 8 | frame[3]) &&
                e.value == static_cast<uint16_t>(frame[4] << 8 | frame[5]);
    return false;
}
MotorControlRS::Status noBroadcastReply(const Rtu::Expectation&, const uint8_t*, std::size_t) {
    return MotorControlRS::Status(MotorControlRS::Err::FRAME_ERROR, 0, "broadcast has no reply");
}
Probe::Action startBroadcast(App& a, uint32_t commandId, Probe::BroadcastFrame frame, uint32_t& operationId) {
    const auto index = static_cast<std::size_t>(frame);
    if (index >= BROADCAST_FRAME_COUNT) return Probe::Action::INVALID;
    const bool stop = frame == Probe::BroadcastFrame::STOP_NORMAL || frame == Probe::BroadcastFrame::STOP_FAST;
    if (a.owner.commissioningOwned() || a.discovery.owned) return Probe::Action::BUSY;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    const uint64_t now = uart.sample();
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    // A stop passes a unicast move's axis reservation, as urgent stops do. It
    // uses ordinary capacity, so the urgent unicast stop stays available. A
    // write or start needs an idle host: no work, reservation or monitor.
    if (!stop && (a.owner.active() || a.owner.pending() || axisReserved(a) || acting(a) || reading(a) || groupSequencing(a) ||
        a.monitorState.settings.enabled || a.motionProfile.view.pending || a.persistenceCapture ||
        a.persistenceRequest.owner || a.persistenceReadRequest.owner || a.commissioningRequest.owner))
        return Probe::Action::BUSY;
    App::Record* record = nullptr;
    for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    const uint8_t* bytes = BROADCAST_FRAMES[index];
    Rtu::BusRequest request;
    request.wire.bytes = bytes; request.wire.length = sizeof(BROADCAST_FRAMES[index]);
    request.wire.silenceUs = BROADCAST_WINDOW_US;
    request.wire.deadlineUs = now + BROADCAST_WINDOW_US + REQUEST_US;
    request.expected.address = 0; request.expected.function = 6; request.expected.count = 1;
    request.expected.first = static_cast<uint16_t>(bytes[2] << 8 | bytes[3]);
    request.expected.value = static_cast<uint16_t>(bytes[4] << 8 | bytes[5]);
    request.expected.targetGeneration = a.bindingGeneration;
    request.validator.checkRequest = listedBroadcast; request.validator.checkReply = noBroadcastReply;
    Rtu::RequestId id;
    switch (a.owner.admit(request, now, id)) {
    case Rtu::BusAdmission::ACCEPTED: break;
    case Rtu::BusAdmission::QUEUE_FULL: return Probe::Action::QUEUE_FULL;
    case Rtu::BusAdmission::RESULTS_FULL: return Probe::Action::RESULTS_FULL;
    case Rtu::BusAdmission::IDS_EXHAUSTED: return Probe::Action::IDS_EXHAUSTED;
    default: return Probe::Action::FAILED;
    }
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = 0;
    record->requestId = id; operationId = a.latestOperationId = record->operationId;
    record->deadlineUs = request.wire.deadlineUs;
    record->kind = App::OperationKind::TRANSACTION; record->broadcastFrame = static_cast<uint8_t>(index + 1);
    return Probe::Action::OK;
}
Probe::Action broadcast(void* context, uint32_t commandId, Probe::BroadcastFrame frame, uint32_t& operationId) {
    return startBroadcast(*static_cast<App*>(context), commandId, frame, operationId);
}
#endif
Rtu::BusAdmission admitStep(App& a, App::Record& record, uint64_t sampled) {
    ESS::PreparedRead prepared;
    if (!ESS::nextRead(record.read, sampled, prepared)) return Rtu::BusAdmission::EXPIRED;
    Rtu::BusRequest request;
    request.wire.bytes = prepared.bytes; request.wire.length = prepared.length;
    request.wire.replyLength = ESS::expectedReadRegistersLen(prepared.count);
    request.wire.responseTimeoutUs = a.serial.timing.responseTimeoutUs; request.wire.replyGapUs = a.serial.timing.replyGapUs;
    request.wire.deadlineUs = prepared.deadlineUs;
    request.expected.address = prepared.target.address; request.expected.function = 3;
    request.expected.target = prepared.target.id; request.expected.targetGeneration = prepared.target.generation;
    request.expected.first = prepared.first; request.expected.count = prepared.count;
    request.validator = Rtu::essValidator();
    const auto admitted = a.owner.admit(request, sampled, record.requestId);
    if (admitted == Rtu::BusAdmission::ACCEPTED && record.read.kind == ESS::ReadKind::STATE) {
        auto* member = record.groupChild ? groupMember(a, record.read.target.address) : nullptr;
        if (!record.groupChild) Probe::stateAttempt(a.stateCache, record.read.target, record.read.operationId, record.read.step, sampled);
        else if (member && Probe::sameTarget(member->axis.target, record.read.target))
            Probe::stateAttempt(member->state, record.read.target, record.read.operationId, record.read.step, sampled);
    }
    return admitted;
}
Probe::Action startTypedRead(void* context, uint32_t commandId, uint8_t address, ESS::ReadKind kind,
                             uint32_t& operationId, bool monitored) {
    App& a = *static_cast<App*>(context);
    if (a.owner.commissioningOwned() || a.discovery.owned || groupSequencing(a)) return Probe::Action::BUSY;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    const uint64_t sampled = uart.sample();
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    if ((kind == ESS::ReadKind::VELOCITY_PARAMETERS || kind == ESS::ReadKind::HOMING_PARAMETERS) &&
        address != a.axis.target.address)
        return Probe::Action::INVALID;
    App::Record* record = nullptr;
    if (monitored) {
        if (!a.records[REQUEST_CAPACITY].operationId) record = &a.records[REQUEST_CAPACITY];
    } else for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    MotorControlRS::ReadTarget target; target.id = address; target.address = address; target.generation = a.bindingGeneration;
    const auto serial = communicationTuple(a.serial.active);
    const auto* configuration = a.configuration.operationId && Probe::sameTarget(a.configuration.target, target) ?
        &a.configuration : nullptr;
    const auto prepared = kind == ESS::ReadKind::IDENTITY ?
        ESS::prepareIdentity(record->read, target, a.nextOperationId, sampled, sampled + REQUEST_US, serial) :
        kind == ESS::ReadKind::HOMING_PARAMETERS ?
        ESS::prepareHomingParameters(record->read, target, a.nextOperationId, a.axis.generation,
            sampled, sampled + REQUEST_US, serial) : kind == ESS::ReadKind::VELOCITY_PARAMETERS ?
        ESS::prepareVelocityParameters(record->read, target, a.nextOperationId, a.axis.generation,
            sampled, sampled + REQUEST_US, serial) : kind == ESS::ReadKind::STATE ?
        ESS::prepareState(record->read, target, a.nextOperationId, sampled, sampled + REQUEST_US, serial, configuration) :
        ESS::prepareConfig(record->read, target, a.nextOperationId, sampled, sampled + REQUEST_US, serial,
            address == a.axis.target.address ? a.inputWiring : nullptr);
    if (!prepared || (kind != ESS::ReadKind::IDENTITY && kind != ESS::ReadKind::CONFIG &&
        kind != ESS::ReadKind::STATE && kind != ESS::ReadKind::VELOCITY_PARAMETERS && kind != ESS::ReadKind::HOMING_PARAMETERS)) {
        clearRecord(*record); return Probe::Action::INVALID;
    }
    const auto admitted = admitStep(a, *record, sampled);
    if (admitted != Rtu::BusAdmission::ACCEPTED) {
        clearRecord(*record);
        return admitted == Rtu::BusAdmission::QUEUE_FULL ? Probe::Action::QUEUE_FULL :
            admitted == Rtu::BusAdmission::RESULTS_FULL ? Probe::Action::RESULTS_FULL : Probe::Action::FAILED;
    }
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->deadlineUs = record->read.deadlineUs; record->kind = App::OperationKind::TYPED_READ;
    record->configurationGeneration = a.axis.generation;
    record->monitored = monitored; operationId = record->operationId;
    if (!monitored) a.latestOperationId = operationId;
    return Probe::Action::OK;
}
Probe::Action typedRead(void* context, uint32_t commandId, uint8_t address, ESS::ReadKind kind, uint32_t& operationId) {
    return startTypedRead(context, commandId, address, kind, operationId, false);
}
MotorControlRS::ActionEvent actionEvent(const App::Record& record, ReadEventKind kind) {
    MotorControlRS::ActionEvent event;
    switch (record.kind) {
    case App::OperationKind::HOME: event.transport.target = record.home.target; event.transport.step = record.home.step; break;
    case App::OperationKind::DRIVER: event.transport.target = record.driver.target; event.transport.step = record.driver.step; break;
    case App::OperationKind::VELOCITY:
        event.transport.target = record.velocity.phase == ESS::VelocityPhase::STOPPING ?
            record.velocity.stop.target : record.velocity.target;
        event.transport.step = record.velocity.step; break;
    case App::OperationKind::MOVE: event.transport.target = record.move.target; event.transport.step = record.move.step; break;
    case App::OperationKind::ACTION: event.transport.target = record.action.target; event.transport.step = record.action.step; break;
    case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION: case App::OperationKind::TYPED_READ: break;
    }
    event.transport.operationId = record.operationId;
    event.transport.kind = kind;
    return event;
}
// Copy the owner's borrowed transport evidence consistently. Callers retain
// their operation/step correlation and choose their own terminal-event and
// response-source policies; the typed parser still validates the frame.
void copyCompletion(MotorControlRS::ReadEvent& event, const Rtu::Completion& result) {
    event.target.id = result.expected.target;
    event.target.address = result.expected.address;
    event.target.generation = result.expected.targetGeneration;
    event.txAccepted = result.transport.txAccepted;
    event.executionUnknown = result.executionUnknown;
    event.transportDetail = static_cast<int32_t>(result.transport.reason);
    event.frame = result.transport.rxLength ? result.raw : nullptr;
    event.length = result.transport.rxLength;
    event.qualified = event.kind == ReadEventKind::FRAME && result.transport.closureQualified;
    event.earliestUs = event.qualified ? result.transport.closureEarliestUs : 0;
    event.latestUs = event.qualified ? result.transport.closureLatestUs : 0;
}
Rtu::BusAdmission admitActionStep(App& a, App::Record& record, const ESS::PreparedAction& prepared, uint64_t now) {
    Rtu::BusRequest request;
    request.wire.bytes = prepared.bytes; request.wire.length = prepared.length;
    request.wire.replyLength = prepared.write ? ESS::WRITE_RESPONSE_LEN : ESS::expectedReadRegistersLen(prepared.count);
    request.wire.responseTimeoutUs = a.serial.timing.responseTimeoutUs; request.wire.replyGapUs = a.serial.timing.replyGapUs;
    request.wire.deadlineUs = prepared.deadlineUs;
    request.expected.address = prepared.target.address; request.expected.function = prepared.write ? 6 : 3;
    request.expected.target = prepared.target.id; request.expected.targetGeneration = prepared.target.generation;
    request.expected.first = prepared.reg; request.expected.count = prepared.write ? 1 : prepared.count;
    request.expected.value = prepared.value; request.validator = Rtu::essValidator();
    return record.action.request.kind == MotorControlRS::ActionKind::STOP ?
        a.owner.admitUrgent(request, now, record.requestId) : a.owner.admit(request, now, record.requestId);
}
bool enableSettling(const App& a, uint8_t address, uint64_t now) {
    return ESS::isValidAddress(address) && now < a.enableWaits[address].untilUs;
}
// The pair reads high bits set below zero; the move sequence decodes it the same way.
// Beyond the +/-0x0FFFFFFF target range (function manual p70) it is no usable zero.
bool signedFeedback(uint32_t raw, int64_t& native) {
    native = raw > INT32_MAX ? static_cast<int64_t>(raw) - (int64_t(1) << 32) : static_cast<int64_t>(raw);
    return native >= -0x0FFFFFFF && native <= 0x0FFFFFFF;
}
#include "MotionReadinessApp.h"
#include "MotionProfileApp.h"
void cancelSimplePreparation(App&, uint8_t, uint64_t);
void cancelPositionStages(App&, uint8_t, uint64_t);

bool confirmedStop(const App::Record& record) {
    using namespace MotorControlRS;
    return record.action.state == ActionState::SUCCEEDED &&
        record.action.execution == ActionExecution::ACKNOWLEDGED &&
        record.action.completion == ActionCompletion::OBSERVED;
}
// Stop storage never depends on ordinary capacity. The next explicit stop first
// acknowledges a delivered confirmed stop, then uses a free slot, then overwrites
// the oldest delivered failed stop (counted). A running or undelivered stop stays.
// The selected-address pool and the group pool follow the same rule.
App::Record* availableStopRecord(App& a, std::size_t first, std::size_t count) {
    App::Record* available = nullptr;
    App::Record* oldest = nullptr;
    App::Record* confirmed = nullptr;
    for (std::size_t i = first; i < first + count; ++i) {
        App::Record& candidate = a.records[i];
        if (!candidate.operationId) { if (!available) available = &candidate; continue; }
        if (resultPending(a, candidate) || !candidate.delivered) continue;
        if (confirmedStop(candidate)) {
            if (!confirmed || candidate.operationId < confirmed->operationId) confirmed = &candidate;
            continue;
        }
        if (!oldest || candidate.operationId < oldest->operationId) oldest = &candidate;
    }
    return confirmed ? confirmed : available ? available : oldest;
}
App::Record* stopRecord(App& a, bool group = false, uint8_t address = 0,
                      MotorControlRS::StopBehavior behavior = MotorControlRS::StopBehavior::UNSPECIFIED) {
    if (group) return availableStopRecord(a, GROUP_STOP_FIRST, GROUP_STOP_RECORDS);
    // One undelivered escalation per address leaves the other reserve usable.
    for (std::size_t i = STOP_ESCALATION_FIRST; i < GROUP_STOP_FIRST; ++i)
        if (a.records[i].operationId && a.records[i].address == address &&
            (resultPending(a, a.records[i]) || !a.records[i].delivered)) return nullptr;
    if (auto* primary = availableStopRecord(a, REQUEST_CAPACITY + 1, STOP_RECORDS)) return primary;
    if (behavior != MotorControlRS::StopBehavior::DIRECT) return nullptr;
    for (std::size_t i = REQUEST_CAPACITY + 1; i < STOP_ESCALATION_FIRST; ++i)
        if (a.records[i].operationId && a.records[i].address == address &&
            a.records[i].action.request.stop.behavior == MotorControlRS::StopBehavior::CONFIGURED_DECELERATION)
            return availableStopRecord(a, STOP_ESCALATION_FIRST, STOP_ESCALATIONS);
    return nullptr;
}
bool failedTransmittedStop(App& a, uint32_t id) {
    const auto* record = findRecord(a, id);
    return record && record->kind == App::OperationKind::ACTION && !record->groupChild &&
        record->action.request.kind == MotorControlRS::ActionKind::STOP &&
        record->action.state == MotorControlRS::ActionState::FAILED &&
        (record->action.execution == MotorControlRS::ActionExecution::UNKNOWN ||
         record->action.execution == MotorControlRS::ActionExecution::ACKNOWLEDGED) &&
        record->action.completion == MotorControlRS::ActionCompletion::NOT_OBSERVED &&
        (a.actionConflicts[record->address / 8] & (1U << (record->address % 8))) &&
        record->action.writeEvidence.txAccepted != 0 && record->address == a.axis.target.address &&
        sameTuple(record->serialTuple, a.serial.active);
}
bool releaseFactsValid(const App& a, const ReleaseAfterStopPrerequisites& facts, uint64_t now) {
    return facts.target.id == a.axis.target.id && facts.target.address == a.axis.target.address &&
        facts.target.generation == a.bindingGeneration && facts.configurationGeneration == a.axis.generation &&
        facts.configurationGeneration && MotorControlRS::evidenceAgeValid(facts.qualifiedUs, now, a.observationAgeUs()) &&
        facts.mechanicsPermitRelease && facts.externalTriggersInhibited;
}
bool positionClearQualificationValid(const App& a) {
    const auto& p = a.positionClearQualification;
    return p.semanticsQualified && p.target.id && a.axis.generation &&
        Probe::sameTarget(p.target, a.axis.target) && p.target.generation == a.bindingGeneration &&
        p.configurationGeneration == a.axis.generation;
}
bool positionClearReadiness(const App& a, uint8_t address, uint64_t now) {
    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
    return a.axis.target.address == address && Probe::fresh(motion, a.axis.target, now, a.observationAgeUs()) &&
        !motion.value.running && !motion.value.released && !motion.value.rawAlarm && !motion.value.alarmFlag;
}
// A declared group member is a stop target even when its readiness facts are stale.
Probe::Action startActionIn(App& a, uint32_t commandId, uint8_t address,
                            const MotorControlRS::ActionRequest& request, uint32_t& operationId, bool groupStop,
                            uint32_t failedStopId = 0, const ReleaseAfterStopPrerequisites* releaseFacts = nullptr) {
    using namespace MotorControlRS;
    const bool scanStop = a.discovery.owned && request.kind == ActionKind::STOP &&
        address == a.discovery.originalTarget.address;
    if (a.owner.commissioningOwned() || (a.discovery.owned && !scanStop)) return Probe::Action::BUSY;
    if (scanStop && a.discovery.phase == Probe::DiscoveryPhase::INTERLOCK) return Probe::Action::RECOVERY_REQUIRED;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    const uint64_t now = uart.sample();
    const bool stop = request.kind == ActionKind::STOP;
    if (releaseFacts && (request.kind != ActionKind::RELEASE || !failedTransmittedStop(a, failedStopId) ||
        !releaseFactsValid(a, *releaseFacts, now))) return Probe::Action::QUALIFICATION_REQUIRED;
    if (groupStop && (!stop || scanStop || !groupMember(a, address))) return Probe::Action::INVALID;
    if (!stop && groupSequencing(a)) return Probe::Action::BUSY;
    ActionRequest admittedRequest = request;
    uint64_t deadline = now + REQUEST_US + (stop ? STOP_RECOVERY_US : 0);
    ActionOptions actionOptions;
    if (stop && request.stop.behavior == StopBehavior::CONFIGURED_DECELERATION) {
        // ESS permits a 2000-ms native deceleration. Observe that ramp plus
        // request/settlement margin; the short generic action policy can end
        // before a valid stop finishes. This bounds observation, not the wire
        // response timeout, and never delays or repeats the priority stop write.
        deadline = now + NORMAL_STOP_US + STOP_RECOVERY_US;
        actionOptions.pollIntervalUs = NORMAL_STOP_POLL_US;
        actionOptions.maxPolls = ESS::ACTION_MAX_POLLS;
    }
    if (request.kind == ActionKind::CLEAR_POSITION) {
        if (request.devicePosition != 0) return Probe::Action::UNSUPPORTED;
        if (!positionClearQualificationValid(a)) return Probe::Action::QUALIFICATION_REQUIRED;
        const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
        const uint64_t age = a.observationAgeUs();
        if (!positionClearReadiness(a, address, now)) return Probe::Action::UNAVAILABLE;
        const uint64_t readinessEnd = evidenceAgeDeadline(motion.observedEarliestUs, age);
        if (readinessEnd <= now) return Probe::Action::UNAVAILABLE;
        if (readinessEnd < deadline) deadline = readinessEnd;
        admittedRequest.positionClearQualified = true;
    }
    ReadTarget target; target.id = address; target.address = address; target.generation = a.bindingGeneration;
    ESS::ActionContext preparedContext;
    const Status prepared = ESS::prepareAction(preparedContext, target, a.nextOperationId, admittedRequest, now, deadline, actionOptions);
    if (!prepared) return prepared.code == Err::UNSUPPORTED ? Probe::Action::UNSUPPORTED : Probe::Action::INVALID;
    // Ordinary stops may wait for one recovery. Discovery owns its tuple and
    // must first complete its explicit recovery/restoration contract.
    const bool faulted = a.owner.needsRecovery() || uart.needsRecovery();
    if (faulted && (!stop || scanStop)) return Probe::Action::RECOVERY_REQUIRED;
    const bool selectedStop = stop && !scanStop && (address == a.axis.target.address || groupStop);
    if (!(a.knownTargets[address / 8] & (1U << (address % 8))) && !selectedStop &&
        !(scanStop && a.discoveryOriginalKnown)) return Probe::Action::UNAVAILABLE;
    if (!stop && axisReserved(a, address, releaseFacts == nullptr)) return Probe::Action::AXIS_CONFLICT;
    App::Record* record = nullptr;
    if (stop) record = stopRecord(a, groupStop, address, request.stop.behavior);
    else for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    ESS::PreparedAction work;
    if (!ESS::nextAction(preparedContext, now, work) || work.kind != ESS::ActionWork::TRANSACTION)
        return Probe::Action::FAILED;
    const bool replacingStop = record->operationId != 0;
    const uint32_t replacedOperationId = record->operationId;
    const bool overwritingEvidence = replacingStop && !confirmedStop(*record);
    if (!replacingStop) record->action = preparedContext;
    const auto admitted = scanStop || faulted ? Rtu::BusAdmission::ACCEPTED : admitActionStep(a, *record, work, now);
    if (admitted != Rtu::BusAdmission::ACCEPTED) {
        if (!replacingStop) clearRecord(*record);
        return admitted == Rtu::BusAdmission::QUEUE_FULL ? Probe::Action::QUEUE_FULL :
            admitted == Rtu::BusAdmission::RESULTS_FULL || admitted == Rtu::BusAdmission::URGENT_FULL ?
            Probe::Action::RESULTS_FULL : Probe::Action::FAILED;
    }
    if (replacingStop) {
        const Rtu::RequestId admittedRequestId = scanStop || faulted ? Rtu::RequestId() : record->requestId;
        if (overwritingEvidence) ++a.stopEvidenceOverwritten;
        clearRecord(*record);
        record->requestId = admittedRequestId;
        record->action = preparedContext;
    }
    record->stopHeld = faulted;
    if (record->stopHeld && a.owner.recovering()) {
        record->stopRecoveryId = a.recovery.id;
        record->stopRecoveryOperationId = a.recovery.operationId;
    }
    record->stopEscalation = stop && !groupStop && record >= &a.records[STOP_ESCALATION_FIRST];
    record->replacedOperationId = replacedOperationId;
    if (releaseFacts) { record->releaseAfterStopId = failedStopId; record->releasePrerequisites = *releaseFacts; }
    record->groupChild = groupStop;
    record->serialTuple = scanStop ? a.discovery.originalTuple : a.serial.active;
    record->serialGeneration = scanStop ? a.discovery.originalSerialGeneration : a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->deadlineUs = preparedContext.deadlineUs; record->kind = App::OperationKind::ACTION; record->axisReserved = true;
    record->configurationGeneration = a.axis.generation;
    if (scanStop) {
        record->discoveryStop = true;
        a.discovery.cancelRequested = true;
        a.discovery.outcome = Probe::DiscoveryOutcome::PREEMPTED;
        if (a.discoveryRequest.owner) a.owner.cancelUnsent(a.discoveryRequest, now);
    }
    operationId = a.latestOperationId = record->operationId;
    if (stop) {
        // This includes an older stop: its unsent write and later polls end here.
        cancelSimplePreparation(a, address, now);
        cancelPositionStages(a, address, now);
        for (auto& interrupted : a.records) {
            if (&interrupted == record || !sequenced(interrupted) || interrupted.address != address ||
                terminal(a, interrupted)) continue;
            interrupted.cancelContinuation = true;
            if (interrupted.kind == App::OperationKind::HOME) ESS::revokeHome(interrupted.home);
            interrupted.interruptedByStop = true;
            if (interrupted.requestId.owner) a.owner.cancelUnsent(interrupted.requestId, now);
        }
    }
    return Probe::Action::OK;
}
Probe::Action startAction(void* context, uint32_t commandId, uint8_t address,
                          const MotorControlRS::ActionRequest& request, uint32_t& operationId) {
    return startActionIn(*static_cast<App*>(context), commandId, address, request, operationId, false);
}
Probe::Action inspectRelease(App& a, uint32_t stopId, ReleaseAfterStopPrerequisites& output) {
    if (!failedTransmittedStop(a, stopId)) return Probe::Action::INVALID;
    if (a.owner.needsRecovery() || uart.needsRecovery() || a.serial.blocked || a.serial.configuring)
        return Probe::Action::RECOVERY_REQUIRED;
    if (a.discovery.owned || a.owner.commissioningOwned() || axisReserved(a, a.axis.target.address, false))
        return Probe::Action::BUSY;
    ReleaseAfterStopPrerequisites facts;
    facts.target = a.axis.target; facts.target.generation = a.bindingGeneration;
    facts.configurationGeneration = a.axis.generation; facts.qualifiedUs = uart.sample();
    output = facts;
    return Probe::Action::OK;
}
Probe::Action startReleaseAfterStop(void* context, uint32_t commandId, uint32_t stopId, uint32_t& operationId) {
    auto& a = *static_cast<App*>(context);
    ReleaseAfterStopPrerequisites facts;
    const auto inspected = inspectRelease(a, stopId, facts);
    if (inspected != Probe::Action::OK) return inspected;
    // The console grammar explicitly supplies these two fixture facts.
    facts.mechanicsPermitRelease = facts.externalTriggersInhibited = true;
    MotorControlRS::ActionRequest request; request.kind = MotorControlRS::ActionKind::RELEASE;
    return startActionIn(a, commandId, facts.target.address, request, operationId, false, stopId, &facts);
}
Probe::Action admissionResult(Rtu::BusAdmission result) {
    switch (result) {
    case Rtu::BusAdmission::ACCEPTED: return Probe::Action::OK;
    case Rtu::BusAdmission::QUEUE_FULL: return Probe::Action::QUEUE_FULL;
    case Rtu::BusAdmission::RESULTS_FULL: return Probe::Action::RESULTS_FULL;
    case Rtu::BusAdmission::URGENT_FULL: return Probe::Action::RESULTS_FULL;
    case Rtu::BusAdmission::IDS_EXHAUSTED: return Probe::Action::IDS_EXHAUSTED;
    case Rtu::BusAdmission::RECOVERING: case Rtu::BusAdmission::CONFIGURING: return Probe::Action::RECOVERY_REQUIRED;
    default: return Probe::Action::INVALID;
    }
}
// Ordinary writers check this policy before owner admission. Each producer
// invalidates affected observations when its first write byte is accepted.
// The operation executor below already owns its same-axis reservation. A raw
// call to the bus owner cannot substitute for this application policy boundary.
Probe::Action checkAxisWrite(const App& a, const Rtu::BusRequest& request) {
    if (a.discovery.owned) return Probe::Action::BUSY;
    if (!ESS::isValidAddress(request.expected.address) ||
        (request.expected.function != 6 && request.expected.function != 0x10) ||
        request.expected.target != request.expected.address ||
        request.expected.targetGeneration != a.bindingGeneration) return Probe::Action::INVALID;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!(a.knownTargets[request.expected.address / 8] & (1U << (request.expected.address % 8))))
        return Probe::Action::UNAVAILABLE;
    if (axisReserved(a, request.expected.address)) return Probe::Action::AXIS_CONFLICT;
    return Probe::Action::OK;
}
Probe::Action prepareSelectedMove(App&, const MotorControlRS::MoveRequest&, uint64_t, uint64_t, ESS::MoveContext&);
Probe::Action admitMoveStep(App& a, App::Record& record, const ESS::PreparedMove& prepared, uint64_t now) {
    Rtu::BusRequest request;
    request.wire.bytes = prepared.bytes; request.wire.length = prepared.length;
    request.wire.replyLength = prepared.write ? ESS::WRITE_RESPONSE_LEN : ESS::expectedReadRegistersLen(prepared.count);
    request.wire.responseTimeoutUs = a.serial.timing.responseTimeoutUs; request.wire.replyGapUs = a.serial.timing.replyGapUs;
    request.wire.deadlineUs = prepared.deadlineUs;
    request.expected.address = prepared.target.address; request.expected.function = prepared.function;
    request.expected.target = prepared.target.id; request.expected.targetGeneration = prepared.target.generation;
    request.expected.first = prepared.reg; request.expected.count = prepared.count;
    request.expected.value = prepared.value; request.validator = Rtu::essValidator();
    if (!record.operationId && prepared.write) {
        const Probe::Action checked = checkAxisWrite(a, request);
        if (checked != Probe::Action::OK) return checked;
    }
    return admissionResult(a.owner.admit(request, now, record.requestId));
}
void captureStoredPosition(App&, App::Record&, uint64_t);
Probe::Action startMove(void* context, uint32_t commandId, uint8_t address,
                        const MotorControlRS::MoveRequest& supplied, uint32_t& operationId) {
    using namespace MotorControlRS;
    App& a = *static_cast<App*>(context);
    if (a.owner.commissioningOwned() || a.discovery.owned || groupSequencing(a)) return Probe::Action::BUSY;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (!ESS::isValidAddress(address) || !supplied.speedRpm ||
        supplied.ramp != MoveRamp::VERIFIED_CONFIGURED) return Probe::Action::INVALID;
    if (!(a.knownTargets[address / 8] & (1U << (address % 8)))) return Probe::Action::UNAVAILABLE;
    if (!a.commandPolarityKnown && supplied.position.frame != CoordinateFrame::NATIVE)
        return Probe::Action::UNAVAILABLE;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (axisReserved(a, address)) return Probe::Action::AXIS_CONFLICT;
    // Begin on a quiescent bus so an earlier producer's admitted write cannot
    // remain queued across our staging reservation. Reads may join afterward.
    if (a.owner.active() || a.owner.pending()) return Probe::Action::BUSY;
    if (enableSettling(a, address, uart.sample())) return Probe::Action::BUSY; // HW-15: the drive ignores an early start.
    if (a.axis.target.address != address || !a.configuration.operationId ||
        !Probe::sameTarget(a.configuration.target, a.axis.target)) return Probe::Action::UNAVAILABLE;
    App::Record* record = nullptr;
    for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    const uint64_t now = uart.sample();
    const uint64_t deadline = now + static_cast<uint64_t>(a.options.moveTimeoutMs) * 1000;
    const auto checked = prepareSelectedMove(a, supplied, now, deadline, record->move);
    if (checked != Probe::Action::OK) { clearRecord(*record); return checked; }
    const MoveRequest& request = supplied;
    ESS::MoveContext& prepared = record->move;
    if (request.setup == MoveSetup::USE_STORED &&
        (a.rememberedMoveGeneration != a.axis.generation || a.rememberedMoveBinding != a.bindingGeneration ||
         a.rememberedMoveSerial != a.serial.generation ||
         std::memcmp(a.rememberedMoveWords, prepared.words, sizeof(prepared.words)))) {
        clearRecord(*record); return Probe::Action::UNAVAILABLE;
    }
    ESS::PreparedMove work;
    if (!ESS::nextMove(record->move, now, work)) { clearRecord(*record); return Probe::Action::FAILED; }
    const auto admitted = admitMoveStep(a, *record, work, now);
    if (admitted != Probe::Action::OK) { clearRecord(*record); return admitted; }
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->deadlineUs = deadline; record->kind = App::OperationKind::MOVE; record->axisReserved = true;
    captureStoredPosition(a, *record, now);
    operationId = a.latestOperationId = record->operationId;
    return Probe::Action::OK;
}
// Selected-axis readiness and move preparation, shared by moves and stages. On
// rejection a simple session receives the preparation status.
Probe::Action prepareSelectedMove(App& a, const MotorControlRS::MoveRequest& supplied, uint64_t now,
                                  uint64_t deadline, ESS::MoveContext& prepared) {
    using namespace MotorControlRS;
    ESS::MovePrerequisites prerequisites = a.movePrerequisites;
    if (!prerequisites.commandUnitsVerified && !moveRequirements(a, supplied, now, prerequisites)) return Probe::Action::UNAVAILABLE;
    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
    if (!Probe::fresh(motion, a.axis.target, now, prerequisites.maximumAgeUs)) prerequisites.readinessQualified = false;
    else {
        prerequisites.rawAlarm = motion.value.rawAlarm; prerequisites.rawMotion = motion.value.rawMotion;
        prerequisites.observedUs = motion.observedEarliestUs;
    }
    if (a.positionStartSpeedRelationRequired) {
        uint16_t minimumRpm = 0;
        if (!positionStartingSpeed(a, now, minimumRpm)) return Probe::Action::UNAVAILABLE;
        prerequisites.startSpeedKnown = true; prerequisites.startSpeed = minimumRpm;
        prerequisites.observedUs = std::min(prerequisites.observedUs, a.positionStartSpeedRelation.qualifiedUs);
        const auto relationAge = a.observationAgeUs();
        if (relationAge && (!prerequisites.maximumAgeUs || relationAge < prerequisites.maximumAgeUs))
            prerequisites.maximumAgeUs = relationAge;
    }
    prerequisites.wordOrderKnown = a.configuration.wordOrderKnown;
    prerequisites.wordOrder = a.configuration.wordOrder;
    prerequisites.subdivision = a.configuration.raw.subdivision;
    if (a.simple.admitting) {
        if (a.simple.view.accelerationKnown) prerequisites.accelerationTime = a.simple.view.acceleration;
        if (a.simple.view.decelerationKnown) prerequisites.decelerationTime = a.simple.view.deceleration;
    }
    const MoveRequest& request = supplied;
    AxisReference reference = axisReference(a);
    // Reuse the standalone session's explicit feedback-coordinate convention.
    // The core never assumes that an arbitrary encoder pair is command position.
    prerequisites.positionFeedbackMatchesCommand = a.simple.admitting && a.bootCoordinates &&
        reference.nativeKnown && reference.stationary;
    ActionOptions options; options.maxPolls = ESS::ACTION_MAX_POLLS; options.pollIntervalUs = 20000;
    options.runningPollIntervalUs = RUNNING_POLL_US;
    const auto prepare = request.position.wrapped ? ESS::prepareMoveAngle :
        request.position.relative ? ESS::prepareMoveRelative : ESS::prepareMoveAbsolute;
    const Status checked = prepare(prepared, a.axis, reference.nativeKnown ? &reference : nullptr,
        a.nextOperationId, request, prerequisites, now, deadline, options);
    if (!checked) {
        if (a.simple.admitting) a.simple.view.status = checked;
        if (checked.code == Err::INVALID_CONFIG && checked.detail == static_cast<int32_t>(MoveError::READINESS) &&
            reference.nativeKnown && (!reference.idle || !reference.stationary || reference.basis != RelativeBasis::ACTUAL))
            return Probe::Action::REFERENCE_NOT_READY;
        return checked.code == Err::UNSUPPORTED ? Probe::Action::UNSUPPORTED : Probe::Action::INVALID;
    }
    return Probe::Action::OK;
}
#include "PositionInterruptApp.h"
Probe::Action admitVelocityStep(App& a, App::Record& record, const ESS::PreparedVelocity& prepared, uint64_t now) {
    Rtu::BusRequest request;
    request.wire.bytes = prepared.bytes; request.wire.length = prepared.length;
    request.wire.replyLength = prepared.write ? ESS::WRITE_RESPONSE_LEN : ESS::expectedReadRegistersLen(prepared.count);
    request.wire.responseTimeoutUs = a.serial.timing.responseTimeoutUs; request.wire.replyGapUs = a.serial.timing.replyGapUs;
    request.wire.deadlineUs = prepared.deadlineUs;
    request.dispatchDeadlineUs = prepared.dispatchDeadlineUs;
    request.expected.address = prepared.target.address; request.expected.function = prepared.function;
    request.expected.target = prepared.target.id; request.expected.targetGeneration = prepared.target.generation;
    request.expected.first = prepared.reg; request.expected.count = prepared.count;
    request.expected.value = prepared.value; request.validator = Rtu::essValidator();
    if (!record.operationId) {
        const auto checked = checkAxisWrite(a, request); if (checked != Probe::Action::OK) return checked;
    }
    return admissionResult(prepared.urgent ? a.owner.admitUrgent(request, now, record.requestId) :
        a.owner.admit(request, now, record.requestId));
}
// Stated facts still stand for the selected axis. Live readiness is checked separately.
bool velocityQualificationPresent(const App& a) {
    const auto& p = a.velocityPrerequisites;
    return p.target.id && Probe::sameTarget(p.target, a.axis.target) && a.axis.generation &&
        p.configurationGeneration == a.axis.generation && p.nativeRpmVerified && p.configuredRampVerified &&
        p.serialInputsPermit && p.readinessQualified;
}
Probe::Action startVelocity(void* context, uint32_t commandId, uint8_t address,
                            const MotorControlRS::VelocityRequest& supplied, uint32_t& operationId) {
    using namespace MotorControlRS;
    App& a = *static_cast<App*>(context);
    if (a.owner.commissioningOwned() || a.discovery.owned || groupSequencing(a)) return Probe::Action::BUSY;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (!ESS::isValidAddress(address) || !supplied.durationUs || supplied.durationUs > 1000000)
        return Probe::Action::INVALID;
    if (!a.commandPolarityKnown && supplied.frame != CoordinateFrame::NATIVE) return Probe::Action::UNAVAILABLE;
    if (supplied.ramp == VelocityRamp::ACCELERATION || supplied.acceleration || supplied.deceleration ||
        supplied.jerk || supplied.blending || supplied.liveUpdate) return Probe::Action::UNSUPPORTED;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (axisReserved(a, address)) return Probe::Action::AXIS_CONFLICT;
    if (a.owner.active() || a.owner.pending()) return Probe::Action::BUSY;
    if (enableSettling(a, address, uart.sample())) return Probe::Action::BUSY; // HW-15: the drive ignores an early start.
    if (!velocityQualificationPresent(a)) return Probe::Action::QUALIFICATION_REQUIRED;
    if (a.axis.target.address != address || !a.configuration.operationId ||
        !Probe::sameTarget(a.configuration.target, a.axis.target)) return Probe::Action::UNAVAILABLE;
    App::Record* record = nullptr;
    for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    const uint64_t now = uart.sample();
    auto prerequisites = a.velocityPrerequisites;
    prerequisites.minimumRpm = std::max<int16_t>(prerequisites.minimumRpm,-60);
    prerequisites.maximumRpm = std::min<int16_t>(prerequisites.maximumRpm,60);
    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
    if (!Probe::fresh(motion, a.axis.target, now, prerequisites.maximumAgeUs)) prerequisites.readinessQualified = false;
    else {
        prerequisites.rawAlarm = motion.value.rawAlarm; prerequisites.rawMotion = motion.value.rawMotion;
        prerequisites.observedUs = motion.observedEarliestUs;
    }
    // Proposed finite free-shaft envelope only; commissioning flags stay false until
    // an operator or API caller states them. Setup consumes duration; the normal-stop
    // observation budget covers the same legal ramp as an independently requested stop.
    const bool normalStop = supplied.stop.behavior == StopBehavior::CONFIGURED_DECELERATION;
    const uint64_t deadline = now + supplied.durationUs + (normalStop ? NORMAL_STOP_US : 2000000);
    ActionOptions options; options.maxPolls = ESS::ACTION_MAX_POLLS; options.pollIntervalUs = 20000;
    if (normalStop) options.pollIntervalUs = NORMAL_STOP_POLL_US;
    const auto checked = ESS::prepareVelocity(record->velocity, a.axis, a.nextOperationId,
        supplied, prerequisites, now, deadline, options);
    if (!checked) { clearRecord(*record); return checked.code == Err::UNSUPPORTED ? Probe::Action::UNSUPPORTED : Probe::Action::INVALID; }
    if (record->velocity.prepared.nativeRpm < -60 || record->velocity.prepared.nativeRpm > 60) {
        clearRecord(*record); return Probe::Action::INVALID;
    }
    ESS::PreparedVelocity work;
    if (!ESS::nextVelocity(record->velocity, now, work)) { clearRecord(*record); return Probe::Action::FAILED; }
    const auto admitted = admitVelocityStep(a, *record, work, now);
    if (admitted != Probe::Action::OK) { clearRecord(*record); return admitted; }
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->deadlineUs = deadline; record->kind = App::OperationKind::VELOCITY; record->axisReserved = true;
    operationId = a.latestOperationId = record->operationId; return Probe::Action::OK;
}
Probe::Action admitHomeStep(App& a, App::Record& record, const ESS::PreparedHome& work, uint64_t now) {
    Rtu::BusRequest request;
    request.wire.bytes = work.bytes; request.wire.length = work.length;
    request.wire.replyLength = work.write ? ESS::WRITE_RESPONSE_LEN : ESS::expectedReadRegistersLen(work.count);
    request.wire.responseTimeoutUs = a.serial.timing.responseTimeoutUs; request.wire.replyGapUs = a.serial.timing.replyGapUs;
    request.wire.deadlineUs = work.deadlineUs;
    request.expected.address = work.target.address; request.expected.function = work.function;
    request.expected.target = work.target.id; request.expected.targetGeneration = work.target.generation;
    request.expected.first = work.reg; request.expected.count = work.count;
    request.expected.value = work.value; request.validator = Rtu::essValidator();
    if (!record.operationId) {
        const auto checked = checkAxisWrite(a, request); if (checked != Probe::Action::OK) return checked;
    }
    return admissionResult(a.owner.admit(request, now, record.requestId));
}
// Enrich a copy with real observations. Never modify or renew supplied facts.
bool homeReadiness(const App& a, ESS::HomePrerequisites& p, uint64_t now) {
    using MotorControlRS::evidenceAgeValid;
    const auto& config = a.configuration;
    const auto& parameters = a.homingParameters;
    if (!a.axis.generation || p.configurationGeneration != a.axis.generation ||
        !Probe::sameTarget(p.target, a.axis.target) || !config.operationId ||
        !Probe::sameTarget(config.target, p.target) || config.unknownPolarityBits ||
        !parameters.operationId || parameters.configurationGeneration != p.configurationGeneration ||
        !Probe::sameTarget(parameters.target, p.target) ||
        // Staging overwrites stored method, rates and ramp before the trigger, so their
        // prior values do not matter. It never writes auxiliary, and would silently erase
        // a stored offset whose interpretation is unresolved.
        parameters.rawAuxiliary != static_cast<uint16_t>(p.auxiliary) ||
        parameters.rawOffsetWords[0] || parameters.rawOffsetWords[1] ||
        p.inputPolarity != config.raw.inputPolarity) return false;
    for (uint8_t i = 0; i < 4; ++i)
        if (!config.inputFunctionKnown[i] || p.inputFunctions[i] != config.raw.inputFunctions[i] ||
            p.inputWiring[i] != config.wiring[i] || p.inputWiring[i] != a.inputWiring[i]) return false;
    p.readbackObservedUs = now;
    auto checked = [&](const ESS::ReadStepObservation& e) {
        p.readbackObservedUs = std::min(p.readbackObservedUs, e.attemptedUs);
        return e.qualified && e.status && e.attemptedUs <= e.earliestUs && e.earliestUs <= e.latestUs &&
            e.latestUs <= now && evidenceAgeValid(e.attemptedUs, now, p.maximumAgeUs);
    };
    for (const auto& e : config.provenance) if (!checked(e)) return false;
    if (!checked(parameters.provenance)) return false;
    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
    const auto& io = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::IO)];
    if (!Probe::current(motion, p.target) || !Probe::current(io, p.target) ||
        motion.value.configOperationId != config.operationId || io.value.configOperationId != config.operationId ||
        !evidenceAgeValid(motion.observedEarliestUs, now, p.maximumAgeUs) ||
        !evidenceAgeValid(io.observedEarliestUs, now, p.maximumAgeUs) ||
        motion.value.unknownMotionBits || io.value.unknownInputBits || motion.value.rawAlarm ||
        (motion.value.rawMotion & 0x7C)) return false;
    p.observedUs = motion.observedEarliestUs; p.ioObservedUs = io.observedEarliestUs;
    p.rawAlarm = motion.value.rawAlarm; p.rawMotion = motion.value.rawMotion;
    p.rawInputs = io.value.rawInputs; p.observeInputs = true;
    return ESS::checkHomeQualification(p, now).isOk();
}
// Stated facts still stand for the selected axis. Live reads are checked by homeReadiness.
bool homeQualificationPresent(const App& a) {
    const auto& p = a.homePrerequisites;
    return p.target.id && Probe::sameTarget(p.target, a.axis.target) && a.axis.generation &&
        p.configurationGeneration == a.axis.generation && p.methodQualified && p.nativeRatesQualified &&
        p.nativeRampQualified && p.zeroOffsetQualified && p.auxiliaryQualified && p.inputsQualified && p.readinessQualified;
}
void revokeActiveHomes(App& a, uint64_t now) {
    for (auto& r : a.records) if (r.kind == App::OperationKind::HOME && r.home.state == MotorControlRS::ActionState::ACTIVE) {
        ESS::revokeHome(r.home); r.cancelContinuation = true;
        if (r.requestId.owner) a.owner.cancelUnsent(r.requestId, now);
    }
}
// Run before owner dispatch and before consuming completions. Our own staging
// invalidates live caches and consumes the future slot, not the admitted facts.
void cancelInvalidHomes(App& a, uint64_t now) {
    for (auto& r : a.records) if (r.kind == App::OperationKind::HOME && r.home.state == MotorControlRS::ActionState::ACTIVE) {
        bool invalid = r.cancelContinuation || r.home.qualificationRevoked || !a.axis.generation ||
            r.configurationGeneration != a.axis.generation || r.home.target.generation != a.bindingGeneration ||
            r.serialGeneration != a.serial.generation;
        if (!invalid && !r.effectsInvalidated && (!r.requestId.owner || !a.owner.txAccepted(r.requestId))) {
            auto p = r.home.prerequisites;
            invalid = !homeReadiness(a, p, now);
        }
        // Own staging invalidates older snapshots; it cannot hide a later
        // independently checked contradiction. Do not renew admitted ages or
        // require ordinary reads to witness trajectory edges.
        const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
        if (!invalid && Probe::current(motion, r.home.target) && motion.observedEarliestUs > r.home.startedUs) {
            const bool runningForbidden = r.home.step < 2 || r.home.request.method == ESS::HomingMethod::METHOD_35;
            invalid = motion.value.unknownMotionBits || motion.value.rawAlarm ||
                (motion.value.rawMotion & (runningForbidden ? 0x7C : 0x78));
        }
        const auto& io = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::IO)];
        if (!invalid && Probe::current(io, r.home.target) && io.observedEarliestUs > r.home.startedUs) {
            auto p = r.home.prerequisites; p.rawInputs = io.value.rawInputs;
            invalid = io.value.unknownInputBits || !ESS::checkHomeQualification(p, r.home.startedUs);
        }
        if (invalid) {
            ESS::revokeHome(r.home); r.cancelContinuation = true;
            if (r.requestId.owner) a.owner.cancelUnsent(r.requestId, now);
        }
    }
}
bool homeRatesWithinPolicy(const App& a, uint16_t search, uint16_t returning) {
    const auto subdivision = a.configuration.raw.subdivision;
    return a.configuration.operationId && Probe::sameTarget(a.configuration.target, a.axis.target) &&
        subdivision >= 400 && subdivision <= 51200 &&
        static_cast<uint64_t>(subdivision) * search <= uint64_t(HOME_MAX_COMMAND_RATE) * 60 &&
        static_cast<uint64_t>(subdivision) * returning <= uint64_t(HOME_MAX_COMMAND_RATE) * 60;
}
Probe::Action startHome(void* context, uint32_t commandId, uint8_t address,
                        const ESS::HomeRequest& supplied, uint32_t& operationId) {
    using namespace MotorControlRS;
    App& a = *static_cast<App*>(context);
    if (a.owner.commissioningOwned() || a.discovery.owned || groupSequencing(a)) return Probe::Action::BUSY;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (!ESS::isValidAddress(address)) return Probe::Action::INVALID;
    const auto* method = ESS::homeMethod(supplied.method);
    if (!method) return Probe::Action::INVALID;
    if (method->support == ESS::HomeSupport::UNRESOLVED) return Probe::Action::UNRESOLVED;
    if (method->support == ESS::HomeSupport::UNIMPLEMENTED) return Probe::Action::UNIMPLEMENTED;
    if (supplied.offset != 0) return Probe::Action::UNRESOLVED;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (axisReserved(a, address)) return Probe::Action::AXIS_CONFLICT;
    if (a.owner.active() || a.owner.pending()) return Probe::Action::BUSY;
    if (enableSettling(a, address, uart.sample())) return Probe::Action::BUSY; // HW-15: the drive ignores an early start.
    if (!homeQualificationPresent(a)) return Probe::Action::QUALIFICATION_REQUIRED;
    if (a.axis.target.address != address || !a.configuration.operationId ||
        !Probe::sameTarget(a.configuration.target, a.axis.target)) return Probe::Action::UNAVAILABLE;
    App::Record* record = nullptr;
    for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    const uint64_t now = uart.sample();
    auto prerequisites = a.homePrerequisites;
    if (!homeReadiness(a, prerequisites, now)) return Probe::Action::UNAVAILABLE;
    if (a.configuration.raw.subdivision < 400 || a.configuration.raw.subdivision > 51200) return Probe::Action::UNAVAILABLE;
    if (!homeRatesWithinPolicy(a, supplied.searchSpeed, supplied.returnSpeed)) return Probe::Action::OPERATING_LIMIT;
    ESS::HomeRequest request = supplied;
    if (!request.configurationGeneration) request.configurationGeneration = a.axis.generation;
    // A search lasts as long as its travel, so it gets the same budget as a move.
    const uint64_t deadline = now + static_cast<uint64_t>(a.options.moveTimeoutMs) * 1000;
    ActionOptions options; options.maxPolls = ESS::ACTION_MAX_POLLS; options.pollIntervalUs = 20000;
    options.runningPollIntervalUs = RUNNING_POLL_US;
    const auto checked = ESS::prepareHome(record->home, a.axis, a.nextOperationId, request, prerequisites, now, deadline, options);
    if (!checked) { clearRecord(*record); return checked.code == Err::UNSUPPORTED ? Probe::Action::UNSUPPORTED : Probe::Action::INVALID; }
    ESS::PreparedHome work;
    if (!ESS::nextHome(record->home, now, work)) { clearRecord(*record); return Probe::Action::FAILED; }
    const auto admitted = admitHomeStep(a, *record, work, now);
    if (admitted != Probe::Action::OK) { clearRecord(*record); return admitted; }
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->deadlineUs = deadline; record->kind = App::OperationKind::HOME; record->axisReserved = true;
    record->configurationGeneration = a.axis.generation;
    operationId = a.latestOperationId = record->operationId; return Probe::Action::OK;
}
// Register-only commissioning policy scoped to the affected terminals. Active
// input controls/inversion require separately reviewed effects; unwired never
// implies disabled. Output function 0 proves no electrical de-energization.
void qualifyIoEffects(App& a, ESS::DriverPrerequisites& p, const ESS::DriverRequest& request) {
    using MotorControlRS::InputWiring;
    p.qualifiedIo = request;
    for (uint8_t i = 0; i < 4; ++i) {
        p.inputWiring[i] = a.inputWiring[i];
        const uint32_t field = uint32_t(1) << (10 + i);
        if ((request.fields & field) && a.inputWiring[i] == InputWiring::UNCONNECTED &&
            p.previous.raw[8 + i] <= 3 && static_cast<uint16_t>(request.inputFunctions[i]) <= 3)
            p.ioEffectsQualifiedFields |= field;
    }
    if (request.fields & static_cast<uint32_t>(ESS::DriverField::INPUT_POLARITY)) {
        const uint16_t changed = request.inputPolarity ^ p.previous.raw[7];
        bool safe = true;
        for (uint8_t i = 0; i < 4; ++i) {
            if (!(changed & (uint16_t(1) << i))) continue;
            const uint32_t functionField = uint32_t(1) << (10 + i);
            const uint16_t function = request.fields & functionField ?
                static_cast<uint16_t>(request.inputFunctions[i]) : p.previous.raw[8 + i];
            if (a.inputWiring[i] != InputWiring::UNCONNECTED || p.previous.raw[8 + i] != 0 || function != 0) safe = false;
        }
        // First disable/read the assignment explicitly; this request never
        // changes polarity under an old active function before a later disable.
        if (safe) p.ioEffectsQualifiedFields |= static_cast<uint32_t>(ESS::DriverField::INPUT_POLARITY);
    }
    for (uint8_t i = 0; i < 2; ++i) {
        p.outputWiring[i] = a.outputWiring[i];
        if (a.outputWiring[i] == InputWiring::UNCONNECTED)
            p.ioEffectsQualifiedFields |= request.fields & (uint32_t(1) << (15 + i));
    }
    for (uint8_t index : {uint8_t(12), uint8_t(15)}) {
        const uint32_t field = static_cast<uint32_t>(ESS::driverFieldAt(index));
        const uint16_t value = index == 12 ? request.outputPolarity : request.customOutput;
        const uint16_t changed = value ^ p.previous.raw[index];
        bool safe = true;
        for (uint8_t i = 0; i < 2; ++i)
            if ((changed & (uint16_t(1) << i)) && a.outputWiring[i] != InputWiring::UNCONNECTED) safe = false;
        if (safe) p.ioEffectsQualifiedFields |= request.fields & field;
    }
}
Probe::Action checkIoWrite(const App& a, const Rtu::BusRequest& request) {
    const uint16_t reg = request.expected.first;
    const bool ioRegister = (reg >= ESS::Registers::INPUT_POLARITY && reg <= ESS::Registers::INPUT_X3_FUNCTION) ||
        (reg >= ESS::Registers::OUTPUT_POLARITY && reg <= ESS::Registers::OUTPUT_Y1_FUNCTION) ||
        reg == ESS::Registers::CUSTOM_OUTPUT;
    if (!ioRegister || request.expected.count != 1) return Probe::Action::INVALID;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (request.expected.address != a.axis.target.address || request.expected.function != 6 ||
        request.expected.target != request.expected.address ||
        request.expected.targetGeneration != a.bindingGeneration) return Probe::Action::INVALID;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!(a.knownTargets[request.expected.address / 8] & (1U << (request.expected.address % 8))))
        return Probe::Action::UNAVAILABLE;
    return axisReserved(a, request.expected.address) ? Probe::Action::AXIS_CONFLICT : Probe::Action::OK;
}
bool segmentGroup(ESS::DriverGroup group) {
    return group >= ESS::DriverGroup::POSITION_SEGMENT && group <= ESS::DriverGroup::SEGMENT_START_SPEED;
}
Probe::Action checkControlWrite(const App& a, const Rtu::BusRequest& request) {
    if (request.expected.first < ESS::Registers::CONTROL_ALGORITHM ||
        request.expected.first > ESS::Registers::LOCK_TIME || request.expected.count != 1 ||
        request.expected.function != 6 || request.expected.address != a.axis.target.address ||
        request.expected.target != request.expected.address || request.expected.targetGeneration != a.bindingGeneration)
        return Probe::Action::INVALID;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!(a.knownTargets[request.expected.address / 8] & (1U << (request.expected.address % 8))))
        return Probe::Action::UNAVAILABLE;
    return axisReserved(a, request.expected.address) ? Probe::Action::AXIS_CONFLICT : Probe::Action::OK;
}
ESS::DriverObservation& tuningCache(App& a, ESS::DriverGroup group) {
    // All callers have checked isTuningGroup; the four group ordinals are contiguous.
    return a.tuningSettings[static_cast<uint8_t>(group) - static_cast<uint8_t>(ESS::DriverGroup::FILTERS)];
}
Probe::Action checkTuningWrite(const App& a, const Rtu::BusRequest& request) {
    bool reviewed = false;
    for (auto group : {ESS::DriverGroup::FILTERS, ESS::DriverGroup::CURRENT_LOOP, ESS::DriverGroup::LA, ESS::DriverGroup::COLLISION}) {
        for (uint8_t slot = 0; slot < ESS::tuningFieldCount(group); ++slot) {
            ESS::TuningParameterInfo info;
            if (ESS::tuningParameterInfo(ESS::tuningParameter(group, slot), info) &&
                info.accessReviewed && info.reg == request.expected.first) reviewed = true;
        }
    }
    if (!reviewed || request.expected.count != 1 || request.expected.function != 6 ||
        request.expected.address != a.axis.target.address || request.expected.target != request.expected.address ||
        request.expected.targetGeneration != a.bindingGeneration) return Probe::Action::INVALID;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!(a.knownTargets[request.expected.address / 8] & (1U << (request.expected.address % 8)))) return Probe::Action::UNAVAILABLE;
    return axisReserved(a, request.expected.address) ? Probe::Action::AXIS_CONFLICT : Probe::Action::OK;
}
Probe::Action checkSegmentWrite(const App& a, const Rtu::BusRequest& request) {
    // Descriptors define exactly the legal indexed scalar registers. Neither a
    // pulse-pair half nor the reserved sixth position word can enter this path.
    bool scalar = false;
    for (uint8_t index = 1; index <= 16; ++index) {
        for (auto field : {ESS::PositionSegmentField::SPEED, ESS::PositionSegmentField::ACCELERATION_TIME, ESS::PositionSegmentField::DECELERATION_TIME}) {
            const auto* descriptor = ESS::positionSegmentRegister(index, field);
            if (descriptor && descriptor->address == request.expected.first) scalar = true;
        }
        for (auto field : {ESS::SpeedSegmentField::SPEED, ESS::SpeedSegmentField::ACCELERATION_TIME, ESS::SpeedSegmentField::DECELERATION_TIME}) {
            const auto* descriptor = ESS::speedSegmentRegister(index, field);
            if (descriptor && descriptor->address == request.expected.first) scalar = true;
        }
        const auto* descriptor = ESS::segmentStartSpeedRegister(index);
        if (descriptor && descriptor->address == request.expected.first) scalar = true;
    }
    if (!scalar || request.expected.count != 1 || request.expected.function != 6 ||
        request.expected.address != a.axis.target.address || request.expected.target != request.expected.address ||
        request.expected.targetGeneration != a.bindingGeneration) return Probe::Action::INVALID;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (!(a.knownTargets[request.expected.address / 8] & (1U << (request.expected.address % 8)))) return Probe::Action::UNAVAILABLE;
    return axisReserved(a, request.expected.address) ? Probe::Action::AXIS_CONFLICT : Probe::Action::OK;
}
Probe::Action admitDriverStep(App& a, App::Record& record, const ESS::PreparedDriver& work, uint64_t now) {
    Rtu::BusRequest request;
    request.wire.bytes = work.bytes; request.wire.length = work.length;
    request.wire.replyLength = work.write ? ESS::WRITE_RESPONSE_LEN : ESS::expectedReadRegistersLen(work.count);
    request.wire.responseTimeoutUs = a.serial.timing.responseTimeoutUs; request.wire.replyGapUs = a.serial.timing.replyGapUs;
    request.wire.deadlineUs = work.deadlineUs;
    request.expected.address = work.target.address; request.expected.function = work.write ? 6 : 3;
    request.expected.target = work.target.id; request.expected.targetGeneration = work.target.generation;
    request.expected.first = work.reg; request.expected.count = work.count;
    request.expected.value = work.value; request.validator = Rtu::essValidator();
    if (!record.operationId && work.write) {
        const auto checked = record.driver.group == ESS::DriverGroup::IO ?
            checkIoWrite(a, request) : segmentGroup(record.driver.group) ?
            checkSegmentWrite(a, request) : record.driver.group == ESS::DriverGroup::CONTROL_SETTINGS ?
            checkControlWrite(a, request) : ESS::isTuningGroup(record.driver.group) ?
            checkTuningWrite(a, request) : checkAxisWrite(a, request);
        if (checked != Probe::Action::OK) return checked;
    }
    return admissionResult(a.owner.admit(request, now, record.requestId));
}
bool singleSettingGroup(ESS::DriverGroup group) {
    return group == ESS::DriverGroup::POSITION_START_SPEED || group == ESS::DriverGroup::HOMING_AUXILIARY;
}
// Reuse checked configuration and logical state; an unconnected terminal is
// never silently reassigned. This policy permits only passive assignments.
bool singleSettingPolicy(App& a, uint64_t now) {
    auto& p = a.driverPrerequisites;
    p.~DriverPrerequisites(); new (&p) ESS::DriverPrerequisites();
    const auto& target = a.axis.target;
    p.configurationGeneration = a.axis.generation;
    p.stationaryTarget = p.triggerTarget = target;
    p.triggerConfigurationGeneration = a.axis.generation;
    p.maxAgeUs = a.observationAgeUs();
    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
    const auto& io = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::IO)];
    const auto& feedback = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::FEEDBACK)];
    p.stationaryEarliestUs = motion.observedEarliestUs; p.stationaryLatestUs = motion.observedLatestUs;
    p.rawAlarm = motion.value.rawAlarm; p.rawMotion = motion.value.rawMotion;
    p.stationaryQualified = Probe::fresh(motion, target, now, p.maxAgeUs) &&
        !p.rawAlarm && !(p.rawMotion & 0xFFEC);
    bool passive = a.configuration.operationId && Probe::sameTarget(a.configuration.target, target) &&
        !a.configuration.unknownPolarityBits &&
        Probe::fresh(io, target, now, p.maxAgeUs) && !io.value.unknownInputBits && !io.value.rawInputs &&
        Probe::fresh(feedback, target, now, p.maxAgeUs) && !feedback.value.rawSpeed;
    p.triggerEarliestUs = std::min(io.observedEarliestUs, feedback.observedEarliestUs);
    p.triggerLatestUs = std::max(io.observedLatestUs, feedback.observedLatestUs);
    for (const auto& e : a.configuration.provenance) {
        passive = passive && e.qualified && e.status && e.attemptedUs <= e.earliestUs &&
            e.earliestUs <= e.latestUs && e.latestUs <= now &&
            MotorControlRS::evidenceAgeValid(e.attemptedUs, now, p.maxAgeUs);
        p.triggerEarliestUs = std::min(p.triggerEarliestUs, e.attemptedUs);
        p.triggerLatestUs = std::max(p.triggerLatestUs, e.latestUs);
    }
    for (uint8_t i = 0; i < 4; ++i)
        passive = passive && a.configuration.raw.inputFunctions[i] <= 3 &&
            (a.configuration.raw.inputFunctions[i] == 0 || a.inputWiring[i] == MotorControlRS::InputWiring::UNCONNECTED);
    p.inputsPermit = p.externalTriggerInhibitedQualified = passive;
    return a.axis.generation && p.stationaryQualified && passive;
}
Probe::Action startSingleSetting(App& a, uint32_t commandId, uint8_t address, ESS::DriverKind kind,
                                     const ESS::DriverRequest& candidate, uint32_t& operationId) {
    const bool position = candidate.group == ESS::DriverGroup::POSITION_START_SPEED;
    const uint16_t value = position ? candidate.positionStartSpeed : static_cast<uint16_t>(candidate.homingAuxiliary);
    if (!singleSettingGroup(candidate.group) || kind != ESS::DriverKind::UPDATE || candidate.fields != 1 ||
        value > (position ? 3000 : 11))
        return Probe::Action::INVALID;
    if (!platformReady || address != a.axis.target.address || !ESS::isValidAddress(address)) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned() ||
        a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (a.owner.commissioningOwned() || a.discovery.owned || a.owner.active() || a.owner.pending() ||
        a.motionProfile.view.pending || a.motionProfile.view.restoreUnsettled || a.motionProfile.request.owner || a.simple.view.pending ||
        a.monitorState.settings.enabled) return Probe::Action::BUSY;
    if (axisReserved(a, address)) return Probe::Action::AXIS_CONFLICT;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    if (!(a.knownTargets[address / 8] & (1U << (address % 8))) ||
        (candidate.configurationGeneration && candidate.configurationGeneration != a.axis.generation)) return Probe::Action::UNAVAILABLE;
    App::Record* record = nullptr;
    for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    const uint64_t now = uart.sample();
    if (!singleSettingPolicy(a, now)) return Probe::Action::UNAVAILABLE;
    const auto checked = ESS::prepareDriverRead(record->driver, a.axis.target, a.nextOperationId,
        a.axis.generation, now, now + 3000000, candidate.group);
    if (!checked) return Probe::driverAdmissionStatus(checked);
    record->driver.request.positionStartSpeed = candidate.positionStartSpeed;
    record->driver.request.homingAuxiliary = candidate.homingAuxiliary;
    ESS::PreparedDriver work;
    if (!ESS::nextDriver(record->driver, now, work)) { clearRecord(*record); return Probe::Action::FAILED; }
    const auto admitted = admitDriverStep(a, *record, work, now);
    if (admitted != Probe::Action::OK) { clearRecord(*record); return admitted; }
    record->kind = App::OperationKind::DRIVER; record->singleSettingSession = true;
    record->requestedSetting = value; record->axisReserved = true;
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->configurationGeneration = a.axis.generation; record->deadlineUs = record->driver.deadlineUs;
    operationId = a.latestOperationId = record->operationId; return Probe::Action::OK;
}
// Continue the same reserved operation. Scratch storage keeps the complete prior
// evidence outside the output being reinitialized, without a large stack copy.
void reconcileSingleSettingPrior(App& a, const App::Record& record) {
    const auto& c = record.driver;
    if (record.serialGeneration != a.serial.generation ||
        !Probe::sameTarget(c.target, a.axis.target) || c.configurationGeneration != a.axis.generation ||
        !ESS::getDriver(c, a.driverObserved)) return;
    const uint16_t raw = a.driverObserved.raw[0];
    if (c.group == ESS::DriverGroup::POSITION_START_SPEED) {
        if (raw > 3000 ||
            (motionProfileBound(a) && raw != a.motionProfile.view.current[0]) ||
            (a.positionStartSpeedRelation.target.id && raw != a.positionStartSpeedRelation.rawStartSpeed)) {
            revokePositionStartSpeedRelation(a);
            a.motionProfile.view.ok = false;
            a.rememberedMoveGeneration = 0;
        }
    } else if (a.homePrerequisites.auxiliaryQualified && raw != static_cast<uint16_t>(a.homePrerequisites.auxiliary)) {
        a.homePrerequisites.auxiliaryQualified = false;
        a.homePrerequisites.referenceSemanticsQualified = a.homePrerequisites.readinessQualified = false;
    }
}
void continueSingleSetting(App& a, App::Record& record, uint64_t now) {
    auto& c = record.driver;
    if (!record.singleSettingSession || c.kind != ESS::DriverKind::READ || c.state != ReadState::SUCCEEDED) return;
    reconcileSingleSettingPrior(a, record);
    MotorControlRS::Status status;
    if (record.cancelContinuation || record.configurationGeneration != a.axis.generation ||
        c.target.generation != a.bindingGeneration || record.serialGeneration != a.serial.generation)
        status = MotorControlRS::Status(MotorControlRS::Err::INVALID_CONFIG, 0, "setting binding changed during prior read");
    else if (!singleSettingPolicy(a, now))
        status = MotorControlRS::Status(MotorControlRS::Err::INVALID_CONFIG, 0, "single-setting prerequisites expired");
    else {
        status = ESS::getDriver(c, a.driverPrerequisites.previous);
        ESS::DriverRequest request;
        request.configurationGeneration = record.configurationGeneration;
        if (status) status = c.group == ESS::DriverGroup::POSITION_START_SPEED ?
            ESS::preparePositionStartSpeed(request, record.requestedSetting) :
            ESS::prepareHomingAuxiliary(request, static_cast<ESS::HomingAuxiliary>(record.requestedSetting));
        if (status) status = ESS::prepareDriverSettings(c, c.target, record.operationId, request,
            a.driverPrerequisites, now, record.deadlineUs);
    }
    if (!status) {
        c.state = ReadState::FAILED;
        c.outcome = ESS::DriverOutcome::UPDATE_NOT_ADMITTED;
        c.status = status;
    }
}
Probe::Action startDriver(void* context, uint32_t commandId, uint8_t address, ESS::DriverKind kind,
                         const ESS::DriverRequest& supplied, uint32_t& operationId) {
    using namespace MotorControlRS;
    App& a = *static_cast<App*>(context);
    if (groupSequencing(a)) return Probe::Action::BUSY;
    if (singleSettingGroup(supplied.group))
        return startSingleSetting(a, commandId, address, kind, supplied, operationId);
    if (a.owner.commissioningOwned() || a.discovery.owned) return Probe::Action::BUSY;
    if (supplied.group > ESS::DriverGroup::COLLISION) return Probe::Action::INVALID;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (!ESS::isValidAddress(address)) return Probe::Action::INVALID;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    if (axisReserved(a, address)) return Probe::Action::AXIS_CONFLICT;
    // Existing admitted writes cannot cross this new configuration reservation.
    if (kind == ESS::DriverKind::UPDATE && (a.owner.active() || a.owner.pending())) return Probe::Action::BUSY;
    if (kind == ESS::DriverKind::UPDATE && address != a.axis.target.address) return Probe::Action::UNAVAILABLE;
    App::Record* record = nullptr;
    for (std::size_t i = 0; i < REQUEST_CAPACITY; ++i)
        if (!a.records[i].operationId) { record = &a.records[i]; break; }
    if (!record) return Probe::Action::RESULTS_FULL;
    const uint64_t now = uart.sample();
    ReadTarget target; target.id = target.address = address; target.generation = a.bindingGeneration;
    const uint32_t generation = address == a.axis.target.address ? a.axis.generation : a.bindingGeneration;
    Status checked;
    if (kind == ESS::DriverKind::READ) {
        checked = segmentGroup(supplied.group) ?
            ESS::prepareSegmentRead(record->driver, target, a.nextOperationId, generation, now, now + REQUEST_US,
                supplied.group == ESS::DriverGroup::POSITION_SEGMENT ? ESS::SegmentKind::POSITION :
                supplied.group == ESS::DriverGroup::SPEED_SEGMENT ? ESS::SegmentKind::SPEED : ESS::SegmentKind::START_SPEED, supplied.segmentIndex) :
            supplied.group == ESS::DriverGroup::CONTROL_SETTINGS ?
            ESS::prepareControlRead(record->driver, target, a.nextOperationId, generation, now, now + REQUEST_US) :
            ESS::isTuningGroup(supplied.group) ?
            ESS::prepareTuningRead(record->driver, target, a.nextOperationId, generation, now, now + REQUEST_US, supplied.group) :
            ESS::prepareDriverRead(record->driver, target, a.nextOperationId, generation, now, now + REQUEST_US, supplied.group);
    } else if (kind == ESS::DriverKind::UPDATE) {
        auto& prerequisites = a.driverPrerequisites;
        prerequisites.~DriverPrerequisites(); new (&prerequisites) ESS::DriverPrerequisites();
        prerequisites.previous = ESS::isTuningGroup(supplied.group) ? tuningCache(a, supplied.group) : segmentGroup(supplied.group) ? a.segmentSettings : supplied.group == ESS::DriverGroup::IO ? a.ioSettings : supplied.group == ESS::DriverGroup::CONTROL_SETTINGS ? a.controlSettings : a.driverSettings;
        prerequisites.configurationGeneration = generation;
        prerequisites.stationaryTarget = target; prerequisites.maxAgeUs = a.observationAgeUs();
        const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
        prerequisites.stationaryQualified = Probe::fresh(motion, target, now, prerequisites.maxAgeUs);
        prerequisites.rawAlarm = motion.value.rawAlarm; prerequisites.rawMotion = motion.value.rawMotion;
        prerequisites.stationaryEarliestUs = motion.observedEarliestUs;
        prerequisites.stationaryLatestUs = motion.observedLatestUs;
        prerequisites.inputsPermit = a.driverInputsQualified;
        ESS::DriverRequest request = supplied;
        if (!request.configurationGeneration) request.configurationGeneration = generation;
        if (request.group == ESS::DriverGroup::DRIVE &&
            request.fields == static_cast<uint32_t>(ESS::DriverField::SUBDIVISION)) {
            // Changing only subdivision is a stopped settings operation. The
            // standalone unwired fixture has no active external motion source;
            // prove assignments/levels rather than requiring a hidden flag.
            const auto& io = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::IO)];
            const auto& feedback = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::FEEDBACK)];
            bool passive = a.configuration.operationId && Probe::sameTarget(a.configuration.target, target) &&
                a.configuration.raw.softLimitEnable == 0 && !a.configuration.unknownPolarityBits &&
                Probe::fresh(io, target, now, prerequisites.maxAgeUs) && !io.value.unknownInputBits &&
                Probe::fresh(feedback, target, now, prerequisites.maxAgeUs) && !feedback.value.rawSpeed;
            for (const auto& evidence : a.configuration.provenance)
                passive = passive && evidence.qualified && evidence.status &&
                    evidenceAgeValid(evidence.earliestUs, now, prerequisites.maxAgeUs);
            for (uint8_t i = 0; i < 4; ++i)
                passive = passive && a.inputWiring[i] == InputWiring::UNCONNECTED &&
                    a.configuration.raw.inputFunctions[i] <= 3 &&
                    (!a.configuration.raw.inputFunctions[i] || !io.value.inputs[i]);
            prerequisites.inputsPermit = prerequisites.inputsPermit || passive;
        }
        if (request.group == ESS::DriverGroup::IO) {
            const auto& io = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::IO)];
            prerequisites.inputsPermit = true; // Changed-terminal policy below, not global mandatory I/O.
            prerequisites.ioLevelsQualified = Probe::fresh(io, target, now, prerequisites.maxAgeUs);
            prerequisites.ioTarget = target; prerequisites.ioConfigurationGeneration = generation;
            prerequisites.actualInputs = io.value.rawInputs; prerequisites.actualOutputs = io.value.rawOutputs;
            prerequisites.ioEarliestUs = io.observedEarliestUs; prerequisites.ioLatestUs = io.observedLatestUs;
            qualifyIoEffects(a, prerequisites, request);
            prerequisites.allowEchoReadback = true; // Stored-value settlement on safe unwired terminals only.
        }
        if (request.group == ESS::DriverGroup::CONTROL_SETTINGS || ESS::isTuningGroup(request.group)) {
            // Explicit standalone bench identification, independent of wire-code
            // decoding. The owner confirmed that every bench drive reporting
            // model 0x4EEA and firmware 0x0029 is an ESS23-RS20 (2026-10-04 for
            // node 1, 2026-11-13 for nodes 2 and 4). The core still requires a
            // fresh checked identity read of this exact target and binding.
            // No motor rating or undocumented algorithm is inferred.
            prerequisites.controlIdentity = a.identity;
            prerequisites.exactModelQualified = a.identity.rawModel == 0x4EEA && a.identity.rawVersion == 0x0029;
            prerequisites.modelSourceId = 20261113; // Owner-confirmed ESS23-RS20 drives and preserved datasheet.
            prerequisites.qualifiedModelCode = 0x4EEA; prerequisites.qualifiedFirmwareCode = 0x0029;
            if (request.group == ESS::DriverGroup::CONTROL_SETTINGS) {
                prerequisites.qualifiedControl = request;
                prerequisites.controlEarliestUs = a.identity.provenance.attemptedUs;
                prerequisites.controlLatestUs = a.identity.provenance.latestUs;
                // Delay changes leave mode, encoder and current codes untouched.
                // Other effects/rating/base semantics remain unavailable here.
                prerequisites.controlEffectsQualifiedFields = request.fields & static_cast<uint32_t>(ESS::DriverField::LOCK_DELAY);
            } else {
                // The finite standalone experiment permits only input-filter
                // coefficients 2/3 on fresh passive, unconnected inputs. It
                // qualifies stored readback, not filter delay or active effects.
                const auto& io = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::IO)];
                bool passive = Probe::fresh(io, target, now, prerequisites.maxAgeUs) && !io.value.rawInputs &&
                    a.ioSettings.operationId && a.ioSettings.group == ESS::DriverGroup::IO && Probe::sameTarget(a.ioSettings.target, target) &&
                    a.ioSettings.configurationGeneration == generation && !(a.ioSettings.raw[7] & ~0xFu);
                uint64_t earliest = io.observedEarliestUs, latest = io.observedLatestUs;
                for (uint8_t i = 0; i < 4; ++i)
                    passive = passive && a.inputWiring[i] == InputWiring::UNCONNECTED && a.ioSettings.raw[8 + i] <= 3;
                for (const auto& evidence : a.ioSettings.provenance) {
                    if (!evidence.count) continue;
                    passive = passive && evidence.qualified && evidence.responseConfirmed && evidence.status &&
                        evidenceAgeValid(evidence.attemptedUs, now, prerequisites.maxAgeUs);
                    if (evidence.attemptedUs < earliest) earliest = evidence.attemptedUs;
                    if (evidence.latestUs > latest) latest = evidence.latestUs;
                }
                const bool experiment = request.group == ESS::DriverGroup::FILTERS && request.fields == 1 &&
                    (request.tuningValues[0] == 2 || request.tuningValues[0] == 3) &&
                    (tuningCache(a, request.group).raw[0] == 2 || tuningCache(a, request.group).raw[0] == 3);
                prerequisites.qualifiedTuning = request;
                prerequisites.tuningEffectsQualifiedFields = passive && experiment ? request.fields : 0;
                prerequisites.tuningEarliestUs = earliest;
                prerequisites.tuningLatestUs = latest;
            }
            prerequisites.inputsPermit = true;
            prerequisites.allowEchoReadback = true;
        }
        if (segmentGroup(request.group)) {
            // Record configuration cannot synthesize a trigger. This bench policy
            // permits writes with fresh checked passive no-function/origin/limit
            // assignments on unconnected terminals and no asserted inputs.
            // Trigger/selection/control assignments require separate qualification.
            const auto& io = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::IO)];
            bool inhibited = a.ioSettings.operationId && a.ioSettings.group == ESS::DriverGroup::IO &&
                Probe::sameTarget(a.ioSettings.target, target) && a.ioSettings.configurationGeneration == generation && !(a.ioSettings.raw[7] & ~0xFu) &&
                Probe::fresh(io, target, now, prerequisites.maxAgeUs) && io.value.rawInputs == 0;
            uint64_t earliest = io.observedEarliestUs, latest = io.observedLatestUs;
            for (const auto& e : a.ioSettings.provenance) {
                if (!e.count) continue;
                inhibited = inhibited && e.qualified && e.responseConfirmed && e.status &&
                    evidenceAgeValid(e.attemptedUs, now, prerequisites.maxAgeUs);
                if (e.attemptedUs < earliest) earliest = e.attemptedUs;
                if (e.latestUs > latest) latest = e.latestUs;
            }
            for (uint8_t i = 0; i < 4; ++i)
                inhibited = inhibited && a.inputWiring[i] == InputWiring::UNCONNECTED &&
                    a.ioSettings.raw[8 + i] <= 3;
            prerequisites.externalTriggerInhibitedQualified = inhibited;
            prerequisites.triggerTarget = target; prerequisites.triggerConfigurationGeneration = generation;
            prerequisites.triggerEarliestUs = earliest; prerequisites.triggerLatestUs = latest;
            prerequisites.qualifiedSegment = request; prerequisites.allowEchoReadback = true;
            prerequisites.inputsPermit = true;
        }
        checked = segmentGroup(request.group) ?
            ESS::prepareSegmentSettings(record->driver, target, a.nextOperationId, request, prerequisites, now, now + 3000000) :
            request.group == ESS::DriverGroup::CONTROL_SETTINGS ?
            ESS::prepareControlSettings(record->driver, target, a.nextOperationId, request, prerequisites, now, now + 3000000) :
            ESS::isTuningGroup(request.group) ?
            ESS::prepareTuningSettings(record->driver, target, a.nextOperationId, request, prerequisites, now, now + 3000000) :
            ESS::prepareDriverSettings(record->driver, target, a.nextOperationId, request, prerequisites, now, now + 3000000);
    } else return Probe::Action::INVALID;
    if (!checked) {
        if (a.simple.admitting) a.simple.view.status = checked;
        clearRecord(*record); return Probe::driverAdmissionStatus(checked);
    }
    ESS::PreparedDriver work;
    if (!ESS::nextDriver(record->driver, now, work)) { clearRecord(*record); return Probe::Action::FAILED; }
    const auto admitted = admitDriverStep(a, *record, work, now);
    if (admitted != Probe::Action::OK) { clearRecord(*record); return admitted; }
    record->serialTuple = a.serial.active; record->serialGeneration = a.serial.generation;
    record->operationId = a.nextOperationId++; record->commandId = commandId; record->address = address;
    record->deadlineUs = record->driver.deadlineUs; record->configurationGeneration = generation;
    record->kind = App::OperationKind::DRIVER; record->axisReserved = kind == ESS::DriverKind::UPDATE;
    operationId = a.latestOperationId = record->operationId; return Probe::Action::OK;
}
// Apply possible changes as soon as TX is accepted. Readback never rewrites
// historical contexts or silently promotes stored codes into active settings.
void invalidateDriverAssumptions(App& a, uint8_t address, uint32_t changed, uint64_t now, const App::Record* changing = nullptr,
                                ESS::DriverGroup group = ESS::DriverGroup::DRIVE) {
    if (group == ESS::DriverGroup::POSITION_START_SPEED)
        a.startSpeedWritten[address / 8] |= static_cast<uint8_t>(1U << (address % 8));
    if (auto* member = groupMember(a, address)) {
        // Members keep no start-speed relation: after a possible start-speed
        // write this boot, that member stays unready for group moves.
        if (group == ESS::DriverGroup::POSITION_START_SPEED) member->startSpeedRelationRequired = true;
        invalidateMemberConfiguration(a, address, now);
    }
    if (singleSettingGroup(group)) {
        // Storing a start speed or future homing policy proves no counter change.
        // Keep historical snapshots, but expire their generation and all future
        // prepared work. Local bit 0 must never be interpreted as DIRECTION.
        if (address == a.axis.target.address) {
            if (group == ESS::DriverGroup::POSITION_START_SPEED) {
                revokePositionStartSpeedRelation(a);
            }
            a.axis.generation = !a.axis.generation || a.axis.generation == UINT32_MAX ? 0 : a.axis.generation + 1;
            a.coordinateReference = MotorControlRS::AxisReference();
            a.configuration.operationId = 0;
            a.simpleEndpointKnown = false; a.rememberedMoveGeneration = 0;
            a.movePrerequisites = ESS::MovePrerequisites(); a.velocityPrerequisites = ESS::VelocityPrerequisites();
            a.homePrerequisites = ESS::HomePrerequisites(); a.positionClearQualification = PositionClearQualification();
            for (auto& other : a.records) if (&other != changing && other.axisReserved && !terminal(a, other) &&
                !(other.groupChild && other.address != address)) {
                other.cancelContinuation = true;
                if (other.requestId.owner) a.owner.cancelUnsent(other.requestId, now);
            }
            invalidateObservations(a, address, now);
        }
        return;
    }
    const bool tuning = ESS::isTuningGroup(group);
    if (address == a.axis.target.address) {
        invalidateAxis(a, changing, now);
        if (!tuning && (changed & (static_cast<uint16_t>(ESS::DriverField::DIRECTION) | static_cast<uint16_t>(ESS::DriverField::SUBDIVISION)))) {
            a.axis.units.commandStepsPerMotorTurn = MotorControlRS::UnitScale();
            a.simple.desired.scaleKnown = false;
        }
        if (!tuning && (changed & static_cast<uint16_t>(ESS::DriverField::DIRECTION))) a.commandPolarityKnown = false;
        if (!tuning && (changed & static_cast<uint32_t>(ESS::DriverField::CONFIGURED_ENCODER)))
            a.axis.units.encoder = MotorControlRS::EncoderScale();
        a.configuration.operationId = 0;
        a.movePrerequisites = ESS::MovePrerequisites(); a.velocityPrerequisites = ESS::VelocityPrerequisites();
        a.homePrerequisites = ESS::HomePrerequisites();
        a.positionClearQualification = PositionClearQualification();
    }
    if (a.driverSettings.target.address == address) a.driverSettings.operationId = 0;
    if (a.ioSettings.target.address == address) a.ioSettings.operationId = 0;
    if (a.segmentSettings.target.address == address) a.segmentSettings.operationId = 0;
    if (a.controlSettings.target.address == address) a.controlSettings.operationId = 0;
    for (auto& cache : a.tuningSettings)
        if (cache.target.address == address) cache.operationId = 0;
    if ((tuning && group == ESS::DriverGroup::FILTERS && (changed & 1)) ||
        (!tuning && (changed & (0x0003FE00u | static_cast<uint32_t>(ESS::DriverField::INTERRUPTION) |
        static_cast<uint32_t>(ESS::DriverField::POSITION_MODE)))))
        a.driverInputsQualified = false;
    invalidateObservations(a, address, now);
}
void driverEffects(App& a, App::Record& record, uint32_t effects, uint64_t now) {
    const uint32_t changed = effects & ~record.driverEffects;
    if (!changed) return;
    record.driverEffects |= changed;
    invalidateDriverAssumptions(a, record.address, changed, now, &record, record.driver.group);
    if (record.singleSettingSession) record.configurationGeneration = a.axis.generation;
}
uint32_t driverConfigEffects(const ESS::RawConfig& config, const ESS::DriverObservation& driver) {
    uint16_t effects = 0;
    if (config.direction != driver.raw[0]) effects |= static_cast<uint16_t>(ESS::DriverField::DIRECTION);
    if (config.subdivision != driver.raw[1]) effects |= static_cast<uint16_t>(ESS::DriverField::SUBDIVISION);
    if (config.wordOrder != driver.raw[2]) effects |= static_cast<uint16_t>(ESS::DriverField::WORD_ORDER);
    if (config.softLimitEnable != driver.raw[3]) effects |= static_cast<uint16_t>(ESS::DriverField::SOFT_LIMIT_ENABLE);
    if (config.overLimitStop != driver.raw[4]) effects |= static_cast<uint16_t>(ESS::DriverField::OVER_LIMIT_STOP);
    return effects;
}
uint32_t controlConfigEffects(const ESS::RawConfig& config, const ESS::DriverObservation& control) {
    uint32_t effects = 0;
    if (config.algorithm != control.raw[0]) effects |= static_cast<uint32_t>(ESS::DriverField::CONTROL_ALGORITHM);
    if (config.encoderResolution != control.raw[1]) effects |= static_cast<uint32_t>(ESS::DriverField::CONFIGURED_ENCODER);
    return effects;
}
// Grouped refreshes publish complete snapshots only. Each checked window must
// still invalidate contradicted assumptions before another write can be yielded.
uint32_t changedWindowWord(uint16_t first, const uint16_t* words, std::size_t count,
                          uint16_t reg, uint16_t previous, ESS::DriverField field) {
    return reg >= first && static_cast<std::size_t>(reg - first) < count &&
        words[reg - first] != previous ? static_cast<uint32_t>(field) : 0;
}
uint32_t changedConfigWindow(const ESS::RawConfig& previous, uint16_t first,
                             const uint16_t* words, std::size_t count) {
    using namespace ESS;
    struct Word { uint16_t reg, value; DriverField field; };
    const Word previousWords[] = {
        {Registers::DEFAULT_DIRECTION, previous.direction, DriverField::DIRECTION},
        {Registers::SUBDIVISION, previous.subdivision, DriverField::SUBDIVISION},
        {Registers::WORD_ORDER, previous.wordOrder, DriverField::WORD_ORDER},
        {Registers::SOFT_LIMIT_ENABLE, previous.softLimitEnable, DriverField::SOFT_LIMIT_ENABLE},
        {Registers::OVER_LIMIT_STOP, previous.overLimitStop, DriverField::OVER_LIMIT_STOP},
        {Registers::INPUT_POLARITY, previous.inputPolarity, DriverField::INPUT_POLARITY},
        {Registers::INPUT_X0_FUNCTION, previous.inputFunctions[0], DriverField::INPUT_X0},
        {Registers::INPUT_X1_FUNCTION, previous.inputFunctions[1], DriverField::INPUT_X1},
        {Registers::INPUT_X2_FUNCTION, previous.inputFunctions[2], DriverField::INPUT_X2},
        {Registers::INPUT_X3_FUNCTION, previous.inputFunctions[3], DriverField::INPUT_X3},
        {Registers::CONTROL_ALGORITHM, previous.algorithm, DriverField::CONTROL_ALGORITHM},
        {Registers::ENCODER_RESOLUTION, previous.encoderResolution, DriverField::CONFIGURED_ENCODER}
    };
    uint32_t changed = 0;
    for (const auto& word : previousWords)
        changed |= changedWindowWord(first, words, count, word.reg, word.value, word.field);
    return changed;
}
uint32_t changedDriverWindow(const ESS::DriverObservation& previous, uint16_t first,
                             const uint16_t* words, std::size_t count) {
    const auto group = previous.group;
    const bool tuning = ESS::isTuningGroup(group);
    const uint16_t registers[] = {ESS::Registers::DEFAULT_DIRECTION, ESS::Registers::SUBDIVISION,
        ESS::Registers::WORD_ORDER, ESS::Registers::SOFT_LIMIT_ENABLE, ESS::Registers::OVER_LIMIT_STOP,
        ESS::Registers::PV_TRIGGER_MODE, ESS::Registers::EXTERNAL_POSITION_MODE,
        ESS::Registers::INPUT_POLARITY, ESS::Registers::INPUT_X0_FUNCTION, ESS::Registers::INPUT_X1_FUNCTION,
        ESS::Registers::INPUT_X2_FUNCTION, ESS::Registers::INPUT_X3_FUNCTION,
        ESS::Registers::OUTPUT_POLARITY, ESS::Registers::OUTPUT_Y0_FUNCTION,
        ESS::Registers::OUTPUT_Y1_FUNCTION, ESS::Registers::CUSTOM_OUTPUT};
    const uint8_t start = group == ESS::DriverGroup::IO ? 7 : 0;
    const uint8_t end = tuning ? ESS::tuningFieldCount(group) : group == ESS::DriverGroup::IO ? 16 :
        group == ESS::DriverGroup::CONTROL_SETTINGS ? 8 : 7;
    uint32_t changed = 0;
    for (uint8_t slot = start; slot < end; ++slot) {
        ESS::TuningParameterInfo info;
        const uint16_t reg = tuning ?
            (ESS::tuningParameterInfo(ESS::tuningParameter(group, slot), info) ? info.reg : 0) :
            group == ESS::DriverGroup::CONTROL_SETTINGS ?
            static_cast<uint16_t>(ESS::Registers::CONTROL_ALGORITHM + slot) : registers[slot];
        changed |= changedWindowWord(first, words, count, reg, previous.raw[slot], ESS::driverFieldAt(slot, group));
    }
    if (group == ESS::DriverGroup::DRIVE) for (uint8_t i = 0; i < 2; ++i) {
        changed |= changedWindowWord(first, words, count, ESS::Registers::POSITIVE_SOFT_LIMIT + i,
            previous.positiveWords[i], ESS::DriverField::POSITIVE_LIMIT);
        changed |= changedWindowWord(first, words, count, ESS::Registers::NEGATIVE_SOFT_LIMIT + i,
            previous.negativeWords[i], ESS::DriverField::NEGATIVE_LIMIT);
    }
    return changed;
}
void reconcileConfigRead(App& a, App::Record& record, uint64_t now) {
    if (record.read.kind != ESS::ReadKind::CONFIG || record.address != a.axis.target.address ||
        record.configurationGeneration != a.axis.generation || record.read.target.generation != a.bindingGeneration ||
        record.operationId <= a.configuration.operationId || record.operationId <= a.driverSettings.operationId ||
        record.operationId <= a.ioSettings.operationId || record.operationId <= a.controlSettings.operationId) return;
    uint32_t changed = 0;
    for (uint8_t step = 0; step < record.read.completedSteps; ++step) {
        const auto& evidence = record.read.observations[step];
        uint16_t words[5] = {}; std::size_t count = 0;
        if (!ESS::parseRegisters(evidence.raw, evidence.length, record.address, evidence.count, words, 5, count)) continue;
        if ((a.configuration.operationId || record.effectsInvalidated) && Probe::sameTarget(a.configuration.target, record.read.target))
            changed |= changedConfigWindow(a.configuration.raw, evidence.first, words, count);
        for (const auto* cache : {&a.driverSettings, &a.ioSettings, &a.controlSettings})
            if ((cache->operationId || record.effectsInvalidated) && Probe::sameTarget(cache->target, record.read.target))
                changed |= changedDriverWindow(*cache, evidence.first, words, count);
    }
    changed &= ~record.driverEffects;
    if (changed) {
        record.driverEffects |= changed;
        record.effectsInvalidated = true;
        invalidateDriverAssumptions(a, record.address, changed, now, &record);
        // Reconcile this private collection record only. Its public observations
        // retain the generation and raw evidence originally supplied by the owner.
        record.configurationGeneration = a.axis.generation;
    }
}
void reconcileDriverRead(App& a, App::Record& record, uint64_t now) {
    if (record.kind != App::OperationKind::DRIVER || record.driver.kind != ESS::DriverKind::READ ||
        record.singleSettingSession ||
        segmentGroup(record.driver.group) || record.address != a.axis.target.address ||
        record.configurationGeneration != a.axis.generation || record.driver.target.generation != a.bindingGeneration) return;
    const bool tuning = ESS::isTuningGroup(record.driver.group);
    const auto& cache = tuning ? tuningCache(a, record.driver.group) : record.driver.group == ESS::DriverGroup::IO ?
        a.ioSettings : record.driver.group == ESS::DriverGroup::CONTROL_SETTINGS ? a.controlSettings : a.driverSettings;
    if (record.operationId <= cache.operationId || record.operationId <= a.configuration.operationId) return;
    uint32_t changed = 0;
    for (uint8_t step = 0; step < record.driver.completedSteps; ++step) {
        const auto& evidence = record.driver.observations[step];
        uint16_t words[5] = {}; std::size_t count = 0;
        if (!ESS::parseRegisters(evidence.raw, evidence.length, record.address, evidence.count, words, 5, count)) continue;
        if ((cache.operationId || record.effectsInvalidated) && cache.group == record.driver.group &&
            Probe::sameTarget(cache.target, record.driver.target))
            changed |= changedDriverWindow(cache, evidence.reg, words, count);
        else if (!tuning && (a.configuration.operationId || record.effectsInvalidated) &&
                 Probe::sameTarget(a.configuration.target, record.driver.target))
            changed |= changedConfigWindow(a.configuration.raw, evidence.reg, words, count);
    }
    changed &= ~record.driverEffects;
    if (changed) {
        record.driverEffects |= changed;
        record.effectsInvalidated = true;
        invalidateDriverAssumptions(a, record.address, changed, now, &record, record.driver.group);
        record.configurationGeneration = a.axis.generation;
    }
}
void observeCommunication(App& a, const Rtu::Completion& result) {
    const bool checked = result.outcome == Rtu::Outcome::SUCCESS || result.outcome == Rtu::Outcome::DEVICE_REJECTED;
    if (!checked || !result.transport.closureQualified || result.transport.txAccepted != result.txLength ||
        result.transport.startedUs > result.transport.closureEarliestUs ||
        result.transport.closureEarliestUs > result.transport.closureLatestUs ||
        result.transport.closureLatestUs > nowUs() ||
        result.expected.targetGeneration != a.bindingGeneration ||
        (a.communicationKnown && result.transport.closureLatestUs < a.communicationLatestUs)) return;
    a.communicationKnown = true;
    a.knownTargets[result.expected.address / 8] |= static_cast<uint8_t>(1U << (result.expected.address % 8));
    a.communicationTarget.id = result.expected.target;
    a.communicationTarget.address = result.expected.address;
    a.communicationTarget.generation = result.expected.targetGeneration;
    a.communicationEarliestUs = result.transport.startedUs;
    a.communicationLatestUs = result.transport.closureLatestUs;
}
MotorControlRS::ReadEvent readEvent(const App::Record& record, ReadEventKind kind) {
    MotorControlRS::ReadEvent event; event.target = record.read.target;
    event.operationId = record.operationId; event.step = record.read.step; event.kind = kind;
    return event;
}
void reconcileVelocityParameters(App& a, const App::Record& record) {
    if (record.serialGeneration != a.serial.generation || record.read.target.generation != a.bindingGeneration) return;
    if (record.read.kind == ESS::ReadKind::VELOCITY_PARAMETERS &&
        Probe::sameTarget(record.read.target, a.axis.target) &&
        record.read.configurationGeneration == a.axis.generation &&
        record.operationId > a.velocityParameters.operationId) {
        ESS::VelocityParametersObservation observed;
        if (ESS::getVelocityParameters(record.read, observed)) {
            const auto& prior = a.velocityParameters;
            auto& qualification = a.velocityPrerequisites;
            const bool same = prior.operationId && Probe::sameTarget(prior.target, observed.target) &&
                prior.configurationGeneration == observed.configurationGeneration;
            const bool rampChanged = (same && (prior.rawAccelerationTime != observed.rawAccelerationTime ||
                prior.rawDecelerationTime != observed.rawDecelerationTime)) ||
                (qualification.configuredRampVerified &&
                 (qualification.accelerationTime != observed.rawAccelerationTime ||
                  qualification.decelerationTime != observed.rawDecelerationTime));
            if (rampChanged) qualification.configuredRampVerified = false;
            if (rampChanged || (same && prior.rawSpeed != observed.rawSpeed))
                qualification.readinessQualified = false;
            a.velocityParameters = observed;
        }
    }
}
void reconcileHomingParameters(App& a, const App::Record& record) {
    if (record.serialGeneration != a.serial.generation || record.read.target.generation != a.bindingGeneration ||
        record.read.kind != ESS::ReadKind::HOMING_PARAMETERS || !Probe::sameTarget(record.read.target, a.axis.target) ||
        record.read.configurationGeneration != a.axis.generation || record.operationId <= a.homingParameters.operationId) return;
    ESS::HomingParametersObservation observed;
    if (!ESS::getHomingParameters(record.read, observed)) return;
    const auto& prior = a.homingParameters;
    auto& p = a.homePrerequisites;
    const bool same = prior.operationId && Probe::sameTarget(prior.target, observed.target) &&
        prior.configurationGeneration == observed.configurationGeneration;
    const bool auxiliaryChanged = (same && prior.rawAuxiliary != observed.rawAuxiliary) ||
        (p.auxiliaryQualified && observed.rawAuxiliary != static_cast<uint16_t>(p.auxiliary));
    // A stored word differing from the candidate is expected before staging; one changing
    // between reads of this generation means something else wrote it.
    const bool methodChanged = same && prior.rawMethod != observed.rawMethod;
    const bool ratesChanged = same && (prior.rawSearchSpeed != observed.rawSearchSpeed || prior.rawReturnSpeed != observed.rawReturnSpeed);
    const bool rampChanged = same && prior.rawRampTime != observed.rawRampTime;
    const bool offsetChanged = (same && (prior.rawOffsetWords[0] != observed.rawOffsetWords[0] || prior.rawOffsetWords[1] != observed.rawOffsetWords[1])) ||
        (p.zeroOffsetQualified && (observed.rawOffsetWords[0] || observed.rawOffsetWords[1]));
    if (auxiliaryChanged) p.auxiliaryQualified = false;
    if (methodChanged) p.methodQualified = false;
    if (ratesChanged) p.nativeRatesQualified = false;
    if (rampChanged) p.nativeRampQualified = false;
    if (offsetChanged) p.zeroOffsetQualified = false;
    if (auxiliaryChanged || methodChanged || offsetChanged) p.referenceSemanticsQualified = false;
    if (auxiliaryChanged || methodChanged || ratesChanged || rampChanged || offsetChanged) p.readinessQualified = false;
    for (auto& active : a.records) if (active.kind == App::OperationKind::HOME &&
        active.home.state == MotorControlRS::ActionState::ACTIVE) {
        const auto& admitted = active.home.prerequisites;
        if (observed.rawAuxiliary != static_cast<uint16_t>(admitted.auxiliary) ||
            observed.rawMethod != static_cast<uint16_t>(admitted.qualifiedMethod) ||
            observed.rawSearchSpeed != admitted.qualifiedSearchSpeed || observed.rawReturnSpeed != admitted.qualifiedReturnSpeed ||
            observed.rawRampTime != admitted.qualifiedRampTime || observed.rawOffsetWords[0] || observed.rawOffsetWords[1]) {
            ESS::revokeHome(active.home); active.cancelContinuation = true;
            if (active.requestId.owner) a.owner.cancelUnsent(active.requestId, nowUs());
        }
    }
    a.homingParameters = observed;
}
// Consume one retained transaction per operation per loop. Intermediate evidence
// is copied into the public context before its owner slot is explicitly released.
// The frontend record reserves terminal storage across the gaps between steps.
void advanceReads(App& a, uint64_t sampled) {
    for (auto& record : a.records) {
        if (!record.operationId || record.kind != App::OperationKind::TYPED_READ || record.read.state != ReadState::ACTIVE) continue;
        if (record.requestId.owner) {
            const auto* result = a.owner.result(record.requestId); if (!result) continue;
            const uint8_t block = record.read.step;
            const auto kind = result->transport.reason == Rtu::Reason::FRAME ? ReadEventKind::FRAME :
                result->transport.reason == Rtu::Reason::REQUEST_DEADLINE ||
                result->outcome == Rtu::Outcome::QUEUE_EXPIRED || result->outcome == Rtu::Outcome::DISPATCH_EXPIRED ? ReadEventKind::DEADLINE :
                result->outcome == Rtu::Outcome::CANCELLED ? ReadEventKind::CANCEL :
                ReadEventKind::TRANSPORT_FAILURE;
            auto event = readEvent(record, kind);
            copyCompletion(event, *result);
            if (!ESS::advanceRead(record.read, event, sampled)) {
                // An impossible owner/event envelope is an integration failure.
                // Preserve the captured prefix and terminate; never re-admit it.
                auto failed = readEvent(record, ReadEventKind::TRANSPORT_FAILURE);
                failed.transportDetail = -1;
                failed.txAccepted = event.txAccepted; failed.executionUnknown = true;
                failed.frame = event.frame; failed.length = event.length;
                if (!ESS::advanceRead(record.read, failed, sampled)) continue;
            }
            observeCommunication(a, *result);
            if (record.groupChild) {
                // Member reads publish into the member's own cache only.
                auto* member = groupMember(a, record.read.target.address);
                if (record.read.kind == ESS::ReadKind::STATE && member &&
                    Probe::sameTarget(member->axis.target, record.read.target) &&
                    record.configurationGeneration == member->axis.generation)
                    Probe::stateResult(member->state, record.read, block, result->transport.startedUs);
            } else {
                reconcileConfigRead(a, record, sampled);
                reconcileVelocityParameters(a, record);
                reconcileHomingParameters(a, record);
            }
            if (!record.groupChild && record.read.kind == ESS::ReadKind::STATE && record.configurationGeneration == a.axis.generation) {
                const auto& previous = a.stateCache.blocks[static_cast<uint8_t>(block)];
                const auto& reference = a.coordinateReference;
                const bool hadPosition = Probe::current(previous, a.axis.target) && previous.value.pairKnown &&
                    (!reference.nativeKnown || previous.observedLatestUs >= reference.observedUs);
                const auto previousPosition = previous.value.rawPosition;
                const auto previousSuccess = previous.observedLatestUs;
                Probe::stateResult(a.stateCache, record.read, block, result->transport.startedUs);
                const auto& current = a.stateCache.blocks[static_cast<uint8_t>(block)];
                // Homing's correlated zero replaces older feedback as the baseline.
                // Zero/nonzero is order/sign neutral; no unresolved pair conversion
                // is needed to detect departure from that qualified zero witness.
                const bool leftZero = reference.nativeKnown && reference.nativePosition == 0 &&
                    current.observedLatestUs >= reference.observedUs &&
                    (current.value.rawPositionWords[0] || current.value.rawPositionWords[1]);
                if (block == static_cast<uint8_t>(ESS::StateBlock::FEEDBACK) && Probe::current(current, a.axis.target) &&
                    current.observedLatestUs > previousSuccess &&
                    ((hadPosition && current.value.pairKnown && current.value.rawPosition != previousPosition) || leftZero) && coordinateKnowledge(a) &&
                    !a.bootCoordinates && !a.motionObservationPending && !triggeredMotion(a, a.axis.target.address)) invalidateAxis(a);
                // The standalone RAM zero is a fixed counter offset. Enabled
                // feedback changes (including servo settling/quantization) do
                // not reset that counter. Release, unexpected running, clear,
                // configuration changes and unresolved encoding still invalidate
                // through their evidence paths; homed references stay strict.
                if (record.read.state == ReadState::SUCCEEDED && a.motionObservationPending) {
                    const auto& motion = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::MOTION)];
                    const auto& feedback = a.stateCache.blocks[static_cast<uint8_t>(ESS::StateBlock::FEEDBACK)];
                    if (Probe::fresh(motion, a.axis.target, sampled, a.observationAgeUs()) &&
                        Probe::fresh(feedback, a.axis.target, sampled, a.observationAgeUs()) &&
                        feedback.value.pairKnown && !motion.value.running && !feedback.value.rawSpeed)
                        a.motionObservationPending = false;
                }
            }
            if (record.read.state != ReadState::ACTIVE) continue;
            a.owner.release(record.requestId); record.requestId = Rtu::RequestId();
        }
        if (record.cancelContinuation || record.read.target.generation != a.bindingGeneration ||
            (record.read.kind == ESS::ReadKind::STATE && record.configurationGeneration != recordGeneration(a, record))) {
            ESS::advanceRead(record.read, readEvent(record, ReadEventKind::CANCEL), sampled);
        } else if (sampled >= record.deadlineUs) {
            ESS::advanceRead(record.read, readEvent(record, ReadEventKind::DEADLINE), sampled);
        } else if (!a.owner.needsRecovery() && !uart.needsRecovery()) {
            admitStep(a, record, sampled); // Queue pressure defers; no admitted frame is retried.
        }
    }
}
void updateActionReservation(App& a, App::Record& record) {
    using namespace MotorControlRS;
    if (!terminal(a, record)) return;
    record.motionUnresolved = (record.kind == App::OperationKind::MOVE &&
        (record.move.uncertain || record.move.interruption == ESS::PositionInterruption::INTERRUPT_CURRENT) &&
        (record.move.triggerEvidence.txAccepted || record.move.triggerEvidence.executionUnknown)) ||
        (record.kind == App::OperationKind::VELOCITY && (record.velocity.uncertain || record.velocity.needsStop) && record.velocity.triggerEvidence.txAccepted) ||
        (record.kind == App::OperationKind::HOME && record.home.uncertain && record.home.triggerEvidence.txAccepted);
    switch (record.kind) {
    case App::OperationKind::HOME: {
        record.axisReserved = false;
        if (record.home.uncertain)
            a.actionConflicts[record.address / 8] |= static_cast<uint8_t>(1U << (record.address % 8));
        if (!record.cancelContinuation && a.axis.generation && record.address == a.axis.target.address &&
            record.configurationGeneration == a.axis.generation && record.home.target.generation == a.bindingGeneration) {
            MotorControlRS::AxisReference reference;
            if (ESS::getHomeReference(record.home, nowUs(), a.observationAgeUs(), reference)) {
                // Only the derived cache is reconciled. Historical operation/evidence remain immutable.
                reference.configurationGeneration = a.axis.generation;
                a.coordinateReference = reference;
            }
        }
        return;
    }
    case App::OperationKind::DRIVER: {
        driverEffects(a, record, record.driver.effects, nowUs());
        record.axisReserved = false;
        if (record.singleSettingSession) return; // Single-field history is not a DRIVE cache or motion profile.
        const bool segment = segmentGroup(record.driver.group);
        const bool tuning = ESS::isTuningGroup(record.driver.group);
        auto& cache = tuning ? tuningCache(a, record.driver.group) : segment ? a.segmentSettings : record.driver.group == ESS::DriverGroup::IO ? a.ioSettings : record.driver.group == ESS::DriverGroup::CONTROL_SETTINGS ? a.controlSettings : a.driverSettings;
        if (record.driver.kind == ESS::DriverKind::READ && record.address == a.axis.target.address &&
            record.configurationGeneration == a.axis.generation && record.driver.target.generation == a.bindingGeneration &&
            record.operationId > cache.operationId && record.operationId > a.configuration.operationId &&
            ESS::getDriver(record.driver, a.driverObserved)) {
            const auto& observed = a.driverObserved;
            uint32_t changed = 0;
            const uint8_t first = record.driver.group == ESS::DriverGroup::IO ? 7 : 0;
            const uint8_t end = tuning ? ESS::tuningFieldCount(record.driver.group) : record.driver.group == ESS::DriverGroup::IO ? 16 : record.driver.group == ESS::DriverGroup::CONTROL_SETTINGS ? 8 : 7;
            if (segment) {
                cache = observed;
                return; // Different indexed records do not invalidate a shared scale.
            }
            // Prefer a current configuration read over invalidated driver raw
            // history. Keep the historical baseline after a host-only tuple
            // change when neither observation is current.
            if (cache.target.id && (cache.operationId || !a.configuration.operationId) &&
                cache.group == observed.group && Probe::sameTarget(cache.target, observed.target)) {
                for (uint8_t i = first; i < end; ++i)
                    if (cache.raw[i] != observed.raw[i]) changed |= static_cast<uint32_t>(ESS::driverFieldAt(i, record.driver.group));
                if (record.driver.group == ESS::DriverGroup::DRIVE &&
                    (std::memcmp(cache.positiveWords, observed.positiveWords, sizeof(observed.positiveWords)) ||
                     std::memcmp(cache.negativeWords, observed.negativeWords, sizeof(observed.negativeWords))))
                    changed |= static_cast<uint32_t>(ESS::DriverField::POSITIVE_LIMIT) | static_cast<uint32_t>(ESS::DriverField::NEGATIVE_LIMIT);
            } else if (!tuning && a.configuration.target.id && Probe::sameTarget(a.configuration.target, observed.target)) {
                if (record.driver.group == ESS::DriverGroup::DRIVE) changed |= driverConfigEffects(a.configuration.raw, observed);
                else if (record.driver.group == ESS::DriverGroup::CONTROL_SETTINGS) changed |= controlConfigEffects(a.configuration.raw, observed);
                else {
                    if (a.configuration.raw.inputPolarity != observed.raw[7]) changed |= static_cast<uint32_t>(ESS::DriverField::INPUT_POLARITY);
                    for (uint8_t i = 0; i < 4; ++i)
                        if (a.configuration.raw.inputFunctions[i] != observed.raw[8+i]) changed |= uint32_t(1) << (10+i);
                }
            }
            changed &= ~record.driverEffects;
            if (changed) invalidateDriverAssumptions(a, record.address, changed, nowUs(), &record, record.driver.group);
            cache = observed;
            // Only the derived cache adopts the reconciled generation.
            cache.configurationGeneration = a.axis.generation;
        }
        return;
    }
    case App::OperationKind::ACTION: case App::OperationKind::MOVE: case App::OperationKind::VELOCITY: break;
    case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION: case App::OperationKind::TYPED_READ: return;
    }
    // Completion/cancellation does not supply a fresh current position. Neither
    // changes the fixed origin; release, counter clear and configuration still
    // invalidate it through their own effect paths.
    if (((record.kind == App::OperationKind::MOVE && record.move.triggerEvidence.txAccepted) ||
        (record.kind == App::OperationKind::VELOCITY && record.velocity.triggerEvidence.txAccepted)))
        invalidateMotionObservations(a, record.address);
    record.axisReserved = false;
    if (record.kind == App::OperationKind::MOVE && record.move.uncertain) a.rememberedMoveGeneration = 0;
    const uint8_t mask = static_cast<uint8_t>(1U << (record.address % 8));
    bool conflict = false, stopped = false;
    switch (record.kind) {
    case App::OperationKind::VELOCITY:
        conflict = record.velocity.needsStop || record.velocity.uncertain;
        stopped = record.velocity.stop.completion == ActionCompletion::OBSERVED;
        break;
    case App::OperationKind::MOVE: conflict = record.move.uncertain || record.motionUnresolved; break;
    case App::OperationKind::ACTION:
        conflict = record.action.execution == ActionExecution::UNKNOWN ||
            (record.action.execution == ActionExecution::ACKNOWLEDGED && record.action.completion != ActionCompletion::OBSERVED);
        stopped = record.action.request.kind == ActionKind::STOP && record.action.completion == ActionCompletion::OBSERVED;
        break;
    case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION: case App::OperationKind::TYPED_READ:
    case App::OperationKind::HOME: case App::OperationKind::DRIVER: break; // Handled above.
    }
    if (conflict) a.actionConflicts[record.address / 8] |= mask;
    if (stopped) {
        // A new checked stopped-state report reconciles conflicts; historical
        // interrupted outcomes and their execution uncertainty stay unchanged.
        a.actionConflicts[record.address / 8] &= static_cast<uint8_t>(~mask);
        for (auto& previous : a.records)
            if (previous.address == record.address && terminal(a, previous)) previous.motionUnresolved = false;
        invalidateMotionObservations(a, record.address);
    }
}
MotorControlRS::Status advanceOperation(App::Record& record, const MotorControlRS::ActionEvent& event, uint64_t now) {
    switch (record.kind) {
    case App::OperationKind::HOME: return ESS::advanceHome(record.home, event, now);
    case App::OperationKind::DRIVER: return ESS::advanceDriver(record.driver, event, now);
    case App::OperationKind::VELOCITY: return ESS::advanceVelocity(record.velocity, event, now);
    case App::OperationKind::MOVE: return ESS::advanceMove(record.move, event, now);
    case App::OperationKind::ACTION: return ESS::advanceAction(record.action, event, now);
    case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION: case App::OperationKind::TYPED_READ: break;
    }
    return MotorControlRS::Status(MotorControlRS::Err::INVALID_CONFIG, 0, "record has no action sequence");
}
bool invalidatesMotion(const App::Record& record) {
    switch (record.kind) {
    case App::OperationKind::VELOCITY: return record.velocity.step == 0;
    case App::OperationKind::MOVE:
        return record.move.step <= record.move.triggerStep &&
            !(record.move.request.setup == MotorControlRS::MoveSetup::VERIFY_AND_UPDATE && record.move.step == 0);
    case App::OperationKind::ACTION: return record.action.step == 0;
    case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION: case App::OperationKind::TYPED_READ:
    case App::OperationKind::DRIVER: case App::OperationKind::HOME: return false;
    }
    return false;
}
Probe::Action startRecovery(App&, uint32_t, bool, uint32_t&);
ESS::ActionContext* stopContext(App::Record& record) {
    if (record.kind == App::OperationKind::ACTION && record.action.request.kind == MotorControlRS::ActionKind::STOP)
        return &record.action;
    if (record.kind == App::OperationKind::VELOCITY && record.velocity.phase == ESS::VelocityPhase::STOPPING)
        return &record.velocity.stop;
    return nullptr;
}
// A stop write with no accepted byte may wait for recovery: sending it afterwards
// is its first transmission, not a replay. Anything already on the wire stays
// with its own transaction and outcome.
void holdStop(App& a, App::Record& record, uint64_t now) {
    const auto* stop = stopContext(record);
    if (!stop || stop->state != MotorControlRS::ActionState::ACTIVE || stop->step != 0 ||
        stop->execution != MotorControlRS::ActionExecution::NOT_TRANSMITTED ||
        stop->writeEvidence.txAccepted || stop->writeEvidence.executionUnknown ||
        record.stopHeld || record.stopRecoveryId || record.discoveryStop || record.cancelContinuation) return;
    if (record.requestId.owner) {
        const auto* settled = a.owner.result(record.requestId);
        if (!settled) {
            if (!a.owner.cancelUnsent(record.requestId, now)) return;
            settled = a.owner.result(record.requestId);
        }
        if (!settled || settled->transport.txAccepted || settled->transport.txComplete || settled->executionUnknown) return;
        record.stopBeforeRecovery = *settled;
        record.stopBeforeRecoveryKnown = true;
        observeCommunication(a, *settled);
        if (!a.owner.release(record.requestId)) return;
        record.requestId = Rtu::RequestId();
    }
    record.stopHeld = true;
}
void endHeldStop(App::Record& record, ReadEventKind kind, int32_t detail, uint64_t now) {
    record.stopHeld = false;
    auto event = actionEvent(record, kind);
    event.transport.transportDetail = detail;
    advanceOperation(record, event, now);
}
// One recovery per held stop and one FC06 after it. Failure is terminal with
// execution=not_transmitted; only a new explicit stop tries again.
void serviceHeldStop(App& a, App::Record& record, uint64_t now) {
    if (record.cancelContinuation) { endHeldStop(record, ReadEventKind::CANCEL, 0, now); return; }
    if (now >= record.deadlineUs) { endHeldStop(record, ReadEventKind::DEADLINE, 0, now); return; }
    if (record.stopRecoveryId && a.recovery.id && record.stopRecoveryId != a.recovery.id) {
        endHeldStop(record, ReadEventKind::TRANSPORT_FAILURE, -2, now);
        return;
    }
    if (a.owner.recovering()) {
        record.stopRecoveryId = a.recovery.id;
        record.stopRecoveryOperationId = a.recovery.operationId;
        return;
    }
    if (a.owner.needsRecovery() || uart.needsRecovery()) {
        uint32_t recovery = 0;
        if (!record.stopRecoveryId && startRecovery(a, 0, true, recovery) == Probe::Action::OK) {
            record.stopRecoveryId = a.recovery.id;
            record.stopRecoveryOperationId = recovery;
        } else endHeldStop(record, ReadEventKind::TRANSPORT_FAILURE, -2, now);
        return;
    }
    if (record.kind == App::OperationKind::VELOCITY) {
        auto target = record.velocity.stop.target;
        if (target.generation != a.bindingGeneration) {
            target.generation = a.bindingGeneration;
            if (!ESS::rebindVelocityStop(record.velocity, target, now)) {
                endHeldStop(record, ReadEventKind::TRANSPORT_FAILURE, -3, now);
                return;
            }
        }
        ESS::PreparedVelocity work;
        if (!ESS::nextVelocity(record.velocity, now, work) || work.kind != ESS::ActionWork::TRANSACTION) {
            endHeldStop(record, ReadEventKind::TRANSPORT_FAILURE, -3, now);
            return;
        }
        const auto admitted = admitVelocityStep(a, record, work, now);
        if (admitted == Probe::Action::OK) record.stopHeld = false;
        else if (admitted != Probe::Action::RESULTS_FULL && admitted != Probe::Action::QUEUE_FULL)
            endHeldStop(record, ReadEventKind::TRANSPORT_FAILURE, -4, now);
        return;
    }
    // Recovery changed the binding generation. The operation, policy and fixed
    // deadline are unchanged; started_us becomes this preparation of the frame.
    MotorControlRS::ReadTarget target = record.action.target; target.generation = a.bindingGeneration;
    ESS::ActionContext prepared;
    ESS::PreparedAction work;
    if (!ESS::prepareAction(prepared, target, record.operationId, record.action.request, now, record.deadlineUs, record.action.options) ||
        !ESS::nextAction(prepared, now, work) || work.kind != ESS::ActionWork::TRANSACTION) {
        endHeldStop(record, ReadEventKind::TRANSPORT_FAILURE, -3, now);
        return;
    }
    const auto admitted = admitActionStep(a, record, work, now);
    if (admitted == Rtu::BusAdmission::ACCEPTED) { record.action = prepared; record.stopHeld = false; }
    else if (admitted != Rtu::BusAdmission::URGENT_FULL) endHeldStop(record, ReadEventKind::TRANSPORT_FAILURE, -4, now);
}
void cancelInvalidPositionClears(App& a, uint64_t now) {
    for (auto& record : a.records) {
        if (record.kind != App::OperationKind::ACTION || record.action.request.kind != MotorControlRS::ActionKind::CLEAR_POSITION ||
            terminal(a, record) || record.action.step != 0 ||
            (record.requestId.owner && a.owner.txAccepted(record.requestId))) continue;
        if (positionClearQualificationValid(a) && positionClearReadiness(a, record.address, now) &&
            Probe::sameTarget(record.action.target, a.positionClearQualification.target) &&
            record.configurationGeneration == a.positionClearQualification.configurationGeneration) continue;
        record.cancelContinuation = true;
        if (record.requestId.owner) a.owner.cancelUnsent(record.requestId, now);
    }
}
void cancelInvalidReleases(App& a, uint64_t now) {
    for (auto& record : a.records) {
        if (!record.releaseAfterStopId || terminal(a, record) || record.action.step != 0 ||
            (record.requestId.owner && a.owner.txAccepted(record.requestId))) continue;
        if (releaseFactsValid(a, record.releasePrerequisites, now) && failedTransmittedStop(a, record.releaseAfterStopId)) continue;
        record.cancelContinuation = true;
        if (record.requestId.owner) a.owner.cancelUnsent(record.requestId, now);
    }
}
void advanceActions(App& a, uint64_t now) {
    cancelInvalidHomes(a, now);
    cancelInvalidReleases(a, now);
    cancelInvalidPositionClears(a, now);
    for (auto& record : a.records) {
        // A cancelled held stop can finish before its recovery. Keep the later
        // recovery outcome as independent evidence even for terminal records.
        if (record.stopRecoveryId && !record.stopRecoveryResult.id)
            if (const auto* recovered = a.owner.recoveryResult(record.stopRecoveryId))
                record.stopRecoveryResult = *recovered;
        if (record.discoveryStop && a.discovery.owned) {
            if (now < record.deadlineUs && a.discovery.phase != Probe::DiscoveryPhase::INTERLOCK) continue;
            record.discoveryStop = false;
            advanceOperation(record, actionEvent(record, now >= record.deadlineUs ?
                ReadEventKind::DEADLINE : ReadEventKind::TRANSPORT_FAILURE), now);
            updateActionReservation(a, record);
        }
        if (record.discoveryStop) {
            record.discoveryStop = false;
            record.serialTuple = a.serial.active; record.serialGeneration = a.serial.generation;
            if (!a.discovery.restored || a.owner.needsRecovery() || uart.needsRecovery())
                advanceOperation(record, actionEvent(record, ReadEventKind::TRANSPORT_FAILURE), now);
            updateActionReservation(a, record);
        }
        if (!sequenced(record) || terminal(a, record)) continue;
        if (a.owner.needsRecovery() || uart.needsRecovery()) holdStop(a, record, now);
        if (record.stopHeld) {
            serviceHeldStop(a, record, now);
            updateActionReservation(a, record);
            continue;
        }
        // A prepared group member waits for its turn; the group sends its first frame.
        if (record.groupWaiting && !record.cancelContinuation) {
            updateActionReservation(a, record);
            continue;
        }
        if (record.interruptWaiting && !settlePositionInterrupt(a, record, now)) {
            updateActionReservation(a, record);
            continue;
        }
        // Reads queued ahead of this write may contradict its admitted stopped/
        // input policy. Settle an unsent cancellation before the owner can TX.
        // Once any write byte is accepted, preserve its outcome and readback.
        if (record.singleSettingSession && record.driver.kind == ESS::DriverKind::UPDATE && record.driver.step == 0 &&
            (!record.requestId.owner || !a.owner.txAccepted(record.requestId)) && !singleSettingPolicy(a, now)) {
            record.cancelContinuation = true;
            if (record.requestId.owner) a.owner.cancelUnsent(record.requestId, now);
        }
        if (record.singleSettingSession && (record.configurationGeneration != a.axis.generation ||
            record.driver.target.generation != a.bindingGeneration || record.serialGeneration != a.serial.generation)) {
            record.cancelContinuation = true;
            if (record.requestId.owner) a.owner.cancelUnsent(record.requestId, now);
        }
        if (record.requestId.owner) {
            if (record.kind == App::OperationKind::HOME && !record.effectsInvalidated && a.owner.txAccepted(record.requestId)) {
                record.effectsInvalidated = true;
                invalidateAxis(a, &record);
                record.configurationGeneration = a.axis.generation;
                a.homePrerequisites = ESS::HomePrerequisites();
                invalidateObservations(a, record.address, now);
            }
            if (record.kind == App::OperationKind::DRIVER && record.driver.kind == ESS::DriverKind::UPDATE &&
                a.owner.txAccepted(record.requestId)) {
                ESS::PreparedDriver work;
                if (ESS::nextDriver(record.driver, record.driver.servicedUs, work) && work.write)
                    for (const auto& progress : record.driver.progress)
                        if (progress.selected && progress.reg == work.reg)
                            driverEffects(a, record, static_cast<uint32_t>(progress.field), now);
            }
            if (((record.kind == App::OperationKind::MOVE && record.move.step == record.move.triggerStep) ||
                (record.kind == App::OperationKind::VELOCITY && record.velocity.phase == ESS::VelocityPhase::TRIGGER)) && record.address == a.axis.target.address &&
                a.owner.txAccepted(record.requestId)) {
                a.coordinateReference.nativeKnown = false;
                a.simpleEndpointKnown = false;
            }
            if (!record.effectsInvalidated && invalidatesMotion(record) && a.owner.txAccepted(record.requestId)) {
                record.effectsInvalidated = true;
                if (record.kind == App::OperationKind::MOVE && record.move.step < record.move.triggerStep) {
                    a.rememberedMoveGeneration = 0;
                    storedWordsChanged(a, record.address);
                }
                invalidateObservations(a, record.address, now, true);
                if (record.kind == App::OperationKind::ACTION && (record.action.request.kind == MotorControlRS::ActionKind::RELEASE ||
                    record.action.request.kind == MotorControlRS::ActionKind::CLEAR_POSITION) &&
                    a.axis.target.address == record.address) invalidateAxis(a);
                if (record.kind == App::OperationKind::ACTION && record.action.request.kind == MotorControlRS::ActionKind::ENABLE) {
                    auto& wait = a.enableWaits[record.address];
                    wait = App::EnableWait();
                    wait.target = record.action.target; wait.serialTuple = record.serialTuple;
                    wait.serialGeneration = record.serialGeneration; wait.operationId = record.operationId;
                    // Preserve the existing origin: first service that sees accepted TX.
                    wait.observedUs = now;
                    wait.untilUs = now > UINT64_MAX - ENABLE_SETTLE_US ? UINT64_MAX : now + ENABLE_SETTLE_US;
                    wait.execution = MotorControlRS::ActionExecution::UNKNOWN;
                }
            }
            const auto* result = a.owner.result(record.requestId); if (!result) continue;
            const auto kind = result->transport.reason == Rtu::Reason::FRAME ? ReadEventKind::FRAME :
                result->transport.reason == Rtu::Reason::REQUEST_DEADLINE ||
                result->outcome == Rtu::Outcome::QUEUE_EXPIRED || result->outcome == Rtu::Outcome::DISPATCH_EXPIRED ? ReadEventKind::DEADLINE :
                result->outcome == Rtu::Outcome::CANCELLED ? ReadEventKind::CANCEL : ReadEventKind::TRANSPORT_FAILURE;
            auto event = actionEvent(record, kind);
            copyCompletion(event.transport, *result);
            event.txComplete = result->transport.txComplete;
            if (record.kind == App::OperationKind::MOVE && record.move.step == record.move.triggerStep) {
                // The start write's physical TX completion, for measured group spreads.
                record.triggerTxComplete = result->transport.txComplete;
                record.triggerTxEndUs = result->transport.txEndUs;
                record.triggerTxUncertaintyUs = result->transport.txUncertaintyUs;
            }
            // Checked FC03/FC10 replies have distinct request/response wire forms.
            // FC06 retains uncertain source evidence unless the adapter/user
            // explicitly established echo exclusion. Analyzer qualification is
            // independent of admission and never fabricated here.
            event.responseConfirmed = kind == ReadEventKind::FRAME &&
                (result->outcome == Rtu::Outcome::SUCCESS || result->outcome == Rtu::Outcome::DEVICE_REJECTED) &&
                result->transport.closureQualified &&
                result->transport.txComplete && (writeResponseConfirmed || result->expected.function != 6);
            if (!advanceOperation(record, event, now)) {
                auto failed = actionEvent(record, ReadEventKind::TRANSPORT_FAILURE);
                failed.transport.transportDetail = -1;
                failed.transport.txAccepted = event.transport.txAccepted;
                failed.transport.executionUnknown = true;
                failed.transport.frame = event.transport.frame; failed.transport.length = event.transport.length;
                failed.txComplete = event.txComplete;
                if (!advanceOperation(record, failed, now)) continue;
            }
            if (record.kind == App::OperationKind::ACTION && record.action.request.kind == MotorControlRS::ActionKind::ENABLE &&
                event.transport.step == 0 && a.enableWaits[record.address].operationId == record.operationId) {
                auto& wait = a.enableWaits[record.address];
                wait.write = record.action.writeEvidence;
                wait.execution = record.action.execution;
            }
            observeCommunication(a, *result);
            if (record.kind == App::OperationKind::MOVE && record.groupChild) {
                // A member's staging can change the stored words of the selected drive.
                if (record.move.uncertain && record.address == a.axis.target.address) a.rememberedMoveGeneration = 0;
            } else if (record.kind == App::OperationKind::MOVE) {
                const auto& move = record.move;
                if (record.storedPosition.target.id && move.execution == MotorControlRS::ActionExecution::ACKNOWLEDGED &&
                    !move.uncertain && (move.stagingApplied || move.verificationKnown ||
                        move.request.setup == MotorControlRS::MoveSetup::USE_STORED))
                    record.storedPosition.qualified = true;
                if (move.uncertain) a.rememberedMoveGeneration = 0;
                else if ((move.stagingApplied || move.verificationKnown) &&
                    move.prepared.configurationGeneration == a.axis.generation &&
                    move.target.generation == a.bindingGeneration && record.serialGeneration == a.serial.generation) {
                    const uint16_t* words = move.stagingApplied ? move.words : move.verificationWords;
                    std::memcpy(a.rememberedMoveWords, words, sizeof(a.rememberedMoveWords));
                    a.rememberedMoveGeneration = move.prepared.configurationGeneration;
                    a.rememberedMoveBinding = move.target.generation; a.rememberedMoveSerial = record.serialGeneration;
                }
            }
            a.owner.release(record.requestId); record.requestId = Rtu::RequestId();
            continueSingleSetting(a, record, now);
            reconcileDriverRead(a, record, now);
        }
        if (!terminal(a, record)) {
            if (record.cancelContinuation || actionEvent(record, ReadEventKind::CANCEL).transport.target.generation != a.bindingGeneration ||
                (record.kind == App::OperationKind::MOVE &&
                    (record.move.admission == ESS::MoveAdmission::NATIVE_INTENT ? record.move.stored.configurationGeneration :
                     record.move.prepared.configurationGeneration) != recordGeneration(a, record)) ||
                (record.kind == App::OperationKind::VELOCITY && record.velocity.phase != ESS::VelocityPhase::STOPPING &&
                    record.velocity.request.configurationGeneration != a.axis.generation) ||
                (record.kind == App::OperationKind::HOME && (!a.axis.generation || record.configurationGeneration != a.axis.generation)))
                advanceOperation(record, actionEvent(record, ReadEventKind::CANCEL), now);
            else if (stopContext(record) && stopContext(record)->step > 0 &&
                (a.owner.needsRecovery() || uart.needsRecovery()))
                advanceOperation(record, actionEvent(record, ReadEventKind::TRANSPORT_FAILURE), now);
            else if (record.kind == App::OperationKind::VELOCITY) {
                // Evidence above is consumed before elapsed time. A borrowed
                // admitted token must settle before stop changes its correlation.
                ESS::serviceVelocity(record.velocity, now);
                if (!terminal(a, record) && !a.owner.needsRecovery() && !uart.needsRecovery()) {
                    ESS::PreparedVelocity work;
                    if (ESS::nextVelocity(record.velocity, now, work) && work.kind == ESS::ActionWork::TRANSACTION) {
                        const auto admitted = admitVelocityStep(a, record, work, now);
                        if (admitted != Probe::Action::OK && admitted != Probe::Action::QUEUE_FULL &&
                            admitted != Probe::Action::RESULTS_FULL && admitted != Probe::Action::RECOVERY_REQUIRED)
                            advanceOperation(record, actionEvent(record, ReadEventKind::TRANSPORT_FAILURE), now);
                    }
                }
            }
            else if (now >= record.deadlineUs)
                advanceOperation(record, actionEvent(record, ReadEventKind::DEADLINE), now);
            else if (!a.owner.needsRecovery() && !uart.needsRecovery()) {
                switch (record.kind) {
                case App::OperationKind::HOME: {
                    ESS::PreparedHome work;
                    const auto next = ESS::nextHome(record.home, now, work);
                    if (!next) advanceOperation(record, actionEvent(record, ReadEventKind::DEADLINE), now);
                    else if (work.kind == ESS::ActionWork::TRANSACTION) {
                        const auto admitted = admitHomeStep(a, record, work, now);
                        if (admitted != Probe::Action::OK && admitted != Probe::Action::QUEUE_FULL &&
                            admitted != Probe::Action::RESULTS_FULL && admitted != Probe::Action::RECOVERY_REQUIRED)
                            advanceOperation(record, actionEvent(record, ReadEventKind::TRANSPORT_FAILURE), now);
                    }
                    break;
                }
                case App::OperationKind::MOVE: {
                    ESS::PreparedMove work;
                    const auto next = ESS::nextMove(record.move, now, work);
                    if (!next && next.detail == static_cast<int32_t>(MotorControlRS::MoveError::READINESS))
                        advanceOperation(record, actionEvent(record, ReadEventKind::DEADLINE), now);
                    // The group admits its members' observation polls, oldest eligible first.
                    else if (record.groupChild && record.move.step > record.move.triggerStep) {}
                    else if (next && work.kind == ESS::ActionWork::TRANSACTION) {
                        const auto admitted = admitMoveStep(a, record, work, now);
                        if (admitted == Probe::Action::OK) record.interruptWaiting = false;
                    }
                    break;
                }
                case App::OperationKind::DRIVER: {
                    ESS::PreparedDriver work;
                    const auto next = ESS::nextDriver(record.driver, now, work);
                    if (!next) advanceOperation(record, actionEvent(record, ReadEventKind::DEADLINE), now);
                    else if (work.kind == ESS::ActionWork::TRANSACTION)
                        admitDriverStep(a, record, work, now);
                    break;
                }
                case App::OperationKind::ACTION: {
                    ESS::PreparedAction work;
                    if (ESS::nextAction(record.action, now, work) && work.kind == ESS::ActionWork::TRANSACTION)
                        admitActionStep(a, record, work, now); // Pressure defers unadmitted work, never replays a frame.
                    break;
                }
                case App::OperationKind::EMPTY: case App::OperationKind::TRANSACTION:
                case App::OperationKind::TYPED_READ: case App::OperationKind::VELOCITY: break;
                }
            }
        }
        updateActionReservation(a, record);
    }
}
// One path for explicit recovery and the recovery a held stop starts. A delivered
// terminal result is released by the next attempt. An automatic attempt moves an
// undelivered result aside so output pressure cannot delay a stop.
Probe::Action startRecovery(App& a, uint32_t commandId, bool automatic, uint32_t& operationId) {
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (!a.nextOperationId) return Probe::Action::IDS_EXHAUSTED;
    if (a.bindingGeneration == UINT32_MAX) return Probe::Action::IDS_EXHAUSTED;
    if (!automatic && a.recoveryDisplaced.operationId && !a.recoveryDisplaced.delivered) return Probe::Action::RESULTS_FULL;
    if (a.recovery.operationId) {
        const auto* finished = a.owner.recoveryResult(a.recovery.id);
        if (!finished || (!a.recovery.delivered && !automatic)) return Probe::Action::RESULTS_FULL;
        for (auto& record : a.records)
            if (record.stopRecoveryId == a.recovery.id) record.stopRecoveryResult = *finished;
        if (!a.recovery.delivered) {
            a.recovery.retained = *finished;
            a.recoveryDisplaced = a.recovery;
        }
        a.owner.releaseRecovery(a.recovery.id);
        a.recovery = App::Recovery();
    }
    const uint64_t now = uart.sample(); uint64_t id = 0;
    for (auto& record : a.records)
        if (!terminal(a, record)) holdStop(a, record, now);
    if (a.owner.recover(now, now + RECOVERY_BUDGET_US, id) != Rtu::RecoveryAdmission::ACCEPTED) return Probe::Action::FAILED;
    // Recovery invalidates the scan's saved generation, including work that
    // has not reached the owner yet. Settle any admitted query and restore the
    // original tuple, but never resume old candidates after recovery.
    if (a.discovery.owned) a.discovery.cancelRequested = true;
    a.commissioningConfirmedGeneration = 0; // Recovery requires a new explicit candidate observation.
    a.persistenceConfirmedGeneration = 0;
    a.persistenceBaselineKnown = false;
    ++a.bindingGeneration;
    invalidateAxis(a);
    invalidateGroupFacts(a, now);
    a.monitorState.settings.enabled = false; a.monitorState.remaining = 0;
    for (auto& record : a.records) if (record.operationId && record.kind == App::OperationKind::TYPED_READ &&
        record.read.state == ReadState::ACTIVE && !record.requestId.owner)
        ESS::advanceRead(record.read, readEvent(record, ReadEventKind::CANCEL), now);
    for (auto& record : a.records) if (sequenced(record) && !terminal(a, record) && !record.stopHeld) {
        record.cancelContinuation = true;
        if (!record.requestId.owner) {
            advanceOperation(record, actionEvent(record, ReadEventKind::CANCEL), now);
            updateActionReservation(a, record);
        }
    }
    a.recovery.serialTuple = a.serial.active; a.recovery.serialGeneration = a.serial.generation;
    a.recovery.id = id; a.recovery.commandId = commandId; a.recovery.operationId = a.nextOperationId++;
    a.recovery.deadlineUs = now + RECOVERY_BUDGET_US;
    a.recovery.automatic = a.recovery.delivered = automatic;
    a.recoveryGuardUntilUs = std::max(a.recoveryGuardUntilUs, now + RECOVER_US);
    operationId = a.recovery.operationId;
    // Attach at admission, even if recovery finishes before the next service.
    // A later explicit recovery cannot extend an old stop's one-attempt budget.
    for (auto& record : a.records) if (record.stopHeld) {
        if (record.stopRecoveryId) {
            endHeldStop(record, record.cancelContinuation ? ReadEventKind::CANCEL :
                now >= record.deadlineUs ? ReadEventKind::DEADLINE : ReadEventKind::TRANSPORT_FAILURE, -2, now);
            updateActionReservation(a, record);
        } else {
            record.stopRecoveryId = id;
            record.stopRecoveryOperationId = operationId;
        }
    }
    if (!automatic) a.latestOperationId = operationId;
    return Probe::Action::OK;
}
Probe::Action recover(void* context, uint32_t commandId, uint32_t& operationId) {
    return startRecovery(*static_cast<App*>(context), commandId, false, operationId);
}
#include "SimpleMotionApp.h"
#include "PositionStageApp.h"
#include "GroupApp.h"

bool lookup(void* context, uint32_t operationId, Probe::ResultView& out) {
    App& a = *static_cast<App*>(context); if (!operationId) operationId = a.latestOperationId;
    if (const auto* group = groupOperation(a, operationId)) {
        out = Probe::ResultView();
        out.operationId = operationId; out.commandId = group->result.commandId;
        out.serialTuple = group->serialTuple; out.serialGeneration = group->serialGeneration;
        out.group = &group->result; out.pending = group->result.pending; return true;
    }
    if (operationId && operationId == a.simple.view.operationId) {
        out = Probe::ResultView(); out.operationId = operationId;
        out.commandId = a.simple.view.commandId; out.address = a.simple.view.address;
        out.pending = a.simple.view.pending; out.simpleMotion = &a.simple.view; return true;
    }
    if (operationId && operationId == a.recovery.operationId) {
        out = Probe::ResultView();
        out.operationId = operationId; out.commandId = a.recovery.commandId;
        out.serialTuple = a.recovery.serialTuple; out.serialGeneration = a.recovery.serialGeneration; out.recovery = true;
        const auto* result = a.owner.recoveryResult(a.recovery.id);
        out.pending = !result; if (result) out.recoveryResult = *result; return true;
    }
    if (operationId && operationId == a.recoveryDisplaced.operationId) {
        out = Probe::ResultView();
        out.operationId = operationId; out.commandId = a.recoveryDisplaced.commandId;
        out.serialTuple = a.recoveryDisplaced.serialTuple; out.serialGeneration = a.recoveryDisplaced.serialGeneration;
        out.recovery = true; out.recoveryResult = a.recoveryDisplaced.retained; return true;
    }
    const auto* record = findRecord(a, operationId); if (!record || record->monitored) return false;
    out = Probe::ResultView();
    out.serialTuple = record->serialTuple; out.serialGeneration = record->serialGeneration;
    out.commandId = record->commandId; out.operationId = operationId; out.address = record->address;
    out.captureRead = record->captureRead;
    out.stopRecoveryOperationId = record->stopRecoveryOperationId;
    if (record->stopRecoveryResult.id) out.stopRecovery = &record->stopRecoveryResult;
    if (record->stopBeforeRecoveryKnown) out.stopBeforeRecovery = &record->stopBeforeRecovery;
    switch (record->kind) {
    case App::OperationKind::EMPTY: return false;
    case App::OperationKind::TRANSACTION: break;
    case App::OperationKind::HOME: {
        out.homeContext = &record->home; out.pending = !terminal(a, *record);
        out.interruptedByStop = record->interruptedByStop; return true;
    }
    case App::OperationKind::DRIVER: {
        out.driverContext = &record->driver; out.pending = !terminal(a, *record); return true;
    }
    case App::OperationKind::VELOCITY: {
        out.velocityContext = &record->velocity; out.pending = resultPending(a, *record);
        out.interruptedByStop = record->interruptedByStop; return true;
    }
    case App::OperationKind::MOVE: {
        out.moveContext = &record->move; out.pending = !terminal(a, *record);
        out.moveRelation = record->moveRelation;
        out.interruptedByStop = record->interruptedByStop; return true;
    }
    case App::OperationKind::ACTION: {
        out.actionContext = &record->action; out.pending = resultPending(a, *record);
        out.ordinaryStop = record->action.request.kind == MotorControlRS::ActionKind::STOP && !record->groupChild;
        out.stopEscalation = record->stopEscalation; out.replacedOperationId = record->replacedOperationId;
        out.interruptedByStop = record->interruptedByStop; return true;
    }
    case App::OperationKind::TYPED_READ: {
        out.typedRead = &record->read; out.pending = record->read.state == ReadState::ACTIVE;
        return true;
    }
    }
    const auto* result = a.owner.result(record->requestId); out.pending = !result; if (!result) return true;
    Probe::ProbeResult& p = out.probe;
    p.captureRead = record->captureRead;
    p.transport = result->transport; p.outcome = result->outcome; p.executionUnknown = result->executionUnknown;
    p.cancellation = result->cancellation; p.codecChecked = p.transport.reason == Rtu::Reason::FRAME;
    p.codec = result->validation; p.rx = result->raw; p.rxLength = p.transport.rxLength;
    if (record->broadcastFrame) {
        p.broadcast = true;
        p.broadcastFrame = static_cast<Probe::BroadcastFrame>(record->broadcastFrame - 1);
        p.silenceUs = BROADCAST_WINDOW_US;
        p.txLength = sizeof(BROADCAST_FRAMES[0]);
        std::memcpy(a.viewTx, BROADCAST_FRAMES[record->broadcastFrame - 1], p.txLength);
    } else
    p.txLength = record->captureRead ? MotorControlRS::ESS_RS::buildReadRegisters(record->address,
        Probe::CAPTURE_FIRST, Probe::CAPTURE_WORDS, a.viewTx, sizeof(a.viewTx)) :
        MotorControlRS::ESS_RS::buildProbe(record->address, a.viewTx, sizeof(a.viewTx));
    p.tx = a.viewTx;
    if (p.codecChecked) {
        if (record->captureRead) {
            uint16_t words[Probe::CAPTURE_WORDS]; std::size_t count = 0;
            MotorControlRS::ESS_RS::parseRegisters(p.rx, p.rxLength, record->address,
                Probe::CAPTURE_WORDS, words, Probe::CAPTURE_WORDS, count, &p.frameError);
        } else MotorControlRS::ESS_RS::parseProbe(p.rx, p.rxLength, record->address, p.rawModel, &p.frameError);
    }
    p.timingValid = p.transport.closureQualified;
    p.txEndUs = p.transport.txEndUs; p.txUncertaintyUs = p.transport.txUncertaintyUs;
    p.firstRxStartUs = p.transport.firstRxStartUs; p.maxRxUncertaintyUs = p.transport.maxRxUncertaintyUs;
    p.observedEarliestUs = p.transport.closureEarliestUs; p.observedLatestUs = p.transport.closureLatestUs;
    p.deliveredUs = record->deliveredUs; return true;
}
Probe::Action cancel(void* context, uint32_t operationId) {
    App& a = *static_cast<App*>(context);
    if ((!operationId && a.discovery.owned) || (operationId && operationId == a.discovery.operationId)) {
        if (!a.discovery.owned || a.discovery.phase == Probe::DiscoveryPhase::INTERLOCK)
            return Probe::Action::ALREADY_TERMINAL;
        a.discovery.cancelRequested = true;
        if (a.discoveryRequest.owner) a.owner.cancelUnsent(a.discoveryRequest, nowUs());
        return Probe::Action::OK;
    }
    if (!operationId) operationId = a.latestOperationId;
    if (operationId && operationId == a.simple.view.operationId) {
        if (!a.simple.view.pending) return Probe::Action::ALREADY_TERMINAL;
        cancelSimplePreparation(a, a.simple.view.address, nowUs());
        a.simple.view.interruptedByStop = false;
        if (!a.simple.view.moveOperationId) return Probe::Action::OK;
        operationId = a.simple.view.moveOperationId;
    }
    auto* record = findRecord(a, operationId); if (!record) return Probe::Action::INVALID;
    if (sequenced(*record)) {
        if (terminal(a, *record)) return Probe::Action::ALREADY_TERMINAL;
        if (record->moveRelation.originalOperationId == operationId) {
            auto* replacement = findRecord(a, record->moveRelation.replacementOperationId);
            if (replacement && !terminal(a, *replacement)) {
                replacement->cancelContinuation = true;
                if (replacement->requestId.owner) a.owner.cancelUnsent(replacement->requestId, nowUs());
            }
        }
        record->cancelContinuation = true;
        if (record->kind == App::OperationKind::HOME) ESS::revokeHome(record->home);
        // Local cancellation ends unsent work only. An in-flight frame settles
        // naturally, so cancelling never interlocks the bus before a later stop.
        if (record->requestId.owner) a.owner.cancelUnsent(record->requestId, uart.sample());
        else {
            advanceOperation(*record, actionEvent(*record, ReadEventKind::CANCEL), nowUs());
            updateActionReservation(a, *record);
        }
        return Probe::Action::OK;
    }
    if (record->kind == App::OperationKind::TYPED_READ && record->read.state != ReadState::ACTIVE) return Probe::Action::ALREADY_TERMINAL;
    if (record->kind == App::OperationKind::TYPED_READ && !record->requestId.owner) {
        ESS::advanceRead(record->read, readEvent(*record, ReadEventKind::CANCEL), nowUs());
        return Probe::Action::OK;
    }
    if (record->kind == App::OperationKind::TYPED_READ) {
        record->cancelContinuation = true;
        a.owner.cancelUnsent(record->requestId, uart.sample());
        return Probe::Action::OK;
    }
    if (record->kind == App::OperationKind::TRANSACTION && !record->broadcastFrame) {
        if (terminal(a, *record)) return Probe::Action::ALREADY_TERMINAL;
        record->cancelContinuation = true;
        a.owner.cancelUnsent(record->requestId, uart.sample());
        return Probe::Action::OK;
    }
    const auto result = a.owner.cancel(record->requestId, uart.sample());
    return result == Rtu::Cancel::CANCELLED ? Probe::Action::OK :
        result == Rtu::Cancel::ALREADY_TERMINAL ? Probe::Action::ALREADY_TERMINAL : Probe::Action::INVALID;
}
Probe::Action release(void* context, uint32_t operationId) {
    App& a = *static_cast<App*>(context);
    if (auto* group = groupOperation(a, operationId)) return releaseGroup(a, *group);
    if (operationId && (operationId == a.simple.view.operationId || operationId == a.simple.view.moveOperationId ||
        operationId == a.simple.view.driverOperationId))
        return releaseSimpleMotion(a);
    if (operationId && operationId == a.simple.view.readOperationId)
        return Probe::Action::BUSY;
    if (operationId && operationId == a.recovery.operationId) {
        if (!a.recovery.delivered || !a.owner.releaseRecovery(a.recovery.id)) return Probe::Action::BUSY;
        a.recovery = App::Recovery(); return Probe::Action::OK;
    }
    if (operationId && operationId == a.recoveryDisplaced.operationId) {
        if (!a.recoveryDisplaced.delivered) return Probe::Action::BUSY;
        a.recoveryDisplaced = App::Recovery(); return Probe::Action::OK;
    }
    auto* record = findRecord(a, operationId); if (!record) return Probe::Action::INVALID;
    const uint32_t peerId = record->moveRelation.originalOperationId == operationId ?
        record->moveRelation.replacementOperationId : record->moveRelation.originalOperationId;
    const auto* peer = findRecord(a, peerId);
    if (peer && !terminal(a, *peer)) return Probe::Action::BUSY;
    if (resultPending(a, *record) || !record->delivered ||
        (record->requestId.owner && !a.owner.release(record->requestId))) return Probe::Action::BUSY;
    clearRecord(*record); return Probe::Action::OK;
}
Probe::Action monitor(void* context, const Probe::MonitorSettings* requested, Probe::MonitorSnapshot& out) {
    App& a = *static_cast<App*>(context);
    // Cached inspection and local cancellation remain available when the host
    // cannot admit traffic. Neither operation depends on UART readiness.
    if (!requested) { out = a.monitorState; return Probe::Action::OK; }
    if (!requested->enabled) {
        a.monitorState.settings.enabled = false; a.monitorState.remaining = 0;
        auto& record = a.records[REQUEST_CAPACITY];
        if (record.operationId && record.read.state == ReadState::ACTIVE && !record.cancelContinuation) {
            cancel(&a, record.operationId); ++a.monitorState.cancelled;
        }
        out = a.monitorState; return Probe::Action::OK;
    }
    if (a.owner.commissioningOwned() || a.discovery.owned) return Probe::Action::BUSY;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.blocked || a.serial.configuring || a.owner.configurationOwned()) return Probe::Action::RECOVERY_REQUIRED;
    if (requested->intervalMs < 100 || requested->intervalMs > 60000 || !requested->count || requested->count > 1000)
        return Probe::Action::INVALID;
    if (a.monitorState.settings.enabled || a.records[REQUEST_CAPACITY].operationId || groupSequencing(a)) return Probe::Action::BUSY;
    if (a.owner.needsRecovery() || uart.needsRecovery()) return Probe::Action::RECOVERY_REQUIRED;
    a.monitorState = Probe::MonitorSnapshot(); a.monitorState.settings = *requested;
    a.monitorState.remaining = requested->count; a.monitorState.nextDueUs = nowUs();
    out = a.monitorState; return Probe::Action::OK;
}
/** One opt-in finite consumer. Its ordinary admissions use the same owner queue;
 * urgent work retains its reserved priority. No catch-up burst or automatic
 * recovery occurs. Each rejected admission consumes one finite attempt. */
void serviceMonitor(App& a, uint64_t sampled) {
    if (!a.monitorState.settings.enabled || a.records[REQUEST_CAPACITY].operationId ||
        sampled < a.monitorState.nextDueUs) return;
    if (!a.monitorState.remaining || a.owner.needsRecovery() || uart.needsRecovery()) {
        a.monitorState.settings.enabled = false; return;
    }
    --a.monitorState.remaining;
    a.monitorState.nextDueUs = sampled + uint64_t(a.monitorState.settings.intervalMs) * 1000;
    uint32_t operation = 0;
    const auto result = startTypedRead(&a, 0, a.axis.target.address, ESS::ReadKind::STATE, operation, true);
    if (result == Probe::Action::OK) {
        ++a.monitorState.admitted; a.monitorState.operationId = operation;
    } else {
        ++a.monitorState.rejected;
        if (!a.monitorState.remaining) a.monitorState.settings.enabled = false;
    }
}
void reset(void* context) {
    static_cast<App*>(context)->runner.clearStats();
#if MOTORCONTROLRS_LOAD_FIXTURE
    loadFixture.resetStats(uart);
#else
    uart.resetStats();
#endif
}
#if MOTORCONTROLRS_LOAD_FIXTURE
Probe::Action load(void* context, const Probe::LoadSettings* requested, Probe::LoadSnapshot& out) {
    App& a = *static_cast<App*>(context);
    if (!fixtureReady) return Probe::Action::UNAVAILABLE;
    if (requested && (a.discovery.owned || a.owner.active() || a.owner.pending() || a.owner.recovering() || reading(a) || acting(a) || a.runner.transmitEnabled())) return Probe::Action::BUSY;
    const auto result = loadFixture.configure(requested, out, uart); out.ready = platformReady;
    if (requested) nextServiceUs = 0;
    return result;
}
#endif
void invalidateTargetKnowledge(App& a, uint64_t now) {
    std::memset(a.knownTargets, 0, sizeof(a.knownTargets));
    a.identity.operationId = a.configuration.operationId = 0;
    a.driverSettings.operationId = a.ioSettings.operationId = a.controlSettings.operationId = a.segmentSettings.operationId = 0;
    for (auto& cache : a.tuningSettings) cache.operationId = 0;
    for (auto& block : a.stateCache.blocks) block.invalidatedUs = now;
    invalidateGroupFacts(a, now);
    a.driverInputsQualified = false;
    a.movePrerequisites.readinessQualified = false;
    a.velocityPrerequisites.readinessQualified = false;
    a.homePrerequisites.readinessQualified = false;
}
void invalidateSerialConfidence(App& a, uint64_t now) {
    a.known = a.ok = a.modelKnown = a.communicationKnown = false;
    a.codecChecked = false;
    invalidateTargetKnowledge(a, now);
    // Endpoint/configuration generations and physical uncertainty do not belong
    // to a temporary UART selection. Historical records and host origins survive.
}
// A broadcast may change every drive outside per-target tracking. Treat it as
// an uncertain write to each: drop cached observations, configuration and
// readiness, and expire prepared work and current-position evidence, as the
// profile restoration path does. Fresh checked reads are required afterwards.
void invalidateAfterBroadcast(App& a, uint64_t now) {
    invalidateTargetKnowledge(a, now);
    a.axis.generation = !a.axis.generation || a.axis.generation == UINT32_MAX ? 0 : a.axis.generation + 1;
    a.coordinateReference = MotorControlRS::AxisReference();
    a.simpleEndpointKnown = false; a.motionObservationPending = true;
    a.movePrerequisites = ESS::MovePrerequisites(); a.velocityPrerequisites = ESS::VelocityPrerequisites();
    a.homePrerequisites = ESS::HomePrerequisites(); a.positionClearQualification = PositionClearQualification();
    a.rememberedMoveGeneration = 0;
}
Probe::Action selectTarget(void* context, uint8_t address) {
    using namespace MotorControlRS;
    App& a = *static_cast<App*>(context);
    if (!ESS::isValidAddress(address)) return Probe::Action::INVALID;
    if (a.axis.target.address == address) return Probe::Action::OK;
    if (a.serial.configuring || a.owner.configurationOwned() || a.owner.commissioningOwned() ||
        a.discovery.owned || a.owner.active() || a.owner.pending() || a.owner.recovering() ||
        a.runner.busy() || a.runner.transmitEnabled() || reading(a) || acting(a) ||
        a.monitorState.settings.enabled || a.persistenceCapture || a.persistenceRequest.owner ||
        a.persistenceReadRequest.owner || a.commissioningRequest.owner || a.motionProfile.view.pending ||
        a.motionProfile.view.restoreUnsettled || groupSequencing(a))
        return Probe::Action::BUSY;
    if (!a.axis.generation || a.axis.generation == UINT32_MAX || a.bindingGeneration == UINT32_MAX)
        return Probe::Action::IDS_EXHAUSTED;
    AxisConfig candidate;
    candidate.generation = a.axis.generation + 1;
    candidate.target.id = candidate.target.address = address;
    candidate.target.generation = a.bindingGeneration + 1;
    candidate.supportedRelativeBases = 1; // Reviewed ESS actual-position relative basis.
    candidate.units.settings = a.axis.units.settings;
    ++a.bindingGeneration;
    a.axis = candidate;
    // Command scale belongs to the selected axis. Generic desired speed/ramp
    // settings may be reused, but a new target needs its own explicit scale.
    a.simple.desired.scaleKnown = false;
    a.simple.desired.stepsPerTurn = Rational();
    a.coordinateReference = AxisReference();
    a.commandPolarityKnown = true;
    a.positionClearQualification = PositionClearQualification();
    a.movePrerequisites = ESS::MovePrerequisites();
    a.velocityPrerequisites = ESS::VelocityPrerequisites();
    a.homePrerequisites = ESS::HomePrerequisites();
    a.commissioningConfirmedGeneration = a.persistenceConfirmedGeneration = 0;
    a.persistenceBaselineKnown = false;
    for (auto& wiring : a.inputWiring) wiring = InputWiring::UNKNOWN;
    for (auto& wiring : a.outputWiring) wiring = InputWiring::UNKNOWN;
    invalidateSerialConfidence(a, nowUs());
    // Historical contexts and physical uncertainty belong to their original
    // endpoint. Rebinding creates no traffic and does not release either.
    return Probe::Action::OK;
}
Probe::Action wiring(void* context, const Probe::WiringRequest* requested, Probe::WiringSnapshot& out) {
    using MotorControlRS::InputWiring;
    App& a = *static_cast<App*>(context);
    out.target = a.axis.target; out.configurationGeneration = a.axis.generation;
    std::memcpy(out.inputs, a.inputWiring, sizeof(out.inputs));
    std::memcpy(out.outputs, a.outputWiring, sizeof(out.outputs));
    if (!requested) return Probe::Action::OK;
    if (requested->terminal >= 6 || requested->state > InputWiring::CONNECTED) return Probe::Action::INVALID;
    auto& declaration = requested->terminal < 4 ? a.inputWiring[requested->terminal] :
        a.outputWiring[requested->terminal - 4];
    if (declaration == requested->state) return Probe::Action::OK;
    if (a.serial.configuring || a.owner.configurationOwned() || a.owner.commissioningOwned() ||
        a.discovery.owned || a.owner.active() || a.owner.pending() || a.owner.recovering() ||
        a.runner.busy() || a.runner.transmitEnabled() || reading(a) || acting(a) ||
        a.monitorState.settings.enabled || a.persistenceCapture || a.persistenceRequest.owner ||
        a.persistenceReadRequest.owner || a.commissioningRequest.owner || a.motionProfile.view.pending ||
        a.motionProfile.request.owner || groupSequencing(a)) return Probe::Action::BUSY;
    if (!a.axis.generation || a.axis.generation == UINT32_MAX) return Probe::Action::IDS_EXHAUSTED;
    declaration = requested->state;
    invalidateAxis(a);
    a.driverInputsQualified = false; a.positionClearQualification = PositionClearQualification();
    a.movePrerequisites = ESS::MovePrerequisites(); a.velocityPrerequisites = ESS::VelocityPrerequisites();
    a.homePrerequisites = ESS::HomePrerequisites();
    for (auto& block : a.stateCache.blocks) block.invalidatedUs = nowUs();
    // This changes an application declaration only. Drive assignments, binding,
    // stored settings and historical results keep their original evidence.
    out.configurationGeneration = a.axis.generation;
    std::memcpy(out.inputs, a.inputWiring, sizeof(out.inputs));
    std::memcpy(out.outputs, a.outputWiring, sizeof(out.outputs));
    return Probe::Action::OK;
}
bool discoveryStopPending(const App& a) {
    for (std::size_t i = REQUEST_CAPACITY + 1; i < REQUEST_CAPACITY + 1 + URGENT_RECORDS; ++i)
        if (a.records[i].discoveryStop) return true;
    return false;
}
Probe::Action hostSerialImpl(void* context, const Probe::HostRequest* requested, Probe::HostSnapshot& out, bool ownedSession) {
    App& a = *static_cast<App*>(context);
    if (!requested) {
        if (!platformReady) return Probe::Action::UNAVAILABLE;
        out = a.serial; return Probe::Action::OK;
    }
    if ((a.owner.commissioningOwned() || a.discovery.owned) && !ownedSession) return Probe::Action::BUSY;
    const HostTuple tuple = requested->restore ? a.serial.original : requested->tuple;
    HostTiming policy;
    if (!Esp32S3Uart::supports(tuple) || !hostTiming(tuple, policy)) return Probe::Action::UNSUPPORTED;
    if (!platformReady) return Probe::Action::UNAVAILABLE;
    if (a.serial.configuring || a.owner.active() || a.owner.pending() || a.owner.recovering() ||
        a.runner.busy() || a.runner.transmitEnabled() || reading(a) || (acting(a) && !(ownedSession && discoveryStopPending(a))) ||
        a.monitorState.settings.enabled || a.motionProfile.view.pending || a.motionProfile.request.owner || groupSequencing(a))
        return Probe::Action::BUSY;
    if (!a.serial.blocked && (a.owner.needsRecovery() || uart.needsRecovery())) return Probe::Action::RECOVERY_REQUIRED;
    if (!a.serial.blocked && a.serial.activeKnown && sameTuple(tuple, a.serial.active)) {
        out = a.serial; return Probe::Action::OK;
    }
    if (a.serial.generation == UINT32_MAX) return Probe::Action::IDS_EXHAUSTED;
    if (!a.owner.configurationOwned() && !a.owner.beginConfiguration(nowUs())) return Probe::Action::BUSY;
    a.serial.configuring = true;
    a.serial.requested = tuple;
    ++a.serial.generation;
    a.persistenceConfirmedGeneration = 0;
    a.persistenceBaselineKnown = false;
    invalidateSerialConfidence(a, nowUs());
    // A first attempt may have refused captured stale RX before touching UART
    // setup. Explicit repair owns its discard; ordinary recovery cannot reopen
    // the configuration lease, and normal tuple changes never discard silently.
    const bool cleared = !a.serial.blocked || uart.configurationBlocked() || uart.clear();
    const bool configured = cleared && uart.reconfigure(tuple);
    const bool settled = configured && a.owner.finishConfiguration(policy.runner, nowUs());
    a.serial.configuring = false;
    a.serial.blocked = !settled;
    a.serial.activeKnown = settled;
    a.serial.actualBaud = settled ? uart.stats().actualBaud : 0;
    if (settled) {
        a.serial.active = tuple; a.serial.timing = policy;
        a.serial.failure = Probe::HostFailure::NONE;
    } else {
        a.serial.failure = requested->restore ? Probe::HostFailure::RESTORE :
            configured ? Probe::HostFailure::RUNNER : Probe::HostFailure::ADAPTER;
    }
    out = a.serial;
    return settled ? Probe::Action::OK : Probe::Action::FAILED;
}

Probe::Action hostSerial(void* context, const Probe::HostRequest* requested, Probe::HostSnapshot& out) {
    return hostSerialImpl(context, requested, out, false);
}
#include "CommunicationApp.h"
#include "PersistenceApp.h"
#include "DiscoveryApp.h"

Probe::Action debugCommand(void* context, const Probe::DebugMode* requested,
                           Probe::DebugSnapshot& out) {
    return static_cast<App*>(context)->debug.command(requested, out);
}
#include "QualificationApp.h"
Probe::Host host(App* a) {
    Probe::Host h; h.context = a; h.emitLine = emit; h.snapshot = snapshot;
    h.startProbe = probe; h.startCaptureRead = captureRead; h.recover = recover; h.resetStats = reset;
    h.startTypedRead = typedRead;
    h.beginInteractiveWork = recycleInteractiveResults;
    h.startAction = startAction; h.startReleaseAfterStop = startReleaseAfterStop;
    h.startMove = startMove; h.startVelocity = startVelocity; h.startDriver = startDriver; h.startHome = startHome;
    h.inspectHomeQualification = [](void* context, ESS::HomePrerequisites& output, bool& valid) {
        const auto& a = *static_cast<App*>(context);
        if (!a.homePrerequisites.target.id) return false;
        auto checked = a.homePrerequisites;
        valid = homeReadiness(a, checked, nowUs()); output = a.homePrerequisites; return true;
    };
    h.inspectPositionClearQualification = [](void*, PositionClearQualification& output, bool& valid) {
        return inspectPositionClearQualification(output, valid);
    };
    h.qualification = qualificationCommand;
    h.startPositionInterrupt = startPositionInterrupt;
    h.simpleMotion = simpleMotion;
    h.monitor = monitor; h.motionProfile = motionProfileCommand; h.debug = debugCommand;
    h.axis = axisCommand; h.hostSerial = hostSerial; h.selectTarget = selectTarget;
    h.wiring = wiring;
    h.communication = communication; h.persistence = persistence;
    h.discovery = discoveryCommand;
    h.group = groupCommand;
    h.result = lookup; h.cancel = cancel; h.release = release;
#if MOTORCONTROLRS_LOAD_FIXTURE
    h.load = load;
    h.broadcast = broadcast;
#endif
    return h;
}
// Both delivered to the person, and a later checked stop has settled the motion.
// The original reads failed and uncertain only because this replacement took over
// its observation; any other failure or uncertainty keeps both until explicit release.
bool settledInterruptPair(const App::Record& replacement, const App::Record& original) {
    using namespace MotorControlRS;
    const auto delivered = [](const App::Record& r) {
        return r.kind == App::OperationKind::MOVE && r.interactive && r.delivered && !r.programmaticMove && !r.simpleChild &&
            !r.axisReserved && !r.motionUnresolved && !r.interruptedByStop;
    };
    return delivered(replacement) && delivered(original) &&
        replacement.moveRelation.observationSuperseded && original.moveRelation.observationSuperseded &&
        original.moveRelation.replacementOperationId == replacement.operationId &&
        replacement.move.state == ActionState::SUCCEEDED && !replacement.move.uncertain &&
        replacement.move.outcome == ActionOutcome::ACKNOWLEDGED && replacement.move.execution == ActionExecution::ACKNOWLEDGED &&
        original.move.outcome == ActionOutcome::CANCELLED && original.move.execution == ActionExecution::ACKNOWLEDGED &&
        original.move.setupExecution != ActionExecution::UNKNOWN;
}
void recycleInteractiveResults(void* context) {
    App& a = *static_cast<App*>(context);
    // The terminal text must have left both bounded output queues. Detailed
    // JSON/API results and failures remain explicitly retained.
    if (a.outputCount || a.console.outputPending()) return;
    for (auto& r : a.records) {
        if (r.moveRelation.replacementOperationId == r.operationId && r.operationId) {
            auto* original = findRecord(a, r.moveRelation.originalOperationId);
            if (original && settledInterruptPair(r, *original) &&
                (!r.requestId.owner || a.owner.release(r.requestId)) &&
                (!original->requestId.owner || a.owner.release(original->requestId))) {
                clearRecord(*original); clearRecord(r);
            }
            continue;
        }
        if (!r.interactive || !r.delivered || r.simpleChild || r.programmaticRead || r.programmaticSettings || r.programmaticHome ||
            r.moveRelation.originalOperationId || r.axisReserved || r.motionUnresolved) continue;
        bool success = false;
        switch (r.kind) {
        case App::OperationKind::EMPTY: break;
        case App::OperationKind::HOME: success = r.home.state == MotorControlRS::ActionState::SUCCEEDED && !r.home.uncertain; break;
        case App::OperationKind::DRIVER: success = r.driver.state == ReadState::SUCCEEDED && !r.driver.uncertain; break;
        case App::OperationKind::VELOCITY: success = r.velocity.state == MotorControlRS::ActionState::SUCCEEDED && !r.velocity.uncertain; break;
        case App::OperationKind::MOVE: success = r.move.state == MotorControlRS::ActionState::SUCCEEDED && !r.move.uncertain; break;
        case App::OperationKind::ACTION: success = r.action.state == MotorControlRS::ActionState::SUCCEEDED; break;
        case App::OperationKind::TYPED_READ: success = r.read.state == ReadState::SUCCEEDED; break;
        case App::OperationKind::TRANSACTION: success = a.owner.result(r.requestId) && a.owner.result(r.requestId)->outcome == Rtu::Outcome::SUCCESS; break;
        }
        if (success && (!r.requestId.owner || a.owner.release(r.requestId))) clearRecord(r);
    }
    // A delivered successful human group move pins no further evidence.
    auto& move = a.group.move;
    if (move.result.operationId && move.delivered && move.interactive && move.result.ok)
        releaseGroup(a, move);
}
void deliver(App& a) {
    for (auto& record : a.records) {
        if (!record.operationId || record.delivered || record.groupChild || record.programmaticAction) continue;
        if (record.monitored) {
            if (!terminal(a, record)) continue;
            // This explicit consumer already harvested each non-consuming block.
            // It owns release and never uses a user command correlation/retention.
            if (record.requestId.owner && !a.owner.release(record.requestId)) continue;
            clearRecord(record); a.monitorState.operationId = 0;
            if (!a.monitorState.remaining) a.monitorState.settings.enabled = false;
            continue;
        }
        Probe::ResultView view; if (!lookup(&a, record.operationId, view) || view.pending) continue;
        record.interactive = a.console.humanResult(record.operationId);
        switch (record.kind) {
        case App::OperationKind::EMPTY: continue;
        case App::OperationKind::TRANSACTION: break;
        case App::OperationKind::HOME: {
            if (!record.programmaticHome && !a.console.reportHome(record.commandId, record.operationId, record.home, record.interruptedByStop, &record.serialTuple, record.serialGeneration)) continue;
            record.delivered = true; record.deliveredUs = nowUs(); continue;
        }
        case App::OperationKind::DRIVER: {
            if (!record.simpleChild && !record.programmaticSettings && !a.console.reportDriver(record.commandId, record.operationId, record.driver, &record.serialTuple, record.serialGeneration)) continue;
            record.delivered = true; record.deliveredUs = nowUs(); continue;
        }
        case App::OperationKind::VELOCITY: {
            if (!a.console.reportVelocity(record.commandId, record.operationId, record.velocity, record.interruptedByStop, &record.serialTuple, record.serialGeneration)) continue;
            record.delivered = true; record.deliveredUs = nowUs(); continue;
        }
        case App::OperationKind::MOVE: {
            if (record.programmaticMove || record.simpleChild) {
                record.delivered = true; record.deliveredUs = nowUs(); continue;
            }
            if (!a.console.reportMove(record.commandId, record.operationId, record.move, record.interruptedByStop,
                &record.serialTuple, record.serialGeneration, record.moveRelation)) continue;
            record.delivered = true; record.deliveredUs = nowUs(); continue;
        }
        case App::OperationKind::ACTION: {
            if (!a.console.reportAction(record.commandId, record.operationId, record.action, record.interruptedByStop, &record.serialTuple, record.serialGeneration)) continue;
            record.delivered = true; record.deliveredUs = nowUs(); continue;
        }
        case App::OperationKind::TYPED_READ: {
            if (!record.observed && record.serialGeneration == a.serial.generation &&
                record.read.target.generation == a.bindingGeneration) {
                record.observed = true;
                if (record.read.kind == ESS::ReadKind::IDENTITY && record.operationId > a.identity.operationId)
                    ESS::getIdentity(record.read, a.identity);
                if (record.read.kind == ESS::ReadKind::CONFIG && record.address == a.axis.target.address &&
                    record.operationId > a.configuration.operationId &&
                    record.operationId > a.driverSettings.operationId && record.operationId > a.ioSettings.operationId &&
                    record.operationId > a.controlSettings.operationId &&
                    record.configurationGeneration == a.axis.generation && record.read.target.generation == a.bindingGeneration) {
                    const ESS::RawConfig old = a.configuration.raw;
                    const bool currentConfig = a.configuration.operationId != 0;
                    const bool same = a.configuration.target.id && Probe::sameTarget(a.configuration.target, record.read.target);
                    if (ESS::getConfig(record.read, a.configuration)) {
                        const auto& updated = a.configuration.raw;
                        const bool inputsChanged = !same || old.inputPolarity != updated.inputPolarity ||
                            std::memcmp(old.inputFunctions, updated.inputFunctions, sizeof(old.inputFunctions)) != 0;
                        if (inputsChanged) a.driverInputsQualified = false;
                        uint32_t effects = 0;
                        if (a.driverSettings.target.id && (a.driverSettings.operationId || !currentConfig) &&
                            Probe::sameTarget(a.driverSettings.target, record.read.target))
                            effects = driverConfigEffects(updated, a.driverSettings);
                        if (a.controlSettings.target.id && (a.controlSettings.operationId || !currentConfig) &&
                            Probe::sameTarget(a.controlSettings.target, record.read.target))
                            effects |= controlConfigEffects(updated, a.controlSettings);
                        if (same && old.algorithm != updated.algorithm) effects |= static_cast<uint32_t>(ESS::DriverField::CONTROL_ALGORITHM);
                        if (same && old.encoderResolution != updated.encoderResolution) effects |= static_cast<uint32_t>(ESS::DriverField::CONFIGURED_ENCODER);
                        if (a.ioSettings.target.id && (a.ioSettings.operationId || !currentConfig) &&
                            Probe::sameTarget(a.ioSettings.target, record.read.target)) {
                            if (updated.inputPolarity != a.ioSettings.raw[7]) effects |= static_cast<uint32_t>(ESS::DriverField::INPUT_POLARITY);
                            for (uint8_t i = 0; i < 4; ++i)
                                if (updated.inputFunctions[i] != a.ioSettings.raw[8+i]) effects |= uint32_t(1) << (10+i);
                        }
                        const bool configChanged = same &&
                            (old.direction != updated.direction || old.subdivision != updated.subdivision ||
                             old.wordOrder != updated.wordOrder || old.algorithm != updated.algorithm ||
                             old.encoderResolution != updated.encoderResolution ||
                             old.inputPolarity != updated.inputPolarity || old.overLimitStop != updated.overLimitStop ||
                             old.softLimitEnable != updated.softLimitEnable ||
                             std::memcmp(old.inputFunctions, updated.inputFunctions, sizeof(old.inputFunctions)) != 0);
                        if (same && old.direction != updated.direction) effects |= static_cast<uint16_t>(ESS::DriverField::DIRECTION);
                        if (same && old.subdivision != updated.subdivision) effects |= static_cast<uint16_t>(ESS::DriverField::SUBDIVISION);
                        if (!record.effectsInvalidated && (effects || configChanged)) {
                            invalidateDriverAssumptions(a, record.address, effects, nowUs());
                            // These are the newly checked stored codes, not an older cache.
                            a.configuration.operationId = record.operationId;
                        }
                    }
                }
            }
            if (!record.simpleChild && !record.programmaticRead &&
                !a.console.reportRead(record.commandId, record.operationId, record.read, &record.serialTuple, record.serialGeneration)) continue;
            record.delivered = true; record.deliveredUs = nowUs(); continue;
        }
        }
        const auto* retained = a.owner.result(record.requestId);
        if (!record.observed && record.broadcastFrame && retained) {
            record.observed = true;
            if (retained->transport.txAccepted) invalidateAfterBroadcast(a, nowUs());
        }
        if (!record.observed && !record.captureRead && record.serialGeneration == a.serial.generation &&
            retained && retained->expected.targetGeneration == a.bindingGeneration) {
            record.observed = true;
            if (view.probe.transport.txAccepted && record.operationId > a.cacheOperationId) {
                a.cacheOperationId = record.operationId; a.known = true; a.address = record.address;
                a.codecChecked = view.probe.codecChecked; a.codec = view.probe.codec; a.frameError = view.probe.frameError;
                a.ok = view.probe.outcome == Rtu::Outcome::SUCCESS;
            }
            if (view.probe.outcome == Rtu::Outcome::SUCCESS && record.operationId > a.modelOperationId) {
                a.modelKnown = true; a.model = view.probe.rawModel; a.modelAddress = record.address;
                a.modelOperationId = record.operationId; a.deliveredUs = record.deliveredUs;
                a.observedEarliestUs = view.probe.timingValid ? view.probe.observedEarliestUs : 0;
                a.observedLatestUs = view.probe.timingValid ? view.probe.observedLatestUs : 0;
            }
        }
        if (record.serialGeneration == a.serial.generation)
            if (const auto* completion = a.owner.result(record.requestId)) observeCommunication(a, *completion);
        view.probe.deliveredUs = nowUs();
        // Output pressure must not prevent harvesting later completed observations.
        if (!a.console.reportProbe(record.commandId, record.address, record.operationId, view.probe, &record.serialTuple, record.serialGeneration)) continue;
        record.delivered = true; record.deliveredUs = view.probe.deliveredUs;
        if (a.modelKnown && record.operationId == a.modelOperationId) a.deliveredUs = record.deliveredUs;
    }
    if (a.recovery.operationId && !a.recovery.delivered) {
        const auto* result = a.owner.recoveryResult(a.recovery.id);
        if (result && a.console.reportRecovery(a.recovery.commandId, a.recovery.operationId, *result, &a.recovery.serialTuple, a.recovery.serialGeneration)) {
            a.recovery.delivered = true;
        }
    }
    if (a.recoveryDisplaced.operationId && !a.recoveryDisplaced.delivered &&
        a.console.reportRecovery(a.recoveryDisplaced.commandId, a.recoveryDisplaced.operationId, a.recoveryDisplaced.retained,
            &a.recoveryDisplaced.serialTuple, a.recoveryDisplaced.serialGeneration))
        a.recoveryDisplaced.delivered = true;
    deliverGroups(a);
}
}
namespace MotorControlRSExample {
bool beginApplication(const Esp32S3Uart::Pins& pins, bool receiverDisabledDuringTransmit, const ApplicationOptions& options) {
    if (app) return false; // Construction and I/O are one explicit startup action.
    RuntimeWitness::begin();
    if (!MotorControlRS::validateUnitConfig(options.positionUnits) ||
        !options.moveTimeoutMs || options.moveTimeoutMs > 30000) return false;
    const bool consoleReady = Platform::beginConsole();
    if (!consoleReady) { Platform::bootFailure("console_init"); return false; }
    // Walk heap metadata only at startup, before real-time capture starts.
    // Runtime memory/free-space queries remain passive and do not scan payloads.
    if (!heap_caps_check_integrity_all(false)) { Platform::bootFailure("heap_integrity"); return false; }
    void* memory = heap_caps_malloc(sizeof(App), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!memory) { Platform::bootFailure("psram_allocation"); return false; }
    writeResponseConfirmed = receiverDisabledDuringTransmit;
    platformReady = uart.begin(pins, BAUD);
    const char* failure = platformReady ? nullptr : "uart_init";
#if MOTORCONTROLRS_TIMER_CAPTURE
    if (platformReady && !uart.startCapture(20, timing().holdUs)) {
        platformReady = false; failure = "capture_init";
    }
#endif
#if MOTORCONTROLRS_LOAD_FIXTURE
    fixtureReady = loadFixture.begin();
    if (!fixtureReady) { platformReady = false; failure = "load_init"; }
#endif
    app = new (memory) App(options);
    if (!OwnerWatchdog::begin()) { platformReady = false; failure = "owner_watchdog"; }
    app->runner.setTrafficCapture(&app->debug.capture);
    app->console.welcome();
    if (failure) Platform::bootFailure(failure);
    return platformReady;
}
MotorControlRS::Status submitMove(const MotorControlRS::PositionRequest& position, uint16_t speedRpm,
                            uint32_t& operationId, MotorControlRS::MoveSetup setup) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    MoveRequest request; request.position = position;
    request.speedRpm = speedRpm; request.ramp = MoveRamp::VERIFIED_CONFIGURED;
    request.setup = setup;
    const auto admitted = startMove(app, 0, app->axis.target.address, request, operationId);
    if (admitted != Probe::Action::OK)
        return Status(admitted == Probe::Action::UNSUPPORTED ? Err::UNSUPPORTED : Err::INVALID_CONFIG,
            static_cast<int32_t>(admitted), admitted == Probe::Action::REFERENCE_NOT_READY ?
                "move reference not ready; settle monitoring and refresh stationary reference" :
                "move not admitted; inspect readiness, units, limits or owner capacity");
    findRecord(*app, operationId)->programmaticMove = true;
    return Ok();
}
static MotorControlRS::Status moveValue(MotorControlRS::Rational value, MotorControlRS::PositionUnit unit,
                            bool relative, uint32_t& operationId, uint16_t speedRpm, MotorControlRS::MoveSetup setup) {
    using namespace MotorControlRS;
    PositionRequest request = Probe::simplePositionRequest();
    request.value = value; request.unit = unit; request.relative = relative;
    request.frame = unit == PositionUnit::STEPS ? CoordinateFrame::NATIVE :
        unit == PositionUnit::MILLIMETRES ? CoordinateFrame::LOAD : CoordinateFrame::MOTOR;
    request.configurationGeneration = app ? app->axis.generation : 0;
    return submitMove(request, speedRpm, operationId, setup);
}
MotorControlRS::Status moveBy(MotorControlRS::Rational value, MotorControlRS::PositionUnit unit,
                            uint32_t& operationId, uint16_t speedRpm, MotorControlRS::MoveSetup setup) {
    return moveValue(value, unit, true, operationId, speedRpm, setup);
}
MotorControlRS::Status moveTo(MotorControlRS::Rational value, MotorControlRS::PositionUnit unit,
                            uint32_t& operationId, uint16_t speedRpm, MotorControlRS::MoveSetup setup) {
    return moveValue(value, unit, false, operationId, speedRpm, setup);
}
bool moveProgress(uint32_t operationId, MoveProgress& output) {
    if (!app || !operationId) return false;
    const auto* record = findRecord(*app, operationId);
    if (!record || record->kind != App::OperationKind::MOVE || !record->programmaticMove) return false;
    const auto& c = record->move;
    MoveProgress result;
    result.pending = !terminal(*app, *record); result.runningObserved = c.runningObserved;
    result.interruptedByStop = record->interruptedByStop; result.uncertain = c.uncertain;
    result.observationKnown = c.observationKnown; result.rawAlarm = c.rawAlarm; result.rawMotion = c.rawMotion;
    result.outcome = c.outcome; result.execution = c.execution; result.completion = c.completion;
    result.status = c.status; result.effectiveNative = c.prepared.effectiveNative;
    output = result; return true;
}
bool positionConfiguration(MotorControlRS::AxisConfig& output) {
    if (!app) return false;
    output = app->axis; return true;
}
bool releaseMove(uint32_t operationId) {
    if (!app || !operationId) return false;
    const auto* record = findRecord(*app, operationId);
    return record && record->kind == App::OperationKind::MOVE && record->programmaticMove && release(app, operationId) == Probe::Action::OK;
}
MotorControlRS::Status submitPositionInterrupt(uint32_t originalId, const ESS::PositionCommand& command,
        uint32_t bits, bool relative, uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    const auto* original = findRecord(*app, originalId);
    if (!original || original->kind != App::OperationKind::MOVE || !original->programmaticMove)
        return Status(Err::INVALID_CONFIG, 0, "original is not a programmatic move");
    const auto result = admitPositionInterrupt(*app, 0, originalId, command, bits, relative, operationId);
    if (result != Probe::Action::OK)
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(result), "position interruption not admitted");
    findRecord(*app, operationId)->programmaticMove = true;
    return Ok();
}
bool copyMoveResult(uint32_t operationId, ESS::MoveContext& output, MoveRelation& relation) {
    if (!app || !operationId) return false;
    const auto* record = findRecord(*app, operationId);
    if (!record || record->kind != App::OperationKind::MOVE || !record->programmaticMove) return false;
    output = record->move; relation = record->moveRelation; return true;
}
MotorControlRS::Status submitVelocityParameterRead(uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    const auto admitted = typedRead(app, 0, app->axis.target.address, ESS::ReadKind::VELOCITY_PARAMETERS, operationId);
    if (admitted != Probe::Action::OK)
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(admitted), "velocity parameter read not admitted");
    findRecord(*app, operationId)->programmaticRead = true;
    return Ok();
}
MotorControlRS::Status submitHomingParameterRead(uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    const auto admitted = typedRead(app, 0, app->axis.target.address, ESS::ReadKind::HOMING_PARAMETERS, operationId);
    if (admitted != Probe::Action::OK)
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(admitted), "homing parameter read not admitted");
    findRecord(*app, operationId)->programmaticRead = true;
    return Ok();
}
bool copyReadResult(uint32_t operationId, MotorControlRS::ESS_RS::ReadContext& output) {
    if (!app || !operationId) return false;
    const auto* record = findRecord(*app, operationId);
    if (!record || record->kind != App::OperationKind::TYPED_READ || record->monitored) return false;
    output = record->read; return true;
}
MotorControlRS::Status submitPositionStartSpeed(uint32_t native, uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    ESS::DriverRequest request;
    const Status checked = ESS::preparePositionStartSpeed(request, native);
    if (!checked) return checked;
    const auto admitted = startDriver(app, 0, app->axis.target.address, ESS::DriverKind::UPDATE, request, operationId);
    if (admitted != Probe::Action::OK)
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(admitted), "position start-speed setting not admitted");
    findRecord(*app, operationId)->programmaticSettings = true; return Ok();
}
MotorControlRS::Status submitHomingAuxiliary(MotorControlRS::ESS_RS::HomingAuxiliary choice, uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    ESS::DriverRequest request;
    const Status checked = ESS::prepareHomingAuxiliary(request, choice);
    if (!checked) return checked;
    const auto admitted = startDriver(app, 0, app->axis.target.address, ESS::DriverKind::UPDATE, request, operationId);
    if (admitted != Probe::Action::OK)
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(admitted), "homing auxiliary setting not admitted");
    findRecord(*app, operationId)->programmaticSettings = true; return Ok();
}
MotorControlRS::Status installPositionStartSpeedRelation(const PositionStartSpeedRelation& relation) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    App& a = *app;
    if (a.owner.active() || a.owner.pending() || a.owner.recovering() || a.owner.configurationOwned() ||
        a.owner.commissioningOwned() || a.discovery.owned || a.serial.configuring ||
        axisReserved(a) || reading(a) || acting(a))
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(Probe::Action::BUSY), "start-speed qualification requires idle application");
    const uint64_t now = uart.sample();
    const auto& profile = a.motionProfile.view;
    if (!relation.target.id || !Probe::sameTarget(relation.target, a.axis.target) ||
        !a.axis.generation || relation.configurationGeneration != a.axis.generation ||
        relation.rawStartSpeed > 3000 || !relation.minimumPositionSpeedRpm || relation.minimumPositionSpeedRpm > 3000 ||
        relation.qualifiedUs > now || !evidenceAgeValid(relation.qualifiedUs, now, a.observationAgeUs()) ||
        !motionProfileBound(a) || !profile.ok || profile.pending || !profile.closureQualified ||
        !evidenceAgeValid(profile.closureEarliestUs, now, a.observationAgeUs()) ||
        relation.rawStartSpeed != profile.current[0])
        return Status(Err::INVALID_CONFIG, 0, "start-speed relation requires exact current binding, raw word and qualification age");
    a.positionStartSpeedRelation = relation;
    a.positionStartSpeedRelationRequired = true;
    return Ok();
}
MotorControlRS::Status installVelocityQualification(const ESS::VelocityPrerequisites& supplied) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    App& a = *app;
    if (!qualificationIdle(a))
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(Probe::Action::BUSY), "velocity qualification requires idle application");
    const auto& observed = a.velocityParameters;
    if (!supplied.target.id || !Probe::sameTarget(supplied.target, a.axis.target) || !a.axis.generation ||
        supplied.configurationGeneration != a.axis.generation || !supplied.nativeRpmVerified ||
        !supplied.configuredRampVerified || !supplied.serialInputsPermit || !supplied.readinessQualified ||
        !observed.operationId || !Probe::sameTarget(observed.target, a.axis.target) ||
        observed.configurationGeneration != a.axis.generation ||
        supplied.accelerationTime != observed.rawAccelerationTime || supplied.decelerationTime != observed.rawDecelerationTime ||
        supplied.accelerationTime > 2000 || supplied.decelerationTime > 2000)
        return Status(Err::INVALID_CONFIG, 0, "velocity qualification requires stated facts and matching checked velocity parameters");
    a.velocityPrerequisites = supplied;
    return Ok();
}
MotorControlRS::Status revokeVelocityQualification() {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    app->velocityPrerequisites = ESS::VelocityPrerequisites();
    return Ok();
}
MotorControlRS::Status installPositionClearQualification() {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    if (!qualificationIdle(*app))
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(Probe::Action::BUSY), "position-clear qualification requires idle application");
    if (!platformReady || app->owner.needsRecovery() || uart.needsRecovery() ||
        !app->axis.generation || !app->axis.target.id || !app->axis.target.generation ||
        app->axis.target.generation != app->bindingGeneration || !app->configuration.operationId ||
        !Probe::sameTarget(app->configuration.target, app->axis.target))
        return Status(Err::INVALID_CONFIG, 0, "position-clear requires current binding and configuration");
    app->positionClearQualification.target = app->axis.target;
    app->positionClearQualification.configurationGeneration = app->axis.generation;
    app->positionClearQualification.semanticsQualified = true;
    return Ok();
}
bool inspectPositionClearQualification(PositionClearQualification& output, bool& valid) {
    if (!app || !app->positionClearQualification.semanticsQualified) return false;
    valid = positionClearQualificationValid(*app); output = app->positionClearQualification; return true;
}
MotorControlRS::Status revokePositionClearQualification() {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    app->positionClearQualification = PositionClearQualification();
    cancelInvalidPositionClears(*app, nowUs());
    return Ok();
}
bool copySettingsResult(uint32_t operationId, MotorControlRS::ESS_RS::DriverContext& output) {
    if (!app || !operationId) return false;
    const auto* record = findRecord(*app, operationId);
    if (!record || record->kind != App::OperationKind::DRIVER) return false;
    output = record->driver; return true;
}
MotorControlRS::Status installHomeQualification(const ESS::HomePrerequisites& supplied) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    App& a = *app;
    if (a.owner.active() || a.owner.pending() || a.owner.recovering() || a.owner.configurationOwned() ||
        a.owner.commissioningOwned() || a.discovery.owned || a.serial.configuring || a.serial.blocked ||
        axisReserved(a) || reading(a) || acting(a))
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(Probe::Action::BUSY), "home qualification requires idle application");
    auto checked = supplied;
    if (!homeReadiness(a, checked, uart.sample()))
        return Status(Err::INVALID_CONFIG, 0, "home qualification requires exact supplied facts and checked configuration/state/parameters");
    // Retain supplied timestamps/facts exactly; live observations are refreshed
    // only into the immutable admitted copy at submit time.
    a.homePrerequisites = supplied;
    return Ok();
}
bool inspectHomeQualification(ESS::HomePrerequisites& output, bool& valid) {
    if (!app || !app->homePrerequisites.target.id) return false;
    auto checked = app->homePrerequisites;
    valid = homeReadiness(*app, checked, nowUs());
    output = app->homePrerequisites; return true;
}
MotorControlRS::Status revokeHomeQualification() {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    app->homePrerequisites = ESS::HomePrerequisites();
    revokeActiveHomes(*app, uart.sample());
    // Historical completed contexts remain immutable; a retained current
    // reference is no longer usable after its external qualification is revoked.
    app->coordinateReference.nativeKnown = false;
    return Ok();
}
MotorControlRS::Status submitHome(const ESS::HomeRequest& request, uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    const auto result = startHome(app, 0, app->axis.target.address, request, operationId);
    if (result != Probe::Action::OK)
        return Status(Err::INVALID_CONFIG, static_cast<int32_t>(result), "home not admitted");
    findRecord(*app, operationId)->programmaticHome = true;
    return Ok();
}
bool copyHomeResult(uint32_t operationId, ESS::HomeContext& output) {
    if (!app || !operationId) return false;
    const auto* record = findRecord(*app, operationId);
    if (!record || record->kind != App::OperationKind::HOME || !record->programmaticHome) return false;
    output = record->home; return true;
}
MotorControlRS::Status submitStop(uint8_t address, const MotorControlRS::StopPolicy& policy, uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    ActionRequest request; request.kind = ActionKind::STOP; request.stop = policy;
    const auto admitted = startAction(app, 0, address, request, operationId);
    if (admitted != Probe::Action::OK) return Status(Err::INVALID_CONFIG, static_cast<int32_t>(admitted), "stop not admitted");
    findRecord(*app, operationId)->programmaticAction = true;
    return Ok();
}
bool copyActionResult(uint32_t operationId, ActionResult& output) {
    if (!app || !operationId) return false;
    auto* record = findRecord(*app, operationId);
    if (!record || record->kind != App::OperationKind::ACTION || !record->programmaticAction) return false;
    output.action = record->action; output.pending = resultPending(*app, *record);
    output.interruptedByStop = record->interruptedByStop;
    output.stopEscalation = record->stopEscalation; output.replacedOperationId = record->replacedOperationId;
    output.recoveryOperationId = record->stopRecoveryOperationId;
    output.beforeRecoveryKnown = record->stopBeforeRecoveryKnown; output.beforeRecovery = record->stopBeforeRecovery;
    output.recovery = record->stopRecoveryResult;
    if (!output.pending) { record->delivered = true; record->deliveredUs = nowUs(); }
    return true;
}
MotorControlRS::Status inspectReleaseAfterStop(uint32_t stopId, ReleaseAfterStopPrerequisites& output) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    const auto inspected = inspectRelease(*app, stopId, output);
    return inspected == Probe::Action::OK ? Ok() : Status(Err::INVALID_CONFIG, static_cast<int32_t>(inspected), "release facts unavailable");
}
MotorControlRS::Status submitReleaseAfterStop(uint32_t stopId, const ReleaseAfterStopPrerequisites& facts, uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    ActionRequest request; request.kind = ActionKind::RELEASE;
    const auto admitted = startActionIn(*app, 0, facts.target.address, request, operationId, false, stopId, &facts);
    if (admitted != Probe::Action::OK) return Status(Err::INVALID_CONFIG, static_cast<int32_t>(admitted), "release not admitted");
    findRecord(*app, operationId)->programmaticAction = true;
    return Ok();
}
bool releaseOperation(uint32_t operationId) {
    if (!app || !operationId) return false;
    if (auto* group = groupOperation(*app, operationId)) return releaseGroup(*app, *group) == Probe::Action::OK;
    const auto* record = findRecord(*app, operationId);
    return record && terminal(*app, *record) && release(app, operationId) == Probe::Action::OK;
}
// Group requests are built in App storage (PSRAM), never on the caller's stack.
static Probe::GroupCommand* groupRequest(Probe::GroupCommandKind kind) {
    if (!app) return nullptr;
    auto& command = app->group.command;
    command.~GroupCommand(); new (&command) Probe::GroupCommand();
    command.kind = kind; return &command;
}
static MotorControlRS::Status submitGroup(const Probe::GroupCommand* command, uint32_t* operationId, const char* message) {
    using namespace MotorControlRS;
    if (!app || !command) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    Probe::GroupReply reply;
    const auto result = groupCommand(app, 0, *command, reply);
    if (result != Probe::Action::OK)
        return Status(result == Probe::Action::UNSUPPORTED ? Err::UNSUPPORTED : Err::INVALID_CONFIG, static_cast<int32_t>(result), message);
    if (reply.operationId && operationId) {
        groupOperation(*app, reply.operationId)->programmatic = true; // Delivered without a console line.
        *operationId = reply.operationId;
    }
    return Ok();
}
MotorControlRS::Status declareGroup(const uint8_t* addresses, std::size_t count, uint32_t& operationId) {
    if (!addresses || !count || count > Probe::GROUP_CAPACITY)
        return MotorControlRS::Status(MotorControlRS::Err::INVALID_CONFIG, static_cast<int32_t>(Probe::Action::INVALID), "group needs 1..15 addresses");
    auto* command = groupRequest(Probe::GroupCommandKind::SET);
    if (command) { std::memcpy(command->addresses, addresses, count); command->count = count; }
    return submitGroup(command, &operationId, "group declaration not admitted");
}
MotorControlRS::Status clearGroup() {
    return submitGroup(groupRequest(Probe::GroupCommandKind::CLEAR), nullptr, "group clear requires an idle application");
}
MotorControlRS::Status declareGroupWiring(uint8_t address, uint8_t terminal, MotorControlRS::InputWiring state) {
    auto* command = groupRequest(Probe::GroupCommandKind::WIRING);
    if (command) { command->address = address; command->terminal = terminal; command->wiring = state; }
    return submitGroup(command, nullptr, "group wiring declaration not admitted");
}
bool inspectGroup(Probe::GroupView& output) {
    if (!app) return false;
    output = buildGroupView(*app); return true;
}
MotorControlRS::Status submitGroupMove(const Probe::GroupMoveRequest& request, uint32_t& operationId) {
    auto* command = groupRequest(Probe::GroupCommandKind::MOVE);
    if (command) command->move = request;
    return submitGroup(command, &operationId, "group move not admitted; inspect member readiness, policy or capacity");
}
MotorControlRS::Status submitGroupStop(MotorControlRS::StopBehavior behavior, uint32_t& operationId) {
    auto* command = groupRequest(Probe::GroupCommandKind::STOP);
    if (command) command->stop = behavior;
    return submitGroup(command, &operationId, "group stop not admitted");
}
MotorControlRS::Status submitGroupStateRead(uint32_t& operationId) {
    return submitGroup(groupRequest(Probe::GroupCommandKind::READ_STATE), &operationId, "group state read not admitted");
}
MotorControlRS::Status stagePositionMove(const MotorControlRS::PositionRequest& position, uint16_t speedRpm, uint32_t& operationId) {
    using namespace MotorControlRS;
    if (!app) return Status(Err::INVALID_CONFIG, 0, "application is not started");
    MoveRequest request; request.position = position;
    request.speedRpm = speedRpm; request.ramp = MoveRamp::VERIFIED_CONFIGURED;
    const auto admitted = startSelectedStage(*app, request, operationId);
    if (admitted != Probe::Action::OK)
        return Status(admitted == Probe::Action::UNSUPPORTED ? Err::UNSUPPORTED : Err::INVALID_CONFIG,
            static_cast<int32_t>(admitted), "stage not admitted; inspect readiness, units, limits or owner capacity");
    return Ok();
}
bool copyPositionStage(uint32_t operationId, Probe::PositionStageView& output) {
    if (!app || !operationId || app->stage.view.operationId != operationId) return false;
    output = app->stage.view; return true;
}
bool copyGroupResult(uint32_t operationId, Probe::GroupResult& output) {
    if (!app || !operationId) return false;
    const auto* op = groupOperation(*app, operationId);
    if (!op) return false;
    output = op->result; return true;
}
void serviceApplication() {
    if (!app) { Platform::idle(10); return; }
    App& a = *app; bool serviceDue = true;
    RuntimeWitness::mark(RuntimeWitness::OWNER);
#if MOTORCONTROLRS_LOAD_FIXTURE
    serviceDue = !a.owner.active() || nowUs() >= nextServiceUs;
#endif
    if (serviceDue) {
        uint64_t sampled = uart.sample(); bool recoveryReady = !a.owner.recovering();
        RuntimeWitness::service(static_cast<uint32_t>(sampled / 1000), static_cast<uint32_t>(a.inputLines),
            static_cast<uint32_t>(a.outputCount), static_cast<uint32_t>(a.outputBlocked));
        if (a.owner.recovering() && sampled < a.recovery.deadlineUs && !a.runner.busy() &&
            !a.runner.transmitEnabled() && sampled >= a.recoveryGuardUntilUs) {
            if (!a.recovery.prepared) a.recovery.prepared = uart.clear();
            recoveryReady = a.recovery.prepared; sampled = uart.sample();
        }
        const bool hadDE = a.runner.transmitEnabled();
#if MOTORCONTROLRS_LOAD_FIXTURE
        loadFixture.serviced(sampled, a.owner.active());
#endif
        cancelInvalidPositionInterrupts(a, sampled);
        cancelInvalidHomes(a, sampled);
        cancelInvalidReleases(a, sampled);
        cancelInvalidPositionClears(a, sampled);
        a.owner.service(sampled, recoveryReady);
        if (hadDE && !a.runner.transmitEnabled()) a.recoveryGuardUntilUs = nowUs() + RECOVER_US;
#if MOTORCONTROLRS_LOAD_FIXTURE
        nextServiceUs = a.owner.active() ? sampled + loadFixture.ownerDelayUs() : 0;
#endif
    }
    const auto* recovered = a.owner.recoveryResult(a.recovery.id);
    if (recovered && recovered->outcome == Rtu::RecoveryOutcome::RECOVERED && a.recovery.operationId > a.cacheOperationId) {
        a.known = a.ok = a.modelKnown = false; a.cacheOperationId = a.recovery.operationId;
        // Both harvest watermarks exclude old results after recovery.
        a.modelOperationId = a.recovery.operationId;
        a.observedEarliestUs = a.observedLatestUs = a.deliveredUs = 0;
    }
    RuntimeWitness::mark(RuntimeWitness::OPERATIONS);
    serviceMotionProfile(a, nowUs());
    serviceCommissioning(a, nowUs());
    servicePersistence(a, nowUs());
    serviceDiscovery(a, nowUs());
    advanceReads(a, nowUs());
    advanceActions(a, nowUs());
    const uint64_t completedSampleUs = nowUs();
    serviceSelectedStage(a, completedSampleUs);
    serviceGroup(a, completedSampleUs); // No extra clock read while no group operation runs.
    serviceCoordinates(a, completedSampleUs);
    RuntimeWitness::mark(RuntimeWitness::CONSOLE);
    a.console.serviceOutput(); deliver(a);
    serviceSimpleMotion(a, nowUs());
    serviceMonitor(a, nowUs());
    for (unsigned i = 0; i < 32 && Platform::availableConsole(); ++i) {
        const char c = static_cast<char>(Platform::readConsole()); ++a.inputBytes;
        if (c == '\n') ++a.inputLines;
        a.console.feed(c);
    }
#if MOTORCONTROLRS_LOAD_FIXTURE
    if (a.outputCount < OUTPUT_LINES - 2 && !a.console.outputPending()) {
        char text[265]; std::size_t size = 0;
        if (loadFixture.takeLine(text, sizeof(text), size)) emit(&a, text, size);
    }
#endif
    a.debug.service(a.console, a.outputCount >= OUTPUT_LINES - 2);
    drainOutput(a);
    if (!OwnerWatchdog::completed(completedSampleUs)) platformReady = false;
    RuntimeWitness::mark(RuntimeWitness::IDLE);
    if (!a.owner.active() || !serviceDue) Platform::idle(1);
}
} // namespace MotorControlRSExample
