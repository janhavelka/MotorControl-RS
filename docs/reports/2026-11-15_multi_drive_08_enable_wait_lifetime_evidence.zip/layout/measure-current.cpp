#include "../../examples/probe_cli/ProbeApp.cpp"
extern "C" {
char multi08_app_size[sizeof(App)];
char multi08_member_size[sizeof(App::GroupMember)];
char multi08_evidence_size[sizeof(ESS::ActionEvidence)];
#ifdef MULTI08_CURRENT
char multi08_wait_size[sizeof(App::EnableWait)];
char multi08_wait_array_size[sizeof(app->enableWaits)];
#endif
}
