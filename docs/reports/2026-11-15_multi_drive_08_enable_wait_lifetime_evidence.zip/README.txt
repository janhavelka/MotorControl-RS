Multi-drive 08 evidence, 15 November 2026
Baseline: 28e5352e34dd02d9c7d8a815f7934d1e2b30f1ad
Implementation: a670c09670164ace09a029f1428fc542d344ec1a
FieldCore read-only: c40ea8341edf8d665460b902cafefbe857a7f73f

baseline/: original native diagnostic, output and source snapshot. Run the
diagnostic against the baseline checkout, not the corrected private App layout.
It uses the real group app/owner/runner and scripted drive replies. CMake paths
record this checkout. Configure with Ninja/Debug, build repro, run repro.exe.
The printed early-time difference samples the fake clock again, so differs by
1 us from subtracting its printed frame time. Both show about 858 ms early.

local/: quick verifier summary and logs, focused 10-suite CTest log, Doxygen.
Commands: python scripts/verify.py --mode quick --build-dir build/multi08_verify
          doxygen docs/Doxyfile
Focused regex: ^(group_app|idf_group_app|probe_app|simple_motion_app|
idf_simple_motion_app|communication_app|stop_path_app|idf_stop_path_app|
move_app|idf_move_app)$
The focused log came from the existing build/audit1516_final/native tree after
rebuilding the affected suites. The fresh quick verifier has its own clean tree.

layout/: exact compile-only commands, tool version and nm output. Root-relative
includes expect the recorded build/multi08_layout paths; baseline snapshot
expands beneath that directory. No measurement object was linked into firmware.

ci/: exact implementation-commit jobs, artifact metadata, downloaded artifact
archives and checked summaries/digests. No temporary authenticated URLs retained.

bench/: one read-only COM13 probe, NO_RESPONSE. No flash or motion. Running image
hash unknown. Command: python scripts/bench_probe.py --port COM13 --address 1
--log build/multi08_bench/preflight.jsonl --timeout 5 --startup 2 probe

source/: committed source bytes and diff. Hashes below identify archive entries.
No new vendor interpretation or changed core behavior. Physical regression,
runtime memory watermarks and HW-15 remain unmeasured in this task.
