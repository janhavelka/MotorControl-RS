cmake_minimum_required(VERSION 3.16)
project(GroupEnableRepro LANGUAGES CXX)
set(BUILD_TESTING OFF CACHE BOOL "" FORCE)
add_subdirectory("C:/Users/Honza/Documents/Projects/MotorControl-RS" core)
add_executable(repro repro.cpp
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/probe_cli/DebugSession.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/probe_cli/ProbeConsole.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/probe_cli/ConsoleText.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/probe_cli/HomeConsoleParser.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/probe_cli/HomeConsoleFormat.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/common/RtuRunner.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/common/RtuBusOwner.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/common/EssRtuValidator.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/common/Esp32S3Uart.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/test/fakes/esp32_uart/FakeEsp.cpp"
 "C:/Users/Honza/Documents/Projects/MotorControl-RS/test/fakes/esp32_uart/FakeUsb.cpp"
)
target_link_libraries(repro PRIVATE MotorControlRS)
target_include_directories(repro PRIVATE "C:/Users/Honza/Documents/Projects/MotorControl-RS/test/fakes/esp32_uart")
target_compile_definitions(repro PRIVATE CONFIG_IDF_TARGET_ESP32S3=1)
target_compile_options(repro PRIVATE -UNDEBUG)
set_target_properties(repro PROPERTIES CXX_STANDARD 11 CXX_STANDARD_REQUIRED YES)
