#define main inherited_group_suite_main
#include "C:/Users/Honza/Documents/Projects/MotorControl-RS/test/group_app_test.cpp"
#undef main
int main() {
    std::printf("App=%zu GroupMember=%zu ActionEvidence=%zu\n", sizeof(App), sizeof(App::GroupMember), sizeof(ESS::ActionEvidence));
    for (unsigned mode=0; mode<3; ++mode) {
        fresh({1,2}); readyGroup({1,2});
        command("@11 enable 1\n");
        runUntil([] { return !acting(*app) && !app->owner.active() && !app->owner.pending(); });
        const uint64_t hold1=groupMember(*app,1)->enableSettleUntilUs;
        assert(hold1 && nowUs()<hold1 && enableSettling(*app,1,nowUs()));
        command("@12 enable 2\n");
        runUntil([] { return !acting(*app) && !app->owner.active() && !app->owner.pending(); });
        assert(nowUs()<hold1 && enableSettling(*app,1,nowUs()) && app->enableSettleAddress==2);
        if (mode==0) { assert(groupOp(declare({1,2})).result.ok); }
        if (mode==1) { assert(groupOp(declare({1})).result.ok); }
        if (mode==2) { assert(clearGroup()); assert(groupOp(declare({1})).result.ok); }
        readGroupState();
        const auto before=nowUs();
        const bool holds=enableSettling(*app,1,before);
        uint32_t moveId=0;
        const auto status=submitGroupMove(groupMove(Policy::LEAVE),moveId);
        std::printf("mode=%u now=%llu original_hold1=%llu delta_to_hold=%llu effective_hold=%d global_address=%u group_move_accepted=%d\n",mode,
            (unsigned long long)before,(unsigned long long)hold1,(unsigned long long)(hold1-before),holds,
            app->enableSettleAddress,status.isOk());
        assert(before<hold1 && !holds);
        if(mode!=0) {
            assert(status.isOk());
            runUntil([] { return isStart(hardware.tx,1); });
            std::printf("first start1 TX time=%llu, %llu us before original wait expires\n",
                (unsigned long long)nowUs(), (unsigned long long)(hold1-nowUs()));
            assert(nowUs()<hold1);
        } else assert(!status.isOk());
    }
}
