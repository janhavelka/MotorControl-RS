Multi-drive 08 bench preflight and, if available, bounded verification.
Only recorded USB 303A:1001 serial 3C:0F:02:CD:6B:98 on COM13 is authorized.
