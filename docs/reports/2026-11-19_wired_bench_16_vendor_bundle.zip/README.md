# ESS23-RS20 firmware 0x0029: questions for the vendor (prepared, not sent)

Drive: ESS23-RS20, model word 0x4EEA, firmware word 0x0029, 24 V supply, RS485
115200 8N1, free shaft, bench of 19 November 2026 (wired bench 16, drive 4 unless
stated). Host: ESP32-S3 controller with checked Modbus RTU framing; every
frame below is raw wire traffic captured by the controller.

## 1. Late `stop normal` leaves the drive creeping (HW-14)

Subdivision 4000, 2000 rpm, ramps 500/500 ms, relative move of 40,000
increments (10 turns). A `stop normal` (FC06 0x0027 = 0x0100) sent 371.1 ms
after the start frame was echoed exactly; the drive then kept RUNNING with
speed word 0 while the position rose about 60-80 increments/s, 3,361
increments past the target. `stop normal` never reported completion. A
release (0x002D) stopped the creep; `stop fast` then completed. Earlier study
(November 2026, drive 1): 15 of 30 stops in a 15 ms band failed at subdivision
4000, failures from 66,667 increments/s upward, none at 60,000 or below.
Files: `hw14_trial.json`, `hw14_console.txt`.

Question: is this a known defect of 0x0029, and does newer firmware fix it?

## 2. Persistent RUNNING at high subdivision (Q05)

Subdivision 51200, ramps 100/100 ms, relative 12,800 increments:

| Speed (rpm) | Attempts | Result |
| ---: | ---: | --- |
| 900 | 6 (Y0 = running 3, Y0 = arrival 3) | 6 of 6 RUNNING persisted for 3 s, position about 370 past the target and rising about 100 increments/s; the running output stayed on, the arrival output stayed off; `stop fast` completed each time |
| 2000 | 3 | 3 of 3 completed (12,788-12,800 increments) |

October 2026 (same drive family, image of that time): 900 rpm failed 3/3,
2000 rpm passed 3/3. Files: `q05_rows.json`, `q05_console.txt`.

Question: what limits the internal command generation at subdivision 51200,
and does the datasheet's "MAX. INPUT FREQUENCY 200KHZ" apply to serial
positioning?

## 3. Reset-like loss of volatile settings (Q04, October 2026, not repeated)

Subdivision 4000, 2700 rpm, 20,000 increments, ramps 100/100 (180,000
increments/s): a missing reply, then position 0 and default subdivision and
profile, twice. Ramps 100/500, 500/500 and 500/100 passed. Supply voltage at
the failure was not measured. (Not repeated in November: a restart cannot be
undone while nobody is at the bench.)

Question: what reset reasons can the drive record, and can they be read?

## 4. Persistent RUNNING at 1,000 increments/s (HW-01, November 2026, not repeated)

Subdivision 1000, 60 rpm, relative 3000, a serial interrupt (0x0027 bit 3) at
about 1.75 s, `stop normal` 6 s later: once in four runs status stayed RUNNING
at speed 0, both stops ended without completion, and only a power cycle
restored normal moves.

## 5. Alarm 5 silence and alarm clear

A lowered position-error threshold (0x010A = 1) latches alarm 5 on the next
move. While latching it the drive does not answer Modbus for 1.0-1.9 s (it
answered again 1.96-1.98 s after the start acknowledgement through the
host's recovery in this run). `alarm clear` (0x0021) clears it, although the
hardware manual lists alarm 5 as "re-power reset". A start sent 0.59 s after
the alarm clear's acknowledgement was ignored three times; starts at 0.91,
1.15 and 1.40 s were acted on. Files: `alarm5_console.txt`.

Questions: is the silence intended, and how long after alarm clear (and after
enable) is a start accepted?

## Settings and images

`settings_drive4.json`: the baseline settings of drive 4 (all fields read on
18-19 November 2026). Host images:

- Arduino image P (wired bench 16): `E83C14B50B106085F70920F8B55B8F47B0DCF0FE978444F641757BFCDFB4D0FF`
- Arduino image Q (wired bench 16, final): `38BDB4903A1918919B3BD0BEA42B9CDF43A40D37E9B6C095D68BDA62864D9EC0`
