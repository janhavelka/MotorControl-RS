from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path('scripts').resolve()))
import bench_probe as b
from serial.tools import list_ports
out=Path('build/m04_hardware')
ports=[dict(device=p.device,vid=p.vid,pid=p.pid,serial=p.serial_number) for p in list_ports.comports()]
record={'ports':ports,'ok':False}
try:
    assert any(p==dict(device='COM13',vid=0x303A,pid=0x1001,serial='3C:0F:02:CD:6B:98') for p in ports),'recorded board absent'
    with (out/'preflight.jsonl').open('x') as log, b.open_port('COM13',115200,3) as port:
        def event(name,**fields):
            log.write(json.dumps(dict(event=name,fields=fields,time=time.monotonic()))+'\n');log.flush()
        c=b.Console(port,on_event=event)
        c.drain_startup(.5)
        record['version']=c.identify()
        for name in ('status','drv','debug'):
            record[name]=c.command(name)
            assert record[name]['ok']
        owner=record['debug']['owner']
        assert not owner['busy'] and not owner['pending'] and not owner['recovery_required'],'owner not idle'
        record['state']=c.command('read-state',address=1,timeout_s=5)
        assert record['state']['ok'] and b.drive_reported_stopped(record['state']),'drive not confirmed stopped'
        record['ok']=True
except Exception as e:
    record['error']=str(e)
finally:
    (out/'preflight.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(ok=record['ok'],error=record.get('error'))))
if not record['ok']: raise SystemExit(1)
