from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path(__file__).resolve().parent.parent
build = root / 'build'
out = root / 'docs/reports/2026-11-16_multi_drive_04_input_programming_evidence.zip'
commit = 'e43c8d0c8235e1077dc176829284cf94490b8831'
baseline = subprocess.check_output(['git', 'rev-parse', 'bbacead2'], cwd=root, text=True).strip()
entries = {}

def add(path, name=None):
    if path.is_file():
        entries[name or path.relative_to(build).as_posix()] = path.read_bytes()

for directory in ('m04_verify', 'm04_final_verify'):
    for path in (build / directory).iterdir():
        if path.is_file() and (path.suffix == '.log' or path.name == 'summary.json'):
            add(path)
for directory in ('m04_hardware', 'm04_ci'):
    for path in (build / directory).iterdir():
        add(path)
for path in (build / 'm04_source_review').iterdir():
    if path.suffix in ('.cpp', '.log', '.txt', '.png'):
        add(path)
for directory in ('m04_app_review', 'm04_console_review'):
    add(build / directory / 'Testing/Temporary/LastTest.log')
for name in ('m04_inventory.json', 'm04_recheck.log', 'm04_firmware_build.log',
             'm04_doxygen.log', 'm04_closeout_checks.log'):
    add(build / name)
sources = {}
for name in ('Modbus-Series-Bus-Product-Function-Manual-V1.0_1_.pdf',
             'ESS23-RS1020_Series_Bus_Integrated_Motor_Hardware_Manual.pdf'):
    path = root / 'docs/vendor' / name
    sources[name] = {'bytes': path.stat().st_size,
                     'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
entries['reviewed_sources.json'] = (json.dumps(sources, indent=2) + '\n').encode()
entries['implementation.patch'] = subprocess.check_output(
    ['git', 'diff', '--binary', baseline, commit], cwd=root)
entries['implementation-stat.txt'] = subprocess.check_output(
    ['git', 'diff', '--stat', baseline, commit], cwd=root)
entries['assemble_evidence.py'] = Path(__file__).read_bytes()
entries['README.txt'] = f'''Multi-drive 04 evidence, 16 November 2026 Europe/Prague
Implementation: {commit}
Baseline: {baseline}
FieldCore read-only reference: c40ea8341edf8d665460b902cafefbe857a7f73f

m04_verify: first integrated run, four failed tests retained.
m04_final_verify: fresh quick verifier, all 97 suites and 15 checks PASS.
m04_ci: exact-commit terminal run and four digest-checked artifact ZIPs.
m04_source_review: original PDF pages, independent reproducer and size checks.
m04_app_review / m04_console_review: focused test records.
m04_hardware: COM13 preflight, image/upload, bounded script, settings backups,
  summary and raw records. The script ran once with prefix run; no recovery,
  automatic rollback or uncertain write replay. Firmware source is the commit
  above. The image hash is recorded in image.json and run.json.

Commands:
python scripts/verify.py --mode quick --build-dir build/m04_final_verify
doxygen docs/Doxyfile
scripts/pio.cmd run -e bench_s3_load_timer -j 2
scripts/pio.cmd run -e bench_s3_load_timer -t upload --upload-port COM13 -j 2
python build/m04_hardware/regression.py --firmware build/m04_hardware/firmware.bin --commit {commit} --out build/m04_hardware/run

These are evidence records, not instructions to replay a motor write.
The benchmark only touched address 1. Terminals were unconnected. Wired effects,
status/polarity mapping, drive restart/persistence and independent electrical
timing remain unqualified. Passive debug dropped 2348 optional records; retained
operation evidence and checked results remain separate from that partial stream.
'''.encode()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(entries.items())}
entries['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
print(json.dumps({'path': out.relative_to(root).as_posix(), 'files': len(entries),
                  'bytes': out.stat().st_size,
                  'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}))
