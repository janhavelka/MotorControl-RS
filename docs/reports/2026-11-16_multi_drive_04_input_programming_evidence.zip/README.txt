Multi-drive 04 evidence, 16 November 2026 Europe/Prague
Implementation: e43c8d0c8235e1077dc176829284cf94490b8831
Baseline: bbacead2023d1e207b80b8439f27103184f642d2
FieldCore read-only reference: c40ea8341edf8d665460b902cafefbe857a7f73f

m04_verify: first integrated run, four failed tests retained.
m04_final_verify: fresh quick verifier, all 97 suites and 15 checks PASS.
m04_ci: exact-commit terminal run and four digest-checked artifact ZIPs.
m04_source_review: original PDF pages, independent reproducer and size checks.
m04_app_review / m04_console_review: focused test records.
m04_hardware: COM13 preflight, image/upload, bounded script, settings backups,
  summary and raw records. The script ran once with prefix run; no recovery,
  automatic rollback or uncertain write replay. Firmware source is the commit
  above. The image hash is recorded in image.json and run.json.

Commands:
python scripts/verify.py --mode quick --build-dir build/m04_final_verify
doxygen docs/Doxyfile
scripts/pio.cmd run -e bench_s3_load_timer -j 2
scripts/pio.cmd run -e bench_s3_load_timer -t upload --upload-port COM13 -j 2
python build/m04_hardware/regression.py --firmware build/m04_hardware/firmware.bin --commit e43c8d0c8235e1077dc176829284cf94490b8831 --out build/m04_hardware/run

These are evidence records, not instructions to replay a motor write.
The benchmark only touched address 1. Terminals were unconnected. Wired effects,
status/polarity mapping, drive restart/persistence and independent electrical
timing remain unqualified. Passive debug dropped 2348 optional records; retained
operation evidence and checked results remain separate from that partial stream.
