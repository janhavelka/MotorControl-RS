#define main existingIoTestMain
#include "../../test/io_test.cpp"
#undef main
#include <cstdio>
int main() {
    auto r = request(7);
    r.fields |= mask(8);
    r.inputPolarity = 1;
    r.inputFunctions[0] = E::InputFunction::UNDEFINED;
    auto p = prerequisites(r, read(0, 0, 0, 7));
    p.inputWiring[0] = InputWiring::CONNECTED;
    p.actualInputs = 0;
    E::DriverContext c;
    const auto s = E::prepareDriverSettings(c, target(), 12, r, p, 200, 9000);
    if (!s) { std::printf("rejected: %s\n", s.msg); return 1; }
    auto w = work(c);
    std::printf("ADMITTED old=X0_POSITION_TRIGGER input=0 polarity=0 candidate=polarity1,X0_NONE; first FC06 reg=%04x value=%u\n", w.reg, w.value);
}
