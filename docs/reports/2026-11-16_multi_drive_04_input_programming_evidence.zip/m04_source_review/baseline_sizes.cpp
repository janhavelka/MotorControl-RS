#include <MotorControlRS/profiles/ess_rs/DriverSettings.h>
#include <cstdio>
namespace E = MotorControlRS::ESS_RS;
int main() { std::printf("baseline DriverPrerequisites=%zu DriverContext=%zu\n", sizeof(E::DriverPrerequisites), sizeof(E::DriverContext)); }
