#include <MotorControlRS/profiles/ess_rs/DriverSettings.h>
#include <cstdio>
namespace E = MotorControlRS::ESS_RS;
int main() { std::printf("IoInputFacts=%zu IoOutputFacts=%zu DriverPrerequisites=%zu DriverContext=%zu\n", sizeof(E::IoInputFacts), sizeof(E::IoOutputFacts), sizeof(E::DriverPrerequisites), sizeof(E::DriverContext)); }
