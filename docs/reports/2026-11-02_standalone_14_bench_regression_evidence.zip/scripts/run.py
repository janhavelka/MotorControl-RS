# usage: run.py LOG.jsonl QUIET CMD...  $OP = last accepted operation id for that @id prefix; =S sleep; ?S drain S seconds; COM13 identity enforced.
import sys, time, json, re, serial
import serial.tools.list_ports as lp
p=[x for x in lp.comports() if x.device=='COM13'][0]
assert (p.vid,p.pid,p.serial_number)==(0x303A,0x1001,'3C:0F:02:CD:6B:98'),'wrong device'
log=open(sys.argv[1],'a',encoding='utf-8'); quiet=float(sys.argv[2])
s=serial.Serial(); s.port='COM13'; s.baudrate=115200; s.timeout=0.02; s.dtr=False; s.rts=False; s.exclusive=True; s.open()
def rec(k,t): log.write(json.dumps({'t':round(time.time(),3),'k':k,'v':t})+'\n'); log.flush()
buf=b''; ops={}; last=0
KEYS=('command','result','ok','state','outcome','execution','completion','uncertain','raw_motion','raw_alarm','raw_position','raw_speed','position_mismatch','position_confirmed','observed_position','endpoint_native','position_interrupt','running_observed','interrupted_by_stop','failure','error','status','original','current','restored','restore_unsettled','reason','read_first','fact','valid','position_words','inputs','stored','relation','raw_auxiliary','raw_method','raw_search_speed','raw_return_speed','raw_ramp_time','raw_offset_words','homing_complete','in_position','tx_hex','rx_hex')
def show(t):
    m=[]
    for k in KEYS:
        f=re.findall('"'+k+r'":(\[[^\]]*\]|\{[^}]*\}|"[^"]*"|[^,}]+)',t)
        if f: m.append(k+'='+f[0].strip('"'))
    print('   <',' '.join(m)[:520] if t.startswith('{') else t[:220])
def drain(q):
    global buf,last
    end=time.time()+q
    while time.time()<end:
        d=s.read(4096)
        if d:
            buf+=d; end=time.time()+q
            while b'\n' in buf:
                l,buf=buf.split(b'\n',1); t=l.decode('utf-8','replace').rstrip()
                if not t: continue
                rec('rx',t); show(t)
                m=re.search(r'"type":"reply".*?"id":(\d+).*?"operation_id":(\d+)',t)
                if m and int(m.group(2)): ops[m.group(1)]=int(m.group(2)); last=int(m.group(2))
drain(0.2)
for c in sys.argv[3:]:
    if c[0]=='=': print('  sleep',c[1:]); time.sleep(float(c[1:])); continue
    if c[0]=='?': drain(float(c[1:])); continue
    c=c.replace('$OP',str(last)); c=re.sub(r'\$(\d+)',lambda m:str(ops.get(m.group(1),0)),c)
    print('>',c); rec('tx',c); s.write((c+'\n').encode()); s.flush(); drain(quiet)
drain(0.3); s.close()
