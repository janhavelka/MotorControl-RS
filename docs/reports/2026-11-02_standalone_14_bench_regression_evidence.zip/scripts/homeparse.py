import json,re,sys
rows=[json.loads(l) for l in open(sys.argv[1],encoding='utf-8')]
on=False;t0=None
for r in rows:
    v=r['v']
    if r['k']=='tx' and sys.argv[2] in v: on=True; t0=r['t']; print(v)
    elif r['k']=='tx' and on and 'debug off' in v: on=False
    if not on or r['k']!='rx': continue
    if '"kind":"TX"' in v or '"kind":"RX"' in v:
        k=re.search(r'"kind":"(\w+)"',v).group(1); h=re.search(r'"raw_hex":"([0-9A-F]*)"',v).group(1)
        if k=='TX' and h.startswith('0103'): continue
        if k=='TX' or h.startswith('0110') or h.startswith('0106'): print(round(r['t']-t0,3),k,h)
        elif h.startswith('010306'): print(round(r['t']-t0,3),'poll alarm',int(h[6:10],16),'motion',int(h[10:14],16),'inputs',int(h[14:18],16))
        elif h.startswith('010304'): print(round(r['t']-t0,3),'pos',int(h[6:14],16))
        else: print(round(r['t']-t0,3),k,h)
    if '"type":"home"' in v:
        print({k:(re.findall('"%s":("[^"]*"|[^,}]+)'%k,v) or ['?'])[0] for k in ('ok','state','outcome','execution','completion','uncertain','polls','raw_motion','raw_alarm','running_observed','homed_low_observed','detail','status')})
