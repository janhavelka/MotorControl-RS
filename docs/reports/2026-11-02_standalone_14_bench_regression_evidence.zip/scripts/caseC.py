# Interrupt a plain stored move and sample without stopping. Args: LOG N DELAY [RPM]
import sys,time,json,re,serial
import serial.tools.list_ports as lp
p=[x for x in lp.comports() if x.device=='COM13'][0]
assert (p.vid,p.pid,p.serial_number)==(0x303A,0x1001,'3C:0F:02:CD:6B:98')
log=open(sys.argv[1],'a',encoding='utf-8'); N=int(sys.argv[2]); D=float(sys.argv[3])
s=serial.Serial(); s.port='COM13'; s.baudrate=115200; s.timeout=0.01; s.dtr=False; s.rts=False; s.exclusive=True; s.open()
buf=b''; idn=[200]; T0=time.time()
def rec(k,t): log.write(json.dumps({'t':round(time.time(),3),'k':k,'v':t})+'\n'); log.flush()
def rx(q):
    global buf
    out=[]; end=time.time()+q
    while time.time()<end:
        d=s.read(4096)
        if d:
            buf+=d
            while b'\n' in buf:
                l,buf=buf.split(b'\n',1); t=l.decode('utf-8','replace').rstrip()
                if t: rec('rx',t); out.append(t)
    return out
def f(t,k):
    m=re.search(r'"%s":("[^"]*"|\[[^\]]*\]|[^,}]+)'%k,t); return m.group(1).strip('"') if m else None
def cmd(c,want=None,limit=1.0):
    i=idn[0]; idn[0]+=1; c=f'@{i} {c}'; rec('tx',c); s.write((c+'\n').encode()); s.flush()
    out=[]; t0=time.time()
    while time.time()-t0<limit:
        out+=rx(0.02)
        if want and any(want in x and f'"id":{i},' in x for x in out): break
        if not want and out: break
    return i,out
def op(o,i):
    for t in o:
        if f'"id":{i},' in t and '"type":"reply"' in t: return f(t,'operation_id')
def st(tag):
    i,o=cmd('read state','"state":"succeeded"',1.0)
    t=[x for x in o if '"state":"succeeded"' in x and '"read-state"' in x]
    if t: print(f"{time.time()-T0:6.2f} {tag}: motion={f(t[-1],'raw_motion')} alarm={f(t[-1],'raw_alarm')} pos={f(t[-1],'position_words')} speed={f(t[-1],'raw_speed')}")
    else: print(f"{time.time()-T0:6.2f} {tag}: no state {[f(x,'result') for x in o]}")
    k=op(o,i)
    if k: cmd(f'release {k}',None,0.2)
    return t[-1] if t else None
i,o=cmd('read config','"state":"succeeded"',2); cmd(f'release {op(o,i)}',None,0.2)
st('before'); cmd('motion-profile read',None,0.5); rx(0.2)
T0=time.time()
mi,o=cmd(f'move relative {N} steps native 60 configured',None,0.5); mop=op(o,mi); print(f"{time.time()-T0:6.2f} move op {mop}")
while time.time()-T0<D: rx(0.02)
ii,o=cmd(f'position interrupt {mop}','"result"',0.5); iop=op(o,ii); print(f"{time.time()-T0:6.2f} interrupt op {iop}", [f(x,'result') for x in o if '"type":"reply"' in x])
for x in o:
    if '"type":"move"' in x: print(f"       terminal {f(x,'command')} outcome={f(x,'outcome')} exec={f(x,'execution')}")
tend=T0+D+N/1000+4
while time.time()<tend:
    st('sample'); rx(0.4)
for x in rx(0.2):
    if '"type":"move"' in x: print('  late terminal',f(x,'command'),f(x,'outcome'))
print('stop-candidates: original',mop,'replacement',iop)
s.close()
