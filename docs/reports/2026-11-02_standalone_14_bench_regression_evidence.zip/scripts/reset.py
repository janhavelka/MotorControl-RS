import serial,time,serial.tools.list_ports as lp
p=[x for x in lp.comports() if x.device=='COM13'][0]
assert (p.vid,p.pid,p.serial_number)==(0x303A,0x1001,'3C:0F:02:CD:6B:98')
s=serial.Serial(); s.port='COM13'; s.baudrate=115200; s.dtr=False; s.rts=True; s.open(); time.sleep(0.15); s.rts=False; time.sleep(0.05); s.close()
