# usage: ladder.py LOG N... : plain finite relative moves at 60 rpm; stops at the first non-clean result. COM13 identity enforced.
import sys,time,json,re,serial
import serial.tools.list_ports as lp
p=[x for x in lp.comports() if x.device=='COM13'][0]
assert (p.vid,p.pid,p.serial_number)==(0x303A,0x1001,'3C:0F:02:CD:6B:98')
log=open(sys.argv[1],'a',encoding='utf-8')
s=serial.Serial(); s.port='COM13'; s.baudrate=115200; s.timeout=0.02; s.dtr=False; s.rts=False; s.exclusive=True; s.open()
buf=b''; ident=[100]
def rec(k,t): log.write(json.dumps({'t':round(time.time(),3),'k':k,'v':t})+'\n'); log.flush()
def rx(q):
    global buf
    out=[]; end=time.time()+q
    while time.time()<end:
        d=s.read(4096)
        if d:
            buf+=d
            while b'\n' in buf:
                l,buf=buf.split(b'\n',1); t=l.decode('utf-8','replace').rstrip()
                if t: rec('rx',t); out.append(t)
    return out
def cmd(c,wait,want=None,limit=None):
    i=ident[0]; ident[0]+=1; c=f'@{i} {c}'; rec('tx',c); s.write((c+'\n').encode()); s.flush()
    out=[]; t0=time.time(); limit=limit or wait
    while time.time()-t0<limit:
        out+=rx(0.05)
        if want and any(want in x and f'"id":{i},' in x for x in out): break
    if not want: out+=rx(wait)
    return i,out
def field(t,k):
    m=re.search('"%s":("[^"]*"|\[[^\]]*\]|[^,}]+)'%k,t); return m.group(1).strip('"') if m else None
def opid(out,i):
    for t in out:
        if f'"id":{i},' in t and '"type":"reply"' in t: return field(t,'operation_id')
def state(tag):
    i,o=cmd('read state',0,'"state":"succeeded"',2)
    t=[x for x in o if '"read-state"' in x and '"state"' in x]
    op=opid(o,i)
    if t: print(f"  {tag}: motion={field(t[-1],'raw_motion')} alarm={field(t[-1],'raw_alarm')} pos={field(t[-1],'position_words')} speed={field(t[-1],'raw_speed')} in_pos={field(t[-1],'in_position')}")
    else: print(' ',tag,'no state:',[field(x,'result') for x in o])
    if op: cmd(f'release {op}',0.05)
    return t[-1] if t else None
cmd('debug decoded',0.1); rx(0.2)
for n in map(int,sys.argv[2:]):
    i,o=cmd('read config',0,'"state":"succeeded"',2); op=opid(o,i); cmd(f'release {op}',0.05)
    before=state(f'before {n}')
    cmd('motion-profile read',0.4)
    t0=time.time(); i,o=cmd(f'move relative {n} steps native 60 configured',0,'"type":"move"',n/1000+6)
    m=[x for x in o if '"type":"move"' in x and f'"id":{i},' in x]; op=opid(o,i)
    print(f"move {n}: took {time.time()-t0:.2f}s", (f"ok={field(m[-1],'ok')} outcome={field(m[-1],'outcome')} polls={field(m[-1],'polls')} uncertain={field(m[-1],'uncertain')} mismatch={field(m[-1],'position_mismatch')} failure_detail={field(m[-1],'detail')}") if m else f'NO TERMINAL replies={[field(x,"result") for x in o if chr(34)+"reply"+chr(34) in x]}')
    after=state(f'after {n}')
    if op: cmd(f'release {op}',0.05)
    if not m or field(m[-1],'ok')!='true': print('STOP: not clean'); break
    a=field(before,'position_words'); b=field(after,'position_words')
    pa=eval(a); pb=eval(b); print(f"  moved {(pb[0]<<16|pb[1])-(pa[0]<<16|pa[1])} of {n}")
    time.sleep(0.5)
cmd('debug off',0.1); s.close()
