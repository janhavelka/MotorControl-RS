"""Does an idle drive's position change after its own stop, or when another drive moves?

Finite moves only, through the stress tool's console and helpers. Per trial:
1. Drive A: finite move, stop mid-move (or let it complete), then poll A alone.
2. Drive B: finite moves while polling A, then poll A again.
Every sample is written to samples.csv. No uncertain write is replayed.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import time
import types

ROOT = Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location("bench_stress", ROOT / "scripts/bench_stress.py")
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)

p = argparse.ArgumentParser()
p.add_argument("--out", required=True)
p.add_argument("--a", type=int, default=2)
p.add_argument("--b", type=int, default=4)
p.add_argument("--trials", type=int, default=6)
p.add_argument("--quiet-s", type=float, default=15.0)
args = p.parse_args()

run_args = types.SimpleNamespace(out=args.out, port="COM13", seed=5, debug="off", addresses=[args.a, args.b],
                                 cross_reads=False, declare_unconnected=True)
run = bench.Run(run_args)
out = Path(args.out)
samples = open(out / "samples.csv", "w", encoding="utf-8")
samples.write("t,trial,phase,read_address,moving,raw_motion,raw_speed,position\n")
t0 = time.time()
results = []


def record(trial, phase, address, fields, moving):
    samples.write(f"{time.time() - t0:.3f},{trial},{phase},{address},{moving},{fields.get('raw_motion')},"
                  f"{fields.get('raw_speed')},{fields.get('position')}\n")
    samples.flush()


def poll_a(trial, phase, seconds, moving=None):
    end = time.time() + seconds
    seen = []
    while time.time() < end:
        fields = run.state(check=True) if run.address == args.a else run.read_other(args.a)
        record(trial, phase, args.a, fields, moving)
        seen.append(fields.get("position"))
        run.console.pump(0.15)
    return seen


try:
    run.console.send("debug off")
    for trial in range(args.trials + 1):
        completed = trial == args.trials  # Last trial: a completed move, no stop.
        run.select(args.a)
        before = run.prepare()
        reply = run.start_move(3000, 120)
        if completed:
            item = run.console.terminal(reply, run.duration(3000, 120) + 5)
            run.check_terminal(item, "MOVE")
            run.console.release_all()
            policy = "none"
        else:
            run.console.pump(0.3 + 0.1 * trial)
            policy = "fast" if trial % 2 == 0 else "normal"
            run.stop(policy)
        quiet = poll_a(trial, "quiet", args.quiet_s)
        run.select(args.b)
        during = []
        for k in range(3):
            run.prepare()
            steps = 1000 if k % 2 == 0 else -1000
            move = run.start_move(steps, 120)
            end = time.time() + run.duration(abs(steps), 120) + 3
            while time.time() < end and move["_id"] not in run.console.terminals:
                fields = run.read_other(args.a)
                record(trial, "other_moving", args.a, fields, args.b)
                during.append(fields.get("position"))
                run.console.pump(0.1)
            run.check_terminal(run.console.terminal(move, 5), "MOVE")
            run.console.release_all()
        after = poll_a(trial, "after", 3.0)
        entry = dict(trial=trial, policy=policy, completed=completed,
                     quiet_first=quiet[0], quiet_last=quiet[-1], quiet_changes=sum(1 for x, y in zip(quiet, quiet[1:]) if x != y),
                     during_min=min(during), during_max=max(during), after_last=after[-1],
                     drift_during=max(abs(x - quiet[-1]) for x in during + after))
        results.append(entry)
        print(json.dumps(entry)); sys.stdout.flush()
finally:
    (out / "diag_summary.json").write_text(json.dumps(results, indent=1))
    run.console.close()
