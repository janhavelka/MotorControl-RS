#!/bin/bash
# Functional write/motion set per drive; stops at the first failure.
# Usage: functional.sh "ADDRESSES" FIRST_INDEX_FOR_FIRST_ADDRESS
FW=.pio/build/bench_s3_load_timer/firmware.bin
OUT=${OUT:-build/multidrive/40_functional}
mkdir -p $OUT
SPECS=("settings --setting input-filter --value 3" "settings --setting lock-delay --value 201" "actions"
       "position --phase absolute" "position --phase return" "position --phase forward" "position --phase return"
       "stop --stop-policy normal" "stop --stop-policy fast")
first=${2:-0}
for a in $1; do
  for i in "${!SPECS[@]}"; do
    [ $i -lt $first ] && continue
    spec=${SPECS[$i]}
    name=$(printf "%02d_%s" $i "$(echo "$spec" | awk '{print $1"_"$NF}')")
    python scripts/bench_scenarios.py --address $a --scenario $spec --out $OUT/a${a}_$name --firmware $FW > $OUT/a${a}_$name.stdout 2>&1
    code=$?
    echo "a$a [$i] $spec -> $code"
    if [ $code -ne 0 ]; then tail -5 $OUT/a${a}_$name.stdout; exit $code; fi
  done
  first=0
done
echo ALL_OK
