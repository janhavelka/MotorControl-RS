"""Pack the three-drive test evidence with a SHA-256 manifest."""
import glob
import hashlib
import os
import sys
import zipfile

os.chdir(sys.argv[1])
target = sys.argv[2]
members = []
for pattern in ('30_*', '31_*', '40_functional', '41_functional', '42_*', '43_*', '5*', '6*'):
    for path in sorted(glob.glob(pattern)):
        if os.path.isdir(path):
            for root, _, files in os.walk(path):
                members += [os.path.join(root, name).replace(os.sep, '/') for name in files]
        else:
            members.append(path.replace(os.sep, '/'))
members += ['tools/functional.sh', 'tools/diag_settle.py', 'tools/sess.py', 'tools/pack_tests.py']
members = sorted(set(members))
with open('MANIFEST_tests.sha256', 'w', newline='\n') as manifest:
    for path in members:
        manifest.write(hashlib.sha256(open(path, 'rb').read()).hexdigest() + '  ' + path + '\n')
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in members + ['MANIFEST_tests.sha256']:
        archive.write(path)
print(len(members) + 1, os.path.getsize(target))
