"""Summarize HW-14 stop trials: where each stop ended relative to the target.
Args: DIR... Each DIR holds trials.jsonl from repro_stop.py, named sSUB_rRPM_tTURNS_aRAMP.
short: ended more than 1% before the target (stop came before the band);
on: within 1% (the braking ramp reached the target); over: beyond it (the failure).
"""
import json
import pathlib
import re
import sys

print("| Run | Rate (increments/s) | Trials | Failed stops | Short | On target | Past target | Stop delay (s) |")
print("| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |")
for arg in sys.argv[1:]:
    d = pathlib.Path(arg)
    m = re.match(r"s(\d+)_r(\d+)_t([\d.]+)_a(\d+)", d.name)
    sub, rpm, turns = int(m[1]), int(m[2]), float(m[3])
    steps = round(turns * sub)
    rows = [json.loads(x) for x in (d / "trials.jsonl").read_text().splitlines() if x.strip()]
    short = on = over = 0
    for r in rows:
        delta = r["delta"] if r["delta"] < 2**31 else r["delta"] - 2**32
        if not r["stop_ok"] or delta > steps * 1.01:
            over += 1
        elif delta < steps * 0.99:
            short += 1
        else:
            on += 1
    failed = sum(not r["stop_ok"] for r in rows)
    delays = [r["delay"] for r in rows]
    print(f"| {d.name} | {sub * rpm // 60:,} | {len(rows)} | {failed} | {short} | {on} | {over} | {min(delays):.3f}..{max(delays):.3f} |")
