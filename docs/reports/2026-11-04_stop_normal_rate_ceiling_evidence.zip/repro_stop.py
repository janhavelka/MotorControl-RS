"""Deliberate reproduction of HW-14: stop normal during a fast ramp leaves RUNNING with creep.

Args: OUT TRIALS RPM STEPS DELAY_MIN DELAY_MAX ACCEL DECEL [POLICY]
Sets the drive ramps with one ordinary moveby (setup write), then repeats:
move relative STEPS at RPM, wait DELAY, stop POLICY, check. A failed stop is
sampled for 2 s, then settled with one stop fast prepared in advance.
Uses the drive's current subdivision; never changes it.
"""
import argparse
import json
import pathlib
import sys
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "scripts"))
from bench_stress import Anomaly, Run, RUNNING

out, trials, rpm, steps, dmin, dmax, accel, decel = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), float(sys.argv[5]), float(sys.argv[6]), int(sys.argv[7]), int(sys.argv[8])
policy = sys.argv[9] if len(sys.argv) > 9 else "normal"
args = argparse.Namespace(port="COM13", out=out, seed=int(time.time()), debug="raw", duration=0, recover=False, mix="limit", only=None, subdivision=None, restore=None)
r = Run(args)
c = r.console
c.ring = type(c.ring)(maxlen=400000)
c.send("debug raw", 2.0)
item = c.simple("settings", 5.0)
c.release_all()
r.subdivision = item["actual"]["subdivision"]
r.ceiling = item["maximum_position_rpm"]
print("subdivision", r.subdivision, "ceiling", r.ceiling, "profile", item["actual"]["profile"], flush=True)
for command in (f"speed {min(60, r.ceiling)}", f"accel {accel}", f"decel {decel}"):
    c.send(command)
setup = c.simple("moveby 100", 10)
c.release_all()
item = c.simple("settings", 5.0)
c.release_all()
print("ramps set by moveby:", setup and setup.get("state"), "profile now", item["actual"]["profile"], flush=True)
results = []
log = open(pathlib.Path(out) / "trials.jsonl", "a", encoding="utf-8")
for n in range(trials):
    delay = r.random.uniform(dmin, dmax)
    mark = len(c.ring)
    before = r.prepare()
    r.start_move(steps, rpm)
    while time.time() - r.t0 < delay:
        c.pump(0.002)
    reply = c.send(f"stop {policy} 1")
    item = c.terminal(reply, 8.0)
    c.release_all()
    ok = bool(item and item.get("ok"))
    record = dict(n=n, delay=round(delay, 3), stop_ok=ok, outcome=item and item.get("outcome"), motion=item and item.get("raw_motion"))
    if not ok:
        samples = []
        for _ in range(5):
            f = r.state(check=False)
            samples.append((round(time.time() - r.t0, 2), f.get("raw_motion"), f.get("raw_speed"), f.get("position")))
            c.pump(0.4)
        record["creep"] = samples
        reply = c.send("stop fast 1")
        fast = c.terminal(reply, 8.0)
        c.release_all()
        record["fast_ok"] = bool(fast and fast.get("ok"))
        record["wire"] = list(c.ring)[mark:]
    after = r.state(check=False)
    record["after"] = (after.get("raw_motion"), after.get("raw_speed"), after.get("position"))
    record["delta"] = (after["position"] - before["position"]) & 0xFFFFFFFF
    log.write(json.dumps(record) + "\n")
    log.flush()
    print(n, {k: v for k, v in record.items() if k != "wire"}, flush=True)
    results.append(record)
    if not ok and not record.get("fast_ok"):
        print("stop fast did not settle it; leaving the drive as it is", flush=True)
        break
    c.pump(0.5)
c.send("debug off", 2.0)
c.close()
fails = [x for x in results if not x["stop_ok"]]
print(f"SUMMARY trials={len(results)} failed_stops={len(fails)} delays={[x['delay'] for x in fails]}")
