"""HW-14 recheck, part 1: the old failing rates are refused before any motor write.
Args: OUT. For each subdivision: set it (RAM, checked readback, ceiling checked by
Run.set_subdivision against min(2000, 3000000 // subdivision)), then send the
night's failing speed and ceiling+1 through the advanced and the simple route.
Every request must be refused, with no FC06/FC10 frame on the wire.
"""
import argparse
import json
import pathlib
import sys
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "scripts"))
from bench_stress import Run

out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
args = argparse.Namespace(port="COM13", out=str(out), seed=int(time.time()), debug="raw", duration=0, recover=False, mix="limit", only=None, subdivision=None, restore=None)
r = Run(args)
c = r.console
c.ring = type(c.ring)(maxlen=400000)
c.send("debug raw", 2.0)


def writes(mark):
    frames = []
    for _, line in list(c.ring)[mark:]:
        if '"kind":"TX"' in line:
            raw = json.loads(line).get("raw_hex", "")
            if raw[2:4] in ("06", "10"):
                frames.append(raw)
    return frames


log = open(out / "refusals.jsonl", "a", encoding="utf-8")
failures = 0
for sub, old_rpm in ((6000, 2000), (3200, 2000), (51200, 234)):
    r.set_subdivision(sub)
    for rpm in (old_rpm, r.ceiling + 1):
        r.prepare()
        mark = len(c.ring)
        reply = c.send(f"move relative {10 * sub} steps native {rpm} configured")
        c.pump(0.5)
        advanced = dict(ok=reply.get("ok"), result=reply.get("result"), error=reply.get("error"), writes=writes(mark))
        mark = len(c.ring)
        c.send(f"speed {rpm}")
        item = c.simple("moveby 1000", 8.0)
        c.release_all()
        simple = dict(ok=bool(item and item.get("ok")), state=item and item.get("state"),
                      error=item and (item.get("error") or item.get("message")), writes=writes(mark))
        c.send("speed 60")
        refused = not advanced["ok"] and not simple["ok"] and not advanced["writes"] and not simple["writes"]
        failures += not refused
        record = dict(subdivision=sub, ceiling=r.ceiling, rpm=rpm, rate=sub * rpm // 60, refused=refused,
                      advanced=advanced, simple=simple)
        log.write(json.dumps(record) + "\n"); log.flush()
        print(json.dumps(record), flush=True)
r.set_subdivision(1000)
c.send("debug off", 2.0)
c.close()
print(f"SUMMARY requests={6} not_refused={failures}")
