"""Deliberate stop sequence on a drive found stuck, with raw traffic. Args: LOG STEP... (stop-normal, stop-fast, release, enable, reset, alarm-clear, sample)."""
import json
import pathlib
import sys
import time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2] / "scripts"))
from bench_stress import Console, state_fields

log_path = pathlib.Path(sys.argv[1])
c = Console("COM13", None, ring=200000)
c.next_id = 7500


def sample(tag, count=4, interval=0.4):
    for _ in range(count):
        try:
            reply = c.send("read state", 2.0)
            item = c.terminal(reply, 2.0) if reply.get("ok") else None
            c.release_all()
            f = state_fields(item) if item else {"refused": reply.get("result")}
        except Exception as exc:  # keep sampling through a lost reply
            f = {"error": str(exc)}
        print(time.strftime("%H:%M:%S"), tag, {k: f.get(k) for k in ("raw_motion", "raw_alarm", "raw_speed", "position", "refused", "error")}, flush=True)
        c.pump(interval)


def act(command, wait):
    reply = c.send(command, 3.0)
    keep = ("ok", "result", "operation_id")
    print(time.strftime("%H:%M:%S"), ">", command, {k: reply.get(k) for k in keep}, flush=True)
    if reply.get("ok") and reply.get("result") != "done":
        item = c.terminal(reply, wait)
        print("   terminal", item and {k: item.get(k) for k in ("ok", "outcome", "execution", "completion", "raw_motion", "raw_alarm", "uncertain", "status", "message")}, flush=True)
    c.release_all()


c.send("debug raw", 2.0)
sample("before")
for step in sys.argv[2:]:
    if step == "stop-normal":
        act("stop normal 1", 8.0)
    elif step == "stop-fast":
        act("stop fast 1", 8.0)
    elif step == "release":
        act("motor-release 1", 4.0)
    elif step == "enable":
        act("enable 1", 4.0)
    elif step == "alarm-clear":
        act("alarm-clear 1", 4.0)
    elif step == "reset":
        c.reset_mcu()
        print(time.strftime("%H:%M:%S"), "mcu reset", flush=True)
        c.send("debug raw", 3.0)
        c.send("probe", 3.0)
        c.pump(0.3)
        reply = c.send("read config", 2.0)
        c.terminal(reply, 2.0)
        c.release_all()
    elif step == "sample":
        pass
    sample("after " + step)
for command in ("drv", "stats"):
    try:
        c.send(command, 2.0)
    except Exception:
        pass
c.send("debug off", 2.0)
c.pump(0.3)
with open(log_path, "a", encoding="utf-8") as f:
    for entry in c.ring:
        f.write(json.dumps(entry) + "\n")
c.close()
print("logged", len(c.ring), "lines to", log_path)
