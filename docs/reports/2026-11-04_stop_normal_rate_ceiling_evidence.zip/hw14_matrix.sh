#!/usr/bin/env bash
# HW-14 follow-up: documented/conventional subdivisions, same failure geometry.
# Each row: subdivision rpm turns ramp_ms. The boundary time for a stop during the
# ramp is t_b = sqrt(turns * ramp / rps); failures were seen 2..16 ms before it.
cd "$(dirname "$0")/../.."
OUT=build/stress/25_hw14_matrix
mkdir -p $OUT
run() {
  local sub=$1 rpm=$2 turns=$3 ramp=$4 trials=${5:-30}
  local rb=$(python build/stress/peek.py "subdivision $sub" 2>&1 | grep -o '"readback":[0-9]*' | tail -1 | cut -d: -f2)
  if [ "$rb" != "$sub" ]; then echo "subdivision $sub not set (readback $rb)"; return 1; fi
  read steps lo hi < <(python -c "
import math
rps=$rpm/60; tb=math.sqrt($turns*($ramp/1000)/rps)
print(int(round($turns*$sub)), round(tb-0.025,3), round(tb+0.005,3))")
  local d=$OUT/s${sub}_r${rpm}_t${turns}_a${ramp}
  mkdir -p $d
  echo "== sub=$sub rpm=$rpm rate=$((sub*rpm/60)) turns=$turns ramp=$ramp steps=$steps window=$lo..$hi"
  python build/stress/repro_stop.py $d $trials $rpm $steps $lo $hi $ramp $ramp normal 2>&1 | grep -E "SUMMARY|did not"
}
# Same trajectory as the night's sweeps.
run 1600 2000 10 500
run 3200 2000 10 500
run 4000 2000 10 500
run 5000 2000 10 500
# Conventional high subdivisions at the 200,000/s ceiling, boundary 0.4 s into the ramp.
run 6400 1875 10 500
run 12800 937 5 500
run 25600 468 2.5 500
run 51200 234 1.25 500
# Another ramp length.
run 6000 2000 5 200
run 1000 2000 5 200
python build/stress/peek.py "subdivision 1000" 2>&1 | grep -o '"readback":[0-9]*' | tail -1
date
