import serial,time,json,sys
s=serial.Serial(); s.port='COM13'; s.baudrate=115200; s.timeout=0.05; s.dtr=False; s.rts=False; s.exclusive=True; s.open()
buf=b''
def rd(q):
    global buf
    e=time.time()+q; out=[]
    while time.time()<e:
        d=s.read(8192)
        if d:
            buf+=d
            while b'\n' in buf:
                l,buf=buf.split(b'\n',1); out.append(l.decode('utf-8','replace').rstrip())
    return out
o=rd(1.5); print('unsolicited lines:',len(o)); [print(' ',x[:700]) for x in o[-12:]]
for i,c in enumerate(sys.argv[1:],9000):
    s.write(f'@{i} {c}\n'.encode()); o=rd(1.2); print('>',c,'lines',len(o)); [print('  ',x[:1500]) for x in o]
s.close()
