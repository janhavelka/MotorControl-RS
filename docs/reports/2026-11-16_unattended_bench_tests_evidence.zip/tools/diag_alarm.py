#!/usr/bin/env python3
"""Read-only diagnosis after drive 4 went silent in d02 (threshold 1, 2000-step move).

One explicit host recovery, then probes and typed reads of every drive. No write,
no motion, no resend of the acknowledged move. Usage: diag_alarm.py OUT
"""
import importlib.util
import json
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extra", HERE / "extra.py")
e = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)
r, bp = e.r, e.bp


def run(c):
    rows = {"drv_before": c.command("drv", timeout_s=5)}
    rows["recover"] = c.command("recover", timeout_s=8)
    rows["drv_after"] = c.command("drv", timeout_s=5)
    for a in (4, 1, 2, 4):
        rows.setdefault(f"probe_{a}", []).append(c.command("probe", address=a, timeout_s=5))
        time.sleep(0.3)
    for a in (4, 1, 2):
        row = {}
        for name in ("read-identity", "read-config", "read-state"):
            row[name] = c.command(name, address=a, timeout_s=5)
        row["filters"] = e.op(c, "tuning", driver_args=("filters", "read"), address=a)
        row["home"] = e.op(c, "home-read", address=a)
        row["velocity"] = e.op(c, "velocity-read", address=a)
        rows[f"drive_{a}"] = row
        state = row["read-state"]
        blocks = {b["block"]: b for b in state.get("state_blocks") or []}
        e.note(step="diag", address=a, probe=[p.get("ok") for p in rows.get(f"probe_{a}", [])],
               alarm=blocks.get(0, {}).get("raw_alarm"), motion=blocks.get(0, {}).get("raw_motion"),
               position=blocks.get(2, {}).get("raw_position"), speed=blocks.get(2, {}).get("raw_speed"),
               threshold=(e.raw_of(row["filters"]) or [None] * 3)[2],
               jog=(row["velocity"].get("velocity_parameters") or {}).get("raw_speed"),
               home_method=(row["home"].get("homing_parameters") or {}).get("raw_method"))
    c.emit("diag_alarm", rows=rows)
    for key in ("drv_before", "recover", "drv_after"):
        e.note(step="diag", key=key, ok=rows[key].get("ok"), result=rows[key].get("result"),
               recovery_required=rows[key].get("recovery_required"), outcome=rows[key].get("outcome"))


r.session("diag_alarm", run)
pathlib.Path(r.OUT / "diag_summary.jsonl").write_text("".join(json.dumps(x) + "\n" for x in e.SUMMARY), encoding="utf-8")
