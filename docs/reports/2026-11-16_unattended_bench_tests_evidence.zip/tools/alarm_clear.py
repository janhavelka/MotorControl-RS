#!/usr/bin/env python3
"""Drive 4 with latched alarm 5: explicit stop to reconcile the uncertain move, then one
alarm-clear. Only if the alarm clears: enable, restore the threshold to 4000 and confirm
with one 200-step move. Nothing is resent. Usage: alarm_clear.py OUT
"""
import importlib.util
import json
import pathlib
import time

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extra2", HERE / "extra2.py")
x = importlib.util.module_from_spec(spec)
spec.loader.exec_module(x)
e, r, bp, ok, op = x.e, x.r, x.bp, x.ok, x.op
A = 4


def blocks(c):
    b, state = e.position(c, A)
    return dict(alarm=b[0]["raw_alarm"], motion=b[0]["raw_motion"], released=b[0]["released"],
                enabled=b[0]["enabled"], position=b[2]["raw_position"], speed=b[2]["raw_speed"])


def run(c):
    rows = {}
    e.select(c, A)
    rows["state_start"] = blocks(c)
    stop = op(c, "stop", stop_policy="fast", address=A)
    rows["stop"] = {k: stop.get(k) for k in ("ok", "result", "outcome", "execution", "completion", "replaced_operation_id")}
    time.sleep(0.5)
    rows["state_after_stop"] = blocks(c)
    clear = op(c, "alarm-clear", address=A)
    rows["clear"] = {k: clear.get(k) for k in ("ok", "result", "outcome", "execution", "completion", "raw_alarm", "raw_motion")}
    for wait in (0.2, 1.0, 3.0):
        time.sleep(wait)
        rows[f"state_after_clear_{wait}"] = blocks(c)
    if not rows["state_after_clear_3.0"]["alarm"]:
        enabled = op(c, "enable", address=A)
        rows["enable"] = {k: enabled.get(k) for k in ("ok", "result", "outcome", "execution", "completion")}
        time.sleep(1.5)
        rows["state_after_enable"] = blocks(c)
        ok(c, "read-identity", address=A)
        e.fresh(c, A)
        op(c, "io", driver_args=("read",), address=A)
        rows["threshold_before_restore"] = e.raw_of(op(c, "tuning", driver_args=("filters", "read"), address=A))
        restore = op(c, "tuning", driver_args=("filters", "set", "deviation-threshold", "4000"), address=A)
        rows["restore"] = dict(ok=e.write_checked(restore), outcome=restore.get("outcome"), result=restore.get("result"))
        rows["threshold_final"] = e.raw_of(op(c, "tuning", driver_args=("filters", "read"), address=A))
        rows["confirm_move"] = x.move_delta(c, A, 200)
        rows["state_final"] = blocks(c)
    c.emit("alarm_clear", rows=rows)
    for key, value in rows.items():
        print(key, json.dumps(value))


r.OUT.mkdir(parents=True, exist_ok=True)
r.session("alarm_clear", run)
