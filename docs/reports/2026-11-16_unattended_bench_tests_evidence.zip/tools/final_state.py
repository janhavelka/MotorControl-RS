"""Final read-only state of drives 1, 2 and 4 plus controller memory."""
import importlib.util, json, pathlib, sys
HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extra", HERE / "extra.py"); e = importlib.util.module_from_spec(spec); spec.loader.exec_module(e)
def run(c):
    out = {}
    for a in (2, 4, 1):
        e.select(c, a)
        b, _ = e.position(c, a)
        out[a] = dict(alarm=b[0]["raw_alarm"], motion=b[0]["raw_motion"], enabled=b[0]["enabled"], released=b[0]["released"],
                      running=b[0]["running"], position=b[2]["raw_position"], speed=b[2]["raw_speed"])
    out["memory"] = c.command("memory", timeout_s=5)
    out["drv"] = {k: v for k, v in c.command("drv", timeout_s=5).items() if k in ("recovery_required", "input_dropped", "output_blocked")}
    c.emit("final_state", state=out)
    print(json.dumps(out))
e.r.session("final_state", run)
