"""Group start spread with raw traffic copying on, then off: 20 staged + 20 sequential each."""
import importlib.util, json, pathlib, statistics, sys, time
HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extra2", HERE / "extra2.py"); x = importlib.util.module_from_spec(spec); spec.loader.exec_module(x)
r, r2, ok, note = x.r, x.r2, x.ok, x.note
def runner(label):
    def run(c):
        for a in (1, 2, 4):
            ok(c, "probe", address=a)
        r2.declare(c)
        spreads = {"staged": [], "sequential": []}
        for n in range(40):
            mode = ("staged", "sequential")[n % 2]
            ok(c, "group-read-state", timeout_s=10)
            g = ok(c, "group-move", host_args=("relative", ("1000", "-1000")[(n // 2) % 2], "steps", "native", "120",
                                               "configured", "start", mode, "on-failure", "stop", "fast"), timeout_s=30)
            spreads[mode].append(g.get("start_tx_spread_us"))
            if g.get("operation_id"):
                c.command("release", operation_id=g["operation_id"], timeout_s=5)
        ok(c, "group-clear")
        row = {m: dict(n=len(v), median=statistics.median(v), low=min(v), high=max(v)) for m, v in spreads.items()}
        c.emit("spread", label=label, spreads=spreads, summary=row)
        note(step="spread", debug=label, **row)
    return run
r.OUT.mkdir(parents=True, exist_ok=True)
r.reset_controller("spread_raw")
r.session("spread_raw", runner("raw"), debug="raw")
r.reset_controller("spread_off")
r.session("spread_off", runner("off"), debug=None)
(r.OUT / "summary.jsonl").write_text("".join(json.dumps(v) + "\n" for v in x.e.SUMMARY), encoding="utf-8")
