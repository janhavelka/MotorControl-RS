#!/usr/bin/env python3
"""Remaining unattended hardware routes on the current image (16 November 2026).

Drives 1, 2 and 4, power and RS485 only, free shafts, owner-approved risk.
RAM-only writes, each acknowledged, read back and restored. No save, no
replay: a refused or uncertain write is recorded and never resent.

Usage: extra.py OUT [STEP ...]
"""
import importlib.util
import json
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("regress", HERE / "regress.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
bp, ok, session = r.bp, r.ok, r.session
sys.path.insert(0, str(r.ROOT / "scripts"))
from bench_motion import select_drive  # noqa: E402

DRIVES = (1, 2, 4)
SUMMARY = []


def note(**fields):
    SUMMARY.append(fields)
    print(json.dumps(fields), flush=True)


def op(c, command, *, release=True, timeout_s=8, **kwargs):
    """One attempt. Release the retained result once its terminal is in the evidence."""
    result = c.command(command, timeout_s=timeout_s, **kwargs)
    if release and result.get("operation_id"):
        c.command("release", operation_id=result["operation_id"], timeout_s=5)
    return result


def fresh(c, a):
    ok(c, "read-config", address=a)
    return ok(c, "read-state", address=a)


def write_checked(result):
    rows = result.get("progress") or []
    return bool(result.get("ok")) and bool(rows) and all(
        row[4] is True and row[5] is True and row[6] == row[3] for row in rows)


def raw_of(result):
    observation = result.get("observation") or {}
    return observation.get("raw")


def select(c, a):
    select_drive(c, a, declare_unconnected=True)
    fresh(c, a)


# x01 ---------------------------------------------------------------------
def read_all(c, a):
    select(c, a)
    row = {}
    if True:
        if True:
            for name, args in (("driver", ("read",)), ("io", ("read",)), ("control", ("read",))):
                row[name] = raw_of(op(c, name, driver_args=args, address=a))
            for group in ("filters", "current-loop", "la", "collision"):
                row["tuning_" + group] = raw_of(op(c, "tuning", driver_args=(group, "read"), address=a))
            row["home"] = op(c, "home-read", address=a).get("homing_parameters")
            row["velocity"] = op(c, "velocity-read", address=a).get("velocity_parameters")
            for kind in ("position", "speed", "start"):
                for index in range(1, 17):
                    row[f"segment_{kind}_{index}"] = raw_of(op(c, "segment", driver_args=(kind, str(index), "read"), address=a))
    from bench_motion import profile_snapshot
    row["motion_profile"] = profile_snapshot(c, "read", 8)["current"]
    ok(c, "motion-profile", host_args=("forget",))
    return row


def x01_reads():
    """Every typed read on every drive: the baseline for restoration checks."""
    def run(c):
        baseline = {a: read_all(c, a) for a in DRIVES}
        c.emit("baseline", baseline=baseline)
        (r.OUT / "x01_baseline.json").write_text(json.dumps(baseline, indent=1), encoding="utf-8")
        note(step="x01_reads", drives=list(baseline))
    session("x01_reads", run)


# x02 ---------------------------------------------------------------------
def x02_aux():
    """Every homing auxiliary choice written and read back on each drive; 0 last."""
    def run(c):
        for a in DRIVES:
            select(c, a)
            for choice in (1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 0):
                fresh(c, a)
                result = c.set_homing_auxiliary(choice, timeout_s=8)
                if result.get("operation_id"):
                    c.command("release", operation_id=result["operation_id"], timeout_s=5)
                read = op(c, "home-read", address=a)["homing_parameters"]["raw_auxiliary"]
                passed = write_checked(result) and read == choice
                note(step="x02_aux", address=a, choice=choice, ok=passed, outcome=result.get("outcome"),
                     result=result.get("result"), readback=read)
                if not passed:
                    raise bp.BenchError(f"auxiliary {choice} on drive {a} not confirmed")
    session("x02_aux", run)


# x03 ---------------------------------------------------------------------
def segment_round_trip(c, a, kind, index):
    """All three scalar words changed by one native step, read back, then restored."""
    names = ("speed", "acceleration", "deceleration")
    before = raw_of(op(c, "segment", driver_args=(kind, str(index), "read"), address=a))
    offset = 0  # Observation raw is in field order: speed, acceleration, deceleration[, target pair].
    original = before[offset:offset + 3]
    changed = [value - 1 if value >= (3000 if i == 0 else 2000) else value + 1 for i, value in enumerate(original)]
    rows = {}
    for label, words in (("change", changed), ("restore", original)):
        fresh(c, a)
        op(c, "io", driver_args=("read",), address=a)  # Passive-input proof in this generation.
        op(c, "segment", driver_args=(kind, str(index), "read"), address=a)  # Exact record baseline.
        args = ("set",) + tuple(x for pair in zip(names, map(str, words)) for x in pair)
        result = op(c, "segment", driver_args=(kind, str(index)) + args, address=a)
        after = raw_of(op(c, "segment", driver_args=(kind, str(index), "read"), address=a))
        rows[label] = dict(ok=write_checked(result) and after[offset:offset + 3] == words,
                           outcome=result.get("outcome"), result=result.get("result"), after=after)
    passed = rows["change"]["ok"] and rows["restore"]["ok"]
    note(step="x03_segments", address=a, kind=kind, index=index, ok=passed, before=before,
         change=rows["change"], restore=rows["restore"])
    return passed


def x03_segments():
    def run(c):
        failures = 0
        for a in DRIVES:
            select(c, a)
            indexes = range(1, 17) if a == 1 else (1, 16)
            for kind in ("position", "speed"):
                for index in indexes:
                    failures += not segment_round_trip(c, a, kind, index)
                    if failures > 2:
                        raise bp.BenchError("repeated segment failures")
        if failures:
            raise bp.BenchError(f"{failures} segment round trips failed")
    session("x03_segments", run)


# x04 ---------------------------------------------------------------------
def x04_start_speed():
    """Deliberate rerun of the 4 October shared-start FAIL (index 1: 0 to 1 read back 0)
    with raw traffic. Each value is a new explicit write; nothing is resent."""
    def run(c):
        a = 1
        select(c, a)
        for index, value in ((1, 1), (1, 10), (1, 60), (1, 180), (2, 1), (16, 100)):
            fresh(c, a)
            op(c, "io", driver_args=("read",), address=a)
            before = raw_of(op(c, "segment", driver_args=("start", str(index), "read"), address=a))
            result = op(c, "segment", driver_args=("start", str(index), "set", "value", str(value)), address=a)
            time.sleep(0.5)
            after = raw_of(op(c, "segment", driver_args=("start", str(index), "read"), address=a))
            note(step="x04_start_speed", index=index, requested=value, before=before, after=after,
                 ok=result.get("ok"), outcome=result.get("outcome"), result=result.get("result"),
                 progress=result.get("progress"), evidence=result.get("evidence"))
            if after and after[0] != before[0]:
                fresh(c, a)
                op(c, "io", driver_args=("read",), address=a)
                op(c, "segment", driver_args=("start", str(index), "read"), address=a)
                restore = op(c, "segment", driver_args=("start", str(index), "set", "value", str(before[0])), address=a)
                final = raw_of(op(c, "segment", driver_args=("start", str(index), "read"), address=a))
                note(step="x04_start_speed_restore", index=index, value=before[0], final=final,
                     ok=restore.get("ok"), outcome=restore.get("outcome"))
    session("x04_start_speed", run)


# x05 ---------------------------------------------------------------------
def configure_facts(c, a):
    """CONFIGURE records for X0-X3 from a fresh I/O read (owner: nothing wired)."""
    raw = raw_of(op(c, "io", driver_args=("read",), address=a))
    if raw[0]:
        raise bp.BenchError("input polarity is not 0; no mapping is qualified")
    for terminal in range(4):
        ok(c, "io-qualification-install", host_args=(str(a), f"x{terminal}", str(raw[1 + terminal]), "0",
                                                       "configure", "unknown"))
    return raw


def driver_round_trip(c, a, field, candidate, original):
    rows = {}
    for label, value in (("change", candidate), ("restore", original)):
        fresh(c, a)
        op(c, "driver", driver_args=("read",), address=a)
        configure_facts(c, a)
        result = op(c, "driver", driver_args=("set", field, str(value)), address=a)
        rows[label] = dict(ok=write_checked(result), outcome=result.get("outcome"), result=result.get("result"),
                           progress=result.get("progress"))
        if not rows[label]["ok"]:
            break
    passed = all(row["ok"] for row in rows.values()) and len(rows) == 2
    note(step="x05_driver", address=a, field=field, original=original, candidate=candidate, ok=passed, **rows)
    return passed


def x05_driver():
    """Each writable single-word driver field except soft-limit (enabling needs qualified
    limits and a homed reference). No move while a field is changed."""
    fields = ("direction", "subdivision", "word-order", "soft-limit", "over-limit", "interruption", "position-mode")
    def run(c):
        failures = 0
        for a in DRIVES:
            select(c, a)
            before = raw_of(op(c, "driver", driver_args=("read",), address=a))
            note(step="x05_driver_before", address=a, raw=before)
            plan = [("over-limit", 1 - before[fields.index("over-limit")])]
            if a == 1:
                values = dict(zip(fields, before))
                subdivision = values["subdivision"]
                plan = [("direction", 1 - values["direction"]),
                        ("subdivision", 2000 if subdivision != 2000 else 1000),
                        ("word-order", 1 - values["word-order"]),
                        ("over-limit", 1 - values["over-limit"]),
                        ("interruption", 1 - values["interruption"]),
                        ("position-mode", 1 - values["position-mode"])]
            for field, candidate in plan:
                original = before[fields.index(field)]
                failures += not driver_round_trip(c, a, field, candidate, original)
            fresh(c, a)
            after = raw_of(op(c, "driver", driver_args=("read",), address=a))
            note(step="x05_driver_after", address=a, raw=after, restored=after == before)
            if after != before:
                raise bp.BenchError(f"driver settings of drive {a} not restored")
        if failures:
            raise bp.BenchError(f"{failures} driver round trips failed")
    session("x05_driver", run)


# x06 ---------------------------------------------------------------------
def position(c, a):
    state = fresh(c, a)
    blocks = {b["block"]: b for b in state["state_blocks"]}
    return blocks, state


def x06_negative_velocity():
    """Owner-approved encoding experiment: the `negative` fact is stated to test the
    two's-complement wire form the manual implies (signed RPM, function PDF p17/18)."""
    def run(c):
        for a in DRIVES:
            select(c, a)
            cases = (("60", "500", "normal"), ("-6", "500", "normal"), ("-60", "500", "normal"),
                     ("-60", "1000", "fast"), ("60", "500", "normal")) if a == 1 else (("-60", "500", "normal"), ("60", "500", "normal"))
            for rpm, duration, stop in cases:
                fresh(c, a)
                ok(c, "velocity-read", address=a)
                ok(c, "velocity-qualification-install", host_args=("rpm", "ramp", "inputs", "negative"))
                before = fresh(c, a)
                bp.velocity_campaign(c, velocity_args=(rpm, "rpm", "native", duration, "configured", stop),
                                     cleanup_stop=stop, timeout_s=10, address=a)
                time.sleep(2.0)  # Post-stop settling before the comparison read.
                after = fresh(c, a)
                note(step="x06_velocity", address=a, rpm=int(rpm), duration_ms=int(duration), stop=stop,
                     before=before.get("state_blocks"), after=after.get("state_blocks"))
    session("x06_negative_velocity", run)


def x07_compare(name="x07_compare"):
    """Full read sweep compared with the x01 baseline; reports every differing word."""
    baseline = json.loads((r.OUT / "x01_baseline.json").read_text(encoding="utf-8"))
    def run(c):
        current = {a: read_all(c, a) for a in DRIVES}
        (r.OUT / f"{name}.json").write_text(json.dumps(current, indent=1), encoding="utf-8")
        for a in DRIVES:
            for key, value in current[a].items():
                old = baseline[str(a)].get(key)
                if old != value:
                    note(step=name, address=a, key=key, baseline=old, current=value)
        note(step=name, done=True)
    session(name, run)


STEPS = [x01_reads, x02_aux, x03_segments, x04_start_speed, x05_driver, x07_compare, x06_negative_velocity]


def main():
    r.OUT.mkdir(parents=True, exist_ok=True)
    wanted = sys.argv[2:]
    with (r.OUT / "steps.jsonl").open("a", encoding="utf-8") as log:
        for step in STEPS:
            if wanted and step.__name__ not in wanted:
                continue
            started = time.time()
            try:
                step()
                status = "pass"
            except BaseException as error:  # Record, then stop the run.
                status = f"fail: {error!r}"
            log.write(json.dumps({"step": step.__name__, "status": status,
                                  "seconds": round(time.time() - started, 1)}) + "\n")
            log.flush()
            (r.OUT / "summary.jsonl").open("a", encoding="utf-8").write(
                "".join(json.dumps(row) + "\n" for row in SUMMARY))
            SUMMARY.clear()
            print(step.__name__, status, flush=True)
            if status != "pass":
                return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
