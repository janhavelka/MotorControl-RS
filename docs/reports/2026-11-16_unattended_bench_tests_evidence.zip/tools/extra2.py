#!/usr/bin/env python3
"""New-image regression, long soak, group endurance, then the two tests that can
leave a drive changed: direction with motion and a latched alarm (drive 4 last).

Same rules as extra.py. Usage: extra2.py OUT [STEP ...]
"""
import importlib.util
import json
import pathlib
import subprocess
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent


def load(name):
    spec = importlib.util.spec_from_file_location(name, HERE / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


e = load("extra")
r, r2 = e.r, load("regress2")
bp, ok, session, note, op, fresh, select, raw_of = e.bp, e.ok, e.session, e.note, e.op, e.fresh, e.select, e.raw_of
r.FIRMWARE = r.ROOT / "build/multidrive3/image_extra/firmware.bin"


def c01_regress():
    """Short regression of the new image: shared steps of the 16 November run."""
    for step in (r.s01_quick, r.s04_stop, r.s05_actions, r.s12_drives, r.s13_group, r2.t01_stack):
        step()
        note(step="c01_regress", part=step.__name__, ok=True)


def c01b_clear_and_rest():
    """Qualified zero clear on drives 2 and 4 (the return phase needs raw 0..250), then the
    parts of c01 after s05."""
    def run(c):
        for a in (2, 4):
            select(c, a)
            before = fresh(c, a)
            ok(c, "position-clear-qualification-install", host_args=("clear-semantics",))
            cleared = ok(c, "position-clear", address=a)
            after = bp.observe_stopped(c, address=a, timeout_s=8)
            c.emit("position_clear", address=a, before=before, cleared=cleared, after=after)
            note(step="c01b_clear", address=a, before=e.position(c, a)[0][2]["raw_position"])
        ok(c, "useaddr", address=1)
    session("c01b_clear", run)
    for step in (r.s12_drives, r.s13_group, r2.t01_stack):
        step()
        note(step="c01_regress", part=step.__name__, ok=True)


def stress(name, seconds, seed):
    out = r.OUT / name
    with (r.OUT / f"{name}.stdout").open("w", encoding="utf-8") as stream:
        code = subprocess.run([sys.executable, str(r.ROOT / "scripts/bench_stress.py"), "--out", str(out),
                               "--duration", str(seconds), "--seed", str(seed), "--mix", "extended",
                               "--addresses", "1,2,4", "--cross-reads", "--declare-unconnected"],
                              stdout=stream, stderr=subprocess.STDOUT).returncode
    note(step=name, exit=code)
    if code:
        raise SystemExit(f"{name} exit {code}")


def c02_soak():
    stress("c02_soak_8h", 8 * 3600, 116)


def c03_group_endurance(seconds=3600):
    """Repeated group moves (staged and sequential, both directions) with a group stop
    every tenth case; stack and heap sampled throughout. One attempt per case."""
    r.reset_controller("c03_group_endurance")
    def run(c):
        for a in e.DRIVES:
            ok(c, "probe", address=a)
        r2.declare(c)
        started, n, rows = time.time(), 0, []
        while time.time() - started < seconds:
            n += 1
            mode = ("staged", "sequential")[n % 2]
            ok(c, "group-read-state", timeout_s=10)
            if n % 10 == 0:
                move = c.begin("group-move", host_args=("relative", "4000", "steps", "native", "120", "configured",
                                                        "start", mode, "on-failure", "stop", "fast"), timeout_s=30)
                time.sleep(0.8)
                stop = c.command("group-stop", host_args=(("normal", "fast")[n // 10 % 2],), timeout_s=10)
                result = c.wait(move)
                time.sleep(2.0)  # Post-stop settling.
                row = dict(n=n, kind="stop", mode=mode, stop_ok=stop.get("ok"), move_outcome=result.get("outcome"))
                for handle_id in (stop.get("operation_id"), result.get("operation_id")):
                    if handle_id:
                        c.command("release", operation_id=handle_id, timeout_s=5)
                if not stop.get("ok"):
                    raise bp.BenchError(f"group stop {n} failed")
            else:
                steps = ("1000", "-1000")[(n // 2) % 2]
                g = ok(c, "group-move", host_args=("relative", steps, "steps", "native", "120", "configured",
                                                   "start", mode, "on-failure", "stop", "fast"), timeout_s=30)
                row = dict(n=n, kind="move", mode=mode, steps=int(steps), spread_us=g.get("start_tx_spread_us"))
                if n <= 12:  # Member transaction times, to split the start spread (no observer drops).
                    row["member_steps"] = {}
                    for m in g["members"]:
                        if m.get("operation_id"):
                            view = c.command("result", operation_id=m["operation_id"], timeout_s=5)
                            row["member_steps"][m["address"]] = [
                                {k: step.get(k) for k in ("step", "tx", "rx", "attempted_us", "earliest_us", "latest_us",
                                                          "delivered_us", "tx_accepted")}
                                for step in view.get("steps") or []]
                if g.get("operation_id"):
                    c.command("release", operation_id=g["operation_id"], timeout_s=5)
            if n % 25 == 0:
                memory = c.command("memory", timeout_s=5)
                row["stack_free"] = memory.get("stack_free_bytes")
                row["internal_min"] = memory.get("internal_min")
            rows.append(row)
        memory = c.command("memory", timeout_s=5)
        c.emit("group_endurance", rows=rows, memory=memory)
        spreads = sorted(x["spread_us"] for x in rows if x.get("spread_us") is not None and x["mode"] == "staged")
        sequential = sorted(x["spread_us"] for x in rows if x.get("spread_us") is not None and x["mode"] == "sequential")
        note(step="c03_group_endurance", cases=n, stops=sum(x["kind"] == "stop" for x in rows),
             staged_median=spreads[len(spreads) // 2] if spreads else None,
             sequential_median=sequential[len(sequential) // 2] if sequential else None,
             stack_free=memory.get("stack_free_bytes"), internal_min=memory.get("internal_min"))
        ok(c, "group-clear")
    session("c03_group_endurance", run, debug=None)


def move_delta(c, a, steps, rpm=60):
    from bench_motion import profile_snapshot
    before = e.position(c, a)[0][2]["raw_position"]
    profile_snapshot(c, "read", 8)  # A configured move needs a checked position profile.
    result = c.command("move-relative", move_args=(str(steps), "steps", "native", str(rpm), "configured"),
                       address=a, timeout_s=20)
    if result.get("operation_id"):
        c.command("release", operation_id=result["operation_id"], timeout_s=5)
    c.command("motion-profile", host_args=("forget",), timeout_s=5)
    time.sleep(2.0)
    blocks = e.position(c, a)[0]
    return dict(ok=result.get("ok"), outcome=result.get("outcome"), result=result.get("result"),
                delta=blocks[2]["raw_position"] - before, alarm=blocks[0]["raw_alarm"])


def d01_direction():
    """Drive 4: a native move with direction reversed, then normal again. Feedback
    sign only; without shaft observation the physical direction stays unmeasured."""
    def run(c):
        a = 4
        select(c, a)
        rows = dict(normal=move_delta(c, a, 200))
        for label, value in (("reverse", 1), ("restore", 0)):
            fresh(c, a)
            op(c, "driver", driver_args=("read",), address=a)
            e.configure_facts(c, a)
            result = op(c, "driver", driver_args=("set", "direction", str(value)), address=a)
            rows[label + "_write"] = dict(ok=e.write_checked(result), outcome=result.get("outcome"))
            if not e.write_checked(result):
                raise bp.BenchError(f"direction {value} not confirmed")
            rows[label + "_move"] = move_delta(c, a, 200)
        note(step="d01_direction", **rows)
    session("d01_direction", run)


def d02_alarm():
    """Drive 4: lower the position-error threshold, latch alarm 5 with one faster move,
    stop, then alarm-clear. If the alarm clears, restore 4000 and confirm a move. If it
    does not (hardware manual: re-power reset), leave it for the owner's power cycle."""
    def run(c):
        a = 4
        select(c, a)
        rows = {}
        ok(c, "read-identity", address=a)  # The tuning gate needs this drive's exact identity.
        fresh(c, a)
        op(c, "io", driver_args=("read",), address=a)
        rows["threshold_before"] = raw_of(op(c, "tuning", driver_args=("filters", "read"), address=a))
        result = op(c, "tuning", driver_args=("filters", "set", "deviation-threshold", "1"), address=a)
        rows["lower"] = dict(ok=e.write_checked(result), outcome=result.get("outcome"), result=result.get("result"))
        if not e.write_checked(result):
            raise bp.BenchError("threshold not lowered")
        time.sleep(1.0)
        blocks, state = e.position(c, a)
        rows["state_after_lower"] = state.get("state_blocks")
        for steps, rpm in ((2000, 60), (3000, 300)):
            if blocks[0]["raw_alarm"]:
                break
            rows[f"move_{rpm}"] = move_delta(c, a, steps, rpm)
            blocks, state = e.position(c, a)
        rows["stop"] = bp.cleanup_stop_attempts(c, policy="fast", address=a, timeout_s=8)
        time.sleep(1.0)
        blocks, latched = e.position(c, a)
        rows["state_latched"] = latched.get("state_blocks")
        rows["alarm_code"] = blocks[0]["raw_alarm"]
        if not rows["alarm_code"]:
            note(step="d02_alarm", latched=False, **rows)
            raise bp.BenchError("no alarm latched with threshold 1")
        clear = op(c, "alarm-clear", address=a)
        rows["clear"] = dict(ok=clear.get("ok"), outcome=clear.get("outcome"), result=clear.get("result"),
                             execution=clear.get("execution"), completion=clear.get("completion"))
        time.sleep(1.0)
        blocks, after = e.position(c, a)
        rows["state_after_clear"] = after.get("state_blocks")
        cleared = not blocks[0]["raw_alarm"]
        rows["cleared"] = cleared
        if cleared:
            enabled = op(c, "enable", address=a)
            rows["enable"] = dict(ok=enabled.get("ok"), outcome=enabled.get("outcome"))
            time.sleep(1.5)
            ok(c, "read-identity", address=a)
            fresh(c, a)
            op(c, "io", driver_args=("read",), address=a)
            op(c, "tuning", driver_args=("filters", "read"), address=a)
            restore = op(c, "tuning", driver_args=("filters", "set", "deviation-threshold", "4000"), address=a)
            rows["restore"] = dict(ok=e.write_checked(restore), outcome=restore.get("outcome"))
            rows["threshold_final"] = raw_of(op(c, "tuning", driver_args=("filters", "read"), address=a))
            rows["confirm_move"] = move_delta(c, a, 200)
        note(step="d02_alarm", **rows)
    session("d02_alarm", run)


STEPS = [c01_regress, c01b_clear_and_rest, c02_soak, c03_group_endurance, d01_direction, d02_alarm]


def main():
    r.OUT.mkdir(parents=True, exist_ok=True)
    wanted = sys.argv[2:]
    with (r.OUT / "steps.jsonl").open("a", encoding="utf-8") as log:
        for step in STEPS:
            if wanted and step.__name__ not in wanted:
                continue
            started = time.time()
            try:
                step()
                status = "pass"
            except BaseException as error:
                status = f"fail: {error!r}"
            log.write(json.dumps({"step": step.__name__, "status": status,
                                  "seconds": round(time.time() - started, 1)}) + "\n")
            log.flush()
            with (r.OUT / "summary.jsonl").open("a", encoding="utf-8") as summary:
                summary.write("".join(json.dumps(row) + "\n" for row in e.SUMMARY))
            e.SUMMARY.clear()
            print(step.__name__, status, flush=True)
            if status != "pass":
                return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
