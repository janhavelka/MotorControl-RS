#!/usr/bin/env python3
"""Deliberate rerun of d02's silent poll on drive 4, with diagnostics.

Each attempt: threshold 1, one 2000-step 60 rpm move (one attempt, never resent).
After the move ends: host counters, one recovery if required, then probes until the
drive answers, timed on the controller clock. Then stop fast, alarm-clear, enable,
threshold 4000 and one confirming 200-step move. Usage: diag_silence.py OUT [ATTEMPTS]
"""
import importlib.util
import json
import sys
import time

HERE = __import__("pathlib").Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("extra2", HERE / "extra2.py")
x = importlib.util.module_from_spec(spec)
spec.loader.exec_module(x)
e, r, bp, ok, op = x.e, x.r, x.bp, x.ok, x.op
from bench_motion import profile_snapshot  # noqa: E402
A = int(__import__("os").environ.get("SILENCE_DRIVE", "4"))
ATTEMPTS = int(sys.argv[2]) if len(sys.argv) > 2 else 2
OTHER = int(sys.argv[3]) if len(sys.argv) > 3 else 0  # Probe this drive before each drive 4 probe.
KEYS = ("ok", "result", "outcome", "status", "detail", "execution", "completion")


def blocks(c):
    b, _ = e.position(c, A)
    return dict(alarm=b[0]["raw_alarm"], motion=b[0]["raw_motion"], released=b[0]["released"],
                enabled=b[0]["enabled"], position=b[2]["raw_position"], speed=b[2]["raw_speed"])


def set_threshold(c, value):
    ok(c, "read-identity", address=A)
    e.fresh(c, A)
    op(c, "io", driver_args=("read",), address=A)
    op(c, "tuning", driver_args=("filters", "read"), address=A)
    result = op(c, "tuning", driver_args=("filters", "set", "deviation-threshold", str(value)), address=A)
    if not e.write_checked(result):
        raise bp.BenchError(f"threshold {value} not confirmed: {result.get('outcome')}")


def attempt(c, n):
    row = {"n": n}
    set_threshold(c, 1)
    row["state_before"] = blocks(c)
    row["drv_before"] = c.command("drv", timeout_s=5)
    profile_snapshot(c, "read", 8)
    move = c.command("move-relative", move_args=("2000", "steps", "native", "60", "configured"),
                     address=A, timeout_s=20)
    row["move"] = {k: move.get(k) for k in KEYS + ("polls", "running_observed", "raw_alarm", "raw_motion",
                                                   "trigger_evidence", "failure_evidence", "last_observation",
                                                   "started_us", "serviced_us")}
    row["drv_after"] = c.command("drv", timeout_s=5)
    row["stats"] = c.command("stats", timeout_s=5)
    if move.get("operation_id"):
        c.command("release", operation_id=move["operation_id"], timeout_s=5)
    c.command("motion-profile", host_args=("forget",), timeout_s=5)
    row["probes"] = []
    started = time.time()
    while time.time() - started < 10:
        if row["drv_after"].get("recovery_required") or (row["probes"] and row["probes"][-1].get("result") == "recovery_required"):
            recovered = c.command("recover", timeout_s=8)
            row.setdefault("recoveries", []).append({k: recovered.get(k) for k in KEYS})
            row["drv_after"] = {}
        answered = False
        for address in ((OTHER, A) if OTHER else (A,)):
            probe = c.command("probe", address=address, timeout_s=5)
            row["probes"].append(dict(address=address, host_s=round(time.time() - started, 3), ok=probe.get("ok"),
                                      result=probe.get("result"), outcome=probe.get("outcome"),
                                      transport=probe.get("transport"), tx_end_us=probe.get("tx_end_us"),
                                      received=probe.get("rx_bytes"), frame_error=probe.get("frame_error")))
            if probe.get("operation_id"):
                c.command("release", operation_id=probe["operation_id"], timeout_s=5)
            if not probe.get("ok"):
                break  # The owner now needs recovery before any other request.
            answered = address == A
        if answered:
            break
        time.sleep(0.05)
    row["state_latched"] = blocks(c)
    stop = op(c, "stop", stop_policy="fast", address=A)
    row["stop"] = {k: stop.get(k) for k in KEYS}
    time.sleep(0.5)
    clear = op(c, "alarm-clear", address=A)
    row["clear"] = {k: clear.get(k) for k in KEYS}
    time.sleep(1.0)
    row["state_cleared"] = blocks(c)
    if row["state_cleared"]["alarm"]:
        raise bp.BenchError("alarm did not clear")
    if not row["state_cleared"]["enabled"]:
        enabled = op(c, "enable", address=A)
        row["enable"] = {k: enabled.get(k) for k in KEYS}
    time.sleep(1.5)
    set_threshold(c, 4000)
    row["threshold_final"] = e.raw_of(op(c, "tuning", driver_args=("filters", "read"), address=A))
    row["confirm_move"] = x.move_delta(c, A, 200)
    e.note(step="diag_silence", n=n, move_outcome=row["move"].get("outcome"), polls=row["move"].get("polls"),
           failure=(row["move"].get("failure_evidence") or {}).get("received_length"),
           probes=[(p["address"], p["host_s"], p["ok"], p.get("result") or p.get("transport") or p.get("outcome"), p["tx_end_us"]) for p in row["probes"]],
           trigger_us=(row["move"].get("trigger_evidence") or {}).get("latest_us"),
           latched=row["state_latched"], cleared=row["state_cleared"], threshold=row["threshold_final"][2],
           confirm=row["confirm_move"])
    return row


def run(c):
    e.select(c, A)
    rows = []
    for n in range(1, ATTEMPTS + 1):
        rows.append(attempt(c, n))
        c.emit("silence_attempt", row=rows[-1])
    return rows


r.OUT.mkdir(parents=True, exist_ok=True)
r.session("diag_silence", run)
(r.OUT / "summary.jsonl").write_text("".join(json.dumps(x) + "\n" for x in e.SUMMARY), encoding="utf-8")
