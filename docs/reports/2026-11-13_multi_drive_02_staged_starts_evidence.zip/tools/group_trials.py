#!/usr/bin/env python3
"""Multi-drive 02 on the bench: several drives moving at the same time by unicast.

Drives 1, 2 and 4, power and RS485 only, free shafts. Finite moves only, within
the default position policy. Counts are fixed in advance:
  G1  5 group moves of +1000 increments at 60 rpm, on-failure stop fast
  G2  5 group moves of -2000 at 120 rpm, on-failure stop normal
  G3  5 group moves of +6000 at 600 rpm, on-failure stop fast
  G4  5 group stop normal and 5 group stop fast during a +5000 move at 120 rpm
  G5  optional timed soak: random G1-G4 cases until --soak-s elapses
Every case reads every member before and after; a member that does not end
where its own evidence says is an anomaly and stops the run. No write is resent.
A group stop is the prepared fallback when a member still runs after its bound.
"""
import argparse
import importlib.util
import json
import pathlib
import random
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location("bench_stress", ROOT / "build/multidrive2/snap/scripts/bench_stress.py")
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("broadcast_trials", HERE / "broadcast_trials.py")
trials = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trials)

MEMBERS = (1, 2, 4)
RUNNING = bench.RUNNING


class Stop(Exception):
    pass


def signed(value):
    value &= 0xFFFFFFFF
    return value - 0x100000000 if value > 0x7FFFFFFF else value


class Group:
    def __init__(self, console, out):
        self.c, self.out = console, out
        self.file = open(out / "cases.jsonl", "a", encoding="utf-8")
        self.counts = {}
        self.moved = 0

    def record(self, entry):
        entry = dict(entry, t=round(time.time(), 3))
        self.file.write(json.dumps(entry) + "\n")
        self.file.flush()
        short = {k: v for k, v in entry.items() if k not in ("terminal", "stop_terminal")}
        print(json.dumps(short)[:700])
        sys.stdout.flush()

    def command(self, text, wait=8.0):
        reply = self.c.send(text, 3.0)
        if not reply.get("ok"):
            raise Stop({"command": text, "result": reply.get("result"), "address": reply.get("address")})
        if reply.get("result") in ("accepted",):
            item = self.c.terminal(reply, wait)
            self.c.release_all()
            if item is None:
                raise Stop({"command": text, "terminal": None})
            return reply, item
        return reply, None

    def release(self, operation):
        if operation:
            self.c.send(f"release {operation}", 2.0)

    def setup(self):
        reply, item = self.command("group set " + " ".join(str(a) for a in MEMBERS), 10.0)
        if not item.get("ok"):
            raise Stop({"group set": item})
        self.release(reply.get("operation_id"))
        self.record({"case": "set", "members": item.get("members")})
        for a in MEMBERS:  # Owner fact: only power and RS485 are wired.
            for t in ("x0", "x1", "x2", "x3", "y0", "y1"):
                self.command(f"group wiring {a} {t} unconnected")

    def states(self):
        reply, item = self.command("group read state", 6.0)
        if not item.get("ok"):
            raise Stop({"group read state": item})
        self.release(reply.get("operation_id"))
        out = {}
        for m in item["members"]:
            if not m.get("state_known") or not m.get("position_known"):
                raise Stop({"state unknown": m})
            if m.get("raw_alarm"):
                raise Stop({"alarm": m})
            out[m["address"]] = m
        return out

    def settled(self):
        """Wait out post-stop settling: two reads 2 s apart with identical positions."""
        first = self.states()
        for _ in range(4):
            time.sleep(2.0)
            second = self.states()
            if all(second[a]["raw_position"] == first[a]["raw_position"] for a in MEMBERS) and \
                    not any(second[a]["raw_motion"] & RUNNING for a in MEMBERS):
                return second
            first = second
        raise Stop({"not settled": first})

    def move(self, steps, rpm, policy, start=None):
        before = self.settled()
        mode = f" start {start}" if start else ""
        text = f"group move relative {steps} steps native {rpm} configured{mode} on-failure {policy}"
        duration = abs(steps) / (rpm * 1000 / 60) + 6 + 0.6 * len(MEMBERS)
        reply, item = self.command(text, duration)
        after = self.settled()
        deltas = {a: signed(after[a]["raw_position"] - before[a]["raw_position"]) for a in MEMBERS}
        ok = item.get("ok") and all(abs(d - steps) <= 20 for d in deltas.values())
        self.record({"case": "move", "start": (item.get("request") or {}).get("start"), "steps": steps, "rpm": rpm,
                     "policy": policy, "ok": bool(item.get("ok")),
                     "stages": {m["address"]: [m.get("stage"), m.get("stage_readback"), m.get("stage_tx_end_us")]
                                for m in item.get("members", [])},
                     "deltas": deltas, "start_tx_spread_us": item.get("start_tx_spread_us"),
                     "running_bound_spread_us": item.get("running_bound_spread_us"),
                     "starts": {m["address"]: [m.get("start"), m.get("start_tx_end_us"), m.get("running_earliest_us"),
                                                m.get("running_latest_us")] for m in item.get("members", [])},
                     "terminal": item})
        self.release(reply.get("operation_id"))
        if not ok:
            raise Stop({"group move": text, "ok": item.get("ok"), "deltas": deltas,
                        "members": [{k: m.get(k) for k in ("address", "start", "state", "outcome", "uncertain", "status")}
                                    for m in item.get("members", [])]})
        self.moved += abs(steps) * len(MEMBERS)
        return deltas

    def stop_mid_move(self, policy, steps=5000, rpm=120, delay=1.0):
        before = self.settled()
        text = f"group move relative {steps} steps native {rpm} configured on-failure stop fast"
        reply = self.c.send(text, 3.0)
        if not reply.get("ok"):
            raise Stop({"command": text, "result": reply.get("result")})
        time.sleep(delay)
        stop_reply = self.c.send(f"group stop {policy}", 3.0)
        if not stop_reply.get("ok"):
            raise Stop({"group stop": stop_reply.get("result")})
        stop = self.c.terminal(stop_reply, 8.0)
        move = self.c.terminal(reply, 15.0)
        self.c.release_all()
        after = self.settled()
        deltas = {a: signed(after[a]["raw_position"] - before[a]["raw_position"]) for a in MEMBERS}
        stopped = bool(stop and stop.get("ok"))
        short = all(0 < d < steps for d in deltas.values())
        self.record({"case": "stop", "policy": policy, "stop_ok": stopped, "deltas": deltas,
                     "spread": max(deltas.values()) - min(deltas.values()),
                     "move_ok": move and move.get("ok"),
                     "members": [{k: m.get(k) for k in ("address", "start", "interrupted_by_stop", "outcome", "uncertain")}
                                 for m in (move or {}).get("members", [])],
                     "stop_members": [{k: m.get(k) for k in ("address", "state", "outcome", "execution", "completion",
                                                             "raw_motion")} for m in (stop or {}).get("members", [])],
                     "terminal": move, "stop_terminal": stop})
        self.release(reply.get("operation_id"))
        self.release(stop_reply.get("operation_id"))
        if not stopped or not short:
            raise Stop({"group stop": policy, "stop": stop and stop.get("ok"), "deltas": deltas})
        self.moved += sum(abs(d) for d in deltas.values())

    def fixed(self):
        for _ in range(5):
            self.move(1000, 60, "stop fast", "staged")
        for _ in range(5):
            self.move(1000, 60, "stop fast", "sequential")
        for _ in range(5):
            self.move(1000, 60, "stop fast")  # Default mode
        for _ in range(5):
            self.move(-2000, 120, "stop normal")
        for _ in range(5):
            self.move(6000, 600, "stop fast")
        for policy in ("normal", "fast"):
            for _ in range(5):
                self.stop_mid_move(policy)

    def soak(self, seconds, seed):
        rng = random.Random(seed)
        end = time.time() + seconds
        n = 0
        while time.time() < end:
            n += 1
            kind = rng.choice(["move", "move", "move", "stop"])
            if kind == "move":
                steps = rng.choice([200, 1000, 3000, 6000]) * rng.choice([1, -1])
                rpm = rng.choice([60, 120, 300, 600])
                self.move(steps, rpm, rng.choice(["stop fast", "stop normal", "leave"]),
                          rng.choice(["staged", "staged", "staged", "sequential"]))
            else:
                self.stop_mid_move(rng.choice(["normal", "fast"]), delay=rng.uniform(0.4, 1.6))
            self.counts[kind] = self.counts.get(kind, 0) + 1
        return n


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    parser.add_argument("--fixed", action="store_true")
    parser.add_argument("--soak-s", type=float, default=0)
    parser.add_argument("--seed", type=int, default=61)
    args = parser.parse_args()
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    log = open(out / "console.jsonl", "w", encoding="utf-8")
    console = trials.Logged("COM13", out, log)
    group = Group(console, out)
    started = time.time()
    code = 0
    summary = {}
    try:
        console.pump(0.3)
        summary["version"] = console.send("version", 3.0)
        console.send("debug off", 2.0)
        group.setup()
        if args.fixed:
            group.fixed()
        if args.soak_s:
            summary["soak_cases"] = group.soak(args.soak_s, args.seed)
        summary["final"] = group.settled()
    except Stop as stop:
        code = 3
        group.record({"case": "anomaly", "reason": str(stop)[:4000]})
        try:
            summary["final"] = group.states()
        except Exception as error:
            summary["capture_failed"] = repr(error)
    except bench.Unresponsive as error:
        code = 4
        group.record({"case": "unresponsive", "reason": str(error)})
    finally:
        try:
            summary["memory"] = console.send("memory", 2.0)
            summary["drv"] = console.send("drv", 2.0)
        except Exception:
            pass
        summary.update(code=code, elapsed_s=round(time.time() - started), counts=group.counts, moved=group.moved)
        (out / "summary.json").write_text(json.dumps(summary, indent=1, default=str))
        log.close()
        console.close()
    print(json.dumps({k: summary.get(k) for k in ("code", "elapsed_s", "counts", "moved", "soak_cases")}))
    return code


if __name__ == "__main__":
    sys.exit(main())
