This diagnostic asserts the existing defect, not corrected behavior.
Built with: cmake -S build/group_review_enable_repro -B build/group_review_enable_repro/native -G Ninja
cmake --build build/group_review_enable_repro/native --target repro
Run native/repro.exe. The archived paths name the original checkout; replace that prefix for relocation.
The source manifest covers the inspected working tree. Relevant snapshots below preserve concurrent edits used by the fixture.
