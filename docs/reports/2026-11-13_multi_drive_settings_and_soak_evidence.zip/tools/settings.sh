#!/bin/bash
# Settings write tests (input filter, lock delay) per drive, each restored; stops at the first failure.
FW=build/multidrive2/image_0984e14/firmware.bin
OUT=build/multidrive2/81_settings
mkdir -p $OUT
for a in $1; do
  for spec in "input-filter 3" "lock-delay 201"; do
    set -- $spec
    name=a${a}_$1
    python build/multidrive2/snap/scripts/bench_scenarios.py --address $a --scenario settings --setting $1 --value $2 --declare-unconnected --out $OUT/$name --firmware $FW > $OUT/$name.stdout 2>&1
    code=$?
    echo "a$a $spec -> $code"
    if [ $code -ne 0 ]; then tail -8 $OUT/$name.stdout; exit $code; fi
  done
done
echo ALL_OK
