#include "C:/Users/Honza/Documents/Projects/MotorControl-RS/examples/probe_cli/ProbeApp.cpp"
extern "C" {
char m09_size_App[sizeof(App)];
char m09_size_GroupMember[sizeof(App::GroupMember)];
char m09_size_GroupMemberMoves[sizeof(Probe::GroupMemberMoves)];
char m09_size_GroupReference[sizeof(Probe::GroupReference)];
char m09_size_GroupMemberResult[sizeof(Probe::GroupMemberResult)];
char m09_size_GroupResult[sizeof(Probe::GroupResult)];
char m09_size_GroupView[sizeof(Probe::GroupView)];
char m09_size_GroupCommand[sizeof(Probe::GroupCommand)];
char m09_size_Console[sizeof(Probe::Console)];
char m09_size_GroupOperation[sizeof(App::GroupOperation)];
char m09_size_Record[sizeof(App::Record)];
char m09_size_StageSession[sizeof(App::StageSession)];
}
