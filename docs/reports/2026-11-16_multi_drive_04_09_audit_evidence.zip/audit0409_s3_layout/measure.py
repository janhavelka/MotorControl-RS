import concurrent.futures
import ctypes
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DATABASE = ROOT / "compile_commands.json"
shell32 = ctypes.windll.shell32
shell32.CommandLineToArgvW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_int)]
shell32.CommandLineToArgvW.restype = ctypes.POINTER(ctypes.c_wchar_p)
kernel32 = ctypes.windll.kernel32
kernel32.LocalFree.argtypes = [ctypes.c_void_p]
kernel32.LocalFree.restype = ctypes.c_void_p


def windows_arguments(command):
    count = ctypes.c_int()
    pointer = shell32.CommandLineToArgvW(command, ctypes.byref(count))
    if not pointer:
        raise OSError("CommandLineToArgvW failed")
    try:
        return [pointer[index] for index in range(count.value)]
    finally:
        kernel32.LocalFree(pointer)


def response_argument(argument):
    # GCC response files use libiberty quoting, not Windows shell quoting.
    return '"' + argument.replace('\\', '\\\\').replace('"', '\\"') + '"'


entries = {}
for entry in json.loads(DATABASE.read_text(encoding="utf-8")):
    if Path(entry["file"]).name in ("ProbeApp.cpp", "ProbeConsole.cpp"):
        entries[Path(entry["file"]).name] = entry
assert set(entries) == {"ProbeApp.cpp", "ProbeConsole.cpp"}

types = {
    "App": "App", "GroupMember": "App::GroupMember",
    "GroupMemberMoves": "Probe::GroupMemberMoves", "GroupReference": "Probe::GroupReference",
    "GroupMemberResult": "Probe::GroupMemberResult", "GroupResult": "Probe::GroupResult",
    "GroupView": "Probe::GroupView", "GroupCommand": "Probe::GroupCommand",
    "Console": "Probe::Console", "GroupOperation": "App::GroupOperation",
    "Record": "App::Record", "StageSession": "App::StageSession",
}
measurement = OUT / "layout.cpp"
measurement.write_text(
    '#include "' + (ROOT / "examples/probe_cli/ProbeApp.cpp").as_posix() + '"\n'
    + 'extern "C" {\n'
    + ''.join('char m09_size_' + name + '[sizeof(' + type_name + ')];\n' for name, type_name in types.items())
    + '}\n', encoding="utf-8")


def compile_source(key, source, stem):
    entry = entries[key]
    original = windows_arguments(entry["command"])
    compiler, arguments = original[0], original[1:]
    output = OUT / (stem + ".o")
    arguments[arguments.index("-o") + 1] = str(output)
    source_index = next(index for index, argument in enumerate(arguments)
                        if Path(argument).as_posix() == Path(entry["file"]).as_posix())
    arguments[source_index] = str(source)
    arguments += ["-fstack-usage"]
    response = OUT / (stem + ".rsp")
    response.write_text("\n".join(response_argument(argument) for argument in arguments) + "\n", encoding="utf-8")
    result = subprocess.run([compiler, "@" + str(response)], cwd=entry["directory"],
                            capture_output=True, text=True, errors="replace")
    (OUT / (stem + ".log")).write_text(result.stdout + result.stderr, encoding="utf-8")
    record = {"compiler": compiler, "directory": entry["directory"], "original_arguments": original[1:],
              "measurement_arguments": arguments, "response_file": str(response), "exit_code": result.returncode}
    (OUT / (stem + ".flags.json")).write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps({"source": stem, "exit_code": result.returncode, "argument_count": len(arguments)}), flush=True)
    if result.returncode:
        raise RuntimeError(stem + " compilation failed; see " + str(OUT / (stem + ".log")))
    return compiler, output


jobs = [("ProbeApp.cpp", ROOT / "examples/probe_cli/ProbeApp.cpp", "ProbeApp"),
        ("ProbeConsole.cpp", ROOT / "examples/probe_cli/ProbeConsole.cpp", "ProbeConsole"),
        ("ProbeApp.cpp", measurement, "layout")]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(lambda job: compile_source(*job), jobs))

compiler = Path(results[0][0])
nm = compiler.with_name(compiler.name.replace("g++", "nm"))
nm_result = subprocess.run([str(nm), "-S", str(OUT / "layout.o")], capture_output=True, text=True, check=True)
(OUT / "layout.nm.txt").write_text(nm_result.stdout, encoding="utf-8")
sizes = {}
for line in nm_result.stdout.splitlines():
    match = re.fullmatch(r"[0-9a-fA-F]+ ([0-9a-fA-F]+) [A-Za-z] m09_size_(\w+)", line)
    if match:
        sizes[match.group(2)] = int(match.group(1), 16)
assert set(sizes) == set(types)

source_files = subprocess.check_output(["git", "ls-files", "include", "src", "examples"], cwd=ROOT, text=True).splitlines()
source_hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                 for name in source_files if (ROOT / name).is_file()}
# A new header may not be staged yet.
for path in (ROOT / "examples/probe_cli").glob("*.h"):
    source_hashes[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
summary = {
    "compiler": str(compiler), "compiler_version": subprocess.check_output([str(compiler), "--version"], text=True).splitlines()[0],
    "compile_database_sha256": hashlib.sha256(DATABASE.read_bytes()).hexdigest(),
    "sizes": sizes, "source_sha256": source_hashes,
    "limits": "Actual bench_s3_load_timer SDK compile flags. Static sizes and individual GCC stack frames, not a runtime high-water mark or full call-chain bound.",
}
(OUT / "results.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps({"compiler_version": summary["compiler_version"], "sizes": sizes}), flush=True)
