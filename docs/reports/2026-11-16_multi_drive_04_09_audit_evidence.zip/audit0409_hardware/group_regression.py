"""Prepared M09 three-drive bench regression. No flashing and no write replay.

Run only after the lead flashes and records the supplied image. --plan-only
prints the bounded traffic plan without enumerating or opening a serial port.
"""
import argparse
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from bench_probe import (BenchError, drive_reported_stopped, observe_stopped,
                         open_port, profile_archive, profile_archive_arguments,
                         save_profile_archive, PROFILE_ARCHIVE_SCHEMA)
from bench_motion import profile_snapshot
from bench_session import checked, run_recorded

ADDRESSES = (1, 2, 4)
TERMINALS = ("x0", "x1", "x2", "x3", "y0", "y1")
USB = dict(port="COM13", vid=0x303A, pid=0x1001, serial="3C:0F:02:CD:6B:98")
CASES = (("distinct_staged", "staged", (100, -150, 200)),
         ("inverse_sequential", "sequential", (-100, 150, -200)),
         ("urgent_group_stop", "staged", (300, 400, 500)))
PLAN = [
    "Check COM13 USB 303A:1001 serial 3C:0F:02:CD:6B:98; open it once.",
    "Version and cached host/config/status/health/stats/load/drv/memory/wiring; debug raw.",
    "Require idle fresh-image group/result/profile state; group clear and plan clear (local).",
    "For 1,2,4: useaddr; declare X0..X3/Y0..Y1 unconnected locally; identity/config/state reads; read and archive all six 0x0020 profile words; forget only local snapshot.",
    "Keep drive 4 selected/configured. group set 1 2 4; declare group terminals unconnected; group set 1 2 4 again to bind wiring; group read state.",
    "Staged plan {1:+100,2:-150,4:+200} native steps at 60 rpm, configured ramps, on-failure stop fast; inspect independent terminal and release.",
    "Fresh group state. Sequential plan {1:-100,2:+150,4:-200}, same speed/policy; inspect terminal and release.",
    "Fresh group state. Staged plan {1:+300,2:+400,4:+500}; at most ten gate polls 20 ms apart: local group status, then fresh read-state 4 only after sequencing=false. Require fresh RUNNING.",
    "One explicit group stop fast; retain and inspect stop and interrupted move separately. No retry if RUNNING is NOT_OBSERVED.",
    "After confirmed stop/known writes: up to ten fresh state reads per drive, 50 ms apart, for stopped/alarm-free/zero speed.",
    "For 1,2,4: fresh selected identity/config/profile/state; skip candidate when all six words already match, otherwise stage saved five 0x0021 words once; refresh config before rereading all six 0x0020 words and compare exactly; forget only local snapshot.",
    "Select 1, refresh config/state; clear local group; final cached diagnostics and restore debug display; close the one connection.",
    "Unexpected failure: retain original result/archive; at most one prepared group fast stop if no stop was attempted and framing/evidence remain usable. No restore after unexpected failure or UNKNOWN write. No recovery, persistence, enable, absolute move or automatic replay.",
]


def require(condition, message):
    if not condition:
        raise BenchError(message)


def exact_port(name, baud, timeout_s):
    from serial.tools import list_ports
    ports = [p for p in list_ports.comports() if p.device.upper() == USB["port"]]
    require(name.upper() == USB["port"] and len(ports) == 1, "recorded COM13 is missing or ambiguous")
    p = ports[0]
    require((p.vid, p.pid, p.serial_number) == (USB["vid"], USB["pid"], USB["serial"]),
            "COM13 USB identity differs; no port opened")
    return open_port(name, baud, timeout_s)


def blocks(state):
    return {b["block"]: b for b in state["state_blocks"]}


def stopped(state):
    motion = blocks(state)[0]
    return drive_reported_stopped(state) and not motion["released"] and not motion["unknown_motion_bits"]


def select(console, address):
    checked(console, "useaddr", address=address)
    for terminal in TERMINALS:
        checked(console, "wiring", host_args=(terminal, "unconnected"))


def settle(console, record, label):
    result = {}
    record[label] = result
    for address in ADDRESSES:
        samples = []
        result[str(address)] = samples
        # For nonselected addresses the position pair stays unresolved. These
        # checks use decoded motion flags and the independent raw speed word.
        state = observe_stopped(console, address=address, timeout_s=5,
                                attempts=10, interval_s=.05, on_sample=samples.append)
        require(stopped(state), f"drive {address}: standstill/enable/alarm evidence unavailable")


def inspect_and_release(console, handle, result):
    require(handle.accepted and handle.operation_id, "operation was not admitted")
    inspected = console.command("result", operation_id=handle.operation_id, timeout_s=5)
    require(inspected["operation_id"] == result["operation_id"] and inspected["ok"] == result["ok"],
            "retained result ID/disposition changed")
    checked(console, "release", operation_id=handle.operation_id)


def check_move(result, values, mode, interrupted=False):
    require(result.get("individual") is True and [m["address"] for m in result["members"]] == list(ADDRESSES),
            "per-member result membership changed")
    for member, value in zip(result["members"], values):
        request = member["request"]
        require(request["value"] == [value, 1] and request["relative"] and request["unit"] == "steps" and
                request["frame"] == 0 and request["speed_rpm"] == 60 and member["effective_native"] == value,
                "exact member intent or prepared native value changed")
        require(member["start"] == "started" and member["execution"] == "acknowledged",
                "member start write failed or remains unknown")
        # Planned cancellation retains historical completion uncertainty even
        # after a later independent stop. It does not make the write UNKNOWN.
        if interrupted and member["interrupted_by_stop"]:
            require(member["outcome"] == "cancelled", "unexpected failure during planned interruption")
        else:
            require(not member["uncertain"] and member["completion"] == "observed",
                    "unplanned member failure or uncertain completion")
        if mode == "staged":
            require(member["stage"] == "staged" and member["stage_execution"] == "acknowledged" and
                    member["stage_readback"] == "match", "staging/readback did not complete")
        else:
            require(member["stage"] == "not_attempted" and member["setup_execution"] == "acknowledged",
                    "sequential setup evidence is incomplete")
    if mode == "staged":
        require(max(m["stage_read_latest_us"] for m in result["members"]) <
                min(m["start_tx_end_us"] for m in result["members"]), "a start preceded complete staging")
    require(result["request"]["start"] == mode, "start mode changed")
    if interrupted:
        require(any(m["interrupted_by_stop"] for m in result["members"]), "urgent interruption NOT_OBSERVED")
    else:
        require(result["ok"] and all(m["completion"] == "observed" for m in result["members"]),
                "finite move completion was not observed")


def build_plan(console, mode, values):
    checked(console, "group-read-state")
    checked(console, "group-plan-begin", host_args=("start", mode, "on-failure", "stop", "fast"))
    for address, value in zip(ADDRESSES, values):
        checked(console, "group-plan-add", host_args=(str(address), "relative", str(value), "steps", "native", "60", "configured"))
    return checked(console, "group-plan-show")


def running_gate(console, handle, case):
    case["running_gate"] = []
    for index in range(10):
        view = checked(console, "group-status")
        sample = dict(index=index + 1, group=view)
        case["running_gate"].append(sample)
        if handle.terminal is not None:
            case["early_terminal"] = handle.terminal
            break
        require(view["operations"]["move"] == handle.operation_id, "pending group move ID changed")
        if not view["sequencing"]:
            state = checked(console, "read-state", address=4)
            sample["state4"] = state
            if blocks(state)[0]["running"]:
                case["running_gate_disposition"] = "OBSERVED"
                return
        if index != 9:
            console.sleep(.02)
    case["running_gate_disposition"] = "NOT_OBSERVED"
    raise BenchError("all-starts plus fresh RUNNING NOT_OBSERVED within ten polls; no replay")


def restore(console, record):
    record["restoration"] = {}
    for address in ADDRESSES:
        saved = record["baselines"][str(address)]
        item = record["restoration"][str(address)] = {}
        select(console, address)
        item["identity"] = checked(console, "read-identity", address=address)
        item["configuration"] = checked(console, "read-config", address=address)
        require(item["configuration"]["config"]["raw"] == saved["configuration"]["config"]["raw"],
                "configuration changed before restoration")
        item["before"] = profile_snapshot(console)
        item["stationary"] = checked(console, "read-state", address=address)
        require(stopped(item["stationary"]), "restoration requires fresh standstill")
        item["unchanged"] = item["before"]["current"] == saved["archive"]["words"]
        if not item["unchanged"]:
            handle = console.begin("motion-profile-stage", host_args=profile_archive_arguments(saved["archive"]), timeout_s=5)
            item["candidate"] = console.wait(handle)
            require(item["candidate"]["ok"], "candidate restoration failed; no replay or further restoration")
            inspect_and_release(console, handle, item["candidate"])
        # A candidate write expires configuration readiness. Refresh it before
        # the ordinary profile read; keep the original archive unchanged.
        item["configuration_after"] = checked(console, "read-config", address=address)
        require(item["configuration_after"]["config"]["raw"] == saved["configuration"]["config"]["raw"],
                "restoration changed configuration")
        item["after"] = profile_snapshot(console)
        require(item["after"]["current"] == saved["archive"]["words"], "six-word restoration differs, including start word")
        item["state_after"] = checked(console, "read-state", address=address)
        require(stopped(item["state_after"]), "restoration did not leave checked standstill")
        checked(console, "motion-profile", host_args=("forget",))
    record["profiles_restored"] = True


def scenario(console, record, out):
    record.update(baselines={}, cases=[], profiles_restored=False, motion_attempted=False,
                  stop_attempted=False, m08_enable_cases="NOT RUN", absolute_physical="NOT RUN: unqualified feedback relation")
    group_ready = False
    try:
        owner = checked(console, "debug")["owner"]
        require(not owner["busy"] and not owner["recovery_required"] and not owner["pending"] and not owner["retained"],
                "fresh-image idle owner required; no automatic recovery or unknown-result release")
        view = checked(console, "group-show")
        require(not view["count"] and not view["sequencing"], "fresh-image empty group required")
        checked(console, "group-plan-clear")
        checked(console, "group-clear")
        profile = checked(console, "motion-profile", host_args=("inspect",))
        require(not profile["saved"] and not profile["pending"] and not profile["restore_unsettled"],
                "pre-existing profile evidence must be handled separately")
        for address in ADDRESSES:
            select(console, address)
            saved = record["baselines"][str(address)] = {}
            saved["identity"] = checked(console, "read-identity", address=address)
            saved["configuration"] = checked(console, "read-config", address=address)
            saved["state"] = checked(console, "read-state", address=address)
            require(stopped(saved["state"]), f"drive {address}: baseline is not stopped/enabled/alarm-free")
            identity, config = saved["identity"]["identity"], saved["configuration"]["config"]
            require((identity["raw_model"], identity["raw_version"]) == (0x4EEA, 0x29), "unexpected bench identity")
            require(config["known"]["word_order"] and 400 <= config["raw"]["subdivision"] <= 50000,
                    "60 rpm native command-rate/word-order prerequisite unavailable")
            saved["profile"] = profile_snapshot(console)
            words = saved["profile"]["current"]
            require(words[0] <= 60 and all(100 <= w <= 2000 for w in words[1:3]), "actual start speed/ramps reject planned move")
            archive = profile_archive(dict(schema=PROFILE_ARCHIVE_SCHEMA, address=address,
                order=config["raw"]["word_order"], words=words, model=identity["raw_model"], firmware=identity["raw_version"]), stage=True)
            saved["archive"] = archive
            save_profile_archive(Path(str(out) + f".drive{address}.profile.json"), archive)
            console.emit("baseline_archive", address=address, archive=archive, baseline=saved)
            checked(console, "motion-profile", host_args=("forget",))
        # Drive 4 remains selected and configured for the urgent read-only gate.
        checked(console, "group-set", host_args=tuple(map(str, ADDRESSES)))
        group_ready = True
        for address in ADDRESSES:
            for terminal in TERMINALS:
                checked(console, "group-wiring", host_args=(str(address), terminal, "unconnected"))
        checked(console, "group-set", host_args=tuple(map(str, ADDRESSES)))
        record["declared"] = checked(console, "group-show")
        for member in record["declared"]["members"]:
            require(member["profile"] == record["baselines"][str(member["address"])]["archive"]["words"] and
                    member["current"] and not member["start_speed_relation_required"], "group profile or readiness differs from baseline")
        for name, mode, values in CASES:
            case = dict(name=name, mode=mode, values=list(values), ok=False)
            record["cases"].append(case)
            case["plan"] = build_plan(console, mode, values)
            record["motion_attempted"] = True
            handle = console.begin("group-plan-submit", timeout_s=32)
            case["operation_id"] = handle.operation_id
            require(handle.accepted, "group plan was refused")
            interrupted = name == "urgent_group_stop"
            if interrupted:
                running_gate(console, handle, case)
                record["stop_attempted"] = True
                stop = console.begin("group-stop", host_args=("fast",), timeout_s=6)
                case["stop"] = console.wait(stop)
                require(case["stop"]["ok"] and all(m["completion"] == "observed" and not m["uncertain"]
                        for m in case["stop"]["members"]), "group fast stop not confirmed")
                inspect_and_release(console, stop, case["stop"])
            case["move"] = console.wait(handle)
            check_move(case["move"], values, mode, interrupted)
            inspect_and_release(console, handle, case["move"])
            case["ok"] = True
            console.emit("case", **case)
        settle(console, record, "standstill_before_restore")
        restore(console, record)
        select(console, 1)
        record["ending_configuration"] = checked(console, "read-config", address=1)
        record["ending_state"] = checked(console, "read-state", address=1)
        require(stopped(record["ending_state"]), "ending standstill unavailable")
        checked(console, "group-clear")
        record["ending_group"] = checked(console, "group-show")
        record["workload_verified"] = True
    except BaseException as error:
        record["failure"] = str(error) or "interrupted"
        record["restoration_disposition"] = "not attempted after failure; preserve archives and uncertain evidence"
        if group_ready and record["motion_attempted"] and not record["stop_attempted"] and console.synchronized:
            try:
                console.emit("failure_stop_plan", policy="fast", addresses=list(ADDRESSES), attempts=1)
                record["stop_attempted"] = True
                stop = console.begin("group-stop", host_args=("fast",), timeout_s=6)
                record["failure_stop"] = console.wait(stop)
                # Failed originals stay retained; the stop cannot turn them into PASS.
            except BaseException as cleanup:
                record["failure_stop_error"] = str(cleanup) or "interrupted"
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--firmware", type=Path, required=True)
    parser.add_argument("--commit", required=True, help="full source commit for the separately flashed image")
    parser.add_argument("--out", type=Path, required=True, help="new evidence prefix, without extension")
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    require(args.firmware.is_file() and re.fullmatch(r"[0-9a-fA-F]{40}", args.commit), "firmware file and full commit required")
    if args.plan_only:
        print(json.dumps(dict(usb=USB, source_commit=args.commit, firmware=str(args.firmware), plan=PLAN), indent=2))
        return 0
    # run_recorded reserves evidence, owns one connection with try/finally,
    # records image SHA-256, and keeps failure summaries when a command raises.
    run_recorded(port=USB["port"], out=args.out, scenario="multi_drive_09_three_drive",
        inputs=dict(source_commit=args.commit, usb=USB, plan=PLAN, image_flash_attestation="caller supplied; console does not attest hash"),
        run=lambda console, record: scenario(console, record, args.out), address=1,
        timeout_s=5, debug="raw", firmware=args.firmware, refresh=False,
        max_records=20000, max_bytes=32 * 1024 * 1024, port_opener=exact_port)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
