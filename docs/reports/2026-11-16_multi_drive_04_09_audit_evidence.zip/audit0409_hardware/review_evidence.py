import collections
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
def read(name):
    return json.loads((root / name).read_text())

def crc(data):
    value = 0xFFFF
    for byte in data:
        value ^= byte
        for _ in range(8):
            value = (value >> 1) ^ (0xA001 if value & 1 else 0)
    return value

checks = []
def check(condition, message):
    checks.append((bool(condition), message))

def frame(raw, address=None):
    data = bytes.fromhex(raw)
    check(len(data) >= 5 and crc(data[:-2]) == int.from_bytes(data[-2:], 'little'), 'CRC ' + raw)
    if address is not None:
        check(data[0] == address, 'Frame address')
    return data

def log(name, data):
    records = [json.loads(line) for line in (root / (name + '.jsonl')).read_text().splitlines()]
    traffic = [r['response'] for r in records if r['event'] == 'traffic']
    responses = [r['response'] for r in records if r['event'] == 'reply']
    raw_frames = [r for r in traffic if r['kind'] in ('TX', 'RX') and r['raw_hex']]
    for r in raw_frames:
        b = frame(r['raw_hex'])
        check(b[0] in ((1,) if name == 'io_run' else (1, 2, 4)), 'Only declared drive addresses')
        check(r['complete'] and len(b) == r['length'], 'Complete retained observer frame')
    debug = data['debug']['after']
    check(debug['emitted'] == len(traffic), 'Debug emitted count matches log')
    check(debug['observed'] == debug['emitted'] + debug['dropped'], 'Debug observer accounting')
    check(data['debug']['restored']['mode'] == 'off', 'Debug restored off')
    check(not data['evidence']['exhausted'], 'Host evidence budget preserved')
    return responses, {
        'jsonl_records': len(records),
        'traffic_events': len(traffic),
        'traffic_kinds': dict(collections.Counter(r['kind'] for r in traffic)),
        'checked_observer_frames': len(raw_frames),
        'debug_observed': debug['observed'], 'debug_dropped': debug['dropped'],
        'capture_dropped': debug['capture_dropped'],
        'complete_wire_log': False,
        'limit': 'The passive observer drops output under pressure. Retained operation evidence supplies the complete checked operation results.'
    }

def resources(d):
    before, after = d['before']['stats'], d['after']['stats']
    counters = {k: after[k] - before[k] for k in ('started', 'frames', 'failed', 'timeouts', 'cancelled', 'rx_bytes', 'discarded', 'echo_bytes', 'capture_faults', 'rx_errors')}
    check(counters['started'] == counters['frames'], 'Every owner request received a frame')
    check(all(counters[k] == 0 for k in ('failed', 'timeouts', 'cancelled', 'discarded', 'echo_bytes', 'capture_faults', 'rx_errors')), 'No owner transport failure')
    owner = {k: d['after']['drv'][k] for k in ('busy', 'transmit_enabled', 'pending', 'retained', 'reserved', 'recovery_required', 'automatic_recovery_operation_id')}
    check(not any(owner.values()), 'Ending owner is idle with no retained or reserved work')
    memory = {k: d['after']['memory'][k] for k in ('internal_min', 'internal_free', 'psram_min', 'psram_free', 'stack_free_bytes')}
    load = {k: d['after']['load'][k] for k in ('owner_gap_max_us', 'capture_gap_max_us', 'sample_gap_limit_us', 'capture_high_water', 'work_stack_free_bytes', 'workload_us', 'owner_delay_us', 'console_bytes')}
    check(load['capture_gap_max_us'] < load['sample_gap_limit_us'], 'Capture gap within configured limit')
    return {'owner_counters_delta': counters, 'memory_bytes': memory, 'timing_and_load': load, 'ending_owner': owner}

def stopped(result):
    blocks = {b['block']: b for b in result['state_blocks']}
    return not blocks[0]['raw_alarm'] and not blocks[0]['running'] and not blocks[0]['released'] and blocks[2]['raw_speed'] == 0

image = read('image.json')
firmware = (root / 'firmware.bin').read_bytes()
check(len(firmware) == image['bytes'] and hashlib.sha256(firmware).hexdigest() == image['sha256'], 'Firmware artifact size and hash')
io, group, prior, guard, session = (read(n) for n in ('io_run.json', 'group_fresh_run.json', 'group_run.json', 'guard_diagnostic.json', 'fresh-group-session.json'))
for d in (io, group):
    check(d['ok'] is True, 'Successful campaign result')
    check(d['inputs']['source_commit'] == image['commit'] and d['firmware_artifact']['sha256'] == image['sha256'], 'Campaign image provenance')
    check(not d['automatic_recovery'] and not d['automatic_write_replay'], 'No automatic recovery or write replay in campaign')

io_responses, io_log = log('io_run', io)
check(len(io['io_cases']) == 64, '64 I/O cases')
for c in io['io_cases']:
    update = c['update']; r = update['result']
    check(c['ok'] and update['admitted'] and update['released'] and r['ok'], 'I/O operation admitted, successful and released')
    check(r in io_responses, 'I/O terminal occurs in console log')
    check(not r['uncertain'] and not r['echo_readback_policy'] and len(r['progress']) == 1, 'Confirmed one-field update')
    row = dict(zip(r['progress_columns'], r['progress'][0]))
    check(row['acknowledged'] and row['readback_known'] and row['requested'] == row['readback'] and row['execution'] == 'acknowledged', 'I/O ACK and readback agree')
    evidence = [dict(zip(r['evidence_columns'], x)) for x in r['evidence']]
    check(len(evidence) == 2 and evidence[0]['write'] and not evidence[1]['write'], 'One I/O write followed by one readback')
    for e in evidence:
        b = frame(e['raw_hex'], 1)
        check(e['qualified'] and e['response_confirmed'] and e['tx_complete'] and not e['execution_unknown'] and e['status'] == 'OK', 'Qualified I/O frame')
        check(e['latest_us'] <= r['deadline_us'], 'I/O evidence within immutable deadline')
        if e['write']:
            check(b[1] == 6 and int.from_bytes(b[2:4], 'big') == row['register'] and int.from_bytes(b[4:6], 'big') == row['requested'], 'Exact FC06 reply')
        else:
            check(b[1:3] == b'\x03\x02' and int.from_bytes(b[3:5], 'big') == row['requested'], 'Exact one-word FC03 readback')
check(io['baseline']['config']['result']['config'] == io['final_config']['result']['config'], 'I/O configuration restored exactly')
check(io['baseline']['io_state']['io']['result']['observation'] == io['final_io_state']['io']['result']['observation'], 'I/O raw settings restored exactly')
check(io['baseline']['profile']['current'] == io['final_profile']['current'], 'I/O six-word profile restored exactly')
check(stopped(io['final_io_state']['state']['result']), 'I/O ending stopped/enabled/alarm-free/zero-speed')
for name in ('move', 'stop'):
    r = io[name]['result']
    check(r in io_responses and r['ok'] and r['execution'] == 'acknowledged' and r['completion'] == 'observed', 'I/O finite move/stop checked terminal')
check(io['move']['result']['running_observed'], 'I/O move observed RUNNING')
io_facts = {
    'result': 'PASS', 'io_updates': 64, 'successful_write_operations': io['successful_write_operations'],
    'tested_functions': {'X0': list(range(4, 18)), 'Y0': [0, 1, 2, 3, 4, 5, 9], 'Y1': [0, 1, 2, 3, 4, 5, 10]},
    'custom_outputs': 'Both canonical outputs active/inactive, then restored',
    'finite_move_native_steps': 100, 'move_running_observed': True, 'move_and_stop': 'ACKNOWLEDGED and OBSERVED',
    'profile_restored': io['final_profile']['current'], 'io_raw_restored': io['final_io_state']['io']['result']['observation']['raw'],
    'configuration_restored_exactly': True, 'ending_stopped_enabled_alarm_free_zero_speed': True,
    'summary_flag_note': 'known_motion_seen=false is the harness guard for unexpected motion in separate stationary reads. The actual move result has running_observed=true.',
    'observer': io_log, **resources(io)
}

group_responses, group_log = log('group_fresh_run', group)
case_facts = []
for index, c in enumerate(group['cases']):
    r = c['move']; members = r['members']
    check(r in group_responses and r['operation_id'] == c['operation_id'], 'Group terminal exact identity in console log')
    check([m['address'] for m in members] == [1, 2, 4], 'Exact group members')
    check([m['effective_native'] for m in members] == c['values'], 'Exact independent native targets')
    check([m['request']['value'] for m in members] == [[n, 1] for n in c['values']], 'Exact copied member intents')
    check(all(m['request']['relative'] and m['request']['speed_rpm'] == 60 and m['request']['frame'] == 0 for m in members), 'Native finite relative requests')
    check(all(m['start'] == 'started' and m['execution'] == 'acknowledged' and m['running_observed'] for m in members), 'All starts acknowledged and RUNNING observed')
    fact = {'name': c['name'], 'group_operation_id': r['operation_id'], 'child_operation_ids': [m['operation_id'] for m in members], 'native_targets': c['values'], 'mode': c['mode'], 'start_tx_end_spread_us': r['start_tx_spread_us'], 'running_observation_spread_us': r['running_bound_spread_us']}
    if c['mode'] == 'staged':
        check(all(m['stage'] == 'staged' and m['stage_readback'] == 'match' and m['stage_execution'] == 'acknowledged' for m in members), 'Every staged member checked')
        last_read = max(m['stage_read_latest_us'] for m in members)
        # Eight-byte FC06 at the configured 89 us maximum character time. Include
        # each copied TX-end uncertainty when bounding the first start byte.
        earliest_start = min(m['start_tx_end_us'] - 8 * group['before']['host']['timing']['character_max_us'] - m['start_tx_uncertainty_us'] for m in members)
        check(last_read < earliest_start, 'All staging readbacks precede every start frame')
        fact['staging_readback_to_start_lower_margin_us'] = earliest_start - last_read
    if index < 2:
        check(r['ok'] and all(m['completion'] == 'observed' and not m['uncertain'] for m in members), 'Finite group completion observed')
        fact['outcome'] = 'All three moves ACKNOWLEDGED and OBSERVED'
    else:
        stop = c['stop']
        check(stop in group_responses and stop['operation_id'] != r['operation_id'] and stop['ok'], 'Independent stop terminal in console log')
        ids = [r['operation_id'], stop['operation_id']] + [m['operation_id'] for m in members] + [m['operation_id'] for m in stop['members']]
        check(len(set(ids)) == len(ids) and all(i > 0 for i in ids), 'Independent positive move/stop identities')
        check(all(m['interrupted_by_stop'] and m['outcome'] == 'cancelled' and m['uncertain'] and m['completion'] == 'not_observed' for m in members), 'Interrupted move evidence stays cancelled/uncertain')
        check(all(m['execution'] == 'acknowledged' and m['completion'] == 'observed' and not m['uncertain'] and not m['raw_alarm'] for m in stop['members']), 'Every explicit stop acknowledged and observed')
        check(c['running_gate_disposition'] == 'OBSERVED', 'Bounded running gate satisfied')
        fact.update(outcome='Original moves remain cancelled/uncertain; all three explicit stops ACKNOWLEDGED and OBSERVED', stop_operation_id=stop['operation_id'], stop_child_operation_ids=[m['operation_id'] for m in stop['members']])
    case_facts.append(fact)
restore_facts = {}
for address, r in group['restoration'].items():
    baseline = group['baselines'][address]
    check(r['configuration_after']['config'] == baseline['configuration']['config'], 'Group configuration restored exactly')
    check(r['after']['current'] == baseline['profile']['current'], 'Group six-word profile restored exactly')
    check(stopped(r['state_after']), 'Group final stopped/enabled/alarm-free/zero-speed')
    candidate = r['candidate']
    check(candidate in group_responses and candidate['ok'] and candidate['execution'] == 'acknowledged' and candidate['readback'] == candidate['candidate'], 'Checked restoration candidate')
    for key in ('prior_evidence', 'write_evidence', 'readback_evidence'):
        e = candidate[key]; frame(e['raw_hex'], int(address))
        check(e['qualified'] and e['response_confirmed'] and not e['execution_unknown'] and e['latest_us'] <= candidate['deadline_us'], 'Restoration evidence qualified/on time')
    restore_facts[address] = {'profile': r['after']['current'], 'configuration_equal': True, 'stopped_enabled_alarm_free_zero_speed': True}
check(group['ending_group']['count'] == 0 and not group['ending_group']['plan']['active'], 'Ending group and plan cleared')
group_facts = {'result': 'PASS in separate fresh controller session', 'cases': case_facts, 'restoration': restore_facts, 'ending_selected_address': group['ending_state']['address'], 'group_cleared': True, 'observer': group_log, **resources(group)}

check(prior['ok'] is False and not prior['motion_attempted'] and not prior['stop_attempted'], 'Earlier preflight abort remains failed without group motion')
check(guard['reply']['ok'] is False and guard['reply']['result'] == 'unavailable' and guard['reply']['operation_id'] == 0 and guard['reply']['address'] == 1, 'Expected exact group refusal')
check(all(guard['before'][k] == guard['after'][k] for k in ('started', 'frames', 'failed', 'timeouts')), 'Guard refusal generated zero bus requests')
check(session['exit'] == 0 and session['prior_failure_preserved'] == 'group_run.json' and session['firmware_sha256'] == image['sha256'], 'Separate fresh-session provenance')
report = {
    'reviewer': 'audit0409_interfaces', 'review_scope': 'Independent read-only artifact review; no port access or source edits',
    'result': 'PASS' if all(c for c, _ in checks) else 'FINDINGS',
    'checks': len(checks), 'contradictions': [m for c, m in checks if not c],
    'image': image, 'M04': io_facts, 'M09': group_facts,
    'earlier_attempt': {'file': 'group_run.json', 'result': 'FAIL retained', 'reason': prior['error'], 'motion_submitted': False, 'followup_guard': guard['reply'], 'zero_bus_request_delta': True, 'next_campaign': 'Separate fresh controller session under documented startup policy; no motor restart or supplied relation claim.'},
    'remaining_limits': [
        'Unconnected terminals: wired input effects, output loads and electrical status/polarity mapping remain unqualified.',
        'No physical absolute/reference qualification, independent shaft observation or independently measured start skew.',
        'No drive restart/persistence qualification, M08 enable/reselection case, HW-15 timing investigation or soak in these runs.',
        'Passive traffic logs are incomplete under console pressure; retained operation evidence and owner counters were reviewed separately.',
        'Firmware hash identifies the supplied uploaded artifact; console output does not cryptographically attest flash contents.',
        'Group profile restoration reestablishes stored values but retains the documented relation guard in that controller session.'
    ]
}
(root / 'evidence_review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'result': report['result'], 'checks': len(checks), 'contradictions': report['contradictions'], 'cases': case_facts}, indent=2))
