from pathlib import Path
import hashlib
import json
import subprocess
from serial.tools import list_ports

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
assert json.loads((out / 'guard_diagnostic.json').read_text())['ok']
image = json.loads((out / 'image.json').read_text())
assert hashlib.sha256((root / '.pio/build/bench_s3_load_timer/firmware.bin').read_bytes()).hexdigest() == image['sha256']
assert any((p.device, p.vid, p.pid, p.serial_number) ==
           ('COM13', 0x303A, 0x1001, '3C:0F:02:CD:6B:98') for p in list_ports.comports())
with (out / 'fresh-group-upload.log').open('x') as log:
    result = subprocess.run([str(root / 'scripts/pio.cmd'), 'run', '-e', 'bench_s3_load_timer',
                             '-t', 'upload', '--upload-port', 'COM13', '-j', '2'],
                            cwd=root, stdout=log, stderr=subprocess.STDOUT)
assert hashlib.sha256((root / '.pio/build/bench_s3_load_timer/firmware.bin').read_bytes()).hexdigest() == image['sha256']
(out / 'fresh-group-session.json').write_text(json.dumps(dict(
    exit=result.returncode, source_commit=image['commit'], firmware_sha256=image['sha256'],
    reason='Separate startup-policy group campaign after retained expected relation guard; no motor restart.',
    prior_failure_preserved='group_run.json', refusal_diagnostic='guard_diagnostic.json'), indent=2) + '\n')
raise SystemExit(result.returncode)
