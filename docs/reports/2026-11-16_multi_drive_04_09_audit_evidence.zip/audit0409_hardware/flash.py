from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
from serial.tools import list_ports

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
commit = sys.argv[1]
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == commit
assert not subprocess.check_output(['git', 'diff', 'HEAD', '--', 'src', 'include', 'examples', 'platformio.ini'], cwd=root)
ports = [dict(device=p.device, vid=p.vid, pid=p.pid, serial=p.serial_number) for p in list_ports.comports()]
(out / 'upload-ports.json').write_text(json.dumps(ports, indent=2) + '\n')
assert dict(device='COM13', vid=0x303A, pid=0x1001, serial='3C:0F:02:CD:6B:98') in ports
source = root / '.pio/build/bench_s3_load_timer/firmware.bin'
target = out / 'firmware.bin'
assert not target.exists()
shutil.copy2(source, target)
digest = hashlib.sha256(target.read_bytes()).hexdigest()
with (out / 'upload.log').open('x') as log:
    result = subprocess.run([str(root / 'scripts/pio.cmd'), 'run', '-e', 'bench_s3_load_timer',
                             '-t', 'upload', '--upload-port', 'COM13', '-j', '2'],
                            cwd=root, stdout=log, stderr=subprocess.STDOUT)
assert hashlib.sha256(source.read_bytes()).hexdigest() == digest, 'upload rebuilt a different image'
metadata = dict(commit=commit, environment='bench_s3_load_timer', sha256=digest,
                bytes=target.stat().st_size, upload_exit=result.returncode,
                platform='pioarduino55.03.311', arduino='3.3.11', idf='5.5.5',
                port='COM13', usb='303A:1001', serial='3C:0F:02:CD:6B:98')
(out / 'image.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata))
raise SystemExit(result.returncode)
