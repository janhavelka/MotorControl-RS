﻿from pathlib import Path
import sys,json,time
from serial.tools import list_ports
sys.path.insert(0,str(Path('scripts').resolve()))
import bench_probe as b
out=Path('build/audit0409_hardware')
ports=[dict(device=p.device,vid=p.vid,pid=p.pid,serial=p.serial_number) for p in list_ports.comports()]
r=dict(ports=ports,ok=False,drives={},writes=False,recovery=False)
try:
 assert any(p==dict(device='COM13',vid=0x303A,pid=0x1001,serial='3C:0F:02:CD:6B:98') for p in ports),'recorded board absent'
 with (out/'preflight.jsonl').open('x') as log,b.open_port('COM13',115200,3) as port:
  def event(name,**fields):
   log.write(json.dumps(dict(event=name,fields=fields,time=time.monotonic()))+'\n');log.flush()
  c=b.Console(port,on_event=event);c.drain_startup(.5)
  r['version']=c.identify();r['owner']=c.command('debug')['owner']
  assert not any(r['owner'][k] for k in ('busy','pending','retained','recovery_required')),'owner not idle'
  for address in (1,2,4):
   d=r['drives'][str(address)]={}
   d['identity']=c.command('read-identity',address=address,timeout_s=5)
   assert d['identity']['ok']
   ident=d['identity']['identity']
   assert (ident['raw_model'],ident['raw_version'])==(0x4EEA,0x29),'unexpected drive identity'
   d['state']=c.command('read-state',address=address,timeout_s=5)
   assert d['state']['ok'] and b.drive_reported_stopped(d['state']),'drive not stopped'
  r['ok']=True
except Exception as e:
 r['error']=str(e)
finally:
 (out/'preflight.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps(dict(ok=r['ok'],error=r.get('error'),drives=list(r['drives']))))
if not r['ok']: raise SystemExit(1)
