"""Prepared M04 address-1 bench checks. No flashing, retries or unknown rollback.

--plan-only prints the reviewed finite plan without enumerating or opening ports.
Run hardware only after the lead verifies software and records the flashed image.
"""
import argparse
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from bench_probe import (BenchError, drive_reported_stopped, driver_arguments,
                         io_qualification_arguments, move_arguments, open_port,
                         profile_archive, profile_archive_arguments,
                         save_profile_archive, PROFILE_ARCHIVE_SCHEMA)
from bench_motion import profile_snapshot
from bench_session import checked, run_recorded

USB = dict(port="COM13", vid=0x303A, pid=0x1001, serial="3C:0F:02:CD:6B:98")
ADDRESS = 1
TERMINALS = ("x0", "x1", "x2", "x3", "y0", "y1")
INPUT_FUNCTIONS = tuple(range(4, 18))
OUTPUT_FUNCTIONS = ((0, 1, 2, 3, 4, 5, 9), (0, 1, 2, 3, 4, 5, 10))
MOVE = ("100", "steps", "native", "60", "configured")
PLAN = [
    "Check only COM13 USB303A:1001 serial3C:0F:02:CD:6B:98; open once. No flash or power cycle.",
    "Record firmware artifact/hash and caller-supplied full source commit, console version, memory, owner counters and raw traffic.",
    "Require idle owner, no pending/retained operations, no recovery, empty group and no old profile session. No automatic recovery or result disposal.",
    "Select address1 locally. Declare X0..X3/Y0..Y1 unconnected from the recorded fixture, then read identity/configuration/state/I/O and all six profile words. Archive before writes.",
    "Require model0x4EEA/version0x29, both polarity masks0, custom0, passive baseline inputs0..3, supported canonical/passive outputs, all inputs inactive, stopped/enabled/alarm-free/zero speed and admissible finite profile.",
    "For each x0 function4..17: fresh I/O+state; install exact ASSIGN facts with unknown mapping and triggers-inhibited; one confirmed io set; fresh I/O+state and exact readback; restore originalx0 through the same explicit path.",
    "For y0 functions0..5/9 and y1 functions0..5/10: exact output ASSIGN, unknown mapping, load none, either level; one confirmed io set and fresh readback/state; restore that original assignment each time.",
    "For Y0/CUSTOM_0 then Y1/CUSTOM_1: assign canonical function, explicitly qualify both output candidates for each custom-word write, custom0->one bit1->0, then restore original assignment. All writes require checked standstill.",
    "Require the complete nine-word I/O configuration equals the backup. Refresh configuration/state/profile. One relative100-step move at60rpm with configured bounded ramps, then one explicit fast stop and fresh stopped/zero-speed observation.",
    "After known success, stage the saved five0x0021 profile words once only when changed. Refresh configuration before rereading all six0x0020 words; compare exactly including unchanged start word.",
    "Final exact configuration/I/O/profile reads, selectedaddress1, owner idle, no recovery/pending/retained work, DE off; final memory/stats/drv diagnostics. Restore debug display and close the port.",
    "On any failure: retain the failing result/archive; no further setting/restoration/motion write. One prepared fast stop only for known motion and settled prior writes with synchronized framing and healthy owner. Never repeat a stop or uncertain write.",
    "Input/output electrical effects, status polarity mapping, connected-load behavior, restart persistence and HW-15 timing remain NOT RUN.",
]


def require(condition, message):
    if not condition:
        raise BenchError(message)


def exact_port(name, baud, timeout_s):
    from serial.tools import list_ports
    ports = [port for port in list_ports.comports() if port.device.upper() == USB["port"]]
    require(name.upper() == USB["port"] and len(ports) == 1, "recorded COM13 is missing or ambiguous")
    port = ports[0]
    require((port.vid, port.pid, port.serial_number) == (USB["vid"], USB["pid"], USB["serial"]),
            "COM13 USB identity differs; no port opened")
    return open_port(name, baud, timeout_s)


def input_facts(function):
    return ("1", "x0", str(function), "0", "assign", "unknown", "triggers-inhibited")


def output_facts(terminal, function, custom):
    return ("1", "y" + str(terminal), str(function), "0", str(custom), "assign", "unknown", "none", "either")


def validate_plan():
    """Validate every fixed command shape before a port can be opened."""
    for function in (*range(4), *INPUT_FUNCTIONS):
        facts = input_facts(function)
        io_qualification_arguments("io-qualification-install", facts)
        driver_arguments(("set", "x0", str(function)), "io")
        line = "@4294967295 io qualification install " + " ".join(facts) + "\n"
        require(len(line) <= 128 and len(line.split()) <= 22, "input plan exceeds console bounds")
    for terminal, functions in enumerate(OUTPUT_FUNCTIONS):
        for function in functions:
            for custom in (0, 1):
                facts = output_facts(terminal, function, custom)
                io_qualification_arguments("io-qualification-install", facts)
                line = "@4294967295 io qualification install " + " ".join(facts) + "\n"
                require(len(line) <= 128 and len(line.split()) <= 22, "output plan exceeds console bounds")
            driver_arguments(("set", "y" + str(terminal), str(function)), "io")
    for custom in (0, 1, 2):
        driver_arguments(("set", "custom", str(custom)), "io")
    move_arguments("relative", MOVE)


def unknown_write(result):
    if result.get("uncertain") or result.get("execution_unknown") or result.get("write_execution_unknown"):
        return True
    if any(result.get(key) == "unknown" for key in ("execution", "setup_execution", "stage_execution")):
        return True
    return any(row[-1] == "unknown" for row in result.get("progress", []))


def operation(console, record, item, command, *, write=False, timeout_s=5, **arguments):
    """Keep failed/unknown firmware results. Release only checked successful results."""
    item["command"] = command
    item["arguments"] = arguments
    if write:
        record["last_write_settled"] = False
    handle = console.begin(command, timeout_s=timeout_s, **arguments)
    item["admitted"] = handle.accepted
    item["operation_id"] = handle.operation_id
    if write and not handle.accepted:
        record["last_write_settled"] = True
    if command == "move-relative":
        record["motion_admitted"] = handle.accepted
    result = console.wait(handle)
    item["result"] = result
    if handle.accepted:
        inspected = console.command("result", operation_id=handle.operation_id, timeout_s=5)
        item["inspection"] = inspected
        require(inspected["operation_id"] == result["operation_id"] and inspected["ok"] == result["ok"],
                "retained operation identity or disposition changed")
    if write:
        record["last_write_settled"] = not unknown_write(result)
        record["unknown_write"] |= unknown_write(result)
    require(handle.accepted and result["ok"], command + " refused/failed; retained without replay or restoration")
    if write:
        require(record["last_write_settled"], command + " left uncertain write evidence")
        if command == "io":
            require(result["echo_readback_policy"] is False and result["progress"] and
                    all(row[4] and row[5] and row[3] == row[6] and row[9] == "acknowledged" for row in result["progress"]),
                    "I/O update lacks confirmed FC06 and matching readback")
        record["successful_write_operations"] += 1
    checked(console, "release", operation_id=handle.operation_id)
    item["released"] = True
    return result


def state_blocks(state):
    return {block["block"]: block for block in state["state_blocks"]}


def verify_state(record, state):
    blocks = state_blocks(state)
    motion, io = blocks[0], blocks[1]
    if record["successful_write_operations"] and (motion["running"] or blocks[2]["raw_speed"]):
        record["known_motion_seen"] = True
    require(drive_reported_stopped(state) and not motion["released"] and not motion["unknown_motion_bits"],
            "fresh stopped/enabled/alarm-free/zero-speed evidence required")
    require(not io["unknown_input_bits"] and not io["unknown_output_bits"] and io["raw_inputs"] == 0,
            "fresh inactive input levels required; no guessed mapping or input rewrite")


def read_state(console, record, item):
    result = operation(console, record, item, "read-state", address=ADDRESS)
    verify_state(record, result)
    return result


def read_io(console, record, item):
    result = operation(console, record, item, "io", driver_args=("read",), address=ADDRESS)
    raw = result["observation"]["raw"]
    require(len(raw) == 9 and raw[0] == 0 and raw[5] == 0, "polarity changed or unknown; no mapping is qualified")
    return raw


def fresh_io(console, record, item):
    item["io"] = {}
    raw = read_io(console, record, item["io"])
    item["state"] = {}
    read_state(console, record, item["state"])
    return raw


def write_io(console, record, case, field, value):
    """A single checked FC06 plus readback. Every candidate is explicit."""
    case["before"] = {}
    old = fresh_io(console, record, case["before"])
    expected = list(old)
    cases = []
    if field == "x0":
        expected[1] = value
        cases.append(input_facts(value))
    elif field.startswith("y"):
        terminal = int(field[1])
        expected[6 + terminal] = value
        cases.append(output_facts(terminal, value, (old[8] >> terminal) & 1))
    else:
        require(field == "custom", "unplanned I/O field")
        expected[8] = value
        # The full custom word also touches unchanged canonical outputs.
        for terminal in range(2):
            cases.append(output_facts(terminal, old[6 + terminal], (value >> terminal) & 1))
    case["qualification"] = []
    for facts in cases:
        case["qualification"].append(checked(console, "io-qualification-install", host_args=facts))
    case["update"] = {}
    operation(console, record, case["update"], "io", write=True,
              driver_args=("set", field, str(value)), address=ADDRESS)
    case["after"] = {}
    actual = fresh_io(console, record, case["after"])
    require(actual == expected, "complete I/O readback differs from the exact candidate")
    case["ok"] = True
    console.emit("io_case", field=field, value=value, before=old, after=actual,
                 operation_id=case["update"]["operation_id"], confirmed=True)


def io_case(console, record, name, field, value):
    case = dict(name=name, ok=False)
    record["io_cases"].append(case)
    write_io(console, record, case, field, value)


def scenario(console, record, out):
    record.update(io_cases=[], last_write_settled=True, unknown_write=False, successful_write_operations=0,
                  motion_admitted=False, known_motion_seen=False, stop_attempted=False,
                  io_restored=False, profile_restored=False,
                  fixture=dict(source="docs/hardware_bench.md recorded power/RS485-only fixture",
                               inputs="X0-X3 unconnected; no external trigger source",
                               input_voltage_current="not independently measured; no external source connected",
                               outputs="Y0-Y1 unconnected; no attached loads"),
                  physical_input_output_effects="NOT RUN: terminals unconnected",
                  status_polarity_mapping="NOT QUALIFIED", persistence="NOT RUN: no restart", hw15="NOT RUN")
    try:
        record["capabilities"] = checked(console, "caps")
        require(record["capabilities"].get("write_response_confirmed") is True and
                record["capabilities"].get("qualification_routes", {}).get("io") is True,
                "confirmed-reply I/O commissioning image required")
        require(all(record["before"]["load"].get(key) == 0 for key in ("workload_us", "owner_delay_us", "console_bytes")),
                "injected host load must be off for this bounded regression")
        require(checked(console, "monitor")["enabled"] is False, "background monitoring must be off")
        owner = checked(console, "debug")["owner"]
        require(not owner["busy"] and not owner["recovery_required"] and not owner["pending"] and not owner["retained"],
                "idle fresh-image owner required; no automatic recovery or result disposal")
        group = checked(console, "group-show")
        require(not group["count"] and not group["sequencing"], "empty idle group required; other drives are outside this session")
        profile = checked(console, "motion-profile", host_args=("inspect",))
        require(not profile["saved"] and not profile["pending"] and not profile["restore_unsettled"],
                "pre-existing profile session needs separate review")
        checked(console, "useaddr", address=ADDRESS)
        record["wiring"] = [checked(console, "wiring", host_args=(terminal, "unconnected")) for terminal in TERMINALS]
        baseline = record["baseline"] = {}
        for kind in ("identity", "config"):
            baseline[kind] = {}
            operation(console, record, baseline[kind], "read-" + kind, address=ADDRESS)
        identity = baseline["identity"]["result"]["identity"]
        config = baseline["config"]["result"]["config"]
        require((identity["raw_model"], identity["raw_version"]) == (0x4EEA, 0x29), "unexpected drive model/firmware")
        require(config["known"]["word_order"] and 400 <= config["raw"]["subdivision"] <= 50000,
                "word order or60rpm native-rate bound unavailable")
        baseline["io_state"] = {}
        original = fresh_io(console, record, baseline["io_state"])
        require(all(function <= 3 for function in original[1:5]) and original[8] == 0 and
                all(original[6 + i] in OUTPUT_FUNCTIONS[i] for i in range(2)),
                "baseline is outside the recorded passive/canonical subset; no setting write attempted")
        baseline["profile"] = profile_snapshot(console)
        words = baseline["profile"]["current"]
        require(words[0] <= 60 and all(100 <= word <= 2000 for word in words[1:3]), "stored start speed/ramps reject the finite move")
        archive = profile_archive(dict(schema=PROFILE_ARCHIVE_SCHEMA, address=ADDRESS, order=config["raw"]["word_order"],
            words=words, model=identity["raw_model"], firmware=identity["raw_version"]), stage=True)
        baseline["archive"] = archive
        save_profile_archive(Path(str(out) + ".drive1.profile.json"), archive)
        with Path(str(out) + ".drive1.io.json").open("x", encoding="utf-8") as stream:
            json.dump(dict(address=ADDRESS, model=identity["raw_model"], firmware=identity["raw_version"], raw=original), stream, indent=2)
            stream.write("\n")
        console.emit("baseline_archive", address=ADDRESS, profile=archive, io=original)
        checked(console, "motion-profile", host_args=("forget",))
        for function in INPUT_FUNCTIONS:
            io_case(console, record, "x0_function_" + str(function), "x0", function)
            io_case(console, record, "x0_restore_after_" + str(function), "x0", original[1])
        for terminal, functions in enumerate(OUTPUT_FUNCTIONS):
            for function in functions:
                field = "y" + str(terminal)
                io_case(console, record, field + "_function_" + str(function), field, function)
                io_case(console, record, field + "_restore_after_" + str(function), field, original[6 + terminal])
        for terminal in range(2):
            field = "y" + str(terminal)
            io_case(console, record, field + "_canonical", field, 9 + terminal)
            io_case(console, record, field + "_custom_active", "custom", 1 << terminal)
            io_case(console, record, field + "_custom_inactive", "custom", 0)
            io_case(console, record, field + "_restore", field, original[6 + terminal])
        record["io_after_roundtrips"] = {}
        require(fresh_io(console, record, record["io_after_roundtrips"]) == original, "I/O settings were not restored")
        record["io_restored"] = True
        record["configuration_before_move"] = {}
        operation(console, record, record["configuration_before_move"], "read-config", address=ADDRESS)
        require(record["configuration_before_move"]["result"]["config"]["raw"] == config["raw"], "configuration changed during I/O round trips")
        record["profile_before_move"] = profile_snapshot(console)
        require(record["profile_before_move"]["current"] == archive["words"], "profile changed before the finite move")
        # Both ordinary move and later candidate admission consume this checked
        # saved profile. Keep it until final restoration has been verified.
        record["state_before_move"] = {}
        read_state(console, record, record["state_before_move"])
        record["move"] = {}
        motion = operation(console, record, record["move"], "move-relative", write=True, timeout_s=32, address=ADDRESS, move_args=MOVE)
        require(motion["completion"] == "observed" and motion["effective_native"] == 100 and motion["execution"] == "acknowledged",
                "100-step motion was not confirmed")
        record["stop_attempted"] = True
        record["stop"] = {}
        stopped = operation(console, record, record["stop"], "stop", write=True, timeout_s=6, address=ADDRESS, stop_policy="fast")
        require(stopped["completion"] == "observed" and stopped["execution"] == "acknowledged", "explicit fast stop not confirmed")
        record["state_before_restore"] = {}
        read_state(console, record, record["state_before_restore"])
        record["profile_before_restore"] = profile_snapshot(console)
        if record["profile_before_restore"]["current"] != archive["words"]:
            require(record["profile_before_restore"]["current"][0] == archive["words"][0], "start speed changed; five-word restoration is insufficient")
            record["restoration"] = {}
            operation(console, record, record["restoration"], "motion-profile-stage", write=True,
                      host_args=profile_archive_arguments(archive))
        # Staging invalidates configuration readiness; refresh before profile read.
        record["final_config"] = {}
        operation(console, record, record["final_config"], "read-config", address=ADDRESS)
        require(record["final_config"]["result"]["config"]["raw"] == config["raw"], "final configuration differs")
        record["final_profile"] = profile_snapshot(console)
        require(record["final_profile"]["current"] == archive["words"], "six-word profile was not restored exactly")
        record["profile_restored"] = True
        checked(console, "motion-profile", host_args=("forget",))
        record["final_io_state"] = {}
        require(fresh_io(console, record, record["final_io_state"]) == original, "final I/O settings differ")
        record["final_owner"] = checked(console, "debug")["owner"]
        require(not record["final_owner"]["busy"] and not record["final_owner"]["pending"] and
                not record["final_owner"]["retained"] and not record["final_owner"]["recovery_required"], "owner is not settled")
        record["final_status"] = checked(console, "status")
        record["final_driver"] = checked(console, "drv")
        require(record["final_driver"]["transmit_enabled"] is False, "DE remains enabled")
        record["final_wiring"] = checked(console, "wiring")
        require(record["final_wiring"]["address"] == ADDRESS, "selected target changed")
        record["workload_verified"] = True
    except BaseException as error:
        record["failure"] = str(error) or "interrupted"
        record["restoration_disposition"] = "no further restoration after failure; retain raw evidence and archives"
        if ((record["motion_admitted"] or record["known_motion_seen"]) and not record["stop_attempted"] and
                record["last_write_settled"] and not record["unknown_write"] and console.synchronized):
            try:
                owner = checked(console, "debug")["owner"]
                require(not owner["recovery_required"], "owner recovery required; no automatic stop")
                record["stop_attempted"] = True
                record["failure_stop"] = {}
                console.emit("failure_stop_plan", address=ADDRESS, policy="fast", attempts=1)
                operation(console, record, record["failure_stop"], "stop", write=True, timeout_s=6, address=ADDRESS, stop_policy="fast")
            except BaseException as cleanup:
                record["failure_stop_error"] = str(cleanup) or "interrupted"
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--firmware", type=Path, help="separately flashed image; required for hardware")
    parser.add_argument("--commit", help="full source commit verified by the lead; required for hardware")
    parser.add_argument("--out", type=Path, help="new evidence prefix; required for hardware")
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    validate_plan()
    if args.plan_only:
        print(json.dumps(dict(usb=USB, address=ADDRESS, maximum_io_write_operations=64, plan=PLAN), indent=2))
        return 0
    require(args.firmware is not None and args.firmware.is_file() and args.commit is not None and
            re.fullmatch(r"[0-9a-fA-F]{40}", args.commit) and args.out is not None, "firmware, full commit and new output prefix required")
    run_recorded(port=USB["port"], out=args.out, scenario="multi_drive_04_unconnected_io",
        inputs=dict(source_commit=args.commit, usb=USB, address=ADDRESS, plan=PLAN,
                    image_flash_attestation="caller supplied; console does not attest hash",
                    software_verification="lead must verify exact code commit before this run"),
        run=lambda console, record: scenario(console, record, args.out), address=ADDRESS,
        timeout_s=5, debug="raw", firmware=args.firmware, refresh=False,
        max_records=40000, max_bytes=64 * 1024 * 1024, port_opener=exact_port)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
