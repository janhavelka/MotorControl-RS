from pathlib import Path
import json
import time
import group_regression as g
from bench_probe import Console

out = Path(__file__).resolve().parent
record = dict(ok=False, expected='group rejection after candidate-write relation revocation')
try:
    with (out / 'guard_diagnostic.jsonl').open('x') as log, g.exact_port('COM13', 115200, 3) as port:
        def event(name, **fields):
            log.write(json.dumps(dict(event=name, fields=fields, time=time.monotonic())) + '\n')
            log.flush()
        console = Console(port, on_event=event)
        console.drain_startup(.5)
        record['version'] = console.identify()
        record['group'] = g.checked(console, 'group-show')
        assert [m['address'] for m in record['group']['members']] == [1, 2, 4]
        assert [m['start_speed_relation_required'] for m in record['group']['members']] == [True, False, False]
        record['plan'] = g.build_plan(console, 'staged', (100, -150, 200))
        record['before'] = g.checked(console, 'stats')
        request = console.begin('group-plan-submit', timeout_s=6)
        if request.accepted:
            # Bounded diagnostic intent was unexpectedly admitted. Stop once;
            # preserve the failed diagnostic and all motion/stop evidence.
            record['unexpected_stop'] = console.command('group-stop', host_args=('fast',), timeout_s=6)
        record['reply'] = console.wait(request)
        record['after'] = g.checked(console, 'stats')
        assert not request.accepted and not record['reply']['ok']
        assert record['reply']['result'] == 'unavailable'
        assert record['before']['started'] == record['after']['started']
        record['clear_plan'] = g.checked(console, 'group-plan-clear')
        record['owner'] = g.checked(console, 'debug')['owner']
        assert not any(record['owner'][k] for k in ('busy', 'pending', 'retained', 'recovery_required'))
        record['ok'] = True
except BaseException as error:
    record['error'] = str(error)
    raise
finally:
    (out / 'guard_diagnostic.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(ok=record['ok'], reply=record.get('reply'), error=record.get('error'))))
