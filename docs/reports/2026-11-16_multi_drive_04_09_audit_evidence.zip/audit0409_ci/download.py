﻿import hashlib, io, json, sys, urllib.request, zipfile
from pathlib import Path
out=Path(__file__).resolve().parent
name,url,digest=sys.argv[1:]
assert name in ('native-gcc','native-clang','arduino','native-idf')
try:
 data=urllib.request.urlopen(url,timeout=60).read()
except Exception as error:
 raise SystemExit('artifact download failed: '+type(error).__name__)
actual=hashlib.sha256(data).hexdigest()
assert 'sha256:'+actual==digest
with zipfile.ZipFile(io.BytesIO(data)) as archive:
 assert archive.testzip() is None
 summaries=[n for n in archive.namelist() if n.endswith('summary.json')]
 assert len(summaries)==1
 summary=json.loads(archive.read(summaries[0]))
 assert summary['status']=='PASS' and summary['registered_tests']==97
 assert all(check['exit']==0 for check in summary['checks'])
 (out/(name+'-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
(out/(name+'.zip')).write_bytes(data)
print(json.dumps(dict(name=name,bytes=len(data),sha256=actual,status=summary['status'],registered_tests=summary['registered_tests'],checks=len(summary['checks']))))
