#define main originalIoQualificationMain
#include "../../test/io_qualification_app_test.cpp"
#undef main
int main() {
    fresh(); wiring(0, InputWiring::CONNECTED); ioBaseline();
    auto q = facts(0); q.function = 7; assert(installIoQualification(q));
    assert(valid(0));
    read(ESS::ReadKind::STATE);
    IoQualification copied; bool current = false;
    assert(copyIoQualification(1,0,IoPurpose::ASSIGN,copied,current));
    uint32_t id = 777; const auto traffic = frames.size();
    const auto admitted = update(input(7),id);
    std::printf("ASSIGN inspector_valid=%u retained_state_id=%u current_state_id=%u update_ok=%u operation_id=%u frames_added=%zu\n",
        current, copied.stateOperationId, app->stateCache.blocks[1].value.operationId, bool(admitted), id, frames.size()-traffic);
    assert(current && !admitted && id == 777 && frames.size() == traffic);
}
