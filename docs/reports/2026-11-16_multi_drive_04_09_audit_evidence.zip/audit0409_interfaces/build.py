from pathlib import Path
import subprocess
root=Path.cwd(); build=root/'build/m04_app_review'; dest=root/'build/audit0409_interfaces'
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','io_qualification_app_test'],text=True).splitlines()
c=next(c for c in commands if ' -c ' in c and c.endswith('/test/io_qualification_app_test.cpp'))
a=c.split(); compiler=a[0]
flags=a[1:a.index('-MD')]
subprocess.run([compiler,*flags,'-c',str(dest/'repro.cpp'),'-o',str(dest/'repro.o')],check=True)
objects=[p for p in (build/'CMakeFiles/io_qualification_app_test.dir').rglob('*.obj') if p.name!='io_qualification_app_test.cpp.obj']
subprocess.run([compiler,str(dest/'repro.o'),*[str(p) for p in objects],str(build/'libMotorControlRS.a'),'-o',str(dest/'repro.exe')],check=True)
r=subprocess.check_output([str(dest/'repro.exe')],text=True)
(dest/'repro.log').write_text(r); print(r)
