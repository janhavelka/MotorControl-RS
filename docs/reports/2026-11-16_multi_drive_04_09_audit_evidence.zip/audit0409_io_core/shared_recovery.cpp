﻿#define main originalGroupMain
#include "../../test/group_app_test.cpp"
#undef main
int main() {
 const std::vector<uint8_t> members={2,4,5};fresh({1,2,4,5});readyGroup(members);
 app->nextOperationId=UINT32_MAX-8;
 loseAcknowledgement=[](const std::vector<uint8_t>&f){return isStart(f,4);};
 uint32_t move=0;assert(submitGroupMoves(memberMoves(members,Policy::STOP_FAST),move));
 const uint32_t reserved=app->group.move.fallbackRecoveryId;
 runUntil([&]{return count([](const std::vector<uint8_t>&f){return isStart(f,4);})==1;});
 ActionRequest request;request.kind=ActionKind::STOP;request.stop.behavior=StopBehavior::DIRECT;
 uint32_t explicitStop=0;assert(startActionIn(*app,0,1,request,explicitStop,false)==Probe::Action::OK);
 assert(app->nextOperationId==0);
 runUntil([&]{return !groupOp(move).result.pending;},4000000);
 const auto* es=findRecord(*app,explicitStop);
 std::printf("reserved=%u recovery=%u explicitrecovery=%u next=%u consumed=%u\n",reserved,app->recovery.operationId,es->stopRecoveryOperationId,app->nextOperationId,app->group.move.fallbackRecoveryId);
 assert(app->recovery.operationId==reserved&&es->stopRecoveryOperationId==reserved&&!app->group.move.fallbackRecoveryId);
 for(auto address:members){const auto&m=memberResult(move,address);const auto*stop=findRecord(*app,m.stopOperationId);std::printf("member=%u start=%u stopId=%u stoprecovery=%u frames=%u laterstarts=%u\n",unsigned(address),unsigned(m.start),m.stopOperationId,stop?stop->stopRecoveryOperationId:0,count([&](const std::vector<uint8_t>&f){return isStop(f,address);}),count([&](const std::vector<uint8_t>&f){return isStart(f,address);}));if(address!=5){assert(stop&&stop->stopRecoveryOperationId==reserved);assert(count([&](const std::vector<uint8_t>&f){return isStop(f,address);})==1);}else assert(count([&](const std::vector<uint8_t>&f){return isStart(f,address);})==0);}
}
