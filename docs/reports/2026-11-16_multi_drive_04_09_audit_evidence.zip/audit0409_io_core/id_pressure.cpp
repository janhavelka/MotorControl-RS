﻿#define main originalGroupMain
#include "../../test/group_app_test.cpp"
#undef main
int main() {
 const std::vector<uint8_t> members={2,4,5};
 fresh({1,2,4,5}); readyGroup(members);
 app->nextOperationId = UINT32_MAX - 8;
 auto request=memberMoves(members,Policy::STOP_FAST);
 loseAcknowledgement=[](const std::vector<uint8_t>& f){return isStart(f,5);};
 uint32_t move=0; assert(submitGroupMoves(request,move));
 ActionRequest stop;stop.kind=ActionKind::STOP;stop.stop.behavior=StopBehavior::DIRECT;
 for(unsigned i=0;i<2;++i){
  uint32_t id=0;auto a=startActionIn(*app,0,1,stop,id,false);
  std::printf("nonmember stop admitted=%u id=%u remaining-next=%u\n",unsigned(a),id,app->nextOperationId);
  assert(a==Probe::Action::OK);
 }
 runUntil([&]{return !groupOp(move).result.pending;},4000000);
 std::printf("group pending=%u next=%u recovery=%u\n",unsigned(groupOp(move).result.pending),app->nextOperationId,app->recovery.operationId);
 for(auto address:members){const auto&m=memberResult(move,address);std::printf("member=%u start=%u stopAdmission=%u stopId=%u stopFrames=%u\n",unsigned(address),unsigned(m.start),unsigned(m.stopAdmission),m.stopOperationId,count([&](const std::vector<uint8_t>&f){return isStop(f,address);}));}
}
