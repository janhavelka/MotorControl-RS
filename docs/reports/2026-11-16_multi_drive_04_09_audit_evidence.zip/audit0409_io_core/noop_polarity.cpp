﻿#define main originalIoMain
#include "../../test/io_test.cpp"
#undef main
#include <cstdio>
int main() {
 for (uint8_t index : {uint8_t(7),uint8_t(12)}) {
  auto r=request(index);
  auto p=prerequisites(r);
  for(auto& w:p.inputWiring) w=InputWiring::CONNECTED;
  for(auto& w:p.outputWiring) w=InputWiring::CONNECTED;
  for(auto& f:p.inputFacts) f=E::IoInputFacts();
  for(auto& f:p.outputFacts) f=E::IoOutputFacts();
  p.allowEchoReadback=true;
  E::DriverContext c;
  auto s=E::prepareDriverSettings(c,target(),12,r,p,200,9000);
  std::printf("same polarity index=%u admitted=%d %s\n",unsigned(index),bool(s),s.msg);
  if(s) { auto w=work(c); std::printf("write reg=%04x value=%u, connected terminals, no terminal facts, echo allowed\n", w.reg,w.value); ack(c,false); supply(c,reply({0})); std::printf("state=%u uncertain=%u execution=%u\n",unsigned(c.state),unsigned(c.uncertain),unsigned(c.progress[index].execution)); }
 }
}
