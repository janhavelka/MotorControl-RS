﻿from pathlib import Path
import subprocess
root=Path.cwd();b=root/'build/audit0409_io_core/native';out=root/'build/audit0409_io_core'
lines=subprocess.check_output(['ninja','-C',str(b),'-t','commands','group_app_test'],text=True).splitlines()
c=next(l for l in lines if ' -c ' in l and l.endswith('/test/group_app_test.cpp')).split()
for flag in ('-o','-MF','-MT'):
 c[c.index(flag)+1]=str(out/('id_pressure.obj.d' if flag=='-MF' else 'id_pressure.obj'))
c[-1]=str(out/'id_pressure.cpp')
subprocess.run(c,cwd=b,check=True)
objects=[str(p) for p in (b/'CMakeFiles/group_app_test.dir').rglob('*.obj') if p.name!='group_app_test.cpp.obj']
subprocess.run([c[0],str(out/'id_pressure.obj'),*objects,str(b/'libMotorControlRS.a'),'-o',str(out/'id_pressure.exe')],check=True)
