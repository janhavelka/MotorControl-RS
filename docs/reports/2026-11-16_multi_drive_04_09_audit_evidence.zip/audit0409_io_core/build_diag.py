﻿from pathlib import Path
import subprocess,sys
root=Path.cwd();b=root/'build/audit0409_io_core/native';out=root/'build/audit0409_io_core';name=sys.argv[1]
lines=subprocess.check_output(['ninja','-C',str(b),'-t','commands','group_app_test'],text=True).splitlines()
c=next(l for l in lines if ' -c ' in l and l.endswith('/test/group_app_test.cpp')).split()
for flag in ('-o','-MF','-MT'): c[c.index(flag)+1]=str(out/(name+'.obj.d' if flag=='-MF' else name+'.obj'))
c[-1]=str(out/(name+'.cpp'));subprocess.run(c,cwd=b,check=True)
objects=[str(p) for p in (b/'CMakeFiles/group_app_test.dir').rglob('*.obj') if p.name!='group_app_test.cpp.obj']
subprocess.run([c[0],str(out/(name+'.obj')),*objects,str(b/'libMotorControlRS.a'),'-o',str(out/(name+'.exe'))],check=True)
