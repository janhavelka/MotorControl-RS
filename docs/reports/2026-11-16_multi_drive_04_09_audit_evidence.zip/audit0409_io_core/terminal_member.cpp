﻿#define main originalGroupMain
#include "../../test/group_app_test.cpp"
#undef main
int main() {
 const auto members=addresses(Probe::GROUP_CAPACITY); fresh(members); readyGroup(members);
 Serial.writeCapacity=0; while(app->outputCount<OUTPUT_LINES) assert(emit(app,"blocked",7));
 Probe::GroupCommand command;command.kind=Probe::GroupCommandKind::STOP;command.stop=StopBehavior::DIRECT;
 Probe::GroupReply reply;assert(groupCommand(app,900,command,reply)==Probe::Action::OK);
 runUntil([&]{return !groupOp(reply.operationId).result.pending;},4000000);
 uint32_t state=0;assert(submitGroupStateRead(state));runUntil([&]{return !groupOp(state).result.pending;},4000000);
 uint32_t move=0;assert(submitGroupMoves(memberMoves(members,Policy::STOP_FAST,Mode::SEQUENTIAL),move));
 drives[1].regs[6]=1;
 auto* early=findRecord(*app,groupOp(move).result.members[0].operationId);
 runUntil([&]{return terminal(*app,*early);},4000000);
 std::printf("early state=%u start=%u startsDone=%u nextmember=%u\n",unsigned(early->move.state),unsigned(classifyStart(early->move)),unsigned(app->group.move.startsDone),unsigned(app->group.move.next));
 assert(!app->group.move.startsDone);
 unsigned char saved[sizeof(early->move)];std::memcpy(saved,&early->move,sizeof(saved));
 uint32_t stop=0;assert(submitGroupStop(StopBehavior::DIRECT,stop));
 runUntil([&]{return !groupOp(move).result.pending&&!groupOp(stop).result.pending;},4000000);
 const bool preserved=std::memcmp(saved,&early->move,sizeof(saved))==0;
 auto&m=memberResult(move,1);
 std::printf("explicitMask=%u originalPreserved=%u fallbackAdmission=%u fallbackId=%u\n",unsigned(app->group.move.explicitStops),preserved,unsigned(m.stopAdmission),m.stopOperationId);
 assert(preserved);
}
