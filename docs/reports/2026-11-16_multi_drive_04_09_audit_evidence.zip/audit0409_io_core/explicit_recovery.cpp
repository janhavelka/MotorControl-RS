﻿#define main originalGroupMain
#include "../../test/group_app_test.cpp"
#undef main
int main() {
 const std::vector<uint8_t> members={1,2,4}; fresh(members); readyGroup(members);
 app->nextOperationId=UINT32_MAX-11;
 uint32_t move=0; assert(submitGroupMoves(memberMoves(members,Policy::STOP_FAST),move));
 runUntil([&]{return app->group.move.startsDone;});
 loseAcknowledgement=[](const std::vector<uint8_t>&f){return isStop(f,1);};
 uint32_t stop=0; assert(submitGroupStop(StopBehavior::DIRECT,stop));
 std::printf("group=%u explicitstop=%u globalnext=%u reservedrecovery=%u\n",move,stop,app->nextOperationId,app->group.move.fallbackRecoveryId);
 runUntil([&]{return !groupOp(stop).result.pending;},4000000);
 std::printf("group pending=%u reservedrecovery=%u actualrecovery=%u\n",unsigned(groupOp(move).result.pending),app->group.move.fallbackRecoveryId,app->recovery.operationId);
 for(auto address:members){const auto&m=memberResult(stop,address); std::printf("member=%u stopstate=%u execution=%u stopFrames=%u\n",unsigned(address),unsigned(m.state),unsigned(m.execution),count([&](const std::vector<uint8_t>&f){return isStop(f,address);}));}
}
