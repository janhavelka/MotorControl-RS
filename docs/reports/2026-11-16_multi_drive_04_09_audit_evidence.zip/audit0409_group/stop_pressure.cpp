﻿#define main originalGroupMain
#include "../../test/group_app_test.cpp"
#undef main
int main() {
    auto all = addresses(Probe::GROUP_CAPACITY);
    fresh(all); readyGroup(all);
    Serial.writeCapacity = 0;
    while (app->outputCount < OUTPUT_LINES) assert(emit(app, "blocked", 7));
    for (unsigned batch = 0; batch < 2; ++batch) {
        Probe::GroupCommand command; command.kind = Probe::GroupCommandKind::STOP; command.stop = StopBehavior::DIRECT;
        Probe::GroupReply reply;
        assert(groupCommand(app, 900 + batch, command, reply) == Probe::Action::OK);
        runUntil([&] { return !groupOp(reply.operationId).result.pending; }, 4000000);
        assert(!groupOp(reply.operationId).delivered);
    }
    unsigned occupied = 0;
    for (std::size_t i = GROUP_STOP_FIRST; i < GROUP_MOVE_FIRST; ++i)
      if (app->records[i].operationId && !app->records[i].delivered) ++occupied;
    assert(occupied == GROUP_STOP_RECORDS);
    uint32_t state = 0; assert(submitGroupStateRead(state));
    runUntil([&] { return !groupOp(state).result.pending; }, 4000000);
    auto request = memberMoves(all, Policy::STOP_FAST);
    loseAcknowledgement = [](const std::vector<uint8_t>& frame) { return isStart(frame, 2); };
    const auto from = frames.size(); uint32_t id = 0;
    const auto admitted = submitGroupMoves(request, id);
    std::printf("group stop slots occupied=%u; move admitted=%d id=%u\n", occupied, bool(admitted), id);
    if (admitted) {
      runUntil([&] { return !groupOp(id).result.pending; }, 4000000);
      for (const uint8_t address : {1,2}) {
        const auto& m = memberResult(id,address);
        std::printf("address=%u start=%u stopAdmission=%u stopId=%u stopFrames=%u\n", address,unsigned(m.start),unsigned(m.stopAdmission),m.stopOperationId,
          count([&](const std::vector<uint8_t>& frame) { return isStop(frame,address); },from));
      }
    }
}
