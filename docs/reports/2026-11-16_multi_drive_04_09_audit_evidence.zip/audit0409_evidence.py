from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent.parent
build = root / 'build'
commit = sys.argv[1]
baseline = subprocess.check_output(['git', 'rev-parse', '92e5d2b'], cwd=root, text=True).strip()
assert subprocess.check_output(['git', 'rev-parse', commit], cwd=root, text=True).strip() == commit
out = root / 'docs/reports/2026-11-16_multi_drive_04_09_audit_evidence.zip'
entries = {}

def add(path, name=None):
    if path.is_file():
        entries[name or path.relative_to(build).as_posix()] = path.read_bytes()

for directory in ('audit0409_io_core', 'audit0409_group', 'audit0409_interfaces'):
    for path in (build / directory).iterdir():
        if path.suffix in ('.cpp', '.py', '.json', '.log', '.txt', '.png'):
            add(path)
    add(build / directory / 'native/Testing/Temporary/LastTest.log')
for directory in ('audit0409_final_verify', 'audit0409_verified', 'audit0409_s3_layout'):
    for path in (build / directory).iterdir():
        if path.suffix in ('.json', '.log', '.txt', '.py', '.su', '.rsp', '.cpp'):
            add(path)
for directory in ('audit0409_hardware', 'audit0409_ci'):
    for path in (build / directory).iterdir():
        add(path)
for path in build.glob('audit0409_*'):
    if path.is_file() and path.suffix in ('.py', '.log', '.json', '.txt'):
        add(path)
for name in ('04_input_programming.md', '09_member_motion_requests.md'):
    add(root / 'docs/prompts/ess_multi_drive' / name, 'original_prompts/' + name)
sources = {}
for name in ('Modbus-Series-Bus-Product-Function-Manual-V1.0_1_.pdf',
             'ESS23-RS1020_Series_Bus_Integrated_Motor_Hardware_Manual.pdf'):
    path = root / 'docs/vendor' / name
    sources[name] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
entries['reviewed_sources.json'] = (json.dumps(sources, indent=2) + '\n').encode()
entries['implementation.patch'] = subprocess.check_output(['git', 'diff', '--binary', baseline, commit], cwd=root)
entries['implementation-stat.txt'] = subprocess.check_output(['git', 'diff', '--stat', baseline, commit], cwd=root)
entries['README.txt'] = f'''Multi-drive 04/09 independent audit evidence, 16 November 2026.
Implementation: {commit}
Baseline: {baseline}
FieldCore read-only reference: c40ea8341edf8d665460b902cafefbe857a7f73f

Independent review records, original reproducers and failed intermediate
approaches are retained. They are not instructions to replay motor writes.
The report identifies final results and remaining physical limits.
audit0409_final_verify: initial run, retained exact-diagnostic assertion failure.
audit0409_verified: final fresh quick verifier and all registered tests.
audit0409_s3_layout: actual SDK compile flags, fixed storage and GCC stack frames.
audit0409_ci: exact-commit run, jobs, digest-checked artifacts and summaries.
audit0409_hardware: exact COM13 USB guard, image/upload, bounded regression
scripts, backups, complete operation records and final state.

No wired effects, drive restart/persistence, physical absolute calibration,
independent skew or electrical timing were qualified. No uncertain write replay.
'''.encode()
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in sorted(entries.items())}
entries['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(entries.items()):
        archive.writestr(name, data)
with zipfile.ZipFile(out) as archive:
    assert archive.testzip() is None
print(json.dumps({'path': out.relative_to(root).as_posix(), 'files': len(entries),
                  'bytes': out.stat().st_size, 'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}))
