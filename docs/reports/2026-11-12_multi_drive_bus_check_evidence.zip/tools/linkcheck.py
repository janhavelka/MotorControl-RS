"""Read-only link check: model-register probes per address, raw traffic on.

On a failed probe: record it, run one explicit host transport recovery, continue.
Bounded by --count per address and --max-failures overall. No motor writes.
"""
import argparse, json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'scripts'))
from bench_probe import Console, Evidence, open_port

p = argparse.ArgumentParser()
p.add_argument('--log', required=True)
p.add_argument('--addresses', default='1,2,3')
p.add_argument('--count', type=int, default=300)
p.add_argument('--interval', type=float, default=0.01)
p.add_argument('--max-failures', type=int, default=12)
p.add_argument('--debug', default='raw')
args = p.parse_args()
addresses = [int(x) for x in args.addresses.split(',')]
failures = []
counts = {a: [0, 0] for a in addresses}
with open(args.log, 'x', encoding='utf-8', newline='\n') as stream, open_port('COM13', 115200, 5) as port:
    c = Console(port, on_event=Evidence(stream, max_records=400000, max_bytes=256*1024*1024))
    c.drain_startup(.3); c.identify(timeout_s=5)
    st = c.command('status', timeout_s=5)
    if st.get('recovery_required'):
        print('initial recover', c.command('recover', timeout_s=5).get('outcome'))
    print('stats before', json.dumps(c.command('stats', timeout_s=5))[:600])
    if args.debug != 'off':
        c.command('debug', host_args=(args.debug,), timeout_s=5)
    try:
        for i in range(args.count):
            for a in addresses:
                r = c.command('probe', address=a, timeout_s=5)
                counts[a][0] += 1
                if r.get('ok'):
                    counts[a][1] += 1
                else:
                    f = {k: r.get(k) for k in ('id', 'address', 'outcome', 'transport', 'codec', 'rx_hex', 'rx_bytes',
                                              'tx_end_us', 'first_rx_start_us', 'duration_us')}
                    f['round'] = i
                    failures.append(f); print('FAIL', json.dumps(f)); sys.stdout.flush()
                    rec = c.command('recover', timeout_s=5)
                    print('  recover', rec.get('outcome'))
                    if len(failures) >= args.max_failures: raise SystemExit('failure bound reached')
                time.sleep(args.interval)
    finally:
        if args.debug != 'off':
            c.command('debug', host_args=('off',), timeout_s=5)
        print('stats after', json.dumps(c.command('stats', timeout_s=5))[:900])
        print('counts', counts, 'failures', len(failures))
