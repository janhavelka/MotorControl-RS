"""Run a short explicit list of console commands on COM13 and log everything.

Each argument is a JSON object: {"c": command, ...Console.command kwargs}.
host_args lists become tuples. No retries; stops on the first framing failure.
"""
import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'scripts'))
from bench_probe import Console, Evidence, open_port

def main():
    log = Path(sys.argv[1])
    steps = [json.loads(a) for a in sys.argv[2:]]
    with log.open('x', encoding='utf-8', newline='\n') as stream, open_port('COM13', 115200, 5) as port:
        console = Console(port, on_event=Evidence(stream))
        console.drain_startup(.3)
        console.identify(timeout_s=5)
        for step in steps:
            step = dict(step)
            name = step.pop('c')
            for key in ('host_args', 'move_args', 'driver_args', 'home_args', 'velocity_args'):
                if key in step: step[key] = tuple(step[key])
            step.setdefault('timeout_s', 5)
            result = console.command(name, **step)
            print(json.dumps({'command': name, 'args': step, 'result': result})[:4000])
            sys.stdout.flush()

if __name__ == '__main__':
    main()
