#define main registered_velocity_main
#include "../../test/velocity_app_test.cpp"
#undef main

int main() {
    unsigned failed = 0;
    for (unsigned ms = 200; ms <= 300; ++ms) {
        fresh(); qualify();
        auto r = request(); r.durationUs = ms * 1000;
        uint32_t id = 0;
        assert(host(app).startVelocity(app, 1, 1, r, id) == Probe::Action::OK);
        unsigned seen = 0, stops = 0;
        while (view(id).pending && hardware.time < 6000000) {
            step();
            if (hardware.writes == seen) continue;
            seen = hardware.writes;
            const auto& tx = hardware.tx;
            if (tx.size() == 8 && tx[1] == 6 && tx[2] == 0 && tx[3] == 0x27 && tx[4]) ++stops;
            auto response = tx[1] == 3 ? registers(1, {0, static_cast<uint16_t>(stops ? 0 : 4)}) : acknowledgement();
            scheduleReply(std::max(hardware.writeStarted + tx.size()*87 + 1000, hardware.time + 1000), response);
        }
        const auto& result = *view(id).velocityContext;
        if (!stops) {
            ++failed;
            std::printf("C1 duration_ms=%u stops=%u recovery=%d needsStop=%d outcome=%u\n", ms, stops,
                app->owner.needsRecovery(), result.needsStop, static_cast<unsigned>(result.outcome));
            assert(result.needsStop && app->owner.needsRecovery());
        }
    }
    std::printf("C1 healthy sweep: %u/101 durations sent no stop\n", failed);
    assert(failed);
    lostStartNeverReplays();
    std::printf("C14 current lost-start regression passed: exactly 2 writes (staging/start), no stop, needsStop retained\n");
    fresh(); qualify(); app->knownTargets[0] |= (1U << 2);
    ActionRequest stop; stop.kind = ActionKind::STOP;
    stop.stop.behavior = StopBehavior::CONFIGURED_DECELERATION;
    uint32_t one = 0, two = 0, fast = 777;
    assert(startAction(app, 20, 1, stop, one) == Probe::Action::OK);
    assert(startAction(app, 21, 2, stop, two) == Probe::Action::OK);
    stop.stop.behavior = StopBehavior::DIRECT;
    const auto admission = startAction(app, 22, 1, stop, fast);
    assert(admission == Probe::Action::RESULTS_FULL && fast == 777);
    std::printf("C11 two non-group address stops prevent fast escalation: results_full, original IDs retained\n");
}
