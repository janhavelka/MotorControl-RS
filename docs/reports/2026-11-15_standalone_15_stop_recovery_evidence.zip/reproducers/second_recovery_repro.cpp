#define main existing_stop_tests_main
#include "../../test/stop_path_app_test.cpp"
#undef main

int main() {
    const auto stopId = stopWithSettledZeroTxFault();
    auto* record = findRecord(*app, stopId);
    const auto firstRecovery = record->stopRecoveryId;
    for (unsigned i = 0; i < 30000 && app->owner.recovering(); ++i) {
        advanceHardware(hardware.time + 100);
        if (hardware.time >= app->recoveryGuardUntilUs && !app->recovery.prepared)
            app->recovery.prepared = uart.clear();
        app->owner.service(uart.sample(), app->recovery.prepared);
    }
    assert(!app->owner.recovering() && record->stopHeld && wire.empty());
    assert(app->owner.recoveryResult(firstRecovery)->outcome == Rtu::RecoveryOutcome::RECOVERED);
    uint32_t secondId = 0;
    assert(startRecovery(*app, 100, false, secondId) == Probe::Action::OK);
    step(RECOVER_US + 1000); // Recovery can finish before the held stop is serviced.
    const auto secondRecovery = app->owner.recoveryResult(app->recovery.id);
    assert(secondRecovery && secondRecovery->outcome == Rtu::RecoveryOutcome::RECOVERED);
    for (unsigned i = 0; i < 10000 && !hardware.writes && view(stopId).pending; ++i) step();
    std::printf("first recovery=%llu, current recovery=%llu, retained recovery=%llu, stop pending=%d, writes=%u, outcome=%u\n",
        static_cast<unsigned long long>(firstRecovery), static_cast<unsigned long long>(app->recovery.id),
        static_cast<unsigned long long>(record->stopRecoveryId), view(stopId).pending, hardware.writes,
        static_cast<unsigned>(actionOf(stopId).outcome));
    return 0;
}
