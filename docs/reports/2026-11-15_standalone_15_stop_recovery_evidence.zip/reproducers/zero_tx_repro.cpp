#define main registered_stop_main
#include "../../test/stop_path_app_test.cpp"
#undef main
int main() {
 fresh(); known();
 ActionRequest stop; stop.kind=ActionKind::STOP; stop.stop.behavior=StopBehavior::DIRECT;
 uint32_t id=0; assert(startAction(app,1,1,stop,id)==Probe::Action::OK);
 scheduleReply(hardware.time+1000, std::vector<uint8_t>(120,0x55),87,913);
 until(id);
 const auto c=actionOf(id);
 std::printf("R02 tx=%zu reason=%u outcome=%u execution=%u recovery=%u owner_fault=%d held=%d\n",c.writeEvidence.txAccepted,(unsigned)c.writeEvidence.transportDetail,(unsigned)c.outcome,(unsigned)c.execution,app->recovery.operationId,app->owner.needsRecovery(),findRecord(*app,id)->stopHeld);
 assert(!hardware.writes && c.execution==ActionExecution::NOT_TRANSMITTED && app->owner.needsRecovery() && !app->recovery.operationId);
}
