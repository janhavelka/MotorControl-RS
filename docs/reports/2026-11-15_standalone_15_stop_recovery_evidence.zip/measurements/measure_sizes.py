from pathlib import Path
import shutil
import subprocess
import zipfile

repo = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
compiler = shutil.which('g++')
for revision in ('2f41e27', '6ee9f01', 'current'):
    root = repo
    if revision != 'current':
        archive = work / ('sizes_' + revision + '.zip')
        subprocess.run(['git', 'archive', '--format=zip', '--output', str(archive), revision,
                        'include', 'examples', 'test/fakes'], cwd=repo, check=True)
        root = work / ('sizes_' + revision)
        with zipfile.ZipFile(archive) as snapshot:
            snapshot.extractall(root)
    source = work / ('measure_' + revision + '.cpp')
    content = '#include "' + (root / 'examples/probe_cli/ProbeApp.cpp').as_posix() + '"\n'
    content += 'extern "C" const size_t measured_sizes[] = {sizeof(App), sizeof(App::Record)'
    if revision == 'current':
        content += ', sizeof(ActionResult)'
    content += '};\n'
    source.write_text(content)
    output = source.with_suffix('.s')
    subprocess.run([compiler, '-std=c++11', '-DCONFIG_IDF_TARGET_ESP32S3=1',
                    '-I' + str(root / 'test/fakes/esp32_uart'), '-I' + str(root / 'include'),
                    '-S', str(source), '-o', str(output)], cwd=repo, check=True)
    print(revision, flush=True)
    rows = output.read_text().splitlines()
    start = rows.index('measured_sizes:')
    print('\n'.join(rows[start:start + (4 if revision == 'current' else 3)]), flush=True)
