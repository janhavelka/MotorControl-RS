	.file	"ProbeConsole.cpp"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC107:
	.string	"unknown"
	.text
	.literal_position
	.literal .LC108, .LC107
	.literal .LC109, CSWTCH$1339
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE:
.LFB999:
	entry	sp, 32
.LCFI0:
	mov.n	a8, a2
	l32r	a2, .LC108
	bgeui	a8, 5, .L1
	l32r	a9, .LC109
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L1:
	retw.n
.LFE999:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE
	.literal_position
	.literal .LC110, .LC107
	.literal .LC111, CSWTCH$1347
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111hostFailureENS0_11HostFailureE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111hostFailureENS0_11HostFailureE:
.LFB1005:
	entry	sp, 32
.LCFI1:
	mov.n	a8, a2
	l32r	a2, .LC110
	bgeui	a8, 4, .L4
	l32r	a9, .LC111
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L4:
	retw.n
.LFE1005:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111hostFailureENS0_11HostFailureE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111hostFailureENS0_11HostFailureE
	.section	.rodata.str1.1
.LC83:
	.string	"steps"
.LC84:
	.string	"fullsteps"
.LC85:
	.string	"counts"
.LC86:
	.string	"turn"
.LC87:
	.string	"deg"
.LC88:
	.string	"rad"
.LC89:
	.string	"mm"
	.section	.rodata
	.align	4
.LC113:
	.word	.LC83
	.word	.LC84
	.word	.LC85
	.word	.LC86
	.word	.LC87
	.word	.LC88
	.word	.LC89
	.text
	.literal_position
	.literal .LC112, .LC107
	.literal .LC114, .LC113
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE:
.LFB1010:
	entry	sp, 64
.LCFI2:
	l32r	a11, .LC114
	mov.n	a7, a2
	movi.n	a12, 0x1c
	mov.n	a10, sp
	call8	memcpy
	l32r	a2, .LC112
	bgeui	a7, 7, .L7
	addx4	a7, a7, sp
	l32i	a2, a7, 0
.L7:
	retw.n
.LFE1010:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	.section	.rodata.str1.1
.LC115:
	.string	"help moveby\n  @1 status  (machine-readable JSON)"
.LC117:
	.string	"moveby 100\n  moveby 36 deg"
.LC119:
	.string	"moveto 100 steps\n  moveto 36 deg"
.LC121:
	.string	"position interrupt 17  (active native move operation ID)"
.LC123:
	.string	"speed 60"
.LC125:
	.string	"accel 100"
.LC127:
	.string	"decel 100"
.LC129:
	.string	"motion\n  motion write\n  motion stored"
.LC131:
	.string	"subdivision\n  subdivision options\n  subdivision 1600"
.LC133:
	.string	"stepsperturn 1000  (only if this is your established scale)"
.LC135:
	.string	"probe 1"
.LC137:
	.string	"read config 1\n  read state 1"
.LC139:
	.string	"debug decoded\n  debug off"
.LC141:
	.string	"move relative 100 steps native 60 configured 1"
.LC143:
	.string	"stop normal 1\n  stop fast 1"
.LC145:
	.string	"group set 1 2 4\n  group read state\n  group move relative 200 steps native 60 configured on-failure stop fast\n  group stop fast"
.LC147:
	.string	"result 12"
.LC149:
	.string	"release 12  (after inspecting the terminal result)"
.LC151:
	.string	"cancel 12  (local cancellation; use stop for the motor)"
.LC153:
	.string	"host\n  host caps"
.LC155:
	.string	"discover addresses 1 1\n  discover inspect"
.LC157:
	.string	"motion-profile start-speed 30"
.LC159:
	.string	"motion-profile read\n  motion-profile inspect"
.LC161:
	.string	"monitor 500 10\n  monitor off"
.LC163:
	.string	"profile list"
.LC165:
	.string	"axis config"
.LC167:
	.string	"prepare relative 100 steps native actual"
.LC169:
	.string	"home methods"
.LC171:
	.string	"motion-profile read\n  motion-profile inspect\n  motion-profile start-speed 30"
.LC173:
	.string	"home methods\n  home qualification install 35 60 30 100 mechanics rates ramp zero-offset auxiliary inputs"
.LC175:
	.string	"position-clear qualification install clear-semantics"
.LC177:
	.string	"velocity read\n  velocity qualification install rpm ramp inputs"
	.text
	.literal_position
	.literal .LC116, .LC115
	.literal .LC118, .LC117
	.literal .LC120, .LC119
	.literal .LC122, .LC121
	.literal .LC124, .LC123
	.literal .LC126, .LC125
	.literal .LC128, .LC127
	.literal .LC130, .LC129
	.literal .LC132, .LC131
	.literal .LC134, .LC133
	.literal .LC136, .LC135
	.literal .LC138, .LC137
	.literal .LC140, .LC139
	.literal .LC142, .LC141
	.literal .LC144, .LC143
	.literal .LC146, .LC145
	.literal .LC148, .LC147
	.literal .LC150, .LC149
	.literal .LC152, .LC151
	.literal .LC154, .LC153
	.literal .LC156, .LC155
	.literal .LC158, .LC157
	.literal .LC160, .LC159
	.literal .LC162, .LC161
	.literal .LC164, .LC163
	.literal .LC166, .LC165
	.literal .LC168, .LC167
	.literal .LC170, .LC169
	.literal .LC172, .LC171
	.literal .LC174, .LC173
	.literal .LC176, .LC175
	.literal .LC178, .LC177
	.literal .LC179, .L13
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111helpExampleENS1_7CommandERKNS0_4HostE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111helpExampleENS1_7CommandERKNS0_4HostE:
.LFB1027:
	entry	sp, 32
.LCFI3:
	movi.n	a8, 0x38
	bltu	a8, a2, .L11
	l32r	a8, .LC179
	addx4	a2, a2, a8
	l32i	a8, a2, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L13:
	.word	.L41
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L40
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L39
	.word	.L38
	.word	.L37
	.word	.L36
	.word	.L35
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L34
	.word	.L33
	.word	.L32
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L31
	.word	.L30
	.word	.L29
	.word	.L28
	.word	.L11
	.word	.L11
	.word	.L27
	.word	.L11
	.word	.L11
	.word	.L11
	.word	.L26
	.word	.L11
	.word	.L11
	.word	.L25
	.word	.L24
	.word	.L23
	.word	.L11
	.word	.L11
	.word	.L42
	.word	.L21
	.word	.L20
	.word	.L19
	.word	.L18
	.word	.L17
	.word	.L16
	.word	.L11
	.word	.L15
	.word	.L14
	.word	.L11
	.word	.L12
	.text
.L41:
	l32r	a2, .LC116
	j	.L10
.L11:
	movi.n	a2, 0
	j	.L10
.L21:
	l32r	a2, .LC120
	j	.L10
.L14:
	l32r	a2, .LC122
	j	.L10
.L20:
	l32r	a2, .LC124
	j	.L10
.L19:
	l32r	a2, .LC126
	j	.L10
.L18:
	l32r	a2, .LC128
	j	.L10
.L17:
	l32r	a2, .LC130
	j	.L10
.L15:
	l32r	a2, .LC132
	j	.L10
.L16:
	l32r	a2, .LC134
	j	.L10
.L40:
	l32r	a2, .LC136
	j	.L10
.L36:
	l32r	a2, .LC138
	j	.L10
.L24:
	l32r	a2, .LC140
	j	.L10
.L30:
	l32r	a2, .LC142
	j	.L10
.L31:
	l32r	a2, .LC144
	j	.L10
.L12:
	l32r	a2, .LC146
	j	.L10
.L39:
	l32r	a2, .LC148
	j	.L10
.L37:
	l32r	a2, .LC150
	j	.L10
.L38:
	l32r	a2, .LC152
	j	.L10
.L26:
	l32r	a2, .LC154
	j	.L10
.L23:
	l32r	a2, .LC156
	j	.L10
.L25:
	l32i	a8, a3, 116
	l32r	a2, .LC158
	beqz.n	a8, .L10
	l32i	a8, a3, 52
	l32r	a2, .LC160
	beqz.n	a8, .L10
	l32i	a8, a3, 12
	l32r	a2, .LC172
	bnez.n	a8, .L10
	l32r	a2, .LC160
	j	.L10
.L34:
	l32r	a2, .LC162
	j	.L10
.L35:
	l32r	a2, .LC164
	j	.L10
.L33:
	l32r	a2, .LC166
	j	.L10
.L32:
	l32r	a2, .LC168
	j	.L10
.L27:
	l32i	a8, a3, 64
	l32r	a2, .LC170
	beqz.n	a8, .L10
	l32r	a2, .LC174
	j	.L10
.L28:
	l32i	a9, a3, 64
	l32r	a2, .LC178
	j	.L49
.L29:
	l32i	a9, a3, 64
	l32r	a2, .LC176
.L49:
	movi.n	a8, 0
	moveqz	a2, a8, a9
	j	.L10
.L42:
	l32r	a2, .LC118
.L10:
	retw.n
.LFE1027:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111helpExampleENS1_7CommandERKNS0_4HostE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111helpExampleENS1_7CommandERKNS0_4HostE
	.section	.rodata.str1.1
.LC181:
	.string	"List documented homing methods."
.LC183:
	.string	"local_method_inventory"
.LC185:
	.string	"home methods | home method search_native return_native ramp_native zero [address]"
.LC187:
	.string	"List homing methods or request qualified homing."
.LC189:
	.string	"qualified_homing_with_fresh_completion_and_zero_evidence"
.LC191:
	.string	"home methods | home read [address]"
.LC193:
	.string	"Read raw homing parameters or list methods."
.LC195:
	.string	"checked_parameter_read_and_method_inventory"
.LC197:
	.string	"explicit_auxiliary_setting_with_independent_active_policy"
.LC199:
	.string	"Select auxiliary configuration or list methods."
.LC201:
	.string	"home methods | home auxiliary <0..11>"
.LC203:
	.string	"checked_parameter_read_or_qualified_homing"
.LC205:
	.string	"Read native homing parameters, list methods or request qualified homing."
.LC207:
	.string	"home methods | home read [address] | home method search_native return_native ramp_native zero [address]"
.LC209:
	.string	"Read homing parameters, select auxiliary configuration or list methods."
.LC211:
	.string	"home methods | home read [address] | home auxiliary <0..11>"
.LC213:
	.string	"Select auxiliary configuration, list methods or request qualified homing."
.LC215:
	.string	"home methods | home auxiliary <0..11> | home method search_native return_native ramp_native zero [address]"
.LC217:
	.string	"home methods | home qualification | home read [address] | home auxiliary <0..11> | home method search_native return_native ramp_native zero [address]"
.LC219:
	.string	"finite_serial_velocity_with_explicit_stop"
.LC221:
	.string	"Request finite velocity with an explicit stop policy."
.LC223:
	.string	"velocity value rpm|steps/s|fullsteps/s|counts/s|turns/s|deg/s|rad/s|mm/s native|motor|load duration_ms configured normal|fast [round mode error [approx error]] [address]"
.LC225:
	.string	"Explicitly set the drive position counter to zero, after stating that its clear semantics are qualified."
.LC227:
	.string	"position-clear [address] | position-clear qualification install clear-semantics | position-clear qualification revoke"
.LC229:
	.string	"explicit_native_start_speed_setting"
.LC231:
	.string	"Explicitly set the native position start-speed word."
.LC233:
	.string	"motion-profile start-speed <native>"
.LC235:
	.string	"snapshot_position_parameters_restore_or_explicitly_release_snapshot"
.LC237:
	.string	"Read, inspect or restore position parameters; forget releases the snapshot."
.LC239:
	.string	"motion-profile read|inspect|restore|forget"
.LC241:
	.string	"Read homing parameters, state qualification facts, select auxiliary configuration, list methods or request qualified homing."
.LC243:
	.ascii	"home methods | home qualification | home quali"
	.string	"fication install METHOD SEARCH RETURN RAMP mechanics rates ramp zero-offset auxiliary inputs [index] [reference] | home qualification revoke | home read [address] | home auxiliary <0..11> | home method search_native return_native ramp_native zero [address]"
.LC245:
	.string	"stats"
.LC247:
	.string	"stats reset"
.LC249:
	.string	"checked_parameter_read"
.LC251:
	.string	"Read raw velocity parameters."
.LC253:
	.string	"velocity read [address]"
.LC255:
	.string	"Read native velocity parameters, state qualification facts or request finite velocity with an explicit stop policy."
.LC257:
	.ascii	"velocity read [address] | veloc"
	.string	"ity qualification install rpm ramp inputs [negative] | velocity qualification revoke | velocity value rpm|steps/s|fullsteps/s|counts/s|turns/s|deg/s|rad/s|mm/s native|motor|load duration_ms configured normal|fast [round mode error [approx error]] [address]"
.LC259:
	.ascii	"Rea"
	.string	"d, inspect or restore position parameters; explicitly set native start speed; a set locks moves until start-speed relation states the minimum rpm for the stored word. A controller restart forgets that lock and uses the stored word under the startup policy."
.LC261:
	.string	"motion-profile read|inspect|restore|forget | motion-profile start-speed <native> | motion-profile start-speed relation RAW_WORD MIN_RPM"
	.text
	.literal_position
	.literal .LC180, .LC169
	.literal .LC182, .LC181
	.literal .LC184, .LC183
	.literal .LC186, .LC185
	.literal .LC188, .LC187
	.literal .LC190, .LC189
	.literal .LC192, .LC191
	.literal .LC194, .LC193
	.literal .LC196, .LC195
	.literal .LC198, .LC197
	.literal .LC200, .LC199
	.literal .LC202, .LC201
	.literal .LC204, .LC203
	.literal .LC206, .LC205
	.literal .LC208, .LC207
	.literal .LC210, .LC209
	.literal .LC212, .LC211
	.literal .LC214, .LC213
	.literal .LC216, .LC215
	.literal .LC218, .LC217
	.literal .LC220, .LC219
	.literal .LC222, .LC221
	.literal .LC224, .LC223
	.literal .LC226, .LC225
	.literal .LC228, .LC227
	.literal .LC230, .LC229
	.literal .LC232, .LC231
	.literal .LC234, .LC233
	.literal .LC236, .LC235
	.literal .LC238, .LC237
	.literal .LC240, .LC239
	.literal .LC242, .LC241
	.literal .LC244, .LC243
	.literal .LC246, .LC245
	.literal .LC248, .LC247
	.literal .LC250, .LC249
	.literal .LC252, .LC251
	.literal .LC254, .LC253
	.literal .LC256, .LC255
	.literal .LC258, .LC257
	.literal .LC260, .LC259
	.literal .LC262, .LC261
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18helpTextERKNS1_5EntryERKNS0_4HostE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18helpTextERKNS1_5EntryERKNS0_4HostE:
.LFB1028:
	entry	sp, 48
.LCFI4:
	mov.n	a8, a3
	l32i	a12, a8, 24
	mov.n	a10, a2
	l32i	a3, a10, 20
	l32i	a2, a2, 8
	l32i	a4, a10, 12
	l8ui	a11, a10, 16
	movi.n	a9, 0
	beqz.n	a12, .L51
	l32i	a12, a8, 12
	movi.n	a9, 1
	moveqz	a9, a12, a12
.L51:
	l8ui	a10, a10, 4
	movi.n	a12, 0x21
	bne	a10, a12, .L52
	l32i	a11, a8, 56
	movi.n	a10, 0
	beqz.n	a11, .L53
	l32i	a11, a8, 12
	beqz.n	a11, .L53
	l32i	a11, a8, 136
	movi.n	a10, 1
	moveqz	a10, a11, a11
.L53:
	l32i	a11, a8, 52
	movi.n	a12, 0
	beqz.n	a11, .L54
	l32i	a11, a8, 12
	movi.n	a12, 1
	moveqz	a12, a11, a11
.L54:
	or	a11, a9, a10
	bnez.n	a10, .L98
	bnez.n	a9, .L55
	j	.L145
.L98:
	bnez.n	a9, .L99
.L145:
	bnez.n	a10, .L57
.L99:
	beqz.n	a11, .L59
	and	a13, a9, a10
	beqz.n	a12, .L60
	l32r	a4, .LC198
	movi.n	a11, 1
	bnez.n	a13, .L61
	bnez.n	a9, .L148
	j	.L149
.L60:
	beqz.n	a9, .L61
	bnez.n	a10, .L80
	j	.L61
.L80:
	l32r	a4, .LC204
	l32r	a3, .LC206
	l32r	a2, .LC208
	j	.L61
.L95:
	l32r	a4, .LC198
	l32r	a3, .LC200
	l32r	a2, .LC202
	movi.n	a11, 1
	j	.L61
.L96:
	l32r	a4, .LC198
	movi.n	a11, 1
.L148:
	l32r	a3, .LC210
	l32r	a2, .LC212
	j	.L61
.L97:
	l32r	a4, .LC198
	movi.n	a11, 1
.L149:
	l32r	a3, .LC214
	l32r	a2, .LC216
.L61:
	l32i	a13, a8, 60
	beqz.n	a13, .L63
	bnone	a9, a10, .L63
	beqz.n	a12, .L63
	l32r	a2, .LC218
.L63:
	l32i	a8, a8, 64
	beqz.n	a8, .L65
	beqz.n	a13, .L65
	bnone	a9, a10, .L65
	beqz.n	a12, .L65
	j	.L82
.L52:
	movi.n	a12, 0x1e
	bne	a10, a12, .L67
	l32i	a11, a8, 48
	movi.n	a10, 0
	beqz.n	a11, .L68
	l32i	a11, a8, 12
	beqz.n	a11, .L68
	l32i	a11, a8, 136
	movi.n	a10, 1
	moveqz	a10, a11, a11
.L68:
	or	a11, a9, a10
	bnez.n	a10, .L100
	bnez.n	a9, .L85
	j	.L146
.L100:
	bnez.n	a9, .L144
.L146:
	bnez.n	a10, .L86
	beqz.n	a9, .L65
.L144:
	beqz.n	a10, .L65
	l32i	a8, a8, 64
	bnez.n	a8, .L87
	j	.L65
.L67:
	movi.n	a9, 0x1d
	bne	a10, a9, .L71
	l32i	a8, a8, 64
	bnez.n	a8, .L88
	j	.L65
.L71:
	movi.n	a9, 0x28
	bne	a10, a9, .L72
	l32i	a9, a8, 52
	beqz.n	a9, .L90
	l32i	a9, a8, 12
	beqz.n	a9, .L90
	l32i	a9, a8, 116
	beqz.n	a9, .L91
	l32i	a8, a8, 64
	bnez.n	a8, .L92
	j	.L65
.L72:
	bnei	a10, 5, .L65
	l32i	a9, a8, 12
	beqz.n	a9, .L93
	l32i	a8, a8, 76
	bnez.n	a8, .L65
	j	.L94
.L82:
	l32r	a3, .LC242
	l32r	a2, .LC244
	j	.L65
.L85:
	l32r	a4, .LC250
	l32r	a3, .LC252
	l32r	a2, .LC254
	j	.L65
.L86:
	l32r	a4, .LC220
	l32r	a3, .LC222
	l32r	a2, .LC224
	j	.L65
.L87:
	l32r	a3, .LC256
	l32r	a2, .LC258
	j	.L65
.L88:
	l32r	a3, .LC226
	l32r	a2, .LC228
	j	.L65
.L90:
	l32r	a4, .LC236
	l32r	a3, .LC238
	l32r	a2, .LC240
	j	.L65
.L91:
	l32r	a4, .LC230
	l32r	a3, .LC232
	l32r	a2, .LC234
	j	.L65
.L92:
	l32r	a3, .LC260
	l32r	a2, .LC262
	j	.L65
.L93:
	l32r	a2, .LC248
	j	.L65
.L94:
	l32r	a2, .LC246
	j	.L65
.L59:
	bnez.n	a12, .L95
	l32r	a2, .LC180
	l32r	a3, .LC182
	l32r	a4, .LC184
	j	.L61
.L55:
	bnez.n	a12, .L96
	l32r	a2, .LC192
	l32r	a3, .LC194
	l32r	a4, .LC196
	j	.L61
.L57:
	bnez.n	a12, .L97
	l32r	a2, .LC186
	l32r	a3, .LC188
	l32r	a4, .LC190
	j	.L61
.L65:
	s8i	a11, sp, 12
	l32i	a5, sp, 12
	retw.n
.LFE1028:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18helpTextERKNS1_5EntryERKNS0_4HostE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18helpTextERKNS1_5EntryERKNS0_4HostE
	.section	.rodata.str1.1
.LC263:
	.string	"failed"
	.text
	.literal_position
	.literal .LC264, .LC263
	.literal .LC265, CSWTCH$1365
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE:
.LFB1035:
	entry	sp, 32
.LCFI5:
	mov.n	a8, a2
	movi.n	a9, 0xf
	l32r	a2, .LC264
	bltu	a9, a8, .L150
	l32r	a9, .LC265
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L150:
	retw.n
.LFE1035:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE:
.LFB1011:
	entry	sp, 32
.LCFI6:
	movi.n	a7, 0
.L156:
	extui	a6, a7, 0, 8
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	mov.n	a11, a10
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L154
	s8i	a6, a3, 0
	movi.n	a2, 1
	j	.L155
.L154:
	addi.n	a7, a7, 1
	bnei	a7, 7, .L156
	movi.n	a2, 0
.L155:
	retw.n
.LFE1011:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE
	.section	.rodata.str1.1
.LC266:
	.string	"native"
.LC268:
	.string	"motor"
.LC270:
	.string	"load"
	.text
	.literal_position
	.literal .LC267, .LC266
	.literal .LC269, .LC268
	.literal .LC271, .LC270
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE:
.LFB1014:
	entry	sp, 32
.LCFI7:
	l32r	a11, .LC267
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L159
	s8i	a10, a3, 0
.L162:
	movi.n	a2, 1
	j	.L160
.L159:
	l32r	a11, .LC269
	mov.n	a10, a2
	call8	strcmp
	movi.n	a8, 1
	beqz.n	a10, .L164
.L161:
	l32r	a11, .LC271
	mov.n	a10, a2
	call8	strcmp
	movi.n	a2, 0
	bnez.n	a10, .L160
	movi.n	a8, 2
.L164:
	s8i	a8, a3, 0
	j	.L162
.L160:
	retw.n
.LFE1014:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE
	.section	.rodata.str1.1
.LC272:
	.string	"positive"
.LC274:
	.string	"negative"
.LC276:
	.string	"shortest"
	.text
	.literal_position
	.literal .LC273, .LC272
	.literal .LC275, .LC274
	.literal .LC277, .LC276
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19anglePathEPKcRN14MotorControlRS9AnglePathE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19anglePathEPKcRN14MotorControlRS9AnglePathE:
.LFB1017:
	entry	sp, 32
.LCFI8:
	l32r	a11, .LC273
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L166
	s8i	a10, a3, 0
.L169:
	movi.n	a2, 1
	j	.L167
.L166:
	l32r	a11, .LC275
	mov.n	a10, a2
	call8	strcmp
	movi.n	a8, 1
	beqz.n	a10, .L171
.L168:
	l32r	a11, .LC277
	mov.n	a10, a2
	call8	strcmp
	movi.n	a2, 0
	bnez.n	a10, .L167
	movi.n	a8, 2
.L171:
	s8i	a8, a3, 0
	j	.L169
.L167:
	retw.n
.LFE1017:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19anglePathEPKcRN14MotorControlRS9AnglePathE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19anglePathEPKcRN14MotorControlRS9AnglePathE
	.section	.rodata.str1.1
.LC278:
	.string	"reject"
	.text
	.literal_position
	.literal .LC279, .LC278
	.literal .LC280, .LC272
	.literal .LC281, .LC274
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111halfTurnTieEPKcRN14MotorControlRS11HalfTurnTieE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111halfTurnTieEPKcRN14MotorControlRS11HalfTurnTieE:
.LFB1018:
	entry	sp, 32
.LCFI9:
	l32r	a11, .LC279
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L173
	s8i	a10, a3, 0
.L176:
	movi.n	a2, 1
	j	.L174
.L173:
	l32r	a11, .LC280
	mov.n	a10, a2
	call8	strcmp
	movi.n	a8, 1
	beqz.n	a10, .L178
.L175:
	l32r	a11, .LC281
	mov.n	a10, a2
	call8	strcmp
	movi.n	a2, 0
	bnez.n	a10, .L174
	movi.n	a8, 2
.L178:
	s8i	a8, a3, 0
	j	.L176
.L174:
	retw.n
.LFE1018:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111halfTurnTieEPKcRN14MotorControlRS11HalfTurnTieE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111halfTurnTieEPKcRN14MotorControlRS11HalfTurnTieE
	.section	.rodata.str1.1
.LC282:
	.string	"actual"
.LC284:
	.string	"commanded"
.LC286:
	.string	"queued"
	.text
	.literal_position
	.literal .LC283, .LC282
	.literal .LC285, .LC284
	.literal .LC287, .LC286
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_113relativeBasisEPKcRN14MotorControlRS13RelativeBasisE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_113relativeBasisEPKcRN14MotorControlRS13RelativeBasisE:
.LFB1015:
	entry	sp, 32
.LCFI10:
	l32r	a11, .LC283
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L180
	s8i	a10, a3, 0
.L183:
	movi.n	a2, 1
	j	.L181
.L180:
	l32r	a11, .LC285
	mov.n	a10, a2
	call8	strcmp
	movi.n	a8, 1
	beqz.n	a10, .L185
.L182:
	l32r	a11, .LC287
	mov.n	a10, a2
	call8	strcmp
	movi.n	a2, 0
	bnez.n	a10, .L181
	movi.n	a8, 2
.L185:
	s8i	a8, a3, 0
	j	.L183
.L181:
	retw.n
.LFE1015:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_113relativeBasisEPKcRN14MotorControlRS13RelativeBasisE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_113relativeBasisEPKcRN14MotorControlRS13RelativeBasisE
	.section	.rodata.str1.1
.LC288:
	.string	"exact"
.LC290:
	.string	"nearest"
.LC292:
	.string	"zero"
.LC294:
	.string	"floor"
.LC296:
	.string	"ceil"
	.text
	.literal_position
	.literal .LC289, .LC288
	.literal .LC291, .LC290
	.literal .LC293, .LC292
	.literal .LC295, .LC294
	.literal .LC297, .LC296
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18roundingEPKcRN14MotorControlRS8RoundingE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18roundingEPKcRN14MotorControlRS8RoundingE:
.LFB1016:
	entry	sp, 32
.LCFI11:
	l32r	a11, .LC289
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L187
	s8i	a10, a3, 0
.L190:
	movi.n	a2, 1
	j	.L188
.L187:
	l32r	a11, .LC291
	mov.n	a10, a2
	call8	strcmp
	movi.n	a8, 1
	beqz.n	a10, .L194
.L189:
	l32r	a11, .LC293
	mov.n	a10, a2
	call8	strcmp
	movi.n	a8, 2
	beqz.n	a10, .L194
.L191:
	l32r	a11, .LC295
	mov.n	a10, a2
	call8	strcmp
	movi.n	a8, 3
	beqz.n	a10, .L194
.L192:
	l32r	a11, .LC297
	mov.n	a10, a2
	call8	strcmp
	movi.n	a2, 0
	bnez.n	a10, .L188
	movi.n	a8, 4
.L194:
	s8i	a8, a3, 0
	j	.L190
.L188:
	retw.n
.LFE1016:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18roundingEPKcRN14MotorControlRS8RoundingE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18roundingEPKcRN14MotorControlRS8RoundingE
	.literal_position
	.literal .LC298, _ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L8COMMANDSE
	.literal .LC299, _ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L8COMMANDSE+1296
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_14findEPKc, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_14findEPKc:
.LFB1025:
	entry	sp, 32
.LCFI12:
	mov.n	a7, a2
	l32r	a2, .LC298
.L197:
	l32i	a11, a2, 0
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L195
	l32r	a8, .LC299
	addi	a2, a2, 24
	bne	a2, a8, .L197
	movi.n	a2, 0
.L195:
	retw.n
.LFE1025:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_14findEPKc, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_14findEPKc
	.section	.rodata.str1.1
.LC300:
	.string	"rpm"
.LC302:
	.string	"turns/s"
.LC304:
	.string	"%s/s"
	.text
	.literal_position
	.literal .LC301, .LC300
	.literal .LC303, .LC302
	.literal .LC305, .LC304
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18rateUnitEPKcRN14MotorControlRS12VelocityUnitE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18rateUnitEPKcRN14MotorControlRS12VelocityUnitE:
.LFB1012:
	entry	sp, 64
.LCFI13:
	l32r	a11, .LC301
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L203
	movi.n	a8, 3
	s8i	a8, a3, 0
	movi.n	a8, 1
	s8i	a8, a3, 1
	j	.L204
.L203:
	l32r	a11, .LC303
	mov.n	a10, a2
	call8	strcmp
	movi.n	a7, 0
	bnez.n	a10, .L205
	movi.n	a8, 3
	s8i	a8, a3, 0
.L211:
	s8i	a10, a3, 1
.L204:
	movi.n	a2, 1
	j	.L206
.L205:
	extui	a6, a7, 0, 8
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	l32r	a12, .LC305
	mov.n	a13, a10
	movi.n	a11, 0x14
	mov.n	a10, sp
	call8	snprintf
	mov.n	a11, sp
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L207
	s8i	a6, a3, 0
	j	.L211
.L207:
	addi.n	a7, a7, 1
	bnei	a7, 7, .L205
	movi.n	a2, 0
.L206:
	retw.n
.LFE1012:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18rateUnitEPKcRN14MotorControlRS12VelocityUnitE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18rateUnitEPKcRN14MotorControlRS12VelocityUnitE
	.section	.rodata.str1.1
.LC308:
	.string	"invalid axis arguments"
	.text
	.literal_position
	.literal .LC309, .LC308
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd:
.LFB1021:
	entry	sp, 80
.LCFI14:
	movi.n	a8, 0
	s32i	a8, sp, 0
	s32i	a8, sp, 4
	movi.n	a8, 1
	s32i	a8, sp, 8
	mov.n	a10, a2
	movi.n	a8, 0
	mov.n	a11, sp
	s32i	a8, sp, 12
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a11, sp, 32
	s32i	a12, sp, 36
	extui	a8, a10, 0, 8
	beqz.n	a8, .L213
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	j	.L214
.L213:
	l32i	a8, sp, 4
	bgez	a8, .L215
	movi.n	a8, 1
	s8i	a8, sp, 16
	movi.n	a8, 1
	s32i	a8, sp, 20
	l32r	a8, .LC309
	s32i	a8, sp, 24
	j	.L214
.L215:
	mov.n	a11, a3
	mov.n	a10, sp
	call8	_ZN14MotorControlRS16rationalToDoubleERKNS_8RationalERd
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
.L214:
	l32i	a2, sp, 16
	l32i	a3, sp, 20
	l32i	a4, sp, 24
	movi.n	a5, 0
	retw.n
.LFE1021:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd
	.section	.rodata.str1.1
.LC311:
	.string	"relative"
.LC313:
	.string	"absolute"
.LC315:
	.string	"angle"
.LC318:
	.string	""
.LC320:
	.string	"config"
.LC322:
	.string	"origin"
.LC324:
	.string	"set"
.LC329:
	.string	"rpm/s"
.LC331:
	.string	"%s/s2"
.LC335:
	.string	"linear"
.LC337:
	.string	"none"
.LC92:
	.string	"command"
.LC93:
	.string	"gear"
.LC94:
	.string	"lead"
.LC95:
	.string	"encoder-scale"
.LC96:
	.string	"encoder-id"
.LC97:
	.string	"encoder-basis"
.LC98:
	.string	"encoder-polarity"
.LC99:
	.string	"polarity"
.LC100:
	.string	"position-unit"
.LC101:
	.string	"velocity-unit"
.LC102:
	.string	"acceleration-unit"
.LC103:
	.string	"native-limits"
.LC104:
	.string	"soft-limits"
.LC105:
	.string	"relative-bases"
	.section	.rodata
	.align	4
.LC326:
	.word	.LC92
	.word	.LC93
	.word	.LC84
	.word	.LC94
	.word	.LC95
	.word	.LC96
	.word	.LC97
	.word	.LC98
	.word	.LC99
	.word	.LC100
	.word	.LC101
	.word	.LC102
	.word	.LC103
	.word	.LC104
	.word	.LC105
	.text
	.literal_position
	.literal .LC310, .LC308
	.literal .LC312, .LC311
	.literal .LC314, .LC313
	.literal .LC316, .LC315
	.literal .LC319, .LC318
	.literal .LC321, .LC320
	.literal .LC323, .LC322
	.literal .LC325, .LC324
	.literal .LC327, .LC326
	.literal .LC330, .LC329
	.literal .LC332, .LC331
	.literal .LC333, .LC268
	.literal .LC334, .LC270
	.literal .LC336, .LC335
	.literal .LC338, .LC337
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111axisRequestEPKPcjbRNS0_11AxisCommandE$constprop$0, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111axisRequestEPKPcjbRNS0_11AxisCommandE$constprop$0:
.LFB1246:
	entry	sp, 144
.LCFI15:
	beqz.n	a4, .L218
	addi	a8, a3, -4
	bltui	a8, 6, .L219
	j	.L274
.L219:
	l32i	a7, a2, 0
	movi.n	a8, 3
	l32r	a11, .LC312
	s8i	a8, a5, 0
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L221
	movi.n	a8, 1
	s8i	a8, a5, 66
	j	.L222
.L221:
	l32r	a11, .LC314
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L223
	s8i	a10, a5, 66
	j	.L222
.L223:
	l32r	a11, .LC316
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L274
	movi	a8, 0x100
	s16i	a8, a5, 66
.L222:
	l32i	a10, a2, 4
	addi	a11, a5, 48
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L225
	j	.L238
.L225:
	l32i	a10, a2, 8
	addi	a11, a5, 64
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE
	beqz.n	a10, .L274
	l32i	a10, a2, 12
	addi	a11, a5, 65
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE
	beqz.n	a10, .L274
	l8ui	a8, a5, 67
	beqz.n	a8, .L271
	bltui	a3, 6, .L274
	l32i	a10, a2, 16
	addi	a11, a5, 68
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19anglePathEPKcRN14MotorControlRS9AnglePathE
	beqz.n	a10, .L274
	l32i	a10, a2, 20
	addi	a11, a5, 69
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111halfTurnTieEPKcRN14MotorControlRS11HalfTurnTieE
	beqz.n	a10, .L274
	movi.n	a6, 6
	j	.L228
.L271:
	movi.n	a6, 4
.L228:
	l8ui	a8, a5, 66
	beqz.n	a8, .L229
	bgeu	a6, a3, .L274
	extui	a8, a6, 0, 16
	addx4	a8, a8, a2
	l32i	a10, a8, 0
	addi	a11, a5, 70
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_113relativeBasisEPKcRN14MotorControlRS13RelativeBasisE
	beqz.n	a10, .L274
	addi.n	a6, a6, 1
.L229:
	mov.n	a7, a6
	bgeu	a6, a3, .L230
	extui	a4, a6, 0, 16
	addx4	a4, a4, a2
	l32i	a10, a4, 0
	addi	a11, a5, 76
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18roundingEPKcRN14MotorControlRS8RoundingE
	beqz.n	a10, .L274
	addi.n	a7, a6, 1
	bgeu	a7, a3, .L230
	l32i	a10, a4, 4
	addi	a11, a5, 80
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	addi.n	a7, a6, 2
	bnez.n	a10, .L238
	bgeu	a7, a3, .L230
	l32i	a10, a4, 8
	addi	a11, a5, 104
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	bnez.n	a10, .L238
	l8ui	a8, a5, 64
	bnei	a8, 5, .L274
	l32i	a10, a5, 104
	l32i	a11, a5, 108
	movi.n	a12, 0
	movi.n	a13, 0
	call8	__ledf2
	blti	a10, 1, .L274
	movi.n	a8, 1
	addi.n	a7, a6, 3
	s8i	a8, a5, 88
.L230:
	bne	a3, a7, .L274
	j	.L234
.L218:
	bnei	a3, 1, .L233
	l32r	a11, .LC321
	l32i	a10, a2, 0
	call8	strcmp
	bnez.n	a10, .L274
.L234:
	movi.n	a8, 0
	s8i	a8, sp, 60
	movi.n	a8, 0
	s32i	a8, sp, 64
	j	.L311
.L233:
	bnei	a3, 2, .L236
	l32r	a11, .LC323
	l32i	a10, a2, 0
	call8	strcmp
	bnez.n	a10, .L274
	l32i	a10, a2, 4
	s8i	a3, a5, 0
	addi.n	a11, a5, 8
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	bnez.n	a10, .L238
	l32i	a8, a5, 16
	bnei	a8, 1, .L274
	l32i	a8, a5, 20
	beqz.n	a8, .L238
.L274:
	movi.n	a8, 1
	s8i	a8, sp, 60
	movi.n	a8, 1
	s32i	a8, sp, 64
	l32r	a8, .LC310
.L309:
	s32i	a8, sp, 68
	j	.L232
.L238:
	l32i	a9, sp, 0
	s32i	a9, sp, 60
	l32i	a9, sp, 4
	s32i	a9, sp, 64
	l32i	a9, sp, 8
	j	.L310
.L236:
	addi	a8, a3, -4
	bgeui	a8, 2, .L274
	l32r	a11, .LC321
	l32i	a10, a2, 0
	call8	strcmp
	bnez.n	a10, .L274
	l32r	a11, .LC325
	l32i	a10, a2, 4
	call8	strcmp
	beqz.n	a10, .L302
	j	.L274
.L302:
	l32r	a11, .LC327
	movi.n	a12, 0x3c
	mov.n	a10, sp
	call8	memcpy
	movi.n	a7, 0
	l32i	a6, a2, 8
	movi.n	a4, 0xf
	j	.L242
.L243:
	addi.n	a7, a7, 1
	beq	a7, a4, .L274
.L242:
	extui	a8, a7, 0, 16
	addx4	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L243
	j	.L303
.L270:
	movi.n	a9, 0x1f
	addmi	a9, a9, 0x2000
	bbc	a9, a7, .L245
	bnei	a3, 4, .L245
	s8i	a8, a5, 40
	s8i	a10, sp, 60
	s32i	a10, sp, 64
.L311:
	l32r	a8, .LC319
	j	.L309
.L245:
	bltui	a4, 2, .L246
	bnei	a3, 4, .L274
	movi.n	a8, 9
	beq	a7, a8, .L247
	bltu	a8, a7, .L248
	beqi	a7, 6, .L249
	j	.L250
.L248:
	beqi	a7, 10, .L251
	movi.n	a8, 0xb
	beq	a7, a8, .L252
	j	.L250
.L247:
	addi	a11, a5, 42
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE
	j	.L305
.L251:
	addi	a11, a5, 43
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18rateUnitEPKcRN14MotorControlRS12VelocityUnitE
.L305:
	bnez.n	a10, .L234
	j	.L274
.L252:
	l32r	a11, .LC330
	mov.n	a10, a6
	call8	strcmp
	movi.n	a7, 0
	bnez.n	a10, .L253
	movi.n	a8, 3
	s8i	a8, a5, 45
	movi.n	a8, 1
	s16i	a8, a5, 46
	j	.L234
.L253:
	extui	a4, a7, 0, 8
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	l32r	a12, .LC332
	mov.n	a13, a10
	movi.n	a11, 0x14
	addi	a10, sp, 60
	call8	snprintf
	addi	a11, sp, 60
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L254
	s8i	a4, a5, 45
	s16i	a10, a5, 46
	j	.L234
.L254:
	addi.n	a7, a7, 1
	bnei	a7, 7, .L253
	j	.L274
.L249:
	l32r	a11, .LC333
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L255
	s8i	a10, a5, 41
	j	.L234
.L255:
	l32r	a11, .LC334
	mov.n	a10, a6
	call8	strcmp
	movi.n	a8, 1
	beqz.n	a10, .L306
.L256:
	l32r	a11, .LC336
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L274
	movi.n	a8, 2
.L306:
	s8i	a8, a5, 41
	j	.L234
.L250:
	addi.n	a11, a5, 8
	mov.n	a10, a6
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 80
	s32i	a11, sp, 84
	s32i	a12, sp, 88
	extui	a10, a10, 0, 8
	beqz.n	a10, .L257
.L263:
	l32i	a10, sp, 84
	l32i	a11, sp, 80
	l32i	a9, sp, 88
	s32i	a11, sp, 60
	s32i	a10, sp, 64
.L310:
	s32i	a9, sp, 68
	j	.L232
.L257:
	bgeui	a7, 5, .L258
	l32i	a9, a5, 12
	l32i	a10, a5, 8
	addi.n	a8, a9, -1
	movnez	a8, a9, a10
	addi.n	a11, a10, -1
	bnez.n	a8, .L274
	movi.n	a8, -2
	bltu	a8, a11, .L274
	l32i	a8, a5, 20
	bnez.n	a8, .L274
	j	.L262
.L258:
	l32i	a8, a5, 16
	bnei	a8, 1, .L274
	l32i	a8, a5, 20
	bnez.n	a8, .L274
	bgeui	a4, 2, .L262
	l32i	a10, a2, 16
	addi	a11, a5, 24
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 80
	s32i	a11, sp, 84
	s32i	a12, sp, 88
	extui	a10, a10, 0, 8
	bnez.n	a10, .L263
	l32i	a8, a5, 32
	bnei	a8, 1, .L274
	l32i	a8, a5, 36
	bnez.n	a8, .L274
	l32i	a9, a5, 12
	l32i	a8, a5, 28
	blt	a8, a9, .L274
	bne	a9, a8, .L262
	l32i	a8, a5, 8
	l32i	a9, a5, 24
	bltu	a9, a8, .L274
.L262:
	l8ui	a8, a5, 1
	addi	a9, a8, -7
	extui	a9, a9, 0, 8
	bgeui	a9, 2, .L265
	l32i	a9, a5, 8
	l32i	a10, a5, 12
	addi.n	a9, a9, 1
	bnez.n	a9, .L266
	addi.n	a10, a10, 1
.L266:
	movi.n	a8, -3
	and	a8, a8, a9
	or	a8, a8, a10
	j	.L308
.L265:
	bnei	a8, 5, .L267
	l32i	a8, a5, 12
.L308:
	bnez.n	a8, .L274
	j	.L234
.L267:
	movi.n	a9, 0xe
	bne	a8, a9, .L234
	l32i	a8, a5, 12
	bnez.n	a8, .L274
	l32i	a8, a5, 8
	bgeui	a8, 8, .L274
	j	.L234
.L246:
	bnei	a3, 5, .L274
	j	.L250
.L303:
	l32i	a6, a2, 12
	movi.n	a8, 1
	extui	a4, a7, 0, 8
	l32r	a11, .LC338
	s8i	a8, a5, 0
	s8i	a4, a5, 1
	mov.n	a10, a6
	s32i	a8, sp, 96
	addi	a4, a4, -12
	call8	strcmp
	l32i	a8, sp, 96
	extui	a4, a4, 0, 8
	beqz.n	a10, .L270
	j	.L245
.L232:
	l32i	a2, sp, 60
	l32i	a3, sp, 64
	l32i	a4, sp, 68
	movi.n	a5, 0
	retw.n
.LFE1246:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111axisRequestEPKPcjbRNS0_11AxisCommandE$constprop$0, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111axisRequestEPKPcjbRNS0_11AxisCommandE$constprop$0
	.literal_position
	.literal .LC339, .L315
	.align	4
	.type	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0, @function
_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0:
.LFB1247:
	entry	sp, 32
.LCFI16:
	addi	a3, a3, -2
	extui	a3, a3, 0, 8
	movi.n	a9, 0x36
	mov.n	a8, a2
	bltu	a9, a3, .L346
	l32r	a9, .LC339
	addx4	a3, a3, a9
	l32i	a9, a3, 0
	jx	a9
	.section	.rodata
	.align	4
	.align	4
.L315:
	.word	.L338
	.word	.L338
	.word	.L338
	.word	.L343
	.word	.L342
	.word	.L341
	.word	.L340
	.word	.L338
	.word	.L339
	.word	.L338
	.word	.L337
	.word	.L336
	.word	.L335
	.word	.L334
	.word	.L346
	.word	.L346
	.word	.L334
	.word	.L334
	.word	.L334
	.word	.L333
	.word	.L345
	.word	.L345
	.word	.L330
	.word	.L330
	.word	.L330
	.word	.L330
	.word	.L331
	.word	.L330
	.word	.L329
	.word	.L328
	.word	.L328
	.word	.L346
	.word	.L328
	.word	.L328
	.word	.L328
	.word	.L327
	.word	.L326
	.word	.L325
	.word	.L324
	.word	.L323
	.word	.L322
	.word	.L321
	.word	.L320
	.word	.L318
	.word	.L318
	.word	.L318
	.word	.L318
	.word	.L318
	.word	.L318
	.word	.L318
	.word	.L318
	.word	.L318
	.word	.L317
	.word	.L316
	.word	.L314
	.text
.L333:
	l32i	a8, a2, 84
	j	.L359
.L339:
	l32i	a8, a2, 80
	j	.L359
.L327:
	l32i	a8, a2, 88
	j	.L359
.L321:
	l32i	a8, a2, 92
	j	.L359
.L320:
	l32i	a8, a2, 96
	j	.L359
.L323:
	l32i	a9, a2, 112
	movi.n	a2, 0
	beqz.n	a9, .L313
	j	.L338
.L324:
	l32i	a9, a2, 116
	movi.n	a2, 1
	bnez.n	a9, .L313
	j	.L328
.L326:
	l32i	a8, a2, 100
	j	.L359
.L325:
	l32i	a8, a2, 104
	j	.L359
.L322:
	l32i	a8, a2, 108
	j	.L359
.L341:
	l32i	a8, a2, 20
	j	.L359
.L316:
	l32i	a8, a2, 72
	j	.L359
.L314:
	l32i	a8, a2, 120
	j	.L359
.L330:
	l32i	a9, a2, 28
	j	.L361
.L318:
	l32i	a8, a2, 44
	j	.L359
.L317:
	l32i	a9, a2, 40
	j	.L361
.L331:
	l32i	a9, a2, 36
	movi.n	a2, 0
	beqz.n	a9, .L313
	l32i	a9, a8, 12
	beqz.n	a9, .L313
.L345:
	l32i	a8, a8, 136
	j	.L359
.L329:
	l32i	a9, a2, 12
	movi.n	a2, 0
	beqz.n	a9, .L313
	l32i	a9, a8, 24
	movi.n	a2, 1
	bnez.n	a9, .L313
	l32i	a9, a8, 48
	bnez.n	a9, .L345
	j	.L358
.L328:
	l32i	a9, a8, 52
.L361:
	bnez.n	a9, .L338
.L358:
	movi.n	a2, 0
	j	.L313
.L334:
	l32i	a8, a2, 24
	j	.L359
.L337:
	l32i	a8, a2, 124
	j	.L359
.L336:
	l32i	a8, a2, 128
	j	.L359
.L335:
	l32i	a8, a2, 132
	j	.L359
.L342:
	l32i	a8, a2, 16
	j	.L359
.L340:
	l32i	a8, a2, 68
	j	.L359
.L343:
	l32i	a9, a2, 12
	movi.n	a2, 1
	bnez.n	a9, .L313
	l32i	a8, a8, 76
	j	.L359
.L338:
	l32i	a8, a8, 12
.L359:
	movi.n	a2, 1
	moveqz	a2, a8, a8
	j	.L313
.L346:
	movi.n	a2, 1
.L313:
	retw.n
.LFE1247:
	.size	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0, .-_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	.section	.rodata._ZN14MotorControlRS11errToStringENS_3ErrE.str1.1,"aMS",@progbits,1
.LC340:
	.string	"UNKNOWN"
	.section	.text._ZN14MotorControlRS11errToStringENS_3ErrE,"axG",@progbits,_ZN14MotorControlRS11errToStringENS_3ErrE,comdat
	.literal_position
	.literal .LC341, .LC340
	.literal .LC342, CSWTCH$1411
	.align	4
	.weak	_ZN14MotorControlRS11errToStringENS_3ErrE
	.type	_ZN14MotorControlRS11errToStringENS_3ErrE, @function
_ZN14MotorControlRS11errToStringENS_3ErrE:
.LFB31:
	entry	sp, 32
.LCFI17:
	extui	a8, a2, 0, 8
	l32r	a2, .LC341
	bgeui	a8, 7, .L364
	l32r	a9, .LC342
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L364:
	retw.n
.LFE31:
	.size	_ZN14MotorControlRS11errToStringENS_3ErrE, .-_ZN14MotorControlRS11errToStringENS_3ErrE
	.section	.rodata._ZN21MotorControlRSExample10formatNameENS_10HostFormatE.str1.1,"aMS",@progbits,1
.LC343:
	.string	"unsupported"
	.section	.text._ZN21MotorControlRSExample10formatNameENS_10HostFormatE,"axG",@progbits,_ZN21MotorControlRSExample10formatNameENS_10HostFormatE,comdat
	.literal_position
	.literal .LC344, .LC343
	.literal .LC345, CSWTCH$1501
	.align	4
	.weak	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE
	.type	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE, @function
_ZN21MotorControlRSExample10formatNameENS_10HostFormatE:
.LFB273:
	entry	sp, 32
.LCFI18:
	extui	a8, a2, 0, 8
	l32r	a2, .LC344
	bgeui	a8, 4, .L367
	l32r	a9, .LC345
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L367:
	retw.n
.LFE273:
	.size	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE, .-_ZN21MotorControlRSExample10formatNameENS_10HostFormatE
	.text
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE:
.LFB1003:
	entry	sp, 32
.LCFI19:
	movi.n	a7, 0
.L373:
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE
	mov.n	a11, a10
	mov.n	a10, a2
	call8	strcmp
	bnez.n	a10, .L371
	s8i	a7, a3, 0
	movi.n	a2, 1
	j	.L372
.L371:
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
	bnei	a7, 4, .L373
	movi.n	a2, 0
.L372:
	retw.n
.LFE1003:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE
	.section	.text._ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE,"axG",@progbits,_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	.type	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE, @function
_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE:
.LFB274:
	entry	sp, 32
.LCFI20:
	l8ui	a9, a2, 4
	mov.n	a8, a2
	movi.n	a2, 0
	bgeui	a9, 4, .L376
	l32i	a9, a8, 0
	movi.n	a10, 0x4b
	slli	a10, a10, 7
	movi.n	a8, 1
	sub	a10, a9, a10
	mov.n	a11, a2
	moveqz	a11, a8, a10
	addmi	a12, a9, -0x4b00
	mov.n	a10, a2
	moveqz	a10, a8, a12
	movi.n	a12, 0x4b
	slli	a12, a12, 9
	or	a11, a11, a10
	sub	a12, a9, a12
	mov.n	a10, a2
	moveqz	a10, a8, a12
	or	a10, a10, a11
	movi	a11, 0xe1
	slli	a11, a11, 9
	sub	a9, a9, a11
	movnez	a8, a2, a9
	or	a2, a8, a10
.L376:
	retw.n
.LFE274:
	.size	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE, .-_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	.section	.text._ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE,"axG",@progbits,_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	.type	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE, @function
_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE:
.LFB283:
	entry	sp, 32
.LCFI21:
	mov.n	a8, a2
	l8ui	a2, a2, 216
	beqz.n	a2, .L379
	l32i	a10, a8, 0
	l32i	a9, a3, 0
	bne	a10, a9, .L385
	l8ui	a10, a8, 4
	l8ui	a9, a3, 4
	bne	a10, a9, .L385
	l32i	a10, a8, 8
	l32i	a9, a3, 8
	bne	a10, a9, .L385
	l32i	a10, a8, 264
	l32i	a9, a8, 268
	or	a11, a10, a9
	beqz.n	a11, .L379
	l32i	a11, a8, 244
	movi.n	a2, 1
	bltu	a9, a11, .L381
	bne	a11, a9, .L382
	l32i	a8, a8, 240
	bltu	a10, a8, .L381
.L382:
	movi.n	a2, 0
.L381:
	extui	a2, a2, 0, 8
	j	.L379
.L385:
	movi.n	a2, 0
.L379:
	retw.n
.LFE283:
	.size	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE, .-_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	.section	.text._ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy,"axG",@progbits,_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	.type	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy, @function
_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy:
.LFB285:
	entry	sp, 48
.LCFI22:
	mov.n	a10, a2
	mov.n	a11, a3
	s32i	a2, sp, 0
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	mov.n	a2, a10
	beqz.n	a10, .L393
	l32i	a8, sp, 0
	l32i	a10, a8, 244
	l32i	a9, a8, 240
	bltu	a5, a10, .L399
	bne	a10, a5, .L400
	bltu	a4, a9, .L399
.L400:
	or	a11, a6, a7
	beqz.n	a11, .L393
	l8ui	a8, a8, 216
	beqz.n	a8, .L393
	sub	a5, a5, a10
	bgeu	a4, a9, .L396
	addi.n	a5, a5, -1
.L396:
	sub	a4, a4, a9
	movi.n	a2, 1
	bltu	a7, a5, .L398
	bne	a5, a7, .L397
	bgeu	a6, a4, .L397
.L398:
	movi.n	a2, 0
.L397:
	extui	a2, a2, 0, 8
	j	.L393
.L399:
	movi.n	a2, 0
.L393:
	retw.n
.LFE285:
	.size	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy, .-_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	.section	.rodata._ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_.str1.1,"aMS",@progbits,1
.LC350:
	.string	"unknown_fact"
.LC352:
	.string	"duplicate_fact"
.LC354:
	.string	"missing_fact"
.LC356:
	.string	"unprintable"
	.section	.text._ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_,"axG",@progbits,_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_,comdat
	.literal_position
	.literal .LC351, .LC350
	.literal .LC353, .LC352
	.literal .LC355, .LC354
	.literal .LC357, .LC356
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_
	.type	_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_, @function
_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_:
.LFB318:
	entry	sp, 48
.LCFI23:
	mov.n	a12, a3
	mov.n	a8, a6
	movi.n	a13, 0
	j	.L411
.L413:
	l32i	a11, a3, 0
	l32i	a10, a2, 0
	s32i	a8, sp, 12
	s32i	a12, sp, 8
	s32i	a9, sp, 4
	s32i	a13, sp, 0
	call8	strcmp
	l32i	a8, sp, 12
	l32i	a12, sp, 8
	l32i	a9, sp, 4
	l32i	a13, sp, 0
	moveqz	a6, a3, a10
	addi.n	a3, a3, 12
.L423:
	bne	a3, a9, .L413
	bnez.n	a6, .L414
	l32r	a8, .LC357
	movi	a14, -0x21
	s32i	a8, a7, 0
	l32i	a11, a2, 0
	movi.n	a8, 1
	l8ui	a9, a11, 0
	mov.n	a12, a11
	moveqz	a8, a9, a9
	movi.n	a15, 0x19
	movi.n	a13, 0
	movi.n	a6, 9
	j	.L415
.L417:
	beqz.n	a8, .L416
	and	a10, a9, a14
	addi	a10, a10, -65
	extui	a10, a10, 0, 8
	bgeu	a15, a10, .L416
	addi	a8, a9, -95
	movi.n	a10, 1
	movnez	a10, a13, a8
	addi	a5, a9, -45
	movi.n	a8, 1
	movnez	a8, a13, a5
	or	a10, a10, a8
	addi	a8, a9, -48
	extui	a8, a8, 0, 8
	saltu	a8, a6, a8
	addi.n	a8, a8, -1
	neg	a8, a8
	or	a8, a8, a10
	extui	a8, a8, 0, 8
.L416:
	addi.n	a12, a12, 1
.L415:
	l8ui	a9, a12, 0
	bnez.n	a9, .L417
	beqz.n	a8, .L418
	s32i	a11, a7, 0
.L418:
	l32r	a2, .LC351
	j	.L410
.L414:
	l32i	a9, a6, 4
	addi.n	a2, a2, 4
	add.n	a9, a8, a9
	l8ui	a10, a9, 0
	beqz.n	a10, .L420
	l32i	a8, a6, 0
	l32r	a2, .LC353
	s32i	a8, a7, 0
	j	.L410
.L420:
	movi.n	a10, 1
	s8i	a10, a9, 0
	addi.n	a13, a13, 1
.L411:
	bne	a13, a12, .L421
	movi.n	a9, 0
	j	.L422
.L421:
	addx2	a9, a5, a5
	mov.n	a3, a4
	addx4	a9, a9, a4
	movi.n	a6, 0
	j	.L423
.L425:
	l8ui	a10, a4, 8
	beqz.n	a10, .L424
	l32i	a10, a4, 4
	add.n	a10, a8, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L424
	l32i	a8, a4, 0
	l32r	a2, .LC355
	s32i	a8, a7, 0
	j	.L410
.L424:
	addi.n	a9, a9, 1
	addi.n	a4, a4, 12
.L422:
	bne	a5, a9, .L425
	movi.n	a2, 0
.L410:
	retw.n
.LFE318:
	.size	_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_, .-_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_
	.section	.text._ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm,"axG",@progbits,_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm,comdat
	.literal_position
	.literal .LC358, -858993459
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	.type	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm, @function
_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm:
.LFB371:
	entry	sp, 32
.LCFI24:
	l8ui	a8, a2, 0
	mov.n	a11, a2
	movi.n	a2, 0
	beqz.n	a8, .L438
	l32r	a13, .LC358
	movi.n	a8, 0
	movi.n	a12, 9
	j	.L439
.L440:
	addi	a10, a10, -48
	extui	a9, a10, 0, 8
	bltu	a12, a9, .L443
	movi.n	a9, -1
	xor	a9, a10, a9
	muluh	a9, a9, a13
	srli	a9, a9, 3
	bltu	a9, a8, .L443
	addx4	a8, a8, a8
	addx2	a8, a8, a10
	addi.n	a11, a11, 1
.L439:
	l8ui	a10, a11, 0
	bnez.n	a10, .L440
	s32i	a8, a3, 0
	movi.n	a2, 1
	j	.L438
.L443:
	movi.n	a2, 0
.L438:
	retw.n
.LFE371:
	.size	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm, .-_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	.section	.text._ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz,"axG",@progbits,_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	.type	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz, @function
_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz:
.LFB373:
	entry	sp, 80
.LCFI25:
	s32i	a6, sp, 32
	s32i	a7, sp, 36
	l32i	a10, a4, 0
	mov.n	a12, a5
	bltu	a10, a3, .L446
.L448:
	movi.n	a2, 0
	j	.L447
.L446:
	addi	a14, sp, 16
	addi	a13, sp, 48
	movi.n	a9, 0x10
	sub	a11, a3, a10
	movi.n	a15, 0x10
	add.n	a10, a2, a10
	s32i	a14, sp, 4
	s32i	a13, sp, 0
	s32i	a9, sp, 8
	call8	vsnprintf
	bltz	a10, .L448
	l32i	a8, a4, 0
	sub	a3, a3, a8
	bgeu	a10, a3, .L448
	add.n	a8, a8, a10
	s32i	a8, a4, 0
	movi.n	a2, 1
.L447:
	retw.n
.LFE373:
	.size	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz, .-_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	.section	.rodata.str1.1
.LC359:
	.string	"{\"baud\":%lu,\"format\":\"%s\"}"
	.text
	.literal_position
	.literal .LC360, .LC359
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE:
.LFB1006:
	entry	sp, 32
.LCFI26:
	l8ui	a10, a5, 4
	l32i	a7, a5, 0
	call8	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE
	l32r	a13, .LC360
	mov.n	a15, a10
	mov.n	a14, a7
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
	retw.n
.LFE1006:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	.section	.rodata.str1.1
.LC361:
	.string	"true"
.LC363:
	.string	"false"
.LC365:
	.string	",\"relation\":{\"original_operation_id\":%lu,\"replacement_operation_id\":%lu,\"observation_superseded\":%s}"
	.text
	.literal_position
	.literal .LC362, .LC361
	.literal .LC364, .LC363
	.literal .LC366, .LC365
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112moveRelationEPcjRjRKNS_12MoveRelationE$constprop$0, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112moveRelationEPcjRjRKNS_12MoveRelationE$constprop$0:
.LFB1249:
	entry	sp, 48
.LCFI27:
	l8ui	a9, a4, 8
	l32i	a14, a4, 0
	l32i	a15, a4, 4
	l32r	a8, .LC364
	mov.n	a10, a2
	mov.n	a12, a3
	beqz.n	a9, .L451
	l32r	a8, .LC362
.L451:
	l32r	a13, .LC366
	movi.n	a11, 1
	s32i	a8, sp, 0
	slli	a11, a11, 14
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
	retw.n
.LFE1249:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112moveRelationEPcjRjRKNS_12MoveRelationE$constprop$0, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112moveRelationEPcjRjRKNS_12MoveRelationE$constprop$0
	.section	.rodata.str1.1
.LC371:
	.string	",\"bus_traffic\":false,\"motion_command\":false,\"wire_motion\":\"not_requested\",\"polarity_known\":%s,\"configuration_generation\":%lu,\"target\":%lu,\"address\":%u,\"binding_generation\":%lu"
.LC374:
	.string	",\"requested\":{\"numerator\":%lld,\"denominator\":%llu,\"unit\":\"%s\",\"frame\":%u,\"relative\":%s,\"wrapped\":%s,\"angle_path\":%u,\"half_turn_tie\":%u,\"basis\":%u,\"rounding\":%u},\"requested_native\":"
.LC376:
	.string	"{\"integral\":%lld,\"numerator\":%llu,\"denominator\":%llu,\"negative\":%s},\"requested_native_approximate\":null"
.LC378:
	.string	"null,\"requested_native_approximate\":%.17g"
.LC380:
	.string	",\"effective_native\":%lld,\"endpoint_known\":%s,\"endpoint_native\":%lld,\"displacement_known\":%s,\"displacement_native\":%lld,\"zero_displacement\":%s,\"rounding_error\":%.17g,\"approximation_error_bound\":%.17g,\"exact_arithmetic\":%s}"
.LC382:
	.string	",\"operator_scales\":["
.LC384:
	.string	"%s{\"numerator\":%lu,\"denominator\":%lu,\"source\":%u}"
.LC386:
	.string	","
.LC388:
	.ascii	"],\"encoder_id\":%lu,\"encoder_basis\":%u,\"encoder_polarity"
	.ascii	"\":%d,\"polarity\":%d,\"position_unit\":\"%s\",\"velocity_un"
	.ascii	"it\":{\"position\":\"%s\",\"time\":%u},\"acceleration_unit\""
	.ascii	":{\"position\":\"%s\",\"velocity_time\":%u,\"acce"
	.string	"leration_time\":%u},\"relative_bases\":%u,\"native_limits\":[%lld,%lld],\"soft_limits_known\":%s,\"soft_limits\":[%lld,%lld],\"origin_known\":%s,\"origin_native\":%lld,\"origin_source\":%u,\"encoder_origin_known\":%s,\"encoder_origin_native\":%lld,\"encoder_origin_source\":%u}"
	.text
	.literal_position
	.literal .LC368, .LC361
	.literal .LC369, .LC363
	.literal .LC370, .LC318
	.literal .LC372, .LC371
	.literal .LC373, 16384
	.literal .LC375, .LC374
	.literal .LC377, .LC376
	.literal .LC379, .LC378
	.literal .LC381, .LC380
	.literal .LC383, .LC382
	.literal .LC385, .LC384
	.literal .LC387, .LC386
	.literal .LC389, .LC388
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18axisViewEPcjRjRKNS0_8AxisViewEb$constprop$0, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18axisViewEPcjRjRKNS0_8AxisViewEb$constprop$0:
.LFB1250:
	entry	sp, 304
.LCFI28:
	l8ui	a8, a4, 0
	l32r	a14, .LC369
	beqz.n	a8, .L454
	l32r	a14, .LC368
.L454:
	l32i	a8, a4, 16
	l32r	a13, .LC372
	s32i	a8, sp, 8
	l8ui	a8, a4, 12
	l32r	a11, .LC373
	s32i	a8, sp, 4
	l32i	a8, a4, 8
	mov.n	a12, a3
	s32i	a8, sp, 0
	l32i	a15, a4, 20
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L455
.L460:
	movi.n	a2, 0
	j	.L456
.L455:
	beqz.n	a5, .L457
	l32i	a8, a4, 192
	l32i	a9, a4, 196
	l8ui	a10, a4, 208
	l32i	a6, a4, 200
	l32i	a7, a4, 204
	s32i	a8, sp, 192
	s32i	a9, sp, 196
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	l8ui	a12, a4, 210
	l8ui	a13, a4, 209
	l32r	a11, .LC369
	beqz.n	a12, .L458
	l32r	a11, .LC368
.L458:
	l8ui	a14, a4, 211
	l32r	a12, .LC369
	beqz.n	a14, .L459
	l32r	a12, .LC368
.L459:
	l8ui	a14, a4, 220
	movi	a8, 0xc0
	s32i	a14, sp, 36
	l8ui	a14, a4, 214
	add.n	a8, a8, sp
	s32i	a14, sp, 32
	l8ui	a14, a4, 213
	s32i	a14, sp, 28
	l8ui	a14, a4, 212
	s32i	a12, sp, 20
	s32i	a11, sp, 16
	s32i	a13, sp, 12
	s32i	a10, sp, 8
	s32i	a14, sp, 24
	s32i	a6, sp, 0
	s32i	a7, sp, 4
	l32i	a14, a8, 0
	l32i	a15, a8, 4
	l32r	a13, .LC375
	l32r	a11, .LC373
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L460
	addmi	a7, a4, 0x100
	l8ui	a8, a7, 104
	beqz.n	a8, .L461
	l8ui	a13, a7, 24
	l32i	a14, a4, 256
	l32i	a15, a4, 260
	l32i	a8, a4, 264
	l32i	a9, a4, 268
	l32i	a10, a4, 272
	l32i	a11, a4, 276
	l32r	a12, .LC369
	beqz.n	a13, .L462
	l32r	a12, .LC368
.L462:
	s32i	a11, sp, 12
	l32r	a13, .LC377
	l32r	a11, .LC373
	s32i	a12, sp, 16
	s32i	a10, sp, 8
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L496
.L465:
	l8ui	a8, a7, 48
	l32i	a14, a4, 296
	l32i	a15, a4, 300
	l32r	a12, .LC368
	bnez.n	a8, .L464
	l32r	a12, .LC369
	j	.L464
.L461:
	l32i	a14, a4, 288
	l32i	a15, a4, 292
	l32r	a13, .LC379
	l32r	a11, .LC373
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L496:
	bnez.n	a10, .L465
	j	.L460
.L464:
	l32i	a8, a4, 312
	l32i	a9, a4, 316
	s32i	a8, sp, 192
	l8ui	a8, a7, 64
	s32i	a9, sp, 196
	l32r	a13, .LC369
	beqz.n	a8, .L466
	l32r	a13, .LC368
.L466:
	l32i	a8, a4, 328
	l32i	a9, a4, 332
	s32i	a8, sp, 200
	l8ui	a8, a7, 80
	s32i	a9, sp, 204
	l32r	a6, .LC369
	beqz.n	a8, .L467
	l32r	a6, .LC368
.L467:
	l32i	a8, a4, 344
	l32i	a9, a4, 348
	l32i	a10, a4, 352
	l32i	a11, a4, 356
	l8ui	a4, a7, 104
	l32r	a7, .LC369
	beqz.n	a4, .L468
	l32r	a7, .LC368
.L468:
	s32i.n	a8, sp, 40
	movi	a8, 0xc8
	s32i.n	a10, sp, 48
	s32i.n	a11, sp, 52
	s32i	a7, sp, 56
	s32i.n	a9, sp, 44
	s32i	a6, sp, 32
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a13, sp, 16
	s32i	a8, sp, 24
	movi	a8, 0xc0
	s32i	a9, sp, 28
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	l32r	a13, .LC381
	l32r	a11, .LC373
	s32i	a12, sp, 0
	s32i	a8, sp, 8
	s32i	a9, sp, 12
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L497
.L457:
	l32r	a13, .LC383
	l32r	a11, .LC373
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L460
	l32i	a9, a4, 28
	l32i	a8, a4, 32
	l32i	a12, a4, 36
	s32i	a8, sp, 136
	l32i	a11, a4, 40
	s32i	a9, sp, 132
	movi	a8, 0x80
	l32i	a9, a4, 44
	add.n	a8, sp, a8
	s32i	a12, a8, 12
	s32i	a11, a8, 16
	l32i	a12, a4, 48
	l32i	a11, a4, 52
	s32i	a9, a8, 20
	l32i	a9, a4, 56
	s32i	a12, a8, 24
	s32i	a11, a8, 28
	l32i	a12, a4, 60
	l32i	a11, a4, 64
	s32i	a9, a8, 32
	l32i	a9, a4, 68
	l32i	a10, a4, 24
	s32i	a12, a8, 36
	s32i	a11, a8, 40
	l32i	a12, a4, 72
	l32i	a11, a4, 76
	s32i	a9, a8, 44
	l32i	a9, a4, 80
	l32r	a14, .LC370
	s32i	a10, sp, 128
	s32i	a12, a8, 48
	s32i	a11, a8, 52
	s32i	a9, a8, 56
	mov.n	a7, a8
	movi.n	a6, 0
.L469:
	l8ui	a8, a7, 8
	l32r	a13, .LC385
	s32i	a8, sp, 4
	l32i	a8, a7, 4
	l32r	a11, .LC373
	s32i	a8, sp, 0
	l32i	a15, a7, 0
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L460
	addi.n	a6, a6, 1
	l32r	a14, .LC387
	addi.n	a7, a7, 12
	bnei	a6, 5, .L469
	l32i	a8, a4, 88
	l8ui	a10, a4, 112
	s32i	a8, sp, 192
	l8ui	a8, a4, 84
	s32i	a8, sp, 200
	l8ui	a8, a4, 92
	sext	a8, a8, 7
	s32i	a8, sp, 208
	l8ui	a8, a4, 96
	sext	a8, a8, 7
	s32i	a8, sp, 212
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	s32i	a10, sp, 216
	l8ui	a10, a4, 113
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	mov.n	a7, a10
	l8ui	a10, a4, 115
	l8ui	a6, a4, 114
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	l32i	a9, a4, 124
	l32i	a8, a4, 120
	s32i	a9, sp, 228
	l32i	a9, a4, 132
	s32i	a8, sp, 224
	l32i	a8, a4, 128
	s32i	a9, sp, 236
	l8ui	a9, a4, 169
	s32i	a8, sp, 232
	s32i	a10, sp, 220
	l8ui	a12, a4, 116
	l8ui	a13, a4, 117
	l8ui	a14, a4, 136
	l32r	a8, .LC369
	beqz.n	a9, .L470
	l32r	a8, .LC368
.L470:
	l32i	a11, a4, 180
	l32i	a10, a4, 176
	s32i	a11, sp, 244
	l32i	a11, a4, 188
	s32i	a10, sp, 240
	l32i	a10, a4, 184
	s32i	a11, sp, 252
	l8ui	a11, a4, 137
	s32i	a10, sp, 248
	l32r	a9, .LC369
	beqz.n	a11, .L471
	l32r	a9, .LC368
.L471:
	l32i	a11, a4, 148
	l32i	a10, a4, 144
	l8ui	a5, a4, 153
	s32i	a11, sp, 260
	s32i	a10, sp, 256
	l8ui	a15, a4, 152
	l32r	a11, .LC369
	beqz.n	a5, .L472
	l32r	a11, .LC368
.L472:
	l8ui	a5, a4, 168
	l32i	a10, sp, 256
	s32i	a5, sp, 112
	l32i	a5, a4, 164
	l32i	a4, a4, 160
	s32i	a11, sp, 100
	l32i	a11, sp, 260
	s32i	a9, sp, 80
	movi	a9, 0xf8
	s32i	a15, sp, 96
	s32i	a4, sp, 104
	s32i	a5, sp, 108
	s32i	a10, sp, 88
	s32i	a11, sp, 92
	add.n	a9, a9, sp
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	movi	a9, 0xf0
	s32i	a10, sp, 72
	s32i	a11, sp, 76
	add.n	a9, a9, sp
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	s32i	a8, sp, 56
	movi	a8, 0xe8
	s32i	a10, sp, 64
	s32i	a11, sp, 68
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 52
	s32i	a8, sp, 48
	movi	a8, 0xe0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a14, sp, 32
	s32i	a8, sp, 40
	s32i	a13, sp, 28
	s32i	a9, sp, 44
	s32i	a12, sp, 24
	l32i	a8, sp, 220
	l32i	a15, sp, 200
	s32i	a8, sp, 20
	l32i	a8, sp, 216
	l32i	a14, sp, 192
	s32i	a8, sp, 8
	l32i	a8, sp, 212
	l32r	a13, .LC389
	s32i	a8, sp, 4
	l32i	a8, sp, 208
	l32r	a11, .LC373
	s32i	a6, sp, 16
	s32i	a7, sp, 12
	s32i	a8, sp, 0
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L497:
	mov.n	a2, a10
.L456:
	retw.n
.LFE1250:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18axisViewEPcjRjRKNS0_8AxisViewEb$constprop$0, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18axisViewEPcjRjRKNS0_8AxisViewEb$constprop$0
	.section	.rodata.str1.1
.LC392:
	.string	"{\"block\":%u,\"config_operation_id\":%lu,"
.LC395:
	.string	"\"raw_alarm\":%u,\"alarm_known\":%s,\"raw_motion\":%u,\"unknown_motion_bits\":%u,\"in_position\":%s,\"homing_complete\":%s,\"running\":%s,\"alarm_flag\":%s,\"released\":%s,\"enabled\":%s,\"positive_soft_limit\":%s,\"negative_soft_limit\":%s}"
.LC397:
	.string	"\"raw_inputs\":%u,\"raw_outputs\":%u,\"unknown_input_bits\":%u,\"unknown_output_bits\":%u,\"inputs\":[%s,%s,%s,%s],\"outputs\":[%s,%s],\"levels\":\"logical_valid_not_voltage\"}"
.LC399:
	.ascii	"\"position_words\":[%u,%u],\"raw_speed\":%u,\"pair_known\":%"
	.ascii	"s,\"raw_position\":%lu"
	.string	",\"position_source\":%u,\"word_order_resolution\":%u,\"position_source_resolution\":%u,\"position_signed_resolution\":%u,\"position_scale_resolution\":%u,\"speed_signed_resolution\":%u,\"speed_unit_resolution\":%u,\"physical_units\":\"unresolved\",\"raw_encoder_counts\":null}"
	.text
	.literal_position
	.literal .LC390, .LC361
	.literal .LC391, .LC363
	.literal .LC393, .LC392
	.literal .LC394, 16384
	.literal .LC396, .LC395
	.literal .LC398, .LC397
	.literal .LC400, .LC399
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateValueEPcjRjRKN14MotorControlRS6ESS_RS16StateObservationE$constprop$0, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateValueEPcjRjRKN14MotorControlRS6ESS_RS16StateObservationE$constprop$0:
.LFB1251:
	entry	sp, 96
.LCFI29:
	l32i	a15, a4, 16
	l8ui	a14, a4, 20
	l32r	a13, .LC393
	l32r	a11, .LC394
	mov.n	a12, a3
	mov.n	a10, a2
	mov.n	a7, a2
	s32i	a3, sp, 48
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L499
	l8ui	a8, a4, 20
	l32i	a12, sp, 48
	beqi	a8, 1, .L500
	beqi	a8, 2, .L501
	movi.n	a10, 0
	bnez.n	a8, .L499
	l8ui	a8, a4, 28
	l16ui	a14, a4, 22
	l32r	a15, .LC391
	beqz.n	a8, .L502
	l32r	a15, .LC390
.L502:
	l16ui	a8, a4, 24
	l8ui	a9, a4, 32
	s32i	a8, sp, 48
	l16ui	a3, a4, 26
	l32r	a8, .LC391
	beqz.n	a9, .L503
	l32r	a8, .LC390
.L503:
	l8ui	a10, a4, 33
	l32r	a9, .LC391
	beqz.n	a10, .L504
	l32r	a9, .LC390
.L504:
	l8ui	a11, a4, 34
	l32r	a10, .LC391
	beqz.n	a11, .L505
	l32r	a10, .LC390
.L505:
	l8ui	a13, a4, 35
	l32r	a11, .LC391
	beqz.n	a13, .L506
	l32r	a11, .LC390
.L506:
	l8ui	a6, a4, 36
	l32r	a13, .LC391
	beqz.n	a6, .L507
	l32r	a13, .LC390
.L507:
	l8ui	a5, a4, 37
	l32r	a6, .LC391
	beqz.n	a5, .L508
	l32r	a6, .LC390
.L508:
	l8ui	a2, a4, 38
	l32r	a5, .LC391
	beqz.n	a2, .L509
	l32r	a5, .LC390
.L509:
	l8ui	a2, a4, 39
	l32r	a4, .LC391
	beqz.n	a2, .L510
	l32r	a4, .LC390
.L510:
	s32i	a8, sp, 8
	l32i	a8, sp, 48
	s32i	a13, sp, 24
	s32i	a4, sp, 36
	l32r	a13, .LC396
	s32i	a5, sp, 32
	s32i	a6, sp, 28
	s32i	a11, sp, 20
	s32i	a10, sp, 16
	s32i	a9, sp, 12
	s32i	a3, sp, 4
	s32i	a8, sp, 0
	j	.L538
.L500:
	l8ui	a9, a4, 48
	l16ui	a14, a4, 40
	l16ui	a15, a4, 42
	l16ui	a5, a4, 44
	l16ui	a3, a4, 46
	l32r	a8, .LC391
	beqz.n	a9, .L511
	l32r	a8, .LC390
.L511:
	l8ui	a10, a4, 49
	l32r	a9, .LC391
	beqz.n	a10, .L512
	l32r	a9, .LC390
.L512:
	l8ui	a11, a4, 50
	l32r	a10, .LC391
	beqz.n	a11, .L513
	l32r	a10, .LC390
.L513:
	l8ui	a13, a4, 51
	l32r	a11, .LC391
	beqz.n	a13, .L514
	l32r	a11, .LC390
.L514:
	l8ui	a6, a4, 52
	l32r	a13, .LC391
	beqz.n	a6, .L515
	l32r	a13, .LC390
.L515:
	l8ui	a4, a4, 53
	l32r	a6, .LC391
	beqz.n	a4, .L516
	l32r	a6, .LC390
.L516:
	s32i	a13, sp, 24
	s32i	a11, sp, 20
	l32r	a13, .LC398
	l32r	a11, .LC394
	s32i	a10, sp, 16
	s32i	a6, sp, 28
	s32i	a9, sp, 12
	s32i	a8, sp, 8
	s32i	a3, sp, 4
	s32i	a5, sp, 0
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L499
.L501:
	l8ui	a10, a4, 60
	l16ui	a14, a4, 54
	l16ui	a15, a4, 56
	l16ui	a9, a4, 58
	l32r	a8, .LC391
	beqz.n	a10, .L517
	l32r	a8, .LC390
.L517:
	l8ui	a10, a4, 74
	l32r	a13, .LC400
	s32i	a10, sp, 36
	l8ui	a10, a4, 73
	s32i	a10, sp, 32
	l8ui	a10, a4, 72
	s32i	a10, sp, 28
	l8ui	a10, a4, 71
	s32i	a10, sp, 24
	l8ui	a10, a4, 70
	s32i	a10, sp, 20
	l8ui	a10, a4, 69
	s32i	a10, sp, 16
	l8ui	a10, a4, 68
	s32i	a10, sp, 12
	l32i	a10, a4, 64
	s32i	a8, sp, 4
	s32i	a10, sp, 8
	s32i	a9, sp, 0
.L538:
	l32r	a11, .LC394
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L499:
	mov.n	a2, a10
	retw.n
.LFE1251:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateValueEPcjRjRKN14MotorControlRS6ESS_RS16StateObservationE$constprop$0, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateValueEPcjRjRKN14MotorControlRS6ESS_RS16StateObservationE$constprop$0
	.section	.rodata.str1.1
.LC401:
	.string	"enabled"
.LC403:
	.string	"disabled"
.LC409:
	.string	"checked_rtu_register"
.LC411:
	.string	"absent"
.LC413:
	.string	"OK"
.LC415:
	.string	",\"now_us\":%llu,\"monitoring\":\"%s\",\"atomic_snapshot\":false,\"sample_time\":\"drive_internal_age_undocumented\",\"state_blocks\":["
.LC418:
	.ascii	"%s{\"block\":%u,\"valid\":%s,\"current\":%s,\"fresh\":%s,\"s"
	.ascii	"ource\":\"%s\",\"target\":%lu,\"address\":%u,\"generation\":"
	.ascii	"%lu,\"operation_id\":%lu,\"attempt_known\":%s,\"last_attempt"
	.ascii	"_ok\":%s,\"last_attempt_us\":%llu,\"last_attempt_tar"
	.string	"get\":%lu,\"last_attempt_address\":%u,\"last_attempt_generation\":%lu,\"last_attempt_operation_id\":%lu,\"last_attempt_status\":\"%s\",\"last_attempt_detail\":%ld,\"last_success_us\":%llu,\"observed_earliest_us\":%llu,\"observed_latest_us\":%llu,\"delivered_us\":%llu,\"age_us\":"
.LC420:
	.string	"%llu"
.LC422:
	.string	"null"
.LC424:
	.string	",\"invalidated_us\":%llu"
.LC426:
	.string	",\"value\":"
.LC428:
	.string	",\"current_config_operation_id\":%lu,\"interpretation_current\":%s"
.LC430:
	.string	"}"
.LC432:
	.string	"],\"selected_target\":%lu,\"selected_address\":%u,\"selected_generation\":%lu,\"communication_known\":%s,\"communication_target\":%lu,\"communication_address\":%u,\"communication_generation\":%lu,\"communication_earliest_us\":%llu,\"communication_latest_us\":%llu"
.LC434:
	.string	",\"age_source\":\"model_probe\",\"communication_age_us\":"
	.text
	.literal_position
	.literal .LC402, .LC401
	.literal .LC404, .LC403
	.literal .LC405, .LC386
	.literal .LC406, .LC318
	.literal .LC407, .LC361
	.literal .LC408, .LC363
	.literal .LC410, .LC409
	.literal .LC412, .LC411
	.literal .LC414, .LC413
	.literal .LC416, .LC415
	.literal .LC417, 16384
	.literal .LC419, .LC418
	.literal .LC421, .LC420
	.literal .LC423, .LC422
	.literal .LC425, .LC424
	.literal .LC427, .LC426
	.literal .LC429, .LC428
	.literal .LC431, .LC430
	.literal .LC433, .LC432
	.literal .LC435, .LC434
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateCacheEPcjRjRKNS0_8SnapshotE$constprop$0, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateCacheEPcjRjRKNS0_8SnapshotE$constprop$0:
.LFB1253:
	entry	sp, 256
.LCFI30:
	l8ui	a8, a4, 120
	l32i	a14, a4, 480
	s32i	a8, sp, 128
	s32i	a8, sp, 112
	s8i	a8, sp, 116
	l32i	a8, a4, 284
	l32i	a15, a4, 484
	s32i	a8, sp, 164
	s32i	a8, sp, 120
	addmi	a8, a4, 0x100
	l8ui	a9, a8, 232
	l32r	a8, .LC404
	beqz.n	a9, .L540
	l32r	a8, .LC402
.L540:
	l32r	a13, .LC416
	l32r	a11, .LC417
	s32i	a8, sp, 0
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	movi.n	a6, 0
	bnez.n	a10, .L541
.L553:
	movi.n	a2, 0
	j	.L542
.L541:
	l32i	a8, a4, 472
	beqz.n	a8, .L574
	extui	a7, a6, 0, 16
	addx8	a7, a7, a7
	slli	a7, a7, 5
	addx8	a9, a6, a6
	add.n	a7, a8, a7
	slli	a9, a9, 5
	add.n	a8, a8, a9
	addi	a11, sp, 112
	mov.n	a10, a7
	l8ui	a5, a8, 216
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	l32i	a9, a4, 144
	movi	a14, 0x3e8
	muluh	a15, a14, a9
	l32i	a12, a4, 480
	mull	a14, a14, a9
	l32i	a13, a4, 484
	s32i	a10, sp, 136
	addi	a11, sp, 112
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	movi.n	a8, 0
	s32i	a8, sp, 132
	l32i	a8, sp, 136
	beqz.n	a5, .L543
	addmi	a9, a4, 0x100
	l8ui	a11, a9, 17
	l32i	a9, a7, 0
	bne	a9, a11, .L543
	l8ui	a11, a7, 4
	bne	a11, a9, .L543
	l32i	a11, a7, 8
	l32i	a9, a4, 280
	bne	a11, a9, .L543
	l32i	a9, a4, 268
	j	.L629
.L574:
	movi.n	a7, 0
	movi.n	a10, 0
	movi.n	a8, 0
	movi.n	a5, 0
	movi.n	a9, 0
.L629:
	s32i	a9, sp, 132
.L543:
	l32r	a9, .LC406
	s32i	a9, sp, 192
	beqz.n	a6, .L544
	l32r	a9, .LC405
	s32i	a9, sp, 192
.L544:
	l32r	a9, .LC408
	s32i	a9, sp, 196
	beqz.n	a5, .L545
	l32r	a9, .LC407
	s32i	a9, sp, 196
.L545:
	l32r	a9, .LC408
	s32i	a9, sp, 200
	beqz.n	a8, .L546
	l32r	a8, .LC407
	s32i	a8, sp, 200
.L546:
	l32r	a8, .LC408
	s32i	a8, sp, 204
	beqz.n	a10, .L547
	l32r	a8, .LC407
	s32i	a8, sp, 204
.L547:
	beqz.n	a5, .L548
	l32i	a8, a7, 0
	s32i	a8, sp, 144
	l8ui	a8, a7, 4
	s32i	a8, sp, 148
	l32i	a8, a7, 8
	s32i	a8, sp, 152
	l32i	a8, a7, 12
	s32i	a8, sp, 156
	l32r	a8, .LC410
	j	.L630
.L548:
	movi.n	a8, 0
	beqz.n	a7, .L583
	s32i	a8, sp, 156
	s32i	a8, sp, 152
	s32i	a8, sp, 148
	s32i	a8, sp, 144
	l32r	a8, .LC412
.L630:
	l32r	a9, .LC408
	s32i	a8, sp, 140
	l8ui	a8, a7, 217
	s32i	a9, sp, 160
	beqz.n	a8, .L551
	l32r	a8, .LC407
	s32i	a8, sp, 160
.L551:
	l32r	a9, .LC408
	l8ui	a8, a7, 218
	s32i	a9, sp, 136
	beqz.n	a8, .L552
	l32r	a8, .LC407
	s32i	a8, sp, 136
.L552:
	l32i	a8, a7, 224
	s32i	a8, sp, 208
	l32i	a8, a7, 228
	s32i	a8, sp, 212
	l32i	a8, a7, 200
	s32i	a8, sp, 168
	l8ui	a8, a7, 204
	s32i	a8, sp, 172
	l32i	a8, a7, 208
	s32i	a8, sp, 176
	l32i	a8, a7, 212
	s32i	a8, sp, 180
	addmi	a8, a7, 0x100
	l8ui	a10, a8, 16
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a7, 276
	s32i	a10, sp, 184
	s32i	a8, sp, 188
	beqz.n	a5, .L586
	l32i	a9, a7, 232
	l32i	a8, a7, 236
	l32i	a11, a7, 240
	l32i	a10, a7, 244
	l32i	a13, a7, 248
	l32i	a12, a7, 252
	l32i	a15, a7, 256
	l32i	a14, a7, 260
	j	.L550
.L583:
	s32i	a8, sp, 188
	l32r	a8, .LC414
	s32i	a8, sp, 184
	movi.n	a8, 0
	s32i	a8, sp, 180
	s32i	a8, sp, 176
	s32i	a8, sp, 172
	s32i	a8, sp, 168
	s32i	a8, sp, 208
	s32i	a8, sp, 212
	l32r	a8, .LC408
	s32i	a8, sp, 136
	s32i	a8, sp, 160
	movi.n	a8, 0
	s32i	a8, sp, 156
	s32i	a8, sp, 152
	s32i	a8, sp, 148
	s32i	a8, sp, 144
	l32r	a8, .LC412
	s32i	a8, sp, 140
.L586:
	movi.n	a13, 0
	movi.n	a12, 0
	movi.n	a11, 0
	movi.n	a10, 0
	movi.n	a9, 0
	movi.n	a8, 0
	movi.n	a15, 0
	movi.n	a14, 0
.L550:
	s32i	a8, sp, 76
	l32i	a8, sp, 188
	s32i	a15, sp, 96
	s32i	a8, sp, 68
	l32i	a8, sp, 184
	s32i	a14, sp, 100
	s32i	a8, sp, 64
	l32i	a8, sp, 180
	s32i	a13, sp, 88
	s32i	a8, sp, 60
	l32i	a8, sp, 176
	s32i	a12, sp, 92
	s32i	a8, sp, 56
	l32i	a8, sp, 172
	s32i	a11, sp, 80
	s32i	a8, sp, 52
	l32i	a8, sp, 168
	s32i	a10, sp, 84
	s32i	a8, sp, 48
	l32i	a8, sp, 208
	s32i	a9, sp, 72
	s32i	a8, sp, 40
	l32i	a8, sp, 212
	mov.n	a15, a6
	s32i	a8, sp, 44
	l32i	a8, sp, 136
	mov.n	a12, a3
	s32i	a8, sp, 36
	l32i	a8, sp, 160
	mov.n	a10, a2
	s32i	a8, sp, 32
	l32i	a8, sp, 156
	s32i	a8, sp, 28
	l32i	a8, sp, 152
	s32i	a8, sp, 24
	l32i	a8, sp, 148
	l32i	a14, sp, 192
	s32i	a8, sp, 20
	l32i	a8, sp, 144
	l32r	a13, .LC419
	s32i	a8, sp, 16
	l32i	a8, sp, 140
	l32r	a11, .LC417
	s32i	a8, sp, 12
	l32i	a8, sp, 204
	s32i	a8, sp, 8
	l32i	a8, sp, 200
	s32i	a8, sp, 4
	l32i	a8, sp, 196
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L553
	beqz.n	a5, .L554
	l32i	a11, a4, 484
	l32i	a10, a7, 244
	l32i	a9, a4, 480
	l32i	a8, a7, 240
	bltu	a11, a10, .L554
	bne	a10, a11, .L591
	bltu	a9, a8, .L554
.L591:
	l8ui	a12, a7, 216
	movi.n	a14, 0
	movi.n	a15, 0
	beqz.n	a12, .L556
	sub	a15, a11, a10
	bgeu	a9, a8, .L557
	addi.n	a15, a15, -1
.L557:
	sub	a14, a9, a8
.L556:
	l32r	a13, .LC421
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L553
.L559:
	l32i	a14, a7, 264
	l32i	a15, a7, 268
	j	.L558
.L554:
	l32r	a13, .LC423
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L553
	bnez.n	a7, .L559
	movi.n	a14, 0
	movi.n	a15, 0
.L558:
	l32r	a13, .LC425
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L553
	beqi	a6, 2, .L560
.L564:
	l32r	a13, .LC427
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L561
	j	.L553
.L560:
	l32r	a15, .LC408
	beqz.n	a5, .L562
	l32i	a8, a7, 16
	l32i	a9, sp, 132
	bne	a8, a9, .L592
	l32r	a15, .LC407
	bnez.n	a8, .L562
.L592:
	l32r	a15, .LC408
.L562:
	l32i	a14, sp, 132
	l32r	a13, .LC429
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L564
	j	.L553
.L561:
	beqz.n	a5, .L565
	mov.n	a12, a7
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateValueEPcjRjRKN14MotorControlRS6ESS_RS16StateObservationE$constprop$0
	j	.L628
.L567:
	l32r	a13, .LC431
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L566
	j	.L553
.L565:
	l32r	a13, .LC423
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L628:
	bnez.n	a10, .L567
	j	.L553
.L566:
	addi.n	a6, a6, 1
	bnei	a6, 3, .L541
	addmi	a7, a4, 0x200
	l8ui	a8, a7, 32
	l32r	a10, .LC408
	beqz.n	a8, .L568
	l32r	a10, .LC407
.L568:
	l32i	a8, a4, 568
	l32i	a9, a4, 572
	s32i	a8, sp, 32
	s32i	a9, sp, 36
	l32i	a8, a4, 560
	l32i	a9, a4, 564
	s32i	a8, sp, 24
	s32i	a9, sp, 28
	l32i	a8, a4, 556
	l32i	a15, sp, 128
	s32i	a8, sp, 16
	l8ui	a8, a7, 40
	l32r	a13, .LC433
	s32i	a8, sp, 12
	l32i	a8, a4, 548
	l32r	a11, .LC417
	s32i	a8, sp, 8
	l32i	a8, sp, 164
	s32i	a10, sp, 4
	s32i	a8, sp, 0
	mov.n	a14, a15
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L553
	l32r	a13, .LC435
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L553
	l8ui	a8, a7, 32
	beqz.n	a8, .L569
	l32i	a15, a4, 484
	l32i	a9, a4, 564
	l32i	a14, a4, 480
	l32i	a8, a4, 560
	bltu	a15, a9, .L569
	bne	a9, a15, .L593
	bltu	a14, a8, .L569
.L593:
	sub	a15, a15, a9
	bgeu	a14, a8, .L571
	addi.n	a15, a15, -1
.L571:
	l32r	a13, .LC421
	l32r	a11, .LC417
	sub	a14, a14, a8
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L631
.L569:
	l32r	a13, .LC423
	l32r	a11, .LC417
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L631:
	mov.n	a2, a10
.L542:
	retw.n
.LFE1253:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateCacheEPcjRjRKNS0_8SnapshotE$constprop$0, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateCacheEPcjRjRKNS0_8SnapshotE$constprop$0
	.section	.rodata.str1.1
.LC440:
	.string	",\"original\":"
.LC443:
	.string	",\"requested\":"
.LC445:
	.string	",\"active\":"
.LC447:
	.string	",\"active_known\":%s,\"blocked\":%s,\"configuring\":%s,\"serial_generation\":%lu,\"actual_baud\":%lu,\"failure\":\"%s\",\"device_settings_changed\":false,\"supported_bauds\":["
.LC449:
	.string	"%s%lu"
.LC451:
	.string	"],\"supported_formats\":["
.LC453:
	.string	"%s\"%s\""
.LC455:
	.string	"],\"timing\":{\"character_min_us\":%lu,\"character_max_us\":%lu,\"stop_guard_us\":%lu,\"capture_period_us\":%lu,\"gap15_us\":%lu,\"gap35_us\":%lu,\"reply_gap_us\":%lu,\"response_timeout_us\":%lu,\"request_timeout_us\":%lu,\"recovery_guard_us\":%lu,\"tx_timeout_us\":%lu}}"
	.text
	.literal_position
	.literal .LC436, .LC361
	.literal .LC437, .LC363
	.literal .LC438, .LC386
	.literal .LC439, .LC318
	.literal .LC441, .LC440
	.literal .LC442, 16384
	.literal .LC444, .LC443
	.literal .LC446, .LC445
	.literal .LC448, .LC447
	.literal .LC450, .LC449
	.literal .LC452, .LC451
	.literal .LC454, .LC453
	.literal .LC456, .LC455
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostStateEPcjRjRKNS0_12HostSnapshotE$constprop$0, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostStateEPcjRjRKNS0_12HostSnapshotE$constprop$0:
.LFB1254:
	entry	sp, 96
.LCFI31:
	l32r	a13, .LC441
	l32r	a11, .LC442
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L633
.L635:
	movi.n	a2, 0
	j	.L634
.L633:
	l32r	a11, .LC442
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	beqz.n	a10, .L635
	l32r	a13, .LC444
	l32r	a11, .LC442
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L635
	l32r	a11, .LC442
	addi.n	a13, a4, 8
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	beqz.n	a10, .L635
	l32r	a13, .LC446
	l32r	a11, .LC442
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L635
	l32r	a11, .LC442
	addi	a13, a4, 16
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	beqz.n	a10, .L635
	l8ui	a8, a4, 24
	l32r	a7, .LC437
	beqz.n	a8, .L636
	l32r	a7, .LC436
.L636:
	l8ui	a8, a4, 25
	l32r	a6, .LC437
	beqz.n	a8, .L637
	l32r	a6, .LC436
.L637:
	l8ui	a8, a4, 26
	l32r	a5, .LC437
	beqz.n	a8, .L638
	l32r	a5, .LC436
.L638:
	l32i	a8, a4, 28
	l32i	a9, a4, 32
	l8ui	a10, a4, 96
	s32i	a8, sp, 52
	s32i	a9, sp, 48
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111hostFailureENS0_11HostFailureE
	l32i	a9, sp, 48
	l32i	a8, sp, 52
	l32r	a13, .LC448
	l32r	a11, .LC442
	s32i	a10, sp, 12
	s32i	a9, sp, 8
	s32i	a8, sp, 4
	s32i	a5, sp, 0
	mov.n	a15, a6
	mov.n	a14, a7
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L635
	addi	a7, a4, 100
	addi	a6, a4, 116
	movi.n	a10, 0
	j	.L639
.L642:
	l32i	a15, a7, 0
	beqz.n	a15, .L640
	l32r	a14, .LC439
	beqz.n	a10, .L641
	l32r	a14, .LC438
.L641:
	l32r	a13, .LC450
	l32r	a11, .LC442
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L635
.L640:
	addi.n	a7, a7, 4
.L639:
	bne	a6, a7, .L642
	l32r	a13, .LC452
	l32r	a11, .LC442
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L635
	movi.n	a7, 0
	movi.n	a10, 0
.L645:
	add.n	a8, a4, a7
	l8ui	a8, a8, 116
	beqz.n	a8, .L643
	l32r	a6, .LC439
	beqz.n	a10, .L644
	l32r	a6, .LC438
.L644:
	extui	a10, a7, 0, 8
	call8	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE
	l32r	a13, .LC454
	l32r	a11, .LC442
	mov.n	a15, a10
	mov.n	a14, a6
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L635
.L643:
	addi.n	a7, a7, 1
	bnei	a7, 4, .L645
	l32i	a8, a4, 56
	l32r	a13, .LC456
	s32i	a8, sp, 32
	l32i	a8, a4, 92
	l32r	a11, .LC442
	s32i	a8, sp, 28
	l32i	a8, a4, 88
	mov.n	a10, a2
	s32i	a8, sp, 24
	l32i	a8, a4, 84
	mov.n	a12, a3
	s32i	a8, sp, 20
	l32i	a8, a4, 80
	s32i	a8, sp, 16
	l32i	a8, a4, 40
	s32i	a8, sp, 12
	l32i	a8, a4, 36
	s32i	a8, sp, 8
	l32i	a8, a4, 76
	s32i	a8, sp, 4
	l32i	a8, a4, 72
	s32i	a8, sp, 0
	l32i	a15, a4, 68
	l32i	a14, a4, 64
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L634:
	retw.n
.LFE1254:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostStateEPcjRjRKNS0_12HostSnapshotE$constprop$0, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostStateEPcjRjRKNS0_12HostSnapshotE$constprop$0
	.section	.text._ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE,"axG",@progbits,_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE,comdat
	.literal_position
	.literal .LC457, .LC107
	.literal .LC458, CSWTCH$1533
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	.type	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE, @function
_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE:
.LFB375:
	entry	sp, 32
.LCFI32:
	extui	a8, a2, 0, 8
	l32r	a2, .LC457
	bgeui	a8, 3, .L685
	l32r	a9, .LC458
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L685:
	retw.n
.LFE375:
	.size	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE, .-_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	.section	.text._ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE,"axG",@progbits,_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE,comdat
	.literal_position
	.literal .LC459, .LC107
	.literal .LC460, CSWTCH$1535
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	.type	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE, @function
_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE:
.LFB376:
	entry	sp, 32
.LCFI33:
	extui	a8, a2, 0, 8
	movi.n	a9, 9
	l32r	a2, .LC459
	bltu	a9, a8, .L688
	l32r	a9, .LC460
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L688:
	retw.n
.LFE376:
	.size	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE, .-_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	.section	.text._ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj,"axG",@progbits,_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj,comdat
	.literal_position
	.literal .LC461, _ZZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcjE6DIGITS
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	.type	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj, @function
_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj:
.LFB377:
	entry	sp, 32
.LCFI34:
	movi.n	a8, 0
	beqz.n	a2, .L692
	addi.n	a8, a5, -1
	srli	a8, a8, 1
	minu	a8, a8, a3
.L692:
	l32r	a10, .LC461
	addx2	a9, a8, a4
	j	.L693
.L694:
	l8ui	a8, a2, 0
	srli	a8, a8, 4
	add.n	a8, a10, a8
	l8ui	a8, a8, 0
	s8i	a8, a4, 0
	l8ui	a8, a2, 0
	addi.n	a2, a2, 1
	extui	a8, a8, 0, 4
	add.n	a8, a10, a8
	l8ui	a8, a8, 0
	s8i	a8, a4, 1
	addi.n	a4, a4, 2
.L693:
	bne	a4, a9, .L694
	movi.n	a8, 0
	s8i	a8, a4, 0
	retw.n
.LFE377:
	.size	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj, .-_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	.section	.rodata.str1.1
.LC464:
	.ascii	"{\"step\":%u,\"event\":%u"
	.string	",\"raw_hex\":\"%s\",\"received_length\":%u,\"tx_accepted\":%u,\"tx_complete\":%s,\"response_confirmed\":%s,\"qualified\":%s,\"execution_unknown\":%s,\"earliest_us\":%llu,\"latest_us\":%llu,\"delivered_us\":%llu,\"transport_detail\":%ld,\"status\":\"%s\",\"detail\":%ld,\"frame_error\":%u}"
	.text
	.literal_position
	.literal .LC462, .LC361
	.literal .LC463, .LC363
	.literal .LC465, .LC464
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE, @function
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE:
.LFB1034:
	entry	sp, 224
.LCFI35:
	l32i	a11, a5, 24
	addi	a12, sp, 80
	movi.n	a13, 0x27
	addi.n	a10, a5, 2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l8ui	a8, a5, 0
	l8ui	a15, a5, 1
	s32i	a8, sp, 128
	l8ui	a8, a5, 36
	l32i	a11, a5, 28
	l32i	a12, a5, 32
	l32r	a7, .LC463
	beqz.n	a8, .L698
	l32r	a7, .LC462
.L698:
	l8ui	a8, a5, 37
	l32r	a6, .LC463
	beqz.n	a8, .L699
	l32r	a6, .LC462
.L699:
	l8ui	a9, a5, 38
	l32r	a8, .LC463
	beqz.n	a9, .L700
	l32r	a8, .LC462
.L700:
	l8ui	a10, a5, 39
	l32r	a9, .LC463
	beqz.n	a10, .L701
	l32r	a9, .LC462
.L701:
	s32i	a9, sp, 176
	s32i	a8, sp, 172
	l32i	a9, a5, 44
	l32i	a8, a5, 40
	s32i	a9, sp, 140
	s32i	a8, sp, 136
	l32i	a9, a5, 52
	l32i	a8, a5, 48
	l32i	a13, a5, 64
	l8ui	a10, a5, 68
	s32i	a8, sp, 144
	s32i	a9, sp, 148
	l32i	a8, a5, 56
	l32i	a9, a5, 60
	s32i	a12, sp, 168
	s32i	a11, sp, 164
	s32i	a15, sp, 160
	s32i	a8, sp, 152
	s32i	a9, sp, 156
	s32i	a13, sp, 132
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l8ui	a14, a5, 80
	l32i	a13, sp, 132
	s32i	a14, sp, 68
	l32i	a14, a5, 72
	movi	a8, 0x98
	s32i	a14, sp, 64
	s32i	a10, sp, 60
	s32i	a13, sp, 56
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 52
	s32i	a8, sp, 48
	movi	a8, 0x90
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 44
	s32i	a8, sp, 40
	movi	a8, 0x88
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 36
	s32i	a8, sp, 32
	l32i	a9, sp, 176
	l32i	a8, sp, 172
	s32i	a9, sp, 24
	s32i	a8, sp, 20
	s32i	a6, sp, 16
	l32i	a12, sp, 168
	l32i	a11, sp, 164
	addi	a8, sp, 80
	l32i	a15, sp, 160
	l32i	a14, sp, 128
	l32r	a13, .LC465
	s32i	a12, sp, 8
	s32i	a11, sp, 4
	s32i	a7, sp, 12
	s32i	a8, sp, 0
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
	retw.n
.LFE1034:
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE, .-_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	.align	4
	.global	_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE
	.type	_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE, @function
_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE:
.LFB994:
	entry	sp, 32
.LCFI36:
	mov.n	a8, a2
	l8ui	a2, a2, 0
	beqz.n	a2, .L707
	bnei	a2, 3, .L708
	l32i	a9, a8, 4
	movi.n	a8, 0xd
	addi	a9, a9, -22
	movi.n	a2, 0xb
	bltu	a8, a9, .L707
	movi.n	a8, 1
	ssl	a9
	sll	a8, a8
	movi.n	a9, 0x12
	addmi	a9, a9, 0x2300
	movi.n	a2, 0xd
	bany	a8, a9, .L707
	movi	a9, 0x81
	addmi	a9, a9, 0x1000
	and	a8, a8, a9
	movi.n	a2, 0xb
	movi.n	a9, 8
	movnez	a2, a9, a8
	j	.L707
.L708:
	movi.n	a2, 8
.L707:
	retw.n
.LFE994:
	.size	_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE, .-_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE
	.section	.rodata.str1.1
.LC468:
	.string	"raw"
.LC470:
	.string	"decoded"
.LC476:
	.string	"write_registers"
.LC478:
	.string	"read_registers"
.LC480:
	.string	"write_register"
.LC484:
	.ascii	"{\"type\":\"traffic\",\"profile\":\"ess"
	.string	"_rs\",\"mode\":\"%s\",\"sequence\":%llu,\"transaction\":%llu,\"kind\":\"%s\",\"at_us\":%llu,\"start_us\":%llu,\"end_us\":%llu,\"uncertainty_us\":%lu,\"length\":%u,\"code\":%u,\"complete\":%s,\"raw_hex\":\"%s\",\"expected_request_hex\":\"%s\",\"expected_request_sequence\":%llu,\"decode_status\":"
.LC487:
	.string	"\"%s\",\"decode_detail\":%ld,\"frame_error\":%u,\"decoded\":"
.LC490:
	.string	"{\"address\":%u,\"function\":%u,\"register_start\":%u,\"register_count\":%u,\"exception\":%s,\"exception_code\":%u,\"words\":["
.LC492:
	.string	"%s%u"
.LC494:
	.string	"],\"function_name\":\"%s\",\"register_names\":["
.LC497:
	.string	"%snull"
.LC499:
	.string	"]}"
.LC501:
	.string	"null,\"decode_detail\":0,\"frame_error\":0,\"decoded\":null"
	.text
	.literal_position
	.literal .LC469, .LC468
	.literal .LC471, .LC470
	.literal .LC472, .LC361
	.literal .LC473, .LC363
	.literal .LC474, .LC318
	.literal .LC475, .LC386
	.literal .LC477, .LC476
	.literal .LC479, .LC478
	.literal .LC481, .LC480
	.literal .LC483, 35380
	.literal .LC485, .LC484
	.literal .LC486, 16384
	.literal .LC488, .LC487
	.literal .LC489, .LC422
	.literal .LC491, .LC490
	.literal .LC493, .LC492
	.literal .LC495, .LC494
	.literal .LC496, .LC453
	.literal .LC498, .LC497
	.literal .LC500, .LC499
	.literal .LC502, .LC501
	.literal .LC503, .LC430
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console13reportTrafficERKN14MotorControlRS13TrafficRecordENS0_9DebugModeEPS4_
	.type	_ZN21MotorControlRSExample5Probe7Console13reportTrafficERKN14MotorControlRS13TrafficRecordENS0_9DebugModeEPS4_, @function
_ZN21MotorControlRSExample5Probe7Console13reportTrafficERKN14MotorControlRS13TrafficRecordENS0_9DebugModeEPS4_:
.LFB1047:
	entry	sp, 1264
.LCFI37:
	mov.n	a8, a4
	mov.n	a4, a5
	extui	a5, a8, 0, 8
	addi.n	a10, a5, -1
	extui	a10, a10, 0, 8
	bltui	a10, 2, .L716
.L742:
	movi.n	a2, 0
	j	.L717
.L716:
	movi	a10, 0x8b
	slli	a10, a10, 8
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L742
	l32r	a10, .LC483
	movi	a9, 0x4a0
	add.n	a10, a2, a10
	l8ui	a8, a10, 0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	bnez.n	a8, .L742
	l32i	a10, a2, 8
	beqz.n	a10, .L742
	l16ui	a11, a3, 44
	movi	a6, 0x100
	bltu	a6, a11, .L742
	addi	a7, sp, 80
	movi	a12, 0x201
	addi	a10, a3, 50
	movi	a13, 0x201
	add.n	a12, a7, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	movi.n	a10, 0
	movi.n	a11, 0
	beqz.n	a4, .L719
	l32i	a11, a4, 8
	l32i	a10, a3, 8
	bne	a11, a10, .L745
	l32i	a11, a4, 12
	l32i	a10, a3, 12
	bne	a11, a10, .L745
	l16ui	a12, a4, 44
	movi.n	a10, 0
	movi.n	a11, 0
	bltu	a6, a12, .L719
	movi	a9, 0x4a0
	movi.n	a8, 1
	add.n	a9, a9, sp
	addi	a10, a4, 50
	mov.n	a11, a12
	s32i	a8, a9, 0
	j	.L719
.L745:
	movi.n	a10, 0
	movi.n	a11, 0
.L719:
	mov.n	a12, a7
	movi	a13, 0x201
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32r	a8, .LC471
	movi	a9, 0x4a4
	addmi	a12, a7, 0x400
	movi.n	a10, 0
	add.n	a9, a9, sp
	movi	a6, 0x124
	s32i	a10, a12, 64
	s32i	a8, a9, 0
	add.n	a6, a2, a6
	bnei	a5, 1, .L720
	l32r	a8, .LC469
	movi	a9, 0x4a4
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L720:
	l32i	a8, a3, 0
	l32i	a9, a3, 4
	movi	a10, 0x4a8
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, a3, 8
	l32i	a9, a3, 12
	movi	a10, 0x4b0
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l8ui	a10, a3, 48
	call8	_ZN14MotorControlRS15trafficKindNameENS_11TrafficKindE
	l32i	a11, a3, 20
	mov.n	a8, a10
	movi	a9, 0x4b8
	l32i	a10, a3, 16
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	l32i	a10, a3, 24
	l32i	a11, a3, 28
	movi	a9, 0x4c0
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	l32i	a10, a3, 32
	movi	a9, 0x4c8
	add.n	a9, a9, sp
	l32i	a11, a3, 36
	s32i	a10, a9, 0
	l8ui	a10, a3, 49
	s32i	a11, a9, 4
	l16ui	a14, a3, 44
	l32i	a9, a3, 40
	l16ui	a15, a3, 46
	l32r	a13, .LC473
	beqz.n	a10, .L721
	l32r	a13, .LC472
.L721:
	bnei	a5, 2, .L750
	l8ui	a10, a3, 48
	bnei	a10, 1, .L750
	movi	a7, 0x4a0
	add.n	a7, a7, sp
	l32i	a7, a7, 0
	addi	a10, sp, 80
	movi.n	a12, 0
	movi.n	a11, 0
	beqz.n	a7, .L722
	l32i	a12, a4, 0
	l32i	a11, a4, 4
	j	.L722
.L750:
	l32r	a10, .LC474
	movi.n	a12, 0
	movi.n	a11, 0
.L722:
	s32i	a10, sp, 68
	addi	a7, sp, 80
	movi	a10, 0x201
	s32i	a9, sp, 48
	add.n	a10, a7, a10
	movi	a9, 0x4c8
	s32i	a12, sp, 72
	s32i	a13, sp, 60
	s32i	a11, sp, 76
	s32i	a10, sp, 64
	s32i	a15, sp, 56
	s32i	a14, sp, 52
	add.n	a9, a9, sp
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	movi	a9, 0x4c0
	s32i	a10, sp, 40
	s32i	a11, sp, 44
	add.n	a9, a9, sp
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	movi	a9, 0x4b8
	s32i	a10, sp, 32
	s32i	a11, sp, 36
	add.n	a9, a9, sp
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	s32i	a8, sp, 16
	movi	a8, 0x4b0
	s32i	a10, sp, 24
	s32i	a11, sp, 28
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 12
	s32i	a8, sp, 8
	movi	a8, 0x4a8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x4a4
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32r	a13, .LC485
	movi	a8, 0x440
	l32r	a11, .LC486
	add.n	a12, a7, a8
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L742
	bnei	a5, 2, .L723
	l8ui	a10, a3, 48
	bgeui	a10, 2, .L723
	addmi	a5, a7, 0x400
	movi.n	a12, 0x30
	movi.n	a11, 0
	addi.n	a10, a5, 4
	call8	memset
	movi	a8, 0x4a0
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	movi.n	a10, 0
	s8i	a10, a5, 68
	movi.n	a10, 0
	moveqz	a4, a10, a9
	movi	a13, 0x444
	movi	a12, 0x404
	mov.n	a10, a3
	add.n	a13, a7, a13
	add.n	a12, a7, a12
	mov.n	a11, a4
	call8	_ZN14MotorControlRS6ESS_RS13decodeTrafficERKNS_13TrafficRecordEPS2_RNS0_14TrafficDecodedEPNS0_10FrameErrorE
	movi	a8, 0x4a0
	s32i	a10, a5, 52
	s32i	a11, a5, 56
	add.n	a8, a8, sp
	s32i	a12, a5, 60
	mov.n	a3, a5
	extui	a5, a10, 0, 8
	s32i	a11, a8, 0
	mov.n	a10, a5
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l8ui	a9, a3, 68
	movi	a8, 0x4a0
	add.n	a8, a8, sp
	s32i	a9, sp, 0
	l32i	a15, a8, 0
	l32r	a13, .LC488
	movi	a8, 0x440
	l32r	a11, .LC486
	mov.n	a14, a10
	add.n	a12, a7, a8
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L742
	beqz.n	a5, .L727
	bnei	a5, 6, .L728
	l8ui	a8, a3, 48
	bnez.n	a8, .L727
.L728:
	l32r	a13, .LC489
	j	.L795
.L727:
	addmi	a8, a7, 0x400
	l8ui	a11, a8, 48
	l8ui	a14, a8, 4
	l8ui	a15, a8, 5
	l16ui	a9, a8, 8
	l16ui	a10, a8, 10
	l32r	a8, .LC473
	beqz.n	a11, .L730
	l32r	a8, .LC472
.L730:
	addmi	a3, a7, 0x400
	l8ui	a11, a3, 6
	movi	a12, 0x440
	s32i	a11, sp, 12
	l32r	a13, .LC491
	l32r	a11, .LC486
	s32i	a10, sp, 4
	s32i	a8, sp, 8
	s32i	a9, sp, 0
	add.n	a12, a7, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L742
	movi	a5, 0x404
	add.n	a5, a7, a5
	movi.n	a4, 0
	j	.L731
.L733:
	l32r	a14, .LC474
	beqz.n	a4, .L732
	l32r	a14, .LC475
.L732:
	l16ui	a15, a5, 8
	l32r	a13, .LC493
	l32r	a11, .LC486
	movi	a12, 0x440
	add.n	a12, a7, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	addi.n	a5, a5, 2
	beqz.n	a10, .L742
	addi.n	a4, a4, 1
.L731:
	l32i	a8, a3, 44
	bltu	a4, a8, .L733
	l8ui	a8, a3, 5
	l32r	a14, .LC479
	beqi	a8, 3, .L734
	l32r	a14, .LC477
	bnei	a8, 6, .L734
	l32r	a14, .LC481
.L734:
	l32r	a13, .LC495
	l32r	a11, .LC486
	movi	a12, 0x440
	add.n	a12, a7, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	movi.n	a4, 0
	addmi	a5, a7, 0x400
	bnez.n	a10, .L735
	j	.L742
.L740:
	l16ui	a10, a5, 8
	add.n	a10, a4, a10
	extui	a10, a10, 0, 16
	call8	_ZN14MotorControlRS6ESS_RS12findRegisterEt
	l32r	a14, .LC474
	beqz.n	a10, .L736
	beqz.n	a4, .L737
	l32r	a14, .LC475
.L737:
	l32i	a15, a10, 16
	l32r	a13, .LC496
	l32r	a11, .LC486
	movi	a12, 0x440
	add.n	a12, a7, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L796
.L739:
	addi.n	a4, a4, 1
	j	.L735
.L736:
	beqz.n	a4, .L738
	l32r	a14, .LC475
.L738:
	movi	a12, 0x440
	l32r	a13, .LC498
	l32r	a11, .LC486
	add.n	a12, a7, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L796:
	bnez.n	a10, .L739
	j	.L742
.L735:
	l16ui	a8, a5, 10
	bltu	a4, a8, .L740
	l32r	a13, .LC500
	j	.L795
.L723:
	l32r	a13, .LC502
.L795:
	movi	a12, 0x440
	l32r	a11, .LC486
	add.n	a12, a7, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L742
	movi	a12, 0x440
	l32r	a13, .LC503
	l32r	a11, .LC486
	add.n	a12, a7, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L742
	l8ui	a8, a2, 142
	bnez.n	a8, .L743
	movi.n	a7, 0x24
	addmi	a7, a7, 0x4100
	add.n	a7, a2, a7
	l32r	a12, .LC486
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe11renderHumanEPKcPcj
	beqz.n	a10, .L742
	mov.n	a10, a7
	call8	strlen
	l32i	a8, a2, 8
	mov.n	a12, a10
	mov.n	a11, a7
	j	.L798
.L743:
	addmi	a7, a7, 0x400
	l32i	a8, a2, 8
	l32i	a12, a7, 64
	mov.n	a11, a6
.L798:
	l32i	a10, a2, 0
	callx8	a8
	mov.n	a2, a10
.L717:
	retw.n
.LFE1047:
	.section	.gcc_except_table,"a",@progbits
.LLSDA1047:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1047-.LLSDACSB1047
.LLSDACSB1047:
.LLSDACSE1047:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console13reportTrafficERKN14MotorControlRS13TrafficRecordENS0_9DebugModeEPS4_, .-_ZN21MotorControlRSExample5Probe7Console13reportTrafficERKN14MotorControlRS13TrafficRecordENS0_9DebugModeEPS4_
	.literal_position
	.literal .LC505, 35380
	.literal .LC506, 35576
	.literal .LC507, 35196
	.literal .LC508, 35376
	.align	4
	.global	_ZNK21MotorControlRSExample5Probe7Console11outstandingEm
	.type	_ZNK21MotorControlRSExample5Probe7Console11outstandingEm, @function
_ZNK21MotorControlRSExample5Probe7Console11outstandingEm:
.LFB1051:
	entry	sp, 32
.LCFI38:
	l32r	a9, .LC505
	l32r	a10, .LC506
	mov.n	a8, a2
	add.n	a9, a2, a9
	add.n	a10, a2, a10
	j	.L800
.L803:
	l8ui	a2, a9, 0
	beqz.n	a2, .L801
	l32i	a11, a9, 8
	beq	a11, a3, .L802
.L801:
	addi	a9, a9, 28
.L800:
	bne	a9, a10, .L803
	l32r	a9, .LC507
	l32r	a10, .LC508
	add.n	a9, a8, a9
	add.n	a8, a8, a10
	j	.L804
.L805:
	l32i	a10, a9, 0
	beq	a10, a3, .L806
	addi.n	a9, a9, 12
.L804:
	bne	a9, a8, .L805
	movi.n	a2, 0
	j	.L802
.L806:
	movi.n	a2, 1
.L802:
	retw.n
.LFE1051:
	.size	_ZNK21MotorControlRSExample5Probe7Console11outstandingEm, .-_ZNK21MotorControlRSExample5Probe7Console11outstandingEm
	.literal_position
	.literal .LC509, 35196
	.literal .LC510, 35376
	.align	4
	.global	_ZNK21MotorControlRSExample5Probe7Console11humanResultEm
	.type	_ZNK21MotorControlRSExample5Probe7Console11humanResultEm, @function
_ZNK21MotorControlRSExample5Probe7Console11humanResultEm:
.LFB1052:
	entry	sp, 32
.LCFI39:
	l32r	a8, .LC509
	l32r	a9, .LC510
	add.n	a8, a2, a8
	add.n	a2, a2, a9
	j	.L811
.L814:
	l32i	a9, a8, 4
	bne	a9, a3, .L812
	l8ui	a2, a8, 9
	nsau	a2, a2
	srli	a2, a2, 5
	j	.L813
.L812:
	addi.n	a8, a8, 12
.L811:
	bne	a8, a2, .L814
	movi.n	a2, 0
.L813:
	retw.n
.LFE1052:
	.size	_ZNK21MotorControlRSExample5Probe7Console11humanResultEm, .-_ZNK21MotorControlRSExample5Probe7Console11humanResultEm
	.literal_position
	.literal .LC511, 35196
	.align	4
	.global	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	.type	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb, @function
_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb:
.LFB1053:
	entry	sp, 32
.LCFI40:
	extui	a4, a4, 0, 8
	mov.n	a10, a2
	extui	a3, a3, 0, 8
	movi.n	a2, 0xd
	movi.n	a9, 0xf
	bnez.n	a4, .L816
	movi.n	a2, 0
	movi.n	a9, 9
	beqz.n	a3, .L816
	movi.n	a2, 9
	movi.n	a9, 0xd
.L816:
	l32r	a11, .LC511
	j	.L817
.L819:
	extui	a8, a2, 0, 16
	addx2	a8, a8, a8
	addx4	a8, a8, a11
	add.n	a8, a10, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L815
	addi.n	a2, a2, 1
.L817:
	bltu	a2, a9, .L819
	movi.n	a2, 0xf
.L815:
	retw.n
.LFE1053:
	.size	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb, .-_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	.literal_position
	.literal .LC512, 35196
	.literal .LC514, 35205
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
	.type	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb, @function
_ZN21MotorControlRSExample5Probe7Console5trackEmmbb:
.LFB1054:
	entry	sp, 32
.LCFI41:
	mov.n	a10, a2
	extui	a12, a6, 0, 8
	extui	a11, a5, 0, 8
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	mov.n	a7, a2
	movi.n	a2, 0
	beq	a10, a8, .L827
	l32r	a8, .LC512
	addx2	a10, a10, a10
	addx4	a10, a10, a7
	add.n	a8, a10, a8
	s32i	a3, a8, 0
	movi	a8, 0x113
	slli	a8, a8, 7
	add.n	a8, a10, a8
	s32i	a4, a8, 0
	l32r	a8, .LC514
	movi.n	a2, 1
	add.n	a10, a10, a8
	l8ui	a8, a7, 141
	s8i	a8, a10, 0
.L827:
	retw.n
.LFE1054:
	.size	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb, .-_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
	.literal_position
	.literal .LC515, 35196
	.literal .LC516, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console7untrackEm
	.type	_ZN21MotorControlRSExample5Probe7Console7untrackEm, @function
_ZN21MotorControlRSExample5Probe7Console7untrackEm:
.LFB1055:
	entry	sp, 32
.LCFI42:
	l32r	a9, .LC516
	l32r	a8, .LC515
	add.n	a8, a2, a8
	add.n	a2, a2, a9
	movi.n	a9, 0
	j	.L830
.L832:
	l32i	a10, a8, 4
	bne	a10, a3, .L831
	s8i	a9, a8, 0
	s8i	a9, a8, 1
	s8i	a9, a8, 2
	s8i	a9, a8, 3
	s8i	a9, a8, 4
	s8i	a9, a8, 5
	s8i	a9, a8, 6
	s8i	a9, a8, 7
	s8i	a9, a8, 8
	s8i	a9, a8, 9
.L831:
	addi.n	a8, a8, 12
.L830:
	bne	a8, a2, .L832
	retw.n
.LFE1055:
	.size	_ZN21MotorControlRSExample5Probe7Console7untrackEm, .-_ZN21MotorControlRSExample5Probe7Console7untrackEm
	.literal_position
	.literal .LC517, 35380
	.literal .LC518, 35576
	.literal .LC519, 35352
	.literal .LC520, 35548
	.literal .LC521, 35388
	.literal .LC522, 35384
	.literal .LC523, 35402
	.literal .LC524, 35403
	.literal .LC526, 35400
	.literal .LC527, 35396
	.literal .LC528, 35401
	.literal .LC529, 35404
	.literal .LC530, 35571
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console15retainStopReplyEmPKcNS0_6ActionEhmbmb
	.type	_ZN21MotorControlRSExample5Probe7Console15retainStopReplyEmPKcNS0_6ActionEhmbmb, @function
_ZN21MotorControlRSExample5Probe7Console15retainStopReplyEmPKcNS0_6ActionEhmbmb:
.LFB1059:
	entry	sp, 64
.LCFI43:
	extui	a9, a6, 0, 8
	l32r	a6, .LC517
	l8ui	a13, sp, 64
	l8ui	a14, sp, 72
	extui	a5, a5, 0, 8
	add.n	a10, a2, a6
	movi.n	a8, 0
	movi.n	a11, 7
	j	.L834
.L836:
	addi.n	a8, a8, 1
	addi	a10, a10, 28
	addi.n	a11, a11, -1
	bnez.n	a11, .L834
	j	.L852
.L834:
	l8ui	a12, a10, 0
	bnez.n	a12, .L836
	j	.L837
.L839:
	addi	a10, a10, -28
	addi.n	a11, a11, -1
	bnez.n	a11, .L844
	j	.L838
.L844:
	l8ui	a15, a10, 0
	mov.n	a12, a8
	addi.n	a8, a8, -1
	beqz.n	a15, .L839
	mov.n	a8, a12
.L838:
	l32r	a10, .LC518
	add.n	a10, a2, a10
	l32i	a11, a10, 0
	l32i	a12, a10, 4
	addi.n	a11, a11, 1
	bnez.n	a11, .L840
	addi.n	a12, a12, 1
.L840:
	s32i	a11, a10, 0
	s32i	a12, a10, 4
	beqz.n	a8, .L833
	l32r	a10, .LC519
	extui	a8, a8, 0, 16
	subx8	a8, a8, a8
	addx4	a10, a8, a10
	l32r	a8, .LC520
	add.n	a10, a2, a10
	add.n	a8, a2, a8
	j	.L842
.L843:
	addi	a11, a10, 28
	movi.n	a12, 0x19
	s32i	a14, sp, 16
	s32i	a13, sp, 12
	s32i	a9, sp, 8
	s32i	a8, sp, 4
	s32i	a11, sp, 0
	call8	memcpy
	l32i	a10, sp, 0
	l32i	a14, sp, 16
	l32i	a13, sp, 12
	l32i	a9, sp, 8
	l32i	a8, sp, 4
.L842:
	bne	a10, a8, .L843
	movi.n	a8, 6
.L837:
	subx8	a8, a8, a8
	addx4	a8, a8, a2
	add.n	a6, a8, a6
	movi.n	a10, 1
	s8i	a10, a6, 0
	l32r	a10, .LC521
	add.n	a10, a8, a10
	s32i	a3, a10, 0
	l32r	a10, .LC522
	add.n	a10, a8, a10
	s32i	a4, a10, 0
	l32r	a10, .LC523
	add.n	a10, a8, a10
	s8i	a9, a10, 0
	l32r	a9, .LC524
	l32i	a10, sp, 68
	add.n	a9, a8, a9
	s8i	a5, a9, 0
	movi	a9, 0x229
	slli	a9, a9, 6
	add.n	a9, a8, a9
	s32i	a7, a9, 0
	l32r	a9, .LC526
	add.n	a9, a8, a9
	s8i	a13, a9, 0
	l32r	a9, .LC527
	add.n	a9, a8, a9
	s32i	a10, a9, 0
	l32r	a9, .LC528
	add.n	a9, a8, a9
	s8i	a14, a9, 0
	l32r	a9, .LC529
	add.n	a8, a8, a9
	l8ui	a9, a2, 141
	s8i	a9, a8, 0
	j	.L833
.L852:
	l32r	a10, .LC530
	movi.n	a11, 7
	add.n	a10, a2, a10
	j	.L844
.L833:
	retw.n
.LFE1059:
	.size	_ZN21MotorControlRSExample5Probe7Console15retainStopReplyEmPKcNS0_6ActionEhmbmb, .-_ZN21MotorControlRSExample5Probe7Console15retainStopReplyEmPKcNS0_6ActionEhmbmb
	.section	.rodata.str1.1
.LC533:
	.string	",\"read_kind\":\"identity\""
.LC536:
	.string	",\"read_kind\":\"config\""
.LC538:
	.string	",\"read_kind\":\"velocity_parameters\""
.LC540:
	.string	",\"read_kind\":\"state\""
.LC542:
	.string	",\"read_kind\":\"homing_parameters\""
.LC544:
	.string	"done"
.LC546:
	.string	"read-identity"
.LC548:
	.string	"read-config"
.LC550:
	.string	"read-state"
.LC552:
	.string	"velocity-read"
.LC554:
	.string	"home-read"
.LC556:
	.string	"position-interrupt"
.LC558:
	.string	"home-auxiliary"
.LC560:
	.string	"motion-profile-start-speed"
.LC562:
	.string	"enable"
.LC564:
	.string	"motor-release"
.LC566:
	.string	"alarm-clear"
.LC568:
	.string	"position-clear"
.LC570:
	.string	"stop"
.LC572:
	.string	"move-"
.LC574:
	.string	"velocity"
.LC576:
	.string	"home"
.LC578:
	.string	"driver"
.LC580:
	.string	"io"
.LC582:
	.string	"segment"
.LC584:
	.string	"control"
.LC586:
	.string	"tuning"
.LC588:
	.string	"group-set"
.LC590:
	.string	"group-move"
.LC592:
	.string	"group-stop"
.LC594:
	.string	"group-read-state"
.LC596:
	.string	"probe"
.LC598:
	.string	"capture-read"
.LC600:
	.string	"recover"
.LC602:
	.string	"broadcast"
.LC604:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"ok\":%s,\"result\":\"%s\",\"address\":%u,\"operation_id\":%lu%s}"
.LC607:
	.string	",\"replaced_operation_id\":%lu,\"stop_escalation\":%s}"
	.text
	.literal_position
	.literal .LC531, .LC363
	.literal .LC532, .LC361
	.literal .LC534, .LC533
	.literal .LC535, .LC318
	.literal .LC537, .LC536
	.literal .LC539, .LC538
	.literal .LC541, .LC540
	.literal .LC543, .LC542
	.literal .LC545, .LC544
	.literal .LC547, .LC546
	.literal .LC549, .LC548
	.literal .LC551, .LC550
	.literal .LC553, .LC552
	.literal .LC555, .LC554
	.literal .LC557, .LC556
	.literal .LC559, .LC558
	.literal .LC561, .LC560
	.literal .LC563, .LC562
	.literal .LC565, .LC564
	.literal .LC567, .LC566
	.literal .LC569, .LC568
	.literal .LC571, .LC570
	.literal .LC573, .LC572
	.literal .LC575, .LC574
	.literal .LC577, .LC576
	.literal .LC579, .LC578
	.literal .LC581, .LC580
	.literal .LC583, .LC582
	.literal .LC585, .LC584
	.literal .LC587, .LC586
	.literal .LC589, .LC588
	.literal .LC591, .LC590
	.literal .LC593, .LC592
	.literal .LC595, .LC594
	.literal .LC597, .LC596
	.literal .LC599, .LC598
	.literal .LC601, .LC600
	.literal .LC603, .LC602
	.literal .LC605, .LC604
	.literal .LC606, 16384
	.literal .LC608, .LC607
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	.type	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb, @function
_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb:
.LFB1060:
	entry	sp, 96
.LCFI44:
	extui	a8, a6, 0, 8
	s32i	a8, sp, 44
	l8ui	a8, sp, 96
	l32r	a11, .LC547
	s32i	a8, sp, 52
	l8ui	a8, sp, 104
	mov.n	a10, a4
	s32i	a7, sp, 48
	s32i	a2, sp, 36
	s32i	a3, sp, 40
	s32i	a8, sp, 56
	call8	strcmp
	s32i	a10, sp, 32
	extui	a5, a5, 0, 8
	movi.n	a6, 1
	beqz.n	a10, .L856
	l32r	a11, .LC549
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L856
	l32r	a11, .LC551
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L856
	l32r	a11, .LC553
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L856
	l32r	a11, .LC555
	mov.n	a10, a4
	call8	strcmp
	nsau	a6, a10
	srli	a6, a6, 5
.L856:
	l32r	a11, .LC557
	mov.n	a10, a4
	call8	strcmp
	movi.n	a3, 1
	beqz.n	a10, .L857
	l32r	a11, .LC559
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC561
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC563
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC565
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC567
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC569
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC571
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC573
	movi.n	a12, 5
	mov.n	a10, a4
	call8	strncmp
	beqz.n	a10, .L857
	l32r	a11, .LC575
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC577
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC579
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC581
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC583
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC585
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC587
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC589
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC591
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC593
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L857
	l32r	a11, .LC595
	mov.n	a10, a4
	call8	strcmp
	nsau	a3, a10
	srli	a3, a3, 5
.L857:
	l32i	a8, sp, 36
	movi	a2, 0x124
	add.n	a2, a8, a2
	bnez.n	a5, .L887
	l32r	a7, .LC532
	bnez.n	a6, .L858
	bnez.n	a3, .L858
	l32r	a11, .LC597
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L858
	l32r	a11, .LC599
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L858
	l32r	a11, .LC601
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L858
	l32r	a11, .LC603
	mov.n	a10, a4
	call8	strcmp
	bnez.n	a10, .L892
	j	.L858
.L887:
	l32r	a7, .LC531
.L858:
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	l32r	a8, .LC535
	mov.n	a3, a10
	beqz.n	a6, .L859
	l32i	a9, sp, 32
	l32r	a8, .LC534
	beqz.n	a9, .L859
	l32r	a11, .LC549
	mov.n	a10, a4
	call8	strcmp
	l32r	a8, .LC537
	beqz.n	a10, .L859
	l32r	a11, .LC553
	mov.n	a10, a4
	call8	strcmp
	l32r	a8, .LC539
	beqz.n	a10, .L859
	l32r	a11, .LC555
	mov.n	a10, a4
	call8	strcmp
	l32r	a8, .LC541
	bnez.n	a10, .L859
	l32r	a8, .LC543
	j	.L859
.L892:
	l32r	a3, .LC545
	l32r	a8, .LC535
.L859:
	s32i	a8, sp, 12
	l32i	a8, sp, 48
	l32i	a13, sp, 40
	s32i	a8, sp, 8
	l32i	a8, sp, 44
	l32r	a12, .LC605
	l32r	a11, .LC606
	s32i	a8, sp, 4
	s32i	a3, sp, 0
	mov.n	a15, a7
	mov.n	a14, a4
	mov.n	a10, a2
	call8	snprintf
	bnez.n	a5, .L860
	l32i	a8, sp, 52
	beqz.n	a8, .L860
	mov.n	a10, a2
	call8	strlen
	addi.n	a10, a10, -1
	l32i	a8, sp, 56
	s32i	a10, sp, 16
	l32r	a15, .LC531
	beqz.n	a8, .L861
	l32r	a15, .LC532
.L861:
	l32i	a14, sp, 100
	l32r	a13, .LC608
	l32r	a11, .LC606
	addi	a12, sp, 16
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L855
.L860:
	l32i	a10, sp, 36
	movi.n	a12, 0
	movi.n	a11, 0
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L855:
	retw.n
.LFE1060:
	.size	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb, .-_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	.literal_position
	.literal .LC609, 35584
	.literal .LC611, 35376
	.literal .LC612, 35380
	.literal .LC613, 35384
	.literal .LC614, 35388
	.literal .LC616, 35396
	.literal .LC617, 35400
	.literal .LC618, 35401
	.literal .LC619, 35402
	.literal .LC620, 35403
	.literal .LC621, 35404
	.literal .LC622, 35548
	.literal .LC623, .LC570
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console13serviceOutputEv
	.type	_ZN21MotorControlRSExample5Probe7Console13serviceOutputEv, @function
_ZN21MotorControlRSExample5Probe7Console13serviceOutputEv:
.LFB1057:
	entry	sp, 112
.LCFI45:
	l32r	a7, .LC609
	mov.n	a4, a2
	add.n	a7, a2, a7
	l8ui	a9, a7, 0
	beqz.n	a9, .L929
	l32i	a5, a2, 8
	bnez.n	a5, .L930
.L932:
	movi.n	a2, 0
	j	.L931
.L930:
	movi.n	a6, 0x24
	addmi	a6, a6, 0x4100
	add.n	a6, a2, a6
	mov.n	a10, a6
	call8	strlen
	mov.n	a12, a10
	l32i	a10, a2, 0
	mov.n	a11, a6
	callx8	a5
	beqz.n	a10, .L932
	movi.n	a9, 0
	s8i	a9, a7, 0
	l32r	a7, .LC611
	add.n	a9, a2, a7
	l32i	a11, a9, 0
	beqz.n	a11, .L933
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console7untrackEm
.L933:
	add.n	a7, a4, a7
	movi.n	a9, 0
	s32i	a9, a7, 0
.L929:
	l32r	a10, .LC612
	movi.n	a2, 1
	add.n	a10, a4, a10
	l8ui	a9, a10, 0
	beqz.n	a9, .L931
	l32r	a9, .LC613
	add.n	a9, a4, a9
	l32i	a8, a9, 0
	l32r	a9, .LC614
	s32i	a8, sp, 64
	add.n	a9, a4, a9
	l32i	a8, a9, 0
	movi	a9, 0x229
	slli	a9, a9, 6
	add.n	a9, a4, a9
	s32i	a8, sp, 52
	l32i	a8, a9, 0
	l32r	a9, .LC616
	s32i	a8, sp, 56
	add.n	a9, a4, a9
	l32i	a7, a9, 0
	l32r	a9, .LC617
	add.n	a9, a4, a9
	l8ui	a5, a9, 0
	l32r	a9, .LC618
	add.n	a9, a4, a9
	l8ui	a3, a9, 0
	l32r	a9, .LC619
	add.n	a9, a4, a9
	l8ui	a8, a9, 0
	l32r	a9, .LC620
	s32i	a8, sp, 60
	add.n	a9, a4, a9
	l8ui	a8, a9, 0
	l32r	a9, .LC621
	s32i	a8, sp, 48
	add.n	a9, a4, a9
	l8ui	a2, a9, 0
	l32r	a9, .LC622
	add.n	a6, a4, a9
.L934:
	addi	a11, a10, 28
	movi.n	a12, 0x19
	s32i	a11, sp, 68
	call8	memcpy
	l32i	a10, sp, 68
	bne	a10, a6, .L934
	movi.n	a12, 0x1c
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a9, .LC623
	l32r	a10, .LC622
	s32i	a9, sp, 20
	movi.n	a12, 0x19
	movi.n	a9, 4
	addi	a11, sp, 16
	add.n	a10, a4, a10
	s8i	a9, sp, 39
	call8	memcpy
	l32i	a15, sp, 56
	s8i	a2, a4, 141
	l32i	a14, sp, 60
	l32i	a13, sp, 48
	l32i	a12, sp, 64
	l32i	a11, sp, 52
	s32i	a3, sp, 8
	s32i	a7, sp, 4
	s32i	a5, sp, 0
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	l32r	a9, .LC609
	add.n	a8, a4, a9
	l8ui	a2, a8, 0
	movi.n	a8, 1
	xor	a2, a2, a8
	extui	a2, a2, 0, 8
.L931:
	retw.n
.LFE1057:
	.section	.gcc_except_table
.LLSDA1057:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1057-.LLSDACSB1057
.LLSDACSB1057:
.LLSDACSE1057:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console13serviceOutputEv, .-_ZN21MotorControlRSExample5Probe7Console13serviceOutputEv
	.section	.rodata.str1.1
.LC628:
	.string	"ERROR: response formatting failed. Inspect @ID result %lu for JSON evidence."
.LC630:
	.string	"ERROR: response formatting failed. Inspect retained results with @ID result N; do not repeat writes."
	.text
	.literal_position
	.literal .LC625, 35576
	.literal .LC627, 16384
	.literal .LC629, .LC628
	.literal .LC631, .LC630
	.literal .LC632, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	.type	_ZN21MotorControlRSExample5Probe7Console4emitEmb, @function
_ZN21MotorControlRSExample5Probe7Console4emitEmb:
.LFB1056:
	entry	sp, 32
.LCFI46:
	movi	a6, 0x8b
	slli	a6, a6, 8
	add.n	a8, a2, a6
	l8ui	a9, a8, 0
	extui	a4, a4, 0, 8
	beqz.n	a9, .L949
	l32r	a8, .LC625
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L950
	addi.n	a10, a10, 1
.L950:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L948
.L949:
	l8ui	a10, a2, 141
	movi.n	a8, 1
	movi.n	a7, 0x24
	moveqz	a8, a9, a10
	addmi	a7, a7, 0x4100
	bnez.n	a8, .L952
	bnez.n	a4, .L952
	add.n	a7, a2, a7
	movi	a10, 0x124
	l32r	a12, .LC627
	mov.n	a11, a7
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe11renderHumanEPKcPcj
	bnez.n	a10, .L953
	beqz.n	a3, .L954
	l32r	a12, .LC629
	l32r	a11, .LC627
	mov.n	a13, a3
	mov.n	a10, a7
	call8	snprintf
	j	.L953
.L954:
	l32r	a11, .LC631
	mov.n	a10, a7
	call8	strcpy
	j	.L953
.L952:
	movi	a5, 0x124
	add.n	a5, a2, a5
	mov.n	a10, a5
	call8	strlen
	addi.n	a12, a10, 1
	mov.n	a11, a5
	add.n	a10, a2, a7
	call8	memcpy
.L953:
	movi.n	a8, 1
	add.n	a6, a2, a6
	s8i	a8, a6, 0
	l32r	a8, .LC632
	mov.n	a10, a2
	add.n	a8, a2, a8
	s32i	a3, a8, 0
	call8	_ZN21MotorControlRSExample5Probe7Console13serviceOutputEv
.L948:
	retw.n
.LFE1056:
	.size	_ZN21MotorControlRSExample5Probe7Console4emitEmb, .-_ZN21MotorControlRSExample5Probe7Console4emitEmb
	.section	.rodata.str1.1
.LC635:
	.string	"1.0.0"
.LC637:
	.string	"MotorControl-RS %s\nType help for commands; help COMMAND shows usage.\nPlain commands use human output. Prefix @ID for JSON, for example @1 status."
	.text
	.literal_position
	.literal .LC634, 35380
	.literal .LC636, .LC635
	.literal .LC638, .LC637
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console7welcomeEv
	.type	_ZN21MotorControlRSExample5Probe7Console7welcomeEv, @function
_ZN21MotorControlRSExample5Probe7Console7welcomeEv:
.LFB1046:
	entry	sp, 32
.LCFI47:
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	mov.n	a7, a2
	l8ui	a2, a8, 0
	bnez.n	a2, .L957
	l32r	a8, .LC634
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L956
	l32r	a13, .LC636
	l32r	a12, .LC638
	movi.n	a11, 1
	movi	a10, 0x124
	l8ui	a6, a7, 141
	slli	a11, a11, 14
	s8i	a2, a7, 141
	add.n	a10, a7, a10
	call8	snprintf
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	movi.n	a2, 1
	s8i	a6, a7, 141
	j	.L956
.L957:
	movi.n	a2, 0
.L956:
	retw.n
.LFE1046:
	.size	_ZN21MotorControlRSExample5Probe7Console7welcomeEv, .-_ZN21MotorControlRSExample5Probe7Console7welcomeEv
	.section	.rodata.str1.1
.LC641:
	.string	"\nUsage: "
.LC643:
	.string	"\nType help for available commands."
.LC645:
	.string	"\nHelp: help "
.LC647:
	.string	"ERROR: %s: "
.LC651:
	.string	".%s%s%s%s"
.LC653:
	.string	"ERROR: command failed. Type help for usage."
.LC655:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"ok\":false,\"result\":\"%s\"}"
	.text
	.literal_position
	.literal .LC640, .LC318
	.literal .LC642, .LC641
	.literal .LC644, .LC643
	.literal .LC646, .LC645
	.literal .LC648, .LC647
	.literal .LC649, 16384
	.literal .LC652, .LC651
	.literal .LC654, .LC653
	.literal .LC656, .LC655
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	.type	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_, @function
_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_:
.LFB1058:
	entry	sp, 64
.LCFI48:
	l8ui	a8, a2, 141
	mov.n	a13, a3
	mov.n	a14, a4
	bnez.n	a8, .L959
	movi	a7, 0x124
	add.n	a7, a2, a7
	l32r	a13, .LC648
	l32r	a11, .LC649
	addi	a12, sp, 16
	mov.n	a10, a7
	s32i	a8, sp, 16
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L961
	l32i	a9, sp, 16
	movi.n	a12, -1
	mov.n	a8, a9
	movi.n	a15, 0
	extui	a12, a12, 18, 14
	movi.n	a13, 0x5f
	movi	a14, 0x124
	j	.L962
.L964:
	addi.n	a4, a8, 1
	bltu	a12, a4, .L961
	bne	a11, a13, .L963
	movi.n	a11, 0x20
.L963:
	add.n	a8, a8, a14
	add.n	a8, a2, a8
	s8i	a11, a8, 0
	mov.n	a15, a10
	mov.n	a8, a4
.L962:
	sub	a11, a8, a9
	add.n	a11, a5, a11
	l8ui	a11, a11, 0
	bnez.n	a11, .L964
	beqz.n	a15, .L965
	s32i	a8, sp, 16
	mov.n	a9, a8
.L965:
	add.n	a9, a7, a9
	movi.n	a8, 0
	s8i	a8, a9, 0
	l32i	a15, a2, 144
	l32r	a14, .LC642
	bnez.n	a15, .L966
	l32r	a14, .LC640
	mov.n	a15, a14
.L966:
	l32i	a8, a2, 148
	l32r	a9, .LC646
	bnez.n	a8, .L967
	l32r	a9, .LC644
	l32r	a8, .LC640
.L967:
	l32r	a13, .LC652
	l32r	a11, .LC649
	s32i	a8, sp, 4
	s32i	a9, sp, 0
	addi	a12, sp, 16
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L968
.L961:
	l32r	a11, .LC654
	mov.n	a10, a7
	call8	strcpy
.L968:
	movi.n	a12, 1
	j	.L976
.L959:
	l32r	a12, .LC656
	l32r	a11, .LC649
	movi	a10, 0x124
	mov.n	a15, a5
	add.n	a10, a2, a10
	call8	snprintf
	movi.n	a12, 0
.L976:
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	retw.n
.LFE1058:
	.size	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_, .-_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm:
.LFB1062:
	entry	sp, 32
.LCFI49:
	bnez.n	a3, .L978
	movi	a8, 0xe1
	s32i	a3, a2, 160
	movi.n	a9, 0
	slli	a8, a8, 9
	j	.L979
.L978:
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	movi.n	a8, 0
	moveqz	a4, a8, a10
	s32i	a4, a2, 160
	l32i	a8, a3, 0
	l8ui	a9, a3, 4
.L979:
	extui	a10, a8, 8, 8
	s8i	a8, a2, 152
	s8i	a10, a2, 153
	extui	a10, a8, 16, 8
	extui	a8, a8, 24, 8
	s8i	a10, a2, 154
	s8i	a8, a2, 155
	s8i	a9, a2, 156
	retw.n
.LFE1062:
	.size	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC658:
	.string	"format"
.LC660:
	.string	"address"
.LC662:
	.string	"baud"
	.text
	.literal_position
	.literal .LC659, .LC658
	.literal .LC661, .LC660
	.literal .LC663, .LC662
	.align	4
	.global	_ZN21MotorControlRSExample5Probe18communicationFieldEN14MotorControlRS6ESS_RS18CommunicationFieldE
	.type	_ZN21MotorControlRSExample5Probe18communicationFieldEN14MotorControlRS6ESS_RS18CommunicationFieldE, @function
_ZN21MotorControlRSExample5Probe18communicationFieldEN14MotorControlRS6ESS_RS18CommunicationFieldE:
.LFB1063:
	entry	sp, 32
.LCFI50:
	extui	a8, a2, 0, 8
	l32r	a2, .LC661
	beqz.n	a8, .L982
	l32r	a2, .LC659
	bnei	a8, 1, .L982
	l32r	a2, .LC663
.L982:
	retw.n
.LFE1063:
	.size	_ZN21MotorControlRSExample5Probe18communicationFieldEN14MotorControlRS6ESS_RS18CommunicationFieldE, .-_ZN21MotorControlRSExample5Probe18communicationFieldEN14MotorControlRS6ESS_RS18CommunicationFieldE
	.section	.rodata.str1.1
.LC666:
	.string	"{\"target\":%lu,\"address\":%u,\"generation\":%lu,\"baud\":%lu,\"data_bits\":%u,\"parity\":%u,\"stop_bits\":%u,\"serial_known\":%s}"
	.text
	.literal_position
	.literal .LC664, .LC361
	.literal .LC665, .LC363
	.literal .LC667, .LC666
	.align	4
	.global	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE
	.type	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE, @function
_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE:
.LFB1064:
	entry	sp, 64
.LCFI51:
	l32i	a14, a5, 0
	l8ui	a15, a5, 4
	l32i	a9, a5, 8
	l32i	a13, a6, 4
	l8ui	a5, a6, 8
	l8ui	a7, a6, 9
	mov.n	a12, a4
	l8ui	a4, a6, 10
	l8ui	a6, a6, 0
	l32r	a8, .LC665
	mov.n	a10, a2
	mov.n	a11, a3
	beqz.n	a6, .L987
	l32r	a8, .LC664
.L987:
	s32i	a13, sp, 4
	l32r	a13, .LC667
	s32i	a8, sp, 20
	s32i	a4, sp, 16
	s32i	a7, sp, 12
	s32i	a5, sp, 8
	s32i	a9, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
	retw.n
.LFE1064:
	.size	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE, .-_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE
	.section	.rodata.str1.1
.LC670:
	.string	"{\"endpoint\":"
.LC672:
	.string	",\"eligible_us\":%llu,\"deadline_us\":%llu,\"readback_known\":%s,\"readback\":%u,\"wire\":"
	.text
	.literal_position
	.literal .LC668, .LC361
	.literal .LC669, .LC363
	.literal .LC671, .LC670
	.literal .LC673, .LC672
	.literal .LC674, .LC430
	.align	4
	.global	_ZN21MotorControlRSExample5Probe21communicationEvidenceEPcjRjRKN14MotorControlRS6ESS_RS21CommunicationEvidenceE
	.type	_ZN21MotorControlRSExample5Probe21communicationEvidenceEPcjRjRKN14MotorControlRS6ESS_RS21CommunicationEvidenceE, @function
_ZN21MotorControlRSExample5Probe21communicationEvidenceEPcjRjRKN14MotorControlRS6ESS_RS21CommunicationEvidenceE:
.LFB1065:
	entry	sp, 48
.LCFI52:
	l32r	a13, .LC671
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L990
.L992:
	movi.n	a2, 0
	j	.L991
.L990:
	addi.n	a14, a5, 12
	mov.n	a13, a5
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE
	beqz.n	a10, .L992
	l8ui	a9, a5, 130
	l32i	a14, a5, 24
	l32i	a15, a5, 28
	l32i	a10, a5, 32
	l32i	a11, a5, 36
	l32r	a8, .LC669
	beqz.n	a9, .L993
	l32r	a8, .LC668
.L993:
	l16ui	a9, a5, 128
	l32r	a13, .LC673
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a9, sp, 12
	s32i	a8, sp, 8
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L992
	addi	a13, a5, 40
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L992
	l32r	a13, .LC674
	mov.n	a10, a2
	mov.n	a12, a4
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L991:
	retw.n
.LFE1065:
	.size	_ZN21MotorControlRSExample5Probe21communicationEvidenceEPcjRjRKN14MotorControlRS6ESS_RS21CommunicationEvidenceE, .-_ZN21MotorControlRSExample5Probe21communicationEvidenceEPcjRjRKN14MotorControlRS6ESS_RS21CommunicationEvidenceE
	.section	.rodata.str1.1
.LC677:
	.string	"required"
.LC679:
	.string	"unresolved"
.LC682:
	.ascii	"{\"operation_id\":%lu,\"field\":\"%s\",\"register\":%u,\"pre"
	.ascii	"vious\":%u,\"requested\":%u,\"readback\":%u,\"readback_kn"
	.string	"own\":%s,\"observed_active_known\":%s,\"activation_unknown\":%s,\"effects\":%s,\"uncertain\":%s,\"execution\":%u,\"state\":%u,\"outcome\":%u,\"write_outcome\":%u,\"step\":%u,\"confirmations\":%u,\"save\":\"%s\",\"restart\":\"%s\",\"status\":\"%s\",\"detail\":%ld,\"deadline_us\":%llu,\"before\":"
.LC684:
	.string	",\"requested_endpoint\":"
.LC686:
	.string	",\"observed_active\":"
.LC688:
	.string	",\"write_evidence\":"
.LC690:
	.string	",\"confirmation_evidence\":["
	.text
	.literal_position
	.literal .LC675, .LC361
	.literal .LC676, .LC363
	.literal .LC678, .LC677
	.literal .LC680, .LC679
	.literal .LC681, .LC422
	.literal .LC683, .LC682
	.literal .LC685, .LC684
	.literal .LC687, .LC686
	.literal .LC689, .LC688
	.literal .LC691, .LC690
	.literal .LC692, .LC386
	.literal .LC693, .LC499
	.align	4
	.global	_ZN21MotorControlRSExample5Probe20communicationContextEPcjRjPKN14MotorControlRS6ESS_RS20CommunicationContextE
	.type	_ZN21MotorControlRSExample5Probe20communicationContextEPcjRjPKN14MotorControlRS6ESS_RS20CommunicationContextE, @function
_ZN21MotorControlRSExample5Probe20communicationContextEPcjRjPKN14MotorControlRS6ESS_RS20CommunicationContextE:
.LFB1066:
	entry	sp, 208
.LCFI53:
	l32r	a13, .LC681
	beqz.n	a5, .L1057
.L1005:
	l32i	a8, a5, 96
	l8ui	a10, a5, 100
	s32i	a8, sp, 96
	call8	_ZN21MotorControlRSExample5Probe18communicationFieldEN14MotorControlRS6ESS_RS18CommunicationFieldE
	l16ui	a8, a5, 112
	l32r	a7, .LC676
	s32i	a8, sp, 100
	l16ui	a8, a5, 114
	mov.n	a15, a10
	s32i	a8, sp, 104
	l16ui	a8, a5, 116
	s32i	a8, sp, 108
	l16ui	a8, a5, 118
	s32i	a8, sp, 112
	l8ui	a8, a5, 120
	beqz.n	a8, .L1007
	l32r	a7, .LC675
.L1007:
	l8ui	a8, a5, 121
	l32r	a6, .LC676
	beqz.n	a8, .L1008
	l32r	a6, .LC675
.L1008:
	l8ui	a9, a5, 124
	l32r	a8, .LC676
	beqz.n	a9, .L1009
	l32r	a8, .LC675
.L1009:
	l8ui	a10, a5, 122
	l32r	a9, .LC676
	beqz.n	a10, .L1010
	l32r	a9, .LC675
.L1010:
	l8ui	a10, a5, 123
	l32r	a11, .LC676
	beqz.n	a10, .L1011
	l32r	a11, .LC675
.L1011:
	l8ui	a10, a5, 111
	l8ui	a14, a5, 127
	s32i	a10, sp, 116
	l8ui	a10, a5, 108
	l32r	a12, .LC680
	s32i	a10, sp, 120
	l8ui	a10, a5, 109
	s32i	a10, sp, 124
	l8ui	a10, a5, 110
	s32i	a10, sp, 128
	l8ui	a10, a5, 128
	s32i	a10, sp, 132
	l8ui	a10, a5, 126
	bnez.n	a10, .L1012
	l32r	a12, .LC678
.L1012:
	l8ui	a10, a5, 125
	l32r	a13, .LC680
	bnez.n	a10, .L1013
	l32r	a13, .LC678
.L1013:
	addmi	a10, a5, 0x200
	l8ui	a10, a10, 64
	s32i	a11, sp, 160
	s32i	a9, sp, 156
	s32i	a8, sp, 152
	s32i	a13, sp, 148
	s32i	a12, sp, 144
	s32i	a14, sp, 140
	s32i	a15, sp, 136
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a5, 144
	l32i	a9, a5, 148
	s32i	a8, sp, 80
	s32i	a9, sp, 84
	l32i	a8, a5, 580
	l32i	a13, sp, 148
	s32i	a8, sp, 72
	l32i	a8, sp, 132
	l32i	a12, sp, 144
	s32i	a8, sp, 56
	l32i	a8, sp, 128
	l32i	a14, sp, 140
	s32i	a8, sp, 48
	l32i	a8, sp, 124
	l32i	a11, sp, 160
	s32i	a8, sp, 44
	l32i	a8, sp, 120
	l32i	a9, sp, 156
	s32i	a8, sp, 40
	l32i	a8, sp, 116
	s32i	a10, sp, 68
	s32i	a8, sp, 36
	l32i	a8, sp, 152
	s32i	a13, sp, 64
	s32i	a12, sp, 60
	s32i	a14, sp, 52
	s32i	a11, sp, 32
	s32i	a8, sp, 24
	s32i	a9, sp, 28
	s32i	a6, sp, 20
	s32i	a7, sp, 16
	l32i	a8, sp, 112
	l32i	a15, sp, 136
	s32i	a8, sp, 12
	l32i	a8, sp, 108
	l32i	a14, sp, 96
	s32i	a8, sp, 8
	l32i	a8, sp, 104
	l32r	a13, .LC683
	s32i	a8, sp, 4
	l32i	a8, sp, 100
	mov.n	a12, a4
	s32i	a8, sp, 0
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1014
.L1015:
	movi.n	a2, 0
	j	.L1006
.L1014:
	addi	a14, a5, 48
	mov.n	a13, a5
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE
	beqz.n	a10, .L1015
	l32r	a13, .LC685
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1015
	addi	a14, a5, 60
	addi.n	a13, a5, 12
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE
	beqz.n	a10, .L1015
	l32r	a13, .LC687
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1015
	addi	a14, a5, 84
	addi	a13, a5, 36
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE
	beqz.n	a10, .L1015
	l32r	a13, .LC689
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1015
	movi	a13, 0xa8
	add.n	a13, a5, a13
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe21communicationEvidenceEPcjRjRKN14MotorControlRS6ESS_RS21CommunicationEvidenceE
	beqz.n	a10, .L1015
	l32r	a13, .LC691
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1015
	movi	a6, 0x130
	add.n	a6, a5, a6
	movi.n	a7, 0
	j	.L1016
.L1020:
	bnez.n	a7, .L1017
.L1019:
	mov.n	a13, a6
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe21communicationEvidenceEPcjRjRKN14MotorControlRS6ESS_RS21CommunicationEvidenceE
	movi	a8, 0x88
	add.n	a6, a6, a8
	bnez.n	a10, .L1018
	j	.L1015
.L1017:
	l32r	a13, .LC692
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1019
	j	.L1015
.L1018:
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
.L1016:
	l8ui	a8, a5, 128
	bgeu	a7, a8, .L1029
	bnei	a7, 2, .L1020
.L1029:
	l32r	a13, .LC693
.L1057:
	mov.n	a10, a2
	mov.n	a12, a4
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1006:
	retw.n
.LFE1066:
	.size	_ZN21MotorControlRSExample5Probe20communicationContextEPcjRjPKN14MotorControlRS6ESS_RS20CommunicationContextE, .-_ZN21MotorControlRSExample5Probe20communicationContextEPcjRjPKN14MotorControlRS6ESS_RS20CommunicationContextE
	.section	.rodata.str1.1
.LC694:
	.string	"save"
.LC696:
	.string	"factory-restore"
	.text
	.literal_position
	.literal .LC695, .LC694
	.literal .LC697, .LC696
	.align	4
	.global	_ZN21MotorControlRSExample5Probe15persistenceKindEN14MotorControlRS6ESS_RS15PersistenceKindE
	.type	_ZN21MotorControlRSExample5Probe15persistenceKindEN14MotorControlRS6ESS_RS15PersistenceKindE, @function
_ZN21MotorControlRSExample5Probe15persistenceKindEN14MotorControlRS6ESS_RS15PersistenceKindE:
.LFB1067:
	entry	sp, 32
.LCFI54:
	extui	a8, a2, 0, 8
	l32r	a2, .LC697
	bnez.n	a8, .L1058
	l32r	a2, .LC695
.L1058:
	retw.n
.LFE1067:
	.size	_ZN21MotorControlRSExample5Probe15persistenceKindEN14MotorControlRS6ESS_RS15PersistenceKindE, .-_ZN21MotorControlRSExample5Probe15persistenceKindEN14MotorControlRS6ESS_RS15PersistenceKindE
	.section	.rodata.str1.1
.LC699:
	.string	" ,\"configuration_generation\":%lu,\"operation_ids\":[%lu,%lu,%lu],\"config_words\":[%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%u],\"identity_words\":[%u,%u,%u,%u],\"motion_words\":[%u,%u],\"provenance\":["
.LC701:
	.string	"[%u,%u,\"%s\",%llu,%llu,%llu,%llu]"
	.text
	.literal_position
	.literal .LC698, .LC670
	.literal .LC700, .LC699
	.literal .LC702, .LC701
	.literal .LC703, .LC386
	.literal .LC704, .LC499
	.align	4
	.global	_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm
	.type	_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm, @function
_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm:
.LFB1068:
	entry	sp, 224
.LCFI55:
	l32r	a13, .LC698
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1063
	l32i	a14, sp, 224
	mov.n	a13, a5
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe21communicationEndpointEPcjRjRKN14MotorControlRS10ReadTargetERKNS3_17ActiveSerialTupleE
	beqz.n	a10, .L1063
	l16ui	a8, a7, 24
	mov.n	a12, a4
	s32i	a8, sp, 88
	l16ui	a8, a7, 22
	mov.n	a11, a3
	s32i	a8, sp, 84
	l16ui	a8, a6, 22
	mov.n	a10, a2
	s32i	a8, sp, 80
	l16ui	a8, a6, 20
	s32i	a8, sp, 76
	l16ui	a8, a6, 18
	s32i	a8, sp, 72
	l16ui	a8, a6, 16
	s32i	a8, sp, 68
	l16ui	a8, a5, 44
	s32i	a8, sp, 64
	l16ui	a8, a5, 42
	s32i	a8, sp, 60
	l16ui	a8, a5, 40
	s32i	a8, sp, 56
	l16ui	a8, a5, 38
	s32i	a8, sp, 52
	l16ui	a8, a5, 36
	s32i	a8, sp, 48
	l16ui	a8, a5, 34
	s32i	a8, sp, 44
	l16ui	a8, a5, 32
	s32i	a8, sp, 40
	l16ui	a8, a5, 30
	s32i	a8, sp, 36
	l16ui	a8, a5, 28
	s32i	a8, sp, 32
	l16ui	a8, a5, 26
	s32i	a8, sp, 28
	l16ui	a8, a5, 24
	l32i	a14, sp, 228
	s32i	a8, sp, 24
	l16ui	a8, a5, 22
	l32r	a13, .LC700
	s32i	a8, sp, 20
	l16ui	a8, a5, 20
	s32i	a8, sp, 16
	l16ui	a8, a5, 18
	s32i	a8, sp, 12
	l16ui	a8, a5, 16
	s32i	a8, sp, 8
	l32i	a8, a7, 12
	s32i	a8, sp, 4
	l32i	a8, a6, 12
	s32i	a8, sp, 0
	l32i	a15, a5, 12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1063
	movi	a8, 0xe8
	add.n	a8, a5, a8
	s32i	a8, sp, 176
	addi	a8, a7, 80
	movi.n	a5, 0
	s32i	a8, sp, 180
.L1072:
	l32i	a7, sp, 176
	bltui	a5, 5, .L1066
.L1065:
	l32i	a7, sp, 180
	bnei	a5, 5, .L1066
	addi	a7, a6, 48
.L1066:
	l32i	a11, a7, 44
	movi.n	a13, 0x4b
	addi	a12, sp, 96
	addi.n	a10, a7, 5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	bnez.n	a5, .L1068
.L1071:
	l32i	a10, a7, 80
	l32i	a11, a7, 84
	l16ui	a15, a7, 2
	l16ui	a14, a7, 0
	s32i	a10, sp, 32
	s32i	a11, sp, 36
	l32i	a10, a7, 72
	l32i	a11, a7, 76
	s32i	a10, sp, 24
	s32i	a11, sp, 28
	l32i	a10, a7, 64
	l32i	a11, a7, 68
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	l32i	a10, a7, 56
	l32i	a11, a7, 60
	addi	a8, sp, 96
	l32r	a13, .LC702
	s32i	a10, sp, 8
	s32i	a11, sp, 12
	s32i	a8, sp, 0
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1069
	j	.L1063
.L1068:
	l32r	a13, .LC703
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1071
	j	.L1063
.L1069:
	addi.n	a8, a5, 1
	extui	a5, a8, 0, 8
	l32i	a8, sp, 176
	addi	a8, a8, 120
	s32i	a8, sp, 176
	bnei	a5, 7, .L1072
	j	.L1082
.L1063:
	movi.n	a2, 0
	j	.L1074
.L1082:
	l32r	a13, .LC704
	mov.n	a10, a2
	mov.n	a12, a4
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1074:
	retw.n
.LFE1068:
	.size	_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm, .-_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm
	.section	.rodata.str1.1
.LC711:
	.ascii	"{\"operation_id\":%lu,\"kind\":\"%s\",\"state\":%u,\"outcome"
	.ascii	"\":%u,\"execution\":%u,\"persistence\":%u,\"status\":\"%s\","
	.ascii	"\"detail\":%ld,\"register\":%u,\"value\":%u,\"effects\":%s,\""
	.ascii	"uncertain\":%s,\"snapshot_complete\":%s,\"verification_known"
	.ascii	"\":%s,\"live_readback_known\":%s,\"restart_required_for"
	.string	"_proof\":%s,\"manual_intervention_required\":%s,\"communication_changed\":%s,\"configuration_invalidated\":%s,\"matching_fields\":%u,\"verified_fields\":%u,\"verification_count\":%u,\"started_us\":%llu,\"deadline_us\":%llu,\"backup_source\":%lu,\"complete_backup\":%s,\"before\":"
.LC714:
	.string	",\"verification\":"
.LC719:
	.string	",\"restart_observed\":%s,\"restart_us\":%llu,\"restart_source\":%lu,\"fields\":["
.LC722:
	.string	"[%u,%u,%u,\"%s\",%s,%s]"
	.text
	.literal_position
	.literal .LC705, .LC694
	.literal .LC706, .LC696
	.literal .LC707, .LC361
	.literal .LC708, .LC363
	.literal .LC709, .LC679
	.literal .LC710, .LC422
	.literal .LC712, .LC711
	.literal .LC713, .LC688
	.literal .LC715, .LC714
	.literal .LC720, .LC719
	.literal .LC723, .LC722
	.literal .LC724, .LC386
	.literal .LC725, .LC499
	.align	4
	.global	_ZN21MotorControlRSExample5Probe18persistenceContextEPcjRjPKN14MotorControlRS6ESS_RS18PersistenceContextE
	.type	_ZN21MotorControlRSExample5Probe18persistenceContextEPcjRjPKN14MotorControlRS6ESS_RS18PersistenceContextE, @function
_ZN21MotorControlRSExample5Probe18persistenceContextEPcjRjPKN14MotorControlRS6ESS_RS18PersistenceContextE:
.LFB1069:
	entry	sp, 224
.LCFI56:
	l32r	a13, .LC710
	beqz.n	a5, .L1144
.L1084:
	l32i	a8, a5, 12
	l32r	a9, .LC706
	s32i	a8, sp, 128
	l8ui	a8, a5, 16
	s32i	a9, sp, 124
	bnez.n	a8, .L1086
	l32r	a8, .LC705
	s32i	a8, sp, 124
.L1086:
	l8ui	a8, a5, 17
	addmi	a7, a5, 0xb00
	s32i	a8, sp, 132
	l8ui	a8, a5, 18
	l8ui	a10, a7, 72
	s32i	a8, sp, 136
	l8ui	a8, a5, 19
	s32i	a8, sp, 140
	l8ui	a8, a5, 20
	s32i	a8, sp, 144
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a7, 76
	s32i	a10, sp, 148
	s32i	a8, sp, 152
	addmi	a8, a5, 0x900
	l16ui	a9, a8, 224
	l32r	a14, .LC708
	s32i	a9, sp, 156
	l16ui	a9, a8, 226
	s32i	a9, sp, 160
	l8ui	a9, a8, 211
	beqz.n	a9, .L1087
	l32r	a14, .LC707
.L1087:
	l8ui	a8, a8, 212
	l32r	a15, .LC708
	beqz.n	a8, .L1088
	l32r	a15, .LC707
.L1088:
	addmi	a8, a5, 0x900
	l8ui	a9, a8, 210
	l32r	a7, .LC708
	beqz.n	a9, .L1089
	l32r	a7, .LC707
.L1089:
	l8ui	a8, a8, 208
	l32r	a6, .LC708
	beqz.n	a8, .L1090
	l32r	a6, .LC707
.L1090:
	l32r	a10, .LC708
	addmi	a8, a5, 0x900
	l8ui	a9, a8, 209
	s32i	a10, sp, 112
	beqz.n	a9, .L1091
	l32r	a9, .LC707
	s32i	a9, sp, 112
.L1091:
	l8ui	a9, a8, 213
	l32r	a8, .LC708
	s32i	a8, sp, 116
	beqz.n	a9, .L1092
	l32r	a8, .LC707
	s32i	a8, sp, 116
.L1092:
	l32r	a8, .LC708
	addmi	a10, a5, 0x900
	l8ui	a11, a10, 214
	s32i	a8, sp, 120
	beqz.n	a11, .L1093
	l32r	a8, .LC707
	s32i	a8, sp, 120
.L1093:
	l8ui	a11, a10, 215
	l32r	a10, .LC708
	beqz.n	a11, .L1094
	l32r	a10, .LC707
.L1094:
	addmi	a12, a5, 0x900
	l8ui	a13, a12, 216
	l32r	a11, .LC708
	beqz.n	a13, .L1095
	l32r	a11, .LC707
.L1095:
	l16ui	a8, a12, 220
	l32i	a9, a12, 236
	s32i	a8, sp, 164
	l8ui	a8, a12, 222
	l16ui	a13, a12, 218
	s32i	a8, sp, 168
	l32i	a8, a12, 232
	s32i	a9, sp, 180
	s32i	a8, sp, 176
	l32i	a8, a12, 240
	l32i	a9, a12, 244
	addmi	a12, a5, 0x400
	s32i	a8, sp, 184
	l8ui	a8, a12, 227
	s32i	a9, sp, 188
	l32i	a9, a12, 232
	l32r	a12, .LC708
	beqz.n	a8, .L1096
	l32r	a12, .LC707
.L1096:
	movi	a8, 0xb8
	s32i	a12, sp, 100
	s32i	a9, sp, 96
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 92
	s32i	a8, sp, 88
	movi	a8, 0xb0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a13, sp, 68
	s32i	a8, sp, 80
	l32i	a8, sp, 168
	s32i	a11, sp, 64
	s32i	a8, sp, 76
	l32i	a8, sp, 164
	s32i	a10, sp, 60
	s32i	a8, sp, 72
	l32i	a8, sp, 120
	s32i	a15, sp, 36
	s32i	a8, sp, 56
	l32i	a8, sp, 116
	s32i	a14, sp, 32
	s32i	a8, sp, 52
	l32i	a8, sp, 112
	s32i	a9, sp, 84
	s32i	a8, sp, 48
	l32i	a8, sp, 160
	s32i	a6, sp, 44
	s32i	a8, sp, 28
	l32i	a8, sp, 156
	s32i	a7, sp, 40
	s32i	a8, sp, 24
	l32i	a8, sp, 152
	mov.n	a12, a4
	s32i	a8, sp, 20
	l32i	a8, sp, 148
	l32i	a15, sp, 124
	s32i	a8, sp, 16
	l32i	a8, sp, 144
	l32i	a14, sp, 128
	s32i	a8, sp, 12
	l32i	a8, sp, 140
	l32r	a13, .LC712
	s32i	a8, sp, 8
	l32i	a8, sp, 136
	mov.n	a11, a3
	s32i	a8, sp, 4
	l32i	a8, sp, 132
	mov.n	a10, a2
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1097
.L1098:
	movi.n	a2, 0
	j	.L1085
.L1097:
	addmi	a15, a5, 0x400
	l32i	a8, a15, 212
	movi	a14, 0x358
	s32i	a8, sp, 4
	movi	a8, 0x4c8
	add.n	a8, a5, a8
	s32i	a8, sp, 0
	add.n	a14, a5, a14
	addi	a13, a5, 24
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm
	beqz.n	a10, .L1098
	l32r	a13, .LC713
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1098
	addmi	a13, a5, 0xa00
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1098
	l32r	a13, .LC715
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1098
	addmi	a7, a5, 0x900
	l8ui	a8, a7, 208
	beqz.n	a8, .L1099
	l32i	a8, a7, 172
	movi	a15, 0xd8
	s32i	a8, sp, 4
	movi.n	a8, 0x4d
	slli	a8, a8, 5
	movi.n	a14, 0x30
	add.n	a8, a5, a8
	addmi	a15, a15, 0x800
	addmi	a14, a14, 0x800
	movi	a13, 0x4f0
	s32i	a8, sp, 0
	add.n	a15, a5, a15
	add.n	a14, a5, a14
	add.n	a13, a5, a13
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm
	j	.L1143
.L1102:
	l8ui	a8, a7, 184
	l32r	a14, .LC707
	bnez.n	a8, .L1101
	l32r	a14, .LC708
	j	.L1101
.L1099:
	l32r	a13, .LC710
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L1143:
	bnez.n	a10, .L1102
	j	.L1098
.L1101:
	l32i	a8, a7, 200
	l32r	a13, .LC720
	s32i	a8, sp, 8
	l32i	a8, a7, 192
	l32i	a9, a7, 196
	mov.n	a12, a4
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1098
	movi.n	a7, 0x58
	addmi	a7, a7, 0xa00
	add.n	a7, a5, a7
	l32r	a5, .LC709
	movi.n	a6, 0
.L1107:
	l32i	a8, a7, 8
	l8ui	a10, a7, 12
	l16ui	a14, a7, 0
	l16ui	a15, a7, 2
	l16ui	a11, a7, 4
	l32r	a9, .LC708
	moveqz	a8, a5, a8
	beqz.n	a10, .L1104
	l32r	a9, .LC707
.L1104:
	l8ui	a12, a7, 13
	l32r	a10, .LC708
	beqz.n	a12, .L1105
	l32r	a10, .LC707
.L1105:
	l32r	a13, .LC723
	s32i	a10, sp, 12
	s32i	a11, sp, 0
	s32i	a9, sp, 8
	s32i	a8, sp, 4
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1098
	addi.n	a6, a6, 1
	extui	a6, a6, 0, 8
	movi.n	a8, 0xf
	addi	a7, a7, 16
	beq	a6, a8, .L1106
	l32r	a13, .LC724
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1107
	j	.L1098
.L1106:
	l32r	a13, .LC725
.L1144:
	mov.n	a10, a2
	mov.n	a12, a4
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1085:
	retw.n
.LFE1069:
	.size	_ZN21MotorControlRSExample5Probe18persistenceContextEPcjRjPKN14MotorControlRS6ESS_RS18PersistenceContextE, .-_ZN21MotorControlRSExample5Probe18persistenceContextEPcjRjPKN14MotorControlRS6ESS_RS18PersistenceContextE
	.section	.rodata.str1.1
.LC729:
	.string	",\"host_serial\":{\"known\":%s,\"baud\":%lu,\"format\":\"%s\",\"generation\":%lu}}"
	.text
	.literal_position
	.literal .LC726, .LC361
	.literal .LC727, .LC363
	.literal .LC728, .LC107
	.literal .LC730, .LC729
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	.type	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj, @function
_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj:
.LFB1070:
	entry	sp, 48
.LCFI57:
	l32i	a9, a3, 0
	mov.n	a8, a2
	movi.n	a2, 0
	beqz.n	a9, .L1146
	addi.n	a9, a9, -1
	add.n	a10, a8, a9
	movi	a11, 0x124
	add.n	a10, a10, a11
	l8ui	a12, a10, 0
	movi	a10, 0x7d
	bne	a12, a10, .L1146
	l32i	a6, a8, 160
	s32i	a9, a3, 0
	add.n	a2, a8, a11
	beqz.n	a6, .L1150
	l8ui	a10, a8, 156
	l32i	a7, a8, 152
	call8	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE
	l32r	a14, .LC726
	j	.L1147
.L1150:
	l32r	a14, .LC727
	l32r	a10, .LC728
	movi.n	a7, 0
.L1147:
	l32r	a13, .LC730
	movi.n	a11, 1
	s32i	a10, sp, 0
	s32i	a6, sp, 4
	mov.n	a10, a2
	mov.n	a15, a7
	mov.n	a12, a3
	slli	a11, a11, 14
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1146:
	retw.n
.LFE1070:
	.size	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj, .-_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	.section	.rodata.str1.1
.LC734:
	.string	"[%u,%u,%u,\"%s\",%u,%s,%llu,%llu,%llu,%llu,%ld,%u,%s,\"%s\",%ld,%u]"
	.text
	.literal_position
	.literal .LC732, .LC361
	.literal .LC733, .LC363
	.literal .LC735, .LC734
	.align	4
	.global	_ZN21MotorControlRSExample5Probe17discoveryEvidenceEPcjRjRKN14MotorControlRS6ESS_RS19ReadStepObservationE
	.type	_ZN21MotorControlRSExample5Probe17discoveryEvidenceEPcjRjRKN14MotorControlRS6ESS_RS19ReadStepObservationE, @function
_ZN21MotorControlRSExample5Probe17discoveryEvidenceEPcjRjRKN14MotorControlRS6ESS_RS19ReadStepObservationE:
.LFB1071:
	entry	sp, 256
.LCFI58:
	l32i	a11, a5, 44
	s32i	a2, sp, 164
	movi.n	a8, 0x25
	movi.n	a2, 0
	bltu	a8, a11, .L1153
	movi.n	a13, 0x4b
	addi	a12, sp, 80
	addi.n	a10, a5, 5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l16ui	a8, a5, 0
	l16ui	a15, a5, 2
	s32i	a8, sp, 160
	l8ui	a8, a5, 52
	l8ui	a7, a5, 4
	l32i	a2, a5, 48
	l32r	a6, .LC733
	beqz.n	a8, .L1154
	l32r	a6, .LC732
.L1154:
	l32i	a8, a5, 56
	l32i	a9, a5, 60
	s32i	a8, sp, 168
	s32i	a9, sp, 172
	l32i	a8, a5, 64
	l32i	a9, a5, 68
	s32i	a8, sp, 176
	s32i	a9, sp, 180
	l32i	a8, a5, 72
	l32i	a9, a5, 76
	s32i	a8, sp, 184
	s32i	a9, sp, 188
	l32i	a8, a5, 80
	l32i	a9, a5, 84
	l8ui	a10, a5, 96
	s32i	a8, sp, 192
	s32i	a9, sp, 196
	l32i	a12, a5, 88
	l32i	a13, a5, 92
	l32r	a8, .LC733
	beqz.n	a10, .L1155
	l32r	a8, .LC732
.L1155:
	l8ui	a10, a5, 100
	s32i	a8, sp, 212
	s32i	a13, sp, 208
	s32i	a12, sp, 204
	s32i	a15, sp, 200
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l8ui	a14, a5, 112
	l32i	a8, sp, 212
	s32i	a14, sp, 68
	l32i	a14, a5, 104
	l32i	a13, sp, 208
	l32i	a12, sp, 204
	s32i	a8, sp, 56
	movi	a8, 0xc0
	s32i	a14, sp, 64
	s32i	a10, sp, 60
	s32i	a13, sp, 52
	s32i	a12, sp, 48
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 44
	s32i	a8, sp, 40
	movi	a8, 0xb8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 36
	s32i	a8, sp, 32
	movi	a8, 0xb0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 24
	movi	a8, 0xa8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 20
	s32i	a8, sp, 16
	addi	a8, sp, 80
	s32i	a2, sp, 8
	s32i	a8, sp, 4
	s32i	a6, sp, 12
	s32i	a7, sp, 0
	l32i	a15, sp, 200
	l32i	a14, sp, 160
	l32r	a13, .LC735
	l32i	a10, sp, 164
	mov.n	a12, a4
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1153:
	retw.n
.LFE1071:
	.size	_ZN21MotorControlRSExample5Probe17discoveryEvidenceEPcjRjRKN14MotorControlRS6ESS_RS19ReadStepObservationE, .-_ZN21MotorControlRSExample5Probe17discoveryEvidenceEPcjRjRKN14MotorControlRS6ESS_RS19ReadStepObservationE
	.section	.rodata.str1.1
.LC739:
	.ascii	"{\"operat"
	.string	"ion_id\":%lu,\"phase\":%u,\"outcome\":%u,\"owned\":%s,\"restored\":%s,\"released\":%s,\"cancel_requested\":%s,\"requests\":%u,\"count\":%u,\"tuple_index\":%u,\"address\":%u,\"started_us\":%llu,\"deadline_us\":%llu,\"finished_us\":%llu,\"original_target\":[%lu,%u,%lu],\"original_tuple\":"
.LC741:
	.string	",\"original_serial_generation\":%lu,\"settings\":{\"first\":%u,\"last\":%u,\"query_ms\":%lu,\"overall_ms\":%lu,\"request_limit\":%u,\"result_limit\":%u,\"identity\":%s,\"tuples\":["
.LC744:
	.string	"]},\"evidence_columns\":[\"first\",\"count\",\"event\",\"raw_hex\",\"received_length\",\"qualified\",\"attempted_us\",\"earliest_us\",\"latest_us\",\"delivered_us\",\"transport_detail\",\"tx_accepted\",\"execution_unknown\",\"status\",\"detail\",\"frame_error\"],\"findings\":["
.LC746:
	.string	"{\"profile\":\"ess_rs\",\"target\":[%lu,%u,%lu],\"operation_id\":%lu,\"serial\":[%s,%lu,%u,%u,%u],\"tx_hex\":\"%s\",\"started_us\":%llu,\"deadline_us\":%llu,\"outcome\":%u,\"confidence\":%u,\"raw_model_known\":%s,\"raw_model\":%u,\"probe\":"
.LC748:
	.string	",\"identity_attempted\":%s,\"identity_admission\":[%lu,%llu],\"identity_known\":%s,\"identity_ambiguous\":%s,\"collision_excluded\":%s,\"identity\":[%u,%u,%u,%u],\"identity_evidence\":"
	.text
	.literal_position
	.literal .LC736, .LC361
	.literal .LC737, .LC363
	.literal .LC738, .LC422
	.literal .LC740, .LC739
	.literal .LC742, .LC741
	.literal .LC743, .LC386
	.literal .LC745, .LC744
	.literal .LC747, .LC746
	.literal .LC749, .LC748
	.literal .LC750, .LC430
	.literal .LC751, .LC499
	.align	4
	.global	_ZN21MotorControlRSExample5Probe13discoveryScanEPcjRjPKNS0_13DiscoveryScanE
	.type	_ZN21MotorControlRSExample5Probe13discoveryScanEPcjRjPKNS0_13DiscoveryScanE, @function
_ZN21MotorControlRSExample5Probe13discoveryScanEPcjRjPKNS0_13DiscoveryScanE:
.LFB1072:
	entry	sp, 208
.LCFI59:
	s32i	a4, sp, 112
	bnez.n	a5, .L1160
	l32r	a13, .LC738
	mov.n	a12, a4
	j	.L1222
.L1160:
	l8ui	a7, a5, 108
	movi.n	a8, 8
	bltu	a8, a7, .L1163
	l8ui	a8, a5, 36
	bgeui	a8, 5, .L1163
	l8ui	a8, a5, 111
	l32i	a14, a5, 72
	l8ui	a15, a5, 104
	l8ui	a6, a5, 105
	l32r	a10, .LC737
	beqz.n	a8, .L1165
	l32r	a10, .LC736
.L1165:
	l8ui	a8, a5, 112
	l32r	a11, .LC737
	beqz.n	a8, .L1166
	l32r	a11, .LC736
.L1166:
	l8ui	a8, a5, 113
	l32r	a12, .LC737
	beqz.n	a8, .L1167
	l32r	a12, .LC736
.L1167:
	l8ui	a8, a5, 114
	l32r	a13, .LC737
	beqz.n	a8, .L1168
	l32r	a13, .LC736
.L1168:
	l32i	a8, a5, 60
	s32i	a8, sp, 72
	l8ui	a8, a5, 56
	s32i	a8, sp, 68
	l32i	a8, a5, 52
	s32i	a8, sp, 64
	l32i	a8, a5, 96
	l32i	a9, a5, 100
	s32i	a8, sp, 56
	s32i	a9, sp, 60
	l32i	a8, a5, 88
	l32i	a9, a5, 92
	s32i	a8, sp, 48
	s32i	a9, sp, 52
	l32i	a8, a5, 80
	l32i	a9, a5, 84
	s32i	a8, sp, 40
	s32i	a9, sp, 44
	l8ui	a8, a5, 110
	s32i	a8, sp, 32
	l8ui	a8, a5, 109
	s32i	a7, sp, 24
	s32i	a8, sp, 28
	l16ui	a8, a5, 106
	s32i	a13, sp, 16
	s32i	a12, sp, 12
	l32r	a13, .LC740
	l32i	a12, sp, 112
	s32i	a11, sp, 8
	s32i	a10, sp, 4
	s32i	a8, sp, 20
	s32i	a6, sp, 0
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1163
	l32i	a12, sp, 112
	addi	a13, a5, 64
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	beqz.n	a10, .L1163
	l8ui	a7, a5, 51
	l32i	a14, a5, 76
	l8ui	a15, a5, 1
	l8ui	a9, a5, 2
	l32i	a10, a5, 40
	l32i	a11, a5, 44
	l16ui	a12, a5, 48
	l8ui	a13, a5, 50
	l32r	a8, .LC737
	beqz.n	a7, .L1169
	l32r	a8, .LC736
.L1169:
	s32i	a13, sp, 16
	s32i	a12, sp, 12
	l32r	a13, .LC742
	l32i	a12, sp, 112
	s32i	a11, sp, 8
	s32i	a10, sp, 4
	s32i	a8, sp, 20
	s32i	a9, sp, 0
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	movi.n	a7, 0
	bnez.n	a10, .L1170
	j	.L1163
.L1174:
	bnez.n	a7, .L1171
.L1173:
	addx8	a13, a7, a5
	l32i	a12, sp, 112
	addi.n	a13, a13, 4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	bnez.n	a10, .L1172
	j	.L1163
.L1171:
	l32r	a13, .LC743
	l32i	a12, sp, 112
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1173
	j	.L1163
.L1172:
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
.L1170:
	l8ui	a8, a5, 36
	bltu	a7, a8, .L1174
	l32r	a13, .LC745
	l32i	a12, sp, 112
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	movi.n	a4, 0
	bnez.n	a10, .L1175
	j	.L1163
.L1185:
	slli	a6, a4, 4
	add.n	a9, a6, a4
	addx4	a9, a9, a4
	addx8	a9, a9, a5
	l32i	a11, a9, 180
	movi.n	a9, 8
	bltu	a9, a11, .L1163
	add.n	a7, a6, a4
	addx4	a7, a7, a4
	slli	a7, a7, 3
	movi	a10, 0xac
	add.n	a10, a7, a10
	movi.n	a13, 0x11
	addi	a12, sp, 80
	add.n	a10, a5, a10
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	bnez.n	a4, .L1177
.L1179:
	add.n	a9, a6, a4
	addx4	a9, a9, a4
	addx8	a9, a9, a5
	l32i	a8, a9, 124
	l32i	a10, a9, 136
	l8ui	a15, a9, 128
	s32i	a8, sp, 120
	l32i	a8, a9, 132
	l8ui	a9, a9, 160
	s32i	a10, sp, 116
	l32r	a10, .LC737
	beqz.n	a9, .L1178
	l32r	a10, .LC736
	j	.L1178
.L1177:
	l32r	a13, .LC743
	l32i	a12, sp, 112
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1179
	j	.L1163
.L1178:
	add.n	a9, a6, a4
	addx4	a9, a9, a4
	addx8	a9, a9, a5
	l32i	a11, a9, 164
	l32i	a12, a9, 144
	s32i	a11, sp, 128
	l8ui	a11, a9, 168
	l32i	a13, a9, 148
	s32i	a11, sp, 132
	l8ui	a11, a9, 169
	s32i	a12, sp, 144
	s32i	a13, sp, 148
	l32i	a12, a9, 152
	l32i	a13, a9, 156
	s32i	a11, sp, 136
	l8ui	a11, a9, 170
	s32i	a12, sp, 152
	s32i	a13, sp, 156
	l8ui	a12, a9, 216
	l8ui	a13, a9, 217
	l8ui	a9, a9, 218
	s32i	a11, sp, 140
	l32r	a11, .LC737
	beqz.n	a9, .L1180
	l32r	a11, .LC736
.L1180:
	slli	a9, a4, 4
	add.n	a6, a9, a4
	addx4	a6, a6, a4
	addx8	a6, a6, a5
	l16ui	a14, a6, 220
	s32i	a9, sp, 160
	movi	a9, 0x98
	s32i	a14, sp, 60
	s32i	a11, sp, 56
	s32i	a13, sp, 52
	s32i	a12, sp, 48
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	movi	a9, 0x90
	add.n	a9, a9, sp
	s32i	a12, sp, 40
	s32i	a13, sp, 44
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	addi	a9, sp, 80
	s32i	a9, sp, 28
	l32i	a9, sp, 140
	s32i	a12, sp, 32
	s32i	a9, sp, 24
	l32i	a9, sp, 136
	s32i	a13, sp, 36
	s32i	a9, sp, 20
	l32i	a9, sp, 132
	l32i	a14, sp, 120
	s32i	a9, sp, 16
	l32i	a9, sp, 128
	l32r	a13, .LC747
	s32i	a9, sp, 12
	l32i	a9, sp, 116
	l32i	a12, sp, 112
	s32i	a10, sp, 8
	s32i	a9, sp, 4
	s32i	a8, sp, 0
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1163
	movi	a13, 0xf0
	add.n	a13, a7, a13
	l32i	a12, sp, 112
	add.n	a13, a5, a13
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe17discoveryEvidenceEPcjRjRKN14MotorControlRS6ESS_RS19ReadStepObservationE
	beqz.n	a10, .L1163
	movi	a10, 0x298
	add.n	a6, a6, a10
	l8ui	a10, a6, 0
	l32r	a14, .LC737
	l32i	a9, sp, 160
	beqz.n	a10, .L1181
	l32r	a14, .LC736
.L1181:
	add.n	a10, a9, a4
	addx4	a10, a10, a4
	addx8	a10, a10, a5
	movi	a11, 0x299
	l32i	a12, a10, 656
	l32i	a13, a10, 660
	l32i	a15, a10, 648
	add.n	a10, a10, a11
	l8ui	a10, a10, 0
	s32i	a12, sp, 120
	s32i	a13, sp, 124
	l32r	a11, .LC737
	beqz.n	a10, .L1182
	l32r	a11, .LC736
.L1182:
	add.n	a10, a9, a4
	addx4	a10, a10, a4
	movi	a12, 0x29a
	addx8	a10, a10, a5
	add.n	a10, a10, a12
	l8ui	a12, a10, 0
	l32r	a10, .LC737
	beqz.n	a12, .L1183
	l32r	a10, .LC736
.L1183:
	add.n	a9, a9, a4
	addx4	a9, a9, a4
	movi	a12, 0x29b
	addx8	a9, a9, a5
	add.n	a9, a9, a12
	l8ui	a9, a9, 0
	l32r	a12, .LC737
	beqz.n	a9, .L1184
	l32r	a12, .LC736
.L1184:
	slli	a9, a4, 4
	add.n	a9, a9, a4
	addx4	a9, a9, a4
	addx8	a9, a9, a5
	l16ui	a13, a9, 382
	l32i	a8, sp, 120
	s32i	a13, sp, 32
	l16ui	a13, a9, 380
	s32i	a13, sp, 28
	l16ui	a13, a9, 378
	s32i	a13, sp, 24
	l16ui	a9, a9, 376
	l32r	a13, .LC749
	s32i	a9, sp, 20
	l32i	a9, sp, 124
	s32i	a12, sp, 16
	l32i	a12, sp, 112
	s32i	a10, sp, 12
	s32i	a11, sp, 8
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1163
	movi	a9, 0x210
	add.n	a13, a7, a9
	l32i	a12, sp, 112
	add.n	a13, a5, a13
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe17discoveryEvidenceEPcjRjRKN14MotorControlRS6ESS_RS19ReadStepObservationE
	beqz.n	a10, .L1163
	l32r	a13, .LC750
	l32i	a12, sp, 112
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1163
	addi.n	a8, a4, 1
	extui	a4, a8, 0, 8
	j	.L1175
.L1163:
	movi.n	a2, 0
	j	.L1161
.L1175:
	l8ui	a9, a5, 108
	bltu	a4, a9, .L1185
	l32r	a13, .LC751
	l32i	a12, sp, 112
.L1222:
	mov.n	a10, a2
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1161:
	retw.n
.LFE1072:
	.size	_ZN21MotorControlRSExample5Probe13discoveryScanEPcjRjPKNS0_13DiscoveryScanE, .-_ZN21MotorControlRSExample5Probe13discoveryScanEPcjRjPKNS0_13DiscoveryScanE
	.literal_position
	.literal .LC753, 35380
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	.type	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv, @function
_ZN21MotorControlRSExample5Probe7Console9beginWorkEv:
.LFB1073:
	entry	sp, 32
.LCFI60:
	l8ui	a8, a2, 141
	bnez.n	a8, .L1223
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1223
	l32r	a8, .LC753
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1223
	l32i	a8, a2, 4
	beqz.n	a8, .L1223
	l32i	a10, a2, 0
	callx8	a8
.L1223:
	retw.n
.LFE1073:
	.section	.gcc_except_table
.LLSDA1073:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1073-.LLSDACSB1073
.LLSDACSB1073:
.LLSDACSE1073:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv, .-_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	.section	.rodata.str1.1
.LC754:
	.string	"unavailable"
.LC756:
	.string	"invalid_arguments"
.LC762:
	.string	"invalid_address"
	.text
	.literal_position
	.literal .LC755, .LC754
	.literal .LC757, .LC756
	.literal .LC759, 200000
	.literal .LC760, 500000
	.literal .LC761, .LC318
	.literal .LC763, .LC762
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console13parameterReadEmN14MotorControlRS6ESS_RS8ReadKindEPKc
	.type	_ZN21MotorControlRSExample5Probe7Console13parameterReadEmN14MotorControlRS6ESS_RS8ReadKindEPKc, @function
_ZN21MotorControlRSExample5Probe7Console13parameterReadEmN14MotorControlRS6ESS_RS8ReadKindEPKc:
.LFB1074:
	entry	sp, 736
.LCFI61:
	extui	a8, a4, 0, 8
	mov.n	a10, a8
	s32i	a8, sp, 688
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE
	l32i	a8, a2, 24
	mov.n	a7, a10
	beqz.n	a8, .L1229
	l32i	a6, a2, 12
	bnez.n	a6, .L1230
.L1229:
	l32r	a13, .LC755
	j	.L1243
.L1230:
	movi.n	a8, 0
	s32i	a8, sp, 680
	beqz.n	a5, .L1232
	addi	a8, sp, 16
	movi	a11, 0x298
	add.n	a11, a8, a11
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	l32r	a13, .LC757
	beqz.n	a10, .L1243
	j	.L1233
.L1232:
	movi	a12, 0x298
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi	a8, 0xe1
	slli	a8, a8, 9
	s32i	a8, sp, 16
	s32i	a8, sp, 24
	s32i	a8, sp, 32
	movi.n	a8, 1
	s8i	a8, sp, 40
	movi.n	a9, 0x14
	movi.n	a8, 1
	s32i	a8, sp, 44
	s32i	a9, sp, 92
	s8i	a8, sp, 136
	l32r	a9, .LC759
	l32r	a8, .LC761
	s32i	a9, sp, 100
	s32i	a8, sp, 196
	l32r	a9, .LC760
	movi.n	a8, 0x40
	s32i	a8, sp, 272
	l32i	a10, a2, 0
	movi.n	a8, 0xa
	s32i	a8, sp, 324
	s32i	a9, sp, 104
	s32i	a9, sp, 108
	addi	a11, sp, 16
	callx8	a6
	l8ui	a8, sp, 136
	s32i	a8, sp, 680
.L1233:
	l32i	a5, sp, 680
	movi	a9, 0xf6
	addi.n	a8, a5, -1
	bgeu	a9, a8, .L1235
	l32r	a13, .LC763
.L1243:
	mov.n	a12, a7
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L1228
.L1235:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0
	s32i	a8, sp, 16
	movi.n	a8, 0xf
	movi.n	a6, 1
	movi.n	a4, 0
	beq	a10, a8, .L1236
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	l32i	a8, a2, 24
	l32i	a13, sp, 688
	l32i	a10, a2, 0
	addi	a14, sp, 16
	mov.n	a12, a5
	mov.n	a11, a3
	callx8	a8
	mov.n	a6, a10
	bnez.n	a10, .L1236
	l32i	a4, sp, 16
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L1236:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	mov.n	a15, a4
	mov.n	a14, a5
	mov.n	a13, a6
	mov.n	a12, a7
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
.L1228:
	retw.n
.LFE1074:
	.section	.gcc_except_table
.LLSDA1074:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1074-.LLSDACSB1074
.LLSDACSB1074:
.LLSDACSE1074:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console13parameterReadEmN14MotorControlRS6ESS_RS8ReadKindEPKc, .-_ZN21MotorControlRSExample5Probe7Console13parameterReadEmN14MotorControlRS6ESS_RS8ReadKindEPKc
	.section	.rodata.str1.1
.LC766:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"ok\":%s,\"result\":\"%s\""
.LC770:
	.string	",\"%s\":\"%s\""
.LC772:
	.string	"output_full"
	.text
	.literal_position
	.literal .LC764, .LC361
	.literal .LC765, .LC363
	.literal .LC767, .LC766
	.literal .LC768, 16384
	.literal .LC769, .LC430
	.literal .LC771, .LC770
	.literal .LC773, .LC772
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console18qualificationReplyEmPKcS3_S3_S3_b
	.type	_ZN21MotorControlRSExample5Probe7Console18qualificationReplyEmPKcS3_S3_S3_b, @function
_ZN21MotorControlRSExample5Probe7Console18qualificationReplyEmPKcS3_S3_S3_b:
.LFB1087:
	entry	sp, 64
.LCFI62:
	movi.n	a9, 0
	l8ui	a10, sp, 64
	mov.n	a8, a5
	s32i	a9, sp, 16
	mov.n	a5, a6
	movi	a6, 0x124
	l32r	a9, .LC765
	add.n	a6, a2, a6
	beqz.n	a10, .L1245
	l32r	a9, .LC764
.L1245:
	l32r	a13, .LC767
	l32r	a11, .LC768
	s32i	a8, sp, 4
	s32i	a9, sp, 0
	mov.n	a15, a4
	mov.n	a14, a3
	addi	a12, sp, 16
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1246
	bnez.n	a5, .L1247
.L1249:
	l32r	a13, .LC769
	l32r	a11, .LC768
	addi	a12, sp, 16
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1246
	j	.L1248
.L1247:
	l32r	a13, .LC771
	l32r	a11, .LC768
	mov.n	a15, a7
	mov.n	a14, a5
	addi	a12, sp, 16
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1249
	j	.L1246
.L1248:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L1244
.L1246:
	l32r	a13, .LC773
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
.L1244:
	retw.n
.LFE1087:
	.size	_ZN21MotorControlRSExample5Probe7Console18qualificationReplyEmPKcS3_S3_S3_b, .-_ZN21MotorControlRSExample5Probe7Console18qualificationReplyEmPKcS3_S3_S3_b
	.section	.rodata.str1.1
.LC775:
	.string	"invalid"
.LC777:
	.string	"fact_not_applicable"
.LC780:
	.string	"unimplemented"
.LC783:
	.string	"fact"
.LC785:
	.string	"read_first"
.LC788:
	.string	"revoke"
.LC797:
	.string	"install"
.LC800:
	.string	"index"
.LC0:
	.string	"home-qualification-install"
.LC1:
	.string	"velocity-qualification-install"
.LC2:
	.string	"position-clear-qualification-install"
.LC3:
	.string	"motion-profile-start-speed-relation"
	.section	.rodata
	.align	4
.LC790:
	.word	.LC0
	.word	.LC1
	.word	.LC2
	.word	.LC3
	.section	.rodata.str1.1
.LC5:
	.string	"home-qualification-revoke"
.LC6:
	.string	"velocity-qualification-revoke"
.LC7:
	.string	"position-clear-qualification-revoke"
	.section	.rodata
	.align	4
.LC792:
	.word	.LC5
	.word	.LC6
	.word	.LC7
	.word	.LC3
	.text
	.literal_position
	.literal .LC774, .LC756
	.literal .LC776, .LC775
	.literal .LC778, .LC777
	.literal .LC779, .LC679
	.literal .LC781, .LC780
	.literal .LC782, .LC354
	.literal .LC784, .LC783
	.literal .LC786, .LC785
	.literal .LC787, 1966140
	.literal .LC789, .LC788
	.literal .LC791, .LC790
	.literal .LC793, .LC792
	.literal .LC794, .LC754
	.literal .LC798, .LC797
	.literal .LC799, _ZN21MotorControlRSExample5Probe18QualificationFactsL4HOMEE
	.literal .LC801, .LC800
	.literal .LC802, _ZN21MotorControlRSExample5Probe18QualificationFactsL8VELOCITYE
	.literal .LC803, _ZN21MotorControlRSExample5Probe18QualificationFactsL14POSITION_CLEARE
	.literal .LC804, .LC544
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console18qualificationRouteEmNS0_18QualificationRouteEPKPKcj
	.type	_ZN21MotorControlRSExample5Probe7Console18qualificationRouteEmNS0_18QualificationRouteEPKPKcj, @function
_ZN21MotorControlRSExample5Probe7Console18qualificationRouteEmNS0_18QualificationRouteEPKPKcj:
.LFB1088:
	entry	sp, 176
.LCFI63:
	addi	a7, sp, 16
	movi.n	a11, 0
	movi.n	a12, 0x30
	mov.n	a10, a7
	s32i	a3, sp, 132
	call8	memset
	movi.n	a8, 0x23
	s16i	a8, sp, 24
	l32r	a8, .LC787
	extui	a4, a4, 0, 8
	s32i	a8, sp, 32
	movi	a8, 0x64
	movi.n	a11, 0
	s16i	a8, sp, 36
	movi.n	a10, 1
	addi	a8, a4, -3
	moveqz	a10, a11, a8
	addi.n	a3, a6, -1
	movi.n	a8, 1
	moveqz	a11, a8, a3
	s8i	a4, sp, 16
	and	a10, a10, a11
	beqz.n	a10, .L1257
	l32r	a11, .LC789
	l32i	a10, a5, 0
	call8	strcmp
	nsau	a10, a10
	srli	a10, a10, 5
.L1257:
	l32r	a11, .LC791
	s8i	a10, sp, 17
	l32i	a13, a11, 0
	l32i	a14, a11, 4
	s32i	a13, sp, 80
	l32i	a13, a11, 8
	l32i	a11, a11, 12
	s32i	a13, sp, 88
	s32i	a11, sp, 92
	l32r	a11, .LC793
	s32i	a14, sp, 84
	l32i	a13, a11, 0
	l32i	a14, a11, 4
	s32i	a13, sp, 64
	l32i	a13, a11, 8
	l32i	a11, a11, 12
	s32i	a14, sp, 68
	s32i	a11, sp, 76
	s32i	a13, sp, 72
	slli	a11, a4, 2
	add.n	a11, a7, a11
	beqz.n	a10, .L1258
	l32i	a8, a11, 48
	j	.L1304
.L1258:
	l32i	a8, a11, 64
.L1304:
	l32i	a11, a2, 64
	s32i	a8, sp, 128
	bnez.n	a11, .L1260
	l32r	a13, .LC794
	l32i	a12, sp, 128
	l32i	a11, sp, 132
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L1255
.L1260:
	movi.n	a11, 0
	s32i	a11, sp, 112
	bnei	a4, 3, .L1262
	s32i	a11, sp, 108
	s32i	a11, sp, 96
	beqi	a6, 2, .L1263
.L1265:
	l32r	a10, .LC774
	j	.L1264
.L1263:
	l32i	a10, a5, 0
	addi	a11, sp, 108
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L1265
	movi	a9, 0xb8
	l32i	a8, sp, 108
	addmi	a9, a9, 0xb00
	bltu	a9, a8, .L1265
	l32i	a10, a5, 4
	addi	a11, sp, 96
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L1265
	l32i	a8, sp, 96
	movi	a9, 0xb7
	addi.n	a8, a8, -1
	addmi	a9, a9, 0xb00
	bltu	a9, a8, .L1265
	movi.n	a10, 0
.L1264:
	l32i	a8, sp, 108
	s16i	a8, sp, 60
	l32i	a8, sp, 96
	s16i	a8, sp, 62
	j	.L1266
.L1262:
	bnez.n	a10, .L1274
	bnez.n	a6, .L1268
.L1270:
	l32r	a10, .LC774
	j	.L1269
.L1268:
	l32r	a11, .LC798
	l32i	a10, a5, 0
	call8	strcmp
	bnez.n	a10, .L1270
	addi.n	a10, a5, 4
	bnez.n	a4, .L1271
	bltui	a3, 4, .L1270
	addi	a11, sp, 24
	call8	_ZN21MotorControlRSExample5Probe11HomeConsole10parseWordsEPKPKcRN14MotorControlRS6ESS_RS11HomeRequestE
	beqz.n	a10, .L1270
	l16si	a10, sp, 24
	call8	_ZN14MotorControlRS6ESS_RS10homeMethodENS0_12HomingMethodE
	mov.n	a4, a10
	beqz.n	a10, .L1281
	l8ui	a9, a10, 2
	beqi	a9, 2, .L1282
	beqi	a9, 1, .L1283
	l32r	a12, .LC799
	addi	a15, sp, 112
	mov.n	a14, a7
	movi.n	a13, 8
	addi	a11, a6, -5
	addi	a10, a5, 20
	call8	_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_
	bnez.n	a10, .L1269
	l32r	a9, .LC801
	l8ui	a8, a4, 4
	s32i	a9, sp, 112
	l8ui	a9, sp, 54
	beqz.n	a8, .L1272
	l32r	a10, .LC782
	beqz.n	a9, .L1269
	j	.L1273
.L1272:
	l32r	a10, .LC778
	bnez.n	a9, .L1269
.L1273:
	movi.n	a8, 0
	s32i	a8, sp, 112
	j	.L1274
.L1271:
	addi	a15, sp, 112
	mov.n	a14, a7
	bnei	a4, 1, .L1275
	l32r	a12, .LC802
	movi.n	a13, 4
	j	.L1305
.L1275:
	l32r	a12, .LC803
	movi.n	a13, 1
.L1305:
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe18QualificationFacts5parseEPKPKcjPKNS1_4FactEjRNS0_20QualificationCommandERS3_
.L1266:
	beqz.n	a10, .L1274
	j	.L1269
.L1281:
	l32r	a10, .LC776
	j	.L1269
.L1282:
	l32r	a10, .LC779
	j	.L1269
.L1283:
	l32r	a10, .LC781
.L1269:
	l32i	a15, sp, 112
	movi.n	a14, 0
	beqz.n	a15, .L1276
	l32r	a14, .LC784
.L1276:
	movi.n	a8, 0
	s32i	a8, sp, 0
	mov.n	a13, a10
	j	.L1306
.L1274:
	l32i	a8, a2, 64
	l32i	a10, a2, 0
	mov.n	a11, a7
	callx8	a8
	s32i	a10, sp, 96
	s32i	a11, sp, 100
	s32i	a12, sp, 104
	extui	a10, a10, 0, 8
	mov.n	a13, a11
	bnez.n	a10, .L1277
	movi.n	a8, 1
	l32r	a13, .LC804
	s32i	a8, sp, 0
	movi.n	a15, 0
	movi.n	a14, 0
	j	.L1306
.L1277:
	bnez.n	a11, .L1278
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	mov.n	a13, a10
.L1278:
	l32i	a15, sp, 104
	movi.n	a14, 0
	beqz.n	a15, .L1279
	l32r	a14, .LC786
.L1279:
	movi.n	a8, 0
	s32i	a8, sp, 0
.L1306:
	l32i	a12, sp, 128
	l32i	a11, sp, 132
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18qualificationReplyEmPKcS3_S3_S3_b
.L1255:
	retw.n
.LFE1088:
	.section	.gcc_except_table
.LLSDA1088:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1088-.LLSDACSB1088
.LLSDACSB1088:
.LLSDACSE1088:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console18qualificationRouteEmNS0_18QualificationRouteEPKPKcj, .-_ZN21MotorControlRSExample5Probe7Console18qualificationRouteEmNS0_18QualificationRouteEPKPKcj
	.literal_position
	.literal .LC805, .LC107
	.literal .LC806, CSWTCH$1586
	.align	4
	.global	_ZN21MotorControlRSExample5Probe13broadcastNameENS0_14BroadcastFrameE
	.type	_ZN21MotorControlRSExample5Probe13broadcastNameENS0_14BroadcastFrameE, @function
_ZN21MotorControlRSExample5Probe13broadcastNameENS0_14BroadcastFrameE:
.LFB1201:
	entry	sp, 32
.LCFI64:
	extui	a8, a2, 0, 8
	l32r	a2, .LC805
	bgeui	a8, 5, .L1307
	l32r	a9, .LC806
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L1307:
	retw.n
.LFE1201:
	.size	_ZN21MotorControlRSExample5Probe13broadcastNameENS0_14BroadcastFrameE, .-_ZN21MotorControlRSExample5Probe13broadcastNameENS0_14BroadcastFrameE
	.section	.rodata.str1.1
.LC807:
	.string	"reply"
.LC809:
	.string	"result"
.LC817:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"ok\":%s,"
	.ascii	"\"address\":0,\"frame\":\"%s\",\"outcome\":\"%s\",\"confirme"
	.ascii	"d\":false,\"execution_unknown\":%s,\"cancellation\":\"%s\","
	.string	"\"transport\":\"%s\",\"window_us\":%lu,\"tx_bytes\":%u,\"rx_bytes\":%u,\"tx_hex\":\"%s\",\"rx_hex\":\"%s\",\"raw_truncated\":%s,\"started_us\":%llu,\"tx_end_us\":%llu,\"tx_uncertainty_us\":%lu,\"first_rx_start_us\":%llu,\"max_rx_uncertainty_us\":%lu,\"ended_us\":%llu,\"delivered_us\":%llu}"
	.text
	.literal_position
	.literal .LC808, .LC807
	.literal .LC810, .LC809
	.literal .LC811, .LC602
	.literal .LC812, .LC361
	.literal .LC813, .LC363
	.literal .LC814, .LC107
	.literal .LC815, CSWTCH$1382
	.literal .LC816, CSWTCH$1384
	.literal .LC818, .LC817
	.literal .LC821, .LC772
	.literal .LC823, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console15formatBroadcastEmmmRKNS0_11ProbeResultEb
	.type	_ZN21MotorControlRSExample5Probe7Console15formatBroadcastEmmmRKNS0_11ProbeResultEb, @function
_ZN21MotorControlRSExample5Probe7Console15formatBroadcastEmmmRKNS0_11ProbeResultEb:
.LFB1202:
	entry	sp, 352
.LCFI65:
	l32i	a9, a6, 108
	mov.n	a8, a7
	mov.n	a7, a2
	l32i	a2, a6, 112
	s32i	a4, sp, 296
	movi	a12, 0x81
	extui	a4, a8, 0, 8
	addi	a8, sp, 112
	add.n	a12, a8, a12
	mov.n	a10, a9
	movi.n	a13, 0x11
	mov.n	a11, a2
	s32i	a9, sp, 276
	s32i	a3, sp, 280
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a3, a6, 120
	l32i	a10, a6, 116
	mov.n	a11, a3
	movi	a13, 0x81
	addi	a12, sp, 112
	s32i	a10, sp, 272
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l8ui	a8, a6, 39
	movi.n	a11, 8
	saltu	a11, a11, a2
	or	a11, a11, a8
	movi.n	a8, 0x40
	saltu	a8, a8, a3
	or	a8, a8, a11
	extui	a8, a8, 0, 8
	l32i	a10, sp, 272
	l32i	a9, sp, 276
	bnez.n	a8, .L1311
	movi.n	a11, 1
	mov.n	a12, a8
	moveqz	a12, a11, a9
	movnez	a8, a11, a2
	and	a8, a12, a8
	bnez.n	a8, .L1311
	mov.n	a9, a8
	movnez	a9, a11, a3
	movnez	a11, a8, a10
	and	a9, a9, a11
	extui	a8, a9, 0, 8
.L1311:
	movi	a9, 0x124
	add.n	a9, a7, a9
	s32i	a9, sp, 284
	beqz.n	a4, .L1323
	l32r	a9, .LC808
	l32r	a3, .LC810
	s32i	a9, sp, 272
	j	.L1312
.L1323:
	l32r	a9, .LC811
	s32i	a9, sp, 272
	mov.n	a3, a9
.L1312:
	l8ui	a11, a6, 152
	l32r	a2, .LC813
	bnei	a11, 7, .L1313
	l32r	a2, .LC812
.L1313:
	l8ui	a10, a6, 2
	s32i	a8, sp, 300
	s32i	a11, sp, 292
	call8	_ZN21MotorControlRSExample5Probe13broadcastNameENS0_14BroadcastFrameE
	l32r	a8, .LC814
	l32i	a11, sp, 292
	s32i	a8, sp, 276
	s32i	a10, sp, 288
	l32i	a8, sp, 300
	bgeui	a11, 8, .L1314
	l32r	a9, .LC815
	addx4	a11, a11, a9
	l32i	a9, a11, 0
	s32i	a9, sp, 276
.L1314:
	l8ui	a10, a6, 153
	l32r	a11, .LC813
	beqz.n	a10, .L1315
	l32r	a11, .LC812
.L1315:
	l8ui	a10, a6, 154
	l32r	a12, .LC814
	bgeui	a10, 4, .L1316
	l32r	a12, .LC816
	addx4	a10, a10, a12
	l32i	a12, a10, 0
.L1316:
	l8ui	a10, a6, 8
	s32i	a12, sp, 308
	s32i	a11, sp, 304
	s32i	a8, sp, 300
	call8	_ZN21MotorControlRSExample3Rtu10reasonNameENS0_6ReasonE
	l32i	a8, a6, 4
	mov.n	a13, a10
	s32i	a8, sp, 292
	l32i	a8, sp, 300
	l16ui	a10, a6, 32
	l16ui	a14, a6, 34
	l32r	a15, .LC813
	l32i	a11, sp, 304
	l32i	a12, sp, 308
	beqz.n	a8, .L1317
	l32r	a15, .LC812
.L1317:
	l32i	a8, a6, 176
	l32i	a9, a6, 180
	s32i	a8, sp, 104
	s32i	a9, sp, 108
	l32i	a8, a6, 24
	l32i	a9, a6, 28
	s32i	a8, sp, 96
	s32i	a9, sp, 100
	l32i	a8, a6, 132
	s32i	a8, sp, 88
	l32i	a8, a6, 144
	l32i	a9, a6, 148
	s32i	a8, sp, 80
	s32i	a9, sp, 84
	l32i	a8, a6, 128
	s32i	a8, sp, 72
	l32i	a8, a6, 136
	l32i	a9, a6, 140
	s32i	a8, sp, 64
	s32i	a9, sp, 68
	l32i	a8, a6, 16
	l32i	a9, a6, 20
	s32i	a8, sp, 56
	addi	a6, sp, 112
	movi	a8, 0x81
	add.n	a8, a6, a8
	s32i	a8, sp, 44
	l32i	a8, sp, 292
	s32i	a9, sp, 60
	s32i	a15, sp, 52
	s32i	a14, sp, 40
	s32i	a10, sp, 36
	s32i	a8, sp, 32
	s32i	a13, sp, 28
	s32i	a6, sp, 48
	s32i	a12, sp, 24
	l32i	a8, sp, 276
	s32i	a11, sp, 20
	s32i	a8, sp, 16
	l32i	a8, sp, 288
	l32i	a14, sp, 280
	s32i	a8, sp, 12
	l32i	a8, sp, 296
	l32i	a13, sp, 272
	l32r	a12, .LC818
	l32i	a10, sp, 284
	movi.n	a11, 1
	s32i	a8, sp, 0
	s32i	a2, sp, 8
	s32i	a5, sp, 4
	mov.n	a15, a3
	slli	a11, a11, 14
	call8	snprintf
	movi.n	a8, -1
	extui	a8, a8, 18, 14
	bgeu	a8, a10, .L1318
	l32r	a13, .LC821
	l32i	a11, sp, 280
	mov.n	a12, a3
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	bnez.n	a4, .L1319
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1320
	l32r	a8, .LC823
	add.n	a8, a7, a8
	s32i	a5, a8, 0
	j	.L1319
.L1320:
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console7untrackEm
	j	.L1319
.L1318:
	movi	a11, 0x94
	s32i	a10, sp, 260
	add.n	a11, a6, a11
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	beqz.n	a10, .L1321
	movi.n	a8, 0
	movnez	a5, a8, a4
	movi.n	a12, 0
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L1319:
	movi.n	a2, 1
.L1321:
	retw.n
.LFE1202:
	.size	_ZN21MotorControlRSExample5Probe7Console15formatBroadcastEmmmRKNS0_11ProbeResultEb, .-_ZN21MotorControlRSExample5Probe7Console15formatBroadcastEmmmRKNS0_11ProbeResultEb
	.section	.rodata.str1.1
.LC828:
	.string	"capture_read"
.LC833:
	.string	"NOT_CHECKED"
.LC835:
	.string	"not_requested"
.LC837:
	.string	"responder_only"
.LC839:
	.string	"responder_model_unresolved"
.LC844:
	.string	"%u"
.LC848:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"ok\":%s,"
	.ascii	"\"address\":%u,\"outcome\":\"%s\",\"execution_unknown\":%s,\""
	.ascii	"cancellation\":\"%s\",\"transport\":\"%s\",\"codec\":\"%s\","
	.ascii	"\"detail\":%ld,\"frame_error\":%u,\"raw_model\":%s,\"capture"
	.ascii	"_read\":%s,\"register_start\":%u,\"register_count\":%u,\"dur"
	.ascii	"ation_us\":%llu,\"tx_bytes\":%u,\"rx_byt"
	.string	"es\":%u,\"identity\":\"%s\",\"tx_hex\":\"%s\",\"rx_hex\":\"%s\",\"raw_truncated\":%s,\"timing_valid\":%s,\"tx_uncertainty_us\":%lu,\"max_rx_uncertainty_us\":%lu,\"tx_end_us\":%llu,\"first_rx_start_us\":%llu,\"observed_earliest_us\":%llu,\"observed_latest_us\":%llu,\"delivered_us\":%llu}"
.LC855:
	.string	",\"confidence\":\"%s\",\"manufacturer_confirmed\":false,\"exact_model_confirmed\":false,\"collision_excluded\":false}"
	.section	.rodata
.LC842:
	.string	"null"
	.zero	3
	.text
	.literal_position
	.literal .LC824, .LC598
	.literal .LC825, .LC596
	.literal .LC826, .LC807
	.literal .LC827, .LC809
	.literal .LC829, .LC828
	.literal .LC830, .LC361
	.literal .LC831, .LC363
	.literal .LC832, .LC107
	.literal .LC834, .LC833
	.literal .LC836, .LC835
	.literal .LC838, .LC837
	.literal .LC840, .LC839
	.literal .LC841, .LC337
	.literal .LC843, .LC842
	.literal .LC845, .LC844
	.literal .LC846, CSWTCH$1382
	.literal .LC847, CSWTCH$1384
	.literal .LC849, .LC848
	.literal .LC850, 16384
	.literal .LC852, .LC772
	.literal .LC854, 35376
	.literal .LC856, .LC855
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console11formatProbeEmmhmRKNS0_11ProbeResultEb
	.type	_ZN21MotorControlRSExample5Probe7Console11formatProbeEmmhmRKNS0_11ProbeResultEb, @function
_ZN21MotorControlRSExample5Probe7Console11formatProbeEmmhmRKNS0_11ProbeResultEb:
.LFB1200:
	entry	sp, 432
.LCFI66:
	extui	a8, a5, 0, 8
	s32i	a8, sp, 396
	addi	a9, sp, 80
	movi	a8, 0x160
	add.n	a8, a8, a9
	l8ui	a8, a8, 0
	s32i	a3, sp, 340
	s32i	a8, sp, 320
	l8ui	a8, a7, 1
	s32i	a4, sp, 376
	s32i	a8, sp, 324
	beqz.n	a8, .L1335
	l32i	a15, sp, 320
	mov.n	a14, a7
	mov.n	a13, a6
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15formatBroadcastEmmmRKNS0_11ProbeResultEb
	s32i	a10, sp, 324
	j	.L1336
.L1335:
	l8ui	a8, a7, 8
	movi.n	a4, 0
	bnei	a8, 1, .L1337
	l8ui	a4, a7, 88
	beqz.n	a4, .L1337
	l8ui	a4, a7, 92
	nsau	a4, a4
	srli	a4, a4, 5
.L1337:
	l32i	a11, a7, 28
	l32i	a10, a7, 20
	l32i	a9, a7, 24
	l32i	a8, a7, 16
	bltu	a11, a10, .L1366
	bne	a10, a11, .L1384
	bltu	a9, a8, .L1366
.L1384:
	sub	a10, a11, a10
	s32i	a10, sp, 328
	bgeu	a9, a8, .L1340
	addi.n	a10, a10, -1
	s32i	a10, sp, 328
.L1340:
	sub	a8, a9, a8
	s32i	a8, sp, 380
	j	.L1338
.L1366:
	movi.n	a8, 0
	s32i	a8, sp, 380
	s32i	a8, sp, 328
.L1338:
	movi	a5, 0xa0
	add.n	a5, sp, a5
	l32r	a11, .LC843
	movi	a10, 0x92
	movi.n	a12, 5
	add.n	a10, a5, a10
	call8	memcpy
	movi	a10, 0x97
	movi.n	a12, 3
	movi.n	a11, 0
	add.n	a10, a5, a10
	call8	memset
	l32i	a8, a7, 108
	l32i	a3, a7, 112
	movi	a12, 0x81
	mov.n	a10, a8
	add.n	a12, a5, a12
	movi.n	a13, 0x11
	mov.n	a11, a3
	s32i	a8, sp, 344
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a10, a7, 116
	l32i	a11, a7, 120
	mov.n	a12, a5
	movi	a13, 0x81
	s32i	a11, sp, 336
	s32i	a10, sp, 332
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l8ui	a12, a7, 39
	l32i	a11, sp, 336
	movi.n	a9, 8
	saltu	a9, a9, a3
	movi.n	a5, 0x40
	or	a9, a9, a12
	saltu	a5, a5, a11
	or	a5, a5, a9
	extui	a5, a5, 0, 8
	l32i	a10, sp, 332
	l32i	a8, sp, 344
	bnez.n	a5, .L1342
	movi.n	a9, 1
	mov.n	a12, a5
	movnez	a12, a9, a3
	moveqz	a5, a9, a8
	and	a5, a12, a5
	bnez.n	a5, .L1342
	mov.n	a8, a5
	moveqz	a8, a9, a10
	moveqz	a9, a5, a11
	and	a8, a8, a9
	extui	a5, a8, 0, 8
.L1342:
	beqz.n	a4, .L1343
	l8ui	a8, a7, 0
	bnez.n	a8, .L1343
	movi	a10, 0x132
	l16ui	a13, a7, 106
	l32r	a12, .LC845
	movi.n	a11, 8
	add.n	a10, sp, a10
	call8	snprintf
.L1343:
	l8ui	a8, a7, 0
	l32r	a3, .LC825
	beqz.n	a8, .L1344
	l32r	a3, .LC824
.L1344:
	movi	a9, 0x124
	add.n	a9, a2, a9
	s32i	a9, sp, 348
	l32i	a9, sp, 320
	bnez.n	a9, .L1368
	s32i	a3, sp, 336
	beqz.n	a8, .L1369
	l32r	a8, .LC829
	j	.L1402
.L1368:
	l32r	a8, .LC826
	s32i	a8, sp, 332
	l32r	a8, .LC827
	s32i	a8, sp, 336
	j	.L1345
.L1369:
	l32r	a8, .LC825
.L1402:
	s32i	a8, sp, 332
.L1345:
	l32r	a8, .LC831
	s32i	a8, sp, 352
	beqz.n	a4, .L1346
	l32r	a8, .LC830
	s32i	a8, sp, 352
.L1346:
	l32r	a9, .LC832
	l8ui	a8, a7, 152
	s32i	a9, sp, 368
	bgeui	a8, 8, .L1347
	l32r	a9, .LC846
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	s32i	a8, sp, 368
.L1347:
	l32r	a9, .LC831
	l8ui	a8, a7, 153
	s32i	a9, sp, 356
	beqz.n	a8, .L1348
	l32r	a8, .LC830
	s32i	a8, sp, 356
.L1348:
	l32r	a9, .LC832
	l8ui	a8, a7, 154
	s32i	a9, sp, 372
	bgeui	a8, 4, .L1349
	l32r	a9, .LC847
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	s32i	a8, sp, 372
.L1349:
	l8ui	a10, a7, 8
	call8	_ZN21MotorControlRSExample3Rtu10reasonNameENS0_6ReasonE
	l8ui	a8, a7, 88
	s32i	a10, sp, 384
	beqz.n	a8, .L1374
	l8ui	a10, a7, 92
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a15, a7, 96
	l8ui	a8, a7, 104
	mov.n	a14, a10
	j	.L1403
.L1374:
	l32r	a14, .LC834
	movi.n	a15, 0
	movi.n	a8, 0
.L1403:
	l8ui	a12, a7, 0
	s32i	a8, sp, 360
	bnez.n	a12, .L1375
	movi.n	a8, 0
	s32i	a8, sp, 344
	l32r	a9, .LC831
	movi.n	a8, 1
	j	.L1404
.L1375:
	movi	a8, 0x130
	l32r	a9, .LC830
	s32i	a8, sp, 344
	movi.n	a8, 0x10
.L1404:
	s32i	a8, sp, 364
	l16ui	a8, a7, 32
	s32i	a8, sp, 388
	l16ui	a8, a7, 34
	s32i	a8, sp, 392
	l32r	a8, .LC836
	bnez.n	a12, .L1352
	l32r	a8, .LC832
	beqz.n	a4, .L1352
	l32r	a8, .LC838
.L1352:
	l32r	a12, .LC831
	beqz.n	a5, .L1353
	l32r	a12, .LC830
.L1353:
	l8ui	a5, a7, 124
	l32r	a13, .LC831
	beqz.n	a5, .L1354
	l32r	a13, .LC830
.L1354:
	l32i	a10, a7, 176
	l32i	a11, a7, 180
	s32i	a10, sp, 144
	s32i	a11, sp, 148
	l32i	a10, a7, 168
	l32i	a11, a7, 172
	s32i	a10, sp, 136
	s32i	a11, sp, 140
	l32i	a10, a7, 160
	l32i	a11, a7, 164
	s32i	a10, sp, 128
	s32i	a11, sp, 132
	l32i	a10, a7, 144
	l32i	a11, a7, 148
	s32i	a10, sp, 120
	s32i	a11, sp, 124
	l32i	a10, a7, 136
	l32i	a11, a7, 140
	s32i	a10, sp, 112
	s32i	a11, sp, 116
	l32i	a5, a7, 132
	s32i	a5, sp, 104
	l32i	a5, a7, 128
	s32i	a12, sp, 92
	s32i	a8, sp, 80
	movi	a12, 0xa0
	l32i	a8, sp, 392
	add.n	a12, sp, a12
	s32i	a13, sp, 96
	movi	a13, 0x81
	add.n	a13, a12, a13
	s32i	a8, sp, 76
	l32i	a8, sp, 388
	s32i	a12, sp, 88
	s32i	a13, sp, 84
	s32i	a5, sp, 100
	s32i	a8, sp, 72
	l32i	a8, sp, 380
	l32i	a13, sp, 332
	s32i	a8, sp, 64
	l32i	a8, sp, 328
	s32i	a9, sp, 48
	s32i	a8, sp, 68
	l32i	a8, sp, 364
	s32i	a15, sp, 36
	s32i	a8, sp, 56
	l32i	a8, sp, 344
	l32i	a15, sp, 336
	s32i	a8, sp, 52
	movi	a8, 0x92
	add.n	a12, a12, a8
	l32i	a8, sp, 360
	s32i	a14, sp, 32
	s32i	a8, sp, 40
	l32i	a8, sp, 384
	l32i	a14, sp, 340
	s32i	a8, sp, 28
	l32i	a8, sp, 372
	s32i	a12, sp, 44
	s32i	a8, sp, 24
	l32i	a8, sp, 356
	s32i	a6, sp, 4
	s32i	a8, sp, 20
	l32i	a8, sp, 368
	s32i	a8, sp, 16
	l32i	a8, sp, 396
	s32i	a8, sp, 12
	l32i	a8, sp, 352
	s32i	a8, sp, 8
	l32i	a8, sp, 376
	s32i	a8, sp, 0
	l32r	a12, .LC849
	l32r	a11, .LC850
	l32i	a10, sp, 348
	call8	snprintf
	movi.n	a8, -1
	extui	a8, a8, 18, 14
	bgeu	a8, a10, .L1355
	l32i	a8, sp, 320
	beqz.n	a8, .L1356
	l32r	a3, .LC827
.L1356:
	l32r	a13, .LC852
	l32i	a11, sp, 340
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	l32i	a8, sp, 320
	bnez.n	a8, .L1357
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1358
	l32r	a8, .LC854
	add.n	a8, a2, a8
	s32i	a6, a8, 0
	j	.L1357
.L1358:
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console7untrackEm
	j	.L1357
.L1355:
	addi.n	a10, a10, -1
	l8ui	a9, a7, 8
	s32i	a10, sp, 316
	movi.n	a8, 0
	bnei	a9, 1, .L1359
	l8ui	a8, a7, 88
	beqz.n	a8, .L1359
	l8ui	a8, a7, 92
	addi	a8, a8, -6
	nsau	a8, a8
	srli	a8, a8, 5
.L1359:
	l8ui	a9, a7, 0
	l32r	a14, .LC836
	bnez.n	a9, .L1360
	l32r	a14, .LC840
	bnez.n	a4, .L1360
	l32r	a14, .LC841
	beqz.n	a8, .L1360
	l32r	a14, .LC838
.L1360:
	movi	a7, 0x13c
	add.n	a7, sp, a7
	l32r	a13, .LC856
	l32r	a11, .LC850
	l32i	a10, sp, 348
	mov.n	a12, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1336
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	beqz.n	a10, .L1336
	l32i	a9, sp, 320
	movi.n	a8, 0
	movnez	a6, a8, a9
	movi.n	a12, 0
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L1357:
	movi.n	a8, 1
	s32i	a8, sp, 324
.L1336:
	l32i	a2, sp, 324
	retw.n
.LFE1200:
	.size	_ZN21MotorControlRSExample5Probe7Console11formatProbeEmmhmRKNS0_11ProbeResultEb, .-_ZN21MotorControlRSExample5Probe7Console11formatProbeEmmhmRKNS0_11ProbeResultEb
	.literal_position
	.literal .LC858, 35380
	.literal .LC859, 35196
	.literal .LC860, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console11reportProbeEmhmRKNS0_11ProbeResultEPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console11reportProbeEmhmRKNS0_11ProbeResultEPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console11reportProbeEmhmRKNS0_11ProbeResultEPKNS_9HostTupleEm:
.LFB1199:
	entry	sp, 48
.LCFI67:
	l32i	a12, sp, 48
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	extui	a4, a4, 0, 8
	beqz.n	a8, .L1406
.L1408:
	movi.n	a2, 0
	j	.L1407
.L1406:
	l32r	a8, .LC858
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1408
	l32r	a7, .LC859
	l32r	a9, .LC860
	add.n	a7, a2, a7
	add.n	a9, a2, a9
	j	.L1409
.L1412:
	l32i	a8, a7, 0
	bne	a8, a3, .L1410
	l32i	a8, a7, 4
	bne	a8, a5, .L1410
	l8ui	a8, a7, 8
	bnez.n	a8, .L1410
	l8ui	a9, a7, 9
	s32i	a8, a2, 148
	s8i	a9, a2, 141
	s32i	a8, a2, 144
	mov.n	a10, a2
	s32i	a8, sp, 0
	mov.n	a15, a6
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console11formatProbeEmmhmRKNS0_11ProbeResultEb
	mov.n	a2, a10
	beqz.n	a10, .L1408
	l32i	a8, a7, 4
	bne	a8, a5, .L1407
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L1407
.L1410:
	addi.n	a7, a7, 12
.L1409:
	bne	a7, a9, .L1412
	j	.L1408
.L1407:
	retw.n
.LFE1199:
	.size	_ZN21MotorControlRSExample5Probe7Console11reportProbeEmhmRKNS0_11ProbeResultEPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console11reportProbeEmhmRKNS0_11ProbeResultEPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC867:
	.string	"read"
.LC869:
	.string	"update"
.LC876:
	.string	",\"requested_choice\":%u,\"active_policy_qualified\":false"
.LC878:
	.string	",\"requested_native\":%u,\"physical_scaling_known\":false"
.LC880:
	.string	"homing_auxiliary"
.LC882:
	.string	"control_settings"
.LC884:
	.string	"position_start_speed"
.LC886:
	.string	"drive"
.LC888:
	.string	"position_segment"
.LC891:
	.string	"segment_start_speed"
.LC893:
	.string	"speed_segment"
.LC895:
	.string	"stored_readback"
.LC897:
	.string	"checked_ack_readback"
.LC902:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"driver\""
	.ascii	":true,\"driver_kind\":\"%s\",\"ok\":%s,\"state\":\"%s\",\"ou"
	.ascii	"tcome\":\"%s\",\"status\":\"%s\",\"detail\":%ld,\"target\":%"
	.ascii	"lu,\"address\":%u,\"generation\":%lu,\"configuration_generat"
	.ascii	"ion\":%lu,\"started_us\":%llu,\"deadline_us\":%llu,\"station"
	.ascii	"ary_valid_until_us\":%llu,\"serviced_us\":%llu,\"com"
	.string	"pleted_steps\":%u,\"fields\":%u,\"effects\":%u,\"uncertain\":%s,\"atomic\":false,\"active_settings_known\":false,\"progress_columns\":[\"field\",\"register\",\"previous\",\"requested\",\"acknowledged\",\"readback_known\",\"readback\",\"active_known\",\"active\",\"execution\"],\"progress\":["
.LC905:
	.string	"%s[%u,%u,%u,%u,%s,%s,%u,%s,%u,\"%s\"]"
.LC907:
	.ascii	"],\"evidence_columns\":[\"step\",\"registe"
	.string	"r\",\"count\",\"write\",\"event\",\"raw_hex\",\"received_length\",\"tx_accepted\",\"tx_complete\",\"response_confirmed\",\"qualified\",\"execution_unknown\",\"earliest_us\",\"latest_us\",\"delivered_us\",\"transport_detail\",\"status\",\"detail\",\"frame_error\",\"attempted_us\"],\"evidence\":["
.LC910:
	.string	"%s[%u,%u,%u,%s,%u,\"%s\",%u,%u,%s,%s,%s,%s,%llu,%llu,%llu,%ld,\"%s\",%ld,%u,%llu]"
.LC912:
	.string	"],\"observation\":"
.LC918:
	.string	"{\"raw\":[%u],\"known_fields\":%u}"
.LC920:
	.string	"{\"raw\":[%u,%u,%u,%u,%u,%u,%u,%u,%u],\"known_fields\":%u,\"unknown_input_polarity_bits\":%u,\"unknown_output_polarity_bits\":%u,\"unknown_custom_output_bits\":%u}"
.LC922:
	.string	"signed encoding not qualified"
.LC924:
	.string	"{\"raw\":[%u,%u,%u,%u,%u],\"known_fields\":%u,\"paired_write_supported\":false,\"signed_encoding\":\"unresolved\",\"active_settings_known\":false}"
.LC926:
	.string	"{\"raw\":["
.LC929:
	.string	"],\"known_fields\":%u,\"native_units_only\":true,\"physical_scaling_known\":false,\"active_settings_known\":false}"
.LC931:
	.ascii	"{\"raw\":[%u,%u,%u,%u,%u,%u,%u,%u],\"known_fields\":%u,\"alg"
	.ascii	"orithm_known\":%s,\"encoder_s"
	.string	"cale_usable\":%s,\"encoder_resolution\":%u,\"maximum_effective_current_ma\":%u,\"closed_maximum_percent\":%u,\"closed_base_percent\":%u,\"open_maximum_percent\":%u,\"lock_percent\":%u,\"lock_delay_ms\":%u,\"current_percent_base\":\"unresolved\",\"active_settings_known\":false}"
.LC933:
	.string	"{\"raw\":[%u,%u,%u,%u,%u,%u,%u],\"known_fields\":%u,\"positive_words\":[%u,%u],\"negative_words\":[%u,%u],\"pair_known\":%s,\"positive_bits\":%lu,\"negative_bits\":%lu,\"signed_limits\":\"unresolved\",\"native_scale\":\"unresolved\"}"
.LC935:
	.string	",\"prior\":{\"operation_id\":%lu,\"raw\":%u,\"known_fields\":%u,\"raw_hex\":\"%s\",\"attempted_us\":%llu,\"earliest_us\":%llu,\"latest_us\":%llu,\"delivered_us\":%llu}"
.LC938:
	.string	",\"driver_group\":\"%s\",\"echo_readback_policy\":%s,\"settlement\":\"%s\"}"
.LC940:
	.string	",\"segment_index\":%u,\"execution_path\":\"external_input\",\"storage_capacity\":16,\"maximum_input_selections\":8}"
	.text
	.literal_position
	.literal .LC861, .LC558
	.literal .LC862, .LC560
	.literal .LC863, .LC586
	.literal .LC864, .LC578
	.literal .LC865, .LC807
	.literal .LC866, .LC809
	.literal .LC868, .LC867
	.literal .LC870, .LC869
	.literal .LC871, .LC363
	.literal .LC872, .LC361
	.literal .LC873, .LC107
	.literal .LC874, .LC386
	.literal .LC875, .LC318
	.literal .LC877, .LC876
	.literal .LC879, .LC878
	.literal .LC881, .LC880
	.literal .LC883, .LC882
	.literal .LC885, .LC884
	.literal .LC887, .LC886
	.literal .LC889, .LC888
	.literal .LC890, .LC580
	.literal .LC892, .LC891
	.literal .LC894, .LC893
	.literal .LC896, .LC895
	.literal .LC898, .LC897
	.literal .LC899, CSWTCH$1591
	.literal .LC900, CSWTCH$1341
	.literal .LC901, CSWTCH$1345
	.literal .LC903, .LC902
	.literal .LC904, 16384
	.literal .LC906, .LC905
	.literal .LC908, .LC907
	.literal .LC911, .LC910
	.literal .LC913, .LC912
	.literal .LC914, .LC422
	.literal .LC915, 34592
	.literal .LC916, 34652
	.literal .LC917, 34616
	.literal .LC919, .LC918
	.literal .LC921, .LC920
	.literal .LC923, .LC922
	.literal .LC925, .LC924
	.literal .LC927, .LC926
	.literal .LC928, .LC492
	.literal .LC930, .LC929
	.literal .LC932, .LC931
	.literal .LC934, .LC933
	.literal .LC936, .LC935
	.literal .LC937, CSWTCH$1335
	.literal .LC939, .LC938
	.literal .LC941, .LC940
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console12formatDriverEmmmRKN14MotorControlRS6ESS_RS13DriverContextEb
	.type	_ZN21MotorControlRSExample5Probe7Console12formatDriverEmmmRKN14MotorControlRS6ESS_RS13DriverContextEb, @function
_ZN21MotorControlRSExample5Probe7Console12formatDriverEmmmRKN14MotorControlRS6ESS_RS13DriverContextEb:
.LFB1206:
	entry	sp, 512
.LCFI68:
	extui	a8, a7, 0, 8
	s32i	a8, sp, 416
	movi.n	a8, 0
	s32i	a8, sp, 380
	l8ui	a8, a6, 0
	s32i	a2, sp, 392
	mov.n	a10, a8
	s32i	a8, sp, 388
	s32i	a3, sp, 456
	s32i	a4, sp, 460
	s32i	a5, sp, 404
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	l8ui	a8, a6, 0
	s32i	a10, sp, 400
	s32i	a8, sp, 396
	l32i	a9, sp, 396
	movi.n	a8, 0xb
	l32r	a7, .LC861
	beq	a9, a8, .L1417
	l32r	a7, .LC862
	beqi	a9, 10, .L1417
	l32r	a7, .LC863
	bnez.n	a10, .L1417
	l32i	a8, sp, 388
	l32r	a7, .LC864
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 8
	bgeui	a8, 5, .L1417
	l32r	a9, .LC899
	addx4	a8, a8, a9
	l32i	a7, a8, 0
.L1417:
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS19driverWriteDeadlineERKNS0_13DriverContextE
	l32i	a9, sp, 392
	movi	a8, 0x124
	add.n	a8, a9, a8
	s32i	a8, sp, 384
	l32i	a8, sp, 416
	s32i	a10, sp, 464
	s32i	a11, sp, 468
	s32i	a7, sp, 408
	beqz.n	a8, .L1418
	l32r	a8, .LC865
	l32r	a7, .LC866
	s32i	a8, sp, 408
.L1418:
	l8ui	a8, a6, 24
	l32r	a3, .LC870
	bnez.n	a8, .L1419
	l32r	a3, .LC868
.L1419:
	l8ui	a8, a6, 25
	beqi	a8, 2, .L1490
	l32r	a9, .LC871
	l32r	a2, .LC873
	s32i	a9, sp, 412
	bgeui	a8, 4, .L1421
	j	.L1420
.L1490:
	l32r	a9, .LC872
	s32i	a9, sp, 412
.L1420:
	l32r	a9, .LC900
	addx4	a8, a8, a9
	l32i	a2, a8, 0
.L1421:
	l8ui	a8, a6, 26
	movi.n	a9, 9
	l32r	a4, .LC873
	bltu	a9, a8, .L1422
	l32r	a9, .LC901
	addx4	a8, a8, a9
	l32i	a4, a8, 0
.L1422:
	addmi	a5, a6, 0xe00
	l8ui	a10, a5, 144
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a6, 4
	l32i	a9, a5, 148
	s32i	a8, sp, 424
	addmi	a8, a6, 0x600
	l32i	a14, a8, 80
	l32i	a15, a8, 84
	s32i	a14, sp, 432
	l32i	a14, a8, 88
	s32i	a15, sp, 436
	s32i	a14, sp, 440
	l32i	a15, a8, 92
	l32i	a14, a8, 96
	s32i	a15, sp, 444
	s32i	a14, sp, 448
	l32i	a15, a8, 100
	l8ui	a14, a8, 113
	l32i	a8, a5, 136
	l8ui	a5, a5, 140
	s32i	a15, sp, 452
	s32i	a8, sp, 428
	l8ui	a11, a6, 8
	l32i	a12, a6, 12
	l32i	a13, a6, 20
	l32i	a15, a6, 36
	l32r	a8, .LC871
	beqz.n	a5, .L1423
	l32r	a8, .LC872
.L1423:
	s32i	a8, sp, 100
	l32i	a8, sp, 428
	s32i	a15, sp, 92
	s32i	a8, sp, 96
	movi	a8, 0x1c0
	s32i	a14, sp, 88
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32i	a15, a8, 4
	l32i	a8, sp, 464
	s32i	a14, sp, 80
	s32i	a8, sp, 72
	l32i	a8, sp, 468
	s32i	a15, sp, 84
	s32i	a8, sp, 76
	movi	a8, 0x1b8
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32i	a15, a8, 4
	movi	a8, 0x1b0
	s32i	a14, sp, 64
	s32i	a15, sp, 68
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32i	a15, a8, 4
	l32i	a8, sp, 424
	movi	a5, 0x17c
	add.n	a5, sp, a5
	s32i	a8, sp, 36
	l32i	a8, sp, 412
	s32i	a14, sp, 56
	s32i	a15, sp, 60
	s32i	a13, sp, 48
	s32i	a12, sp, 44
	s32i	a11, sp, 40
	s32i	a10, sp, 28
	s32i	a5, sp, 420
	s32i	a9, sp, 32
	s32i	a4, sp, 24
	s32i	a2, sp, 20
	s32i	a8, sp, 16
	l32i	a8, sp, 404
	l32i	a15, sp, 456
	s32i	a8, sp, 8
	l32i	a8, sp, 460
	l32i	a14, sp, 408
	l32r	a13, .LC903
	l32r	a11, .LC904
	l32i	a10, sp, 384
	s32i	a3, sp, 12
	s32i	a8, sp, 4
	s32i	a7, sp, 0
	mov.n	a12, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	movi	a7, 0x684
	movi	a5, 0x7c4
	add.n	a7, a6, a7
	add.n	a5, a6, a5
	movi.n	a10, 0
	j	.L1426
.L1433:
	l8ui	a8, a7, 12
	beqz.n	a8, .L1427
	l32r	a4, .LC875
	beqz.n	a10, .L1428
	l32r	a4, .LC874
.L1428:
	l8ui	a8, a7, 13
	l32i	a15, a7, 0
	l16ui	a2, a7, 4
	l16ui	a12, a7, 6
	l16ui	a13, a7, 8
	l32r	a3, .LC871
	beqz.n	a8, .L1429
	l32r	a3, .LC872
.L1429:
	l8ui	a9, a7, 14
	l32r	a8, .LC871
	beqz.n	a9, .L1430
	l32r	a8, .LC872
.L1430:
	l8ui	a10, a7, 15
	l16ui	a14, a7, 10
	l32r	a9, .LC871
	beqz.n	a10, .L1431
	l32r	a9, .LC872
.L1431:
	l8ui	a10, a7, 18
	s32i	a8, sp, 448
	s32i	a9, sp, 440
	s32i	a14, sp, 432
	s32i	a13, sp, 424
	s32i	a12, sp, 412
	s32i	a15, sp, 408
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	s32i	a10, sp, 32
	l16ui	a10, a7, 16
	l32i	a13, sp, 424
	l32i	a12, sp, 412
	l32i	a14, sp, 432
	l32i	a9, sp, 440
	l32i	a8, sp, 448
	s32i	a10, sp, 28
	s32i	a13, sp, 8
	s32i	a12, sp, 4
	l32i	a15, sp, 408
	l32r	a13, .LC906
	l32i	a12, sp, 420
	l32r	a11, .LC904
	l32i	a10, sp, 384
	s32i	a14, sp, 20
	s32i	a9, sp, 24
	s32i	a8, sp, 16
	s32i	a3, sp, 12
	s32i	a2, sp, 0
	mov.n	a14, a4
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
.L1427:
	addi	a7, a7, 20
.L1426:
	bne	a7, a5, .L1433
	addi	a5, sp, 112
	movi	a12, 0x10c
	l32r	a13, .LC908
	l32r	a11, .LC904
	l32i	a10, sp, 384
	add.n	a12, a5, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	movi	a8, 0x88
	addmi	a8, a8, 0xe00
	movi	a7, 0x7c8
	add.n	a8, a6, a8
	add.n	a7, a6, a7
	s32i	a8, sp, 428
	movi.n	a3, 0
.L1442:
	l16ui	a4, a7, 4
	beqz.n	a4, .L1434
	l32i	a11, a7, 24
	mov.n	a12, a5
	movi.n	a13, 0x1f
	addi.n	a10, a7, 8
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32r	a12, .LC875
	beqz.n	a3, .L1435
	l32r	a12, .LC874
.L1435:
	l16ui	a8, a7, 2
	l8ui	a15, a7, 0
	s32i	a8, sp, 408
	l8ui	a8, a7, 6
	l32r	a3, .LC871
	beqz.n	a8, .L1436
	l32r	a3, .LC872
.L1436:
	l8ui	a8, a7, 7
	l32r	a2, .LC871
	s32i	a8, sp, 412
	l32i	a8, a7, 28
	s32i	a8, sp, 420
	l32i	a8, a7, 32
	s32i	a8, sp, 424
	l8ui	a8, a7, 36
	beqz.n	a8, .L1437
	l32r	a2, .LC872
.L1437:
	l8ui	a9, a7, 37
	l32r	a8, .LC871
	beqz.n	a9, .L1438
	l32r	a8, .LC872
.L1438:
	l8ui	a10, a7, 38
	l32r	a9, .LC871
	beqz.n	a10, .L1439
	l32r	a9, .LC872
.L1439:
	l8ui	a10, a7, 39
	l32r	a11, .LC871
	beqz.n	a10, .L1440
	l32r	a11, .LC872
.L1440:
	s32i	a8, sp, 476
	s32i	a9, sp, 468
	l32i	a8, a7, 48
	l32i	a9, a7, 52
	s32i	a8, sp, 432
	s32i	a9, sp, 436
	l32i	a8, a7, 56
	l32i	a9, a7, 60
	l32i	a13, a7, 72
	l8ui	a10, a7, 76
	s32i	a8, sp, 440
	s32i	a9, sp, 444
	l32i	a8, a7, 64
	l32i	a9, a7, 68
	s32i	a11, sp, 472
	s32i	a12, sp, 464
	s32i	a15, sp, 460
	s32i	a8, sp, 448
	s32i	a9, sp, 452
	s32i	a13, sp, 456
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a7, 40
	l32i	a9, a7, 44
	s32i	a8, sp, 88
	s32i	a9, sp, 92
	l8ui	a14, a7, 88
	l32i	a13, sp, 456
	s32i	a14, sp, 84
	l32i	a14, a7, 80
	movi	a8, 0x1c0
	s32i	a14, sp, 80
	s32i	a10, sp, 76
	s32i	a13, sp, 72
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	movi	a8, 0x1b8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 60
	s32i	a8, sp, 56
	movi	a8, 0x1b0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 52
	s32i	a8, sp, 48
	l32i	a11, sp, 472
	l32i	a8, sp, 476
	l32i	a9, sp, 468
	s32i	a8, sp, 32
	l32i	a8, sp, 424
	s32i	a11, sp, 40
	s32i	a8, sp, 24
	l32i	a8, sp, 420
	l32i	a15, sp, 460
	s32i	a8, sp, 20
	l32i	a8, sp, 412
	l32i	a14, sp, 464
	s32i	a8, sp, 12
	l32i	a8, sp, 408
	l32r	a13, .LC911
	l32r	a11, .LC904
	l32i	a10, sp, 384
	movi	a12, 0x10c
	s32i	a3, sp, 8
	s32i	a9, sp, 36
	s32i	a2, sp, 28
	s32i	a5, sp, 16
	s32i	a4, sp, 4
	s32i	a8, sp, 0
	add.n	a12, a5, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a3, a10
	bnez.n	a10, .L1434
.L1425:
	movi.n	a2, 0
	j	.L1567
.L1434:
	l32i	a8, sp, 428
	addi	a7, a7, 96
	bne	a7, a8, .L1442
	addi	a5, sp, 112
	movi	a4, 0x10c
	add.n	a4, a5, a4
	l32r	a13, .LC913
	l32r	a11, .LC904
	l32i	a10, sp, 384
	mov.n	a12, a4
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	l32i	a8, sp, 388
	addi	a8, a8, -2
	extui	a2, a8, 0, 8
	l32i	a8, sp, 396
	addi	a3, a8, -10
	l8ui	a8, a6, 24
	extui	a3, a3, 0, 8
	beqz.n	a8, .L1443
.L1445:
	movi	a12, 0x17c
	l32r	a13, .LC914
	l32r	a11, .LC904
	l32i	a10, sp, 384
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1444
	j	.L1425
.L1443:
	l32r	a7, .LC915
	l32i	a8, sp, 392
	mov.n	a10, a6
	add.n	a7, a8, a7
	mov.n	a11, a7
	call8	_ZN14MotorControlRS6ESS_RS9getDriverERKNS0_13DriverContextERNS0_17DriverObservationE
	s32i	a10, sp, 112
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	extui	a10, a10, 0, 8
	bnez.n	a10, .L1445
	bgeui	a3, 2, .L1446
	l32i	a8, sp, 392
	l32r	a9, .LC916
	l32i	a10, sp, 392
	add.n	a9, a8, a9
	l32r	a8, .LC917
	l32i	a15, a9, 0
	add.n	a8, a10, a8
	l16ui	a14, a8, 0
	l32r	a13, .LC919
	l32r	a11, .LC904
	l32i	a10, sp, 384
	mov.n	a12, a4
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
.L1469:
	l32i	a9, sp, 396
	movi.n	a8, 0xb
	bne	a9, a8, .L1568
	j	.L1447
.L1446:
	l32i	a8, sp, 388
	bnei	a8, 1, .L1449
	l16ui	a10, a7, 54
	l16ui	a9, a7, 48
	movi.n	a8, -4
	l16ui	a14, a7, 38
	and	a11, a10, a8
	and	a8, a9, a8
	l16ui	a15, a7, 40
	s32i	a8, sp, 36
	movi.n	a8, -0x10
	and	a8, a14, a8
	s32i	a11, sp, 40
	s32i	a8, sp, 32
	l32i	a8, a7, 60
	s32i	a10, sp, 24
	s32i	a8, sp, 28
	l16ui	a8, a7, 52
	l32r	a13, .LC921
	s32i	a8, sp, 20
	l16ui	a8, a7, 50
	s32i	a9, sp, 12
	s32i	a8, sp, 16
	l16ui	a8, a7, 46
	l32r	a11, .LC904
	s32i	a8, sp, 8
	l16ui	a8, a7, 44
	l32i	a10, sp, 384
	s32i	a8, sp, 4
	l16ui	a8, a7, 42
	mov.n	a12, a4
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1473
	j	.L1425
.L1449:
	bgeui	a2, 3, .L1451
	movi	a12, 0x98
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a8, 1
	s8i	a8, sp, 113
	l32r	a8, .LC923
	mov.n	a11, a5
	s32i	a8, sp, 160
	l32r	a8, .LC875
	movi.n	a13, 0
	s32i	a8, sp, 252
	movi.n	a12, 0
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS10getSegmentERKNS0_13DriverContextERNS0_18SegmentObservationEbNS0_9WordOrderE
	s32i	a10, a5, 256
	s32i	a11, a5, 260
	s32i	a12, a5, 264
	extui	a10, a10, 0, 8
	addmi	a5, a5, 0x100
	bnez.n	a10, .L1425
	l32i	a8, a7, 60
	l16ui	a15, a7, 26
	l16ui	a14, a7, 24
	s32i	a8, sp, 12
	l16ui	a8, a7, 32
	l32r	a13, .LC925
	s32i	a8, sp, 8
	l16ui	a8, a7, 30
	l32r	a11, .LC904
	s32i	a8, sp, 4
	l16ui	a8, a7, 28
	l32i	a10, sp, 384
	s32i	a8, sp, 0
	mov.n	a12, a4
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	l32i	a8, sp, 400
	bnez.n	a8, .L1454
	j	.L1455
.L1451:
	l32i	a8, sp, 400
	beqz.n	a8, .L1456
	movi	a12, 0xf0
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a8, 6
	s8i	a8, sp, 112
	l32r	a8, .LC875
	mov.n	a11, a5
	s32i	a8, sp, 244
	s32i	a8, sp, 340
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS9getTuningERKNS0_13DriverContextERNS0_17TuningObservationE
	s32i	a10, a5, 256
	s32i	a11, a5, 260
	s32i	a12, a5, 264
	extui	a7, a10, 0, 8
	addmi	a5, a5, 0x100
	bnez.n	a7, .L1425
	l32r	a13, .LC927
	l32r	a11, .LC904
	l32i	a10, sp, 384
	mov.n	a12, a4
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	addi	a5, sp, 112
	bnez.n	a10, .L1459
	j	.L1425
.L1461:
	l32r	a14, .LC875
	beqz.n	a7, .L1460
	l32r	a14, .LC874
.L1460:
	addx2	a8, a7, a5
	movi	a12, 0x10c
	l16ui	a15, a8, 30
	l32r	a13, .LC928
	l32r	a11, .LC904
	l32i	a10, sp, 384
	add.n	a12, a5, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
.L1459:
	l8ui	a8, sp, 140
	bltu	a7, a8, .L1461
	movi	a12, 0x10c
	l32i	a14, sp, 136
	l32r	a13, .LC930
	l32r	a11, .LC904
	l32i	a10, sp, 384
	add.n	a12, a5, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1454
	j	.L1425
.L1456:
	l32i	a8, sp, 388
	bnei	a8, 5, .L1462
	movi	a12, 0x100
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a8, 1
	s16i	a8, sp, 152
	l32r	a8, .LC875
	mov.n	a11, a5
	s32i	a8, sp, 260
	s32i	a8, sp, 356
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS10getControlERKNS0_13DriverContextERNS0_18ControlObservationE
	s32i	a10, a5, 256
	s32i	a11, a5, 260
	s32i	a12, a5, 264
	extui	a10, a10, 0, 8
	addmi	a5, a5, 0x100
	bnez.n	a10, .L1425
	l8ui	a9, sp, 154
	l16ui	a14, sp, 136
	l16ui	a15, sp, 138
	l16ui	a10, sp, 140
	l16ui	a11, sp, 142
	l16ui	a12, sp, 144
	l16ui	a13, sp, 146
	l16ui	a7, sp, 148
	l16ui	a5, sp, 150
	l32i	a4, sp, 132
	l32r	a8, .LC871
	beqz.n	a9, .L1465
	l32r	a8, .LC872
.L1465:
	l8ui	a3, sp, 155
	l32r	a9, .LC871
	beqz.n	a3, .L1466
	l32r	a9, .LC872
.L1466:
	l16ui	a3, sp, 168
	s32i	a13, sp, 12
	s32i	a3, sp, 60
	l16ui	a3, sp, 166
	s32i	a12, sp, 8
	s32i	a3, sp, 56
	l16ui	a3, sp, 164
	s32i	a11, sp, 4
	s32i	a3, sp, 52
	l16ui	a3, sp, 162
	s32i	a10, sp, 0
	s32i	a3, sp, 48
	l16ui	a3, sp, 160
	movi	a12, 0x17c
	s32i	a3, sp, 44
	l16ui	a3, sp, 158
	l32r	a13, .LC932
	s32i	a3, sp, 40
	l16ui	a3, sp, 156
	l32r	a11, .LC904
	l32i	a10, sp, 384
	s32i	a3, sp, 36
	s32i	a9, sp, 32
	s32i	a8, sp, 28
	s32i	a4, sp, 24
	s32i	a5, sp, 20
	s32i	a7, sp, 16
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
.L1474:
	l32r	a14, .LC883
	j	.L1467
.L1462:
	l16ui	a8, a7, 28
	l16ui	a14, a7, 24
	s32i	a8, sp, 396
	l16ui	a8, a7, 30
	l16ui	a15, a7, 26
	s32i	a8, sp, 408
	l16ui	a8, a7, 70
	l16ui	a10, a7, 32
	s32i	a8, sp, 412
	l8ui	a8, a7, 72
	l16ui	a11, a7, 34
	l16ui	a12, a7, 36
	l32i	a13, a7, 60
	l16ui	a5, a7, 64
	l16ui	a4, a7, 66
	l16ui	a3, a7, 68
	l32r	a7, .LC871
	beqz.n	a8, .L1468
	l32r	a7, .LC872
.L1468:
	l32i	a9, sp, 392
	l32r	a8, .LC915
	add.n	a8, a9, a8
	l32i	a9, a8, 80
	s32i	a9, sp, 48
	l32i	a8, a8, 76
	s32i	a13, sp, 20
	s32i	a8, sp, 44
	l32i	a8, sp, 412
	s32i	a12, sp, 16
	s32i	a8, sp, 36
	l32i	a8, sp, 408
	s32i	a11, sp, 12
	s32i	a8, sp, 4
	l32i	a8, sp, 396
	s32i	a10, sp, 8
	movi	a12, 0x17c
	l32r	a13, .LC934
	l32r	a11, .LC904
	l32i	a10, sp, 384
	s32i	a7, sp, 40
	s32i	a3, sp, 32
	s32i	a4, sp, 28
	s32i	a5, sp, 24
	s32i	a8, sp, 0
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
.L1476:
	l32r	a14, .LC887
	j	.L1467
.L1444:
	bltui	a3, 2, .L1469
	j	.L1473
.L1447:
	l16ui	a14, a6, 46
	l32r	a13, .LC877
	j	.L1470
.L1568:
	l16ui	a14, a6, 44
	l32r	a13, .LC879
.L1470:
	addi	a5, sp, 112
	movi	a7, 0x10c
	add.n	a7, a5, a7
	l32r	a11, .LC904
	l32i	a10, sp, 384
	mov.n	a12, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	l32i	a11, a6, 288
	movi	a10, 0x110
	movi.n	a13, 0x1f
	mov.n	a12, a5
	add.n	a10, a6, a10
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a8, a6, 328
	l32i	a9, a6, 332
	s32i	a8, sp, 32
	s32i	a9, sp, 36
	l32i	a8, a6, 320
	l32i	a9, a6, 324
	s32i	a8, sp, 24
	s32i	a9, sp, 28
	l32i	a8, a6, 312
	l32i	a9, a6, 316
	s32i	a8, sp, 16
	s32i	a9, sp, 20
	l32i	a8, a6, 304
	l32i	a9, a6, 308
	s32i	a8, sp, 8
	s32i	a9, sp, 12
	s32i	a5, sp, 4
	l32i	a8, a6, 236
	l32r	a13, .LC936
	s32i	a8, sp, 0
	l16ui	a15, a6, 200
	l32i	a14, a6, 192
	l32r	a11, .LC904
	l32i	a10, sp, 384
	mov.n	a12, a7
	addmi	a4, a6, 0x100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	l32i	a9, sp, 396
	movi.n	a8, 0xb
	l32r	a14, .LC881
	beq	a9, a8, .L1467
	l32r	a14, .LC885
	beqi	a9, 10, .L1467
	j	.L1473
.L1454:
	l8ui	a8, a6, 0
	l32r	a14, .LC873
	addi	a8, a8, -6
	extui	a8, a8, 0, 8
	bgeui	a8, 4, .L1467
	l32r	a9, .LC937
	addx4	a8, a8, a9
	l32i	a14, a8, 0
	j	.L1467
.L1569:
	l32i	a8, sp, 388
	beqi	a8, 5, .L1474
	bgeui	a2, 3, .L1475
.L1455:
	l8ui	a8, a6, 0
	l32r	a14, .LC889
	beqi	a8, 2, .L1467
	l32r	a14, .LC892
	bnei	a8, 3, .L1467
	l32r	a14, .LC894
	j	.L1467
.L1475:
	l32i	a8, sp, 388
	bnei	a8, 1, .L1476
	l32r	a14, .LC890
.L1467:
	addmi	a8, a6, 0x300
	l8ui	a8, a8, 168
	l32r	a15, .LC871
	beqz.n	a8, .L1477
	l32r	a15, .LC872
.L1477:
	l32i	a8, sp, 388
	addi.n	a9, a8, -1
	extui	a9, a9, 0, 8
	l32r	a8, .LC896
	bltui	a9, 5, .L1478
	l32i	a9, sp, 400
	bnez.n	a9, .L1478
	l32r	a8, .LC898
.L1478:
	addi	a7, sp, 112
	movi	a5, 0x10c
	add.n	a5, a7, a5
	l32r	a13, .LC939
	l32r	a11, .LC904
	l32i	a10, sp, 384
	s32i	a8, sp, 0
	mov.n	a12, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1425
	bltui	a2, 3, .L1479
.L1481:
	l32i	a10, sp, 392
	movi	a11, 0x10c
	add.n	a11, a7, a11
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	bnez.n	a10, .L1480
	j	.L1425
.L1479:
	l32i	a8, sp, 380
	l8ui	a14, a6, 98
	l32r	a13, .LC941
	l32r	a11, .LC904
	l32i	a10, sp, 384
	addi.n	a8, a8, -1
	mov.n	a12, a5
	s32i	a8, sp, 380
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1481
	j	.L1425
.L1480:
	l32i	a9, sp, 404
	l32i	a10, sp, 416
	movi.n	a8, 0
	movnez	a9, a8, a10
	l32i	a10, sp, 392
	movi.n	a12, 0
	mov.n	a11, a9
	s32i	a9, sp, 404
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L1567
.L1473:
	l32i	a8, sp, 400
	bnez.n	a8, .L1454
	j	.L1569
.L1567:
	retw.n
.LFE1206:
	.size	_ZN21MotorControlRSExample5Probe7Console12formatDriverEmmmRKN14MotorControlRS6ESS_RS13DriverContextEb, .-_ZN21MotorControlRSExample5Probe7Console12formatDriverEmmmRKN14MotorControlRS6ESS_RS13DriverContextEb
	.literal_position
	.literal .LC943, 35380
	.literal .LC944, 35196
	.literal .LC945, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console12reportDriverEmmRKN14MotorControlRS6ESS_RS13DriverContextEPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console12reportDriverEmmRKN14MotorControlRS6ESS_RS13DriverContextEPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console12reportDriverEmmRKN14MotorControlRS6ESS_RS13DriverContextEPKNS_9HostTupleEm:
.LFB1205:
	entry	sp, 32
.LCFI69:
	mov.n	a12, a7
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1571
.L1573:
	movi.n	a2, 0
	j	.L1572
.L1571:
	l32r	a8, .LC943
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1573
	l32i	a8, a5, 16
	bne	a8, a4, .L1573
	l8ui	a8, a5, 25
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L1573
	l32r	a7, .LC944
	l32r	a8, .LC945
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	j	.L1574
.L1577:
	l32i	a9, a7, 0
	bne	a9, a3, .L1575
	l32i	a9, a7, 4
	bne	a9, a4, .L1575
	l8ui	a9, a7, 8
	bnez.n	a9, .L1575
	l8ui	a8, a7, 9
	mov.n	a10, a2
	s8i	a8, a2, 141
	s32i	a9, a2, 148
	s32i	a9, a2, 144
	movi.n	a15, 0
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console12formatDriverEmmmRKN14MotorControlRS6ESS_RS13DriverContextEb
	mov.n	a2, a10
	beqz.n	a10, .L1573
	l32i	a8, a7, 4
	bne	a8, a4, .L1572
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L1572
.L1575:
	addi.n	a7, a7, 12
.L1574:
	bne	a7, a8, .L1577
	j	.L1573
.L1572:
	retw.n
.LFE1205:
	.size	_ZN21MotorControlRSExample5Probe7Console12reportDriverEmmRKN14MotorControlRS6ESS_RS13DriverContextEPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console12reportDriverEmmRKN14MotorControlRS6ESS_RS13DriverContextEPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC948:
	.string	"action"
.LC952:
	.string	"\"normal\""
.LC954:
	.string	"\"fast\""
.LC959:
	.string	"succeeded"
.LC962:
	.string	"observed"
.LC964:
	.string	"not_observed"
.LC974:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"action_k"
	.ascii	"ind\":\"%s\",\"stop_policy\":%s,\"read_kind\":null,\"capture"
	.ascii	"_read\":false,\"recovery\":fa"
	.string	"lse,\"ok\":%s,\"state\":\"%s\",\"outcome\":\"%s\",\"execution\":\"%s\",\"completion\":\"%s\",\"target\":%lu,\"address\":%u,\"generation\":%lu,\"started_us\":%llu,\"deadline_us\":%llu,\"serviced_us\":%llu,\"polls\":%u,\"observation_known\":%s,\"raw_alarm\":%s,\"raw_motion\":%s,\"write_evidence\":"
.LC977:
	.string	",\"last_observation\":"
.LC979:
	.string	",\"failure_evidence\":"
.LC981:
	.string	",\"interrupted_by_stop\":%s"
.LC985:
	.string	"%lu"
.LC987:
	.string	"[%u,%u]"
.LC989:
	.string	",\"device_position\":%lld,\"position_clear_qualified\":%s,\"raw_position\":%s,\"raw_position_words\":%s"
.LC991:
	.string	",\"replaced_operation_id\":%lu,\"stop_escalation\":%s"
	.section	.rodata
.LC983:
	.string	"null"
	.zero	11
	.text
	.literal_position
	.literal .LC946, .LC807
	.literal .LC947, .LC809
	.literal .LC949, .LC948
	.literal .LC950, .LC422
	.literal .LC951, .LC570
	.literal .LC953, .LC952
	.literal .LC955, .LC954
	.literal .LC956, .LC107
	.literal .LC957, .LC361
	.literal .LC958, .LC363
	.literal .LC960, .LC959
	.literal .LC961, .LC263
	.literal .LC963, .LC962
	.literal .LC965, .LC964
	.literal .LC966, .LC568
	.literal .LC967, .LC566
	.literal .LC968, .LC564
	.literal .LC969, -16776961
	.literal .LC970, .LC842
	.literal .LC971, .LC844
	.literal .LC972, CSWTCH$1361
	.literal .LC973, 16777218
	.literal .LC975, .LC974
	.literal .LC976, 16384
	.literal .LC978, .LC977
	.literal .LC980, .LC979
	.literal .LC982, .LC981
	.literal .LC984, .LC983
	.literal .LC986, .LC985
	.literal .LC988, .LC987
	.literal .LC990, .LC989
	.literal .LC992, .LC991
	.literal .LC993, .LC430
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console12formatActionEmmmRKN14MotorControlRS6ESS_RS13ActionContextEbbPKNS0_10ResultViewE
	.type	_ZN21MotorControlRSExample5Probe7Console12formatActionEmmmRKN14MotorControlRS6ESS_RS13ActionContextEbbPKNS0_10ResultViewE, @function
_ZN21MotorControlRSExample5Probe7Console12formatActionEmmmRKN14MotorControlRS6ESS_RS13ActionContextEbbPKNS0_10ResultViewE:
.LFB1216:
	entry	sp, 272
.LCFI70:
	extui	a8, a7, 0, 8
	s32i	a8, sp, 172
	movi	a8, 0x110
	add.n	a8, a8, sp
	l8ui	a8, a8, 0
	s32i	a4, sp, 220
	s32i	a8, sp, 224
	addi	a4, sp, 96
	movi.n	a8, 0
	l32i	a7, a6, 52
	l32r	a11, .LC970
	s32i	a2, sp, 160
	s32i	a8, sp, 144
	addi	a2, a4, 40
	l32r	a8, .LC969
	movi.n	a12, 5
	mov.n	a10, a2
	and	a7, a7, a8
	s32i	a3, sp, 216
	call8	memcpy
	movi.n	a12, 3
	movi.n	a11, 0
	addi	a10, a4, 45
	call8	memset
	l32r	a11, .LC970
	addi	a3, a4, 32
	movi.n	a12, 5
	mov.n	a10, a3
	call8	memcpy
	movi.n	a12, 3
	movi.n	a11, 0
	addi	a10, a4, 37
	call8	memset
	l8ui	a9, a6, 94
	beqz.n	a9, .L1584
	l8ui	a9, a6, 16
	beqi	a9, 4, .L1584
	l32r	a4, .LC971
	l16ui	a13, a6, 96
	mov.n	a12, a4
	movi.n	a11, 8
	mov.n	a10, a2
	call8	snprintf
	l16ui	a13, a6, 98
	mov.n	a12, a4
	movi.n	a11, 8
	mov.n	a10, a3
	call8	snprintf
.L1584:
	l32i	a8, sp, 160
	movi	a3, 0x124
	add.n	a3, a8, a3
	l32i	a8, sp, 172
	l8ui	a9, a6, 16
	bnez.n	a8, .L1585
	beqi	a9, 2, .L1613
	beqi	a9, 4, .L1614
	beqi	a9, 1, .L1615
	bgeui	a9, 5, .L1616
	l32r	a8, .LC972
	l32r	a4, .LC949
	addx4	a8, a9, a8
	l32i	a8, a8, 0
	j	.L1588
.L1585:
	l32r	a4, .LC946
	l32r	a8, .LC947
	bgeui	a9, 5, .L1617
.L1588:
	beqi	a9, 3, .L1589
.L1612:
	l32r	a10, .LC972
	addx4	a9, a9, a10
	l32i	a9, a9, 0
	j	.L1668
.L1589:
	l8ui	a9, a6, 17
	bnei	a9, 1, .L1618
	l32r	a9, .LC951
	l32r	a11, .LC953
	j	.L1587
.L1616:
	l32r	a8, .LC956
	l32r	a4, .LC949
	mov.n	a9, a8
	j	.L1668
.L1617:
	l32r	a9, .LC956
.L1668:
	l32r	a11, .LC950
	j	.L1587
.L1618:
	l32r	a9, .LC951
	l32r	a11, .LC955
.L1587:
	l32r	a12, .LC958
	l32r	a10, .LC973
	s32i	a12, sp, 168
	bne	a7, a10, .L1590
	l32r	a10, .LC957
	s32i	a10, sp, 168
.L1590:
	l32r	a12, .LC961
	l8ui	a10, a6, 52
	s32i	a12, sp, 164
	bnei	a10, 2, .L1591
	l32r	a10, .LC960
	s32i	a10, sp, 164
.L1591:
	l8ui	a10, a6, 53
	s32i	a11, sp, 192
	s32i	a9, sp, 188
	s32i	a8, sp, 184
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	s32i	a10, sp, 176
	l8ui	a10, a6, 54
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l8ui	a12, a6, 55
	s32i	a10, sp, 180
	l32i	a8, sp, 184
	l32r	a10, .LC965
	l32i	a9, sp, 188
	l32i	a11, sp, 192
	bnei	a12, 1, .L1592
	l32r	a10, .LC963
.L1592:
	l32i	a15, a6, 60
	l32i	a14, a6, 56
	s32i	a15, sp, 196
	l32i	a15, a6, 68
	l32i	a12, a6, 0
	s32i	a14, sp, 192
	l32i	a14, a6, 64
	s32i	a15, sp, 204
	l32i	a15, a6, 76
	s32i	a12, sp, 184
	s32i	a14, sp, 200
	l8ui	a12, a6, 4
	l32i	a14, a6, 72
	s32i	a15, sp, 212
	l8ui	a15, a6, 94
	s32i	a12, sp, 188
	s32i	a14, sp, 208
	l32i	a13, a6, 8
	l8ui	a14, a6, 89
	l32r	a12, .LC958
	beqz.n	a15, .L1593
	l32r	a12, .LC957
.L1593:
	addi	a7, sp, 96
	addi	a15, a7, 32
	s32i	a15, sp, 92
	s32i	a12, sp, 84
	addi	a15, a7, 40
	movi	a12, 0xd0
	s32i	a15, sp, 88
	s32i	a14, sp, 80
	add.n	a12, a12, sp
	l32i	a14, a12, 0
	l32i	a15, a12, 4
	movi	a12, 0xc8
	s32i	a14, sp, 72
	s32i	a15, sp, 76
	add.n	a12, a12, sp
	l32i	a14, a12, 0
	l32i	a15, a12, 4
	movi	a12, 0xc0
	s32i	a14, sp, 64
	s32i	a15, sp, 68
	add.n	a12, a12, sp
	l32i	a14, a12, 0
	l32i	a15, a12, 4
	s32i	a10, sp, 36
	l32i	a10, sp, 180
	l32i	a12, sp, 188
	s32i	a10, sp, 32
	l32i	a10, sp, 176
	s32i	a12, sp, 44
	s32i	a10, sp, 28
	l32i	a10, sp, 164
	l32i	a12, sp, 184
	s32i	a10, sp, 24
	l32i	a10, sp, 168
	s32i	a14, sp, 56
	s32i	a15, sp, 60
	s32i	a13, sp, 48
	s32i	a12, sp, 40
	s32i	a10, sp, 20
	s32i	a11, sp, 16
	s32i	a9, sp, 12
	s32i	a5, sp, 8
	l32i	a9, sp, 220
	addi	a2, a7, 48
	l32i	a15, sp, 216
	l32r	a13, .LC975
	l32r	a11, .LC976
	s32i	a9, sp, 4
	s32i	a8, sp, 0
	mov.n	a14, a4
	mov.n	a12, a2
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1594
.L1596:
	movi.n	a2, 0
	j	.L1595
.L1594:
	l32r	a11, .LC976
	addi	a13, a6, 112
	mov.n	a12, a2
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1596
	l32r	a13, .LC978
	l32r	a11, .LC976
	mov.n	a12, a2
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1596
	movi	a13, 0xc8
	l32r	a11, .LC976
	add.n	a13, a6, a13
	mov.n	a12, a2
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1596
	l32r	a13, .LC980
	l32r	a11, .LC976
	mov.n	a12, a2
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1596
	movi	a13, 0x120
	l32r	a11, .LC976
	add.n	a13, a6, a13
	mov.n	a12, a2
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1596
	l32i	a8, sp, 224
	l32r	a14, .LC958
	beqz.n	a8, .L1597
	l32r	a14, .LC957
.L1597:
	l32r	a13, .LC982
	l32r	a11, .LC976
	addi	a12, a7, 48
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1595:
	l8ui	a9, a6, 16
	bnei	a9, 4, .L1598
	l32r	a11, .LC984
	addi	a4, sp, 112
	movi.n	a12, 5
	mov.n	a10, a4
	call8	memcpy
	movi.n	a12, 0xb
	movi.n	a11, 0
	addi	a10, sp, 117
	call8	memset
	l32r	a11, .LC984
	movi.n	a12, 5
	mov.n	a10, a7
	call8	memcpy
	movi.n	a12, 0xb
	movi.n	a11, 0
	addi	a10, sp, 101
	call8	memset
	l8ui	a9, a6, 94
	beqz.n	a9, .L1601
	l32i	a13, a6, 104
	l32r	a12, .LC986
	movi.n	a11, 0x10
	mov.n	a10, a4
	call8	snprintf
	l16ui	a14, a6, 102
	l16ui	a13, a6, 100
	l32r	a12, .LC988
	movi.n	a11, 0x10
	mov.n	a10, a7
	call8	snprintf
.L1601:
	beqz.n	a2, .L1598
	l8ui	a9, a6, 32
	l32i	a14, a6, 24
	l32i	a15, a6, 28
	l32r	a8, .LC958
	beqz.n	a9, .L1603
	l32r	a8, .LC957
.L1603:
	l32r	a13, .LC990
	l32r	a11, .LC976
	s32i	a7, sp, 8
	s32i	a4, sp, 4
	s32i	a8, sp, 0
	addi	a12, a7, 48
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
.L1598:
	l32i	a8, sp, 276
	beqz.n	a8, .L1604
	l8ui	a9, a8, 28
	beqz.n	a9, .L1604
	bnez.n	a2, .L1605
.L1608:
	movi.n	a2, 0
	j	.L1667
.L1605:
	l32i	a8, sp, 276
	l32r	a15, .LC958
	l32i	a14, a8, 32
	l8ui	a8, a8, 29
	beqz.n	a8, .L1607
	l32r	a15, .LC957
.L1607:
	l32r	a13, .LC992
	l32r	a11, .LC976
	addi	a12, a7, 48
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1608
.L1610:
	addi	a7, a7, 48
	l32r	a13, .LC993
	l32r	a11, .LC976
	mov.n	a12, a7
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1608
	j	.L1609
.L1604:
	bnez.n	a2, .L1610
	j	.L1608
.L1609:
	l32i	a10, sp, 160
	mov.n	a11, a7
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	beqz.n	a10, .L1608
	l32i	a9, sp, 172
	movi.n	a8, 0
	movnez	a5, a8, a9
	l32i	a10, sp, 160
	movi.n	a12, 0
	mov.n	a11, a5
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L1667
.L1613:
	l32r	a8, .LC967
	j	.L1586
.L1614:
	l32r	a8, .LC966
	j	.L1586
.L1615:
	l32r	a8, .LC968
.L1586:
	l32r	a4, .LC949
	j	.L1612
.L1667:
	retw.n
.LFE1216:
	.size	_ZN21MotorControlRSExample5Probe7Console12formatActionEmmmRKN14MotorControlRS6ESS_RS13ActionContextEbbPKNS0_10ResultViewE, .-_ZN21MotorControlRSExample5Probe7Console12formatActionEmmmRKN14MotorControlRS6ESS_RS13ActionContextEbbPKNS0_10ResultViewE
	.literal_position
	.literal .LC995, 35380
	.literal .LC996, 35196
	.literal .LC997, 35376
	.literal .LC999, .LC318
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console12reportActionEmmRKN14MotorControlRS6ESS_RS13ActionContextEbPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console12reportActionEmmRKN14MotorControlRS6ESS_RS13ActionContextEbPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console12reportActionEmmRKN14MotorControlRS6ESS_RS13ActionContextEbPKNS_9HostTupleEm:
.LFB1204:
	entry	sp, 384
.LCFI71:
	l32i	a12, sp, 384
	extui	a8, a6, 0, 8
	mov.n	a11, a7
	mov.n	a10, a2
	s32i	a8, sp, 336
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	mov.n	a7, a2
	movi.n	a10, 0
	bnez.n	a8, .L1670
	l32r	a8, .LC995
	add.n	a8, a2, a8
	l8ui	a10, a8, 0
	bnez.n	a10, .L1679
	l32i	a8, a5, 12
	bne	a8, a4, .L1670
	l8ui	a8, a5, 52
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L1670
	l32r	a6, .LC996
	l32r	a8, .LC997
	add.n	a6, a2, a6
	add.n	a8, a2, a8
	j	.L1671
.L1677:
	l32i	a9, a6, 0
	bne	a9, a3, .L1672
	l32i	a9, a6, 4
	bne	a9, a4, .L1672
	l8ui	a9, a6, 8
	bnez.n	a9, .L1672
	l8ui	a8, a6, 9
	addi	a2, sp, 16
	s32i	a9, a7, 148
	s32i	a9, a7, 144
	s8i	a8, a7, 141
	movi	a12, 0x140
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	movi	a9, 0xe1
	slli	a9, a9, 9
	s32i	a9, sp, 20
	l32r	a9, .LC999
	addmi	a10, a2, 0x100
	s32i	a9, sp, 196
	movi.n	a9, 1
	s8i	a9, sp, 248
	s8i	a9, a10, 56
	l8ui	a9, a5, 16
	bnei	a9, 3, .L1674
	l32i	a9, a7, 124
	beqz.n	a9, .L1674
	l32i	a10, a7, 0
	mov.n	a12, a2
	mov.n	a11, a4
	callx8	a9
.L1674:
	l32i	a8, sp, 336
	s32i	a2, sp, 4
	s32i	a8, sp, 0
	movi.n	a15, 0
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console12formatActionEmmmRKN14MotorControlRS6ESS_RS13ActionContextEbbPKNS0_10ResultViewE
	beqz.n	a10, .L1670
	l32i	a8, a6, 4
	bne	a8, a4, .L1670
	movi.n	a8, 1
	s8i	a8, a6, 8
	j	.L1670
.L1672:
	addi.n	a6, a6, 12
.L1671:
	bne	a6, a8, .L1677
	j	.L1670
.L1679:
	movi.n	a10, 0
.L1670:
	mov.n	a2, a10
	retw.n
.LFE1204:
	.section	.gcc_except_table
.LLSDA1204:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1204-.LLSDACSB1204
.LLSDACSB1204:
.LLSDACSE1204:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console12reportActionEmmRKN14MotorControlRS6ESS_RS13ActionContextEbPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console12reportActionEmmRKN14MotorControlRS6ESS_RS13ActionContextEbPKNS_9HostTupleEm
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console10formatHomeEmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb
	.type	_ZN21MotorControlRSExample5Probe7Console10formatHomeEmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb, @function
_ZN21MotorControlRSExample5Probe7Console10formatHomeEmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb:
.LFB1219:
	entry	sp, 64
.LCFI72:
	mov.n	a8, a7
	mov.n	a9, a6
	extui	a6, a8, 0, 8
	l8ui	a8, sp, 64
	movi.n	a11, 1
	movi	a10, 0x124
	mov.n	a14, a4
	mov.n	a13, a3
	movi.n	a4, 0
	s32i	a8, sp, 8
	s32i	a6, sp, 4
	s32i	a9, sp, 0
	mov.n	a15, a5
	addi	a12, sp, 16
	slli	a11, a11, 14
	add.n	a10, a2, a10
	mov.n	a7, a2
	s32i	a4, sp, 16
	call8	_ZN21MotorControlRSExample5Probe11HomeConsole12formatResultEPcjRjmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb
	bnez.n	a10, .L1687
.L1689:
	movi.n	a2, 0
	j	.L1688
.L1687:
	mov.n	a10, a2
	addi	a11, sp, 16
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	beqz.n	a10, .L1689
	movnez	a5, a4, a6
	movi.n	a12, 0
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L1688:
	retw.n
.LFE1219:
	.size	_ZN21MotorControlRSExample5Probe7Console10formatHomeEmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb, .-_ZN21MotorControlRSExample5Probe7Console10formatHomeEmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb
	.literal_position
	.literal .LC1002, 35380
	.literal .LC1003, 35196
	.literal .LC1004, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console10reportHomeEmmRKN14MotorControlRS6ESS_RS11HomeContextEbPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console10reportHomeEmmRKN14MotorControlRS6ESS_RS11HomeContextEbPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console10reportHomeEmmRKN14MotorControlRS6ESS_RS11HomeContextEbPKNS_9HostTupleEm:
.LFB1218:
	entry	sp, 48
.LCFI73:
	l32i	a12, sp, 48
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	extui	a6, a6, 0, 8
	beqz.n	a8, .L1697
.L1699:
	movi.n	a2, 0
	j	.L1698
.L1697:
	l32r	a8, .LC1002
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1699
	l32i	a8, a5, 12
	bne	a8, a4, .L1699
	l8ui	a8, a5, 172
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L1699
	l32r	a7, .LC1003
	l32r	a8, .LC1004
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	j	.L1700
.L1703:
	l32i	a9, a7, 0
	bne	a9, a3, .L1701
	l32i	a9, a7, 4
	bne	a9, a4, .L1701
	l8ui	a9, a7, 8
	bnez.n	a9, .L1701
	l8ui	a8, a7, 9
	s32i	a9, a2, 148
	s8i	a8, a2, 141
	s32i	a9, a2, 144
	mov.n	a10, a2
	s32i	a6, sp, 0
	movi.n	a15, 0
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console10formatHomeEmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb
	mov.n	a2, a10
	beqz.n	a10, .L1699
	l32i	a8, a7, 4
	bne	a8, a4, .L1698
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L1698
.L1701:
	addi.n	a7, a7, 12
.L1700:
	bne	a7, a8, .L1703
	j	.L1699
.L1698:
	retw.n
.LFE1218:
	.size	_ZN21MotorControlRSExample5Probe7Console10reportHomeEmmRKN14MotorControlRS6ESS_RS11HomeContextEbPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console10reportHomeEmmRKN14MotorControlRS6ESS_RS11HomeContextEbPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC1005:
	.string	"Checking subdivision and stopped state (operation %lu)..."
.LC1007:
	.string	"Subdivision failed (operation %lu)."
.LC1009:
	.string	"Host angle scale updated. Current stationary position is the new session zero.\n"
.LC1012:
	.string	"Setting may have changed; do not repeat automatically.\n"
.LC17:
	.string	"subdivision"
.LC1019:
	.string	"moveby"
.LC1021:
	.string	"moveto"
.LC1023:
	.string	"active"
.LC1029:
	.string	"\\%c"
.LC1031:
	.string	"%c"
.LC1034:
	.string	"Subdivision: %u. Checked readback.\n%sDetails: @1 result %lu."
.LC1036:
	.string	"Subdivision failed (operation %lu): %s.\n%sDetails: @1 result %lu; setting result %lu."
.LC1038:
	.string	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"driver_operation_id\":%lu,\"ok\":%s,\"pending\":%s,\"requested\":%u,\"readback\":%u,\"uncertain\":%s,\"status\":\"%s\"}"
.LC1042:
	.ascii	"{\"type\":\"motor_settings\",\"profile\":\"ess_rs\",\"id\":%"
	.ascii	"lu,\"command\":\"settings\",\"command_id\":%lu,\"operation_i"
	.ascii	"d\":%lu,\"pending\":%s,\"ok\":%s,\"address\":%u,\"status\":\""
	.ascii	"%s\",\"desired\":{\"speed_rpm\":%u,\"acceleration\":%s,\"dec"
	.ascii	"eleration\":%s,\"steps_per_turn\":{\"numerator\":%lld,\"deno"
	.ascii	"minator\":%llu}},\"actual\":{\"config_known\":%s,\""
	.string	"subdivision\":%u,\"direction\":%u,\"direction_known\":%s,\"word_order\":%u,\"word_order_known\":%s,\"algorithm\":%u,\"algorithm_known\":%s,\"encoder_resolution\":%u,\"soft_limit_enable\":%u,\"soft_limit_known\":%s,\"profile_known\":%s,\"profile\":[%u,%u,%u,%u,%u,%u]},\"message\":\""
.LC1044:
	.ascii	"{\"type\":\"simple_move\",\"profile\":\"ess_rs\",\"id\":%lu,"
	.ascii	"\"command\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\""
	.ascii	"move_operation_id\":%lu,\"address\":%u,\"ok\":%s,\"pending\""
	.ascii	":%s"
	.string	",\"state\":\"%s\",\"phase\":%u,\"outcome\":\"%s\",\"execution\":\"%s\",\"completion\":\"%s\",\"running_observed\":%s,\"uncertain\":%s,\"interrupted_by_stop\":%s,\"no_motion_sent\":%s,\"already_at_target\":%s,\"observation_known\":%s,\"raw_alarm\":%u,\"status\":\"%s\",\"detail\":%ld,\"message\":\""
.LC1047:
	.string	"\\u%04x"
.LC1050:
	.string	",\"maximum_position_rpm\":%u}"
.LC1052:
	.string	",\"position_confirmed\":%s,\"position_mismatch\":%s}"
.LC1054:
	.string	",\"effective_native\":%lld,\"rounding_error\":%.17g}"
.LC1056:
	.ascii	",\"profile_evidence\":{\"address\":%u,\"configurati"
	.string	"on_generation\":%lu,\"serial_generation\":%lu,\"pending\":%s,\"ok\":%s,\"tx_hex\":\"%s\",\"rx_hex\":\"%s\",\"tx_accepted\":%llu,\"tx_complete\":%s,\"closure_qualified\":%s,\"closure_earliest_us\":%llu,\"closure_latest_us\":%llu,\"deadline_us\":%llu,\"delivered_us\":%llu,\"error\":\"%s\"}}"
.LC1058:
	.string	"\",\"read_operation_id\":%lu}"
	.text
	.literal_position
	.literal .LC1006, .LC1005
	.literal .LC1008, .LC1007
	.literal .LC1010, .LC1009
	.literal .LC1011, .LC318
	.literal .LC1013, .LC1012
	.literal .LC1014, .LC807
	.literal .LC1015, .LC809
	.literal .LC1016, .LC17
	.literal .LC1017, .LC361
	.literal .LC1018, .LC363
	.literal .LC1020, .LC1019
	.literal .LC1022, .LC1021
	.literal .LC1024, .LC1023
	.literal .LC1025, .LC263
	.literal .LC1026, .LC959
	.literal .LC1027, .LC962
	.literal .LC1028, .LC964
	.literal .LC1030, .LC1029
	.literal .LC1032, .LC1031
	.literal .LC1033, 16384
	.literal .LC1035, .LC1034
	.literal .LC1037, .LC1036
	.literal .LC1039, .LC1038
	.literal .LC1040, .LC983
	.literal .LC1041, .LC844
	.literal .LC1043, .LC1042
	.literal .LC1045, .LC1044
	.literal .LC1046, .LC337
	.literal .LC1048, .LC1047
	.literal .LC1049, 50000
	.literal .LC1051, .LC1050
	.literal .LC1053, .LC1052
	.literal .LC1055, .LC1054
	.literal .LC1057, .LC1056
	.literal .LC1059, .LC1058
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb
	.type	_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb, @function
_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb:
.LFB1220:
	entry	sp, 432
.LCFI74:
	extui	a8, a5, 0, 8
	s32i	a8, sp, 304
	l8ui	a8, a4, 63
	s32i	a3, sp, 320
	s32i	a8, sp, 312
	beqz.n	a8, .L1708
	l8ui	a9, a2, 141
	l8ui	a8, a4, 58
	bnez.n	a9, .L1709
	movi	a7, 0x124
	l32r	a12, .LC1008
	add.n	a7, a2, a7
	beqz.n	a8, .L1710
	l32r	a12, .LC1006
.L1710:
	l32i	a13, a4, 36
	l32r	a11, .LC1033
	mov.n	a10, a7
	call8	snprintf
	l8ui	a8, a4, 58
	bnez.n	a8, .L1718
	l8ui	a8, a4, 60
	bnez.n	a8, .L1712
	j	.L1713
.L1853:
	l8ui	a8, a4, 60
	bnez.n	a8, .L1714
	j	.L1713
.L1712:
	l8ui	a8, a4, 64
	l16ui	a13, a4, 80
	l32r	a14, .LC1011
	beqz.n	a8, .L1715
	l32r	a14, .LC1010
.L1715:
	l32i	a15, a4, 36
	l32r	a12, .LC1035
	l32r	a11, .LC1033
	mov.n	a10, a7
	call8	snprintf
	l8ui	a8, a4, 58
	beqz.n	a8, .L1853
	j	.L1718
.L1713:
	l8ui	a8, a4, 109
	l32i	a13, a4, 36
	l32i	a14, a4, 152
	l32r	a15, .LC1011
	beqz.n	a8, .L1717
	l32r	a15, .LC1013
.L1717:
	l32i	a8, a4, 68
	l32r	a12, .LC1037
	l32r	a11, .LC1033
	s32i	a8, sp, 4
	s32i	a13, sp, 0
	mov.n	a10, a7
	call8	snprintf
	l32i	a8, sp, 304
	bnez.n	a8, .L1718
	l8ui	a8, a4, 58
.L1856:
	bnez.n	a8, .L1718
	l32i	a11, a4, 36
.L1778:
	movi.n	a12, 1
	j	.L1858
.L1709:
	movi	a5, 0x124
	add.n	a9, a2, a5
	s32i	a9, sp, 308
	l32i	a9, sp, 304
	beqz.n	a9, .L1784
	l32r	a3, .LC1014
	l32r	a15, .LC1015
	j	.L1720
.L1784:
	l32r	a3, .LC1016
	mov.n	a15, a3
.L1720:
	l32i	a5, a4, 48
	l32i	a11, a4, 36
	l32i	a12, a4, 68
	bnez.n	a8, .L1785
	l8ui	a8, a4, 60
	l32r	a6, .LC1018
	beqz.n	a8, .L1857
	j	.L1786
.L1785:
	l32r	a6, .LC1017
.L1857:
	mov.n	a7, a6
	j	.L1721
.L1786:
	l32r	a6, .LC1017
	l32r	a7, .LC1018
.L1721:
	l8ui	a10, a4, 109
	l16ui	a13, a4, 66
	l16ui	a14, a4, 80
	l32r	a8, .LC1018
	beqz.n	a10, .L1722
	l32r	a8, .LC1017
.L1722:
	l8ui	a10, a4, 140
	s32i	a8, sp, 340
	s32i	a15, sp, 336
	s32i	a14, sp, 332
	s32i	a13, sp, 328
	s32i	a12, sp, 316
	s32i	a11, sp, 312
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a14, sp, 332
	l32i	a12, sp, 316
	l32i	a11, sp, 312
	l32i	a13, sp, 328
	l32i	a8, sp, 340
	s32i	a10, sp, 32
	s32i	a14, sp, 24
	s32i	a12, sp, 8
	s32i	a11, sp, 4
	l32i	a15, sp, 336
	l32i	a14, sp, 320
	l32r	a12, .LC1039
	l32r	a11, .LC1033
	l32i	a10, sp, 308
	s32i	a13, sp, 20
	s32i	a8, sp, 28
	s32i	a7, sp, 16
	s32i	a6, sp, 12
	s32i	a5, sp, 0
	mov.n	a13, a3
	call8	snprintf
.L1866:
	l32i	a8, sp, 304
	movi.n	a11, 0
	bnez.n	a8, .L1723
	l8ui	a8, a4, 58
	bnez.n	a8, .L1723
	l32i	a11, a4, 36
.L1723:
	movi.n	a12, 0
.L1858:
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	movi.n	a8, 1
	s32i	a8, sp, 312
	j	.L1827
.L1708:
	l32i	a7, a4, 156
	movi.n	a3, 1
	beqz.n	a7, .L1725
	addmi	a8, a7, 0x100
	l8ui	a8, a8, 236
	movi.n	a3, 0
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L1725
	l32i	a8, a7, 896
	bnez.n	a8, .L1725
	addmi	a8, a7, 0x300
	l8ui	a3, a8, 135
	movi.n	a8, 1
	xor	a3, a3, a8
	extui	a3, a3, 0, 8
.L1725:
	movi.n	a8, 0
	s32i	a8, sp, 296
	l8ui	a8, a4, 72
	beqz.n	a8, .L1726
	movi	a6, 0x80
	add.n	a6, sp, a6
	l32r	a5, .LC1040
	movi	a3, 0x81
	add.n	a3, a6, a3
	movi.n	a12, 5
	mov.n	a11, a5
	mov.n	a10, a3
	call8	memcpy
	movi	a10, 0x86
	movi.n	a12, 0xb
	movi.n	a11, 0
	add.n	a10, a6, a10
	call8	memset
	movi.n	a12, 5
	mov.n	a11, a5
	mov.n	a10, a6
	call8	memcpy
	movi.n	a12, 0xb
	movi.n	a11, 0
	addi.n	a10, a6, 5
	call8	memset
	l8ui	a8, a4, 6
	beqz.n	a8, .L1729
	l16ui	a13, a4, 2
	l32r	a12, .LC1041
	movi.n	a11, 0x10
	mov.n	a10, a3
	call8	snprintf
.L1729:
	l8ui	a8, a4, 7
	beqz.n	a8, .L1730
	movi	a10, 0x80
	l16ui	a13, a4, 4
	l32r	a12, .LC1041
	movi.n	a11, 0x10
	add.n	a10, sp, a10
	call8	snprintf
.L1730:
	movi	a8, 0x124
	add.n	a8, a2, a8
	s32i	a8, sp, 316
	l32i	a8, a4, 48
	s32i	a8, sp, 328
	l32i	a8, a4, 36
	s32i	a8, sp, 332
	l8ui	a8, a4, 58
	bnez.n	a8, .L1793
	l8ui	a8, a4, 60
	l32r	a6, .LC1018
	l32r	a5, .LC1017
	bnez.n	a8, .L1731
	j	.L1859
.L1793:
	l32r	a6, .LC1017
.L1859:
	mov.n	a5, a6
	j	.L1731
.L1731:
	l8ui	a8, a4, 56
	l8ui	a10, a4, 140
	s32i	a8, sp, 336
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l16ui	a8, a4, 0
	s32i	a10, sp, 340
	s32i	a8, sp, 344
	l8ui	a8, a4, 32
	movi.n	a15, 0
	movi.n	a14, 0
	beqz.n	a8, .L1732
	l32i	a15, a4, 16
	l32i	a14, a4, 20
.L1732:
	l32i	a9, a4, 28
	l32i	a8, a4, 24
	s32i	a9, sp, 356
	l32r	a9, .LC1018
	s32i	a8, sp, 352
	l8ui	a8, a4, 73
	s32i	a9, sp, 308
	beqz.n	a8, .L1733
	l32r	a8, .LC1017
	s32i	a8, sp, 308
.L1733:
	l16ui	a8, a4, 80
	l32r	a9, .LC1018
	s32i	a8, sp, 348
	l16ui	a8, a4, 82
	s32i	a8, sp, 360
	l8ui	a8, a4, 104
	beqz.n	a8, .L1734
	l32r	a9, .LC1017
.L1734:
	l16ui	a8, a4, 84
	l32r	a10, .LC1018
	s32i	a8, sp, 364
	l8ui	a8, a4, 105
	beqz.n	a8, .L1735
	l32r	a10, .LC1017
.L1735:
	l16ui	a8, a4, 86
	l32r	a11, .LC1018
	s32i	a8, sp, 368
	l8ui	a8, a4, 106
	beqz.n	a8, .L1736
	l32r	a11, .LC1017
.L1736:
	l16ui	a8, a4, 88
	l32r	a12, .LC1018
	s32i	a8, sp, 372
	l16ui	a8, a4, 90
	s32i	a8, sp, 376
	l8ui	a8, a4, 107
	beqz.n	a8, .L1737
	l32r	a12, .LC1017
.L1737:
	l8ui	a8, a4, 74
	l32r	a13, .LC1018
	beqz.n	a8, .L1738
	l32r	a13, .LC1017
.L1738:
	l16ui	a3, a4, 102
	movi	a8, 0x80
	s32i	a3, sp, 116
	l16ui	a3, a4, 100
	add.n	a8, sp, a8
	s32i	a3, sp, 112
	l16ui	a3, a4, 98
	s32i	a3, sp, 108
	l16ui	a3, a4, 96
	s32i	a3, sp, 104
	l16ui	a3, a4, 94
	s32i	a3, sp, 100
	l16ui	a3, a4, 92
	s32i	a9, sp, 60
	l32i	a9, sp, 360
	s32i	a12, sp, 88
	s32i	a9, sp, 56
	l32i	a9, sp, 348
	l32i	a12, sp, 376
	s32i	a9, sp, 52
	l32i	a9, sp, 308
	s32i	a12, sp, 84
	s32i	a11, sp, 76
	l32i	a12, sp, 372
	s32i	a10, sp, 68
	l32i	a11, sp, 368
	l32i	a10, sp, 364
	s32i	a9, sp, 48
	movi	a9, 0x160
	s32i	a13, sp, 92
	s32i	a12, sp, 80
	add.n	a9, a9, sp
	s32i	a3, sp, 96
	s32i	a11, sp, 72
	s32i	a10, sp, 64
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	movi	a9, 0x81
	add.n	a9, a8, a9
	s32i	a9, sp, 24
	l32i	a9, sp, 344
	s32i	a10, sp, 40
	s32i	a9, sp, 20
	l32i	a9, sp, 340
	s32i	a11, sp, 44
	s32i	a9, sp, 16
	l32i	a9, sp, 336
	s32i	a15, sp, 32
	s32i	a9, sp, 12
	l32i	a9, sp, 332
	s32i	a14, sp, 36
	l32i	a15, sp, 328
	l32i	a14, sp, 320
	l32r	a13, .LC1043
	l32r	a11, .LC1033
	l32i	a10, sp, 316
	movi	a12, 0xa8
	s32i	a8, sp, 28
	s32i	a5, sp, 8
	s32i	a6, sp, 4
	s32i	a9, sp, 0
	add.n	a12, a8, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L1860
.L1726:
	movi	a8, 0x124
	add.n	a8, a2, a8
	l32r	a9, .LC1022
	s32i	a8, sp, 328
	l8ui	a8, a4, 62
	s32i	a9, sp, 316
	beqz.n	a8, .L1740
	l32r	a8, .LC1020
	s32i	a8, sp, 316
.L1740:
	l32i	a8, a4, 48
	s32i	a8, sp, 332
	l32i	a8, a4, 36
	s32i	a8, sp, 336
	l32i	a8, a4, 40
	s32i	a8, sp, 340
	l8ui	a8, a4, 56
	s32i	a8, sp, 344
	l8ui	a8, a4, 58
	bnez.n	a8, .L1803
	l8ui	a8, a4, 60
	l32r	a6, .LC1018
	bnez.n	a8, .L1804
	l32r	a5, .LC1025
	s32i	a6, sp, 308
	j	.L1741
.L1803:
	l32r	a6, .LC1017
	l32r	a5, .LC1024
	s32i	a6, sp, 308
	j	.L1741
.L1804:
	l32r	a8, .LC1017
	l32r	a5, .LC1026
	s32i	a8, sp, 308
.L1741:
	l8ui	a8, a4, 57
	l8ui	a10, a4, 136
	s32i	a8, sp, 352
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	s32i	a10, sp, 348
	l8ui	a10, a4, 137
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l8ui	a9, a4, 138
	s32i	a10, sp, 360
	l32r	a8, .LC1028
	bnei	a9, 1, .L1742
	l32r	a8, .LC1027
.L1742:
	l8ui	a10, a4, 108
	l32r	a9, .LC1018
	beqz.n	a10, .L1743
	l32r	a9, .LC1017
.L1743:
	l8ui	a10, a4, 109
	l32r	a11, .LC1018
	beqz.n	a10, .L1744
	l32r	a11, .LC1017
.L1744:
	l8ui	a10, a4, 110
	l32r	a12, .LC1018
	beqz.n	a10, .L1745
	l32r	a12, .LC1017
.L1745:
	l32r	a13, .LC1018
	beqz.n	a3, .L1746
	l32r	a13, .LC1017
.L1746:
	l8ui	a10, a4, 111
	l32r	a14, .LC1018
	beqz.n	a10, .L1747
	l32r	a14, .LC1017
.L1747:
	beqz.n	a7, .L1811
	addmi	a10, a7, 0x100
	l8ui	a10, a10, 244
	l32r	a3, .LC1017
	bnez.n	a10, .L1749
	l32r	a3, .LC1018
.L1749:
	addmi	a10, a7, 0x200
	l16ui	a15, a10, 98
	j	.L1748
.L1811:
	l32r	a3, .LC1018
	movi.n	a15, 0
.L1748:
	l8ui	a10, a4, 140
	s32i	a9, sp, 388
	s32i	a11, sp, 384
	s32i	a12, sp, 380
	s32i	a14, sp, 376
	s32i	a13, sp, 372
	s32i	a15, sp, 368
	s32i	a8, sp, 364
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a4, 144
	l32i	a15, sp, 368
	s32i	a8, sp, 76
	l32i	a8, sp, 364
	l32i	a14, sp, 376
	s32i	a8, sp, 40
	l32i	a8, sp, 360
	l32i	a13, sp, 372
	s32i	a8, sp, 36
	l32i	a8, sp, 348
	l32i	a12, sp, 380
	s32i	a8, sp, 32
	l32i	a8, sp, 352
	l32i	a11, sp, 384
	s32i	a8, sp, 28
	l32i	a8, sp, 308
	l32i	a9, sp, 388
	s32i	a8, sp, 16
	l32i	a8, sp, 344
	s32i	a10, sp, 72
	s32i	a15, sp, 68
	s32i	a14, sp, 60
	s32i	a13, sp, 56
	s32i	a12, sp, 52
	s32i	a11, sp, 48
	s32i	a3, sp, 64
	s32i	a9, sp, 44
	s32i	a5, sp, 24
	s32i	a6, sp, 20
	s32i	a8, sp, 12
	l32i	a8, sp, 340
	movi	a12, 0x128
	s32i	a8, sp, 8
	l32i	a8, sp, 336
	l32i	a15, sp, 316
	s32i	a8, sp, 4
	l32i	a8, sp, 332
	l32i	a14, sp, 320
	l32r	a13, .LC1045
	l32r	a11, .LC1033
	l32i	a10, sp, 328
	s32i	a8, sp, 0
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L1860:
	l32i	a6, a4, 152
	mov.n	a3, a10
	beqz.n	a6, .L1814
	l32r	a11, .LC1046
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L1814
	j	.L1750
.L1814:
	l32r	a6, .LC1011
.L1750:
	movi	a5, 0x128
	movi.n	a8, 0
	add.n	a5, sp, a5
	j	.L1751
.L1757:
	movi.n	a9, 0x1f
	bltu	a9, a14, .L1752
	movi	a10, 0x124
	l32r	a13, .LC1048
	l32r	a11, .LC1033
	s32i	a8, sp, 308
	mov.n	a12, a5
	add.n	a10, a2, a10
	j	.L1861
.L1752:
	addi	a9, a14, -34
	movi	a10, 0x124
	nsau	a11, a9
	add.n	a10, a2, a10
	srli	a11, a11, 5
	beqz.n	a9, .L1826
	addi	a12, a14, -92
	movi.n	a9, 1
	movnez	a9, a11, a12
	l32r	a13, .LC1032
	beqz.n	a9, .L1754
.L1826:
	l32r	a13, .LC1030
.L1754:
	l32r	a11, .LC1033
	s32i	a8, sp, 308
	mov.n	a12, a5
.L1861:
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	l32i	a8, sp, 308
	mov.n	a3, a10
	addi.n	a8, a8, 1
.L1751:
	beqz.n	a3, .L1827
	add.n	a9, a6, a8
	l8ui	a14, a9, 0
	beqz.n	a14, .L1759
	bnei	a8, 256, .L1757
	j	.L1759
.L1780:
	l8ui	a8, a4, 72
	bnez.n	a8, .L1760
.L1765:
	l8ui	a8, a4, 63
	bnez.n	a8, .L1761
	j	.L1854
.L1760:
	l32i	a8, sp, 296
	movi.n	a10, 0
	addi.n	a8, a8, -1
	s32i	a8, sp, 296
	l8ui	a8, a4, 73
	beqz.n	a8, .L1763
	l16ui	a10, a4, 80
.L1763:
	movi	a8, 0x7d0
	s16i	a8, sp, 128
	l32r	a8, .LC1049
	movi	a5, 0x80
	s32i	a8, sp, 132
	add.n	a5, sp, a5
	movi	a8, 0x64
	mov.n	a11, a5
	s16i	a8, sp, 136
	call8	_ZN14MotorControlRS6ESS_RS18positionSpeedLimitEtRKNS0_14PositionLimitsE
	movi	a12, 0xa8
	l32r	a13, .LC1051
	l32r	a11, .LC1033
	mov.n	a14, a10
	add.n	a12, a5, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1827
	l8ui	a8, a4, 72
	bnez.n	a8, .L1772
	j	.L1765
.L1761:
	l8ui	a8, a4, 112
	beqz.n	a8, .L1866
	j	.L1766
.L1854:
	l32i	a8, sp, 296
	addi.n	a8, a8, -1
	s32i	a8, sp, 296
	beqz.n	a7, .L1817
	addmi	a7, a7, 0x100
	l8ui	a8, a7, 245
	l32r	a14, .LC1017
	bnez.n	a8, .L1769
	l32r	a14, .LC1018
.L1769:
	l8ui	a8, a7, 246
	l32r	a15, .LC1018
	beqz.n	a8, .L1768
	l32r	a15, .LC1017
	j	.L1768
.L1817:
	l32r	a14, .LC1018
	mov.n	a15, a14
.L1768:
	movi	a12, 0x128
	l32r	a13, .LC1053
	l32r	a11, .LC1033
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1827
	l8ui	a8, a4, 72
	beqz.n	a8, .L1761
	j	.L1772
.L1766:
	l32i	a8, sp, 296
	l32i	a9, a4, 132
	addi.n	a8, a8, -1
	s32i	a8, sp, 296
	l32i	a8, a4, 128
	s32i.n	a9, sp, 4
	s32i.n	a8, sp, 0
	movi	a12, 0x128
	l32i	a14, a4, 120
	l32i	a15, a4, 124
	l32r	a13, .LC1055
	l32r	a11, .LC1033
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1827
	l8ui	a8, a4, 72
	bnez.n	a8, .L1772
	j	.L1866
.L1779:
	movi	a5, 0x80
	l32i	a11, a7, 176
	add.n	a5, sp, a5
	movi	a12, 0x81
	movi.n	a13, 0x27
	add.n	a12, a5, a12
	addi	a10, a7, 64
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a11, a7, 180
	movi	a13, 0x81
	mov.n	a12, a5
	addi	a10, a7, 83
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a8, sp, 296
	l8ui	a3, a7, 6
	addi.n	a8, a8, -1
	s32i	a8, sp, 296
	l32i	a8, a7, 8
	l32i	a13, a7, 12
	s32i	a8, sp, 308
	l8ui	a8, a7, 0
	l32r	a9, .LC1018
	beqz.n	a8, .L1773
	l32r	a9, .LC1017
.L1773:
	l8ui	a8, a7, 3
	l32r	a10, .LC1018
	beqz.n	a8, .L1774
	l32r	a10, .LC1017
.L1774:
	l32i	a14, a7, 192
	l32i	a15, a7, 196
	addmi	a8, a7, 0x100
	l8ui	a12, a8, 10
	s32i	a14, sp, 320
	s32i	a15, sp, 324
	l32r	a11, .LC1018
	beqz.n	a12, .L1775
	l32r	a11, .LC1017
.L1775:
	l8ui	a8, a8, 12
	l32r	a12, .LC1018
	beqz.n	a8, .L1776
	l32r	a12, .LC1017
.L1776:
	l32i	a5, a7, 272
	movi	a8, 0x80
	s32i	a5, sp, 72
	l32i	a14, a7, 224
	l32i	a15, a7, 228
	s32i	a14, sp, 64
	s32i	a15, sp, 68
	l32i	a14, a7, 216
	l32i	a15, a7, 220
	s32i	a14, sp, 56
	s32i	a15, sp, 60
	l32i	a14, a7, 208
	l32i	a15, a7, 212
	s32i	a14, sp, 48
	s32i	a15, sp, 52
	l32i	a14, a7, 200
	l32i	a15, a7, 204
	s32i	a11, sp, 32
	movi	a11, 0x140
	s32i	a12, sp, 36
	add.n	a11, a11, sp
	s32i	a14, sp, 40
	s32i	a15, sp, 44
	l32i	a14, a11, 0
	l32i	a15, a11, 4
	add.n	a8, sp, a8
	movi	a11, 0x81
	add.n	a11, a8, a11
	s32i	a15, sp, 28
	s32i	a11, sp, 12
	s32i	a13, sp, 0
	movi	a12, 0xa8
	l32i	a15, sp, 308
	l32r	a13, .LC1057
	l32r	a11, .LC1033
	s32i	a14, sp, 24
	s32i	a10, sp, 8
	s32i	a8, sp, 16
	s32i	a9, sp, 4
	mov.n	a14, a3
	add.n	a12, a8, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1827
	j	.L1866
.L1714:
	l32i	a8, sp, 304
	j	.L1856
.L1718:
	movi.n	a11, 0
	j	.L1778
.L1772:
	l32i	a7, a4, 76
	bnez.n	a7, .L1779
	j	.L1866
.L1759:
	movi	a6, 0x124
	add.n	a6, a2, a6
	movi	a12, 0x128
	l32i	a14, a4, 44
	l32r	a13, .LC1059
	l32r	a11, .LC1033
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1780
.L1827:
	l32i	a2, sp, 312
	retw.n
.LFE1220:
	.size	_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb, .-_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb
	.literal_position
	.literal .LC1061, 35380
	.literal .LC1062, 35196
	.literal .LC1063, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console18reportSimpleMotionEmmRKNS0_16SimpleMotionViewE
	.type	_ZN21MotorControlRSExample5Probe7Console18reportSimpleMotionEmmRKNS0_16SimpleMotionViewE, @function
_ZN21MotorControlRSExample5Probe7Console18reportSimpleMotionEmmRKNS0_16SimpleMotionViewE:
.LFB1221:
	entry	sp, 32
.LCFI75:
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a12, a5
	beqz.n	a8, .L1868
.L1870:
	movi.n	a2, 0
	j	.L1869
.L1868:
	l32r	a8, .LC1061
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1870
	l8ui	a8, a5, 58
	bnez.n	a8, .L1870
	l32i	a8, a5, 36
	bne	a8, a4, .L1870
	l32r	a7, .LC1062
	l32r	a8, .LC1063
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	j	.L1871
.L1874:
	l32i	a9, a7, 0
	bne	a9, a11, .L1872
	l32i	a9, a7, 4
	bne	a9, a4, .L1872
	l8ui	a9, a7, 8
	bnez.n	a9, .L1872
	l8ui	a8, a7, 9
	movi.n	a13, 0
	s8i	a8, a10, 141
	s32i	a9, a10, 148
	s32i	a9, a10, 144
	call8	_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb
	mov.n	a2, a10
	beqz.n	a10, .L1870
	l32i	a8, a7, 4
	bne	a8, a4, .L1869
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L1869
.L1872:
	addi.n	a7, a7, 12
.L1871:
	bne	a7, a8, .L1874
	j	.L1870
.L1869:
	retw.n
.LFE1221:
	.size	_ZN21MotorControlRSExample5Probe7Console18reportSimpleMotionEmmRKNS0_16SimpleMotionViewE, .-_ZN21MotorControlRSExample5Probe7Console18reportSimpleMotionEmmRKNS0_16SimpleMotionViewE
	.section	.rodata.str1.1
.LC1066:
	.string	"move"
.LC1075:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"move_kin"
	.ascii	"d\":\"%s\",\"position_interrupt\":true,\"read_kind\":null,\""
	.ascii	"action_kind\":null,\"capture_read\":false,\"recovery\":false"
	.ascii	",\"ok\":false,\"state\":\"%s\",\"outcome\":\"%s\",\"status\""
	.ascii	":\"%s\",\"detail\":%ld,\"setup_execution\":\"%s\",\"executio"
	.ascii	"n\":\"%s\",\"completion\":\"not_observed\",\"target\":%lu,\""
	.ascii	"address\":%u,\"generation\":%lu,\"configuration_generation\""
	.ascii	":%lu,\"started_us\":%llu,\"deadline_us\":%llu,\"serviced_us\""
	.ascii	":%llu,\"setup\":\"stored\",\"staging_applied\":false,\"uncer"
	.ascii	"tain\":%s,\"observation_known\":false,\"running_observed\":f"
	.ascii	"alse,\"endpoint_known\":false,\"displacement_known\":false,\""
	.ascii	"native_rpm\":%u,\"staging_words\":[%u,%u,%u,%u,%u],\"trigger"
	.ascii	"_step\":%u,\"interrupted_by_stop\":%s,\"stored\":{\"original"
	.ascii	"_operation_id\":%lu,\"configuration"
	.string	"_generation\":%lu,\"target\":%lu,\"address\":%u,\"generation\":%lu,\"subdivision\":%u,\"word_order\":%u,\"relative\":%s,\"qualified\":%s,\"qualified_us\":%llu,\"maximum_age_us\":%llu,\"start_speed\":%u,\"acceleration_time\":%u,\"deceleration_time\":%u,\"speed\":%u,\"target_bits\":%lu}"
.LC1078:
	.string	",\"trigger_evidence\":"
	.text
	.literal_position
	.literal .LC1064, .LC807
	.literal .LC1065, .LC809
	.literal .LC1067, .LC1066
	.literal .LC1068, .LC556
	.literal .LC1069, .LC311
	.literal .LC1070, .LC313
	.literal .LC1071, .LC959
	.literal .LC1072, .LC263
	.literal .LC1073, .LC361
	.literal .LC1074, .LC363
	.literal .LC1076, .LC1075
	.literal .LC1077, 16384
	.literal .LC1079, .LC1078
	.literal .LC1080, .LC979
	.literal .LC1081, .LC430
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console23formatPositionInterruptEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE
	.type	_ZN21MotorControlRSExample5Probe7Console23formatPositionInterruptEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE, @function
_ZN21MotorControlRSExample5Probe7Console23formatPositionInterruptEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE:
.LFB1224:
	entry	sp, 368
.LCFI76:
	extui	a8, a7, 0, 8
	s32i	a8, sp, 228
	movi	a8, 0x170
	add.n	a8, a8, sp
	s32i	a3, sp, 328
	l8ui	a3, a8, 0
	movi.n	a8, 0
	s32i	a8, sp, 192
	l32i	a8, sp, 228
	movi	a7, 0x124
	s32i	a2, sp, 208
	s32i	a4, sp, 332
	add.n	a7, a2, a7
	beqz.n	a8, .L1890
	l32r	a8, .LC1064
	s32i	a8, sp, 224
	l32r	a8, .LC1065
	j	.L1920
.L1890:
	l32r	a8, .LC1067
	s32i	a8, sp, 224
	l32r	a8, .LC1068
.L1920:
	s32i	a8, sp, 212
	l32r	a8, .LC1070
	l8ui	a4, a6, 44
	s32i	a8, sp, 216
	beqz.n	a4, .L1880
	l32r	a8, .LC1069
	s32i	a8, sp, 216
.L1880:
	l32r	a9, .LC1072
	addmi	a2, a6, 0x100
	l8ui	a8, a2, 236
	s32i	a9, sp, 220
	bnei	a8, 2, .L1881
	l32r	a8, .LC1071
	s32i	a8, sp, 220
.L1881:
	l8ui	a10, a2, 237
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	addmi	a8, a6, 0x400
	s32i	a10, sp, 232
	l8ui	a10, a8, 192
	s32i	a8, sp, 240
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, sp, 240
	s32i	a10, sp, 236
	l32i	a8, a8, 196
	l8ui	a10, a2, 238
	s32i	a8, sp, 240
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	s32i	a10, sp, 244
	l8ui	a10, a2, 239
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l32i	a8, a6, 64
	l32i	a9, a6, 620
	s32i	a8, sp, 252
	l8ui	a8, a6, 68
	s32i	a9, sp, 268
	s32i	a8, sp, 256
	l32i	a8, a6, 72
	l32i	a9, a6, 628
	s32i	a8, sp, 260
	l32i	a8, a6, 616
	s32i	a9, sp, 276
	s32i	a8, sp, 264
	l32i	a8, a6, 624
	l32i	a9, a6, 636
	s32i	a8, sp, 272
	l32i	a8, a6, 632
	s32i	a10, sp, 248
	s32i	a8, sp, 280
	l8ui	a8, a2, 242
	s32i	a9, sp, 284
	l32i	a12, a6, 20
	l32r	a13, .LC1074
	beqz.n	a8, .L1882
	l32r	a13, .LC1073
.L1882:
	addmi	a9, a6, 0x200
	l16ui	a10, a9, 88
	l16ui	a8, a6, 38
	s32i	a10, sp, 288
	l16ui	a10, a9, 90
	s32i	a10, sp, 292
	l16ui	a10, a9, 92
	s32i	a10, sp, 296
	l16ui	a10, a9, 94
	s32i	a10, sp, 300
	l16ui	a10, a9, 96
	l8ui	a9, a9, 138
	s32i	a10, sp, 304
	s32i	a9, sp, 308
	l32r	a9, .LC1074
	beqz.n	a3, .L1883
	l32r	a9, .LC1073
.L1883:
	l32i	a10, a6, 24
	l16ui	a3, a6, 28
	s32i	a10, sp, 312
	l32i	a10, a6, 8
	l16ui	a2, a6, 30
	s32i	a10, sp, 316
	l8ui	a10, a6, 12
	s32i	a10, sp, 320
	l32i	a10, a6, 16
	s32i	a10, sp, 324
	l32r	a10, .LC1074
	beqz.n	a4, .L1884
	l32r	a10, .LC1073
.L1884:
	l8ui	a4, a6, 45
	l32r	a11, .LC1074
	beqz.n	a4, .L1885
	l32r	a11, .LC1073
.L1885:
	l32i	a4, a6, 40
	s32i	a8, sp, 180
	s32i	a4, sp, 184
	l16ui	a4, a6, 36
	s32i	a4, sp, 176
	l16ui	a4, a6, 34
	s32i	a4, sp, 172
	l16ui	a4, a6, 32
	s32i	a4, sp, 168
	l32i	a14, a6, 56
	l32i	a15, a6, 60
	s32i	a14, sp, 160
	s32i	a15, sp, 164
	l32i	a14, a6, 48
	l32i	a15, a6, 52
	s32i	a10, sp, 144
	l32i	a10, sp, 324
	s32i	a9, sp, 112
	s32i	a10, sp, 132
	l32i	a10, sp, 320
	l32i	a9, sp, 308
	s32i	a10, sp, 128
	l32i	a10, sp, 316
	s32i	a14, sp, 152
	s32i	a10, sp, 124
	l32i	a10, sp, 312
	s32i	a15, sp, 156
	s32i	a11, sp, 148
	s32i	a12, sp, 120
	s32i	a10, sp, 116
	s32i	a2, sp, 140
	s32i	a3, sp, 136
	s32i	a9, sp, 108
	l32i	a9, sp, 304
	s32i	a8, sp, 84
	s32i	a9, sp, 104
	l32i	a9, sp, 300
	movi	a8, 0x118
	s32i	a9, sp, 100
	l32i	a9, sp, 296
	s32i	a13, sp, 80
	s32i	a9, sp, 96
	l32i	a9, sp, 292
	add.n	a8, a8, sp
	s32i	a9, sp, 92
	l32i	a9, sp, 288
	movi	a4, 0xc0
	s32i	a9, sp, 88
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 76
	s32i	a8, sp, 72
	movi	a8, 0x110
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	movi	a8, 0x108
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a12, sp, 52
	s32i	a8, sp, 56
	l32i	a8, sp, 260
	s32i	a9, sp, 60
	s32i	a8, sp, 48
	l32i	a8, sp, 256
	add.n	a4, sp, a4
	s32i	a8, sp, 44
	l32i	a8, sp, 252
	mov.n	a12, a4
	s32i	a8, sp, 40
	l32i	a8, sp, 248
	mov.n	a10, a7
	s32i	a8, sp, 36
	l32i	a8, sp, 244
	l32i	a15, sp, 328
	s32i	a8, sp, 32
	l32i	a8, sp, 240
	l32i	a14, sp, 224
	s32i	a8, sp, 28
	l32i	a8, sp, 236
	l32r	a13, .LC1076
	s32i	a8, sp, 24
	l32i	a8, sp, 232
	l32r	a11, .LC1077
	s32i	a8, sp, 20
	l32i	a8, sp, 220
	s32i	a5, sp, 8
	s32i	a8, sp, 16
	l32i	a8, sp, 216
	s32i	a8, sp, 12
	l32i	a8, sp, 332
	s32i	a8, sp, 4
	l32i	a8, sp, 212
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1886
.L1888:
	movi.n	a2, 0
	j	.L1887
.L1886:
	l32i	a12, sp, 372
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112moveRelationEPcjRjRKNS_12MoveRelationE$constprop$0
	beqz.n	a10, .L1888
	l32r	a13, .LC1079
	l32r	a11, .LC1077
	mov.n	a12, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1888
	movi	a13, 0x360
	l32r	a11, .LC1077
	add.n	a13, a6, a13
	mov.n	a12, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1888
	l32r	a13, .LC1080
	l32r	a11, .LC1077
	mov.n	a12, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1888
	movi	a13, 0x468
	l32r	a11, .LC1077
	add.n	a13, a6, a13
	mov.n	a12, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1888
	l32r	a13, .LC1081
	l32r	a11, .LC1077
	mov.n	a12, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1888
	l32i	a10, sp, 208
	mov.n	a11, a4
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	beqz.n	a10, .L1888
	l32i	a9, sp, 228
	movi.n	a8, 0
	movnez	a5, a8, a9
	l32i	a10, sp, 208
	movi.n	a12, 0
	mov.n	a11, a5
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L1887:
	retw.n
.LFE1224:
	.size	_ZN21MotorControlRSExample5Probe7Console23formatPositionInterruptEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE, .-_ZN21MotorControlRSExample5Probe7Console23formatPositionInterruptEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE
	.section	.rodata.str1.1
.LC1088:
	.string	"move-angle"
.LC1090:
	.string	"move-relative"
.LC1092:
	.string	"move-absolute"
.LC1100:
	.string	"write"
.LC1102:
	.string	"verify"
.LC1104:
	.string	"stored"
.LC1110:
	.string	"%.17g"
.LC1112:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"move_kin"
	.ascii	"d\":\"%s\",\"read_kind\":null,\"action_kind\":null,\"capture"
	.ascii	"_read\":false,\"recovery\":false,\"ok\":%s,\"state\":\"%s\","
	.ascii	"\"outcome\":\"%s\",\"status\":\"%s\",\"detail\":%ld,\"setup_"
	.ascii	"execution\":\"%s\",\"execution\":\"%s\",\"completion\":\"%s\""
	.ascii	",\"target\":%lu,\"address\":%u,\"generation\":%lu,\"configur"
	.ascii	"ation_generation\":%lu,\"started_us\":%llu,\"deadline_us\":%"
	.ascii	"llu,\"serviced_us\":%llu,\"polls\":%u,\"staging_applied\":%s"
	.ascii	",\"uncertain\":%s,\"running_observed\":%s,\"observation_know"
	.ascii	"n\":%s,\"raw_alarm\":%s,\"raw_motion\":%s,\"native_rpm\":%u,"
	.ascii	"\"ramp\":\"configured\",\"staging_words\":[%u,%u,%u,%u,%u],\""
	.ascii	"requested\":{\"numerator\":%lld,\"denominator\":%llu,\"unit\""
	.ascii	":\"%s\",\"frame\":%u,\"relative\":%s,\"wrapped\":%s,\"angle_"
	.ascii	"path\":%u,\"half_turn_tie\":%u,\"basis\":%u,\"rounding\":%u,"
	.ascii	"\"approximate\":%s,\"rational_radians\":%s,\"radians\":%s,\""
	.ascii	"maximum_quantization_error\":%.17g,\"maximum_approximation_e"
	.ascii	"rror\":%s},\"effective_native"
	.string	"\":%lld,\"endpoint_known\":%s,\"endpoint_native\":%lld,\"displacement_known\":%s,\"displacement_native\":%lld,\"zero_displacement\":%s,\"rounding_error\":%.17g,\"approximation_error_bound\":%.17g,\"exact_arithmetic\":%s,\"requested_native_approximate\":%s,\"staging_evidence\":"
.LC1115:
	.string	",\"setup\":\"%s\",\"trigger_step\":%u,\"setup_offset\":%u,\"setup_count\":%u,\"verification_known\":%s,\"verification_words\":[%u,%u,%u,%u,%u],\"verification_raw_hex\":\""
.LC1117:
	.string	"%s\",\"verification_evidence\":"
.LC1120:
	.string	",\"activity_evidence\":"
.LC1124:
	.ascii	",\"prerequisites\":{\"target\":%lu,\"generation\":%lu,\"conf"
	.ascii	"iguration_generation\":%lu,\"observed_us\":%llu,\"maximum_ag"
	.ascii	"e_us\":%llu,\"raw_alarm\":%u,\"raw_motion\":%u,\"command_uni"
	.ascii	"ts_ve"
	.string	"rified\":%s,\"relative_basis_verified\":%s,\"negative_encoding_verified\":%s,\"configured_ramp_verified\":%s,\"serial_inputs_permit\":%s,\"readiness_qualified\":%s,\"word_order_known\":%s,\"word_order\":%u,\"start_speed_known\":%s,\"start_speed\":%u},\"interrupted_by_stop\":%s"
.LC1126:
	.string	",\"reference\":{\"target\":%lu,\"generation\":%lu,\"configuration_generation\":%lu,\"native_known\":%s,\"native_position\":%lld,\"basis\":%u,\"source\":%u,\"observed_us\":%llu,\"maximum_age_us\":%llu}"
.LC1129:
	.string	",\"position_feedback_matches_command\":%s,\"position_confirmed\":%s,\"position_mismatch\":%s,\"observed_position\":%ld,\"observed_speed\":%u,\"position_match_evidence\":"
	.section	.rodata
.LC1108:
	.string	"null"
	.zero	27
	.text
	.literal_position
	.literal .LC1082, .LC807
	.literal .LC1083, .LC809
	.literal .LC1084, .LC315
	.literal .LC1085, .LC311
	.literal .LC1086, .LC313
	.literal .LC1087, .LC1066
	.literal .LC1089, .LC1088
	.literal .LC1091, .LC1090
	.literal .LC1093, .LC1092
	.literal .LC1094, .LC361
	.literal .LC1095, .LC363
	.literal .LC1096, .LC959
	.literal .LC1097, .LC263
	.literal .LC1098, .LC962
	.literal .LC1099, .LC964
	.literal .LC1101, .LC1100
	.literal .LC1103, .LC1102
	.literal .LC1105, .LC1104
	.literal .LC1106, .LC842
	.literal .LC1107, .LC844
	.literal .LC1109, .LC1108
	.literal .LC1111, .LC1110
	.literal .LC1113, .LC1112
	.literal .LC1114, 16384
	.literal .LC1116, .LC1115
	.literal .LC1118, .LC1117
	.literal .LC1119, .LC1078
	.literal .LC1121, .LC1120
	.literal .LC1122, .LC977
	.literal .LC1123, .LC979
	.literal .LC1125, .LC1124
	.literal .LC1127, .LC1126
	.literal .LC1128, .LC430
	.literal .LC1130, .LC1129
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console10formatMoveEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE
	.type	_ZN21MotorControlRSExample5Probe7Console10formatMoveEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE, @function
_ZN21MotorControlRSExample5Probe7Console10formatMoveEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE:
.LFB1223:
	entry	sp, 752
.LCFI77:
	extui	a8, a7, 0, 8
	s32i	a8, sp, 480
	addmi	a9, sp, 0x100
	movi	a8, 0x1f0
	add.n	a8, a8, a9
	l8ui	a8, a8, 0
	s32i	a2, sp, 476
	s32i	a8, sp, 528
	l8ui	a8, a6, 1
	s32i	a3, sp, 520
	s32i	a4, sp, 524
	s32i	a5, sp, 472
	bnei	a8, 1, .L1922
	l32i	a8, sp, 756
	l32i	a15, sp, 480
	s32i	a8, sp, 4
	l32i	a8, sp, 528
	mov.n	a10, a2
	s32i	a8, sp, 0
	mov.n	a14, a6
	mov.n	a13, a5
	mov.n	a12, a4
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console23formatPositionInterruptEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE
	mov.n	a2, a10
	j	.L1923
.L1922:
	movi.n	a8, 0
	s32i	a8, sp, 448
	addmi	a8, a6, 0x100
	l8ui	a9, a8, 236
	movi.n	a5, 0
	bnei	a9, 2, .L1924
	l8ui	a5, a8, 240
	addi.n	a5, a5, -1
	nsau	a5, a5
	srli	a5, a5, 5
.L1924:
	movi	a7, 0x130
	add.n	a7, sp, a7
	l32r	a3, .LC1106
	movi	a2, 0x87
	add.n	a2, a7, a2
	movi.n	a12, 5
	mov.n	a11, a3
	mov.n	a10, a2
	call8	memcpy
	movi	a10, 0x8c
	movi.n	a12, 3
	movi.n	a11, 0
	add.n	a10, a7, a10
	call8	memset
	addi	a4, a7, 127
	movi.n	a12, 5
	mov.n	a11, a3
	mov.n	a10, a4
	call8	memcpy
	movi	a10, 0x84
	movi.n	a12, 3
	movi.n	a11, 0
	add.n	a10, a7, a10
	call8	memset
	addmi	a8, a6, 0x100
	l8ui	a8, a8, 244
	beqz.n	a8, .L1927
	l32r	a7, .LC1107
	addmi	a3, a6, 0x200
	l16ui	a13, a3, 98
	mov.n	a12, a7
	movi.n	a11, 8
	mov.n	a10, a2
	call8	snprintf
	l16ui	a13, a3, 100
	mov.n	a12, a7
	movi.n	a11, 8
	mov.n	a10, a4
	call8	snprintf
.L1927:
	movi	a7, 0x130
	add.n	a7, sp, a7
	l32r	a4, .LC1109
	addi	a3, a7, 64
	movi.n	a12, 5
	mov.n	a11, a4
	mov.n	a10, a3
	call8	memcpy
	movi.n	a12, 0x1b
	movi.n	a11, 0
	addi	a10, a7, 69
	call8	memset
	movi.n	a12, 5
	mov.n	a11, a4
	addi	a10, a7, 32
	call8	memcpy
	movi.n	a12, 0x1b
	movi.n	a11, 0
	addi	a10, a7, 37
	call8	memset
	movi.n	a12, 5
	mov.n	a11, a4
	mov.n	a10, a7
	call8	memcpy
	movi.n	a12, 0x1b
	movi.n	a11, 0
	addi.n	a10, a7, 5
	call8	memset
	l8ui	a8, a6, 96
	bnei	a8, 5, .L1932
	l8ui	a8, a6, 121
	beqz.n	a8, .L1933
.L1936:
	l8ui	a8, a6, 120
	beqz.n	a8, .L1932
	j	.L1934
.L1933:
	l32i	a14, a6, 128
	l32i	a15, a6, 132
	l32r	a12, .LC1111
	movi.n	a11, 0x20
	mov.n	a10, a3
	call8	snprintf
	l8ui	a8, a6, 96
	beqi	a8, 5, .L1936
	j	.L1932
.L1934:
	movi	a10, 0x130
	l32i	a14, a6, 136
	l32i	a15, a6, 140
	l32r	a12, .LC1111
	movi.n	a11, 0x20
	add.n	a10, sp, a10
	call8	snprintf
.L1932:
	addmi	a8, a6, 0x100
	l8ui	a9, a8, 200
	bnez.n	a9, .L1937
	movi	a10, 0x150
	l32i	a14, a6, 384
	l32i	a15, a6, 388
	l32r	a12, .LC1111
	movi.n	a11, 0x20
	add.n	a10, sp, a10
	call8	snprintf
.L1937:
	l32i	a8, sp, 476
	movi	a7, 0x124
	add.n	a7, a8, a7
	l32i	a8, sp, 480
	l8ui	a3, a6, 98
	l8ui	a4, a6, 99
	bnez.n	a8, .L1938
	l32r	a8, .LC1087
	s32i	a8, sp, 468
	bnez.n	a4, .L1980
	l32r	a13, .LC1091
	bnez.n	a3, .L2078
	j	.L1981
.L1938:
	l32r	a8, .LC1082
	l32r	a13, .LC1083
	s32i	a8, sp, 468
	bnez.n	a4, .L1982
	beqz.n	a3, .L1983
.L2078:
	l32r	a8, .LC1085
	j	.L2077
.L1980:
	l32r	a13, .LC1089
	j	.L1982
.L1981:
	l32r	a13, .LC1093
	j	.L1983
.L1982:
	l32r	a8, .LC1084
	j	.L2077
.L1983:
	l32r	a8, .LC1086
.L2077:
	s32i	a8, sp, 464
	l32r	a8, .LC1095
	s32i	a8, sp, 516
	beqz.n	a5, .L1940
	l32r	a8, .LC1094
	s32i	a8, sp, 516
.L1940:
	l32r	a9, .LC1097
	addmi	a5, a6, 0x100
	l8ui	a8, a5, 236
	s32i	a9, sp, 484
	bnei	a8, 2, .L1941
	l32r	a8, .LC1096
	s32i	a8, sp, 484
.L1941:
	l8ui	a10, a5, 237
	s32i	a13, sp, 496
	addmi	a2, a6, 0x400
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	s32i	a10, sp, 536
	l8ui	a10, a2, 192
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a2, 196
	s32i	a10, sp, 540
	l8ui	a10, a5, 238
	s32i	a8, sp, 544
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	s32i	a10, sp, 548
	l8ui	a10, a5, 239
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l32r	a9, .LC1099
	l8ui	a8, a5, 240
	s32i	a10, sp, 552
	s32i	a9, sp, 488
	l32i	a13, sp, 496
	bnei	a8, 1, .L1942
	l32r	a8, .LC1098
	s32i	a8, sp, 488
.L1942:
	l32i	a8, a6, 64
	l32i	a10, a6, 616
	s32i	a8, sp, 556
	l8ui	a8, a6, 68
	l32i	a11, a6, 620
	s32i	a8, sp, 560
	l32i	a8, a6, 72
	s32i	a10, sp, 576
	s32i	a8, sp, 564
	l32i	a10, a6, 624
	l32i	a9, a6, 472
	s32i	a11, sp, 580
	s32i	a9, sp, 568
	l32i	a11, a6, 628
	s32i	a10, sp, 584
	addmi	a9, a6, 0x200
	l32i	a10, a6, 632
	l8ui	a9, a9, 137
	addmi	a8, a6, 0x100
	s32i	a11, sp, 588
	s32i	a10, sp, 592
	l32i	a11, a6, 636
	l32r	a10, .LC1095
	s32i	a9, sp, 572
	l8ui	a9, a8, 241
	s32i	a11, sp, 596
	s32i	a10, sp, 496
	beqz.n	a9, .L1943
	l32r	a9, .LC1094
	s32i	a9, sp, 496
.L1943:
	l32r	a9, .LC1095
	l8ui	a8, a8, 242
	s32i	a9, sp, 504
	beqz.n	a8, .L1944
	l32r	a8, .LC1094
	s32i	a8, sp, 504
.L1944:
	l32r	a10, .LC1095
	addmi	a8, a6, 0x100
	l8ui	a9, a8, 243
	s32i	a10, sp, 508
	beqz.n	a9, .L1945
	l32r	a9, .LC1094
	s32i	a9, sp, 508
.L1945:
	l32r	a9, .LC1095
	l8ui	a8, a8, 244
	s32i	a9, sp, 512
	beqz.n	a8, .L1946
	l32r	a8, .LC1094
	s32i	a8, sp, 512
.L1946:
	l16ui	a8, a6, 144
	l8ui	a10, a6, 96
	s32i	a8, sp, 600
	addmi	a8, a6, 0x200
	l16ui	a9, a8, 88
	s32i	a13, sp, 532
	s32i	a9, sp, 604
	l16ui	a9, a8, 90
	s32i	a9, sp, 608
	l16ui	a9, a8, 92
	s32i	a9, sp, 612
	l16ui	a9, a8, 94
	l16ui	a8, a8, 96
	s32i	a9, sp, 616
	s32i	a8, sp, 620
	l32i	a9, a6, 84
	l32i	a8, a6, 80
	s32i	a9, sp, 628
	s32i	a8, sp, 624
	l32i	a9, a6, 92
	l32i	a8, a6, 88
	s32i	a9, sp, 636
	s32i	a8, sp, 632
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	l8ui	a8, a6, 97
	s32i	a10, sp, 640
	s32i	a8, sp, 644
	l32r	a9, .LC1095
	l32i	a13, sp, 532
	beqz.n	a3, .L1947
	l32r	a9, .LC1094
.L1947:
	l32r	a10, .LC1095
	beqz.n	a4, .L1948
	l32r	a10, .LC1094
.L1948:
	l8ui	a8, a6, 100
	l32r	a11, .LC1095
	s32i	a8, sp, 648
	l8ui	a8, a6, 101
	s32i	a8, sp, 652
	l8ui	a8, a6, 102
	s32i	a8, sp, 656
	l8ui	a8, a6, 108
	s32i	a8, sp, 660
	l8ui	a8, a6, 120
	beqz.n	a8, .L1949
	l32r	a11, .LC1094
.L1949:
	l8ui	a8, a6, 121
	l32r	a14, .LC1095
	beqz.n	a8, .L1950
	l32r	a14, .LC1094
.L1950:
	l32i	a4, a6, 112
	l32i	a5, a6, 116
	addmi	a8, a6, 0x100
	s32i	a4, sp, 664
	s32i	a5, sp, 668
	l32i	a4, a8, 136
	l32i	a5, a8, 140
	l8ui	a12, a8, 144
	s32i	a4, sp, 672
	s32i	a5, sp, 676
	l32r	a15, .LC1095
	beqz.n	a12, .L1951
	l32r	a15, .LC1094
.L1951:
	l32i	a5, a8, 156
	l32i	a4, a8, 152
	l8ui	a8, a8, 160
	s32i	a5, sp, 684
	s32i	a4, sp, 680
	l32r	a5, .LC1095
	beqz.n	a8, .L1952
	l32r	a5, .LC1094
.L1952:
	addmi	a8, a6, 0x100
	l32i	a2, a8, 168
	l32i	a3, a8, 172
	l8ui	a12, a8, 176
	s32i	a2, sp, 688
	s32i	a3, sp, 692
	l32r	a4, .LC1095
	beqz.n	a12, .L1953
	l32r	a4, .LC1094
.L1953:
	l32i	a2, a8, 184
	l32i	a3, a8, 188
	s32i	a2, sp, 696
	s32i	a3, sp, 700
	l32i	a2, a8, 192
	l32i	a3, a8, 196
	l8ui	a8, a8, 200
	s32i	a3, sp, 708
	s32i	a2, sp, 704
	l32r	a3, .LC1095
	beqz.n	a8, .L1954
	l32r	a3, .LC1094
.L1954:
	movi	a8, 0x130
	add.n	a8, sp, a8
	movi	a2, 0x90
	add.n	a12, a8, a2
	s32i	a12, sp, 532
	addi	a12, a8, 32
	s32i	a12, sp, 292
	movi	a12, 0x2c0
	s32i	a3, sp, 288
	add.n	a12, a12, sp
	l32i.n	a2, a12, 0
	l32i.n	a3, a12, 4
	movi	a12, 0x2b8
	s32i	a2, sp, 280
	s32i	a3, sp, 284
	add.n	a12, a12, sp
	l32i.n	a2, a12, 0
	l32i.n	a3, a12, 4
	movi	a12, 0x2b0
	s32i	a2, sp, 272
	s32i	a3, sp, 276
	s32i	a4, sp, 264
	add.n	a12, a12, sp
	l32i	a2, a12, 0
	l32i	a3, a12, 4
	movi	a12, 0x2a8
	s32i	a2, sp, 256
	s32i	a3, sp, 260
	s32i	a5, sp, 248
	add.n	a12, a12, sp
	l32i	a4, a12, 0
	l32i	a5, a12, 4
	movi	a12, 0x2a0
	s32i	a15, sp, 232
	s32i	a4, sp, 240
	s32i	a5, sp, 244
	add.n	a12, a12, sp
	l32i	a4, a12, 0
	l32i	a5, a12, 4
	movi	a12, 0x298
	s32i	a8, sp, 216
	s32i	a4, sp, 224
	s32i	a5, sp, 228
	add.n	a12, a12, sp
	l32i.n	a4, a12, 0
	l32i.n	a5, a12, 4
	addi	a12, a8, 64
	s32i	a12, sp, 200
	s32i	a4, sp, 208
	s32i	a5, sp, 212
	s32i	a14, sp, 196
	s32i	a11, sp, 192
	l32i	a11, sp, 660
	s32i	a9, sp, 168
	s32i	a11, sp, 188
	l32i	a11, sp, 656
	l32i	a9, sp, 644
	s32i	a11, sp, 184
	l32i	a11, sp, 652
	s32i	a9, sp, 164
	l32i	a9, sp, 640
	s32i	a11, sp, 180
	l32i	a11, sp, 648
	s32i	a9, sp, 160
	movi	a9, 0x278
	s32i	a11, sp, 176
	s32i	a10, sp, 172
	add.n	a9, a9, sp
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	movi	a9, 0x270
	s32i	a10, sp, 152
	s32i	a11, sp, 156
	add.n	a9, a9, sp
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	l32i	a9, sp, 620
	s32i	a10, sp, 144
	s32i	a9, sp, 136
	l32i	a9, sp, 616
	s32i	a11, sp, 148
	s32i	a9, sp, 132
	l32i	a9, sp, 612
	mov.n	a10, a7
	s32i	a9, sp, 128
	l32i	a9, sp, 608
	s32i	a9, sp, 124
	l32i	a9, sp, 604
	s32i	a9, sp, 120
	l32i	a9, sp, 600
	s32i	a9, sp, 116
	addi	a9, a8, 127
	s32i	a9, sp, 112
	movi	a9, 0x87
	add.n	a8, a8, a9
	s32i	a8, sp, 108
	l32i	a8, sp, 512
	s32i	a8, sp, 104
	l32i	a8, sp, 508
	s32i	a8, sp, 100
	l32i	a8, sp, 504
	s32i	a8, sp, 96
	l32i	a8, sp, 496
	s32i	a8, sp, 92
	l32i	a8, sp, 572
	s32i	a8, sp, 88
	movi	a8, 0x250
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 84
	s32i	a8, sp, 80
	movi	a8, 0x248
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 76
	s32i	a8, sp, 72
	movi	a8, 0x240
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	l32i	a8, sp, 568
	s32i	a8, sp, 60
	l32i	a8, sp, 564
	s32i	a8, sp, 56
	l32i	a8, sp, 560
	s32i	a8, sp, 52
	l32i	a8, sp, 556
	s32i	a13, sp, 0
	s32i	a8, sp, 48
	l32i	a8, sp, 488
	l32i	a15, sp, 520
	s32i	a8, sp, 44
	l32i	a8, sp, 552
	l32i	a14, sp, 468
	s32i	a8, sp, 40
	l32i	a8, sp, 548
	l32r	a13, .LC1113
	s32i	a8, sp, 36
	l32i	a8, sp, 544
	l32i	a12, sp, 532
	s32i	a8, sp, 32
	l32i	a8, sp, 540
	l32r	a11, .LC1114
	s32i	a8, sp, 28
	l32i	a8, sp, 536
	s32i	a8, sp, 24
	l32i	a8, sp, 484
	s32i	a8, sp, 20
	l32i	a8, sp, 516
	s32i	a8, sp, 16
	l32i	a8, sp, 464
	s32i	a8, sp, 12
	l32i	a8, sp, 472
	s32i	a8, sp, 8
	l32i	a8, sp, 524
	s32i	a8, sp, 4
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1955
.L1957:
	movi.n	a4, 0
	j	.L1956
.L1955:
	movi	a13, 0x308
	l32i	a12, sp, 532
	l32r	a11, .LC1114
	add.n	a13, a6, a13
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1957
	l8ui	a8, a6, 147
	l32r	a14, .LC1103
	beqi	a8, 1, .L1958
	l32r	a14, .LC1101
	bnei	a8, 2, .L1958
	l32r	a14, .LC1105
.L1958:
	addmi	a8, a6, 0x200
	l8ui	a15, a8, 138
	l8ui	a10, a8, 139
	l8ui	a11, a8, 140
	l8ui	a8, a8, 141
	l32r	a9, .LC1095
	beqz.n	a8, .L1959
	l32r	a9, .LC1094
.L1959:
	addmi	a8, a6, 0x200
	l16ui	a12, a8, 150
	l32r	a13, .LC1116
	s32i	a12, sp, 28
	l16ui	a12, a8, 148
	s32i	a12, sp, 24
	l16ui	a12, a8, 146
	s32i	a12, sp, 20
	l16ui	a12, a8, 144
	s32i	a12, sp, 16
	l16ui	a8, a8, 142
	movi	a12, 0x1c0
	s32i	a11, sp, 4
	l32r	a11, .LC1114
	s32i	a10, sp, 0
	s32i	a8, sp, 12
	s32i	a9, sp, 8
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a4, a10
.L1956:
	movi	a5, 0x130
	add.n	a5, sp, a5
	addi	a3, a5, 96
	movi	a10, 0x298
	l32i	a11, a6, 680
	movi.n	a13, 0x1f
	mov.n	a12, a3
	add.n	a10, a6, a10
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	bnez.n	a4, .L1960
.L1961:
	movi.n	a2, 0
	j	.L1923
.L1960:
	movi	a8, 0x90
	add.n	a5, a5, a8
	l32r	a13, .LC1118
	l32r	a11, .LC1114
	mov.n	a14, a3
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	movi	a13, 0x2b0
	l32r	a11, .LC1114
	add.n	a13, a6, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1961
	l32r	a13, .LC1119
	l32r	a11, .LC1114
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	movi	a13, 0x360
	l32r	a11, .LC1114
	add.n	a13, a6, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1961
	l32r	a13, .LC1121
	l32r	a11, .LC1114
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	movi	a13, 0x3b8
	l32r	a11, .LC1114
	add.n	a13, a6, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1961
	l32r	a13, .LC1122
	l32r	a11, .LC1114
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	movi	a13, 0x410
	l32r	a11, .LC1114
	add.n	a13, a6, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1961
	l32r	a13, .LC1123
	l32r	a11, .LC1114
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	movi	a13, 0x468
	movi	a12, 0x1c0
	l32r	a11, .LC1114
	add.n	a13, a6, a13
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1961
	l32i	a8, a6, 152
	l32i	a9, a6, 212
	s32i	a8, sp, 464
	l32i	a8, a6, 160
	s32i	a9, sp, 492
	s32i	a8, sp, 468
	l32i	a8, a6, 180
	l32i	a9, a6, 220
	s32i	a8, sp, 484
	l32i	a8, a6, 208
	s32i	a9, sp, 500
	s32i	a8, sp, 488
	l32i	a8, a6, 216
	l8ui	a9, a6, 184
	s32i	a8, sp, 496
	l16ui	a8, a6, 202
	s32i	a8, sp, 504
	l16ui	a8, a6, 204
	s32i	a8, sp, 508
	l32r	a8, .LC1095
	beqz.n	a9, .L1962
	l32r	a8, .LC1094
.L1962:
	l8ui	a10, a6, 185
	l32r	a9, .LC1095
	beqz.n	a10, .L1963
	l32r	a9, .LC1094
.L1963:
	l8ui	a11, a6, 186
	l32r	a10, .LC1095
	beqz.n	a11, .L1964
	l32r	a10, .LC1094
.L1964:
	l8ui	a12, a6, 187
	l32r	a11, .LC1095
	beqz.n	a12, .L1965
	l32r	a11, .LC1094
.L1965:
	l8ui	a13, a6, 188
	l32r	a12, .LC1095
	beqz.n	a13, .L1966
	l32r	a12, .LC1094
.L1966:
	l8ui	a14, a6, 189
	l32r	a13, .LC1095
	beqz.n	a14, .L1967
	l32r	a13, .LC1094
.L1967:
	l8ui	a5, a6, 196
	l32r	a14, .LC1095
	beqz.n	a5, .L1968
	l32r	a14, .LC1094
.L1968:
	l8ui	a4, a6, 197
	l16ui	a3, a6, 200
	l32r	a5, .LC1095
	beqz.n	a4, .L1969
	l32r	a5, .LC1094
.L1969:
	l32i	a15, sp, 528
	l16ui	a2, a6, 198
	l32r	a4, .LC1095
	beqz.n	a15, .L1970
	l32r	a4, .LC1094
.L1970:
	s32i	a8, sp, 32
	l32i	a8, sp, 508
	s32i	a14, sp, 56
	s32i	a8, sp, 28
	l32i	a8, sp, 504
	s32i	a13, sp, 52
	s32i	a8, sp, 24
	movi	a8, 0x1f0
	s32i	a12, sp, 48
	s32i	a11, sp, 44
	s32i	a10, sp, 40
	s32i	a4, sp, 72
	s32i	a2, sp, 68
	s32i	a5, sp, 64
	s32i	a3, sp, 60
	s32i	a9, sp, 36
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 20
	s32i	a8, sp, 16
	movi	a8, 0x1e8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	movi	a12, 0x1c0
	s32i	a8, sp, 8
	l32i	a8, sp, 484
	l32i	a15, sp, 468
	l32i	a14, sp, 464
	l32r	a13, .LC1125
	l32r	a11, .LC1114
	s32i	a9, sp, 12
	s32i	a8, sp, 0
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	l8ui	a8, a6, 242
	l32i	a14, a6, 224
	l32i	a15, a6, 232
	l32i	a11, a6, 236
	l32r	a10, .LC1095
	beqz.n	a8, .L1971
	l32r	a10, .LC1094
.L1971:
	l32i	a8, a6, 280
	l32i	a9, a6, 284
	s32i	a8, sp, 32
	s32i	a9, sp, 36
	l32i	a8, a6, 264
	l32i	a9, a6, 268
	addmi	a4, a6, 0x100
	s32i	a8, sp, 24
	s32i	a9, sp, 28
	l8ui	a8, a4, 1
	movi	a5, 0x1c0
	s32i	a8, sp, 20
	l8ui	a8, a4, 0
	add.n	a5, sp, a5
	s32i	a8, sp, 16
	l32i	a8, a6, 248
	l32i	a9, a6, 252
	l32r	a13, .LC1127
	s32i	a11, sp, 0
	l32r	a11, .LC1114
	s32i	a10, sp, 4
	s32i	a8, sp, 8
	s32i	a9, sp, 12
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	l32r	a13, .LC1128
	l32r	a11, .LC1114
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	l32i	a8, sp, 448
	l32r	a14, .LC1095
	addi.n	a8, a8, -1
	s32i	a8, sp, 448
	l8ui	a8, a6, 190
	beqz.n	a8, .L1972
	l32r	a14, .LC1094
.L1972:
	l8ui	a8, a4, 245
	l32r	a15, .LC1095
	beqz.n	a8, .L1973
	l32r	a15, .LC1094
.L1973:
	l8ui	a9, a4, 246
	l32r	a8, .LC1095
	beqz.n	a9, .L1974
	l32r	a8, .LC1094
.L1974:
	l16ui	a9, a6, 508
	movi	a5, 0x1c0
	s32i	a9, sp, 8
	l32i	a9, a6, 504
	add.n	a5, sp, a5
	l32r	a13, .LC1130
	l32r	a11, .LC1114
	s32i	a9, sp, 4
	s32i	a8, sp, 0
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	l32r	a11, .LC1114
	addmi	a13, a6, 0x200
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L1961
	l32r	a6, .LC1128
	l32r	a11, .LC1114
	mov.n	a13, a6
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L1961
	l32i	a8, sp, 756
	l32i	a8, a8, 0
	bnez.n	a8, .L1975
.L1977:
	l32i	a10, sp, 476
	movi	a11, 0x1c0
	add.n	a11, sp, a11
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	bnez.n	a10, .L1976
	j	.L1961
.L1975:
	l32i	a8, sp, 448
	l32i	a12, sp, 756
	addi.n	a8, a8, -1
	mov.n	a11, a5
	mov.n	a10, a7
	s32i	a8, sp, 448
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112moveRelationEPcjRjRKNS_12MoveRelationE$constprop$0
	beqz.n	a10, .L1961
	l32r	a11, .LC1114
	mov.n	a13, a6
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L1977
	j	.L1961
.L1976:
	l32i	a9, sp, 472
	l32i	a10, sp, 480
	movi.n	a8, 0
	movnez	a9, a8, a10
	l32i	a10, sp, 476
	movi.n	a12, 0
	mov.n	a11, a9
	s32i	a9, sp, 472
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L1923:
	retw.n
.LFE1223:
	.size	_ZN21MotorControlRSExample5Probe7Console10formatMoveEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE, .-_ZN21MotorControlRSExample5Probe7Console10formatMoveEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE
	.literal_position
	.literal .LC1132, 35380
	.literal .LC1133, 35196
	.literal .LC1134, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console10reportMoveEmmRKN14MotorControlRS6ESS_RS11MoveContextEbPKNS_9HostTupleEmRKNS_12MoveRelationE
	.type	_ZN21MotorControlRSExample5Probe7Console10reportMoveEmmRKN14MotorControlRS6ESS_RS11MoveContextEbPKNS_9HostTupleEmRKNS_12MoveRelationE, @function
_ZN21MotorControlRSExample5Probe7Console10reportMoveEmmRKN14MotorControlRS6ESS_RS11MoveContextEbPKNS_9HostTupleEmRKNS_12MoveRelationE:
.LFB1222:
	entry	sp, 48
.LCFI78:
	l32i	a12, sp, 48
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	extui	a6, a6, 0, 8
	beqz.n	a8, .L2080
.L2082:
	movi.n	a2, 0
	j	.L2081
.L2080:
	l32r	a8, .LC1132
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2082
	l32i	a8, a5, 76
	bne	a8, a4, .L2082
	addmi	a8, a5, 0x100
	l8ui	a8, a8, 236
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L2082
	l32r	a7, .LC1133
	l32r	a8, .LC1134
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	j	.L2083
.L2086:
	l32i	a9, a7, 0
	bne	a9, a3, .L2084
	l32i	a9, a7, 4
	bne	a9, a4, .L2084
	l8ui	a9, a7, 8
	bnez.n	a9, .L2084
	l8ui	a8, a7, 9
	s32i	a9, a2, 148
	s8i	a8, a2, 141
	l32i	a8, sp, 52
	s32i	a9, a2, 144
	mov.n	a10, a2
	s32i	a8, sp, 4
	s32i	a6, sp, 0
	movi.n	a15, 0
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console10formatMoveEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE
	mov.n	a2, a10
	beqz.n	a10, .L2082
	l32i	a8, a7, 4
	bne	a8, a4, .L2081
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L2081
.L2084:
	addi.n	a7, a7, 12
.L2083:
	bne	a7, a8, .L2086
	j	.L2082
.L2081:
	retw.n
.LFE1222:
	.size	_ZN21MotorControlRSExample5Probe7Console10reportMoveEmmRKN14MotorControlRS6ESS_RS11MoveContextEbPKNS_9HostTupleEmRKNS_12MoveRelationE, .-_ZN21MotorControlRSExample5Probe7Console10reportMoveEmmRKN14MotorControlRS6ESS_RS11MoveContextEbPKNS_9HostTupleEmRKNS_12MoveRelationE
	.section	.rodata.str1.1
.LC1144:
	.string	"fast"
.LC1146:
	.string	"normal"
.LC1150:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"velocity"
	.ascii	"\":true,\"ok\":%s,\"state\":\"%s\",\"outcome\":\"%s\",\"stat"
	.ascii	"us\":\"%s\",\"detail\":%ld,\"setup_execution\":\"%s\",\"exec"
	.ascii	"ution\":\"%s\",\"completion\":\"%s\",\"target\":%lu,\"addres"
	.ascii	"s\":%u,\"generation\":%lu,\"configuration_generation\":%lu,\""
	.ascii	"started_us\":%llu,\"deadline_us\":%llu,\"stop_due_us\":%llu,"
	.ascii	"\"serviced_us\":%llu,\"polls\":%u,\"phase\":%u,\"staging_app"
	.ascii	"lied\":%s,\"uncertain\":%s,\"needs_stop\":%s,\"running_obser"
	.ascii	"ved\":%s,\"service_missed\":%s,\"observation_known\":%s,\"ra"
	.ascii	"w_alarm\":%s,\"raw_motion\":%s,\"native_rpm\":%d,\"ramp\":\""
	.ascii	"configured\",\"staging_words\":[%u,%u,%u],\"stop_policy\":\""
	.ascii	"%s\",\"requested\":{\"numerator\":%lld,\"denominator\":%llu,"
	.ascii	"\"position_unit\":%u,\"time_unit\":%u,\"frame\":%u,\"duratio"
	.ascii	"n_us\":%lu,\"rounding\":%u,\"approximate\":%s,\"maximum_quan"
	.ascii	"tization_error_rpm\":%.17g,\"maximu"
	.string	"m_approximation_error_rpm\":%.17g},\"rounding_error\":%.17g,\"approximation_error_bound\":%.17g,\"exact_arithmetic\":%s,\"requested_rpm_approximate\":%.17g,\"stop_execution\":\"%s\",\"stop_completion\":\"%s\",\"stop_outcome\":\"%s\",\"interrupted_by_stop\":%s,\"staging_evidence\":"
.LC1156:
	.string	",\"stop_write_evidence\":"
.LC1158:
	.string	",\"stop_observation\":"
.LC1160:
	.string	",\"stop_failure_evidence\":"
.LC1162:
	.string	",\"last_observation\":{\"step\":%u,\"raw_hex\":\"%s\",\"earliest_us\":%llu,\"latest_us\":%llu,\"delivered_us\":%llu}}"
	.text
	.literal_position
	.literal .LC1135, .LC807
	.literal .LC1136, .LC809
	.literal .LC1137, .LC574
	.literal .LC1138, .LC361
	.literal .LC1139, .LC959
	.literal .LC1140, .LC363
	.literal .LC1141, .LC263
	.literal .LC1142, .LC962
	.literal .LC1143, .LC964
	.literal .LC1145, .LC1144
	.literal .LC1147, .LC1146
	.literal .LC1148, .LC842
	.literal .LC1149, .LC844
	.literal .LC1151, .LC1150
	.literal .LC1152, 16384
	.literal .LC1153, .LC1078
	.literal .LC1154, .LC1120
	.literal .LC1155, .LC979
	.literal .LC1157, .LC1156
	.literal .LC1159, .LC1158
	.literal .LC1161, .LC1160
	.literal .LC1163, .LC1162
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console14formatVelocityEmmmRKN14MotorControlRS6ESS_RS15VelocityContextEbb
	.type	_ZN21MotorControlRSExample5Probe7Console14formatVelocityEmmmRKN14MotorControlRS6ESS_RS15VelocityContextEbb, @function
_ZN21MotorControlRSExample5Probe7Console14formatVelocityEmmmRKN14MotorControlRS6ESS_RS15VelocityContextEbb:
.LFB1226:
	entry	sp, 624
.LCFI79:
	extui	a8, a7, 0, 8
	addmi	a9, sp, 0x100
	s32i	a8, sp, 388
	movi	a8, 0x170
	add.n	a8, a8, a9
	movi.n	a9, 0
	l8ui	a8, a8, 0
	s32i	a9, sp, 328
	addmi	a9, a6, 0x100
	l8ui	a10, a9, 12
	s32i	a2, sp, 336
	s32i	a3, sp, 560
	s32i	a4, sp, 564
	s32i	a8, sp, 568
	mov.n	a3, a5
	mov.n	a2, a6
	movi.n	a5, 0
	bnei	a10, 2, .L2091
	l8ui	a5, a9, 16
	addi.n	a5, a5, -1
	nsau	a5, a5
	srli	a5, a5, 5
.L2091:
	movi	a7, 0x110
	add.n	a7, sp, a7
	l32r	a11, .LC1148
	addi	a6, a7, 47
	movi.n	a12, 5
	mov.n	a10, a6
	call8	memcpy
	movi.n	a12, 3
	movi.n	a11, 0
	addi	a10, a7, 52
	call8	memset
	l32r	a11, .LC1148
	addi	a4, a7, 39
	movi.n	a12, 5
	mov.n	a10, a4
	call8	memcpy
	movi.n	a12, 3
	movi.n	a11, 0
	addi	a10, a7, 44
	call8	memset
	addmi	a9, a2, 0x100
	l8ui	a9, a9, 22
	beqz.n	a9, .L2094
	l32r	a7, .LC1149
	l16ui	a13, a2, 286
	mov.n	a12, a7
	movi.n	a11, 8
	mov.n	a10, a6
	call8	snprintf
	l16ui	a13, a2, 288
	mov.n	a12, a7
	movi.n	a11, 8
	mov.n	a10, a4
	call8	snprintf
.L2094:
	l32i	a11, a2, 632
	movi	a12, 0x110
	movi	a10, 0x262
	movi.n	a13, 0x27
	add.n	a12, sp, a12
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a8, sp, 336
	movi	a7, 0x124
	add.n	a7, a8, a7
	l32i	a8, sp, 388
	beqz.n	a8, .L2114
	l32r	a8, .LC1136
	l32r	a4, .LC1135
	s32i	a8, sp, 340
	j	.L2095
.L2114:
	l32r	a4, .LC1137
	s32i	a4, sp, 340
.L2095:
	beqz.n	a5, .L2115
	l32r	a8, .LC1138
	s32i	a8, sp, 384
	l32r	a8, .LC1139
	j	.L2178
.L2115:
	l32r	a8, .LC1140
	s32i	a8, sp, 384
	l32r	a8, .LC1141
.L2178:
	addmi	a6, a2, 0x100
	l8ui	a10, a6, 13
	s32i	a8, sp, 344
	addmi	a5, a2, 0x400
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	s32i	a10, sp, 392
	l8ui	a10, a5, 152
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a5, 156
	s32i	a10, sp, 396
	l8ui	a10, a6, 14
	s32i	a8, sp, 400
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	s32i	a10, sp, 404
	l8ui	a10, a6, 15
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l8ui	a9, a6, 16
	s32i	a10, sp, 408
	l32r	a6, .LC1143
	bnei	a9, 1, .L2097
	l32r	a6, .LC1142
.L2097:
	l32i	a8, a2, 0
	l32i	a9, a2, 300
	s32i	a8, sp, 412
	l8ui	a8, a2, 4
	s32i	a9, sp, 436
	s32i	a8, sp, 416
	l32i	a8, a2, 8
	l32i	a9, a2, 308
	s32i	a8, sp, 420
	l32i	a8, a2, 36
	s32i	a9, sp, 444
	s32i	a8, sp, 424
	l32i	a8, a2, 296
	l32i	a9, a2, 316
	s32i	a8, sp, 432
	l32i	a8, a2, 304
	s32i	a9, sp, 452
	s32i	a8, sp, 440
	l32i	a8, a2, 312
	l32i	a9, a2, 324
	s32i	a8, sp, 448
	l32i	a8, a2, 320
	s32i	a9, sp, 460
	addmi	a9, a2, 0x100
	s32i	a8, sp, 456
	l8ui	a8, a9, 81
	l8ui	a10, a9, 18
	s32i	a8, sp, 428
	l8ui	a8, a9, 17
	s32i	a8, sp, 464
	l32r	a8, .LC1140
	s32i	a8, sp, 356
	beqz.n	a10, .L2098
	l32r	a8, .LC1138
	s32i	a8, sp, 356
.L2098:
	l32r	a8, .LC1140
	l8ui	a9, a9, 19
	s32i	a8, sp, 360
	beqz.n	a9, .L2099
	l32r	a8, .LC1138
	s32i	a8, sp, 360
.L2099:
	l32r	a8, .LC1140
	addmi	a9, a2, 0x100
	l8ui	a10, a9, 20
	s32i	a8, sp, 364
	beqz.n	a10, .L2100
	l32r	a8, .LC1138
	s32i	a8, sp, 364
.L2100:
	l32r	a8, .LC1140
	l8ui	a9, a9, 21
	s32i	a8, sp, 368
	beqz.n	a9, .L2101
	l32r	a8, .LC1138
	s32i	a8, sp, 368
.L2101:
	l32r	a8, .LC1140
	addmi	a9, a2, 0x100
	l8ui	a10, a9, 23
	s32i	a8, sp, 372
	beqz.n	a10, .L2102
	l32r	a8, .LC1138
	s32i	a8, sp, 372
.L2102:
	l32r	a8, .LC1140
	l8ui	a9, a9, 22
	s32i	a8, sp, 376
	beqz.n	a9, .L2103
	l32r	a8, .LC1138
	s32i	a8, sp, 376
.L2103:
	l16si	a8, a2, 184
	l8ui	a9, a2, 120
	s32i	a8, sp, 468
	l16ui	a8, a2, 280
	s32i	a8, sp, 472
	l16ui	a8, a2, 282
	s32i	a8, sp, 476
	l16ui	a8, a2, 284
	s32i	a8, sp, 480
	l32r	a8, .LC1147
	s32i	a8, sp, 348
	bnei	a9, 2, .L2104
	l32r	a8, .LC1145
	s32i	a8, sp, 348
.L2104:
	l32i	a8, a2, 16
	l32i	a9, a2, 20
	s32i	a8, sp, 488
	l32i	a8, a2, 24
	s32i	a9, sp, 492
	s32i	a8, sp, 496
	l8ui	a8, a2, 32
	l32i	a9, a2, 28
	s32i	a8, sp, 484
	l8ui	a8, a2, 33
	s32i	a9, sp, 500
	s32i	a8, sp, 504
	l8ui	a8, a2, 34
	l8ui	a9, a2, 56
	s32i	a8, sp, 508
	l32i	a8, a2, 116
	s32i	a8, sp, 512
	l8ui	a8, a2, 40
	s32i	a8, sp, 516
	l32r	a8, .LC1140
	s32i	a8, sp, 380
	beqz.n	a9, .L2105
	l32r	a8, .LC1138
	s32i	a8, sp, 380
.L2105:
	l32i.n	a8, a2, 48
	l32i.n	a9, a2, 52
	s32i	a8, sp, 520
	l32i	a8, a2, 64
	s32i	a9, sp, 524
	l32i	a9, a2, 68
	s32i	a8, sp, 528
	l32i	a8, a2, 232
	s32i	a9, sp, 532
	l32i	a9, a2, 236
	s32i	a8, sp, 536
	l32i	a8, a2, 240
	s32i	a9, sp, 540
	l32i	a9, a2, 244
	s32i	a8, sp, 544
	l32r	a8, .LC1140
	s32i	a9, sp, 548
	l8ui	a9, a2, 248
	s32i	a8, sp, 352
	beqz.n	a9, .L2106
	l32r	a8, .LC1138
	s32i	a8, sp, 352
.L2106:
	addmi	a5, a2, 0x300
	l32i	a9, a2, 228
	l32i	a8, a2, 224
	l8ui	a10, a5, 70
	s32i	a9, sp, 556
	s32i	a8, sp, 552
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l8ui	a9, a5, 71
	l32r	a12, .LC1143
	mov.n	a11, a10
	bnei	a9, 1, .L2107
	l32r	a12, .LC1142
.L2107:
	l8ui	a10, a5, 69
	s32i	a12, sp, 576
	s32i	a11, sp, 572
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	l32i	a8, sp, 568
	l32r	a13, .LC1140
	l32i	a11, sp, 572
	l32i	a12, sp, 576
	beqz.n	a8, .L2108
	l32r	a13, .LC1138
.L2108:
	movi	a8, 0x228
	s32i	a13, sp, 260
	s32i	a12, sp, 252
	s32i	a10, sp, 256
	s32i	a11, sp, 248
	add.n	a8, a8, sp
	l32i.n	a10, a8, 0
	l32i.n	a11, a8, 4
	l32i	a8, sp, 352
	s32i	a10, sp, 240
	s32i	a8, sp, 232
	movi	a8, 0x220
	s32i	a11, sp, 244
	add.n	a8, a8, sp
	l32i.n	a10, a8, 0
	l32i.n	a11, a8, 4
	movi	a8, 0x218
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	add.n	a8, a8, sp
	l32i.n	a10, a8, 0
	l32i.n	a11, a8, 4
	movi	a8, 0x210
	s32i	a10, sp, 216
	s32i	a11, sp, 220
	add.n	a8, a8, sp
	l32i.n	a10, a8, 0
	l32i.n	a11, a8, 4
	movi	a8, 0x208
	s32i	a10, sp, 208
	s32i	a11, sp, 212
	add.n	a8, a8, sp
	l32i.n	a10, a8, 0
	l32i.n	a11, a8, 4
	l32i	a8, sp, 380
	s32i	a10, sp, 200
	s32i	a8, sp, 196
	l32i	a8, sp, 516
	s32i	a11, sp, 204
	s32i	a8, sp, 192
	l32i	a8, sp, 512
	movi	a9, 0x110
	s32i	a8, sp, 188
	l32i	a8, sp, 508
	add.n	a9, sp, a9
	s32i	a8, sp, 184
	l32i	a8, sp, 504
	addi	a5, a9, 56
	s32i	a8, sp, 180
	l32i	a8, sp, 484
	mov.n	a14, a4
	s32i	a8, sp, 176
	movi	a8, 0x1f0
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	l32i	a11, a8, 4
	movi	a8, 0x1e8
	s32i	a10, sp, 168
	s32i	a11, sp, 172
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	l32i	a11, a8, 4
	l32i	a8, sp, 348
	s32i	a10, sp, 160
	s32i	a8, sp, 152
	l32i	a8, sp, 480
	addi	a10, a9, 39
	s32i	a8, sp, 148
	l32i	a8, sp, 476
	addi	a9, a9, 47
	s32i	a8, sp, 144
	l32i	a8, sp, 472
	s32i	a11, sp, 164
	s32i	a8, sp, 140
	l32i	a8, sp, 468
	s32i	a10, sp, 132
	s32i	a8, sp, 136
	l32i	a8, sp, 376
	s32i	a9, sp, 128
	s32i	a8, sp, 124
	l32i	a8, sp, 372
	mov.n	a12, a5
	s32i	a8, sp, 120
	l32i	a8, sp, 368
	mov.n	a10, a7
	s32i	a8, sp, 116
	l32i	a8, sp, 364
	s32i	a8, sp, 112
	l32i	a8, sp, 360
	s32i	a8, sp, 108
	l32i	a8, sp, 356
	s32i	a8, sp, 104
	l32i	a8, sp, 464
	s32i	a8, sp, 100
	l32i	a8, sp, 428
	s32i	a8, sp, 96
	movi	a8, 0x1c8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 92
	s32i	a8, sp, 88
	movi	a8, 0x1c0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 84
	s32i	a8, sp, 80
	movi	a8, 0x1b8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 76
	s32i	a8, sp, 72
	movi	a8, 0x1b0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	l32i	a8, sp, 424
	s32i	a8, sp, 56
	l32i	a8, sp, 420
	s32i	a8, sp, 52
	l32i	a8, sp, 416
	s32i	a8, sp, 48
	l32i	a8, sp, 412
	l32i	a15, sp, 560
	s32i	a8, sp, 44
	l32i	a8, sp, 408
	l32r	a13, .LC1151
	s32i	a8, sp, 36
	l32i	a8, sp, 404
	l32r	a11, .LC1152
	s32i	a8, sp, 32
	l32i	a8, sp, 400
	s32i	a6, sp, 40
	s32i	a8, sp, 28
	l32i	a8, sp, 396
	s32i	a3, sp, 8
	s32i	a8, sp, 24
	l32i	a8, sp, 392
	s32i	a8, sp, 20
	l32i	a8, sp, 344
	s32i	a8, sp, 16
	l32i	a8, sp, 384
	s32i	a8, sp, 12
	l32i	a8, sp, 564
	s32i	a8, sp, 4
	l32i	a8, sp, 340
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2109
.L2111:
	movi.n	a2, 0
	j	.L2110
.L2109:
	movi	a13, 0x158
	l32r	a11, .LC1152
	add.n	a13, a2, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L2111
	l32r	a13, .LC1153
	l32r	a11, .LC1152
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2111
	movi	a13, 0x1b0
	l32r	a11, .LC1152
	add.n	a13, a2, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L2111
	l32r	a13, .LC1154
	l32r	a11, .LC1152
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2111
	movi	a13, 0x208
	l32r	a11, .LC1152
	add.n	a13, a2, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L2111
	l32r	a13, .LC1155
	l32r	a11, .LC1152
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2111
	movi	a13, 0x2b8
	l32r	a11, .LC1152
	add.n	a13, a2, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L2111
	l32r	a13, .LC1157
	l32r	a11, .LC1152
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2111
	movi	a13, 0x380
	l32r	a11, .LC1152
	add.n	a13, a2, a13
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L2111
	movi	a5, 0x110
	add.n	a5, sp, a5
	addi	a6, a5, 56
	l32r	a13, .LC1159
	l32r	a11, .LC1152
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2111
	movi	a13, 0x3d8
	l32r	a11, .LC1152
	add.n	a13, a2, a13
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L2111
	l32r	a13, .LC1161
	l32r	a11, .LC1152
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2111
	movi	a13, 0x430
	l32r	a11, .LC1152
	add.n	a13, a2, a13
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_114actionEvidenceEPcjRjRKN14MotorControlRS6ESS_RS14ActionEvidenceE
	beqz.n	a10, .L2111
	l32i	a10, a2, 664
	l32i	a11, a2, 668
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	l32i	a10, a2, 656
	l32i	a11, a2, 660
	s32i	a10, sp, 8
	s32i	a11, sp, 12
	l32i	a10, a2, 648
	l32i	a11, a2, 652
	addmi	a9, a2, 0x200
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	l8ui	a14, a9, 96
	l32r	a13, .LC1163
	l32r	a11, .LC1152
	mov.n	a15, a5
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2111
	l32i	a10, sp, 336
	mov.n	a11, a6
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	beqz.n	a10, .L2111
	l32i	a9, sp, 388
	movi.n	a8, 0
	movnez	a3, a8, a9
	l32i	a10, sp, 336
	movi.n	a12, 0
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L2110:
	retw.n
.LFE1226:
	.size	_ZN21MotorControlRSExample5Probe7Console14formatVelocityEmmmRKN14MotorControlRS6ESS_RS15VelocityContextEbb, .-_ZN21MotorControlRSExample5Probe7Console14formatVelocityEmmmRKN14MotorControlRS6ESS_RS15VelocityContextEbb
	.literal_position
	.literal .LC1165, 35380
	.literal .LC1166, 35196
	.literal .LC1167, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console14reportVelocityEmmRKN14MotorControlRS6ESS_RS15VelocityContextEbPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console14reportVelocityEmmRKN14MotorControlRS6ESS_RS15VelocityContextEbPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console14reportVelocityEmmRKN14MotorControlRS6ESS_RS15VelocityContextEbPKNS_9HostTupleEm:
.LFB1225:
	entry	sp, 48
.LCFI80:
	l32i	a12, sp, 48
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	extui	a6, a6, 0, 8
	beqz.n	a8, .L2180
.L2182:
	movi.n	a2, 0
	j	.L2181
.L2180:
	l32r	a8, .LC1165
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2182
	l32i	a8, a5, 12
	bne	a8, a4, .L2182
	addmi	a8, a5, 0x100
	l8ui	a8, a8, 12
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L2182
	l32r	a7, .LC1166
	l32r	a8, .LC1167
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	j	.L2183
.L2186:
	l32i	a9, a7, 0
	bne	a9, a3, .L2184
	l32i	a9, a7, 4
	bne	a9, a4, .L2184
	l8ui	a9, a7, 8
	bnez.n	a9, .L2184
	l8ui	a8, a7, 9
	s32i	a9, a2, 148
	s8i	a8, a2, 141
	s32i	a9, a2, 144
	mov.n	a10, a2
	s32i	a6, sp, 0
	movi.n	a15, 0
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console14formatVelocityEmmmRKN14MotorControlRS6ESS_RS15VelocityContextEbb
	mov.n	a2, a10
	beqz.n	a10, .L2182
	l32i	a8, a7, 4
	bne	a8, a4, .L2181
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L2181
.L2184:
	addi.n	a7, a7, 12
.L2183:
	bne	a7, a8, .L2186
	j	.L2182
.L2181:
	retw.n
.LFE1225:
	.size	_ZN21MotorControlRSExample5Probe7Console14reportVelocityEmmRKN14MotorControlRS6ESS_RS15VelocityContextEbPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console14reportVelocityEmmRKN14MotorControlRS6ESS_RS15VelocityContextEbPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC1168:
	.string	"checked"
.LC1170:
	.string	"read failed"
.LC1172:
	.string	"running"
.LC1174:
	.string	"not running"
.LC1176:
	.string	"released"
.LC1185:
	.string	"state_blocks"
.LC1189:
	.string	"implemented"
.LC1193:
	.string	"assigned"
.LC1196:
	.string	"connected"
.LC1198:
	.string	"unconnected"
.LC1200:
	.string	"State %s (operation %lu).\n"
.LC1206:
	.string	"Motor: %s, %s. Alarm: %u. Unknown motion bits: 0x%X.\n"
.LC1212:
	.string	"Position (raw): %lu. "
.LC1215:
	.string	"Speed (raw): %u.\n"
.LC1217:
	.string	"Position: unavailable (word order unresolved). "
.LC1219:
	.string	"Status: %s. Details: @1 result %lu."
.LC1228:
	.ascii	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command"
	.ascii	"\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"read_kin"
	.ascii	"d\":\"%s\",\"ok\":%s,\"state"
	.string	"\":\"%s\",\"outcome\":\"%s\",\"status\":\"%s\",\"detail\":%ld,\"target\":%lu,\"address\":%u,\"generation\":%lu,\"started_us\":%llu,\"deadline_us\":%llu,\"serviced_us\":%llu,\"completed_steps\":%u,\"active_serial\":{\"known\":%s,\"baud\":%lu,\"data_bits\":%u,\"parity\":%u,\"stop_bits\":%u},\"%s\":"
.LC1230:
	.string	"["
.LC1232:
	.string	"%s"
.LC1234:
	.string	"]"
.LC1237:
	.string	"{\"raw_speed\":%u,\"raw_acceleration_time\":%u,\"raw_deceleration_time\":%u,\"acceleration_time_in_range\":%s,\"deceleration_time_in_range\":%s,\"speed_signed_resolution\":%u,\"speed_scale_resolution\":%u,\"ramp_scale_resolution\":%u}"
.LC1239:
	.ascii	"{\"raw_auxiliary\":%u,\"raw_method\":%u,\"raw_search_speed\""
	.ascii	":%u,\"raw_return_speed\":%u,\"raw_ramp_time\":%u,\"raw_offse"
	.ascii	"t_words\":[%u,%u],\"auxiliary_known\":%s,\"method_kn"
	.string	"own\":%s,\"method_support\":\"%s\",\"search_speed_in_range\":%s,\"return_speed_in_range\":%s,\"ramp_time_in_range\":%s,\"speed_scale_resolution\":%u,\"ramp_scale_resolution\":%u,\"offset_word_order_resolution\":%u,\"offset_signed_resolution\":%u,\"offset_scale_resolution\":%u}"
.LC1241:
	.ascii	"{\"raw_model\":%u,\"raw_version\":%"
	.string	"u,\"raw_active_node\":%u,\"raw_dip\":%u,\"active_node_known\":%s,\"active_node\":%u,\"model_resolution\":%u,\"version_resolution\":%u,\"dip_resolution\":%u,\"dip_issues\":%lu,\"model\":\"mapping_unresolved\",\"firmware\":\"mapping_unresolved\",\"dip\":\"mapping_conflict_unresolved\"}"
.LC1244:
	.ascii	"{\"raw\":{\"direction\":%u,\"subdivision\":%u,\"custom_node\""
	.ascii	":%u,\"baud\":%u,\"format\":%u,\"over_limit_stop\":%u,\"soft_"
	.ascii	"limit_enable\":%u,\"word_order\":%u,\"input_polarity\":%u,\""
	.ascii	"algorithm\":%u,\"encoder_resolution\":%u},\"known\":{\"direc"
	.ascii	"tion\":%s,\"baud\":%s,\"format\":%s,\"over_limit_stop\":%s,\""
	.ascii	"soft_limit_enabl"
	.string	"e\":%s,\"word_order\":%s,\"algorithm\":%s},\"unknown_polarity_bits\":%u,\"subdivision_resolution\":%u,\"encoder_resolution\":%u,\"subdivision_issues\":%lu,\"custom_node_issues\":%lu,\"over_limit_stop_issues\":%lu,\"soft_limit_issues\":%lu,\"encoder_scale_source\":%u,\"inputs\":["
.LC1246:
	.string	"%s{\"function\":%u,\"known\":%s,\"inverted\":%s,\"wiring\":%u,\"level_known\":%s,\"level\":null,\"assignment\":\"%s\",\"declared_wiring\":\"%s\"}"
.LC1250:
	.string	"],\"stored_serial\":{\"baud_code\":%u,\"format_code\":%u,\"activation\":\"power_cycle_required\"},\"units\":\"command_scale_unresolved_encoder_readback_only\"}"
.LC1252:
	.string	",\"configuration_generation\":%lu"
.LC1254:
	.string	",\"decode_config\":{\"operation_id\":%lu,\"word_order_known\":%s,\"word_order\":%u,\"algorithm_known\":%s,\"algorithm\":%u}"
.LC1256:
	.string	",\"steps\":["
.LC1258:
	.ascii	"%s{\"step\":%u,\"first\":%u,\"coun"
	.string	"t\":%u,\"event\":%u,\"status\":\"%s\",\"detail\":%ld,\"frame_error\":%u,\"qualified\":%s,\"attempted_us\":%llu,\"earliest_us\":%llu,\"latest_us\":%llu,\"delivered_us\":%llu,\"tx\":\"%s\",\"rx\":\"%s\",\"received_length\":%u,\"tx_accepted\":%u,\"execution_unknown\":%s,\"transport_detail\":%ld}"
	.text
	.literal_position
	.literal .LC1169, .LC1168
	.literal .LC1171, .LC1170
	.literal .LC1173, .LC1172
	.literal .LC1175, .LC1174
	.literal .LC1177, .LC1176
	.literal .LC1178, .LC401
	.literal .LC1179, .LC807
	.literal .LC1180, .LC809
	.literal .LC1181, .LC867
	.literal .LC1182, .LC107
	.literal .LC1183, .LC361
	.literal .LC1184, .LC363
	.literal .LC1186, .LC1185
	.literal .LC1187, .LC318
	.literal .LC1188, .LC386
	.literal .LC1190, .LC1189
	.literal .LC1191, .LC679
	.literal .LC1192, .LC780
	.literal .LC1194, .LC1193
	.literal .LC1195, .LC403
	.literal .LC1197, .LC1196
	.literal .LC1199, .LC1198
	.literal .LC1201, .LC1200
	.literal .LC1202, 16384
	.literal .LC1203, 34064
	.literal .LC1207, .LC1206
	.literal .LC1213, .LC1212
	.literal .LC1216, .LC1215
	.literal .LC1218, .LC1217
	.literal .LC1220, .LC1219
	.literal .LC1221, 33064
	.literal .LC1222, 33232
	.literal .LC1223, 34264
	.literal .LC1224, 34416
	.literal .LC1225, CSWTCH$1337
	.literal .LC1226, CSWTCH$1341
	.literal .LC1227, CSWTCH$1343
	.literal .LC1229, .LC1228
	.literal .LC1231, .LC1230
	.literal .LC1233, .LC1232
	.literal .LC1235, .LC1234
	.literal .LC1236, .LC422
	.literal .LC1238, .LC1237
	.literal .LC1240, .LC1239
	.literal .LC1242, .LC1241
	.literal .LC1243, 33248
	.literal .LC1245, .LC1244
	.literal .LC1247, .LC1246
	.literal .LC1251, .LC1250
	.literal .LC1253, .LC1252
	.literal .LC1255, .LC1254
	.literal .LC1257, .LC1256
	.literal .LC1259, .LC1258
	.literal .LC1260, .LC499
	.literal .LC1261, .LC772
	.literal .LC1263, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console10formatReadEmmmRKN14MotorControlRS6ESS_RS11ReadContextEb
	.type	_ZN21MotorControlRSExample5Probe7Console10formatReadEmmmRKN14MotorControlRS6ESS_RS11ReadContextEb, @function
_ZN21MotorControlRSExample5Probe7Console10formatReadEmmmRKN14MotorControlRS6ESS_RS11ReadContextEb:
.LFB1227:
	entry	sp, 368
.LCFI81:
	extui	a8, a7, 0, 8
	s32i	a8, sp, 232
	l8ui	a9, a2, 141
	movi.n	a8, 0
	s32i	a4, sp, 320
	s32i	a8, sp, 212
	s32i	a3, sp, 264
	s32i	a5, sp, 228
	l8ui	a4, a6, 20
	l8ui	a8, a6, 21
	bnez.n	a9, .L2191
	l32i	a9, sp, 232
	bnez.n	a9, .L2191
	bnei	a4, 2, .L2191
	movi	a7, 0x124
	l32r	a14, .LC1171
	add.n	a7, a2, a7
	bnei	a8, 2, .L2192
	l32r	a14, .LC1169
.L2192:
	l32i	a15, sp, 228
	l32r	a13, .LC1201
	l32r	a11, .LC1202
	addi	a5, sp, 112
	addi	a12, a5, 100
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	l32r	a4, .LC1203
	s32i	a10, sp, 224
	add.n	a4, a2, a4
	mov.n	a3, a10
	mov.n	a12, a4
	movi.n	a11, 0
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS13getStateBlockERKNS0_11ReadContextEhRNS0_16StateObservationE
	s32i	a10, sp, 112
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2193
	l32i	a8, sp, 224
	beqz.n	a8, .L2193
	movi	a8, 0x632
	addmi	a8, a8, 0x7f00
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	l32r	a14, .LC1175
	beqz.n	a8, .L2194
	l32r	a14, .LC1173
.L2194:
	movi	a8, 0x634
	addmi	a8, a8, 0x7f00
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	l32r	a15, .LC1178
	beqz.n	a8, .L2195
	l32r	a15, .LC1177
.L2195:
	movi	a8, 0x62a
	addmi	a8, a8, 0x7f00
	add.n	a8, a2, a8
	l16ui	a8, a8, 0
	l32r	a13, .LC1207
	s32i	a8, sp, 4
	movi	a8, 0x626
	addmi	a8, a8, 0x7f00
	add.n	a8, a2, a8
	l16ui	a8, a8, 0
	l32r	a11, .LC1202
	s32i	a8, sp, 0
	addi	a12, a5, 100
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a3, a10
.L2193:
	mov.n	a12, a4
	movi.n	a11, 2
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS13getStateBlockERKNS0_11ReadContextEhRNS0_16StateObservationE
	s32i	a10, sp, 112
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2196
	movi	a8, 0x64c
	addmi	a8, a8, 0x7f00
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2197
	bnez.n	a3, .L2198
.L2200:
	movi.n	a2, 0
	j	.L2199
.L2198:
	movi	a8, 0x650
	addmi	a8, a8, 0x7f00
	add.n	a8, a2, a8
	l32i	a14, a8, 0
	l32r	a13, .LC1213
	l32r	a11, .LC1202
	addi	a12, a5, 100
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L2371:
	beqz.n	a10, .L2200
	movi	a8, 0x64a
	addmi	a8, a8, 0x7f00
	add.n	a8, a2, a8
	l16ui	a14, a8, 0
	l32r	a13, .LC1216
	l32r	a11, .LC1202
	addi	a12, a5, 100
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2201
	j	.L2200
.L2197:
	beqz.n	a3, .L2200
	l32r	a13, .LC1218
	l32r	a11, .LC1202
	addi	a12, a5, 100
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2371
.L2201:
	l8ui	a10, a6, 52
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a15, sp, 228
	l32r	a13, .LC1220
	l32r	a11, .LC1202
	mov.n	a14, a10
	addi	a12, a5, 100
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2200
	j	.L2203
.L2196:
	bnez.n	a3, .L2201
	j	.L2200
.L2203:
	l32i	a11, sp, 228
	movi.n	a12, 1
	j	.L2374
.L2191:
	movi.n	a3, 0
	bnei	a8, 2, .L2205
	bnez.n	a4, .L2206
	l32r	a11, .LC1221
	mov.n	a10, a6
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS11getIdentityERKNS0_11ReadContextERNS0_19IdentityObservationE
	s32i	a10, sp, 112
	movi.n	a3, 1
	extui	a10, a10, 0, 8
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	movnez	a3, a4, a10
	j	.L2205
.L2206:
	bnei	a4, 1, .L2207
	l32r	a11, .LC1222
	mov.n	a10, a6
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS9getConfigERKNS0_11ReadContextERNS0_17ConfigObservationE
	s32i	a10, sp, 112
	extui	a10, a10, 0, 8
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	moveqz	a3, a4, a10
	j	.L2205
.L2207:
	bnei	a4, 3, .L2209
	l32r	a11, .LC1223
	mov.n	a10, a6
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS21getVelocityParametersERKNS0_11ReadContextERNS0_29VelocityParametersObservationE
	s32i	a10, sp, 112
	movi.n	a8, 1
	extui	a10, a10, 0, 8
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	moveqz	a3, a8, a10
	j	.L2205
.L2209:
	movi.n	a3, 1
	bnei	a4, 4, .L2205
	l32r	a11, .LC1224
	mov.n	a10, a6
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS19getHomingParametersERKNS0_11ReadContextERNS0_27HomingParametersObservationE
	s32i	a10, sp, 112
	extui	a10, a10, 0, 8
	nsau	a3, a10
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	srli	a3, a3, 5
.L2205:
	movi	a8, 0x124
	add.n	a8, a2, a8
	s32i	a8, sp, 224
	l32i	a8, sp, 232
	l8ui	a7, a6, 20
	bnez.n	a8, .L2280
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE
	l32r	a8, .LC1181
	s32i	a10, sp, 236
	s32i	a8, sp, 244
	j	.L2210
.L2280:
	l32r	a8, .LC1179
	s32i	a8, sp, 244
	l32r	a8, .LC1180
	s32i	a8, sp, 236
.L2210:
	l32r	a15, .LC1182
	bgeui	a7, 5, .L2211
	l32r	a8, .LC1225
	addx4	a8, a7, a8
	l32i	a15, a8, 0
.L2211:
	l32r	a8, .LC1184
	s32i	a8, sp, 240
	beqz.n	a3, .L2212
	l32r	a8, .LC1183
	s32i	a8, sp, 240
.L2212:
	l32r	a9, .LC1182
	l8ui	a8, a6, 21
	s32i	a9, sp, 256
	bgeui	a8, 4, .L2213
	l32r	a9, .LC1226
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	s32i	a8, sp, 256
.L2213:
	l32r	a9, .LC1182
	l8ui	a8, a6, 22
	s32i	a9, sp, 248
	bgeui	a8, 7, .L2214
	l32r	a9, .LC1227
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	s32i	a8, sp, 248
.L2214:
	l8ui	a10, a6, 52
	s32i	a15, sp, 324
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a6, 56
	l32i	a9, a6, 28
	s32i	a8, sp, 272
	l32i	a8, a6, 0
	s32i	a9, sp, 300
	s32i	a8, sp, 280
	l8ui	a8, a6, 4
	l32i	a9, a6, 36
	s32i	a8, sp, 268
	l32i	a8, a6, 8
	s32i	a9, sp, 308
	s32i	a8, sp, 288
	l32i	a8, a6, 24
	l32i	a9, a6, 44
	s32i	a8, sp, 296
	l32i	a8, a6, 32
	s32i	a9, sp, 316
	s32i	a8, sp, 304
	l32i	a8, a6, 40
	l8ui	a9, a6, 64
	s32i	a8, sp, 312
	l8ui	a8, a6, 49
	l32i	a15, sp, 324
	s32i	a8, sp, 292
	l32r	a8, .LC1184
	beqz.n	a9, .L2215
	l32r	a8, .LC1183
.L2215:
	l32i	a11, a6, 68
	l8ui	a12, a6, 72
	l8ui	a13, a6, 73
	l8ui	a14, a6, 74
	mov.n	a9, a15
	bnei	a7, 2, .L2216
	l32r	a9, .LC1186
.L2216:
	s32i	a8, sp, 76
	l32i	a8, sp, 292
	s32i	a14, sp, 92
	s32i	a8, sp, 72
	movi	a8, 0x138
	s32i	a13, sp, 88
	s32i	a12, sp, 84
	s32i	a11, sp, 80
	s32i	a9, sp, 96
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	movi	a8, 0x130
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 60
	s32i	a8, sp, 56
	movi	a8, 0x128
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 52
	s32i	a8, sp, 48
	l32i	a8, sp, 288
	s32i	a10, sp, 28
	s32i	a8, sp, 44
	l32i	a8, sp, 268
	addi	a5, sp, 112
	s32i	a8, sp, 40
	l32i	a8, sp, 280
	addi	a7, a5, 100
	s32i	a8, sp, 36
	l32i	a8, sp, 272
	mov.n	a12, a7
	s32i	a8, sp, 32
	l32i	a8, sp, 248
	s32i	a8, sp, 24
	l32i	a8, sp, 256
	s32i	a8, sp, 20
	l32i	a8, sp, 240
	s32i	a15, sp, 12
	s32i	a8, sp, 16
	l32i	a8, sp, 228
	l32i	a15, sp, 264
	s32i	a8, sp, 8
	l32i	a8, sp, 320
	l32i	a14, sp, 244
	s32i	a8, sp, 4
	l32i	a8, sp, 236
	l32r	a13, .LC1229
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	l8ui	a9, a6, 20
	mov.n	a8, a10
	bnei	a9, 2, .L2217
	beqz.n	a10, .L2218
	s32i	a10, sp, 236
	l32r	a13, .LC1231
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	mov.n	a12, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	l32r	a3, .LC1203
	l32i	a8, sp, 236
	movi.n	a4, 0
	add.n	a3, a2, a3
	j	.L2219
.L2222:
	mov.n	a12, a3
	mov.n	a11, a4
	mov.n	a10, a6
	s32i	a8, sp, 240
	s32i	a9, sp, 236
	call8	_ZN14MotorControlRS6ESS_RS13getStateBlockERKNS0_11ReadContextEhRNS0_16StateObservationE
	s32i	a10, sp, 112
	s32i	a11, sp, 116
	s32i	a12, sp, 120
	extui	a10, a10, 0, 8
	l32i	a9, sp, 236
	l32i	a8, sp, 240
	bnez.n	a10, .L2220
	l32r	a14, .LC1188
	beqz.n	a8, .L2221
	l32r	a14, .LC1187
.L2221:
	l32r	a13, .LC1233
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	mov.n	a12, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a9, a10
	movi.n	a8, 0
	beqz.n	a10, .L2220
	l32i	a10, sp, 224
	mov.n	a12, a3
	mov.n	a11, a7
	s32i	a8, sp, 236
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateValueEPcjRjRKN14MotorControlRS6ESS_RS16StateObservationE$constprop$0
	l32i	a8, sp, 236
	mov.n	a9, a10
.L2220:
	addi.n	a4, a4, 1
	mov.n	a10, a9
.L2219:
	extui	a11, a4, 0, 8
	addi	a11, a11, -3
	movi.n	a9, 1
	moveqz	a9, a11, a11
	and	a9, a10, a9
	bnez.n	a9, .L2222
	bnez.n	a10, .L2223
.L2218:
	movi.n	a10, 0
	j	.L2224
.L2223:
	l32r	a13, .LC1235
	addi	a12, a5, 100
	j	.L2372
.L2217:
	bnez.n	a3, .L2225
	beqz.n	a10, .L2218
	l32r	a13, .LC1236
	mov.n	a12, a7
.L2372:
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2224
.L2225:
	bnei	a9, 3, .L2226
	beqz.n	a10, .L2218
	l32r	a8, .LC1223
	add.n	a9, a2, a8
	l8ui	a10, a9, 26
	l16ui	a14, a9, 20
	l16ui	a15, a9, 22
	l16ui	a11, a9, 24
	l32r	a9, .LC1184
	beqz.n	a10, .L2227
	l32r	a9, .LC1183
.L2227:
	add.n	a10, a2, a8
	l8ui	a12, a10, 27
	l32r	a10, .LC1184
	beqz.n	a12, .L2228
	l32r	a10, .LC1183
.L2228:
	add.n	a8, a2, a8
	l8ui	a12, a8, 30
	l32r	a13, .LC1238
	s32i	a12, sp, 20
	l8ui	a12, a8, 29
	s32i	a12, sp, 16
	l8ui	a8, a8, 28
	s32i	a10, sp, 8
	s32i	a11, sp, 0
	l32i	a10, sp, 224
	l32r	a11, .LC1202
	s32i	a8, sp, 12
	s32i	a9, sp, 4
	addi	a12, a5, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2224
.L2226:
	bnei	a9, 4, .L2229
	l32r	a10, .LC1224
	l32r	a9, .LC1182
	add.n	a11, a2, a10
	l8ui	a12, a11, 35
	beqz.n	a12, .L2230
	l8ui	a11, a11, 40
	l32r	a9, .LC1190
	beqz.n	a11, .L2230
	l32r	a9, .LC1191
	bnei	a11, 1, .L2230
	l32r	a9, .LC1192
.L2230:
	beqz.n	a8, .L2218
	add.n	a8, a2, a10
	l16ui	a10, a8, 24
	l16ui	a14, a8, 20
	s32i	a10, sp, 236
	l16ui	a10, a8, 26
	l16ui	a15, a8, 22
	s32i	a10, sp, 240
	l16ui	a10, a8, 28
	l16ui	a3, a8, 30
	l16ui	a5, a8, 32
	l8ui	a8, a8, 34
	s32i	a10, sp, 244
	l32r	a10, .LC1184
	beqz.n	a8, .L2231
	l32r	a10, .LC1183
.L2231:
	l32r	a11, .LC1184
	beqz.n	a12, .L2232
	l32r	a11, .LC1183
.L2232:
	l32r	a8, .LC1224
	add.n	a12, a2, a8
	l8ui	a13, a12, 41
	l32r	a12, .LC1184
	beqz.n	a13, .L2233
	l32r	a12, .LC1183
.L2233:
	add.n	a8, a2, a8
	l8ui	a8, a8, 42
	l32r	a13, .LC1184
	beqz.n	a8, .L2234
	l32r	a13, .LC1183
.L2234:
	l32r	a8, .LC1224
	l32r	a7, .LC1184
	add.n	a8, a2, a8
	l8ui	a8, a8, 43
	beqz.n	a8, .L2235
	l32r	a7, .LC1183
.L2235:
	l32r	a8, .LC1224
	add.n	a8, a2, a8
	l8ui	a4, a8, 48
	s32i	a4, sp, 60
	l8ui	a4, a8, 47
	s32i	a4, sp, 56
	l8ui	a4, a8, 46
	s32i	a4, sp, 52
	l8ui	a4, a8, 45
	s32i	a4, sp, 48
	l8ui	a8, a8, 44
	s32i	a13, sp, 36
	s32i	a8, sp, 44
	l32i	a8, sp, 244
	s32i	a12, sp, 32
	s32i	a8, sp, 8
	l32i	a8, sp, 240
	s32i	a11, sp, 24
	s32i	a8, sp, 4
	l32i	a8, sp, 236
	s32i	a10, sp, 20
	addi	a12, sp, 112
	l32r	a13, .LC1240
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	s32i	a7, sp, 40
	s32i	a9, sp, 28
	s32i	a5, sp, 16
	s32i	a3, sp, 12
	s32i	a8, sp, 0
	addi	a12, a12, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2224
.L2229:
	bnez.n	a4, .L2236
	beqz.n	a10, .L2218
	l32r	a8, .LC1221
	add.n	a9, a2, a8
	l8ui	a12, a9, 24
	l16ui	a14, a9, 16
	l16ui	a15, a9, 18
	l16ui	a10, a9, 20
	l16ui	a11, a9, 22
	l32r	a9, .LC1184
	beqz.n	a12, .L2237
	l32r	a9, .LC1183
.L2237:
	add.n	a8, a2, a8
	l32i	a12, a8, 32
	l32r	a13, .LC1242
	s32i	a12, sp, 28
	l8ui	a12, a8, 28
	s32i	a12, sp, 24
	l8ui	a12, a8, 27
	s32i	a12, sp, 20
	l8ui	a12, a8, 26
	s32i	a12, sp, 16
	l8ui	a8, a8, 25
	s32i	a11, sp, 4
	s32i	a10, sp, 0
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	s32i	a8, sp, 12
	s32i	a9, sp, 8
	addi	a12, a5, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2224
.L2236:
	beqz.n	a10, .L2238
	l32r	a8, .LC1243
	add.n	a8, a2, a8
	l16ui	a9, a8, 4
	l16ui	a14, a8, 0
	s32i	a9, sp, 236
	l16ui	a9, a8, 6
	l16ui	a15, a8, 2
	s32i	a9, sp, 240
	l16ui	a9, a8, 8
	l16ui	a3, a8, 28
	s32i	a9, sp, 244
	l16ui	a9, a8, 10
	s32i	a9, sp, 248
	l16ui	a9, a8, 12
	s32i	a9, sp, 256
	l16ui	a9, a8, 14
	s32i	a9, sp, 272
	l16ui	a9, a8, 16
	s32i	a9, sp, 280
	l16ui	a9, a8, 26
	l32r	a8, .LC1222
	s32i	a9, sp, 268
	add.n	a9, a2, a8
	l8ui	a10, a9, 46
	l32r	a9, .LC1184
	beqz.n	a10, .L2239
	l32r	a9, .LC1183
.L2239:
	add.n	a8, a2, a8
	l8ui	a8, a8, 47
	l32r	a10, .LC1184
	beqz.n	a8, .L2240
	l32r	a10, .LC1183
.L2240:
	l32r	a8, .LC1222
	add.n	a11, a2, a8
	l8ui	a12, a11, 48
	l32r	a11, .LC1184
	beqz.n	a12, .L2241
	l32r	a11, .LC1183
.L2241:
	add.n	a8, a2, a8
	l8ui	a8, a8, 49
	l32r	a12, .LC1184
	beqz.n	a8, .L2242
	l32r	a12, .LC1183
.L2242:
	l32r	a8, .LC1222
	add.n	a13, a2, a8
	l8ui	a7, a13, 50
	l32r	a13, .LC1184
	beqz.n	a7, .L2243
	l32r	a13, .LC1183
.L2243:
	add.n	a8, a2, a8
	l8ui	a8, a8, 51
	l32r	a7, .LC1184
	beqz.n	a8, .L2244
	l32r	a7, .LC1183
.L2244:
	l32r	a8, .LC1222
	l32r	a5, .LC1184
	add.n	a8, a2, a8
	l8ui	a8, a8, 52
	beqz.n	a8, .L2245
	l32r	a5, .LC1183
.L2245:
	l32r	a8, .LC1222
	add.n	a8, a2, a8
	l8ui	a4, a8, 176
	s32i	a4, sp, 92
	l32i	a4, a8, 112
	s32i	a4, sp, 88
	l32i	a4, a8, 108
	s32i	a4, sp, 84
	l32i	a4, a8, 104
	s32i	a4, sp, 80
	l32i	a4, a8, 100
	s32i	a4, sp, 76
	l8ui	a4, a8, 117
	s32i	a4, sp, 72
	l8ui	a4, a8, 116
	s32i	a4, sp, 68
	l16ui	a8, a8, 84
	s32i	a13, sp, 52
	s32i	a8, sp, 64
	l32i	a8, sp, 268
	s32i	a12, sp, 48
	s32i	a8, sp, 28
	l32i	a8, sp, 280
	s32i	a11, sp, 44
	s32i	a8, sp, 24
	l32i	a8, sp, 272
	s32i	a10, sp, 40
	s32i	a8, sp, 20
	l32i	a8, sp, 256
	s32i	a9, sp, 36
	s32i	a5, sp, 60
	s32i	a7, sp, 56
	s32i	a3, sp, 32
	s32i	a8, sp, 16
	l32i	a8, sp, 248
	l32r	a13, .LC1245
	s32i	a8, sp, 12
	l32i	a8, sp, 244
	l32r	a11, .LC1202
	s32i	a8, sp, 8
	l32i	a8, sp, 240
	l32i	a10, sp, 224
	s32i	a8, sp, 4
	l32i	a8, sp, 236
	addi	a12, sp, 112
	s32i	a8, sp, 0
	addi	a12, a12, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a8, a10
	j	.L2238
.L2253:
	l32r	a14, .LC1188
	l32r	a8, .LC1187
	l8ui	a10, a7, 0
	l16ui	a15, a5, 0
	l32r	a11, .LC1184
	moveqz	a14, a8, a4
	beqz.n	a10, .L2247
	l32r	a11, .LC1183
.L2247:
	l8ui	a8, a7, 27
	l32r	a12, .LC1184
	beqz.n	a8, .L2248
	l32r	a12, .LC1183
.L2248:
	l8ui	a9, a7, 37
	l8ui	a8, a7, 33
	l32r	a13, .LC1184
	beqz.n	a9, .L2249
	l32r	a13, .LC1183
.L2249:
	l32r	a9, .LC1191
	beqz.n	a10, .L2250
	l32r	a9, .LC1194
	bnez.n	a15, .L2250
	l32r	a9, .LC1195
.L2250:
	l32r	a10, .LC1197
	beqi	a8, 2, .L2251
	l32r	a10, .LC1182
	bnei	a8, 1, .L2251
	l32r	a10, .LC1199
.L2251:
	s32i	a10, sp, 20
	s32i	a13, sp, 12
	s32i	a11, sp, 0
	l32r	a13, .LC1247
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	s32i	a8, sp, 8
	s32i	a12, sp, 4
	s32i	a9, sp, 16
	mov.n	a12, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a8, a10
	addi.n	a4, a4, 1
	addi.n	a7, a7, 1
	addi.n	a5, a5, 2
	j	.L2252
.L2238:
	movi	a7, 0x305
	movi	a5, 0x2f2
	addmi	a7, a7, 0x7f00
	addmi	a5, a5, 0x7f00
	addi	a9, sp, 112
	add.n	a7, a2, a7
	add.n	a5, a2, a5
	movi.n	a4, 0
	addi	a3, a9, 100
.L2252:
	beqi	a4, 4, .L2321
	bnez.n	a8, .L2253
	j	.L2218
.L2321:
	beqz.n	a8, .L2218
	l32r	a8, .LC1243
	addi	a12, sp, 112
	add.n	a8, a2, a8
	l16ui	a15, a8, 8
	l16ui	a14, a8, 6
	l32r	a13, .LC1251
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	addi	a12, a12, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L2224:
	l8ui	a8, a6, 20
	addi	a8, a8, -3
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L2255
	beqz.n	a10, .L2255
	addi	a12, sp, 112
	l32i	a14, a6, 16
	l32r	a13, .LC1253
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	addi	a12, a12, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L2255:
	l8ui	a8, a6, 20
	bnei	a8, 2, .L2373
	beqz.n	a10, .L2257
	l8ui	a8, a6, 84
	l32i	a14, a6, 80
	l32r	a15, .LC1184
	beqz.n	a8, .L2258
	l32r	a15, .LC1183
.L2258:
	l8ui	a10, a6, 85
	l16ui	a9, a6, 86
	l32r	a8, .LC1184
	beqz.n	a10, .L2259
	l32r	a8, .LC1183
.L2259:
	l16ui	a10, a6, 88
	addi	a12, sp, 112
	s32i	a10, sp, 8
	l32r	a13, .LC1255
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	s32i	a8, sp, 4
	s32i	a9, sp, 0
	addi	a12, a12, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L2373:
	beqz.n	a10, .L2257
	addi	a12, sp, 112
	l32r	a13, .LC1257
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	addi	a12, a12, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2260
.L2267:
	l16ui	a12, a7, 2
	beqz.n	a12, .L2262
	addi	a3, a5, 92
	l16ui	a11, a7, 0
	l8ui	a10, a6, 4
	movi.n	a14, 8
	mov.n	a13, a3
	s32i	a8, sp, 236
	call8	_ZN14MotorControlRS6ESS_RS18buildReadRegistersEhttPhj
	mov.n	a11, a10
	movi.n	a13, 0x11
	mov.n	a10, a3
	addi	a12, a5, 75
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a11, a7, 44
	movi.n	a13, 0x4b
	mov.n	a12, a5
	addi.n	a10, a7, 5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a8, sp, 236
	l32r	a3, .LC1188
	beqz.n	a8, .L2263
	l32r	a3, .LC1187
.L2263:
	l16ui	a8, a7, 0
	l8ui	a10, a7, 100
	s32i	a8, sp, 236
	l16ui	a8, a7, 2
	s32i	a8, sp, 240
	l8ui	a8, a7, 4
	s32i	a8, sp, 244
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l8ui	a9, a7, 52
	mov.n	a15, a10
	l8ui	a11, a7, 112
	l32i	a10, a7, 104
	l32r	a8, .LC1184
	beqz.n	a9, .L2264
	l32r	a8, .LC1183
.L2264:
	l32i	a12, a7, 56
	l32i	a13, a7, 60
	s32i	a12, sp, 248
	s32i	a13, sp, 252
	l32i	a12, a7, 64
	l32i	a13, a7, 68
	s32i	a12, sp, 256
	s32i	a13, sp, 260
	l32i	a12, a7, 72
	l32i	a13, a7, 76
	s32i	a12, sp, 272
	s32i	a13, sp, 276
	l32i	a12, a7, 80
	l32i	a13, a7, 84
	l8ui	a14, a7, 96
	s32i	a12, sp, 280
	s32i	a13, sp, 284
	l32i	a12, a7, 48
	l32i	a13, a7, 92
	l32r	a9, .LC1184
	beqz.n	a14, .L2265
	l32r	a9, .LC1183
.L2265:
	l32i	a14, a7, 88
	s32i	a9, sp, 80
	addi	a9, a5, 75
	s32i	a9, sp, 64
	movi	a9, 0x118
	s32i	a14, sp, 84
	s32i	a13, sp, 76
	s32i	a12, sp, 72
	s32i	a5, sp, 68
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	movi	a9, 0x110
	s32i	a12, sp, 56
	s32i	a13, sp, 60
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	s32i	a12, sp, 48
	s32i	a13, sp, 52
	l32i	a12, sp, 256
	l32i	a13, sp, 260
	movi	a9, 0xf8
	s32i	a12, sp, 40
	s32i	a13, sp, 44
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	s32i	a8, sp, 24
	l32i	a8, sp, 244
	s32i	a12, sp, 32
	s32i	a8, sp, 8
	l32i	a8, sp, 240
	s32i	a13, sp, 36
	s32i	a8, sp, 4
	l32i	a8, sp, 236
	s32i	a11, sp, 20
	s32i	a10, sp, 16
	s32i	a15, sp, 12
	s32i	a8, sp, 0
	l32r	a13, .LC1259
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	mov.n	a14, a3
	mov.n	a15, a4
	addi	a12, a5, 100
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a3, a10
	movi.n	a8, 0
.L2262:
	addi.n	a4, a4, 1
	addi	a7, a7, 120
	mov.n	a10, a3
	j	.L2266
.L2257:
	movi.n	a10, 0
.L2260:
	addi	a7, a6, 96
	movi.n	a4, 0
	movi.n	a8, 1
	addi	a5, sp, 112
.L2266:
	addi	a9, a4, -5
	movi.n	a3, 1
	moveqz	a3, a9, a9
	and	a3, a10, a3
	bnez.n	a3, .L2267
	bnez.n	a10, .L2268
.L2271:
	l32i	a8, sp, 232
	l32r	a12, .LC1180
	bnez.n	a8, .L2269
	j	.L2370
.L2268:
	addi	a7, sp, 112
	addi	a7, a7, 100
	l32r	a13, .LC1260
	l32r	a11, .LC1202
	l32i	a10, sp, 224
	mov.n	a12, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2271
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	bnez.n	a10, .L2272
	j	.L2200
.L2370:
	l8ui	a10, a6, 20
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE
	mov.n	a12, a10
.L2269:
	l32r	a13, .LC1261
	l32i	a11, sp, 264
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	l32i	a8, sp, 232
	bnez.n	a8, .L2204
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2273
	l32r	a8, .LC1263
	l32i	a9, sp, 228
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	j	.L2204
.L2273:
	l32i	a11, sp, 228
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console7untrackEm
.L2204:
	movi.n	a2, 1
	j	.L2199
.L2272:
	l32i	a11, sp, 228
	l32i	a8, sp, 232
	movi.n	a12, 0
	movnez	a11, a3, a8
.L2374:
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2204
.L2199:
	retw.n
.LFE1227:
	.size	_ZN21MotorControlRSExample5Probe7Console10formatReadEmmmRKN14MotorControlRS6ESS_RS11ReadContextEb, .-_ZN21MotorControlRSExample5Probe7Console10formatReadEmmmRKN14MotorControlRS6ESS_RS11ReadContextEb
	.literal_position
	.literal .LC1265, 35380
	.literal .LC1266, 35196
	.literal .LC1267, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console10reportReadEmmRKN14MotorControlRS6ESS_RS11ReadContextEPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console10reportReadEmmRKN14MotorControlRS6ESS_RS11ReadContextEPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console10reportReadEmmRKN14MotorControlRS6ESS_RS11ReadContextEPKNS_9HostTupleEm:
.LFB1217:
	entry	sp, 32
.LCFI82:
	mov.n	a12, a7
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2376
.L2378:
	movi.n	a2, 0
	j	.L2377
.L2376:
	l32r	a8, .LC1265
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2378
	l32i	a8, a5, 12
	bne	a8, a4, .L2378
	l8ui	a8, a5, 21
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L2378
	l32r	a7, .LC1266
	l32r	a8, .LC1267
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	j	.L2379
.L2382:
	l32i	a9, a7, 0
	bne	a9, a3, .L2380
	l32i	a9, a7, 4
	bne	a9, a4, .L2380
	l8ui	a9, a7, 8
	bnez.n	a9, .L2380
	l8ui	a8, a7, 9
	mov.n	a10, a2
	s8i	a8, a2, 141
	s32i	a9, a2, 148
	s32i	a9, a2, 144
	movi.n	a15, 0
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console10formatReadEmmmRKN14MotorControlRS6ESS_RS11ReadContextEb
	mov.n	a2, a10
	beqz.n	a10, .L2378
	l32i	a8, a7, 4
	bne	a8, a4, .L2377
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L2377
.L2380:
	addi.n	a7, a7, 12
.L2379:
	bne	a7, a8, .L2382
	j	.L2378
.L2377:
	retw.n
.LFE1217:
	.size	_ZN21MotorControlRSExample5Probe7Console10reportReadEmmRKN14MotorControlRS6ESS_RS11ReadContextEPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console10reportReadEmmRKN14MotorControlRS6ESS_RS11ReadContextEPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC1268:
	.string	"expired"
.LC1272:
	.string	"recovery"
.LC1278:
	.string	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"ok\":%s,\"recovery\":true,\"outcome\":\"%s\",\"transport\":\"%s\",\"requested_us\":%llu,\"deadline_us\":%llu,\"finished_us\":%llu}"
	.text
	.literal_position
	.literal .LC1269, .LC1268
	.literal .LC1270, .LC807
	.literal .LC1271, .LC809
	.literal .LC1273, .LC1272
	.literal .LC1274, .LC600
	.literal .LC1275, .LC361
	.literal .LC1276, .LC363
	.literal .LC1277, CSWTCH$1607
	.literal .LC1279, .LC1278
	.literal .LC1282, .LC772
	.literal .LC1284, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console14formatRecoveryEmmmRKNS_3Rtu14RecoveryResultEb
	.type	_ZN21MotorControlRSExample5Probe7Console14formatRecoveryEmmmRKNS_3Rtu14RecoveryResultEb, @function
_ZN21MotorControlRSExample5Probe7Console14formatRecoveryEmmmRKNS_3Rtu14RecoveryResultEb:
.LFB1228:
	entry	sp, 128
.LCFI83:
	mov.n	a8, a7
	mov.n	a11, a6
	extui	a6, a8, 0, 8
	l8ui	a8, a11, 48
	l32r	a15, .LC1269
	mov.n	a7, a2
	mov.n	a12, a4
	bgeui	a8, 4, .L2387
	l32r	a9, .LC1277
	addx4	a9, a8, a9
	l32i	a15, a9, 0
.L2387:
	movi	a4, 0x124
	add.n	a9, a7, a4
	s32i	a9, sp, 64
	beqz.n	a6, .L2396
	l32r	a13, .LC1270
	l32r	a2, .LC1271
	j	.L2388
.L2396:
	l32r	a13, .LC1273
	l32r	a2, .LC1274
.L2388:
	l32r	a4, .LC1276
	bnez.n	a8, .L2389
	l32r	a4, .LC1275
.L2389:
	l8ui	a10, a11, 49
	s32i	a12, sp, 80
	s32i	a15, sp, 76
	s32i	a13, sp, 72
	s32i	a11, sp, 68
	call8	_ZN21MotorControlRSExample3Rtu10reasonNameENS0_6ReasonE
	l32i	a11, sp, 68
	l32i	a12, sp, 80
	l32i	a8, a11, 24
	l32i	a9, a11, 28
	s32i	a8, sp, 40
	s32i	a9, sp, 44
	l32i	a8, a11, 16
	l32i	a9, a11, 20
	s32i	a8, sp, 32
	s32i	a9, sp, 36
	l32i	a8, a11, 8
	l32i	a9, a11, 12
	l32i	a15, sp, 76
	s32i	a10, sp, 16
	s32i	a12, sp, 0
	l32i	a13, sp, 72
	l32r	a12, .LC1279
	l32i	a10, sp, 64
	movi.n	a11, 1
	s32i	a8, sp, 24
	s32i	a15, sp, 12
	s32i	a9, sp, 28
	s32i	a4, sp, 8
	s32i	a5, sp, 4
	mov.n	a15, a2
	mov.n	a14, a3
	slli	a11, a11, 14
	call8	snprintf
	movi.n	a8, -1
	extui	a8, a8, 18, 14
	bgeu	a8, a10, .L2390
	l32r	a13, .LC1282
	mov.n	a12, a2
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	bnez.n	a6, .L2391
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2392
	l32r	a8, .LC1284
	add.n	a8, a7, a8
	s32i	a5, a8, 0
	j	.L2391
.L2392:
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console7untrackEm
	j	.L2391
.L2390:
	s32i	a10, sp, 48
	addi	a11, sp, 48
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	beqz.n	a10, .L2393
	movi.n	a8, 0
	movnez	a5, a8, a6
	movi.n	a12, 0
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L2391:
	movi.n	a2, 1
.L2393:
	retw.n
.LFE1228:
	.size	_ZN21MotorControlRSExample5Probe7Console14formatRecoveryEmmmRKNS_3Rtu14RecoveryResultEb, .-_ZN21MotorControlRSExample5Probe7Console14formatRecoveryEmmmRKNS_3Rtu14RecoveryResultEb
	.literal_position
	.literal .LC1286, 35380
	.literal .LC1287, 35196
	.literal .LC1288, 35376
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console14reportRecoveryEmmRKNS_3Rtu14RecoveryResultEPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console14reportRecoveryEmmRKNS_3Rtu14RecoveryResultEPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console14reportRecoveryEmmRKNS_3Rtu14RecoveryResultEPKNS_9HostTupleEm:
.LFB1203:
	entry	sp, 32
.LCFI84:
	mov.n	a12, a7
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a8, 0x8b
	slli	a8, a8, 8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2404
.L2406:
	movi.n	a2, 0
	j	.L2405
.L2404:
	l32r	a8, .LC1286
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2406
	l32r	a7, .LC1287
	l32r	a8, .LC1288
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	j	.L2407
.L2410:
	l32i	a9, a7, 0
	bne	a9, a3, .L2408
	l32i	a9, a7, 4
	bne	a9, a4, .L2408
	l8ui	a9, a7, 8
	bnez.n	a9, .L2408
	l8ui	a8, a7, 9
	mov.n	a10, a2
	s8i	a8, a2, 141
	s32i	a9, a2, 148
	s32i	a9, a2, 144
	movi.n	a15, 0
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe7Console14formatRecoveryEmmmRKNS_3Rtu14RecoveryResultEb
	mov.n	a2, a10
	beqz.n	a10, .L2406
	l32i	a8, a7, 4
	bne	a8, a4, .L2405
	movi.n	a8, 1
	s8i	a8, a7, 8
	j	.L2405
.L2408:
	addi.n	a7, a7, 12
.L2407:
	bne	a7, a8, .L2410
	j	.L2406
.L2405:
	retw.n
.LFE1203:
	.size	_ZN21MotorControlRSExample5Probe7Console14reportRecoveryEmmRKNS_3Rtu14RecoveryResultEPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console14reportRecoveryEmmRKNS_3Rtu14RecoveryResultEPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC1292:
	.string	"group-status"
.LC1294:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"ok\":%s,\"result\":\"%s\",\"bus_traffic\":false"
.LC1298:
	.string	",\"capacity\":%u,\"count\":%u,\"declaration\":%lu,\"binding_generation\":%lu,\"sequencing\":%s,\"operations\":{\"set\":%lu,\"read_state\":%lu,\"move\":%lu,\"stops\":[%lu,%lu]},\"members\":["
.LC1304:
	.string	"{\"address\":%u,\"current\":%s,\"motion_fresh\":%s,\"io_fresh\":%s,\"feedback_fresh\":%s,\"raw_alarm\":%u,\"raw_motion\":%u,\"raw_inputs\":%u,\"position_known\":%s,\"raw_position\":%lu,\"age_ms\":%s,\"settling\":%s,\"settle_until_us\":%llu,\"reserved\":%s}"
.LC1306:
	.ascii	"{\"address\":%u,\"target\":%lu,\"generation\":%lu,\"con"
	.string	"figuration_generation\":%lu,\"current\":%s,\"identity_known\":%s,\"raw_model\":%u,\"raw_version\":%u,\"raw_active_node\":%u,\"config_known\":%s,\"profile_known\":%s,\"profile\":[%u,%u,%u,%u,%u,%u],\"inputs\":[%u,%u,%u,%u],\"outputs\":[%u,%u],\"start_speed_relation_required\":%s}"
	.section	.rodata
.LC1301:
	.string	"null"
	.zero	19
	.text
	.literal_position
	.literal .LC1289, .LC363
	.literal .LC1290, .LC361
	.literal .LC1291, .LC544
	.literal .LC1293, .LC1292
	.literal .LC1295, .LC1294
	.literal .LC1296, 16384
	.literal .LC1297, .LC430
	.literal .LC1299, .LC1298
	.literal .LC1300, .LC386
	.literal .LC1302, .LC1301
	.literal .LC1303, .LC420
	.literal .LC1305, .LC1304
	.literal .LC1307, .LC1306
	.literal .LC1308, .LC1234
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console15formatGroupViewEmPKcNS0_6ActionEPKNS0_9GroupViewE
	.type	_ZN21MotorControlRSExample5Probe7Console15formatGroupViewEmPKcNS0_6ActionEPKNS0_9GroupViewE, @function
_ZN21MotorControlRSExample5Probe7Console15formatGroupViewEmPKcNS0_6ActionEPKNS0_9GroupViewE:
.LFB1230:
	entry	sp, 240
.LCFI85:
	l32r	a11, .LC1293
	mov.n	a10, a4
	s32i	a2, sp, 136
	call8	strcmp
	movi.n	a8, 0
	l32i	a9, sp, 136
	s32i	a8, sp, 120
	movi	a8, 0x124
	add.n	a8, a9, a8
	extui	a5, a5, 0, 8
	s32i	a10, sp, 140
	s32i	a8, sp, 128
	mov.n	a2, a6
	beqz.n	a5, .L2449
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	l32r	a8, .LC1289
	j	.L2415
.L2449:
	l32r	a8, .LC1290
	l32r	a10, .LC1291
.L2415:
	s32i	a10, sp, 4
	l32r	a13, .LC1295
	l32r	a11, .LC1296
	l32i	a10, sp, 128
	s32i	a8, sp, 0
	mov.n	a15, a4
	mov.n	a14, a3
	addi	a12, sp, 120
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2417
	bnez.n	a2, .L2418
.L2448:
	l32r	a13, .LC1297
	l32r	a11, .LC1296
	l32i	a10, sp, 128
	addi	a12, sp, 120
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a2, a10
	beqz.n	a10, .L2417
	j	.L2419
.L2418:
	l8ui	a11, a2, 24
	l8ui	a15, a2, 0
	l32i	a9, a2, 4
	l32i	a10, a2, 8
	l32r	a8, .LC1289
	beqz.n	a11, .L2421
	l32r	a8, .LC1290
.L2421:
	l32i	a11, a2, 44
	l32r	a13, .LC1299
	s32i	a11, sp, 28
	l32i	a11, a2, 40
	movi.n	a14, 0xf
	s32i	a11, sp, 24
	l32i	a11, a2, 36
	addi	a12, sp, 120
	s32i	a11, sp, 20
	l32i	a11, a2, 32
	s32i	a11, sp, 16
	l32i	a11, a2, 28
	s32i	a10, sp, 4
	s32i	a11, sp, 12
	l32i	a10, sp, 128
	l32r	a11, .LC1296
	s32i	a8, sp, 8
	s32i	a9, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2417
	addi	a6, a2, 48
	movi.n	a7, 0
	j	.L2422
.L2446:
	bnez.n	a7, .L2423
.L2426:
	l32i	a8, sp, 140
	beqz.n	a8, .L2424
	j	.L2477
.L2423:
	l32r	a13, .LC1300
	l32r	a11, .LC1296
	l32i	a10, sp, 128
	addi	a12, sp, 120
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2426
	j	.L2417
.L2424:
	l32r	a11, .LC1302
	movi.n	a12, 5
	addi	a10, sp, 96
	call8	memcpy
	movi.n	a12, 0x13
	movi.n	a11, 0
	addi	a10, sp, 101
	call8	memset
	l8ui	a8, a6, 48
	beqz.n	a8, .L2428
	l32i	a11, a2, 20
	l32i	a9, a6, 68
	l32i	a10, a2, 16
	l32i	a8, a6, 64
	bltu	a11, a9, .L2428
	bne	a9, a11, .L2463
	bltu	a10, a8, .L2428
.L2463:
	sub	a11, a11, a9
	bgeu	a10, a8, .L2430
	addi.n	a11, a11, -1
.L2430:
	movi	a12, 0x3e8
	movi.n	a13, 0
	sub	a10, a10, a8
	call8	__udivdi3
	l32r	a12, .LC1303
	mov.n	a14, a10
	mov.n	a15, a11
	addi	a10, sp, 96
	movi.n	a11, 0x18
	call8	snprintf
.L2428:
	l8ui	a8, a6, 20
	l8ui	a14, a6, 0
	l32r	a15, .LC1289
	beqz.n	a8, .L2431
	l32r	a15, .LC1290
.L2431:
	l8ui	a9, a6, 48
	l32r	a8, .LC1289
	beqz.n	a9, .L2432
	l32r	a8, .LC1290
.L2432:
	l8ui	a10, a6, 49
	l32r	a9, .LC1289
	beqz.n	a10, .L2433
	l32r	a9, .LC1290
.L2433:
	l8ui	a11, a6, 50
	l32r	a10, .LC1289
	beqz.n	a11, .L2434
	l32r	a10, .LC1290
.L2434:
	l8ui	a12, a6, 58
	l16ui	a3, a6, 52
	l16ui	a4, a6, 54
	l16ui	a5, a6, 56
	l32r	a11, .LC1289
	beqz.n	a12, .L2435
	l32r	a11, .LC1290
.L2435:
	l32i	a12, a6, 60
	l8ui	a13, a6, 72
	s32i	a12, sp, 144
	l32r	a12, .LC1289
	s32i	a12, sp, 132
	beqz.n	a13, .L2436
	l32r	a12, .LC1290
	s32i	a12, sp, 132
.L2436:
	l32i	a12, a6, 80
	l32i	a13, a6, 84
	s32i	a12, sp, 152
	l8ui	a12, a6, 88
	s32i	a13, sp, 156
	l32r	a13, .LC1289
	beqz.n	a12, .L2437
	l32r	a13, .LC1290
.L2437:
	movi	a12, 0x98
	s32i	a13, sp, 48
	add.n	a12, a12, sp
	l32i	a13, a12, 4
	l32i	a12, a12, 0
	s32i	a13, sp, 44
	s32i	a12, sp, 40
	l32i	a12, sp, 132
	s32i	a11, sp, 24
	s32i	a12, sp, 36
	addi	a12, sp, 96
	s32i	a12, sp, 32
	l32i	a12, sp, 144
	s32i	a10, sp, 8
	l32r	a13, .LC1305
	l32r	a11, .LC1296
	l32i	a10, sp, 128
	s32i	a12, sp, 28
	s32i	a5, sp, 20
	s32i	a4, sp, 16
	s32i	a3, sp, 12
	s32i	a9, sp, 4
	s32i	a8, sp, 0
	addi	a12, sp, 120
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L2478:
	bnez.n	a10, .L2440
.L2417:
	movi.n	a2, 0
	j	.L2439
.L2477:
	l32i	a8, a6, 12
	l8ui	a14, a6, 0
	s32i	a8, sp, 132
	l32i	a8, a6, 16
	l32i	a15, a6, 4
	s32i	a8, sp, 144
	l8ui	a8, a6, 20
	l32r	a9, .LC1289
	beqz.n	a8, .L2441
	l32r	a9, .LC1290
.L2441:
	l8ui	a8, a6, 21
	l32r	a10, .LC1289
	beqz.n	a8, .L2442
	l32r	a10, .LC1290
.L2442:
	l16ui	a8, a6, 24
	l32r	a11, .LC1289
	s32i	a8, sp, 152
	l16ui	a8, a6, 26
	s32i	a8, sp, 148
	l16ui	a8, a6, 28
	s32i	a8, sp, 160
	l8ui	a8, a6, 22
	beqz.n	a8, .L2443
	l32r	a11, .LC1290
.L2443:
	l8ui	a8, a6, 23
	l32r	a12, .LC1289
	beqz.n	a8, .L2444
	l32r	a12, .LC1290
.L2444:
	l16ui	a8, a6, 30
	l8ui	a13, a6, 89
	s32i	a8, sp, 164
	l16ui	a8, a6, 32
	l8ui	a5, a6, 45
	s32i	a8, sp, 168
	l16ui	a8, a6, 34
	l8ui	a4, a6, 46
	s32i	a8, sp, 172
	l16ui	a8, a6, 36
	l8ui	a3, a6, 47
	s32i	a8, sp, 176
	l16ui	a8, a6, 38
	s32i	a8, sp, 180
	l16ui	a8, a6, 40
	s32i	a8, sp, 184
	l8ui	a8, a6, 42
	s32i	a8, sp, 188
	l8ui	a8, a6, 43
	s32i	a8, sp, 192
	l8ui	a8, a6, 44
	s32i	a8, sp, 196
	l32r	a8, .LC1289
	beqz.n	a13, .L2445
	l32r	a8, .LC1290
.L2445:
	s32i	a8, sp, 84
	l32i	a8, sp, 196
	s32i	a12, sp, 32
	s32i	a8, sp, 68
	l32i	a8, sp, 192
	s32i	a11, sp, 28
	s32i	a8, sp, 64
	l32i	a8, sp, 188
	s32i	a10, sp, 12
	s32i	a8, sp, 60
	l32i	a8, sp, 184
	s32i	a3, sp, 80
	s32i	a8, sp, 56
	l32i	a8, sp, 180
	s32i	a4, sp, 76
	s32i	a8, sp, 52
	l32i	a8, sp, 176
	s32i	a5, sp, 72
	s32i	a8, sp, 48
	l32i	a8, sp, 172
	s32i	a9, sp, 8
	s32i	a8, sp, 44
	l32i	a8, sp, 168
	addi	a12, sp, 120
	s32i	a8, sp, 40
	l32i	a8, sp, 164
	s32i	a8, sp, 36
	l32i	a8, sp, 160
	s32i	a8, sp, 24
	l32i	a8, sp, 148
	s32i	a8, sp, 20
	l32i	a8, sp, 152
	s32i	a8, sp, 16
	l32i	a8, sp, 144
	l32r	a13, .LC1307
	s32i	a8, sp, 4
	l32i	a8, sp, 132
	l32r	a11, .LC1296
	l32i	a10, sp, 128
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2478
.L2440:
	addi.n	a8, a7, 1
	extui	a7, a8, 0, 8
	addi	a6, a6, 96
.L2422:
	l8ui	a8, a2, 0
	bgeu	a7, a8, .L2464
	addi	a8, a7, -15
	bnez.n	a8, .L2446
.L2464:
	l32r	a13, .LC1308
	l32r	a11, .LC1296
	l32i	a10, sp, 128
	addi	a12, sp, 120
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2448
	j	.L2417
.L2419:
	l32i	a10, sp, 136
	movi.n	a12, 0
	movi.n	a11, 0
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L2439:
	retw.n
.LFE1230:
	.size	_ZN21MotorControlRSExample5Probe7Console15formatGroupViewEmPKcNS0_6ActionEPKNS0_9GroupViewE, .-_ZN21MotorControlRSExample5Probe7Console15formatGroupViewEmPKcNS0_6ActionEPKNS0_9GroupViewE
	.section	.rodata.str1.1
.LC1310:
	.string	"group-clear"
.LC1312:
	.string	"group-show"
.LC1318:
	.string	"group-wiring"
.LC1329:
	.string	"show"
.LC1332:
	.string	"status"
.LC1334:
	.string	"clear"
.LC1339:
	.string	"duplicate_address"
.LC1341:
	.string	"wiring"
.LC1347:
	.string	"state"
.LC1351:
	.string	"unsupported_policy"
.LC1359:
	.string	"configured"
.LC1361:
	.string	"setup"
.LC1365:
	.string	"start"
.LC1367:
	.string	"staged"
.LC1369:
	.string	"sequential"
.LC1371:
	.string	"on-failure"
.LC1373:
	.string	"failure_policy_required"
.LC1375:
	.string	"leave"
.LC1377:
	.string	"group"
	.text
	.literal_position
	.literal .LC1309, .LC318
	.literal .LC1311, .LC1310
	.literal .LC1313, .LC1312
	.literal .LC1314, .LC1292
	.literal .LC1315, .LC756
	.literal .LC1316, .LC343
	.literal .LC1317, .LC588
	.literal .LC1319, .LC1318
	.literal .LC1320, .LC594
	.literal .LC1321, .LC592
	.literal .LC1322, .LC590
	.literal .LC1323, .LC570
	.literal .LC1324, 35584
	.literal .LC1325, 35380
	.literal .LC1326, 35064
	.literal .LC1327, 35088
	.literal .LC1330, .LC1329
	.literal .LC1331, 35576
	.literal .LC1333, .LC1332
	.literal .LC1335, .LC1334
	.literal .LC1336, .LC324
	.literal .LC1337, .LC762
	.literal .LC1338, 35065
	.literal .LC1340, .LC1339
	.literal .LC1342, .LC1341
	.literal .LC1343, .LC1196
	.literal .LC1344, .LC1198
	.literal .LC1345, .LC107
	.literal .LC1346, .LC867
	.literal .LC1348, .LC1347
	.literal .LC1349, .LC1146
	.literal .LC1350, .LC1144
	.literal .LC1352, .LC1351
	.literal .LC1353, .LC1066
	.literal .LC1354, .LC313
	.literal .LC1355, .LC315
	.literal .LC1356, .LC311
	.literal .LC1358, 65534
	.literal .LC1360, .LC1359
	.literal .LC1362, .LC1361
	.literal .LC1363, .LC1100
	.literal .LC1364, .LC1102
	.literal .LC1366, .LC1365
	.literal .LC1368, .LC1367
	.literal .LC1370, .LC1369
	.literal .LC1372, .LC1371
	.literal .LC1374, .LC1373
	.literal .LC1376, .LC1375
	.literal .LC1378, .LC1377
	.literal .LC1379, .LC754
	.literal .LC1380, 35176
	.literal .LC1381, .LC772
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console5groupEmPKPKcj
	.type	_ZN21MotorControlRSExample5Probe7Console5groupEmPKPKcj, @function
_ZN21MotorControlRSExample5Probe7Console5groupEmPKPKcj:
.LFB1229:
	entry	sp, 112
.LCFI86:
	l32r	a7, .LC1309
	beqz.n	a5, .L2480
	l32i	a7, a4, 0
.L2480:
	l32r	a11, .LC1323
	mov.n	a10, a7
	call8	strcmp
	l32r	a8, .LC1324
	s32i	a10, sp, 64
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2481
	l32r	a8, .LC1325
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2482
.L2481:
	l32i	a8, sp, 64
	bnez.n	a8, .L2483
.L2482:
	l32r	a8, .LC1326
	movi.n	a11, 0
	add.n	a6, a2, a8
	movi	a12, 0x70
	mov.n	a10, a6
	call8	memset
	l32r	a8, .LC1327
	movi.n	a9, 1
	add.n	a8, a2, a8
	s32i	a9, a8, 8
	movi.n	a9, 0
	movi.n	a10, 2
	s32i	a9, a8, 12
	l32r	a11, .LC1330
	movi.n	a9, 1
	s8i	a10, a8, 20
	s8i	a9, a8, 18
	s8i	a9, a8, 41
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L2485
	j	.L2591
.L2483:
	l32r	a8, .LC1331
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2487
	addi.n	a10, a10, 1
.L2487:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2479
.L2591:
	l32r	a11, .LC1333
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L2485
	l32r	a11, .LC1335
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2489
.L2485:
	l8ui	a8, a7, 1
	movi	a9, 0x68
	l32r	a4, .LC1313
	beq	a8, a9, .L2490
	movi	a9, 0x74
	bne	a8, a9, .L2491
	l32r	a8, .LC1326
	movi.n	a9, 1
	add.n	a8, a2, a8
	l32r	a4, .LC1314
	s8i	a9, a8, 0
	j	.L2490
.L2491:
	l32r	a8, .LC1326
	movi.n	a9, 3
	add.n	a8, a2, a8
	l32r	a4, .LC1311
	s8i	a9, a8, 0
.L2490:
	l32r	a13, .LC1315
	movi.n	a7, 0
	bnei	a5, 1, .L2592
	j	.L2492
.L2489:
	l32r	a11, .LC1336
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2493
	movi.n	a8, 2
	s8i	a8, a6, 0
	movi.n	a9, 0xe
	addi	a8, a5, -2
	l32r	a13, .LC1315
	addi.n	a6, a4, 4
	addx4	a5, a5, a4
	bltu	a9, a8, .L2594
.L2500:
	movi.n	a8, 0
	l32i	a10, a6, 0
	s32i	a8, sp, 16
	addi	a11, sp, 16
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	mov.n	a7, a10
	beqz.n	a10, .L2495
	l32i	a9, sp, 16
	movi	a10, 0xf6
	addi.n	a8, a9, -1
	bltu	a10, a8, .L2495
	l32r	a8, .LC1326
	l32r	a12, .LC1338
	add.n	a8, a2, a8
	l32i	a10, a8, 16
	movi.n	a8, 0
	j	.L2496
.L2495:
	l32r	a13, .LC1337
.L2594:
	l32r	a12, .LC1317
	j	.L2593
.L2499:
	add.n	a11, a8, a12
	add.n	a11, a2, a11
	l8ui	a11, a11, 0
	bne	a9, a11, .L2498
	l32r	a13, .LC1340
	j	.L2594
.L2498:
	addi.n	a8, a8, 1
.L2496:
	bne	a10, a8, .L2499
	l32r	a8, .LC1326
	addi.n	a11, a10, 1
	add.n	a8, a2, a8
	s32i	a11, a8, 16
	add.n	a8, a8, a10
	s8i	a9, a8, 1
	addi.n	a6, a6, 4
	bne	a5, a6, .L2500
	l32r	a4, .LC1317
	j	.L2492
.L2493:
	l32r	a11, .LC1342
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2501
	movi.n	a8, 4
	s8i	a8, a6, 0
	s32i	a10, sp, 16
	bnei	a5, 4, .L2509
	l32i	a10, a4, 4
	addi	a11, sp, 16
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L2509
	l32i	a7, sp, 16
	movi	a9, 0xf6
	addi.n	a8, a7, -1
	bltu	a9, a8, .L2509
	l32i	a6, a4, 8
	mov.n	a10, a6
	call8	strlen
	beqi	a10, 2, .L2503
.L2509:
	l32r	a13, .LC1315
	l32r	a12, .LC1319
	j	.L2593
.L2503:
	l8ui	a8, a6, 0
	movi	a9, 0x78
	bne	a8, a9, .L2504
	l8ui	a8, a6, 1
	addi	a8, a8, -48
	extui	a8, a8, 0, 8
	bgeui	a8, 4, .L2509
	j	.L2505
.L2504:
	movi	a9, 0x79
	bne	a8, a9, .L2509
	l8ui	a8, a6, 1
	addi	a8, a8, -48
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L2509
.L2505:
	l32r	a8, .LC1326
	l32r	a11, .LC1343
	add.n	a5, a2, a8
	s8i	a7, a5, 20
	l8ui	a9, a6, 0
	movi.n	a7, 1
	addi	a9, a9, -121
	movi.n	a8, 0
	moveqz	a8, a7, a9
	l8ui	a9, a6, 1
	addi	a9, a9, -48
	addx4	a8, a8, a9
	s8i	a8, a5, 21
	l32i	a6, a4, 12
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L2506
	movi.n	a8, 2
	s8i	a8, a5, 22
	j	.L2507
.L2506:
	l32r	a11, .LC1344
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L2508
	s8i	a7, a5, 22
	j	.L2507
.L2508:
	l32r	a11, .LC1345
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L2509
.L2507:
	l32r	a4, .LC1319
	movi.n	a7, 0
	j	.L2492
.L2501:
	l32r	a11, .LC1346
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2510
	movi.n	a8, 7
	s8i	a8, a6, 0
	bnei	a5, 2, .L2511
	l32i	a10, a4, 4
	l32r	a11, .LC1348
	movi.n	a7, 1
	call8	strcmp
	l32r	a4, .LC1320
	beqz.n	a10, .L2492
.L2511:
	l32r	a13, .LC1315
	l32r	a12, .LC1320
	j	.L2593
.L2510:
	l32i	a8, sp, 64
	bnez.n	a8, .L2512
	movi.n	a8, 6
	s8i	a8, a6, 0
	l32r	a13, .LC1315
	l32r	a6, .LC1321
	bnei	a5, 2, .L2596
.L2513:
	l32i	a7, a4, 4
	l32r	a11, .LC1349
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L2544
	l32r	a11, .LC1350
	mov.n	a10, a7
	call8	strcmp
	movi.n	a8, 2
	beqz.n	a10, .L2514
	l32r	a13, .LC1352
.L2596:
	mov.n	a12, a6
	j	.L2593
.L2512:
	l32r	a11, .LC1353
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2515
	movi.n	a8, 5
	s8i	a8, a6, 0
	bltui	a5, 2, .L2521
	l32i	a7, a4, 4
	l32r	a11, .LC1354
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L2547
	l32r	a11, .LC1355
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2517
.L2547:
	l32r	a13, .LC1316
	j	.L2595
.L2517:
	l32r	a11, .LC1356
	mov.n	a10, a7
	call8	strcmp
	movi.n	a8, 6
	saltu	a8, a8, a5
	addi.n	a8, a8, -1
	neg	a8, a8
	extui	a8, a8, 0, 8
	bnez.n	a8, .L2521
	movi.n	a9, 1
	movnez	a8, a9, a10
	beqz.n	a8, .L2519
	j	.L2521
.L2519:
	movi.n	a8, 0
	s32i	a8, sp, 16
	s32i	a8, sp, 20
	movi.n	a8, 1
	s32i	a8, sp, 24
	movi.n	a8, 0
	s32i	a8, sp, 28
	l32r	a8, .LC1327
	l32i	a10, a4, 8
	add.n	a7, a2, a8
	mov.n	a11, a7
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 44
	s32i	a11, sp, 48
	s32i	a12, sp, 52
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2521
	l32i	a10, a4, 12
	addi	a11, a7, 16
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE
	beqz.n	a10, .L2521
	l32i	a10, a4, 16
	addi	a11, a7, 17
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE
	mov.n	a7, a10
	beqz.n	a10, .L2521
	l32i	a10, a4, 20
	addi	a11, sp, 16
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 32
	s32i	a11, sp, 36
	s32i	a12, sp, 40
	extui	a6, a10, 0, 8
	bnez.n	a6, .L2521
	l32i	a8, sp, 24
	bnei	a8, 1, .L2521
	l32i	a8, sp, 28
	bnez.n	a8, .L2521
	l32i	a9, sp, 16
	l32i	a8, sp, 20
	addi.n	a10, a9, -1
	addi.n	a8, a8, -1
	beqz.n	a9, .L2522
	addi.n	a8, a8, 1
.L2522:
	s32i	a9, sp, 68
	bnez.n	a8, .L2521
	l32r	a8, .LC1358
	bltu	a8, a10, .L2521
	l32r	a11, .LC1360
	l32i	a10, a4, 24
	call8	strcmp
	bnez.n	a10, .L2521
	l32r	a8, .LC1327
	l32i	a9, sp, 68
	add.n	a8, a2, a8
	movi.n	a10, 1
	s8i	a10, a8, 18
	s16i	a9, a8, 64
	s8i	a10, a8, 66
	movi.n	a8, 7
	beqi	a5, 7, .L2525
	j	.L2524
.L2521:
	l32r	a13, .LC1315
	j	.L2595
.L2524:
	l32r	a11, .LC1362
	l32i	a10, a4, 28
	call8	strcmp
	bnez.n	a10, .L2548
	beqi	a5, 8, .L2521
	l32i	a8, a4, 32
	l32r	a11, .LC1363
	mov.n	a10, a8
	s32i	a8, sp, 68
	call8	strcmp
	beqz.n	a10, .L2549
	l32r	a11, .LC1364
	l32i	a10, sp, 68
	call8	strcmp
	movi.n	a9, 1
	beqz.n	a10, .L2528
	j	.L2521
.L2549:
	movi.n	a9, 0
.L2528:
	l32r	a8, .LC1327
	add.n	a8, a2, a8
	s8i	a9, a8, 67
	movi.n	a8, 9
	beq	a5, a8, .L2525
	j	.L2526
.L2548:
	movi.n	a8, 7
.L2526:
	extui	a9, a8, 0, 16
	addx4	a9, a9, a4
	l32r	a11, .LC1366
	l32i	a10, a9, 0
	s32i	a8, sp, 68
	s32i	a9, sp, 72
	call8	strcmp
	l32i	a8, sp, 68
	bnez.n	a10, .L2525
	addi	a12, a8, -7
	movi.n	a10, 8
	movi.n	a11, 0xa
	movnez	a10, a11, a12
	bgeu	a10, a5, .L2521
	l32i	a9, sp, 72
	l32r	a11, .LC1368
	l32i	a9, a9, 4
	mov.n	a10, a9
	s32i	a9, sp, 72
	call8	strcmp
	l32i	a8, sp, 68
	beqz.n	a10, .L2529
	l32r	a11, .LC1370
	l32i	a10, sp, 72
	call8	strcmp
	bnez.n	a10, .L2521
	l32i	a8, sp, 68
	movi.n	a6, 1
.L2529:
	l32r	a9, .LC1326
	addi.n	a8, a8, 2
	add.n	a9, a2, a9
	s8i	a6, a9, 97
.L2525:
	l32r	a9, .LC1326
	add.n	a9, a2, a9
	l8ui	a9, a9, 97
	bnez.n	a9, .L2530
	l32r	a9, .LC1327
	add.n	a9, a2, a9
	l8ui	a9, a9, 67
	beqi	a9, 1, .L2521
.L2530:
	bgeu	a8, a5, .L2531
	extui	a6, a8, 0, 16
	addx4	a6, a6, a4
	l32r	a11, .LC1372
	l32i	a10, a6, 0
	s32i	a8, sp, 68
	call8	strcmp
	l32i	a8, sp, 68
	beqz.n	a10, .L2532
.L2531:
	l32r	a13, .LC1374
.L2595:
	l32r	a12, .LC1322
	j	.L2593
.L2532:
	addi.n	a9, a8, 2
	bne	a9, a5, .L2533
	l32r	a11, .LC1376
	l32i	a10, a6, 4
	call8	strcmp
	beqz.n	a10, .L2551
	j	.L2531
.L2533:
	addi.n	a8, a8, 3
	bne	a8, a5, .L2531
	l32r	a11, .LC1323
	l32i	a10, a6, 4
	call8	strcmp
	bnez.n	a10, .L2531
	l32i	a6, a6, 8
	l32r	a11, .LC1349
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L2552
	l32r	a11, .LC1350
	mov.n	a10, a6
	call8	strcmp
	movi.n	a8, 2
	beqz.n	a10, .L2534
	j	.L2531
.L2551:
	movi.n	a8, 3
	j	.L2534
.L2552:
	movi.n	a8, 1
.L2534:
	l32r	a9, .LC1326
	l32r	a4, .LC1322
	add.n	a9, a2, a9
	s8i	a8, a9, 96
	j	.L2492
.L2515:
	l32r	a13, .LC1315
	l32r	a12, .LC1378
	j	.L2593
.L2544:
	movi.n	a8, 1
.L2514:
	l32r	a9, .LC1326
	movi.n	a7, 1
	add.n	a9, a2, a9
	s8i	a8, a9, 104
	mov.n	a4, a6
.L2492:
	l32i	a9, a2, 120
	l32r	a13, .LC1379
	beqz.n	a9, .L2592
.L2535:
	l32r	a8, .LC1326
	l32r	a6, .LC1380
	add.n	a8, a2, a8
	add.n	a5, a2, a6
	s32i	a8, sp, 68
	movi.n	a8, 0
	s32i	a8, a5, 0
	s8i	a8, a5, 4
	s32i	a8, a5, 8
	bnez.n	a7, .L2536
	l32i	a12, sp, 68
	l32i	a10, a2, 0
	mov.n	a13, a5
	mov.n	a11, a3
	callx8	a9
	l32i	a14, a5, 8
	mov.n	a13, a10
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15formatGroupViewEmPKcNS0_6ActionEPKNS0_9GroupViewE
	bnez.n	a10, .L2479
	l32r	a13, .LC1381
.L2592:
	mov.n	a12, a4
.L2593:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2479
.L2536:
	l32i	a9, sp, 64
	movi.n	a7, 1
	movnez	a7, a8, a9
	mov.n	a12, a7
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a9, 0xf
	movi.n	a15, 0
	movi.n	a8, 1
	beq	a10, a9, .L2537
	mov.n	a10, a2
	s32i	a15, sp, 72
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	l32i	a8, a2, 120
	l32i	a12, sp, 68
	l32i	a10, a2, 0
	mov.n	a13, a5
	mov.n	a11, a3
	callx8	a8
	l32i	a15, sp, 72
	mov.n	a8, a10
	bnez.n	a10, .L2537
	l32i	a15, a5, 0
	s32i	a10, sp, 72
	mov.n	a12, a15
	mov.n	a14, a7
	movi.n	a13, 0
	mov.n	a11, a3
	mov.n	a10, a2
	s32i	a15, sp, 68
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
	l32i	a8, sp, 72
	l32i	a15, sp, 68
.L2537:
	l32i	a9, sp, 64
	bnez.n	a9, .L2538
	l32r	a9, .LC1324
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L2539
	l32r	a9, .LC1325
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L2539
.L2538:
	add.n	a6, a2, a6
	l8ui	a14, a6, 4
	movi.n	a9, 0
	s32i	a9, sp, 8
	s32i	a9, sp, 4
	s32i	a9, sp, 0
	mov.n	a13, a8
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2479
.L2539:
	add.n	a6, a2, a6
	l8ui	a14, a6, 4
	movi.n	a9, 0
	s32i	a9, sp, 8
	s32i	a9, sp, 4
	s32i	a9, sp, 0
	mov.n	a13, a8
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15retainStopReplyEmPKcNS0_6ActionEhmbmb
.L2479:
	retw.n
.LFE1229:
	.section	.gcc_except_table
.LLSDA1229:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1229-.LLSDACSB1229
.LLSDACSB1229:
.LLSDACSE1229:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console5groupEmPKPKcj, .-_ZN21MotorControlRSExample5Probe7Console5groupEmPKPKcj
	.section	.rodata.str1.1
.LC1398:
	.string	"admitted"
.LC1400:
	.string	"not_attempted"
.LC1406:
	.string	"{\"type\":\"%s\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"command_id\":%lu,\"operation_id\":%lu,\"group_kind\":\"%s\",\"ok\":%s,\"state\":\"%s\",\"declaration\":%lu,\"binding_generation\":%lu,\"aborted\":%s,\"failed_address\":%u,\"started_us\":%llu,\"finished_us\":%llu,\"count\":%u"
.LC1409:
	.string	",\"stop_policy\":\"%s\""
.LC1414:
	.string	",\"request\":{\"relative\":true,\"value\":[%lld,%llu],\"unit\":\"%s\",\"frame\":%u,\"speed_rpm\":%u,\"setup\":\"%s\",\"start\":\"%s\"},\"on_failure\":\"%s\",\"start_tx_spread_us\":%s,\"running_bound_spread_us\":%s"
.LC1416:
	.string	",\"members\":["
.LC1419:
	.string	"{\"address\":%u,\"operation_id\":%lu,\"admission\":\"%s\",\"status\":\"%s\",\"detail\":%ld"
.LC1423:
	.string	",\"join\":\"%s\",\"read_state\":\"%s\",\"raw_model\":%u,\"raw_version\":%u,\"raw_active_node\":%u,\"config_known\":%s,\"profile_known\":%s}"
.LC1425:
	.string	",\"read_state\":\"%s\",\"state_known\":%s,\"raw_alarm\":%u,\"raw_motion\":%u,\"raw_inputs\":%u,\"position_known\":%s,\"raw_position\":%lu}"
.LC1427:
	.string	",\"state\":\"%s\",\"outcome\":\"%s\",\"execution\":\"%s\",\"completion\":\"%s\",\"uncertain\":%s,\"raw_alarm\":%u,\"raw_motion\":%u}"
.LC1430:
	.ascii	",\"start\":\"%s\",\"state\":\"%s\",\"outcome\":\"%s\",\"exec"
	.ascii	"ution\":\"%s\",\"setup_execution\":\"%s\",\"completion\":\"%"
	.ascii	"s\",\"uncertain\":%s,\"interrupted_by_stop\":%s,\"effective_"
	.ascii	"native\":%lld,\"s"
	.string	"tart_tx_complete\":%s,\"start_tx_end_us\":%llu,\"start_tx_uncertainty_us\":%lu,\"running_observed\":%s,\"running_earliest_us\":%llu,\"running_latest_us\":%llu,\"stop_operation_id\":%lu,\"stop_admission\":\"%s\",\"stop_state\":\"%s\",\"stop_execution\":\"%s\",\"stop_completion\":\"%s\""
.LC1433:
	.string	",\"stage\":\"%s\",\"stage_execution\":\"%s\",\"stage_readback\":\"%s\",\"stage_tx_complete\":%s,\"stage_tx_end_us\":%llu,\"stage_read_latest_us\":%llu,\"stage_status\":\"%s\",\"stage_detail\":%ld}"
	.text
	.literal_position
	.literal .LC1382, .LC807
	.literal .LC1383, .LC809
	.literal .LC1384, .LC1377
	.literal .LC1385, .LC107
	.literal .LC1386, .LC361
	.literal .LC1387, .LC363
	.literal .LC1388, .LC1023
	.literal .LC1389, .LC263
	.literal .LC1390, .LC959
	.literal .LC1391, .LC1144
	.literal .LC1392, .LC1146
	.literal .LC1393, .LC1100
	.literal .LC1394, .LC1102
	.literal .LC1395, .LC1104
	.literal .LC1396, .LC1367
	.literal .LC1397, .LC1369
	.literal .LC1399, .LC1398
	.literal .LC1401, .LC1400
	.literal .LC1402, .LC962
	.literal .LC1403, .LC964
	.literal .LC1404, CSWTCH$1369
	.literal .LC1405, CSWTCH$1367
	.literal .LC1407, .LC1406
	.literal .LC1408, 16384
	.literal .LC1410, .LC1409
	.literal .LC1411, .LC1301
	.literal .LC1412, .LC420
	.literal .LC1413, CSWTCH$1375
	.literal .LC1415, .LC1414
	.literal .LC1417, .LC1416
	.literal .LC1418, .LC386
	.literal .LC1420, .LC1419
	.literal .LC1421, CSWTCH$1373
	.literal .LC1422, CSWTCH$1341
	.literal .LC1424, .LC1423
	.literal .LC1426, .LC1425
	.literal .LC1428, .LC1427
	.literal .LC1429, CSWTCH$1371
	.literal .LC1431, .LC1430
	.literal .LC1432, CSWTCH$1377
	.literal .LC1434, .LC1433
	.literal .LC1435, .LC499
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console11formatGroupEmmmRKNS0_11GroupResultEb
	.type	_ZN21MotorControlRSExample5Probe7Console11formatGroupEmmmRKNS0_11GroupResultEb, @function
_ZN21MotorControlRSExample5Probe7Console11formatGroupEmmmRKNS0_11GroupResultEb:
.LFB1232:
	entry	sp, 304
.LCFI87:
	extui	a8, a7, 0, 8
	s32i	a8, sp, 200
	movi.n	a8, 0
	s32i	a8, sp, 144
	movi	a8, 0x124
	add.n	a8, a2, a8
	s32i	a8, sp, 160
	l32i	a8, sp, 200
	s32i	a2, sp, 184
	s32i	a5, sp, 168
	l8ui	a7, a6, 0
	mov.n	a15, a3
	bnez.n	a8, .L2598
	bgeui	a7, 4, .L2679
	l32r	a8, .LC1404
	l32r	a14, .LC1384
	addx4	a8, a7, a8
	l32i	a8, a8, 0
	j	.L2600
.L2598:
	l32r	a14, .LC1382
	l32r	a8, .LC1383
	bgeui	a7, 4, .L2680
.L2600:
	l32r	a9, .LC1405
	addx4	a9, a7, a9
	l32i	a9, a9, 0
	j	.L2599
.L2679:
	l32r	a14, .LC1384
	mov.n	a8, a14
.L2680:
	l32r	a9, .LC1385
.L2599:
	l8ui	a12, a6, 13
	l32r	a11, .LC1387
	beqz.n	a12, .L2601
	l32r	a11, .LC1386
.L2601:
	l8ui	a13, a6, 12
	l32r	a10, .LC1388
	bnez.n	a13, .L2602
	l32r	a10, .LC1389
	beqz.n	a12, .L2602
	l32r	a10, .LC1390
.L2602:
	l32i	a12, a6, 20
	l8ui	a5, a6, 105
	s32i	a12, sp, 164
	l32i	a13, a6, 16
	l32r	a12, .LC1387
	beqz.n	a5, .L2603
	l32r	a12, .LC1386
.L2603:
	l8ui	a2, a6, 128
	addi	a5, sp, 96
	s32i	a2, sp, 56
	l32i	a2, a6, 120
	l32i	a3, a6, 124
	s32i	a2, sp, 48
	s32i	a3, sp, 52
	l32i	a2, a6, 112
	l32i	a3, a6, 116
	s32i	a2, sp, 40
	s32i	a3, sp, 44
	l8ui	a2, a6, 106
	s32i	a12, sp, 32
	s32i	a9, sp, 12
	l32i	a12, sp, 164
	l32i	a9, sp, 168
	s32i	a13, sp, 24
	s32i	a10, sp, 20
	s32i	a11, sp, 16
	l32r	a13, .LC1407
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	s32i	a12, sp, 28
	s32i	a2, sp, 36
	s32i	a9, sp, 8
	s32i	a4, sp, 4
	s32i	a8, sp, 0
	addi	a12, a5, 48
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2605
	l8ui	a8, a6, 0
	beqi	a8, 2, .L2606
.L2610:
	beqi	a7, 1, .L2607
	j	.L2608
.L2606:
	l8ui	a8, a6, 104
	l32r	a14, .LC1392
	bnei	a8, 2, .L2609
	l32r	a14, .LC1391
.L2609:
	l32r	a13, .LC1410
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	addi	a12, a5, 48
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2610
	j	.L2605
.L2607:
	l8ui	a8, a6, 128
	movi.n	a9, 0
	s32i	a8, sp, 196
	movi.n	a2, 0
	mov.n	a8, a6
	movi.n	a7, 0
	movi.n	a3, 0
	movi.n	a4, 0
	movi.n	a14, 0
	movi.n	a5, 0
	s32i	a9, sp, 164
	movi.n	a15, 0
	movi.n	a13, 0
	s32i	a9, sp, 172
	s32i	a9, sp, 176
	j	.L2612
.L2625:
	l8ui	a9, a8, 166
	beqz.n	a9, .L2613
	l8ui	a11, a8, 176
	beqz.n	a11, .L2613
	l32i	a10, a8, 184
	l32i	a9, a8, 188
	or	a12, a10, a9
	beqz.n	a12, .L2613
	l32i	a12, sp, 176
	beqz.n	a12, .L2686
	bltu	a9, a15, .L2616
	bne	a15, a9, .L2615
	l32i	a11, sp, 164
	bgeu	a10, a11, .L2615
.L2616:
	s32i	a10, sp, 164
	mov.n	a15, a9
.L2615:
	bltu	a5, a9, .L2618
	bne	a9, a5, .L2613
	bgeu	a14, a10, .L2613
.L2618:
	mov.n	a14, a10
	mov.n	a5, a9
	j	.L2613
.L2686:
	mov.n	a14, a10
	mov.n	a5, a9
	s32i	a10, sp, 164
	mov.n	a15, a9
	s32i	a11, sp, 176
.L2613:
	l8ui	a9, a8, 196
	s32i	a9, sp, 192
	beqz.n	a9, .L2619
	l32i	a11, a8, 208
	l32i	a9, a8, 212
	or	a10, a11, a9
	beqz.n	a10, .L2619
	l32i	a10, a8, 200
	l32i	a12, sp, 172
	s32i	a10, sp, 188
	l32i	a10, a8, 204
	beqz.n	a12, .L2687
	bltu	a10, a4, .L2622
	bne	a4, a10, .L2621
	l32i	a12, sp, 188
	bgeu	a12, a3, .L2621
.L2622:
	l32i	a3, sp, 188
	mov.n	a4, a10
.L2621:
	bltu	a7, a9, .L2624
	bne	a9, a7, .L2619
	bgeu	a2, a11, .L2619
.L2624:
	mov.n	a2, a11
	mov.n	a7, a9
	j	.L2619
.L2687:
	mov.n	a7, a9
	l32i	a9, sp, 192
	l32i	a3, sp, 188
	mov.n	a2, a11
	mov.n	a4, a10
	s32i	a9, sp, 172
.L2619:
	addi.n	a9, a13, 1
	extui	a13, a9, 0, 8
	movi	a9, 0x90
	add.n	a8, a8, a9
.L2612:
	l32i	a9, sp, 196
	bgeu	a13, a9, .L2719
	addi	a9, a13, -15
	bnez.n	a9, .L2625
.L2719:
	l32r	a11, .LC1411
	movi.n	a12, 5
	addi	a10, sp, 120
	s32i	a14, sp, 192
	s32i	a15, sp, 188
	call8	memcpy
	movi.n	a12, 0x13
	movi.n	a11, 0
	addi	a10, sp, 125
	call8	memset
	l32r	a11, .LC1411
	movi.n	a12, 5
	addi	a10, sp, 96
	call8	memcpy
	movi.n	a12, 0x13
	movi.n	a11, 0
	addi	a10, sp, 101
	call8	memset
	l32i	a8, sp, 176
	l32i	a15, sp, 188
	l32i	a14, sp, 192
	beqz.n	a8, .L2629
	l32i	a8, sp, 164
	sub	a15, a5, a15
	bgeu	a14, a8, .L2630
	addi.n	a15, a15, -1
.L2630:
	l32i	a8, sp, 164
	l32r	a12, .LC1412
	sub	a14, a14, a8
	movi.n	a11, 0x18
	addi	a10, sp, 120
	call8	snprintf
.L2629:
	bltu	a7, a4, .L2631
	bne	a4, a7, .L2738
	bltu	a2, a3, .L2631
.L2738:
	l32i	a8, sp, 172
	beqz.n	a8, .L2631
	sub	a15, a7, a4
	bgeu	a2, a3, .L2634
	addi.n	a15, a15, -1
.L2634:
	l32r	a12, .LC1412
	sub	a14, a2, a3
	movi.n	a11, 0x18
	addi	a10, sp, 96
	call8	snprintf
.L2631:
	l8ui	a10, a6, 40
	l32i	a4, a6, 24
	l32i	a5, a6, 28
	l32i	a2, a6, 32
	l32i	a3, a6, 36
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18unitNameEN14MotorControlRS12PositionUnitE
	l8ui	a9, a6, 91
	l8ui	a13, a6, 41
	l16ui	a14, a6, 88
	l32r	a8, .LC1394
	beqi	a9, 1, .L2635
	l32r	a8, .LC1393
	bnei	a9, 2, .L2635
	l32r	a8, .LC1395
.L2635:
	l8ui	a11, a6, 97
	l32r	a9, .LC1397
	bnez.n	a11, .L2636
	l32r	a9, .LC1396
.L2636:
	l8ui	a12, a6, 96
	l32r	a11, .LC1385
	bgeui	a12, 4, .L2637
	l32r	a11, .LC1413
	addx4	a12, a12, a11
	l32i	a11, a12, 0
.L2637:
	addi	a12, sp, 96
	addi	a15, sp, 120
	s32i	a11, sp, 28
	s32i	a13, sp, 12
	s32i	a10, sp, 8
	l32r	a13, .LC1415
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	s32i	a12, sp, 36
	s32i	a15, sp, 32
	s32i	a14, sp, 16
	s32i	a9, sp, 24
	s32i	a8, sp, 20
	s32i	a2, sp, 0
	s32i	a3, sp, 4
	mov.n	a14, a4
	mov.n	a15, a5
	addi	a12, a12, 48
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2608
.L2605:
	movi.n	a2, 0
	j	.L2639
.L2608:
	addi	a8, sp, 96
	addi	a8, a8, 48
	l32r	a13, .LC1417
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	mov.n	a12, a8
	s32i	a8, sp, 164
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2605
	movi	a2, 0x88
	add.n	a2, a6, a2
	movi.n	a7, 0
	j	.L2640
.L2676:
	bnez.n	a7, .L2641
.L2644:
	l32i	a5, a2, 4
	l8ui	a4, a2, 0
	l32r	a3, .LC1399
	bnez.n	a5, .L2643
	j	.L2642
.L2641:
	l32r	a13, .LC1418
	l32i	a12, sp, 164
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2644
	j	.L2605
.L2642:
	l8ui	a10, a2, 8
	l32r	a3, .LC1401
	beqz.n	a10, .L2643
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	mov.n	a3, a10
.L2643:
	l8ui	a10, a2, 16
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a8, a2, 20
	l32r	a13, .LC1420
	s32i	a10, sp, 4
	l32i	a12, sp, 164
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	s32i	a8, sp, 8
	s32i	a3, sp, 0
	mov.n	a15, a5
	mov.n	a14, a4
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2605
	l8ui	a8, a6, 0
	beqi	a8, 2, .L2645
	bgeui	a8, 3, .L2646
	bnez.n	a8, .L2771
	j	.L2647
.L2646:
	beqi	a8, 3, .L2649
	j	.L2650
.L2647:
	l8ui	a8, a2, 9
	l32r	a14, .LC1385
	bgeui	a8, 4, .L2651
	l32r	a9, .LC1421
	addx4	a8, a8, a9
	l32i	a14, a8, 0
.L2651:
	l8ui	a8, a2, 10
	l32r	a15, .LC1385
	bgeui	a8, 4, .L2652
	l32r	a9, .LC1422
	addx4	a8, a8, a9
	l32i	a15, a8, 0
.L2652:
	l8ui	a9, a2, 130
	l16ui	a10, a2, 124
	l16ui	a11, a2, 126
	l16ui	a12, a2, 128
	l32r	a8, .LC1387
	beqz.n	a9, .L2653
	l32r	a8, .LC1386
.L2653:
	l8ui	a13, a2, 131
	l32r	a9, .LC1387
	beqz.n	a13, .L2654
	l32r	a9, .LC1386
.L2654:
	s32i	a12, sp, 8
	l32r	a13, .LC1424
	l32i	a12, sp, 164
	s32i	a9, sp, 16
	s32i	a8, sp, 12
	s32i	a11, sp, 4
	s32i	a10, sp, 0
	j	.L2774
.L2649:
	l8ui	a8, a2, 10
	l32r	a14, .LC1385
	bgeui	a8, 4, .L2656
	l32r	a9, .LC1422
	addx4	a8, a8, a9
	l32i	a14, a8, 0
.L2656:
	l8ui	a8, a2, 132
	l32r	a15, .LC1387
	beqz.n	a8, .L2657
	l32r	a15, .LC1386
.L2657:
	l8ui	a12, a2, 133
	l16ui	a9, a2, 134
	l16ui	a10, a2, 136
	l16ui	a11, a2, 138
	l32r	a8, .LC1387
	beqz.n	a12, .L2658
	l32r	a8, .LC1386
.L2658:
	l32i	a12, a2, 140
	l32r	a13, .LC1426
	s32i	a12, sp, 16
	s32i	a8, sp, 12
	s32i	a11, sp, 8
	s32i	a10, sp, 4
	s32i	a9, sp, 0
	j	.L2773
.L2645:
	l8ui	a8, a2, 11
	l32r	a4, .LC1385
	bgeui	a8, 4, .L2659
	l32r	a9, .LC1422
	addx4	a8, a8, a9
	l32i	a4, a8, 0
.L2659:
	l8ui	a10, a2, 12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	mov.n	a5, a10
	l8ui	a10, a2, 13
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l8ui	a9, a2, 15
	l32r	a8, .LC1403
	bnei	a9, 1, .L2660
	l32r	a8, .LC1402
.L2660:
	l8ui	a11, a2, 28
	l32r	a9, .LC1387
	beqz.n	a11, .L2661
	l32r	a9, .LC1386
.L2661:
	l16ui	a11, a2, 136
	l32r	a13, .LC1428
	s32i	a11, sp, 16
	l16ui	a11, a2, 134
	mov.n	a15, a5
	s32i	a11, sp, 12
	s32i	a9, sp, 8
	s32i	a8, sp, 4
	s32i	a10, sp, 0
	mov.n	a14, a4
.L2773:
	addi	a8, sp, 96
	addi	a12, a8, 48
.L2774:
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L2655
.L2771:
	l32r	a9, .LC1385
	l8ui	a8, a2, 30
	s32i	a9, sp, 196
	bgeui	a8, 4, .L2662
	l32r	a9, .LC1429
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	s32i	a8, sp, 196
.L2662:
	l32r	a9, .LC1385
	l8ui	a8, a2, 11
	s32i	a9, sp, 192
	bgeui	a8, 4, .L2663
	l32r	a9, .LC1422
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	s32i	a8, sp, 192
.L2663:
	l8ui	a10, a2, 12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport12motorOutcomeEN14MotorControlRS13ActionOutcomeE
	s32i	a10, sp, 204
	l8ui	a10, a2, 13
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	s32i	a10, sp, 208
	l8ui	a10, a2, 14
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l32r	a9, .LC1403
	l8ui	a8, a2, 15
	s32i	a10, sp, 212
	s32i	a9, sp, 176
	bnei	a8, 1, .L2664
	l32r	a8, .LC1402
	s32i	a8, sp, 176
.L2664:
	l32r	a9, .LC1387
	l8ui	a8, a2, 28
	s32i	a9, sp, 172
	beqz.n	a8, .L2665
	l32r	a8, .LC1386
	s32i	a8, sp, 172
.L2665:
	l32r	a9, .LC1387
	l8ui	a8, a2, 29
	s32i	a9, sp, 188
	beqz.n	a8, .L2666
	l32r	a8, .LC1386
	s32i	a8, sp, 188
.L2666:
	l32i	a8, a2, 32
	l32i	a9, a2, 36
	s32i	a8, sp, 216
	l8ui	a8, a2, 40
	s32i	a9, sp, 220
	l32r	a5, .LC1387
	beqz.n	a8, .L2667
	l32r	a5, .LC1386
.L2667:
	l32i	a8, a2, 48
	l32i	a9, a2, 52
	s32i	a8, sp, 224
	l32i	a8, a2, 56
	s32i	a9, sp, 228
	s32i	a8, sp, 232
	l8ui	a8, a2, 60
	l32r	a4, .LC1387
	beqz.n	a8, .L2668
	l32r	a4, .LC1386
.L2668:
	l32i	a8, a2, 64
	l32i	a9, a2, 68
	s32i	a8, sp, 240
	s32i	a9, sp, 244
	l32i	a8, a2, 72
	l32i	a9, a2, 76
	l32i	a3, a2, 116
	s32i	a8, sp, 248
	s32i	a9, sp, 252
	l32r	a8, .LC1399
	bnez.n	a3, .L2669
	l8ui	a10, a2, 120
	l32r	a8, .LC1401
	beqz.n	a10, .L2669
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	mov.n	a8, a10
.L2669:
	l8ui	a10, a2, 121
	l32r	a9, .LC1385
	bgeui	a10, 4, .L2670
	l32r	a9, .LC1422
	addx4	a10, a10, a9
	l32i	a9, a10, 0
.L2670:
	l8ui	a10, a2, 122
	s32i	a8, sp, 256
	s32i	a9, sp, 236
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l8ui	a12, a2, 123
	l32r	a11, .LC1403
	l32i	a9, sp, 236
	l32i	a8, sp, 256
	bnei	a12, 1, .L2671
	l32r	a11, .LC1402
.L2671:
	s32i	a8, sp, 76
	movi	a8, 0xf8
	s32i	a11, sp, 88
	s32i	a10, sp, 84
	s32i	a9, sp, 80
	s32i	a3, sp, 72
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	movi	a8, 0xf0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 60
	s32i	a8, sp, 56
	l32i	a8, sp, 232
	s32i	a4, sp, 52
	s32i	a8, sp, 48
	movi	a8, 0xe0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 44
	s32i	a8, sp, 40
	movi	a8, 0xd8
	s32i	a5, sp, 32
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 24
	l32i	a8, sp, 188
	s32i	a8, sp, 20
	l32i	a8, sp, 172
	s32i	a8, sp, 16
	l32i	a8, sp, 176
	s32i	a8, sp, 12
	l32i	a8, sp, 212
	s32i	a8, sp, 8
	l32i	a8, sp, 208
	l32i	a15, sp, 192
	s32i	a8, sp, 4
	l32i	a8, sp, 204
	l32i	a14, sp, 196
	l32r	a13, .LC1431
	l32i	a12, sp, 164
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	s32i	a8, sp, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2605
	l8ui	a8, a2, 80
	l32r	a3, .LC1401
	beqz.n	a8, .L2672
	l32r	a3, .LC1396
	beqi	a8, 2, .L2672
	l32r	a3, .LC1389
	bnei	a8, 1, .L2672
	l32r	a3, .LC1388
.L2672:
	l8ui	a10, a2, 81
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport13executionNameEN14MotorControlRS15ActionExecutionE
	l8ui	a8, a2, 82
	l32r	a11, .LC1385
	mov.n	a15, a10
	bgeui	a8, 3, .L2673
	l32r	a9, .LC1432
	addx4	a8, a8, a9
	l32i	a11, a8, 0
.L2673:
	l8ui	a8, a2, 83
	l32r	a12, .LC1387
	beqz.n	a8, .L2674
	l32r	a12, .LC1386
.L2674:
	l32i	a8, a2, 88
	l32i	a9, a2, 92
	l8ui	a10, a2, 104
	l32i	a4, a2, 96
	l32i	a5, a2, 100
	s32i	a11, sp, 192
	s32i	a12, sp, 188
	s32i	a15, sp, 172
	s32i	a8, sp, 176
	s32i	a9, sp, 180
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	l32i	a13, a2, 108
	movi	a8, 0xb0
	s32i	a13, sp, 28
	s32i	a10, sp, 24
	l32i	a12, sp, 188
	l32i	a11, sp, 192
	s32i	a4, sp, 16
	s32i	a5, sp, 20
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	l32i	a15, sp, 172
	s32i	a12, sp, 4
	s32i	a11, sp, 0
	l32r	a13, .LC1434
	l32i	a12, sp, 164
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	s32i	a8, sp, 8
	s32i	a9, sp, 12
	mov.n	a14, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L2655:
	beqz.n	a10, .L2605
.L2650:
	addi.n	a7, a7, 1
	movi	a8, 0x90
	extui	a7, a7, 0, 8
	add.n	a2, a2, a8
.L2640:
	l8ui	a8, a6, 128
	bgeu	a7, a8, .L2720
	addi	a8, a7, -15
	bnez.n	a8, .L2676
.L2720:
	addi	a8, sp, 96
	addi	a7, a8, 48
	l32r	a13, .LC1435
	l32r	a11, .LC1408
	l32i	a10, sp, 160
	mov.n	a12, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2605
	l32i	a10, sp, 184
	mov.n	a11, a7
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	mov.n	a2, a10
	beqz.n	a10, .L2605
	l32i	a9, sp, 168
	l32i	a10, sp, 200
	movi.n	a8, 0
	movnez	a9, a8, a10
	l32i	a10, sp, 184
	movi.n	a12, 0
	mov.n	a11, a9
	s32i	a9, sp, 168
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
.L2639:
	retw.n
.LFE1232:
	.size	_ZN21MotorControlRSExample5Probe7Console11formatGroupEmmmRKNS0_11GroupResultEb, .-_ZN21MotorControlRSExample5Probe7Console11formatGroupEmmmRKNS0_11GroupResultEb
	.section	.rodata.str1.1
.LC12:
	.string	"ess_rs"
.LC10:
	.string	"stepperonline"
.LC1442:
	.string	"off"
.LC1446:
	.string	"timer"
.LC1448:
	.string	"poll"
.LC1455:
	.string	"_address_dip_off"
.LC1462:
	.string	"0"
.LC1464:
	.string	"2"
.LC1466:
	.string	"1"
.LC1468:
	.string	"invalid_value"
.LC1471:
	.string	"ms"
.LC1473:
	.string	"speed_must_be_0_to_3000_rpm"
.LC1475:
	.string	"ramp_must_be_0_to_2000_ms"
.LC1477:
	.string	"reuse stored parameters"
.LC1479:
	.string	"send parameters before start"
.LC56:
	.string	"Diagnostics"
.LC1497:
	.string	"[\"enable\",\"release\",\"clear_alarm\",\"clear_position\",\"stop_normal\",\"stop_fast\"]"
.LC1499:
	.string	"[]"
.LC1502:
	.string	"\"identity\""
.LC1505:
	.string	"\"state\""
.LC1509:
	.string	"\"stop\""
.LC1511:
	.string	"\"enable\""
.LC1513:
	.string	"\"absolute\""
.LC1515:
	.string	"\"angle\""
.LC1517:
	.string	"\"relative\""
.LC1519:
	.string	"8N1"
.LC1521:
	.string	"cached"
.LC81:
	.string	"current"
.LC1527:
	.string	"stale"
.LC1530:
	.string	"present"
.LC1534:
	.string	"too_many_arguments"
.LC1536:
	.string	"input"
.LC1539:
	.string	"invalid_id"
.LC1541:
	.string	"missing_command"
.LC1543:
	.string	"duplicate_id"
.LC1545:
	.string	"jog"
.LC1547:
	.string	"torque"
.LC1549:
	.string	"velocity-update"
.LC1552:
	.string	"unknown_command"
.LC1554:
	.string	"discover"
.LC1557:
	.string	"inspect"
.LC1559:
	.string	"cancel"
.LC1561:
	.string	"restore"
.LC1563:
	.string	"finish"
.LC1565:
	.string	"profile"
.LC1567:
	.string	"manufacturer"
.LC1569:
	.string	"unsupported_profile"
.LC1571:
	.string	"addresses"
.LC1573:
	.string	"invalid_addresses"
.LC1575:
	.string	"tuple"
.LC1577:
	.string	"invalid_tuple"
.LC1580:
	.string	"duplicate_tuple"
.LC1582:
	.string	"identity"
.LC1584:
	.string	"query-ms"
.LC1586:
	.string	"overall-ms"
.LC1588:
	.string	"requests"
.LC1590:
	.string	"results"
.LC1593:
	.string	"invalid_budget"
.LC1595:
	.string	"duplicate_option"
.LC1600:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"discover\",\"ok\":%s,\"result\":\"%s\",\"action\":%d,\"scan\":"
.LC1603:
	.string	"output_capacity"
.LC1606:
	.string	"list"
.LC1608:
	.string	"profile-list"
.LC1610:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"profile-list\",\"ok\":true,\"bus_traffic\":false,\"profiles\":["
.LC1612:
	.string	"inventory_error"
.LC1614:
	.ascii	"{\"manu"
	.string	"facturer\":\"%s\",\"manufacturer_name\":\"%s\",\"profile\":\"%s\",\"name\":\"%s\",\"probe\":%s,\"identity\":%s,\"nonchanging\":%s,\"exact_model\":%s,\"firmware\":%s,\"minimum_address\":%u,\"maximum_address\":%u,\"probe_first\":%u,\"probe_count\":%u,\"identity_first\":%u,\"identity_count\":%u}"
.LC1618:
	.string	"debug"
.LC1622:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"debug\",\"ok\":%s,\"result\":\"%s\",\"mode\":\"%s\","
	.ascii	"\"observed\":%llu,\"emitted\":%llu,\"dropped\":%llu,\"missed"
	.ascii	"\":%llu,\"skipped\":%llu,\"cursor\":%llu,\"overwritten\":%lu"
	.ascii	",\"capture_dropped\":%"
	.string	"lu,\"retained\":%u,\"capacity\":%u,\"owner\":{\"phase\":\"%s\",\"busy\":%s,\"recovery_required\":%s,\"pending\":%u,\"retained\":%u},\"capture\":{\"mode\":\"%s\",\"faults\":%lu,\"max_poll_gap_us\":%llu},\"memory\":{\"valid\":%s,\"stack_free_bytes\":%lu,\"internal_free\":%lu,\"psram_free\":%lu}}"
.LC1624:
	.string	"qualification"
.LC1627:
	.string	"start-speed"
.LC1629:
	.string	"relation"
.LC1632:
	.string	"motion-profile"
.LC1635:
	.string	"forget"
.LC1638:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"motion-profile\",\"ok\":%s,\"result\":\"%s\",\"pendi"
	.ascii	"ng\":%s,\"saved\":%s,\"restored\":%s,\"session_ok\":%s,\"pha"
	.ascii	"se\":%u,\"address\":%u,\"configuration_generation\":%lu,\"se"
	.ascii	"rial_ge"
	.string	"neration\":%lu,\"original\":[%u,%u,%u,%u,%u,%u],\"current\":[%u,%u,%u,%u,%u,%u],\"tx_hex\":\"%s\",\"rx_hex\":\"%s\",\"write_reply_hex\":\"%s\",\"tx_accepted\":%llu,\"closure_qualified\":%s,\"closure_earliest_us\":%llu,\"closure_latest_us\":%llu,\"execution_unknown\":%s,\"error\":\"%s\"}"
.LC1640:
	.ascii	",\"request\":\"%s\",\"tx_complete\":%s"
	.string	",\"write_tx_complete\":%s,\"deadline_us\":%llu,\"delivered_us\":%llu,\"write_tx_hex\":\"%s\",\"write_tx_accepted\":%llu,\"write_closure_qualified\":%s,\"write_closure_earliest_us\":%llu,\"write_closure_latest_us\":%llu,\"write_delivered_us\":%llu,\"write_execution_unknown\":%s}"
.LC1642:
	.string	",\"restore_unsettled\":%s,\"write_deadline_us\":%llu,\"write_configuration_generation\":%lu,\"write_serial_generation\":%lu,\"write_binding_generation\":%lu}"
.LC1644:
	.string	"host"
.LC1646:
	.string	"caps"
.LC1649:
	.string	"active_tuple_unknown"
.LC1651:
	.string	"fmt"
.LC1654:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"host\",\"ok\":%s,\"result\":\"%s\""
.LC1657:
	.string	"persistence"
.LC1659:
	.string	"snapshot"
.LC1662:
	.string	"before"
.LC1664:
	.string	"plan"
.LC1666:
	.string	"begin"
.LC1668:
	.string	"invalid_kind"
.LC1670:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"persistence\",\"ok\":%s,\"result"
	.string	"\":\"%s\",\"action\":%d,\"pending\":%s,\"owned\":%s,\"route_ready\":%s,\"snapshot_known\":%s,\"snapshot_failed\":%s,\"verification_attempts\":%u,\"parent_session\":%s,\"finished\":%s,\"invocations\":%u,\"invocation_limit\":2,\"restart_performed\":false,\"write_replayed\":false,\"plan\":"
.LC1672:
	.string	"{\"kind\":\"%s\",\"register\":45,\"value\":%u,\"writes\":1,\"scope\":\"all_parameters\",\"stopped_required\":true,\"completion\":\"unresolved\",\"durability\":\"unverified\",\"restart\":\"required_for_proof\",\"backup\":\"partial_standard_config\"}"
.LC1674:
	.string	",\"baseline\":"
.LC1676:
	.string	",\"context\":"
.LC1678:
	.string	",\"host\":{\"active\":"
.LC1680:
	.string	",\"active_known\":%s,\"blocked\":%s,\"serial_generation\":%lu,\"actual_baud\":%lu,\"failure\":\"%s\"}}"
.LC1682:
	.string	"communication"
.LC1684:
	.string	"confirm"
.LC1686:
	.string	"requested"
.LC1688:
	.string	"invalid_candidate"
.LC1695:
	.string	"invalid_baud"
.LC1698:
	.string	"invalid_format"
.LC1700:
	.string	"invalid_field"
.LC1702:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"communication\",\"ok\":%s,\"result\":\"%s\",\"action\":%d,\"pending\":%s,\"owned\":%s,\"route_ready\":%s,\"save_sent\":false,\"restart_performed\":false,\"write_replayed\":false,\"plan\":"
.LC1704:
	.string	"{\"field\":\"%s\",\"address\":%u,\"register\":%u,\"value\":%u,\"writes\":1,\"save\":\"%s\",\"restart\":\"%s\",\"activation\":\"unresolved\",\"prerequisites\":\"fresh_checked_config_exact_candidate_stationary_effects_route_back%s\"}"
.LC1707:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"home-qualification\",\"ok\":true,\"present\":%s,\"va"
	.ascii	"lid\":%s,\"target\":%lu,\"add"
	.string	"ress\":%u,\"generation\":%lu,\"configuration_generation\":%lu,\"method\":%d,\"native_parameters\":[%u,%u,%u],\"qualified_us\":%llu,\"qualification_maximum_age_us\":%llu,\"maximum_age_us\":%llu,\"available_inputs\":%u,\"index_qualified\":%s,\"reference_semantics_qualified\":%s}"
.LC1709:
	.string	"auxiliary"
.LC1712:
	.string	"methods"
.LC1719:
	.string	"options"
.LC1722:
	.ascii	"Subdivision: any integer from 400 to 51200; documented defau"
	.ascii	"lt 1000.\nUseful examples: 400, 800, 1000, 1600, 2000, 3200,"
	.ascii	" 6400, 12800, 25600, 51200.\nThese are examples, not the onl"
	.ascii	"y allowed values.\nRead: subdivi"
	.string	"sion. Set while stopped with one command: subdivision 1600.\nRequired reads, setting write and readback run automatically.\nA checked change updates the host scale and establishes a new zero at the current stationary position. No save or motion is automatic."
.LC1724:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"subdivision\",\"ok\":true,\"minimum\":400,\"maximum\":51200,\"default\":1000,\"examples\":[400,800,1000,1600,2000,3200,6400,12800,25600,51200],\"all_integers_in_range\":true,\"device_settings_changed\":false}"
.LC1726:
	.string	"filters"
.LC1728:
	.string	"current-loop"
.LC1730:
	.string	"la"
.LC1732:
	.string	"collision"
.LC1734:
	.string	"invalid_tuning_group"
.LC1736:
	.string	"position"
.LC36:
	.string	"speed"
.LC1740:
	.string	"invalid_record_kind"
.LC1742:
	.string	"invalid_index"
.LC1750:
	.string	"value"
.LC80:
	.string	"threshold"
.LC1761:
	.string	"duplicate_field"
.LC1763:
	.string	"open-loop"
.LC1765:
	.string	"algorithm-1"
.LC1768:
	.string	"invalid_integer"
.LC1779:
	.string	"round"
.LC1781:
	.string	"approx"
.LC1784:
	.string	"invalid_axis_configuration"
.LC1788:
	.string	"subdivision_must_be_400_to_51200"
.LC1791:
	.string	"use_steps_deg_turn_or_mm"
.LC1793:
	.string	"invalid_positive_scale"
.LC1799:
	.string	"Angle scale: %lld/%llu command steps per motor turn.\nThis host declaration applies after the next move's stopped-state checks; no drive setting changed."
.LC1801:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"stepsperturn\",\"ok\":true,\"numerator\":%lld,\"denominator\":%llu,\"device_settings_changed\":false}"
.LC1804:
	.string	"use drive setting"
.LC1806:
	.string	"Host settings: speed %u rpm; accel %s ms; decel %s ms.\nNo motor setting changed yet. Next move will %s.\nUse settings to compare with the motor's actual values."
.LC1808:
	.ascii	"{"
	.string	"\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"ok\":true,\"speed_rpm\":%u,\"acceleration\":%u,\"deceleration\":%u,\"acceleration_known\":%s,\"deceleration_known\":%s,\"ramp_units\":\"native\",\"ramp_time_unit\":\"ms\",\"setup\":\"%s\",\"device_settings_changed\":false}"
.LC1810:
	.string	"interrupt"
.LC1820:
	.string	"basis"
.LC1822:
	.string	"after-stop"
.LC1824:
	.string	"mechanics-permit-release"
.LC1826:
	.string	"triggers-inhibited"
.LC1829:
	.string	"accel"
.LC1831:
	.string	"300"
.LC1833:
	.string	"301"
.LC1836:
	.string	"useaddr"
.LC1841:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"wiring\",\"ok\":%s,\"result\":\"%s\",\"target\":%lu,\"address\":%u,\"generation\":%lu,\"configuration_generation\":%lu,\"inputs\":[%u,%u,%u,%u],\"outputs\":[%u,%u],\"bus_traffic\":false}"
.LC1843:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"ok\":%s,\"code\":\"%s\",\"detail\":%ld"
.LC1846:
	.string	",\"bus_traffic\":false,\"motion_command\":false}"
.LC1850:
	.string	"invalid_operation_id"
.LC1852:
	.string	"reset"
.LC1855:
	.string	"monitor"
.LC1858:
	.string	"help"
.LC1860:
	.string	"%s\nUsage: %s\n"
.LC1863:
	.string	"\nFast stop uses reserved priority after the current bus transaction settles.\nIt requires working RS485 communication; it is not a hardwired emergency-stop circuit."
.LC1865:
	.string	"\nExamples:\n  %s"
.LC1867:
	.string	"\nArguments in [brackets] are optional. Use @ID before the command for full JSON evidence."
.LC1869:
	.string	"MotorControl-RS: all commands\nOne menu for everyday control and diagnostics; no separate advanced list.\nUse help COMMAND for syntax and examples. Prefix @ID for JSON evidence.\n"
.LC1874:
	.string	"\n[%s]\n"
.LC1876:
	.string	"  %-16s "
.LC1878:
	.string	"\n"
.LC1881:
	.string	"\nExample defaults: 60 rpm, 100 ms ramps, assumed 1000 command steps/turn. No automatic motion.\n"
.LC1883:
	.string	"\nAccepted operations finish asynchronously. Cancel is local; it does not stop the motor."
.LC1885:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"help\",\"ok\":true,\"syntax\":\"%s\",\"effect\":\"%s\",\"bus_traffic\":%s}"
.LC1887:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"help\",\"ok\":true,\"commands\":["
.LC1892:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"%s\",\"ok\":true,\"product\":\"MotorControl-RS\",\"protocol\":3,\"version\":\"%s\",\"outstanding_capacity\":%u}"
.LC1894:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"caps\",\"ok\":true,\"probe\":%s,\"identity\":%s,\"co"
	.ascii	"nfig\":%s,\"state\":%s,\"velocity_parameters\":%s,\"homing_p"
	.ascii	"arameters\":%s,\"max_steps\":%u,\"max_reply_bytes\":%u,\"wri"
	.ascii	"tes\":%s,\"motion\":%s,\"write_response_confirmed\":%s,\"axi"
	.ascii	"s_reserved\":%s,\"actions\":%s,\"device_queue_guarantee\":fa"
	.ascii	"lse,\"velocity\":%s,\"configured_ramp_policy\":true,\"accele"
	.ascii	"ration_mapping\":false,\"velocity_unsupported\":[\"jerk\",\""
	.ascii	"blending\",\"live_updates\",\"torque\",\"current\",\"externa"
	.ascii	"l_jog\"],\"driver_settings\":%s,\"limit_pair_writes\":false,"
	.ascii	"\"home\":%s,\"home_methods\":[1,2,3,4,5,6,7,8,9,10,11,12,13,"
	.ascii	"14,17,19,20,21,22,23,24,25,26,27,28,29,30,33,34,35],\"home_p"
	.ascii	"hysical_qualified\":false,\"io_settings\":%s,\"input_termina"
	.ascii	"ls\":4,\"output_terminals\":2,\"no_function\":0,\"input_func"
	.ascii	"tion_codes\":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17],\""
	.ascii	"output_function_codes\":[0,1,2,3,4,5,9,10],\"output_function"
	.ascii	"_11\":\"unresolved\",\"input_mask\":15,\"output_mask\":3,\"e"
	.ascii	"xternal_enable_precedence\":\"unknown\",\"electrical_output_"
	.ascii	"state_known\":false,\"segment_storage\":16,\"maximum_input_s"
	.ascii	"elections\":8,\"segment_execution\":\"external_input\",\"seg"
	.ascii	"ment_pulse_writes\":false,\"negative_segment_speed_encoding\""
	.ascii	":\"unresolved\",\"control_settings\":%s,\"control_algorithm_"
	.ascii	"codes\":[1,2],\"configured_encoder_is_identification\":false"
	.ascii	",\"current_percent_base\":\"unresolved\",\"effective_current"
	.ascii	"_limit_from_peak\":false,\"tuning\":%s,\"tuning_groups\":[\""
	.ascii	"f"
	.string	"ilters\",\"current-loop\",\"la\",\"collision\"],\"tuning_physical_scaling_known\":false,\"collision_003b_003c_access\":\"unresolved\",\"persistence\":%s,\"persistence_operations\":[\"save\",\"factory_restore\"],\"persistence_verified_all\":false,\"persistence_invocation_limit\":2}"
.LC1896:
	.ascii	",\"discovery\":%s,\"discovery_profiles\":%u,\"discovery_nonc"
	.ascii	"hanging\":true,\"discovery_max_tuples\":%u,\"discovery_max_r"
	.ascii	"esults\":%u,\"discovery_model_mapping\":\"unresolved\",\"dis"
	.ascii	"covery_manufacturer_confirmation\":false,\"capability_scope\""
	.ascii	":\"implemented_application_routes\",\"unsupported\":[\"torqu"
	.ascii	"e_motion\",\"current_motion\",\"serial_segment_start\"],\"un"
	.ascii	"resolved\":["
	.string	"\"home_method_18\",\"collision_homing\",\"nonzero_home_offset\",\"paired_native_settings\",\"physical_acceleration_mapping\"],\"position_start_speed_write\":%s,\"homing_auxiliary_write\":%s,\"unimplemented\":[],\"coverage_inventory\":\"docs/reference/ess_rs_operations.json\"}"
.LC1898:
	.string	",\"position_interrupt_stored\":%s,\"position_interrupt_completion\":\"not_observed\",\"position_interrupt_new_target\":false,\"qualification_routes\":{\"home\":%s,\"velocity\":%s,\"position_clear\":%s,\"start_speed_relation\":%s}}"
.LC1903:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"result\",\"command_id\":%lu,\"operation_id\":%lu,\"ok\":true,\"result\":\"pending\",\"recovery\":false,\"group_kind\":\"%s\"}"
.LC1907:
	.ascii	"{\"ty"
	.string	"pe\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"result\",\"command_id\":%lu,\"operation_id\":%lu,\"ok\":true,\"result\":\"pending\",\"recovery\":%s,\"capture_read\":%s,\"read_kind\":%s,\"action_kind\":%s,\"stop_policy\":%s,\"move_kind\":%s,\"velocity\":%s,\"driver\":%s,\"home\":%s}"
.LC1910:
	.string	",\"position_interrupt\":%s"
.LC1912:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"monitor\",\"ok\":true,\"enabled\":%s,\"interval_ms\":%lu,\"count\":%lu,\"remaining\":%lu,\"operation_id\":%lu,\"next_due_us\":%llu,\"admitted\":%llu,\"rejected\":%llu,\"cancelled\":%llu}"
.LC1914:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"load\",\"ok\":true,\"result\":\"done\",\"ready\":%s,"
	.ascii	"\"capture_mode\":\"%s\",\"workload_us\":%lu,\"owner_delay_us"
	.ascii	"\":%lu,\"console_bytes\":%lu,\"elapsed_us\":%llu,\"work_us\""
	.ascii	":%llu,\"work_iterations\":%llu,\"console_lines\":%llu,\"cons"
	.ascii	"ole_dropped\":%llu,\"capture_us\":%l"
	.string	"lu,\"capture_samples\":%llu,\"timer_callbacks\":%llu,\"sample_gap_limit_us\":%lu,\"sample_gap_exceeded\":%s,\"capture_high_water\":%lu,\"owner_gap_max_us\":%llu,\"capture_gap_max_us\":%llu,\"work_stack_free_bytes\":%lu,\"cpu_valid\":%s,\"cpu0_busy_pct\":%s,\"cpu1_busy_pct\":%s}"
.LC1920:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"drv\",\"ok\":true,\"phase\":\"%s\",\"busy\":%s,\"tra"
	.ascii	"nsmit_enabled\":%s,\"recovery_required\":%s,\"pending\":%u,\""
	.ascii	"retained\":%u,\"reserved\":%u,\"pending_capacity\":%u,\"resu"
	.ascii	"lt_capacity\":%u,\"outstanding_capacity\":%u,\"operation_id\""
	.ascii	":%lu,\"output_queued\":%u,\"output_blocked\":%llu,\"output_s"
	.ascii	"hort_writes\":%llu,\"input_bytes\":%llu,\"input_lines\":%llu"
	.ascii	",\"input_dropped\":%llu,\"stop_evidence_overwritten\":%llu,\""
	.ascii	"automatic_recovery_operation_id\":%lu,\"recovery_guard_until"
	.ascii	"_us\":%llu,\"request_deadline_us\":%llu,\"capture_mode\":\"%"
	.ascii	"s\",\"read_budget\":%lu,\"model_address\":%s,\"model_operati"
	.ascii	"on_id\":%lu,\"observed_earliest_us\":%llu,\"observed_latest_"
	.ascii	"us\":%llu,\"delivered_us\":%llu,\""
	.string	"previous_runtime\":{\"valid\":%s,\"stage\":%lu,\"uptime_ms\":%lu,\"loops\":%lu,\"input_lines\":%lu,\"output_queued\":%lu,\"output_blocked\":%lu},\"owner_watchdog\":{\"subscribed\":%s,\"error\":%ld,\"timeout_ms\":%lu,\"last_feed_us\":%llu,\"completed_loops\":%llu},\"reset_reason\":%lu}"
.LC1922:
	.string	",\"usb_stall\":{\"count\":%lu,\"nudges\":%lu,\"longest_us\":%llu,\"active\":%s,\"int_raw\":%lu,\"int_ena\":%lu,\"in_fifo\":%lu,\"endpoint\":%lu,\"connected\":%s}}"
.LC1924:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"%s\",\"ok\":true,\"address\":%u,\"baud\":%lu,\"forma"
	.ascii	"t\":\"%s\",\"response_timeout_us\":%lu,\"reply_gap_us\":%lu,"
	.ascii	"\"gap15_us\":%lu,\"gap35_us\":%lu,\"stale_after_ms\":%lu,\"r"
	.ascii	"eady\":%s,\"timing_qualified\":%s,\"device_set"
	.string	"tings\":\"%s\",\"cache_off_supported\":%s,\"sample_gap_limit_us\":%lu,\"cached_identity_id\":%lu,\"cached_identity_address\":%u,\"cached_identity_generation\":%lu,\"cached_config_id\":%lu,\"cached_config_address\":%u,\"cached_config_generation\":%lu,\"binding_generation\":%lu}"
.LC1926:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"status\",\"ok\":true,\"uptime_ms\":%llu,\"ready\":%s"
	.ascii	",\"timing_qualified\":%s"
	.string	",\"busy\":%s,\"transmit_enabled\":%s,\"recovery_required\":%s,\"phase\":\"%s\",\"transport\":\"%s\",\"codec\":\"%s\",\"detail\":%ld,\"frame_error\":%u,\"last_probe_known\":%s,\"last_probe_ok\":%s,\"probe_address\":%s,\"model_address\":%s,\"raw_model\":%s,\"age_ms\":%s,\"stale_after_ms\":%lu}"
.LC1928:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"health\",\"ok\":true,\"communication\":\"%s\",\"probe_address\":%s,\"model_address\":%s,\"age_ms\":%s,\"stale_after_ms\":%lu,\"readiness\":\"unknown\",\"alarms\":\"%s\",\"state\":\"%s\",\"identity\":\"%s\"}"
.LC1930:
	.ascii	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"comm"
	.ascii	"and\":\"stats\",\"ok\":"
	.string	"true,\"started\":%lu,\"frames\":%lu,\"failed\":%lu,\"timeouts\":%lu,\"cancelled\":%lu,\"rx_bytes\":%lu,\"discarded\":%lu,\"echo_bytes\":%lu,\"trace_overwritten\":%lu,\"max_poll_gap_us\":%llu,\"capture_faults\":%lu,\"rx_errors\":%lu,\"sample_gap_exceeded\":%s,\"cache_interrupted\":%s}"
.LC1932:
	.string	"{\"type\":\"reply\",\"profile\":\"ess_rs\",\"id\":%lu,\"command\":\"memory\",\"ok\":true,\"valid\":%s,\"internal_free\":%lu,\"internal_min\":%lu,\"internal_largest\":%lu,\"psram_free\":%lu,\"psram_min\":%lu,\"psram_largest\":%lu,\"stack_free_bytes\":%lu}"
.LC1935:
	.string	"unknown_field"
	.section	.rodata
	.align	4
.LC9:
	.byte	0
	.zero	3
	.byte	0
	.byte	0
	.byte	0
	.zero	1
	.word	115200
	.byte	0
	.zero	3
	.word	115200
	.byte	0
	.zero	3
	.word	115200
	.byte	0
	.zero	3
	.word	115200
	.byte	0
	.zero	3
	.byte	0
	.zero	3
	.word	500
	.word	5000
	.short	16
	.byte	8
	.byte	0
	.section	.rodata.str1.1
.LC11:
	.string	"STEPPERONLINE"
.LC13:
	.string	"ESS-RS"
	.section	.rodata
	.align	4
.LC1616:
	.byte	0
	.byte	0
	.zero	2
	.word	.LC10
	.word	.LC11
	.word	.LC12
	.word	.LC13
	.align	8
.LC15:
	.short	35
	.zero	2
	.word	0
	.short	60
	.short	30
	.short	100
	.zero	2
	.word	0
	.word	0
	.section	.rodata.str1.1
.LC16:
	.string	"direction"
.LC18:
	.string	"word-order"
.LC19:
	.string	"soft-limit"
.LC20:
	.string	"over-limit"
.LC21:
	.string	"interruption"
.LC22:
	.string	"position-mode"
.LC23:
	.string	"positive-limit"
.LC24:
	.string	"negative-limit"
	.section	.rodata
	.align	4
.LC1744:
	.word	.LC16
	.word	.LC17
	.word	.LC18
	.word	.LC19
	.word	.LC20
	.word	.LC21
	.word	.LC22
	.word	.LC23
	.word	.LC24
	.section	.rodata.str1.1
.LC26:
	.string	"input-polarity"
.LC27:
	.string	"x0"
.LC28:
	.string	"x1"
.LC29:
	.string	"x2"
.LC30:
	.string	"x3"
.LC31:
	.string	"output-polarity"
.LC32:
	.string	"y0"
.LC33:
	.string	"y1"
.LC34:
	.string	"custom"
	.section	.rodata
	.align	4
.LC1746:
	.word	.LC26
	.word	.LC27
	.word	.LC28
	.word	.LC29
	.word	.LC30
	.word	.LC31
	.word	.LC32
	.word	.LC33
	.word	.LC34
	.section	.rodata.str1.1
.LC37:
	.string	"acceleration"
.LC38:
	.string	"deceleration"
.LC39:
	.string	"target"
	.section	.rodata
	.align	4
.LC1748:
	.word	.LC36
	.word	.LC37
	.word	.LC38
	.word	.LC39
	.section	.rodata.str1.1
.LC41:
	.string	"algorithm"
.LC42:
	.string	"encoder-resolution"
.LC43:
	.string	"maximum-effective-current"
.LC44:
	.string	"closed-maximum-current"
.LC45:
	.string	"closed-base-current"
.LC46:
	.string	"open-maximum-current"
.LC47:
	.string	"lock-current"
.LC48:
	.string	"lock-delay"
	.section	.rodata
	.align	4
.LC1752:
	.word	.LC41
	.word	.LC42
	.word	.LC43
	.word	.LC44
	.word	.LC45
	.word	.LC46
	.word	.LC47
	.word	.LC48
	.section	.rodata.str1.1
.LC59:
	.string	"input-filter"
.LC60:
	.string	"pulse-low-pass"
.LC61:
	.string	"deviation-threshold"
.LC62:
	.string	"arrival-window"
.LC63:
	.string	"arrival-time"
.LC64:
	.string	"pulse-mean"
	.section	.rodata
	.align	4
.LC1754:
	.word	.LC59
	.word	.LC60
	.word	.LC61
	.word	.LC62
	.word	.LC63
	.word	.LC64
	.section	.rodata.str1.1
.LC66:
	.string	"multiplier"
.LC67:
	.string	"kp"
.LC68:
	.string	"ki"
.LC69:
	.string	"kc"
	.section	.rodata
	.align	4
.LC1756:
	.word	.LC66
	.word	.LC67
	.word	.LC68
	.word	.LC69
	.section	.rodata.str1.1
.LC71:
	.string	"kp1"
.LC72:
	.string	"kv1"
.LC73:
	.string	"node1"
.LC74:
	.string	"kp2"
.LC75:
	.string	"kv2"
.LC76:
	.string	"node2"
.LC77:
	.string	"kvf"
.LC78:
	.string	"position-ki"
	.section	.rodata
	.align	4
.LC1758:
	.word	.LC71
	.word	.LC72
	.word	.LC73
	.word	.LC74
	.word	.LC75
	.word	.LC76
	.word	.LC77
	.word	.LC78
	.align	8
.LC91:
	.word	0
	.word	0
	.word	1
	.word	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.zero	1
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.byte	0
	.byte	1
	.zero	6
	.word	0
	.word	0
	.word	0
	.word	0
	.align	8
.LC50:
	.word	0
	.word	0
	.word	1
	.word	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.zero	1
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.byte	0
	.byte	1
	.zero	6
	.word	0
	.word	0
	.word	0
	.word	0
	.short	0
	.byte	0
	.byte	0
	.zero	4
	.section	.rodata.str1.1
.LC51:
	.string	"Motor operations"
.LC52:
	.string	"Read and observe"
.LC53:
	.string	"Drive settings"
.LC54:
	.string	"Host and setup"
.LC55:
	.string	"Operation results"
.LC57:
	.string	"Getting started"
	.section	.rodata
	.align	4
.LC1871:
	.word	.LC51
	.word	.LC52
	.word	.LC53
	.word	.LC54
	.word	.LC55
	.word	.LC56
	.word	.LC57
	.text
	.literal_position
	.literal .LC1436, .LC12
	.literal .LC1437, .LC10
	.literal .LC1439, 5000
	.literal .LC1440, .LC361
	.literal .LC1441, .LC363
	.literal .LC1443, .LC1442
	.literal .LC1444, .LC468
	.literal .LC1445, .LC470
	.literal .LC1447, .LC1446
	.literal .LC1449, .LC1448
	.literal .LC1450, .LC544
	.literal .LC1451, .LC694
	.literal .LC1452, .LC696
	.literal .LC1453, .LC679
	.literal .LC1454, .LC677
	.literal .LC1456, .LC1455
	.literal .LC1457, .LC318
	.literal .LC1458, .LC586
	.literal .LC1459, .LC578
	.literal .LC1463, .LC1462
	.literal .LC1465, .LC1464
	.literal .LC1467, .LC1466
	.literal .LC1469, .LC1468
	.literal .LC1470, .LC300
	.literal .LC1472, .LC1471
	.literal .LC1474, .LC1473
	.literal .LC1476, .LC1475
	.literal .LC1478, .LC1477
	.literal .LC1480, .LC1479
	.literal .LC1481, .LC1104
	.literal .LC1482, .LC1100
	.literal .LC1483, .LC1088
	.literal .LC1484, .LC1090
	.literal .LC1485, .LC1092
	.literal .LC1486, .LC564
	.literal .LC1487, .LC570
	.literal .LC1488, .LC568
	.literal .LC1489, .LC566
	.literal .LC1490, .LC562
	.literal .LC1491, _ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L12CONFIG_ENTRYE
	.literal .LC1492, _ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L14IDENTITY_ENTRYE
	.literal .LC1493, _ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L11STATE_ENTRYE
	.literal .LC1494, _ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L8COMMANDSE
	.literal .LC1495, .LC56
	.literal .LC1496, .LC386
	.literal .LC1498, .LC1497
	.literal .LC1500, .LC1499
	.literal .LC1501, .LC107
	.literal .LC1503, .LC1502
	.literal .LC1504, .LC422
	.literal .LC1506, .LC1505
	.literal .LC1507, .LC952
	.literal .LC1508, .LC954
	.literal .LC1510, .LC1509
	.literal .LC1512, .LC1511
	.literal .LC1514, .LC1513
	.literal .LC1516, .LC1515
	.literal .LC1518, .LC1517
	.literal .LC1520, .LC1519
	.literal .LC1522, .LC1521
	.literal .LC1523, .LC833
	.literal .LC1524, .LC754
	.literal .LC1525, .LC263
	.literal .LC1526, .LC81
	.literal .LC1528, .LC1527
	.literal .LC1529, .LC962
	.literal .LC1531, .LC1530
	.literal .LC1532, .LC1334
	.literal .LC1533, .LC837
	.literal .LC1535, .LC1534
	.literal .LC1537, .LC1536
	.literal .LC1538, 35192
	.literal .LC1540, .LC1539
	.literal .LC1542, .LC1541
	.literal .LC1544, .LC1543
	.literal .LC1546, .LC1545
	.literal .LC1548, .LC1547
	.literal .LC1550, .LC1549
	.literal .LC1551, .LC343
	.literal .LC1553, .LC1552
	.literal .LC1555, .LC1554
	.literal .LC1556, .LC9
	.literal .LC1558, .LC1557
	.literal .LC1560, .LC1559
	.literal .LC1562, .LC1561
	.literal .LC1564, .LC1563
	.literal .LC1566, .LC1565
	.literal .LC1568, .LC1567
	.literal .LC1570, .LC1569
	.literal .LC1572, .LC1571
	.literal .LC1574, .LC1573
	.literal .LC1576, .LC1575
	.literal .LC1578, .LC1577
	.literal .LC1579, 115200
	.literal .LC1581, .LC1580
	.literal .LC1583, .LC1582
	.literal .LC1585, .LC1584
	.literal .LC1587, .LC1586
	.literal .LC1589, .LC1588
	.literal .LC1591, .LC1590
	.literal .LC1592, .LC756
	.literal .LC1594, .LC1593
	.literal .LC1596, .LC1595
	.literal .LC1597, 35584
	.literal .LC1598, 35380
	.literal .LC1599, 35576
	.literal .LC1601, .LC1600
	.literal .LC1602, 16384
	.literal .LC1604, .LC1603
	.literal .LC1605, .LC430
	.literal .LC1607, .LC1606
	.literal .LC1609, .LC1608
	.literal .LC1611, .LC1610
	.literal .LC1613, .LC1612
	.literal .LC1615, .LC1614
	.literal .LC1617, .LC1616
	.literal .LC1619, .LC1618
	.literal .LC1620, 200000
	.literal .LC1621, 500000
	.literal .LC1623, .LC1622
	.literal .LC1625, .LC1624
	.literal .LC1626, .L2900
	.literal .LC1628, .LC1627
	.literal .LC1630, .LC1629
	.literal .LC1631, .LC560
	.literal .LC1633, .LC1632
	.literal .LC1634, .LC867
	.literal .LC1636, .LC1635
	.literal .LC1637, .LC337
	.literal .LC1639, .LC1638
	.literal .LC1641, .LC1640
	.literal .LC1643, .LC1642
	.literal .LC1645, .LC1644
	.literal .LC1647, .LC1646
	.literal .LC1648, .LC662
	.literal .LC1650, .LC1649
	.literal .LC1652, .LC1651
	.literal .LC1653, .LC324
	.literal .LC1655, .LC1654
	.literal .LC1656, .LC772
	.literal .LC1658, .LC1657
	.literal .LC1660, .LC1659
	.literal .LC1661, .LC1102
	.literal .LC1663, .LC1662
	.literal .LC1665, .LC1664
	.literal .LC1667, .LC1666
	.literal .LC1669, .LC1668
	.literal .LC1671, .LC1670
	.literal .LC1673, .LC1672
	.literal .LC1675, .LC1674
	.literal .LC1677, .LC1676
	.literal .LC1679, .LC1678
	.literal .LC1681, .LC1680
	.literal .LC1683, .LC1682
	.literal .LC1685, .LC1684
	.literal .LC1687, .LC1686
	.literal .LC1689, .LC1688
	.literal .LC1690, .LC660
	.literal .LC1691, .LC762
	.literal .LC1696, .LC1695
	.literal .LC1697, .LC658
	.literal .LC1699, .LC1698
	.literal .LC1701, .LC1700
	.literal .LC1703, .LC1702
	.literal .LC1705, .LC1704
	.literal .LC1706, .LC576
	.literal .LC1708, .LC1707
	.literal .LC1710, .LC1709
	.literal .LC1711, .LC558
	.literal .LC1713, .LC1712
	.literal .LC1714, .LC15
	.literal .LC1720, .LC1719
	.literal .LC1721, CSWTCH$1623
	.literal .LC1723, .LC1722
	.literal .LC1725, .LC1724
	.literal .LC1727, .LC1726
	.literal .LC1729, .LC1728
	.literal .LC1731, .LC1730
	.literal .LC1733, .LC1732
	.literal .LC1735, .LC1734
	.literal .LC1737, .LC1736
	.literal .LC1738, .LC36
	.literal .LC1739, .LC1365
	.literal .LC1741, .LC1740
	.literal .LC1743, .LC1742
	.literal .LC1745, .LC1744
	.literal .LC1747, .LC1746
	.literal .LC1749, .LC1748
	.literal .LC1751, .LC1750
	.literal .LC1753, .LC1752
	.literal .LC1755, .LC1754
	.literal .LC1757, .LC1756
	.literal .LC1759, .LC1758
	.literal .LC1760, .LC80
	.literal .LC1762, .LC1761
	.literal .LC1764, .LC1763
	.literal .LC1766, .LC1765
	.literal .LC1769, .LC1768
	.literal .LC1770, 65535
	.literal .LC1772, .L3173
	.literal .LC1773, .L3191
	.literal .LC1774, .LC574
	.literal .LC1775, .LC1359
	.literal .LC1776, .LC1146
	.literal .LC1777, .LC1144
	.literal .LC1778, .LC1351
	.literal .LC1780, .LC1779
	.literal .LC1782, .LC1781
	.literal .LC1785, .LC1784
	.literal .LC1786, .LC91
	.literal .LC1789, .LC1788
	.literal .LC1790, 50800
	.literal .LC1792, .LC1791
	.literal .LC1794, .LC1793
	.literal .LC1795, 6553660
	.literal .LC1796, 16842852
	.literal .LC1800, .LC1799
	.literal .LC1802, .LC1801
	.literal .LC1803, .LC844
	.literal .LC1805, .LC1804
	.literal .LC1807, .LC1806
	.literal .LC1809, .LC1808
	.literal .LC1811, .LC1810
	.literal .LC1812, .LC556
	.literal .LC1813, .LC50
	.literal .LC1814, .LC311
	.literal .LC1815, .LC313
	.literal .LC1816, .LC315
	.literal .LC1817, .LC1066
	.literal .LC1818, 65534
	.literal .LC1819, .LC1361
	.literal .LC1821, .LC1820
	.literal .LC1823, .LC1822
	.literal .LC1825, .LC1824
	.literal .LC1827, .LC1826
	.literal .LC1828, .L3359
	.literal .LC1830, .LC1829
	.literal .LC1832, .LC1831
	.literal .LC1834, .LC1833
	.literal .LC1835, .LC602
	.literal .LC1837, .LC1836
	.literal .LC1838, .LC1341
	.literal .LC1839, .LC1196
	.literal .LC1840, .LC1198
	.literal .LC1842, .LC1841
	.literal .LC1844, .LC1843
	.literal .LC1845, 16383
	.literal .LC1847, .LC1846
	.literal .LC1848, .LC320
	.literal .LC1849, .LC1347
	.literal .LC1851, .LC1850
	.literal .LC1853, .LC1852
	.literal .LC1856, .LC1855
	.literal .LC1857, 59900
	.literal .LC1859, .LC1858
	.literal .LC1861, .LC1860
	.literal .LC1862, .LC1232
	.literal .LC1864, .LC1863
	.literal .LC1866, .LC1865
	.literal .LC1868, .LC1867
	.literal .LC1870, .LC1869
	.literal .LC1872, .LC1871
	.literal .LC1873, CSWTCH$1352
	.literal .LC1875, .LC1874
	.literal .LC1877, .LC1876
	.literal .LC1879, .LC1878
	.literal .LC1880, _ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L8COMMANDSE+1296
	.literal .LC1882, .LC1881
	.literal .LC1884, .LC1883
	.literal .LC1886, .LC1885
	.literal .LC1888, .LC1887
	.literal .LC1889, .LC453
	.literal .LC1890, .LC499
	.literal .LC1891, .LC635
	.literal .LC1893, .LC1892
	.literal .LC1895, .LC1894
	.literal .LC1897, .LC1896
	.literal .LC1899, .LC1898
	.literal .LC1900, .L3554
	.literal .LC1901, .LC809
	.literal .LC1902, CSWTCH$1367
	.literal .LC1904, .LC1903
	.literal .LC1905, CSWTCH$1624
	.literal .LC1906, CSWTCH$1625
	.literal .LC1908, .LC1907
	.literal .LC1909, .LC607
	.literal .LC1911, .LC1910
	.literal .LC1913, .LC1912
	.literal .LC1915, .LC1914
	.literal .LC1916, .LC842
	.literal .LC1917, .LC1301
	.literal .LC1918, .LC420
	.literal .LC1919, .L3634
	.literal .LC1921, .LC1920
	.literal .LC1923, .LC1922
	.literal .LC1925, .LC1924
	.literal .LC1927, .LC1926
	.literal .LC1929, .LC1928
	.literal .LC1931, .LC1930
	.literal .LC1933, .LC1932
	.literal .LC1936, .LC1935
	.literal .LC1937, -2147483648
	.literal .LC1938, 2147483647
	.literal .LC1939, -1598689907
	.literal .LC1940, 1051772663
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console8dispatchEv
	.type	_ZN21MotorControlRSExample5Probe7Console8dispatchEv, @function
_ZN21MotorControlRSExample5Probe7Console8dispatchEv:
.LFB1095:
	entry	sp, 1952
.LCFI88:
	movi	a10, 0x5d8
	add.n	a10, sp, a10
	movi.n	a12, 0x58
	movi.n	a11, 0
	call8	memset
	movi	a8, 0xa4
	add.n	a8, a2, a8
	movi.n	a7, 0
	movi.n	a13, 1
	movi.n	a14, 0x16
	movi	a15, -0x21
	movi.n	a6, 9
	movi.n	a5, 0
	j	.L2777
.L2778:
	addi.n	a8, a8, 1
.L2787:
	l8ui	a11, a8, 0
	addi	a12, a11, -32
	nsau	a9, a12
	srli	a9, a9, 5
	beqz.n	a12, .L2778
	addi	a12, a11, -9
	moveqz	a9, a13, a12
	bnez.n	a9, .L2778
	beqz.n	a11, .L2779
	bne	a7, a14, .L2780
	l32r	a13, .LC1535
	l32r	a12, .LC1537
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2780:
	addi.n	a7, a7, 1
	s32i	a8, a10, 0
	j	.L2782
.L2784:
	addi.n	a8, a8, 1
.L2782:
	l8ui	a9, a8, 0
	bnone	a9, a15, .L2783
	bne	a9, a6, .L2784
	j	.L2785
.L2783:
	beqz.n	a9, .L2786
.L2785:
	s8i	a5, a8, 0
	addi.n	a8, a8, 1
.L2786:
	addi.n	a10, a10, 4
.L2777:
	l8ui	a9, a8, 0
	bnez.n	a9, .L2787
.L2779:
	beqz.n	a7, .L2775
	l32r	a6, .LC1538
	add.n	a6, a2, a6
	j	.L2789
.L2790:
	movi.n	a9, 1
	movnez	a9, a8, a8
	s32i	a9, a6, 0
.L2789:
	l32i	a8, a6, 0
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a11, a9, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console11outstandingEm
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addi.n	a8, a8, 1
	bnez.n	a10, .L2790
	movi	a10, 0x6b0
	movi	a9, 0xe0
	add.n	a10, a10, sp
	l32i	a10, a10, 0
	add.n	a9, sp, a9
	addmi	a5, a9, 0x500
	s32i	a10, a5, 200
	movi.n	a10, 1
	maxu	a8, a8, a10
	s32i	a8, a6, 0
	movi	a8, 0x4f8
	add.n	a8, a9, a8
	l32i	a10, a8, 0
	movi.n	a6, 0
	l8ui	a8, a10, 0
	bnei	a8, 64, .L2791
	movi	a11, 0x5c8
	add.n	a11, a9, a11
	addi.n	a10, a10, 1
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L2792
	l32i	a8, a5, 200
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	beqz.n	a8, .L2792
	beqi	a7, 1, .L2793
	movi.n	a6, 1
	j	.L2791
.L2792:
	l32r	a13, .LC1540
	l32r	a12, .LC1537
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2793:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1542
	l32r	a12, .LC1537
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2791:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console11outstandingEm
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a10, a8, 0
	beqz.n	a10, .L2794
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1544
	l32r	a12, .LC1537
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2794:
	movi	a5, 0xe0
	add.n	a5, sp, a5
	movi	a8, 0x4f8
	add.n	a8, a5, a8
	addx4	a8, a6, a8
	l32i	a4, a8, 0
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_14findEPKc
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	s32i	a10, a8, 0
	beqz.n	a10, .L2795
	mov.n	a11, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18helpTextERKNS1_5EntryERKNS0_4HostE
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a10, a2, 144
	l32i	a8, a8, 0
	addmi	a5, a5, 0x500
	s32i	a10, a5, 168
	s32i	a11, a5, 172
	s32i	a12, a5, 176
	s32i	a13, a5, 180
	s32i	a8, a2, 148
.L2795:
	l32r	a11, .LC1546
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L2796
	l32r	a11, .LC1548
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L2796
	l32r	a11, .LC1526
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L2796
	l32r	a11, .LC1550
	mov.n	a10, a4
	call8	strcmp
	bnez.n	a10, .L2797
.L2796:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1551
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2797:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L2798
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1553
	l32r	a12, .LC1501
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2798:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l8ui	a3, a8, 4
	movi.n	a8, 0x2a
	bne	a3, a8, .L2799
	l32i	a8, a2, 108
	movi	a9, 0x6e0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	bnez.n	a8, .L2800
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2800:
	movi	a8, 0xe0
	l32r	a11, .LC1556
	add.n	a10, sp, a8
	movi.n	a12, 0x38
	call8	memcpy
	mov.n	a8, a10
	movi	a10, 0x6d0
	movi.n	a9, 0
	add.n	a10, a10, sp
	addi.n	a5, a6, 1
	s32i	a9, a10, 0
	addi.n	a6, a6, 2
	bne	a7, a6, .L2802
	movi	a9, 0x4f8
	add.n	a8, a8, a9
	addx4	a8, a5, a8
	l32i	a6, a8, 0
	l32r	a11, .LC1558
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3711
	l32r	a11, .LC1560
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3712
	l32r	a11, .LC1562
	mov.n	a10, a6
	call8	strcmp
	movi.n	a8, 2
	beqz.n	a10, .L2804
	j	.L2805
.L3712:
	movi.n	a8, 1
	j	.L2804
.L3713:
	movi.n	a8, 3
.L2804:
	s8i	a8, sp, 224
	j	.L2803
.L2805:
	l32r	a11, .LC1564
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3713
	movi	a9, 0x6d0
	movi.n	a8, 0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	j	.L2802
.L2831:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a11, .LC1566
	addx4	a8, a5, a8
	l32i	a4, a8, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	mov.n	a10, a4
	addmi	a3, a8, 0x400
	movi.n	a8, 0
	s32i	a8, a3, 24
	call8	strcmp
	addi.n	a6, a5, 1
	mov.n	a8, a10
	beqz.n	a10, .L2806
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	l32r	a11, .LC1568
	s32i	a10, a9, 0
	mov.n	a10, a4
	call8	strcmp
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a10, .L2807
.L2806:
	bgeu	a6, a7, .L2808
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	l32r	a11, .LC1437
	addx4	a6, a6, a9
	l32i	a10, a6, 0
	addi.n	a4, a5, 2
	bnez.n	a8, .L2809
	l32r	a11, .LC1436
.L2809:
	call8	strcmp
	beqz.n	a10, .L3715
.L2808:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1570
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2807:
	l32r	a11, .LC1572
	mov.n	a10, a4
	call8	strcmp
	bnez.n	a10, .L2812
	s32i	a10, sp, 888
	addi.n	a4, a5, 3
	bltu	a7, a4, .L2813
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a11, 0x418
	addx4	a6, a6, a8
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a10, a6, 0
	add.n	a11, a8, a11
	addi.n	a5, a5, 2
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L2813
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a11, 0x298
	addx4	a5, a5, a8
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a10, a5, 0
	add.n	a11, a8, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L2813
	l32i	a9, a3, 24
	beqz.n	a9, .L2813
	l32i	a8, sp, 888
	bltu	a8, a9, .L2813
	movi	a10, 0xf7
	bltu	a10, a8, .L2813
	s8i	a9, sp, 229
	s8i	a8, sp, 230
	movi.n	a3, 2
	j	.L2810
.L2813:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1574
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2812:
	l32r	a11, .LC1576
	mov.n	a10, a4
	call8	strcmp
	bnez.n	a10, .L2814
	addi.n	a4, a5, 3
	bgeu	a7, a4, .L2815
.L2817:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1578
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2815:
	addmi	a8, sp, 0x100
	l8ui	a8, a8, 8
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	beqi	a8, 4, .L2817
	movi	a9, 0x6e8
	addi.n	a8, a5, 2
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a9, .LC1579
	addx4	a6, a6, a8
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a3, 0x298
	addmi	a5, a8, 0x200
	s32i	a9, a8, 664
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s8i	a10, a5, 156
	add.n	a3, a8, a3
	l32i	a10, a6, 0
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	l32i	a6, a5, 152
	beqz.n	a10, .L2817
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addi.n	a11, a3, 4
	addx4	a8, a8, a9
	l32i	a10, a8, 0
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE
	l8ui	a5, a5, 156
	beqz.n	a10, .L2817
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	beqz.n	a10, .L2817
	movi	a8, 0xe0
	add.n	a8, sp, a8
	movi.n	a9, 0
	j	.L2818
.L2821:
	l32i	a10, a8, 8
	bne	a10, a6, .L2819
	l8ui	a10, a8, 12
	beq	a10, a5, .L2820
.L2819:
	addi.n	a9, a9, 1
	extui	a9, a9, 0, 8
	addi.n	a8, a8, 8
	j	.L2818
.L2820:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1581
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2818:
	movi	a10, 0x6d8
	add.n	a10, a10, sp
	l32i	a10, a10, 0
	bne	a10, a9, .L2821
	addi.n	a8, a10, 1
	addmi	a9, sp, 0x100
	s8i	a8, a9, 8
	movi	a9, 0xe0
	extui	a8, a8, 0, 8
	add.n	a9, sp, a9
	addx8	a8, a8, a9
	s32i	a6, a8, 0
	s8i	a5, a8, 4
	movi.n	a3, 0
	j	.L2822
.L2814:
	l32r	a11, .LC1583
	mov.n	a10, a4
	call8	strcmp
	bnez.n	a10, .L2823
	movi.n	a9, 1
	addmi	a8, sp, 0x100
	s8i	a9, a8, 23
	mov.n	a4, a6
	movi.n	a3, 4
	j	.L2810
.L2823:
	l32r	a11, .LC1585
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3716
	l32r	a11, .LC1587
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3717
	l32r	a11, .LC1589
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3718
	l32r	a11, .LC1591
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3719
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3716:
	l32r	a9, .LC1439
	movi.n	a3, 8
	j	.L2824
.L3717:
	movi	a9, 0x753
	movi.n	a3, 0x10
	slli	a9, a9, 5
	j	.L2824
.L3718:
	movi.n	a3, 0x20
	movi	a9, 0x100
	j	.L2824
.L3719:
	movi.n	a3, 0x40
	movi.n	a9, 8
.L2824:
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	s32i	a9, a8, 0
	bgeu	a6, a7, .L2825
	movi	a8, 0xe0
	addi.n	a4, a5, 2
	add.n	a5, sp, a8
	movi	a8, 0x4f8
	add.n	a8, a5, a8
	addx4	a6, a6, a8
	movi	a11, 0x418
	l32i	a10, a6, 0
	add.n	a11, a5, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L2825
	addmi	a8, a5, 0x400
	movi	a9, 0x6d8
	l32i	a8, a8, 24
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addi.n	a10, a8, -1
	bgeu	a10, a9, .L2825
	bnei	a3, 8, .L4558
	j	.L2826
.L2825:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1594
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2826:
	s32i	a8, sp, 268
	j	.L2810
.L4558:
	bnei	a3, 16, .L2828
	s32i	a8, sp, 272
	j	.L2810
.L2828:
	bnei	a3, 32, .L2829
	s16i	a8, sp, 276
	j	.L2810
.L2829:
	addmi	a9, sp, 0x100
	s8i	a8, a9, 22
	movi.n	a3, 0x40
	j	.L2810
.L3715:
	movi.n	a3, 1
.L2810:
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnone	a8, a3, .L2822
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1596
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2822:
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6d0
	or	a8, a8, a3
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	mov.n	a5, a4
	j	.L2830
.L2802:
	movi	a8, 0xe0
	movi	a9, 0x6b8
	add.n	a8, sp, a8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi	a8, 0x4f8
	add.n	a8, a9, a8
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L2830:
	bltu	a5, a7, .L2831
	j	.L2803
.L3711:
	movi	a9, 0x6c8
	movi.n	a8, 1
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L2803:
	l32r	a7, .LC1597
	add.n	a8, a2, a7
	l8ui	a8, a8, 0
	bnez.n	a8, .L2833
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2834
.L2833:
	l8ui	a8, sp, 224
	bnei	a8, 1, .L2835
.L2834:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a9, a8, 0x400
	movi.n	a11, 0
	s32i	a11, a9, 24
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi	a12, 0x418
	moveqz	a11, a8, a9
	add.n	a12, a8, a12
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a10, a2, 0
	callx8	a8
	add.n	a8, a2, a7
	l8ui	a8, a8, 0
	bnez.n	a8, .L2838
	j	.L4559
.L2835:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2837
	addi.n	a10, a10, 1
.L2837:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L4559:
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2839
.L2838:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2840
	addi.n	a10, a10, 1
.L2840:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2839:
	movi	a7, 0x124
	s32i	a8, sp, 888
	l32r	a4, .LC1441
	add.n	a7, a2, a7
	bnez.n	a10, .L2841
	l32r	a4, .LC1440
.L2841:
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a9, -1
	bnez.n	a8, .L2842
	l8ui	a9, sp, 224
.L2842:
	movi	a8, 0xe0
	add.n	a6, sp, a8
	movi	a8, 0x6b0
	s32i	a10, sp, 0
	movi	a5, 0x298
	s32i	a9, sp, 4
	add.n	a8, a8, sp
	add.n	a5, a6, a5
	l32i	a14, a8, 0
	l32r	a13, .LC1601
	l32r	a11, .LC1602
	mov.n	a15, a4
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2843
.L2844:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1555
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2843:
	addmi	a8, a6, 0x400
	l32i	a13, a8, 24
	l32r	a11, .LC1602
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13discoveryScanEPcjRjPKNS0_13DiscoveryScanE
	beqz.n	a10, .L2844
	l32r	a13, .LC1605
	l32r	a11, .LC1602
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2844
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2799:
	bnei	a3, 16, .L2845
	addi.n	a5, a6, 2
	bltu	a7, a5, .L2846
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32r	a11, .LC1607
	l32i	a10, a8, 4
	call8	strcmp
	bnez.n	a10, .L2846
	beq	a5, a7, .L2847
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1609
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2847:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2849
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2850
.L2849:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2851
	addi.n	a10, a10, 1
.L2851:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2850:
	movi	a6, 0xe0
	add.n	a6, sp, a6
	addmi	a9, a6, 0x500
	s32i	a8, a9, 80
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	movi	a5, 0x124
	l32i	a14, a8, 0
	l32r	a13, .LC1611
	l32r	a11, .LC1602
	add.n	a5, a2, a5
	movi	a12, 0x550
	add.n	a12, a6, a12
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	movi.n	a4, 0
	addmi	a7, a6, 0x200
	j	.L2852
.L4561:
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l8ui	a10, sp, 225
	s32i	a8, a9, 0
	mov.n	a11, a3
	call8	_ZN14MotorControlRS24getDiscoveryCapabilitiesENS_12DriveProfileERNS_21DiscoveryCapabilitiesE
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a10, a8, 24
	s32i	a11, a8, 28
	s32i	a12, a8, 32
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2853
	bnez.n	a4, .L2854
.L2856:
	l32i	a8, sp, 236
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l8ui	a9, a7, 152
	l32i	a14, sp, 228
	l32i	a15, sp, 232
	l32i	a3, sp, 240
	l32r	a8, .LC1441
	beqz.n	a9, .L2855
	l32r	a8, .LC1440
	j	.L2855
.L2853:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1613
	l32r	a12, .LC1609
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2854:
	movi	a12, 0x550
	l32r	a13, .LC1496
	l32r	a11, .LC1602
	add.n	a12, a6, a12
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2856
	j	.L3701
.L2855:
	l8ui	a10, a7, 153
	l32r	a9, .LC1441
	beqz.n	a10, .L2858
	l32r	a9, .LC1440
.L2858:
	l8ui	a11, a7, 154
	l32r	a10, .LC1441
	beqz.n	a11, .L2859
	l32r	a10, .LC1440
.L2859:
	l8ui	a12, a7, 155
	l32r	a11, .LC1441
	beqz.n	a12, .L2860
	l32r	a11, .LC1440
.L2860:
	l8ui	a13, a7, 156
	l32r	a12, .LC1441
	beqz.n	a13, .L2861
	l32r	a12, .LC1440
.L2861:
	l16ui	a13, a7, 168
	addi.n	a4, a4, 1
	s32i	a13, sp, 48
	l16ui	a13, a7, 166
	s32i	a13, sp, 44
	l16ui	a13, a7, 164
	s32i	a13, sp, 40
	l16ui	a13, a7, 162
	s32i	a13, sp, 36
	l8ui	a13, a7, 158
	s32i	a13, sp, 32
	l8ui	a13, a7, 157
	s32i	a8, sp, 8
	movi	a8, 0x6b8
	s32i	a13, sp, 28
	s32i	a12, sp, 24
	s32i	a11, sp, 20
	s32i	a10, sp, 16
	s32i	a9, sp, 12
	s32i	a3, sp, 4
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1615
	l32r	a11, .LC1602
	movi	a12, 0x550
	s32i	a8, sp, 0
	add.n	a12, a6, a12
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L2852:
	beqz.n	a10, .L3701
	call8	_ZN14MotorControlRS21discoveryProfileCountEv
	bltu	a4, a10, .L2862
	j	.L4560
.L3701:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1609
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2862:
	l32r	a11, .LC1617
	movi.n	a12, 0x14
	mov.n	a10, a6
	movi	a3, 0x98
	call8	memcpy
	add.n	a3, a7, a3
	movi.n	a12, 0x12
	movi.n	a11, 0
	mov.n	a10, a3
	call8	memset
	mov.n	a11, a6
	mov.n	a10, a4
	call8	_ZN14MotorControlRS19getDiscoveryProfileEjRNS_16DiscoveryProfileE
	addmi	a8, a6, 0x400
	s32i	a10, a8, 136
	s32i	a11, a8, 140
	s32i	a12, a8, 144
	extui	a10, a10, 0, 8
	beqz.n	a10, .L4561
	j	.L2853
.L3702:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2845:
	movi.n	a8, 0x29
	bne	a3, a8, .L2846
	l32i	a4, a2, 112
	beqz.n	a4, .L2865
	l32i	a8, a2, 12
	bnez.n	a8, .L2866
.L2865:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1619
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2866:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a3, a8, 0x400
	movi.n	a9, 0
	addi.n	a5, a6, 2
	s8i	a9, a3, 136
	addi.n	a6, a6, 1
	bltu	a7, a6, .L3996
	bgeu	a5, a7, .L2868
.L3996:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1619
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2868:
	bne	a5, a7, .L2870
	movi	a9, 0x4f8
	add.n	a8, a8, a9
	addx4	a6, a6, a8
	l32i	a6, a6, 0
	l32r	a11, .LC1444
	mov.n	a10, a6
	call8	strcmp
	movi.n	a8, 1
	beqz.n	a10, .L4579
.L2871:
	l32r	a11, .LC1445
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L2872
	movi.n	a8, 2
.L4579:
	s8i	a8, a3, 136
	j	.L2870
.L2872:
	l32r	a11, .LC1443
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L2870
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1619
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2870:
	l32r	a6, .LC1597
	add.n	a8, a2, a6
	l8ui	a8, a8, 0
	bnez.n	a8, .L2873
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2874
.L2873:
	bne	a5, a7, .L2875
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 136
	bnez.n	a8, .L2875
.L2874:
	movi	a3, 0xe0
	add.n	a3, sp, a3
	movi	a10, 0x298
	movi.n	a11, 0
	movi.n	a12, 0x48
	add.n	a10, a3, a10
	call8	memset
	l32i	a10, a2, 0
	movi.n	a11, 0
	bne	a5, a7, .L2877
	movi	a11, 0x488
	add.n	a11, a3, a11
	j	.L2877
.L2875:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2878
	addi.n	a10, a10, 1
.L2878:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2877:
	movi	a12, 0x378
	add.n	a12, sp, a12
	callx8	a4
	mov.n	a4, a10
	bnez.n	a10, .L2879
	bne	a5, a7, .L2879
	l8ui	a8, a2, 141
	s8i	a8, a2, 142
.L2879:
	add.n	a6, a2, a6
	l8ui	a8, a6, 0
	bnez.n	a8, .L2880
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2881
.L2880:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2882
	addi.n	a10, a10, 1
.L2882:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2881:
	movi	a8, 0xe0
	add.n	a10, sp, a8
	movi	a12, 0x298
	movi.n	a11, 0
	call8	memset
	mov.n	a8, a10
	movi.n	a10, 0x14
	l32r	a9, .LC1579
	s32i	a10, sp, 300
	l32r	a10, .LC1620
	s32i	a9, sp, 224
	s32i	a9, sp, 232
	s32i	a9, sp, 240
	s32i	a10, sp, 308
	movi.n	a9, 1
	l32r	a10, .LC1621
	s8i	a9, sp, 248
	movi.n	a9, 1
	s32i	a9, sp, 252
	s32i	a10, sp, 312
	s32i	a10, sp, 316
	addmi	a10, sp, 0x100
	s8i	a9, a10, 88
	l32r	a9, .LC1457
	s32i	a9, sp, 404
	movi.n	a9, 0x40
	s32i	a9, sp, 480
	movi.n	a9, 0xa
	s32i	a9, sp, 532
	l32i	a9, a2, 12
	beqz.n	a9, .L2884
	l32i	a10, a2, 0
	mov.n	a11, a8
	callx8	a9
.L2884:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	movi.n	a9, 0
	s32i	a9, a8, 24
	movi	a7, 0x124
	movi	a9, 0x6b8
	add.n	a8, a2, a7
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32r	a5, .LC1441
	bnez.n	a4, .L2885
	l32r	a5, .LC1440
.L2885:
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 152
	l32r	a6, .LC1444
	mov.n	a7, a10
	beqi	a8, 1, .L2886
	l32r	a6, .LC1443
	bnei	a8, 2, .L2886
	l32r	a6, .LC1445
.L2886:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l32i	a10, a8, 160
	l32i	a11, a8, 164
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	l32i	a10, a8, 168
	l32i	a11, a8, 172
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	l32i	a10, a8, 176
	l32i	a11, a8, 180
	movi	a9, 0x6d0
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	l32i	a10, a8, 184
	l32i	a11, a8, 188
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	l32i	a10, a8, 192
	l32i	a11, a8, 196
	movi	a9, 0x6e0
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	l32i	a10, a8, 200
	l32i	a11, a8, 204
	movi	a9, 0x6e8
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	movi	a10, 0x6f0
	l32i	a9, a8, 208
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	l32i	a9, a8, 212
	movi	a10, 0x6f8
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	l32i	a9, a8, 216
	addmi	a10, sp, 0x700
	addmi	a4, sp, 0x100
	s32i	a9, a10, 0
	l8ui	a10, a4, 135
	l32i	a3, a8, 220
	call8	_ZN21MotorControlRSExample3Rtu9phaseNameENS0_5PhaseE
	l8ui	a9, a4, 132
	l32r	a8, .LC1441
	beqz.n	a9, .L2887
	l32r	a8, .LC1440
.L2887:
	l8ui	a11, a4, 134
	l32r	a9, .LC1441
	beqz.n	a11, .L2888
	l32r	a9, .LC1440
.L2888:
	l32i	a11, sp, 512
	movi	a12, 0x708
	add.n	a12, a12, sp
	s32i	a11, a12, 0
	addmi	a11, sp, 0x100
	l8ui	a12, a11, 216
	l32i	a14, sp, 516
	l32r	a11, .LC1449
	beqz.n	a12, .L2889
	l32r	a11, .LC1447
.L2889:
	l32i	a12, sp, 840
	movi	a4, 0x710
	add.n	a4, a4, sp
	s32i	a12, a4, 0
	l32i	a13, sp, 844
	movi	a12, 0x2e0
	add.n	a12, sp, a12
	s32i	a13, a4, 4
	l8ui	a4, a12, 120
	l32i	a15, sp, 848
	l32r	a12, .LC1441
	beqz.n	a4, .L2890
	l32r	a12, .LC1440
.L2890:
	l32i	a4, sp, 872
	s32i	a12, sp, 112
	s32i	a4, sp, 124
	l32i	a4, sp, 860
	movi	a12, 0x710
	s32i	a4, sp, 120
	l32i	a4, sp, 884
	add.n	a12, a12, sp
	s32i	a4, sp, 116
	l32i	a13, a12, 4
	l32i	a12, a12, 0
	s32i	a11, sp, 92
	movi	a11, 0x708
	s32i	a12, sp, 104
	s32i	a13, sp, 108
	s32i	a15, sp, 96
	s32i	a14, sp, 88
	add.n	a11, a11, sp
	l32i	a11, a11, 0
	s32i	a8, sp, 76
	s32i	a11, sp, 84
	s32i	a10, sp, 72
	s32i	a9, sp, 80
	s32i	a3, sp, 68
	addmi	a8, sp, 0x700
	l32i	a8, a8, 0
	movi	a12, 0x4f8
	s32i	a8, sp, 64
	movi	a8, 0x6f8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	mov.n	a15, a5
	s32i	a8, sp, 60
	movi	a8, 0x6f0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	add.n	a12, sp, a12
	s32i	a8, sp, 56
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 52
	s32i	a8, sp, 48
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a8, sp, 40
	movi	a8, 0x6d8
	s32i	a9, sp, 44
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 36
	s32i	a8, sp, 32
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 24
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 20
	s32i	a8, sp, 16
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 12
	s32i	a8, sp, 8
	movi	a8, 0x6b0
	s32i	a6, sp, 4
	s32i	a7, sp, 0
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a13, .LC1623
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2891
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2891:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1619
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2846:
	addi	a8, a3, -29
	extui	a8, a8, 0, 8
	movi.n	a9, 1
	saltu	a8, a9, a8
	addi.n	a8, a8, -1
	neg	a8, a8
	extui	a8, a8, 0, 8
	bnez.n	a8, .L3997
	addi	a10, a3, -33
	movnez	a9, a8, a10
	beqz.n	a9, .L2892
.L3997:
	addi.n	a5, a6, 2
	bgeu	a5, a7, .L2892
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32r	a11, .LC1625
	l32i	a10, a8, 4
	call8	strcmp
	bnez.n	a10, .L2892
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2894
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2895
.L2894:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2896
	addi.n	a10, a10, 1
.L2896:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2895:
	movi.n	a8, 0x21
	movi.n	a12, 0
	beq	a3, a8, .L2897
	movi.n	a8, 0x1e
	movi.n	a12, 2
	bne	a3, a8, .L2897
	movi.n	a12, 1
.L2897:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	movi	a13, 0x5d8
	addi	a14, a7, -2
	add.n	a13, sp, a13
	extui	a5, a5, 0, 16
	l32i	a11, a8, 0
	sub	a14, a14, a6
	addx4	a13, a5, a13
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18qualificationRouteEmNS0_18QualificationRouteEPKPKcj
	j	.L2775
.L2892:
	addi	a8, a3, -30
	extui	a8, a8, 0, 8
	movi.n	a9, 0xa
	bltu	a9, a8, .L2898
	l32r	a9, .LC1626
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L2900:
	.word	.L2904
	.word	.L2898
	.word	.L2898
	.word	.L2904
	.word	.L2898
	.word	.L2898
	.word	.L2898
	.word	.L2903
	.word	.L2902
	.word	.L2901
	.word	.L2899
	.text
.L2899:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2905
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2906
.L2905:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2907
	addi.n	a10, a10, 1
.L2907:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2906:
	addi.n	a5, a6, 3
	addi.n	a4, a6, 2
	bltu	a7, a5, .L2909
	movi	a3, 0x5d8
	add.n	a3, sp, a3
	addx4	a8, a6, a3
	l32r	a11, .LC1628
	l32i	a10, a8, 4
	call8	strcmp
	bnez.n	a10, .L2910
	addx4	a8, a4, a3
	l32r	a11, .LC1630
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L2911
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	addi	a14, a7, -3
	extui	a13, a5, 0, 16
	l32i	a11, a8, 0
	sub	a14, a14, a6
	addx4	a13, a13, a3
	movi.n	a12, 3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18qualificationRouteEmNS0_18QualificationRouteEPKPKcj
	j	.L2775
.L2909:
	bltu	a7, a4, .L2910
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32r	a11, .LC1628
	l32i	a10, a8, 4
	call8	strcmp
	bnez.n	a10, .L2910
.L2911:
	l32i	a8, a2, 52
	beqz.n	a8, .L2912
	l32i	a8, a2, 12
	bnez.n	a8, .L2913
.L2912:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1631
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2913:
	movi	a6, 0xe0
	add.n	a6, sp, a6
	movi.n	a8, 0
	addmi	a3, a6, 0x400
	movi	a10, 0x6c0
	s32i	a8, a3, 136
	add.n	a10, a10, sp
	addmi	a8, a6, 0x200
	movi	a9, 0x98
	add.n	a9, a8, a9
	s32i	a8, a10, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	s32i	a9, a8, 0
	mov.n	a10, a9
	movi	a12, 0x88
	movi.n	a11, 0
	call8	memset
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a9, 7
	s16i	a9, a8, 166
	movi	a9, 0x190
	s16i	a9, a8, 170
	movi.n	a9, 1
	s8i	a9, a8, 218
	movi.n	a9, 2
	s16i	a9, a8, 240
	bne	a5, a7, .L2916
	movi	a8, 0x4f8
	add.n	a8, a6, a8
	addx4	a8, a4, a8
	movi	a11, 0x488
	l32i	a10, a8, 0
	add.n	a11, a6, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L2916
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a11, a3, 136
	l32i	a10, a8, 0
	call8	_ZN14MotorControlRS6ESS_RS25preparePositionStartSpeedERNS0_13DriverRequestEm
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a5, a10, 0, 8
	bnez.n	a5, .L2916
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	movi.n	a9, 1
	s8i	a9, sp, 248
	movi.n	a9, 0x14
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	l32r	a8, .LC1579
	s32i	a9, sp, 308
	l32r	a9, .LC1621
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a7, sp, 0x100
	s8i	a8, a7, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	mov.n	a11, a6
	callx8	a8
	movi.n	a12, 0
	s32i	a5, a3, 24
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	bne	a10, a8, .L2918
	l8ui	a5, a7, 88
	movi.n	a6, 1
	movi.n	a7, 0
	j	.L2919
.L2916:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1631
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2918:
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a14, a9, 0
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l8ui	a12, a7, 88
	l32i	a8, a2, 52
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a15, 0x418
	add.n	a15, a6, a15
	movi.n	a13, 1
	callx8	a8
	mov.n	a6, a10
	l8ui	a5, a7, 88
	movi.n	a7, 0
	bnez.n	a10, .L2919
	movi	a8, 0x6b0
	l32i	a7, a3, 24
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L2919:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1631
	l32i	a11, a8, 0
	mov.n	a15, a7
	mov.n	a14, a5
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L2910:
	l32i	a5, a2, 116
	bnez.n	a5, .L2920
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1633
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2920:
	beq	a7, a4, .L2921
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1633
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2921:
	movi	a8, 0x5d8
	addi.n	a6, a6, 1
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32i	a7, a8, 0
	l32r	a11, .LC1558
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L3739
	l32r	a11, .LC1634
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L3740
	l32r	a11, .LC1562
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L3741
	l32r	a11, .LC1636
	mov.n	a10, a7
	call8	strcmp
	movi.n	a4, 3
	beqz.n	a10, .L2922
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1633
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3739:
	movi.n	a4, 0
	j	.L2922
.L3740:
	movi.n	a4, 1
	j	.L2922
.L3741:
	movi.n	a4, 2
.L2922:
	movi	a7, 0xe0
	add.n	a7, sp, a7
	movi	a12, 0x118
	movi.n	a11, 0
	mov.n	a10, a7
	call8	memset
	l32r	a8, .LC1637
	l32i	a10, a2, 0
	s32i	a8, sp, 496
	mov.n	a12, a7
	mov.n	a11, a4
	callx8	a5
	l32i	a11, sp, 400
	movi	a12, 0x488
	add.n	a12, a7, a12
	movi.n	a13, 0x27
	mov.n	a4, a10
	addi	a10, a7, 64
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a11, sp, 404
	movi	a12, 0x298
	add.n	a12, a7, a12
	addi	a10, a7, 83
	movi	a13, 0x81
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a11, sp, 408
	movi	a12, 0x550
	movi	a10, 0x93
	add.n	a12, a7, a12
	add.n	a10, a7, a10
	movi.n	a13, 0x11
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	l32i	a11, sp, 412
	movi	a12, 0x418
	movi	a10, 0x9b
	add.n	a12, a7, a12
	add.n	a10, a7, a10
	movi.n	a13, 0x27
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcj
	addmi	a7, a7, 0x500
	movi.n	a8, 0
	movi	a5, 0x124
	s32i	a8, a7, 112
	l32r	a3, .LC1441
	add.n	a5, a2, a5
	bnez.n	a4, .L2924
	l32r	a3, .LC1440
.L2924:
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l8ui	a9, sp, 224
	s32i	a10, a8, 0
	l32r	a8, .LC1441
	beqz.n	a9, .L2925
	l32r	a8, .LC1440
.L2925:
	l8ui	a10, sp, 225
	l32r	a9, .LC1441
	beqz.n	a10, .L2926
	l32r	a9, .LC1440
.L2926:
	l8ui	a11, sp, 226
	l32r	a10, .LC1441
	beqz.n	a11, .L2927
	l32r	a10, .LC1440
.L2927:
	l8ui	a12, sp, 227
	l32r	a11, .LC1441
	beqz.n	a12, .L2928
	l32r	a11, .LC1440
.L2928:
	l8ui	a12, sp, 229
	movi	a13, 0x6c8
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l8ui	a12, sp, 230
	movi	a13, 0x6d0
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l32i	a12, sp, 232
	movi	a13, 0x6d8
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l32i	a12, sp, 236
	movi	a13, 0x6e0
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 264
	movi	a13, 0x6e8
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 266
	movi	a13, 0x6f0
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 268
	movi	a13, 0x6f8
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 270
	addmi	a13, sp, 0x700
	s32i	a12, a13, 0
	l16ui	a12, sp, 272
	movi	a13, 0x708
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 274
	movi	a13, 0x710
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 276
	movi	a13, 0x718
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 278
	movi	a13, 0x720
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	l16ui	a12, sp, 280
	movi	a13, 0x728
	add.n	a13, a13, sp
	s32i	a12, a13, 0
	movi	a7, 0x730
	l32i	a12, sp, 416
	add.n	a7, a7, sp
	s32i	a12, a7, 0
	l32i	a13, sp, 420
	movi	a12, 0x1e0
	add.n	a12, sp, a12
	l16ui	a14, sp, 282
	l16ui	a15, sp, 284
	l16ui	a4, sp, 286
	s32i	a13, a7, 4
	l8ui	a13, a12, 12
	movi	a7, 0x6b8
	l32r	a12, .LC1441
	add.n	a7, a7, sp
	s32i	a12, a7, 0
	beqz.n	a13, .L2929
	l32r	a12, .LC1440
	s32i	a12, a7, 0
.L2929:
	l32i	a12, sp, 424
	l32i	a13, sp, 428
	movi	a7, 0x738
	add.n	a7, a7, sp
	s32i	a12, a7, 0
	s32i	a13, a7, 4
	l32i	a13, sp, 436
	movi	a7, 0x740
	add.n	a7, a7, sp
	s32i	a13, a7, 4
	l32i	a12, sp, 432
	movi	a13, 0x1e0
	add.n	a13, sp, a13
	s32i	a12, a7, 0
	l8ui	a7, a13, 13
	l32r	a13, .LC1441
	beqz.n	a7, .L2930
	l32r	a13, .LC1440
.L2930:
	l32i	a12, sp, 496
	s32i	a13, sp, 128
	s32i	a12, sp, 132
	movi	a12, 0x740
	add.n	a12, a12, sp
	l32i	a13, a12, 4
	l32i	a12, a12, 0
	s32i	a13, sp, 124
	s32i	a12, sp, 120
	movi	a12, 0x738
	add.n	a12, a12, sp
	l32i	a13, a12, 4
	l32i	a12, a12, 0
	s32i	a13, sp, 116
	s32i	a12, sp, 112
	movi	a12, 0x6b8
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	movi	a7, 0xe0
	s32i	a12, sp, 104
	movi	a12, 0x730
	add.n	a12, a12, sp
	l32i	a13, a12, 4
	l32i	a12, a12, 0
	add.n	a7, sp, a7
	s32i	a12, sp, 96
	movi	a12, 0x550
	add.n	a12, a7, a12
	s32i	a12, sp, 92
	movi	a12, 0x298
	add.n	a12, a7, a12
	s32i	a12, sp, 88
	movi	a12, 0x488
	add.n	a12, a7, a12
	s32i	a12, sp, 84
	movi	a12, 0x728
	s32i	a13, sp, 100
	s32i	a15, sp, 76
	s32i	a14, sp, 72
	s32i	a4, sp, 80
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	mov.n	a15, a3
	s32i	a12, sp, 68
	movi	a12, 0x720
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 64
	movi	a12, 0x718
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 60
	movi	a12, 0x710
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 56
	movi	a12, 0x708
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 52
	addmi	a12, sp, 0x700
	l32i	a12, a12, 0
	l32r	a13, .LC1639
	s32i	a12, sp, 48
	movi	a12, 0x6f8
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 44
	movi	a12, 0x6f0
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 40
	movi	a12, 0x6e8
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 36
	movi	a12, 0x6e0
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 32
	movi	a12, 0x6d8
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 28
	movi	a12, 0x6d0
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a12, sp, 24
	movi	a12, 0x6c8
	add.n	a12, a12, sp
	l32i	a12, a12, 0
	s32i	a8, sp, 4
	movi	a8, 0x6c0
	s32i	a12, sp, 20
	s32i	a11, sp, 16
	s32i	a10, sp, 12
	s32i	a9, sp, 8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a12, 0x570
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32r	a11, .LC1602
	add.n	a12, a7, a12
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2931
	addmi	a9, a7, 0x500
	l32i	a8, a9, 112
	l32r	a15, .LC1441
	addi.n	a8, a8, -1
	s32i	a8, a9, 112
	movi	a8, 0x4f8
	add.n	a8, a7, a8
	addmi	a7, a7, 0x100
	addx4	a6, a6, a8
	l8ui	a8, a7, 10
	l32i	a14, a6, 0
	beqz.n	a8, .L2932
	l32r	a15, .LC1440
.L2932:
	movi	a8, 0x1e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 11
	l32r	a12, .LC1441
	beqz.n	a8, .L2933
	l32r	a12, .LC1440
.L2933:
	l32i	a8, sp, 440
	l32i	a9, sp, 444
	movi	a10, 0x6b8
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 448
	l32i	a9, sp, 452
	movi	a10, 0x6c0
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 456
	movi	a10, 0x6c8
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	movi	a8, 0x1e0
	l32i	a9, sp, 460
	add.n	a8, sp, a8
	l8ui	a8, a8, 8
	s32i	a9, a10, 4
	l32r	a13, .LC1441
	beqz.n	a8, .L2934
	l32r	a13, .LC1440
.L2934:
	movi	a7, 0x1e0
	l32i	a8, sp, 464
	l32i	a9, sp, 468
	movi	a10, 0x6d0
	add.n	a7, sp, a7
	add.n	a10, a10, sp
	l8ui	a7, a7, 9
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 472
	l32i	a9, sp, 476
	l32i	a10, sp, 480
	l32i	a11, sp, 484
	l32r	a6, .LC1441
	beqz.n	a7, .L2935
	l32r	a6, .LC1440
.L2935:
	s32i	a8, sp, 56
	movi	a8, 0x6d0
	s32i	a10, sp, 64
	s32i	a11, sp, 68
	s32i	a6, sp, 72
	s32i	a9, sp, 60
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a13, sp, 40
	s32i	a8, sp, 48
	movi	a8, 0x6c8
	s32i	a9, sp, 52
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	movi	a7, 0xe0
	s32i	a8, sp, 32
	add.n	a7, sp, a7
	movi	a8, 0x418
	add.n	a8, a7, a8
	s32i	a8, sp, 24
	movi	a8, 0x6c0
	s32i	a9, sp, 36
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 20
	s32i	a8, sp, 16
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	l32r	a13, .LC1641
	s32i	a12, sp, 0
	l32r	a11, .LC1602
	movi	a12, 0x570
	s32i	a8, sp, 8
	s32i	a9, sp, 12
	add.n	a12, a7, a12
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2936
	addmi	a7, a7, 0x500
	l32i	a8, a7, 112
	l32r	a14, .LC1441
	addi.n	a8, a8, -1
	s32i	a8, a7, 112
	l8ui	a8, sp, 228
	beqz.n	a8, .L2937
	l32r	a14, .LC1440
.L2937:
	l32i	a8, sp, 248
	l32i	a9, sp, 260
	s32i	a8, sp, 16
	l32i	a8, sp, 244
	movi	a12, 0x650
	s32i	a8, sp, 12
	l32i	a8, sp, 240
	l32r	a13, .LC1643
	s32i	a8, sp, 8
	l32i	a8, sp, 256
	l32r	a11, .LC1602
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	add.n	a12, sp, a12
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2938
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2938:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1633
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2936:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1633
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2931:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1633
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2903:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2939
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2940
.L2939:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2941
	addi.n	a10, a10, 1
.L2941:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2940:
	l32i	a5, a2, 88
	bnez.n	a5, .L2943
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2943:
	movi	a8, 0xe0
	add.n	a3, sp, a8
	movi	a12, 0x74
	movi.n	a11, 0
	addi.n	a10, a3, 4
	call8	memset
	l32r	a8, .LC1579
	l32i	a10, a2, 0
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	movi.n	a8, 1
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	movi.n	a8, 0x14
	s32i	a8, sp, 300
	l32r	a8, .LC1620
	mov.n	a12, a3
	s32i	a8, sp, 308
	l32r	a8, .LC1621
	movi.n	a11, 0
	s32i	a8, sp, 312
	s32i	a8, sp, 316
	addi.n	a4, a6, 1
	callx8	a5
	beqz.n	a10, .L2945
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a13, a10
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2945:
	addmi	a9, a3, 0x200
	s8i	a10, a9, 160
	l32i	a11, a3, 16
	l8ui	a10, a3, 20
	movi	a8, 0x98
	add.n	a8, a9, a8
	s32i	a11, a8, 0
	s8i	a10, a8, 4
	beq	a7, a4, .L2946
	addi.n	a5, a6, 2
	bne	a5, a7, .L2947
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	s32i	a9, a8, 0
	movi	a8, 0x4f8
	add.n	a8, a3, a8
	addx4	a8, a4, a8
	l32i	a8, a8, 0
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32r	a11, .LC1647
	mov.n	a10, a8
	s32i	a8, a9, 0
	call8	strcmp
	beqz.n	a10, .L2946
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a11, .LC1562
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L2947
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi.n	a8, 1
	s8i	a8, a9, 160
	mov.n	a7, a3
	j	.L2948
.L2947:
	movi	a9, 0x6b8
	addi.n	a8, a6, 3
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	bne	a8, a7, .L2949
	movi	a8, 0xe0
	add.n	a3, sp, a8
	movi	a8, 0x4f8
	add.n	a8, a3, a8
	addx4	a9, a4, a8
	l32i	a9, a9, 0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32r	a11, .LC1648
	s32i	a9, a8, 0
	mov.n	a10, a9
	call8	strcmp
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	movi	a8, 0x5d8
	add.n	a8, a8, sp
	bnez.n	a10, .L2950
	l8ui	a9, sp, 248
	bnez.n	a9, .L2951
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1650
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2951:
	addx4	a8, a5, a8
	movi	a11, 0x298
	l32i	a10, a8, 0
	add.n	a11, a3, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	bnez.n	a10, .L2952
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1578
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2950:
	l32r	a11, .LC1652
	mov.n	a10, a9
	call8	strcmp
	bnez.n	a10, .L2949
	l8ui	a9, sp, 248
	movi	a8, 0x5d8
	add.n	a8, a8, sp
	bnez.n	a9, .L2953
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1650
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2953:
	addx4	a8, a5, a8
	movi	a11, 0x29c
	l32i	a10, a8, 0
	add.n	a11, a3, a11
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE
	bnez.n	a10, .L2952
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1578
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2949:
	addi.n	a6, a6, 4
	bne	a7, a6, .L2954
	movi	a7, 0xe0
	add.n	a7, sp, a7
	movi	a6, 0x4f8
	add.n	a6, a7, a6
	addx4	a4, a4, a6
	l32r	a11, .LC1653
	l32i	a10, a4, 0
	call8	strcmp
	bnez.n	a10, .L2954
	movi	a8, 0x298
	addx4	a5, a5, a6
	add.n	a7, a7, a8
	l32i	a10, a5, 0
	mov.n	a11, a7
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	bnez.n	a10, .L2955
.L2956:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1578
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2955:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addi.n	a11, a7, 4
	addx4	a3, a8, a6
	l32i	a10, a3, 0
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE
	bnez.n	a10, .L2952
	j	.L2956
.L2954:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2948:
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	beqz.n	a10, .L2957
	l8ui	a9, a7, 4
	bgeui	a9, 4, .L2957
	movi	a8, 0xe0
	add.n	a8, sp, a8
	add.n	a9, a9, a8
	l8ui	a9, a9, 116
	beqz.n	a9, .L2957
	movi.n	a9, 4
	loop	a9, .L2960_LEND
.L2960:
	l32i	a10, a8, 100
	beqz.n	a10, .L2958
	l32i	a11, a7, 0
	beq	a10, a11, .L2959
.L2958:
	addi.n	a8, a8, 4
	.L2960_LEND:
	j	.L2957
.L2946:
	movi	a7, 0x124
	add.n	a7, a2, a7
	j	.L3995
.L2957:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1551
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L4577:
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	l32r	a15, .LC1441
	j	.L2961
.L3995:
	l32r	a15, .LC1440
	l32r	a10, .LC1450
.L2961:
	movi	a5, 0xe0
	add.n	a5, sp, a5
	addmi	a8, a5, 0x400
	movi.n	a9, 0
	s32i	a9, a8, 24
	movi	a8, 0x6b0
	s32i	a10, sp, 0
	movi	a6, 0x418
	add.n	a8, a8, sp
	add.n	a6, a5, a6
	l32i	a14, a8, 0
	l32r	a13, .LC1655
	l32r	a11, .LC1602
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L2962
.L2963:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1645
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2962:
	mov.n	a12, a5
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostStateEPcjRjRKNS0_12HostSnapshotE$constprop$0
	beqz.n	a10, .L2963
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2901:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2964
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a3, a8, 0
	beqz.n	a3, .L2965
.L2964:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L2966
	addi.n	a10, a10, 1
.L2966:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L2965:
	l32i	a8, a2, 104
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	bnez.n	a8, .L2968
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1658
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2968:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	movi	a10, 0x6c8
	addmi	a9, a8, 0x400
	add.n	a10, a10, sp
	addi.n	a4, a6, 1
	s32i	a9, a10, 0
	s8i	a3, a9, 24
	s8i	a3, a9, 25
	beq	a7, a4, .L3756
	addi.n	a5, a6, 2
	bne	a5, a7, .L2970
	movi	a9, 0x4f8
	add.n	a8, a8, a9
	addx4	a8, a4, a8
	l32i	a8, a8, 0
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32r	a11, .LC1558
	l32i	a10, a9, 0
	call8	strcmp
	beqz.n	a10, .L3756
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a11, .LC1660
	l32i	a10, a8, 0
	call8	strcmp
	movi.n	a9, 4
	beqz.n	a10, .L2973
	j	.L2971
.L3757:
	movi.n	a9, 3
	j	.L2973
.L3758:
	movi.n	a9, 5
.L2973:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	s8i	a9, a8, 24
	j	.L4580
.L2971:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a11, .LC1661
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L2972
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi.n	a8, 2
	s8i	a8, a9, 24
.L4580:
	movi.n	a7, 0
.L4581:
	movi.n	a5, 0
	j	.L2969
.L2972:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a11, .LC1564
	l32i	a10, a8, 0
	call8	strcmp
	beqz.n	a10, .L3757
.L2970:
	addi.n	a6, a6, 3
	bne	a7, a6, .L2974
	movi	a6, 0x5d8
	add.n	a6, sp, a6
	addx4	a4, a4, a6
	l32i	a7, a4, 0
	l32r	a11, .LC1645
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2975
	addx4	a6, a5, a6
	l32r	a11, .LC1663
	l32i	a10, a6, 0
	call8	strcmp
	beqz.n	a10, .L3758
.L2975:
	l32r	a11, .LC1665
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L3759
	l32r	a11, .LC1667
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L2974
	movi.n	a7, 0
	movi.n	a9, 1
	j	.L2976
.L3759:
	movi.n	a7, 1
	movi.n	a9, 0
.L2976:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a6, a8, 0x400
	s8i	a9, a6, 24
	movi	a9, 0x4f8
	add.n	a8, a8, a9
	addx4	a5, a5, a8
	l32i	a5, a5, 0
	l32r	a11, .LC1451
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L4581
	l32r	a11, .LC1452
	mov.n	a10, a5
	call8	strcmp
	bnez.n	a10, .L2978
	movi.n	a8, 1
	s8i	a8, a6, 25
	j	.L4581
.L2978:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1669
	l32r	a12, .LC1658
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2974:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1658
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3756:
	movi.n	a7, 0
	movi.n	a5, 1
.L2969:
	movi	a9, 0xe0
	add.n	a10, sp, a9
	movi	a12, 0x8c
	movi.n	a11, 0
	call8	memset
	l32r	a8, .LC1579
	mov.n	a9, a10
	s32i	a8, sp, 244
	s32i	a8, sp, 252
	s32i	a8, sp, 260
	movi.n	a10, 1
	addmi	a8, sp, 0x100
	s8i	a10, a8, 12
	movi.n	a8, 1
	s32i	a8, sp, 272
	movi.n	a8, 0x14
	s32i	a8, sp, 320
	l32r	a8, .LC1620
	movi	a11, 0x418
	s32i	a8, sp, 328
	l32r	a8, .LC1621
	movi.n	a6, 0
	s32i	a8, sp, 332
	s32i	a8, sp, 336
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	add.n	a11, a9, a11
	l32i	a10, a2, 0
	l32i	a8, a8, 0
	movnez	a11, a6, a5
	mov.n	a12, a9
	callx8	a8
	s32i	a6, sp, 888
	movi	a6, 0x124
	add.n	a6, a2, a6
	beqz.n	a10, .L3761
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a15, .LC1441
	s32i	a10, a8, 0
	j	.L2981
.L3761:
	l32r	a8, .LC1450
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32r	a15, .LC1440
	s32i	a8, a9, 0
.L2981:
	movi	a9, 0x6c0
	movi.n	a8, -1
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	bnez.n	a5, .L2982
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 24
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L2982:
	l32r	a9, .LC1441
	movi	a10, 0x6c8
	add.n	a10, a10, sp
	l8ui	a8, sp, 232
	s32i	a9, a10, 0
	beqz.n	a8, .L2983
	l32r	a8, .LC1440
	s32i	a8, a10, 0
.L2983:
	l8ui	a8, sp, 233
	l32r	a14, .LC1441
	beqz.n	a8, .L2984
	l32r	a14, .LC1440
.L2984:
	l8ui	a9, sp, 234
	l32r	a8, .LC1441
	beqz.n	a9, .L2985
	l32r	a8, .LC1440
.L2985:
	l8ui	a10, sp, 235
	l32r	a9, .LC1441
	beqz.n	a10, .L2986
	l32r	a9, .LC1440
.L2986:
	l8ui	a11, sp, 239
	l32r	a10, .LC1441
	beqz.n	a11, .L2987
	l32r	a10, .LC1440
.L2987:
	l8ui	a11, sp, 240
	movi	a12, 0x6d0
	add.n	a12, a12, sp
	s32i	a11, a12, 0
	l8ui	a12, sp, 236
	l32r	a11, .LC1441
	beqz.n	a12, .L2988
	l32r	a11, .LC1440
.L2988:
	l8ui	a13, sp, 237
	l32r	a12, .LC1441
	beqz.n	a13, .L2989
	l32r	a12, .LC1440
.L2989:
	l8ui	a13, sp, 238
	s32i	a11, sp, 32
	movi	a11, 0x6d0
	s32i	a13, sp, 40
	s32i	a12, sp, 36
	add.n	a11, a11, sp
	l32i	a11, a11, 0
	s32i	a8, sp, 16
	movi	a8, 0x6c8
	s32i	a11, sp, 28
	s32i	a10, sp, 24
	s32i	a9, sp, 20
	s32i	a14, sp, 12
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a4, 0xe0
	s32i	a8, sp, 8
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	add.n	a4, sp, a4
	s32i	a8, sp, 4
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a12, 0x298
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32r	a13, .LC1671
	l32r	a11, .LC1602
	add.n	a12, a4, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a5, .L2990
	bnez.n	a7, .L2991
	addmi	a4, a4, 0x400
	l8ui	a8, a4, 24
	bnei	a8, 1, .L2990
.L2991:
	beqz.n	a10, .L2993
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 25
	beqz.n	a8, .L3770
	l32r	a14, .LC1452
	movi.n	a15, 0x41
	j	.L2994
.L3770:
	l32r	a14, .LC1451
	movi.n	a15, 0x42
.L2994:
	movi	a12, 0x378
	l32r	a13, .LC1673
	l32r	a11, .LC1602
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L4582:
	beqz.n	a10, .L2993
	l32r	a13, .LC1675
	l32r	a11, .LC1602
	movi	a12, 0x378
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a3, a10
	j	.L2993
.L2990:
	beqz.n	a10, .L2993
	l32r	a13, .LC1504
	l32r	a11, .LC1602
	movi	a12, 0x378
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L4582
.L2993:
	l32i	a13, sp, 228
	beqz.n	a13, .L2997
	bnez.n	a3, .L2998
.L2999:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1658
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L2998:
	addmi	a8, a13, 0x400
	l32i	a8, a8, 188
	movi	a15, 0x3e8
	s32i	a8, sp, 4
	movi	a8, 0x4b0
	add.n	a8, a13, a8
	movi	a14, 0x340
	movi	a12, 0x378
	l32r	a11, .LC1602
	s32i	a8, sp, 0
	add.n	a15, a13, a15
	add.n	a14, a13, a14
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe19persistenceSnapshotEPcjRjRKN14MotorControlRS6ESS_RS17ConfigObservationERKNS4_19IdentityObservationERKNS4_16StateObservationERKNS3_17ActiveSerialTupleEm
.L4583:
	beqz.n	a10, .L2999
	movi	a5, 0xe0
	add.n	a5, sp, a5
	movi	a7, 0x298
	add.n	a7, a5, a7
	l32r	a13, .LC1677
	l32r	a11, .LC1602
	mov.n	a12, a7
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2999
	j	.L3000
.L2997:
	beqz.n	a3, .L2999
	l32r	a13, .LC1504
	l32r	a11, .LC1602
	movi	a12, 0x378
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L4583
.L3000:
	l32i	a13, sp, 224
	l32r	a11, .LC1602
	mov.n	a12, a7
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe18persistenceContextEPcjRjPKN14MotorControlRS6ESS_RS18PersistenceContextE
	beqz.n	a10, .L2999
	l32r	a13, .LC1679
	l32r	a11, .LC1602
	mov.n	a12, a7
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2999
	l32r	a11, .LC1602
	addi	a13, a5, 36
	mov.n	a12, a7
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	beqz.n	a10, .L2999
	addmi	a8, sp, 0x100
	l8ui	a9, a8, 12
	l32r	a7, .LC1441
	beqz.n	a9, .L3002
	l32r	a7, .LC1440
.L3002:
	l8ui	a9, a8, 13
	l32r	a5, .LC1441
	beqz.n	a9, .L3003
	l32r	a5, .LC1440
.L3003:
	l8ui	a10, a8, 84
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111hostFailureENS0_11HostFailureE
	l32i	a8, sp, 276
	movi	a12, 0x378
	s32i	a8, sp, 4
	l32i	a8, sp, 272
	l32r	a13, .LC1681
	l32r	a11, .LC1602
	s32i	a10, sp, 8
	s32i	a8, sp, 0
	mov.n	a15, a5
	mov.n	a14, a7
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L2999
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2902:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3004
	l32r	a8, .LC1598
	movi	a9, 0x6b8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	beqz.n	a8, .L3005
.L3004:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3006
	addi.n	a10, a10, 1
.L3006:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3005:
	l32i	a8, a2, 100
	bnez.n	a8, .L3008
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3008:
	movi	a9, 0x6b8
	movi	a8, 0xe0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	add.n	a8, sp, a8
	addmi	a4, a8, 0x200
	s8i	a9, a4, 152
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addi.n	a5, a6, 1
	s8i	a9, a4, 154
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	s16i	a9, a4, 156
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	s16i	a9, a4, 158
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	s16i	a9, a4, 160
	movi.n	a9, 1
	s8i	a9, a4, 162
	beq	a7, a5, .L3774
	movi	a10, 0x6c0
	addi.n	a9, a6, 2
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	bne	a9, a7, .L3010
	movi	a9, 0x4f8
	add.n	a8, a8, a9
	addx4	a8, a5, a8
	l32i	a3, a8, 0
	l32r	a11, .LC1558
	mov.n	a10, a3
	call8	strcmp
	beqz.n	a10, .L3774
	l32r	a11, .LC1564
	mov.n	a10, a3
	call8	strcmp
	bnez.n	a10, .L3010
	movi.n	a8, 6
	s8i	a8, a4, 152
	j	.L4584
.L3010:
	addi.n	a4, a6, 3
	bne	a4, a7, .L3011
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a5, a8
	l32i	a8, a8, 0
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	l32r	a11, .LC1645
	mov.n	a10, a8
	s32i	a8, a9, 0
	call8	strcmp
	mov.n	a3, a10
	beqz.n	a10, .L3012
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32r	a11, .LC1685
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3011
.L3012:
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a9, a8
	l32i	a7, a8, 0
	l32r	a11, .LC1663
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L3013
	l32r	a11, .LC1687
	mov.n	a10, a7
	call8	strcmp
	movi.n	a8, 3
	movi.n	a9, 5
	movnez	a8, a9, a3
	beqz.n	a10, .L3690
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1689
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3690:
	movi	a9, 0x2e0
	add.n	a9, sp, a9
	s8i	a8, a9, 152
.L4584:
	movi.n	a3, 0
	movi.n	a4, 0
	movi.n	a5, 0
	j	.L3009
.L3011:
	movi	a9, 0x6d0
	addi.n	a8, a6, 4
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	beq	a8, a7, .L3015
	addi.n	a8, a6, 5
	bne	a7, a8, .L3016
.L3015:
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a5, a5, a8
	l32i	a5, a5, 0
	l32r	a11, .LC1665
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L3775
	l32r	a11, .LC1667
	mov.n	a10, a5
	call8	strcmp
	bnez.n	a10, .L3016
	movi	a9, 0x6c8
	movi.n	a8, 0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi.n	a8, 1
	j	.L3017
.L3775:
	movi	a9, 0x6c8
	movi.n	a8, 1
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi.n	a8, 0
.L3017:
	movi	a9, 0xe0
	add.n	a9, sp, a9
	addmi	a10, a9, 0x200
	s8i	a8, a10, 152
	movi	a12, 0x298
	mov.n	a10, a9
	movi.n	a11, 0
	call8	memset
	mov.n	a9, a10
	movi.n	a10, 0x14
	l32r	a8, .LC1579
	s32i	a10, sp, 300
	l32r	a10, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a10, sp, 308
	movi.n	a8, 1
	l32r	a10, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a10, sp, 312
	s32i	a10, sp, 316
	addmi	a5, sp, 0x100
	s8i	a8, a5, 88
	l32r	a8, .LC1457
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	beqz.n	a8, .L3019
	l32i	a10, a2, 0
	mov.n	a11, a9
	callx8	a8
.L3019:
	movi	a9, 0xe0
	add.n	a9, sp, a9
	l8ui	a8, a5, 88
	addmi	a3, a9, 0x200
	movi	a10, 0x6c0
	s8i	a8, a3, 162
	add.n	a10, a10, sp
	addmi	a8, a9, 0x400
	s32i	a8, a10, 0
	movi	a5, 0x4f8
	addmi	a10, a9, 0x400
	movi.n	a8, 0
	s32i	a8, a10, 24
	add.n	a5, a9, a5
	addi.n	a8, a6, 2
	addx4	a8, a8, a5
	l32i	a8, a8, 0
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a10, a9, 0
	l32r	a11, .LC1690
	call8	strcmp
	movi	a9, 0xe0
	mov.n	a8, a10
	add.n	a9, a9, sp
	bnez.n	a10, .L3020
	movi	a10, 0x6b8
	add.n	a10, a10, sp
	addx4	a5, a4, a5
	s32i	a8, a10, 0
	movi	a11, 0x418
	l32i	a10, a5, 0
	add.n	a11, a9, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3021
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a10, 0xf6
	l32i	a4, a8, 24
	addi.n	a9, a4, -1
	bltu	a10, a9, .L3021
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	extui	a4, a4, 0, 16
	s8i	a8, a3, 154
	s16i	a4, a3, 156
	movi.n	a5, 0x13
	j	.L3022
.L3021:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3020:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a11, .LC1648
	l32i	a10, a8, 0
	call8	strcmp
	movi	a9, 0xe0
	add.n	a9, a9, sp
	bnez.n	a10, .L3024
	addx4	a5, a4, a5
	movi	a11, 0x418
	l32i	a10, a5, 0
	add.n	a11, a9, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3025
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a9, .LC1579
	l32i	a8, a8, 24
	movi.n	a4, 1
	sub	a9, a8, a9
	moveqz	a4, a9, a9
	movi.n	a9, 0x4b
	slli	a9, a9, 9
	beq	a8, a9, .L3029
	beqz.n	a4, .L3029
	addmi	a9, a8, -0x4b00
	beqz.n	a9, .L3028
	movi.n	a9, 0x4b
	slli	a9, a9, 7
	beq	a8, a9, .L3028
.L3025:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1696
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3028:
	movi.n	a9, 0x4b
	slli	a9, a9, 8
	movi.n	a4, 3
	bne	a8, a9, .L3029
	movi.n	a4, 2
.L3029:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	movi.n	a9, 1
	s8i	a9, a8, 154
	s16i	a4, a8, 158
	movi.n	a5, 0x14
	j	.L3022
.L3024:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a11, .LC1697
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3030
	addx4	a4, a4, a5
	movi	a9, 0xe0
	movi	a11, 0x488
	add.n	a9, a9, sp
	l32i	a10, a4, 0
	add.n	a11, a9, a11
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111parseFormatEPKcRNS_10HostFormatE
	bnez.n	a10, .L3031
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1699
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3031:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a5, 0x15
	l8ui	a4, a8, 136
	movi.n	a8, 2
	s8i	a8, a3, 154
	s16i	a4, a3, 160
	j	.L3022
.L3030:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1701
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3022:
	addi.n	a6, a6, 5
	bne	a7, a6, .L3032
	movi	a9, 0x6d0
	movi	a8, 0xe0
	add.n	a9, a9, sp
	add.n	a7, sp, a8
	l32i	a9, a9, 0
	movi	a8, 0x4f8
	add.n	a8, a7, a8
	addx4	a8, a9, a8
	movi	a11, 0x418
	l32i	a10, a8, 0
	add.n	a11, a7, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3033
	addmi	a8, a7, 0x400
	l32i	a9, a8, 24
	movi	a10, 0xf6
	addi.n	a8, a9, -1
	bltu	a10, a8, .L3033
	addmi	a8, a7, 0x200
	s8i	a9, a8, 162
	j	.L3032
.L3033:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3032:
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	movi.n	a3, 0
	s32i	a8, a9, 0
	j	.L3009
.L3016:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3774:
	movi.n	a4, 0
	movi.n	a5, 0
	movi.n	a3, 1
.L3009:
	movi	a12, 0xe0
	add.n	a7, sp, a12
	movi.n	a11, 0
	movi	a12, 0x80
	mov.n	a10, a7
	call8	memset
	l32r	a8, .LC1579
	addmi	a6, sp, 0x100
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a8, sp, 248
	movi.n	a8, 1
	s8i	a8, a6, 0
	movi.n	a8, 1
	s32i	a8, sp, 260
	movi.n	a8, 0x14
	s32i	a8, sp, 308
	l32r	a8, .LC1620
	movi	a11, 0x298
	s32i	a8, sp, 316
	l32r	a8, .LC1621
	add.n	a11, a7, a11
	s32i	a8, sp, 320
	s32i	a8, sp, 324
	l32i	a9, a2, 100
	movi.n	a8, 0
	l32i	a10, a2, 0
	mov.n	a12, a7
	movnez	a11, a8, a3
	callx8	a9
	addmi	a12, a7, 0x400
	movi.n	a8, 0
	movi	a7, 0x124
	s32i	a8, a12, 24
	add.n	a7, a2, a7
	beqz.n	a10, .L3778
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	l32r	a15, .LC1441
	j	.L3036
.L3778:
	l32r	a15, .LC1440
	l32r	a10, .LC1450
.L3036:
	movi.n	a8, -1
	bnez.n	a3, .L3037
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 152
.L3037:
	l8ui	a11, sp, 228
	l32r	a9, .LC1441
	beqz.n	a11, .L3038
	l32r	a9, .LC1440
.L3038:
	l8ui	a12, sp, 229
	l32r	a11, .LC1441
	beqz.n	a12, .L3039
	l32r	a11, .LC1440
.L3039:
	l8ui	a12, sp, 230
	l32r	a13, .LC1441
	beqz.n	a12, .L3040
	l32r	a13, .LC1440
.L3040:
	s32i	a8, sp, 4
	movi	a8, 0x6b0
	s32i	a13, sp, 16
	s32i	a11, sp, 12
	s32i	a10, sp, 0
	add.n	a8, a8, sp
	s32i	a9, sp, 8
	movi	a3, 0xe0
	l32i	a14, a8, 0
	l32r	a13, .LC1703
	l32r	a11, .LC1602
	add.n	a3, sp, a3
	movi	a12, 0x418
	add.n	a12, a3, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L3041
	addmi	a3, a3, 0x200
	l8ui	a8, a3, 152
	movi	a12, 0x4f8
	add.n	a12, a12, sp
	bnei	a8, 1, .L3042
.L3041:
	bnez.n	a10, .L3043
.L3045:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1683
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3043:
	movi	a3, 0x2e0
	add.n	a3, sp, a3
	l8ui	a10, a3, 154
	call8	_ZN21MotorControlRSExample5Probe18communicationFieldEN14MotorControlRS6ESS_RS18CommunicationFieldE
	movi.n	a8, 0x13
	l8ui	a15, a3, 162
	mov.n	a14, a10
	bne	a5, a8, .L3783
	l32r	a9, .LC1453
	l32r	a8, .LC1454
	l32r	a10, .LC1456
	j	.L3044
.L3783:
	l32r	a9, .LC1454
	l32r	a8, .LC1453
	l32r	a10, .LC1457
.L3044:
	movi	a12, 0x4f8
	l32r	a13, .LC1705
	l32r	a11, .LC1602
	s32i	a10, sp, 16
	s32i	a9, sp, 12
	s32i	a8, sp, 8
	s32i	a4, sp, 4
	s32i	a5, sp, 0
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
.L4585:
	beqz.n	a10, .L3045
	movi	a4, 0xe0
	add.n	a4, sp, a4
	movi	a5, 0x418
	add.n	a5, a4, a5
	l32r	a13, .LC1677
	l32r	a11, .LC1602
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3045
	j	.L3046
.L3042:
	beqz.n	a10, .L3045
	l32r	a13, .LC1504
	l32r	a11, .LC1602
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	j	.L4585
.L3046:
	l32i	a13, sp, 224
	l32r	a11, .LC1602
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe20communicationContextEPcjRjPKN14MotorControlRS6ESS_RS20CommunicationContextE
	beqz.n	a10, .L3045
	l32r	a13, .LC1679
	l32r	a11, .LC1602
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3045
	l32r	a11, .LC1602
	addi	a13, a4, 24
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19hostTupleEPcjRjRKNS_9HostTupleE
	beqz.n	a10, .L3045
	addmi	a8, sp, 0x100
	l8ui	a9, a8, 0
	l32r	a5, .LC1441
	beqz.n	a9, .L3048
	l32r	a5, .LC1440
.L3048:
	l8ui	a8, a8, 1
	l32r	a4, .LC1441
	beqz.n	a8, .L3049
	l32r	a4, .LC1440
.L3049:
	l8ui	a10, a6, 72
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111hostFailureENS0_11HostFailureE
	l32i	a8, sp, 264
	movi	a12, 0x4f8
	s32i	a8, sp, 4
	l32i	a8, sp, 260
	l32r	a13, .LC1681
	l32r	a11, .LC1602
	s32i	a10, sp, 8
	s32i	a8, sp, 0
	mov.n	a15, a4
	mov.n	a14, a5
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3045
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2904:
	addi.n	a5, a6, 1
	bgeu	a5, a7, .L3050
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a5, a8
	l32r	a11, .LC1634
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3050
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2894
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2894
	movi.n	a8, 0x21
	movi.n	a10, 3
	bne	a3, a8, .L3051
	movi.n	a10, 4
.L3051:
	addi.n	a8, a6, 3
	bgeu	a8, a7, .L3052
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115readCommandNameEN14MotorControlRS6ESS_RS8ReadKindE
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a10
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3052:
	movi.n	a13, 0
	bne	a8, a7, .L3053
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32i	a13, a8, 8
.L3053:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a12, a10
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console13parameterReadEmN14MotorControlRS6ESS_RS8ReadKindEPKc
	j	.L2775
.L3050:
	movi.n	a8, 0x21
	bne	a3, a8, .L2898
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3054
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3055
.L3054:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3056
	addi.n	a10, a10, 1
.L3056:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3055:
	bgeu	a5, a7, .L3058
	movi	a3, 0xe0
	movi	a4, 0x4f8
	add.n	a3, sp, a3
	movi	a9, 0x6b8
	add.n	a8, a3, a4
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a9, 0x6c0
	addx4	a8, a5, a8
	l32i	a8, a8, 0
	add.n	a9, a9, sp
	l32r	a11, .LC1625
	mov.n	a10, a8
	s32i	a8, a9, 0
	call8	strcmp
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	mov.n	a4, a10
	bnez.n	a10, .L3059
	addi.n	a6, a6, 2
	beq	a7, a6, .L3060
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3060:
	l32i	a6, a2, 60
	bnez.n	a6, .L3062
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3062:
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, a3
	call8	memset
	movi.n	a8, 0x23
	s16i	a8, sp, 244
	l32i	a10, a2, 0
	movi.n	a8, 7
	addmi	a7, a3, 0x400
	movi	a12, 0x418
	s16i	a8, sp, 254
	s8i	a4, a7, 24
	add.n	a12, a3, a12
	mov.n	a11, a3
	callx8	a6
	mov.n	a8, a10
	s32i	a4, sp, 888
	movi	a10, 0x124
	add.n	a10, a2, a10
	beqz.n	a8, .L3788
	l8ui	a8, a7, 24
	l32r	a15, .LC1440
	beqz.n	a8, .L3789
	j	.L4586
.L3788:
	l32r	a15, .LC1441
.L4586:
	mov.n	a8, a15
	j	.L3064
.L3789:
	l32r	a8, .LC1441
.L3064:
	l32i	a9, sp, 224
	movi	a11, 0x6b8
	add.n	a11, a11, sp
	s32i	a9, a11, 0
	l8ui	a9, sp, 228
	movi	a11, 0x6c0
	add.n	a11, a11, sp
	l32i	a4, sp, 288
	l32i	a5, sp, 292
	s32i	a9, a11, 0
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	s32i	a4, a9, 0
	s32i	a5, a9, 4
	l32i	a4, sp, 296
	l32i	a5, sp, 300
	movi	a9, 0x6d0
	add.n	a9, a9, sp
	s32i	a4, a9, 0
	s32i	a5, a9, 4
	l32i	a4, sp, 280
	l32i	a5, sp, 284
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	s32i	a4, a9, 0
	s32i	a5, a9, 4
	addmi	a9, sp, 0x100
	l8ui	a4, a9, 1
	l32i	a3, sp, 232
	l32i	a12, sp, 236
	l16si	a13, sp, 244
	l16ui	a14, sp, 246
	l16ui	a7, sp, 248
	l16ui	a6, sp, 250
	l8ui	a5, a9, 4
	l32r	a11, .LC1441
	beqz.n	a4, .L3065
	l32r	a11, .LC1440
.L3065:
	l8ui	a4, a9, 3
	l32r	a9, .LC1441
	beqz.n	a4, .L3066
	l32r	a9, .LC1440
.L3066:
	s32i	a9, sp, 72
	movi	a9, 0x6d8
	s32i	a11, sp, 68
	s32i	a5, sp, 64
	add.n	a9, a9, sp
	l32i	a4, a9, 0
	l32i	a5, a9, 4
	movi	a9, 0x6d0
	s32i	a4, sp, 56
	s32i	a5, sp, 60
	add.n	a9, a9, sp
	l32i	a4, a9, 0
	l32i	a5, a9, 4
	movi	a9, 0x6c8
	s32i	a4, sp, 48
	s32i	a5, sp, 52
	add.n	a9, a9, sp
	l32i	a4, a9, 0
	l32i	a5, a9, 4
	movi	a9, 0x6c0
	s32i	a13, sp, 20
	s32i	a12, sp, 16
	s32i	a4, sp, 40
	s32i	a5, sp, 44
	s32i	a6, sp, 32
	s32i	a7, sp, 28
	s32i	a14, sp, 24
	s32i	a3, sp, 12
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi	a12, 0x378
	s32i	a9, sp, 8
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	s32i	a9, sp, 4
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32r	a13, .LC1708
	l32r	a11, .LC1602
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3067
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3067:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3059:
	l32r	a11, .LC1710
	mov.n	a10, a8
	call8	strcmp
	bnez.n	a10, .L3058
	l32i	a8, a2, 52
	beqz.n	a8, .L3068
	l32i	a8, a2, 12
	bnez.n	a8, .L3069
.L3068:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1711
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3069:
	addmi	a8, a3, 0x400
	addmi	a5, a3, 0x200
	s32i	a10, a8, 136
	movi	a10, 0x98
	movi	a12, 0x88
	movi.n	a11, 0
	add.n	a10, a5, a10
	call8	memset
	movi.n	a8, 7
	s16i	a8, a5, 166
	movi	a8, 0x190
	s16i	a8, a5, 170
	movi.n	a8, 1
	s8i	a8, a5, 218
	movi.n	a8, 2
	s16i	a8, a5, 240
	addi.n	a8, a6, 3
	bne	a7, a8, .L3072
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a11, 0x488
	addx4	a4, a6, a8
	l32i	a10, a4, 8
	add.n	a11, a3, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3072
	movi	a7, 0xe0
	add.n	a7, sp, a7
	addmi	a3, a7, 0x400
	l32i	a11, a3, 136
	movi.n	a8, 0xb
	bltu	a8, a11, .L3072
	movi	a4, 0x298
	add.n	a4, a7, a4
	extui	a11, a11, 0, 16
	mov.n	a10, a4
	call8	_ZN14MotorControlRS6ESS_RS22prepareHomingAuxiliaryERNS0_13DriverRequestENS0_15HomingAuxiliaryE
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a5, a10, 0, 8
	bnez.n	a5, .L3072
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a7
	call8	memset
	movi.n	a9, 0x14
	l32r	a8, .LC1579
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a9, sp, 308
	movi.n	a8, 1
	l32r	a9, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a6, sp, 0x100
	s8i	a8, a6, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	mov.n	a11, a7
	callx8	a8
	movi.n	a12, 0
	s32i	a5, a3, 24
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	bne	a10, a8, .L3074
	l8ui	a6, a6, 88
	movi.n	a4, 1
	movi.n	a7, 0
	j	.L3075
.L3072:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1711
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3074:
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l8ui	a12, a6, 88
	l32i	a8, a2, 52
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a15, 0x418
	add.n	a15, a7, a15
	mov.n	a14, a4
	movi.n	a13, 1
	callx8	a8
	mov.n	a4, a10
	l8ui	a6, a6, 88
	movi.n	a7, 0
	bnez.n	a10, .L3075
	movi	a8, 0x6b0
	l32i	a7, a3, 24
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3075:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1711
	l32i	a11, a8, 0
	mov.n	a15, a7
	mov.n	a14, a6
	mov.n	a13, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3058:
	addi.n	a6, a6, 2
	bne	a7, a6, .L3076
	movi	a6, 0xe0
	add.n	a6, sp, a6
	movi	a8, 0x4f8
	add.n	a8, a6, a8
	addx4	a8, a5, a8
	l32r	a11, .LC1713
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3076
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	s32i	a10, sp, 224
	l32i	a13, a8, 0
	movi	a10, 0x124
	l32r	a11, .LC1602
	mov.n	a12, a6
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe11HomeConsole13formatMethodsEPcjRjm
	bnez.n	a10, .L3077
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3077:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3076:
	l32i	a8, a2, 56
	beqz.n	a8, .L3079
	l32i	a8, a2, 12
	beqz.n	a8, .L3079
	l32i	a8, a2, 136
	bnez.n	a8, .L3080
.L3079:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3080:
	movi	a4, 0xe0
	add.n	a4, sp, a4
	l32r	a11, .LC1714
	addmi	a10, a4, 0x400
	movi.n	a12, 0x18
	addi	a10, a10, 24
	call8	memcpy
	movi.n	a8, 0
	addmi	a3, a4, 0x500
	s8i	a8, a3, 112
	s8i	a8, a3, 80
	movi	a8, 0x4f8
	add.n	a8, a4, a8
	extui	a10, a5, 0, 16
	movi	a14, 0x550
	movi	a13, 0x570
	movi	a12, 0x418
	add.n	a13, a4, a13
	add.n	a14, a4, a14
	add.n	a12, a4, a12
	sub	a11, a7, a5
	addx4	a10, a10, a8
	call8	_ZN21MotorControlRSExample5Probe11HomeConsole5parseEPKPKcjRN14MotorControlRS6ESS_RS11HomeRequestERhRb
	mov.n	a13, a10
	beqz.n	a10, .L3081
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3081:
	l8ui	a8, a3, 80
	beqz.n	a8, .L3082
	l8ui	a4, a3, 112
	j	.L3083
.L3082:
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a4
	call8	memset
	movi.n	a9, 0x14
	l32r	a8, .LC1579
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a9, sp, 308
	movi.n	a8, 1
	l32r	a9, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a7, sp, 0x100
	s8i	a8, a7, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	mov.n	a11, a4
	callx8	a8
	l8ui	a4, a7, 88
.L3083:
	addi.n	a8, a4, -1
	movi	a9, 0xf6
	bgeu	a9, a8, .L3085
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3085:
	movi	a7, 0xe0
	add.n	a7, sp, a7
	addmi	a9, a7, 0x200
	movi	a8, 0x98
	add.n	a6, a9, a8
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	s32i	a9, a8, 0
	movi	a12, 0x70
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	movi	a10, 0x6c0
	movi.n	a8, 2
	add.n	a10, a10, sp
	s8i	a8, a9, 220
	s32i	a8, a10, 0
	movi	a8, 0x6b8
	movi.n	a3, 1
	movi.n	a5, 0
	movi.n	a13, 1
	add.n	a8, a8, sp
	s32i	a3, a9, 168
	s32i	a5, a9, 172
	s32i	a3, a9, 184
	s32i	a5, a9, 188
	s32i	a3, a9, 208
	s32i	a5, a9, 212
	s8i	a13, a9, 218
	s8i	a13, a9, 241
	s32i	a13, a8, 0
	movi	a12, 0x180
	movi.n	a11, 0
	mov.n	a10, a7
	call8	memset
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	movi.n	a9, 1
	s8i	a13, sp, 224
	s32i	a9, sp, 244
	s32i	a9, sp, 252
	s32i	a9, sp, 264
	s32i	a9, sp, 276
	s32i	a9, sp, 288
	s32i	a9, sp, 300
	addmi	a12, sp, 0x100
	l32r	a10, .LC1939
	s8i	a9, a12, 60
	s8i	a9, a12, 64
	s32i	a10, sp, 328
	movi.n	a10, 0
	s32i	a10, sp, 344
	l32r	a10, .LC1937
	movi	a8, 0x6c0
	s32i	a10, sp, 348
	movi.n	a10, -1
	s32i	a10, sp, 352
	l32r	a11, .LC1940
	l32r	a10, .LC1938
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a11, sp, 332
	s32i	a10, sp, 356
	s32i	a3, sp, 424
	s32i	a5, sp, 428
	s8i	a8, a12, 180
	s8i	a9, a12, 178
	s8i	a9, a12, 201
	s32i	a3, sp, 496
	s32i	a5, sp, 500
	addmi	a8, a7, 0x100
	s8i	a9, a8, 104
	l32i	a10, a2, 0
	l32i	a8, a2, 136
	mov.n	a12, a7
	mov.n	a11, a6
	callx8	a8
	addmi	a3, a7, 0x400
	s32i	a10, a3, 136
	s32i	a11, a3, 140
	s32i	a12, a3, 144
	extui	a5, a10, 0, 8
	beqz.n	a5, .L3088
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3088:
	l32i	a8, sp, 244
	movi.n	a12, 0
	s32i	a8, a3, 28
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	s32i	a5, a3, 136
	movi.n	a5, 1
	beq	a10, a8, .L3089
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 56
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a14, 0x488
	movi	a13, 0x418
	add.n	a14, a7, a14
	add.n	a13, a7, a13
	mov.n	a12, a4
	callx8	a8
	mov.n	a5, a10
	beqz.n	a10, .L3090
.L3089:
	movi.n	a7, 0
	j	.L3091
.L3090:
	movi	a8, 0x6b0
	l32i	a7, a3, 136
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3091:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1706
	l32i	a11, a8, 0
	mov.n	a15, a7
	mov.n	a14, a4
	mov.n	a13, a5
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L2898:
	addi	a8, a3, -32
	nsau	a9, a8
	movi	a10, 0x6f0
	srli	a9, a9, 5
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	addi	a9, a3, -35
	movi	a10, 0x6e0
	add.n	a10, a10, sp
	nsau	a9, a9
	s32i	a9, a10, 0
	l32i	a9, a10, 0
	movi	a10, 0x6e0
	srli	a9, a9, 5
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	addi	a9, a3, -31
	beqz.n	a9, .L3092
	movi	a9, 0x6f0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	bnez.n	a9, .L3092
	movi	a11, 0x6f0
	add.n	a11, a11, sp
	l32i	a11, a11, 0
	addi	a10, a3, -34
	movi.n	a9, 1
	movnez	a9, a11, a10
	movi	a10, 0x6e0
	add.n	a10, a10, sp
	l32i	a10, a10, 0
	or	a9, a10, a9
	extui	a9, a9, 0, 8
	bnez.n	a9, .L3092
	movi.n	a8, 0x24
	beq	a3, a8, .L3794
	movi.n	a8, 0x35
	bne	a3, a8, .L3094
	addi.n	a8, a6, 2
	bltu	a7, a8, .L3795
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32r	a11, .LC1720
	l32i	a10, a8, 4
	call8	strcmp
	beqz.n	a10, .L3796
	j	.L3795
.L3092:
	extui	a8, a8, 0, 8
	movi.n	a9, 0x15
	l32r	a4, .LC1459
	bltu	a9, a8, .L3093
	j	.L3096
.L3796:
	movi.n	a8, 0x15
.L3096:
	l32r	a9, .LC1721
	addx4	a8, a8, a9
	l32i	a4, a8, 0
	j	.L3093
.L3794:
	l32r	a4, .LC1458
.L3093:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3097
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3098
.L3097:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3099
	addi.n	a10, a10, 1
.L3099:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3098:
	movi.n	a8, 0x35
	bne	a3, a8, .L3101
	addi.n	a8, a6, 2
	bgeu	a8, a7, .L3102
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3102:
	bne	a8, a7, .L3101
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32r	a11, .LC1720
	l32i	a10, a8, 4
	call8	strcmp
	bnez.n	a10, .L3101
	l8ui	a8, a2, 141
	bnez.n	a8, .L3103
	l32r	a11, .LC1723
	movi	a10, 0x124
	add.n	a10, a2, a10
	call8	strcpy
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3103:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	l32r	a12, .LC1725
	l32r	a11, .LC1602
	movi	a10, 0x124
	add.n	a10, a2, a10
	call8	snprintf
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3101:
	l32i	a8, a2, 52
	beqz.n	a8, .L3104
	l32i	a8, a2, 12
	bnez.n	a8, .L3105
.L3104:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3105:
	addi.n	a5, a6, 1
	bltu	a5, a7, .L3106
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3106:
	movi	a8, 0xe0
	add.n	a13, sp, a8
	movi	a8, 0x6b8
	addmi	a14, a13, 0x200
	add.n	a8, a8, sp
	movi	a10, 0x98
	s32i	a14, a8, 0
	add.n	a10, a14, a10
	movi	a12, 0x88
	movi.n	a11, 0
	call8	memset
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a14, a9, 0
	movi.n	a8, 7
	s16i	a8, a14, 166
	movi	a8, 0x190
	movi.n	a9, 2
	s16i	a8, a14, 170
	movi.n	a8, 1
	s16i	a9, a14, 240
	movi	a13, 0xe0
	s8i	a8, a14, 218
	movi.n	a9, 0x23
	add.n	a13, a13, sp
	bne	a3, a9, .L3108
	movi.n	a8, 5
	j	.L4587
.L3108:
	bnei	a3, 32, .L3110
.L4587:
	s8i	a8, a14, 152
	j	.L3114
.L3110:
	movi.n	a8, 0x24
	bne	a3, a8, .L3111
	addi.n	a8, a6, 3
	bltu	a7, a8, .L3112
	movi	a8, 0x4f8
	add.n	a8, a13, a8
	addx4	a8, a5, a8
	l32i	a5, a8, 0
	l32r	a11, .LC1727
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L3798
	l32r	a11, .LC1729
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L3799
	l32r	a11, .LC1731
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L3800
	l32r	a11, .LC1733
	mov.n	a10, a5
	call8	strcmp
	movi.n	a8, 9
	beqz.n	a10, .L3113
	j	.L3112
.L3798:
	movi.n	a8, 6
	j	.L3113
.L3799:
	movi.n	a8, 7
	j	.L3113
.L3800:
	movi.n	a8, 8
.L3113:
	movi	a9, 0x2e0
	add.n	a9, sp, a9
	s8i	a8, a9, 152
	addi.n	a5, a6, 2
	j	.L3114
.L3112:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1735
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3111:
	movi.n	a8, 0x22
	bne	a3, a8, .L3114
	addi.n	a8, a6, 4
	bgeu	a7, a8, .L3115
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3115:
	movi	a8, 0x4f8
	add.n	a8, a13, a8
	addx4	a8, a5, a8
	l32i	a5, a8, 0
	l32r	a11, .LC1737
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L3801
	l32r	a11, .LC1738
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L3802
	l32r	a11, .LC1739
	mov.n	a10, a5
	call8	strcmp
	movi.n	a8, 4
	beqz.n	a10, .L3117
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1741
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3801:
	movi.n	a8, 2
	j	.L3117
.L3802:
	movi.n	a8, 3
.L3117:
	movi	a11, 0xe0
	add.n	a11, sp, a11
	addmi	a5, a11, 0x200
	s8i	a8, a5, 152
	movi.n	a8, 0
	s32i	a8, sp, 224
	addx4	a8, a6, a11
	addmi	a8, a8, 0x500
	l32i	a10, a8, 0
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3118
	l32i	a8, sp, 224
	movi.n	a10, 0xf
	addi.n	a9, a8, -1
	bltu	a10, a9, .L3118
	s8i	a8, a5, 218
	addi.n	a5, a6, 3
	j	.L3114
.L3118:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1743
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3114:
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a5, a8
	l32i	a8, a8, 0
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32r	a11, .LC1634
	mov.n	a10, a8
	s32i	a8, a9, 0
	call8	strcmp
	mov.n	a6, a10
	beqz.n	a10, .L3119
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	l32r	a11, .LC1653
	call8	strcmp
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	addi.n	a8, a5, 1
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a9, 0x6d8
	sub	a8, a7, a8
	extui	a8, a8, 0, 1
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	beqz.n	a10, .L3121
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3119:
	movi	a9, 0x6c0
	addi.n	a8, a5, 1
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	addi.n	a8, a5, 2
	sub	a8, a8, a7
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	nsau	a8, a8
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a9, 0x6d8
	srli	a8, a8, 5
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L3121:
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addmi	a9, sp, 0x700
	sub	a8, a7, a8
	s32i	a8, a9, 0
	movi.n	a8, 1
	movi	a9, 0x710
	moveqz	a8, a6, a6
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a9, 0x6c0
	addmi	a8, sp, 0x700
	add.n	a9, a9, sp
	l32i	a8, a8, 0
	l32i	a9, a9, 0
	sub	a9, a8, a9
	movi.n	a8, 1
	moveqz	a8, a9, a9
	movi	a9, 0x710
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	beq	a8, a9, .L3122
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3122:
	movi	a9, 0xe0
	add.n	a9, sp, a9
	movi.n	a8, 0
	addmi	a7, a9, 0x500
	s32i	a8, a7, 196
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L3123
.L3127:
	movi	a9, 0xe0
	add.n	a5, sp, a9
	addmi	a6, a5, 0x400
	movi	a7, 0x88
	l32r	a11, .LC1745
	add.n	a7, a6, a7
	movi.n	a12, 0x24
	mov.n	a10, a7
	call8	memcpy
	l32r	a11, .LC1747
	movi.n	a12, 0x24
	addi	a10, a6, 24
	call8	memcpy
	l32r	a8, .LC1749
	addmi	a10, a5, 0x500
	l32i	a11, a8, 0
	movi	a6, 0x98
	add.n	a6, a10, a6
	l32i	a12, a8, 4
	s32i	a11, a6, 0
	l32i	a11, a8, 8
	l32i	a8, a8, 12
	s32i	a11, a6, 8
	s32i	a8, a6, 12
	l32r	a8, .LC1751
	l32r	a11, .LC1753
	s32i	a8, a10, 192
	s32i	a12, a6, 4
	addi	a10, a10, 80
	movi.n	a12, 0x20
	call8	memcpy
	addmi	a8, a5, 0x200
	l8ui	a8, a8, 152
	movi	a9, 0x6d0
	add.n	a9, a9, sp
	movi	a10, 0x550
	s32i	a8, a9, 0
	add.n	a9, a5, a10
	movi	a10, 0x6c8
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	movi	a10, 0x6b8
	movi.n	a9, 8
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	movi.n	a8, 0x23
	movi.n	a9, 0x24
	bne	a3, a8, .L4562
	j	.L3124
.L3123:
	addmi	a10, sp, 0x700
	l32i	a10, a10, 0
	movi	a8, 0x4f8
	add.n	a8, a9, a8
	addx4	a8, a10, a8
	movi	a11, 0x5c4
	l32i	a10, a8, 0
	add.n	a11, a9, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3126
	l32i	a8, a7, 196
	movi	a9, 0xf6
	addi.n	a8, a8, -1
	bgeu	a9, a8, .L3127
.L3126:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L4562:
	movi.n	a8, 0x22
	bne	a3, a8, .L3128
	movi	a8, 0x5c0
	movi	a9, 0x6c8
	add.n	a8, a5, a8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a9, 0x6b8
	movi.n	a8, 1
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnei	a8, 4, .L4563
	j	.L3124
.L3128:
	movi	a8, 0x418
	movi	a10, 0x6c8
	add.n	a8, a5, a8
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	movi	a10, 0x6b8
	movi.n	a8, 9
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	beqi	a3, 32, .L3124
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a7, a8, 0
	bne	a3, a9, .L3124
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	call8	_ZN14MotorControlRS6ESS_RS16tuningFieldCountENS0_11DriverGroupE
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	s32i	a10, a8, 0
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a7, a8, 0
.L3124:
	addi	a8, a3, -36
	movi	a9, 0x6f8
	add.n	a9, a9, sp
	nsau	a8, a8
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a9, 0x6f8
	srli	a8, a8, 5
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a9, 0x6c0
	movi	a7, 0xe0
	add.n	a9, a9, sp
	l16ui	a9, a9, 0
	add.n	a7, sp, a7
	movi	a8, 0x4f8
	add.n	a8, a7, a8
	addx4	a8, a9, a8
	movi	a9, 0x6e8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a9, 0x708
	addmi	a8, a7, 0x500
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	addi	a8, a8, 112
	movi	a9, 0x720
	j	.L4592
.L3817:
	movi.n	a6, 0
	movi.n	a5, 0
.L3139:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	beq	a5, a8, .L3131
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x718
	l32i	a8, a8, 0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi.n	a9, 0x24
	bne	a3, a9, .L3132
	addmi	a9, a7, 0x200
	l8ui	a14, a9, 152
	movi	a8, 0x728
	add.n	a8, a8, sp
	s32i	a14, a8, 0
	movi	a8, 0x720
	add.n	a8, a8, sp
	l32r	a11, .LC1755
	l32i	a10, a8, 0
	movi.n	a12, 0x18
	call8	memcpy
	movi	a8, 0x708
	l32r	a10, .LC1757
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a11, a10, 0
	movi	a9, 0x88
	add.n	a9, a8, a9
	s32i	a11, a9, 0
	l32i	a11, a10, 8
	l32i	a12, a10, 4
	movi	a8, 0x730
	l32i	a10, a10, 12
	s32i	a11, a9, 8
	add.n	a8, a8, sp
	l32r	a11, .LC1759
	s32i	a12, a9, 4
	s32i	a10, a9, 12
	s32i	a9, a8, 0
	movi.n	a12, 0x20
	mov.n	a10, a7
	call8	memcpy
	movi	a8, 0x708
	add.n	a8, a8, sp
	l32r	a10, .LC1760
	l32i	a8, a8, 0
	s32i	a10, a8, 184
	movi	a8, 0x708
	add.n	a8, a8, sp
	l32r	a10, .LC1526
	l32i	a8, a8, 0
	s32i	a10, a8, 188
	movi	a8, 0x728
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	call8	_ZN14MotorControlRS6ESS_RS16tuningFieldCountENS0_11DriverGroupE
	l32r	a11, .LC1457
	bgeu	a5, a10, .L3137
	movi	a8, 0x728
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	movi	a8, 0x730
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	bnei	a14, 6, .L3134
	movi	a9, 0x570
	j	.L4604
.L3134:
	bnei	a14, 7, .L3135
	j	.L4603
.L3135:
	add.n	a9, a7, a6
	beqi	a14, 8, .L4588
.L3136:
	movi	a9, 0x5b8
.L4604:
	add.n	a9, a7, a9
.L4603:
	add.n	a9, a9, a6
	j	.L4588
.L3132:
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	add.n	a9, a8, a6
.L4588:
	l32i	a11, a9, 0
.L3137:
	movi	a8, 0x718
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	addi.n	a6, a6, 4
	call8	strcmp
	beqz.n	a10, .L3138
	addi.n	a5, a5, 1
	j	.L3139
.L4576:
	movi.n	a9, 0x23
	bne	a3, a9, .L3141
	addi	a9, a5, 23
	j	.L4589
.L3141:
	movi.n	a9, 0x22
	bne	a3, a9, .L3142
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a6, 1
	slli	a6, a6, 21
	beqi	a8, 4, .L3140
	movi.n	a6, 1
	slli	a6, a6, 22
	addi	a9, a5, 18
	bnei	a5, 3, .L4589
	j	.L3140
.L3142:
	movi.n	a9, 0
	bnei	a3, 32, .L3143
	movi.n	a9, 9
.L3143:
	add.n	a9, a5, a9
.L4589:
	movi.n	a6, 1
	ssl	a9
	sll	a6, a6
.L3140:
	l32i	a9, a7, 668
	bnone	a6, a9, .L3144
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1762
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3144:
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a12, a8, 4
	bnei	a3, 32, .L3146
	movi	a8, 0x718
	add.n	a8, a8, sp
	l32r	a11, .LC1637
	s32i	a12, a8, 0
	mov.n	a10, a12
	call8	strcmp
	movi	a8, 0x718
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	bnez.n	a10, .L3146
	bgeui	a5, 5, .L3147
	beqz.n	a5, .L4557
	j	.L4590
.L3147:
	addi	a9, a5, -6
	bgeui	a9, 2, .L3146
.L4590:
	l32r	a12, .LC1463
.L3146:
	bnez.n	a5, .L3148
.L4557:
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	beqz.n	a8, .L3148
	movi	a8, 0x718
	add.n	a8, a8, sp
	l32r	a11, .LC1764
	mov.n	a10, a12
	s32i	a12, a8, 0
	call8	strcmp
	l32r	a12, .LC1467
	beqz.n	a10, .L3148
	movi	a8, 0x718
	add.n	a8, a8, sp
	l32r	a11, .LC1766
	l32i	a10, a8, 0
	call8	strcmp
	l32r	a12, .LC1465
	beqz.n	a10, .L3148
	movi	a8, 0x718
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	j	.L3148
.L3148:
	movi.n	a9, 0
	s32i	a9, sp, 224
	s32i	a9, sp, 228
	movi.n	a9, 1
	s32i	a9, sp, 232
	movi.n	a9, 0
	s32i	a9, sp, 236
	l8ui	a11, a12, 0
	movi.n	a9, 0x2d
	mov.n	a10, a12
	bne	a11, a9, .L3149
	addi.n	a10, a12, 1
.L3149:
	l8ui	a9, a10, 0
	beqz.n	a9, .L4564
	movi.n	a11, 9
	j	.L3150
.L4564:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1769
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3152:
	addi	a9, a9, -48
	extui	a9, a9, 0, 8
	bgeu	a11, a9, .L3151
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1769
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3151:
	addi.n	a10, a10, 1
.L3150:
	l8ui	a9, a10, 0
	bnez.n	a9, .L3152
	movi	a9, 0xe0
	add.n	a11, sp, a9
	mov.n	a10, a12
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	movi	a9, 0xe0
	add.n	a9, a9, sp
	addmi	a9, a9, 0x500
	s32i	a10, a9, 112
	s32i	a11, a9, 116
	s32i	a12, a9, 120
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3153
.L3154:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1769
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3153:
	l32i	a9, sp, 232
	bnei	a9, 1, .L3154
	l32i	a9, sp, 236
	bnez.n	a9, .L3154
	movi.n	a10, 0x22
	l32i	a9, sp, 224
	l32i	a11, sp, 228
	beq	a3, a10, .L3155
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L3156
	movi	a8, 0x6f8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L3156
	movi.n	a10, 6
	saltu	a10, a10, a5
	addi.n	a10, a10, -1
	neg	a10, a10
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3156
	movi	a8, 0x6f0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L3156
	j	.L4565
.L3156:
	bnez.n	a11, .L3154
	l32r	a10, .LC1770
	bltu	a10, a9, .L3154
	movi.n	a10, 0x24
	bne	a3, a10, .L4565
	j	.L3159
.L3155:
	beqi	a5, 3, .L3161
	mov.n	a10, a11
	bgez	a9, .L3162
	addi.n	a10, a11, 1
.L3162:
	beqz.n	a10, .L3161
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1769
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3161:
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	beqi	a8, 4, .L3164
	addi.n	a10, a5, -1
	bgeui	a10, 2, .L3164
	bnez.n	a11, .L4000
	l32r	a10, .LC1770
	bgeu	a10, a9, .L3164
.L4000:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1769
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3164:
	movi	a10, 0x2e0
	add.n	a10, sp, a10
	l32i	a12, a10, 156
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	or	a12, a12, a6
	l32i	a8, a8, 0
	s32i	a12, a10, 156
	bnei	a8, 4, .L3166
	s32i	a9, a10, 224
	j	.L3167
.L3166:
	bnez.n	a5, .L3168
	s32i	a9, a10, 220
	j	.L3167
.L3168:
	bnei	a5, 1, .L3169
	s16i	a9, a10, 228
	j	.L3167
.L3169:
	bnei	a5, 2, .L3170
	s16i	a9, a10, 230
	j	.L3167
.L3170:
	s32i	a9, a10, 232
	s32i	a11, a10, 236
	j	.L3167
.L3159:
	movi	a6, 0xe0
	add.n	a6, sp, a6
	addmi	a10, a6, 0x200
	movi	a8, 0x718
	add.n	a8, a8, sp
	l8ui	a10, a10, 152
	s32i	a9, a8, 0
	mov.n	a11, a5
	call8	_ZN14MotorControlRS6ESS_RS15tuningParameterENS0_11DriverGroupEh
	movi	a8, 0x718
	add.n	a8, a8, sp
	mov.n	a11, a10
	l32i	a12, a8, 0
	movi	a10, 0x298
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS18prepareTuningValueERNS0_13DriverRequestENS0_15TuningParameterEm
	addmi	a6, a6, 0x500
	s32i	a10, a6, 112
	s32i	a11, a6, 116
	s32i	a12, a6, 120
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3167
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1469
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L4565:
	movi	a10, 0xe0
	add.n	a10, sp, a10
	l32i	a14, a10, 668
	addmi	a13, a10, 0x200
	or	a14, a14, a6
	s32i	a14, a13, 156
	movi.n	a14, 0x23
	extui	a12, a9, 0, 16
	bne	a3, a14, .L3171
	bgeui	a5, 8, .L3167
	l32r	a9, .LC1772
	addx4	a8, a5, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L3173:
	.word	.L3180
	.word	.L3179
	.word	.L3178
	.word	.L3177
	.word	.L3176
	.word	.L3175
	.word	.L3174
	.word	.L3172
	.text
.L3180:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 240
	j	.L3167
.L3179:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 242
	j	.L3167
.L3178:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 244
	j	.L3167
.L3177:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 246
	j	.L3167
.L3176:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 248
	j	.L3167
.L3175:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 250
	j	.L3167
.L3174:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 252
	j	.L3167
.L3172:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 254
	j	.L3167
.L3171:
	bnei	a3, 32, .L3181
	addmi	a6, a10, 0x500
	movi.n	a9, 0
	s32i	a9, a6, 116
	l32r	a9, .LC1457
	addi.n	a11, a5, -1
	s32i	a9, a6, 120
	bgeui	a11, 4, .L3182
	movi	a8, 0x298
	add.n	a10, a10, a8
	extui	a11, a11, 0, 8
	call8	_ZN14MotorControlRS6ESS_RS20prepareInputFunctionERNS0_13DriverRequestEhNS0_13InputFunctionE
	j	.L4591
.L3182:
	addi	a11, a5, -6
	bgeui	a11, 2, .L3184
	movi	a8, 0x298
	extui	a11, a11, 0, 8
	add.n	a10, a10, a8
	call8	_ZN14MotorControlRS6ESS_RS21prepareOutputFunctionERNS0_13DriverRequestEhNS0_14OutputFunctionE
.L4591:
	s32i	a10, a6, 112
	s32i	a11, a6, 116
	s32i	a12, a6, 120
	extui	a8, a10, 0, 8
	j	.L3183
.L3184:
	bnez.n	a5, .L3185
	s16i	a12, a13, 212
	j	.L3167
.L3185:
	bnei	a5, 5, .L3187
	s16i	a12, a13, 214
	j	.L3167
.L3187:
	s16i	a12, a13, 216
	j	.L3167
.L3183:
	beqz.n	a8, .L3167
	movi	a9, 0xe0
	add.n	a9, sp, a9
	addmi	a10, a9, 0x500
	s8i	a8, a10, 112
	movi	a10, 0x570
	add.n	a10, a9, a10
	call8	_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE
	movi.n	a8, 0xd
	l32r	a13, .LC1469
	bne	a10, a8, .L3189
	l32r	a13, .LC1453
.L3189:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3181:
	movi.n	a10, 8
	bltu	a10, a5, .L3167
	l32r	a10, .LC1773
	addx4	a8, a5, a10
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L3191:
	.word	.L3199
	.word	.L3198
	.word	.L3197
	.word	.L3196
	.word	.L3195
	.word	.L3194
	.word	.L3193
	.word	.L3192
	.word	.L3190
	.text
.L3199:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 168
	j	.L3167
.L3198:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 170
	j	.L3167
.L3197:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 172
	j	.L3167
.L3196:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 174
	j	.L3167
.L3195:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 176
	j	.L3167
.L3194:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 178
	j	.L3167
.L3193:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s16i	a12, a8, 180
	j	.L3167
.L3192:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s32i	a9, a8, 184
	s32i	a11, a8, 188
	j	.L3167
.L3190:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s32i	a9, a8, 192
	s32i	a11, a8, 196
.L3167:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6c0
	addi.n	a8, a8, 2
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6e8
	addi.n	a8, a8, 8
.L4592:
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	addmi	a9, sp, 0x700
	l32i	a8, a8, 0
	l32i	a9, a9, 0
	bltu	a8, a9, .L3817
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L3200
	movi	a10, 0xe0
	add.n	a7, sp, a10
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a7
	call8	memset
	movi.n	a9, 0x14
	l32r	a8, .LC1579
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a9, sp, 308
	movi.n	a8, 1
	l32r	a9, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a6, sp, 0x100
	s8i	a8, a6, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	mov.n	a11, a7
	callx8	a8
	l8ui	a8, a6, 88
	addmi	a10, a7, 0x500
	s32i	a8, a10, 196
.L3200:
	movi	a3, 0xe0
	add.n	a3, sp, a3
	addmi	a8, a3, 0x500
	l32i	a7, a8, 196
	movi	a9, 0xf6
	addi.n	a8, a7, -1
	bgeu	a9, a8, .L3202
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3202:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0
	s32i	a8, sp, 224
	movi.n	a8, 0xf
	movi.n	a5, 1
	movi.n	a6, 0
	beq	a10, a8, .L3203
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x710
	add.n	a9, a9, sp
	l32i	a13, a9, 0
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 52
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a14, 0x298
	mov.n	a15, a3
	add.n	a14, a3, a14
	mov.n	a12, a7
	callx8	a8
	mov.n	a5, a10
	bnez.n	a10, .L3203
	movi	a8, 0x6b0
	l32i	a6, sp, 224
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3203:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a15, a6
	mov.n	a14, a7
	mov.n	a13, a5
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3094:
	movi.n	a8, 0x1e
	bne	a3, a8, .L3204
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3205
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3206
.L3205:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3207
	addi.n	a10, a10, 1
.L3207:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3206:
	l32i	a8, a2, 48
	beqz.n	a8, .L3209
	l32i	a8, a2, 12
	beqz.n	a8, .L3209
	l32i	a8, a2, 136
	bnez.n	a8, .L3210
.L3209:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3210:
	movi	a8, 0xe0
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	add.n	a8, sp, a8
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a9, 0x6b8
	addmi	a3, a8, 0x400
	movi	a8, 0x88
	add.n	a9, a9, sp
	add.n	a8, a3, a8
	s32i	a8, a9, 0
	l32i	a10, a9, 0
	movi	a12, 0x70
	movi.n	a11, 0
	call8	memset
	movi.n	a8, 1
	s32i	a8, a3, 144
	movi.n	a8, 0
	s32i	a8, a3, 148
	movi	a8, 0x103
	s16i	a8, a3, 152
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6c8
	addmi	a8, a8, 0x500
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi.n	a8, 0
	s32i	a8, a9, 136
	addi.n	a5, a6, 7
	bltu	a7, a5, .L3212
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a4, 0x4f8
	add.n	a4, a8, a4
	movi	a9, 0x6b8
	addx4	a8, a6, a4
	add.n	a9, a9, sp
	l32i	a11, a9, 0
	l32i	a10, a8, 4
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3212
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addx4	a8, a6, a4
	l32i	a10, a8, 8
	addi	a11, a9, 16
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18rateUnitEPKcRN14MotorControlRS12VelocityUnitE
	beqz.n	a10, .L3212
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addx4	a8, a6, a4
	l32i	a10, a8, 12
	addi	a11, a9, 18
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE
	beqz.n	a10, .L3212
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addx4	a8, a6, a4
	movi	a11, 0x588
	l32i	a10, a8, 16
	add.n	a11, a9, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3212
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a10, 0x6b8
	l32i	a9, a8, 136
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	addi.n	a8, a9, -1
	movi	a10, 0x3e7
	bltu	a10, a8, .L3212
	addx4	a8, a6, a4
	l32r	a11, .LC1775
	l32i	a10, a8, 20
	call8	strcmp
	bnez.n	a10, .L3212
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	addx4	a4, a6, a4
	slli	a8, a9, 5
	sub	a8, a8, a9
	addx4	a8, a8, a9
	slli	a8, a8, 3
	l32i	a4, a4, 24
	s32i	a8, a3, 236
	l32r	a11, .LC1776
	movi.n	a8, 1
	s8i	a8, a3, 192
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3820
	j	.L4566
.L3212:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L4566:
	l32r	a11, .LC1777
	mov.n	a10, a4
	call8	strcmp
	movi.n	a8, 2
	beqz.n	a10, .L3213
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1778
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3820:
	movi.n	a8, 1
.L3213:
	movi	a4, 0xe0
	add.n	a4, sp, a4
	movi	a10, 0x6b8
	addmi	a9, a4, 0x400
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	s8i	a8, a9, 240
	bgeu	a5, a7, .L3215
	movi	a8, 0x4f8
	add.n	a3, a4, a8
	addx4	a8, a5, a3
	l32r	a11, .LC1780
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3215
	addi.n	a5, a6, 10
	bltu	a7, a5, .L3216
	movi	a8, 0x488
	add.n	a4, a4, a8
	addx4	a8, a6, a3
	l32i	a10, a8, 32
	addi	a11, a4, 24
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18roundingEPKcRN14MotorControlRS8RoundingE
	beqz.n	a10, .L3216
	addx4	a8, a6, a3
	l32i	a10, a8, 36
	addi	a11, a4, 32
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3216
	bltu	a5, a7, .L3217
	j	.L3215
.L3216:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3217:
	addx4	a8, a5, a3
	l32r	a11, .LC1782
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3215
	addi.n	a8, a6, 11
	bgeu	a8, a7, .L3218
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	l8ui	a9, a9, 152
	bnei	a9, 5, .L3218
	addx4	a8, a8, a3
	l32i	a10, a8, 0
	addi	a11, a4, 48
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	addi.n	a5, a6, 12
	bnez.n	a10, .L3218
	movi	a6, 0x4e0
	add.n	a6, sp, a6
	l32i	a10, a6, 184
	l32i	a11, a6, 188
	movi.n	a12, 0
	movi.n	a13, 0
	call8	__ledf2
	blti	a10, 1, .L3218
	movi.n	a8, 1
	s8i	a8, a6, 176
	j	.L3215
.L3218:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3215:
	movi	a6, 0xe0
	add.n	a6, sp, a6
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	movi.n	a9, 0x14
	l32r	a8, .LC1579
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a9, sp, 308
	movi.n	a8, 1
	l32r	a9, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a4, sp, 0x100
	s8i	a8, a4, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	mov.n	a11, a6
	callx8	a8
	l8ui	a9, a4, 88
	addmi	a8, a6, 0x500
	s32i	a9, a8, 112
	addi.n	a8, a5, 1
	bgeu	a8, a7, .L3220
.L3222:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3220:
	bne	a8, a7, .L3221
	movi	a8, 0x4f8
	add.n	a8, a6, a8
	addx4	a5, a5, a8
	movi	a11, 0x570
	l32i	a10, a5, 0
	add.n	a11, a6, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3222
.L3221:
	movi	a5, 0xe0
	add.n	a5, sp, a5
	addmi	a4, a5, 0x500
	l32i	a8, a4, 112
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a9, 0xf6
	addi.n	a8, a8, -1
	bgeu	a9, a8, .L3223
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3223:
	addmi	a6, a5, 0x400
	movi	a12, 0x70
	movi.n	a11, 0
	addi	a10, a6, 24
	call8	memset
	movi.n	a8, 1
	s32i	a8, a6, 40
	s32i	a8, a6, 56
	s32i	a8, a6, 80
	movi	a8, 0x6c8
	movi.n	a14, 2
	add.n	a8, a8, sp
	s32i	a14, a8, 0
	movi	a8, 0x6c0
	addmi	a7, a5, 0x200
	movi.n	a3, 0
	movi.n	a13, 1
	add.n	a8, a8, sp
	movi	a9, 0x98
	s32i	a13, a8, 0
	s32i	a3, a6, 44
	s32i	a3, a6, 60
	s32i	a3, a6, 84
	s8i	a13, a6, 90
	s8i	a14, a6, 92
	s8i	a13, a6, 113
	add.n	a10, a7, a9
	movi	a12, 0x180
	movi.n	a11, 0
	call8	memset
	mov.n	a9, a10
	l32r	a10, .LC1939
	l32r	a11, .LC1940
	s32i	a10, a7, 256
	movi.n	a10, 0
	s32i	a10, a7, 272
	l32r	a10, .LC1937
	movi	a8, 0x6c0
	s32i	a11, a7, 260
	s32i	a10, a7, 276
	add.n	a8, a8, sp
	movi.n	a10, -1
	movi	a11, 0x6c8
	s32i	a10, a7, 280
	l32i	a13, a8, 0
	l32r	a10, .LC1938
	add.n	a11, a11, sp
	movi.n	a12, 1
	l32i	a14, a11, 0
	movi.n	a8, 1
	s32i	a12, a7, 172
	s32i	a12, a7, 180
	s32i	a12, a7, 192
	s32i	a12, a7, 204
	s32i	a12, a7, 216
	s32i	a12, a7, 228
	s8i	a12, a7, 244
	s8i	a12, a7, 248
	s32i	a10, a7, 284
	s32i	a8, a7, 352
	s32i	a3, a7, 356
	s8i	a13, a7, 152
	addmi	a10, a5, 0x300
	s8i	a12, a10, 106
	s8i	a12, a10, 129
	s8i	a14, a10, 108
	s32i	a8, a7, 424
	s32i	a3, a7, 428
	l32i	a8, a2, 136
	l32i	a10, a2, 0
	movi	a11, 0x418
	s8i	a12, a6, 0
	add.n	a11, a5, a11
	mov.n	a12, a9
	callx8	a8
	s32i	a10, a4, 80
	s32i	a11, a4, 84
	s32i	a12, a4, 88
	extui	a3, a10, 0, 8
	beqz.n	a3, .L3226
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1785
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3226:
	l32i	a9, a7, 172
	movi.n	a12, 0
	s32i	a9, a6, 156
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	s32i	a3, a4, 80
	movi.n	a6, 1
	movi.n	a7, 0
	beq	a10, a8, .L3227
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 48
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a14, 0x550
	movi	a13, 0x488
	add.n	a14, a5, a14
	add.n	a13, a5, a13
	callx8	a8
	mov.n	a6, a10
	bnez.n	a10, .L3227
	movi	a8, 0x6b0
	l32i	a7, a4, 80
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3227:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1774
	l32i	a11, a8, 0
	mov.n	a15, a7
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3204:
	addi	a5, a3, -45
	extui	a5, a5, 0, 8
	movi.n	a8, 8
	bltu	a8, a5, .L3228
	j	.L3095
.L3795:
	movi.n	a5, 8
.L3095:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3229
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3230
.L3229:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3231
	addi.n	a10, a10, 1
.L3231:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3230:
	l32i	a9, a2, 44
	bnez.n	a9, .L3233
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1524
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3233:
	movi	a9, 0xe0
	add.n	a13, sp, a9
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	addmi	a4, a13, 0x200
	s32i	a8, a9, 0
	l32r	a11, .LC1786
	movi.n	a9, 0
	movi	a10, 0xa0
	s8i	a8, a4, 152
	s16i	a8, a4, 154
	s8i	a9, a4, 156
	movi.n	a12, 0x40
	add.n	a10, a4, a10
	call8	memcpy
	movi	a11, 0x1ff
	movi.n	a10, 0
	movi.n	a9, 1
	slli	a11, a11, 21
	movi	a8, 0x6c0
	s32i	a10, a4, 192
	sub	a7, a7, a6
	add.n	a8, a8, sp
	movi	a13, 0xe0
	s8i	a9, a4, 188
	s32i	a11, a4, 196
	movi.n	a10, 0x35
	l32i	a8, a8, 0
	addi.n	a14, a7, -1
	add.n	a13, a13, sp
	bne	a3, a10, .L3234
	s32i	a8, sp, 224
	bltui	a14, 2, .L3235
.L3237:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1789
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3235:
	beqz.n	a14, .L3236
	movi	a8, 0x4f8
	add.n	a8, a13, a8
	addx4	a8, a6, a8
	l32i	a10, a8, 4
	mov.n	a11, a13
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3237
	l32i	a14, sp, 224
	movi	a8, -0x190
	l32r	a9, .LC1790
	add.n	a8, a14, a8
	bltu	a9, a8, .L3237
.L3236:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	movi.n	a9, 9
	s8i	a9, a8, 152
	s16i	a14, a8, 154
	j	.L3238
.L3234:
	movi.n	a10, 0x34
	bne	a3, a10, .L3239
	beqz.n	a14, .L3240
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3240:
	s8i	a9, a4, 152
	j	.L3238
.L3239:
	bgeui	a5, 2, .L3241
	addi	a7, a7, -2
	bltui	a7, 2, .L3242
.L3243:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3242:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	s32i	a14, a8, 0
	movi	a8, 0x4f8
	add.n	a7, a13, a8
	addx4	a8, a6, a7
	movi	a4, 0x298
	add.n	a4, a13, a4
	l32i	a10, a8, 4
	addi.n	a11, a4, 8
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3243
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	bnei	a14, 2, .L3244
	addx4	a7, a6, a7
	l32i	a10, a7, 8
	addi	a11, a4, 24
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE
	beqz.n	a10, .L3243
.L3244:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a12, a8, 176
	bgeui	a12, 7, .L3245
	movi	a8, -0x5a
	bbc	a8, a12, .L3246
.L3245:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1792
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3246:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a10, 0x2d
	l8ui	a9, a8, 4
	movi.n	a8, 8
	bne	a9, a10, .L3247
	movi.n	a8, 7
.L3247:
	movi	a10, 0x2e0
	add.n	a10, sp, a10
	addi	a9, a9, -45
	s8i	a8, a10, 152
	movi.n	a11, 0
	movi.n	a8, 1
	moveqz	a11, a8, a9
	s8i	a11, a10, 178
	moveqz	a8, a12, a9
	beqz.n	a12, .L3249
.L3248:
	movi.n	a8, 1
	bnei	a12, 6, .L3249
	movi.n	a8, 2
.L3249:
	movi	a9, 0x2e0
	add.n	a9, sp, a9
	s8i	a8, a9, 177
	j	.L3238
.L3241:
	movi.n	a9, 0x33
	bne	a3, a9, .L3250
	bnei	a14, 1, .L3251
	movi	a8, 0x4f8
	add.n	a8, a13, a8
	addx4	a8, a6, a8
	l32i	a10, a8, 4
	movi	a11, 0x2a0
	add.n	a11, a13, a11
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3251
	l32i	a9, a4, 160
	l32i	a8, a4, 164
	addi.n	a10, a9, -1
	addi.n	a8, a8, -1
	beqz.n	a9, .L3252
	addi.n	a8, a8, 1
.L3252:
	bnez.n	a8, .L3251
	movi.n	a8, -2
	bltu	a8, a10, .L3251
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l32i	a9, a8, 172
	bnez.n	a9, .L3251
	movi.n	a9, 6
	s8i	a9, a8, 152
	j	.L3238
.L3251:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1794
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3250:
	bgeui	a14, 3, .L3255
	addi	a7, a7, -3
	movi.n	a9, 1
	mov.n	a10, a8
	moveqz	a10, a9, a7
	beqz.n	a10, .L3256
	addi	a10, a3, -50
	movnez	a9, a8, a10
	beqz.n	a9, .L3256
.L3255:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3256:
	beqz.n	a14, .L3238
	movi	a9, 0xe0
	add.n	a9, sp, a9
	movi	a8, 0x4f8
	add.n	a8, a9, a8
	addx4	a8, a6, a8
	l32i	a7, a8, 4
	movi.n	a8, 0x32
	bne	a3, a8, .L3258
	addmi	a6, a9, 0x200
	movi.n	a8, 5
	l32r	a11, .LC1482
	s8i	a8, a6, 152
	mov.n	a10, a7
	call8	strcmp
	beqz.n	a10, .L3238
	l32r	a11, .LC1481
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L3259
	movi.n	a8, 2
	s8i	a8, a6, 156
	j	.L3238
.L3259:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3258:
	movi.n	a8, 0
	s32i	a8, sp, 224
	s32i	a8, sp, 228
	movi.n	a8, 1
	s32i	a8, sp, 232
	movi.n	a8, 0
	s32i	a8, sp, 236
	movi.n	a8, 0x2f
	l32r	a4, .LC1472
	bne	a3, a8, .L3260
	l32r	a4, .LC1470
.L3260:
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a14, a8, 0
	mov.n	a10, a7
	call8	strlen
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a10, a9, 0
	mov.n	a10, a4
	call8	strlen
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	movi	a9, 0x6c8
	l32i	a8, a8, 0
	add.n	a9, a9, sp
	l32i	a14, a9, 0
	bgeu	a10, a8, .L3261
	sub	a8, a8, a10
	movi	a9, 0x6c0
	add.n	a8, a7, a8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	mov.n	a10, a8
	mov.n	a11, a4
	call8	strcmp
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	movi	a8, 0x6c0
	l32i	a14, a9, 0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnei	a14, 2, .L3262
	beqz.n	a10, .L3263
.L3697:
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a6, a8
	l32i	a10, a8, 8
	mov.n	a11, a4
	call8	strcmp
	beqz.n	a10, .L3264
.L3263:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3262:
	bnez.n	a10, .L3264
	s8i	a10, a8, 0
.L3264:
	movi	a8, 0xe0
	add.n	a6, sp, a8
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	addmi	a8, a6, 0x400
	s32i	a10, a8, 24
	s32i	a11, a8, 28
	s32i	a12, a8, 32
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3266
.L3268:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1476
	l32i	a12, a8, 0
	movi.n	a8, 0x2f
	bne	a3, a8, .L3267
.L3696:
	l32r	a13, .LC1474
	j	.L3267
.L3266:
	l32i	a8, sp, 232
	bnei	a8, 1, .L3268
	l32i	a8, sp, 236
	bnez.n	a8, .L3268
	l32i	a8, sp, 228
	l32i	a9, sp, 224
	bltz	a8, .L3268
	movi.n	a10, 0x2f
	bne	a3, a10, .L4567
	j	.L3270
.L3267:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3691:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	s8i	a10, a8, 152
	s16i	a9, a8, 154
.L3238:
	addi	a8, a3, -52
	movi.n	a4, 1
	extui	a8, a8, 0, 8
	saltu	a8, a4, a8
	saltu	a5, a4, a5
	addi.n	a8, a8, -1
	addi.n	a5, a5, -1
	neg	a5, a5
	neg	a8, a8
	or	a8, a8, a5
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	extui	a6, a8, 0, 8
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	l32r	a8, .LC1795
	movi.n	a7, 0
	s32i	a8, sp, 224
	l32r	a8, .LC1796
	addmi	a5, sp, 0x100
	s32i	a8, sp, 228
	movi	a8, 0x3e8
	s32i	a8, sp, 240
	movi.n	a8, 0
	s32i	a8, sp, 244
	movi.n	a8, 1
	s32i	a8, sp, 248
	movi.n	a8, 0
	s32i	a8, sp, 252
	s8i	a7, sp, 232
	movi.n	a8, 1
	s8i	a4, a5, 0
	slli	a8, a8, 16
	s32i	a8, sp, 284
	s32i	a7, sp, 260
	s32i	a7, sp, 264
	s32i	a7, sp, 268
	s32i	a7, sp, 272
	s32i	a7, sp, 276
	s32i	a7, sp, 280
	s8i	a7, a5, 32
	movi.n	a4, 0
	addi	a10, a10, -15
	s16i	a7, sp, 290
	s32i	a7, sp, 292
	s16i	a7, sp, 296
	movi.n	a3, 1
	s8i	a4, a5, 42
	moveqz	a3, a10, a10
	movi	a10, 0x13c
	s32i	a7, sp, 300
	s32i	a7, sp, 304
	s32i	a7, sp, 308
	s32i	a7, sp, 312
	movi.n	a12, 0xc
	movi.n	a11, 0
	add.n	a10, sp, a10
	call8	memset
	s32i	a7, sp, 328
	s32i	a7, sp, 332
	s8i	a4, a5, 80
	movi.n	a8, 0
	s32i	a8, sp, 344
	s32i	a8, sp, 348
	movi.n	a9, 0
	movi.n	a8, 0
	s32i	a8, sp, 352
	s32i	a9, sp, 356
	l32r	a8, .LC1457
	s16i	a7, sp, 360
	s8i	a4, a5, 106
	s8i	a4, a5, 108
	s32i	a8, sp, 372
	l32r	a8, .LC1637
	s32i	a7, sp, 368
	s32i	a8, sp, 376
	s32i	a7, sp, 380
	beqz.n	a6, .L3273
	beqz.n	a3, .L3273
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	j	.L3274
.L3273:
	bnei	a6, 1, .L3274
	beqz.n	a3, .L3828
.L3274:
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	movi	a7, 0xe0
	add.n	a7, sp, a7
	l32i	a8, a2, 44
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a12, 0x298
	mov.n	a13, a7
	add.n	a12, a7, a12
	callx8	a8
	mov.n	a13, a10
	beqz.n	a10, .L3277
	j	.L3275
.L3828:
	movi.n	a13, 1
.L3275:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a15, 0
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3277:
	beqz.n	a6, .L3278
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a12, sp, 260
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a13, 1
	mov.n	a12, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb
	j	.L2775
.L3278:
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	l8ui	a8, a2, 141
	l8ui	a10, a9, 4
	movi.n	a9, 0x33
	bne	a10, a9, .L3279
	l32i	a10, a7, 680
	l32i	a11, a7, 684
	l32i	a14, a7, 672
	l32i	a15, a7, 676
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	addmi	a7, a7, 0x200
	bnez.n	a8, .L3280
	l32r	a12, .LC1800
	l32r	a11, .LC1602
	movi	a10, 0x124
	add.n	a10, a2, a10
	call8	snprintf
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3280:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	l32r	a12, .LC1802
	l32r	a11, .LC1602
	movi	a10, 0x124
	add.n	a10, a2, a10
	call8	snprintf
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3279:
	l8ui	a9, sp, 230
	bnez.n	a8, .L3281
	beqz.n	a9, .L3282
	l16ui	a13, sp, 226
	l32r	a12, .LC1803
	movi	a10, 0x488
	movi.n	a11, 0x18
	add.n	a10, a7, a10
	call8	snprintf
	j	.L3283
.L3282:
	movi	a10, 0x488
	l32r	a11, .LC1805
	add.n	a10, a7, a10
	call8	strcpy
.L3283:
	l8ui	a8, sp, 231
	beqz.n	a8, .L3284
	l16ui	a13, sp, 228
	l32r	a12, .LC1803
	movi	a10, 0x4f8
	movi.n	a11, 0x18
	add.n	a10, sp, a10
	call8	snprintf
	j	.L3285
.L3284:
	movi	a10, 0x4f8
	l32r	a11, .LC1805
	add.n	a10, sp, a10
	call8	strcpy
.L3285:
	l8ui	a8, sp, 232
	movi	a10, 0x124
	l16ui	a13, sp, 224
	l32r	a9, .LC1480
	add.n	a10, a2, a10
	bnei	a8, 2, .L3286
	l32r	a9, .LC1478
.L3286:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	l32r	a12, .LC1807
	l32r	a11, .LC1602
	movi	a15, 0x418
	movi	a14, 0x488
	s32i	a9, sp, 0
	add.n	a15, a8, a15
	add.n	a14, a8, a14
	call8	snprintf
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3281:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a10, 0x124
	l32i	a14, a8, 0
	l16ui	a15, sp, 224
	l16ui	a12, sp, 226
	l16ui	a13, sp, 228
	l32r	a8, .LC1441
	add.n	a10, a2, a10
	beqz.n	a9, .L3287
	l32r	a8, .LC1440
.L3287:
	l8ui	a11, sp, 231
	l32r	a9, .LC1441
	beqz.n	a11, .L3288
	l32r	a9, .LC1440
.L3288:
	l8ui	a7, sp, 232
	l32r	a11, .LC1482
	bnei	a7, 2, .L3289
	l32r	a11, .LC1481
.L3289:
	s32i	a8, sp, 8
	movi	a8, 0x6b0
	s32i	a11, sp, 16
	s32i	a12, sp, 0
	s32i	a9, sp, 12
	s32i	a13, sp, 4
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	l32r	a12, .LC1809
	l32r	a11, .LC1602
	call8	snprintf
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3228:
	movi.n	a8, 0x36
	bne	a3, a8, .L3290
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3291
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3292
.L3291:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3293
	addi.n	a10, a10, 1
.L3293:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3292:
	movi	a5, 0xe0
	add.n	a5, sp, a5
	movi.n	a8, 0
	addmi	a3, a5, 0x400
	s32i	a8, a3, 24
	addi.n	a8, a6, 3
	bne	a7, a8, .L3295
	movi	a8, 0x4f8
	add.n	a4, a5, a8
	addx4	a8, a6, a4
	l32r	a11, .LC1811
	l32i	a10, a8, 4
	call8	strcmp
	mov.n	a7, a10
	bnez.n	a10, .L3295
	addx4	a8, a6, a4
	movi	a11, 0x418
	l32i	a10, a8, 8
	add.n	a11, a5, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3295
	l32i	a6, a3, 24
	beqz.n	a6, .L3295
	l32i	a8, a2, 40
	bnez.n	a8, .L4568
	j	.L3296
.L3295:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1812
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L4568:
	l32i	a4, a2, 12
	bnez.n	a4, .L3298
.L3296:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1812
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3298:
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a9, 0x14
	l32r	a8, .LC1579
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a9, sp, 308
	movi.n	a8, 1
	l32r	a9, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a3, sp, 0x100
	s8i	a8, a3, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	mov.n	a11, a5
	callx8	a4
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	s32i	a7, sp, 888
	bne	a10, a8, .L3300
	l8ui	a5, a3, 88
	movi.n	a7, 1
	movi.n	a6, 0
	j	.L3301
.L3300:
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 40
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a13, 0x298
	add.n	a13, a5, a13
	mov.n	a12, a6
	callx8	a8
	mov.n	a7, a10
	l8ui	a5, a3, 88
	movi.n	a6, 0
	bnez.n	a10, .L3301
	movi	a8, 0x6b0
	l32i	a6, sp, 888
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3301:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1812
	l32i	a11, a8, 0
	mov.n	a15, a6
	mov.n	a14, a5
	mov.n	a13, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3290:
	movi.n	a8, 0x1c
	bne	a3, a8, .L3302
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3303
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3304
.L3303:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3305
	addi.n	a10, a10, 1
.L3305:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3304:
	addi.n	a8, a6, 1
	l32r	a4, .LC1457
	bgeu	a8, a7, .L3307
	movi	a9, 0x5d8
	add.n	a9, sp, a9
	addx4	a8, a8, a9
	l32i	a4, a8, 0
.L3307:
	movi	a5, 0x4e0
	l32r	a11, .LC1813
	add.n	a5, sp, a5
	movi	a10, 0x88
	movi.n	a12, 0x48
	add.n	a10, a5, a10
	call8	memcpy
	l32r	a11, .LC1814
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3308
	l32r	a11, .LC1815
	mov.n	a10, a4
	call8	strcmp
	bnez.n	a10, .L3309
	s8i	a10, a5, 154
	j	.L3308
.L3309:
	l32r	a11, .LC1816
	mov.n	a10, a4
	call8	strcmp
	bnez.n	a10, .L3310
	movi	a8, 0x100
	s16i	a8, a5, 154
	j	.L3308
.L3310:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1817
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3308:
	movi	a8, 0x4e0
	l32r	a10, .LC1483
	add.n	a8, sp, a8
	movi	a11, 0x6b8
	add.n	a11, a11, sp
	l8ui	a9, a8, 155
	s32i	a10, a11, 0
	bnez.n	a9, .L3311
	l32r	a10, .LC1485
	movi	a11, 0x6b8
	add.n	a11, a11, sp
	l8ui	a8, a8, 154
	s32i	a10, a11, 0
	beqz.n	a8, .L3311
	l32r	a8, .LC1484
	s32i	a8, a11, 0
.L3311:
	l32i	a8, a2, 36
	beqz.n	a8, .L3312
	l32i	a8, a2, 12
	beqz.n	a8, .L3312
	l32i	a8, a2, 136
	bnez.n	a8, .L3313
.L3312:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3313:
	movi.n	a8, 5
	movi.n	a11, 7
	addi.n	a10, a6, 2
	movnez	a8, a11, a9
	add.n	a8, a8, a10
	bgeu	a7, a8, .L3315
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3315:
	movi	a3, 0xe0
	add.n	a3, sp, a3
	addmi	a9, a3, 0x500
	movi.n	a8, 0
	s32i	a8, a9, 80
	s32i	a8, a9, 84
	movi.n	a8, 1
	s32i	a8, a9, 88
	movi.n	a8, 0
	s32i	a8, a9, 92
	movi	a8, 0x488
	movi	a9, 0x6c0
	add.n	a8, a3, a8
	add.n	a9, a9, sp
	movi	a4, 0x4f8
	s32i	a8, a9, 0
	add.n	a4, a3, a4
	movi	a9, 0x6c0
	addx4	a8, a10, a4
	add.n	a9, a9, sp
	l32i	a11, a9, 0
	l32i	a10, a8, 0
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3316
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addx4	a8, a6, a4
	l32i	a10, a8, 12
	addi	a11, a9, 16
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112positionUnitEPKcRN14MotorControlRS12PositionUnitE
	beqz.n	a10, .L3316
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addx4	a8, a6, a4
	l32i	a10, a8, 16
	addi	a11, a9, 17
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_115coordinateFrameEPKcRN14MotorControlRS15CoordinateFrameE
	beqz.n	a10, .L3316
	addmi	a3, a3, 0x400
	l8ui	a8, a3, 155
	addi.n	a5, a6, 5
	bnez.n	a8, .L3317
	j	.L3318
.L3316:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3317:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addx4	a5, a5, a4
	l32i	a10, a5, 0
	addi	a11, a8, 20
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19anglePathEPKcRN14MotorControlRS9AnglePathE
	beqz.n	a10, .L3319
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addx4	a4, a6, a4
	l32i	a10, a4, 24
	addi	a11, a8, 21
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111halfTurnTieEPKcRN14MotorControlRS11HalfTurnTieE
	beqz.n	a10, .L3319
	addi.n	a5, a6, 7
	j	.L3318
.L3319:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3318:
	movi	a8, 0xe0
	add.n	a4, sp, a8
	movi	a8, 0x4f8
	add.n	a8, a4, a8
	addx4	a8, a5, a8
	l32i	a10, a8, 0
	movi	a11, 0x550
	add.n	a11, a4, a11
	call8	_ZN14MotorControlRS16parseExactNumberEPKcRNS_8RationalE
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a6, a10, 0, 8
	bnez.n	a6, .L3320
	addmi	a8, a4, 0x500
	l32i	a9, a8, 88
	bnei	a9, 1, .L3320
	l32i	a9, a8, 92
	bnez.n	a9, .L3320
	l32i	a9, a8, 84
	l32i	a12, a8, 80
	addi.n	a8, a9, -1
	movnez	a8, a9, a12
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a12, a9, 0
	addi.n	a10, a12, -1
	bnez.n	a8, .L3320
	l32r	a8, .LC1818
	bltu	a8, a10, .L3320
	mov.n	a8, a4
	movi	a4, 0x4f8
	add.n	a4, a8, a4
	addx4	a9, a5, a4
	l32r	a11, .LC1775
	l32i	a10, a9, 4
	addi.n	a3, a5, 2
	call8	strcmp
	bnez.n	a10, .L3320
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	movi	a8, 0xe0
	l32i	a12, a9, 0
	add.n	a8, a8, sp
	addmi	a8, a8, 0x400
	movi.n	a9, 1
	s16i	a12, a8, 200
	s8i	a9, a8, 202
	bltu	a3, a7, .L3323
	j	.L3324
.L3320:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3323:
	addx4	a8, a3, a4
	l32r	a11, .LC1819
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3325
	addi.n	a8, a5, 3
	bltu	a8, a7, .L3326
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3326:
	addx4	a8, a8, a4
	l32i	a4, a8, 0
	l32r	a11, .LC1482
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3327
	l32r	a11, .LC1661
	mov.n	a10, a4
	call8	strcmp
	beqz.n	a10, .L3838
	l32r	a11, .LC1481
	mov.n	a10, a4
	call8	strcmp
	movi.n	a6, 2
	beqz.n	a10, .L3327
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3838:
	movi.n	a6, 1
.L3327:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	s8i	a6, a8, 203
	addi.n	a3, a5, 4
	bgeu	a3, a7, .L3324
.L3325:
	movi	a5, 0xe0
	add.n	a5, sp, a5
	movi	a6, 0x4f8
	add.n	a6, a5, a6
	addx4	a8, a3, a6
	l32r	a11, .LC1821
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3840
	addmi	a8, a5, 0x400
	l8ui	a8, a8, 154
	bnez.n	a8, .L3329
.L3330:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3329:
	addi.n	a8, a3, 1
	bgeu	a8, a7, .L3330
	addx4	a8, a8, a6
	movi	a11, 0x49e
	l32i	a10, a8, 0
	add.n	a11, a5, a11
	addi.n	a3, a3, 2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_113relativeBasisEPKcRN14MotorControlRS13RelativeBasisE
	beqz.n	a10, .L3330
	bgeu	a3, a7, .L3324
.L3840:
	movi	a6, 0xe0
	movi	a8, 0x6c0
	add.n	a6, sp, a6
	movi	a5, 0x4f8
	add.n	a8, a8, sp
	add.n	a5, a6, a5
	s32i	a3, a8, 0
	addx4	a8, a3, a5
	l32i	a10, a8, 0
	l32r	a11, .LC1780
	call8	strcmp
	addi.n	a8, a3, 1
	bnez.n	a10, .L3324
	addi.n	a3, a3, 3
	bltu	a7, a3, .L3331
	movi	a4, 0x488
	addx4	a8, a8, a5
	add.n	a4, a6, a4
	l32i	a10, a8, 0
	addi	a11, a4, 28
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18roundingEPKcRN14MotorControlRS8RoundingE
	beqz.n	a10, .L3331
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addi	a11, a4, 32
	addx4	a8, a8, a5
	l32i	a10, a8, 8
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3331
	bltu	a3, a7, .L3332
	j	.L3324
.L3331:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3332:
	addx4	a8, a3, a5
	l32r	a11, .LC1782
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3324
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	addi.n	a8, a8, 4
	bgeu	a8, a7, .L3333
	addmi	a6, a6, 0x400
	l8ui	a9, a6, 152
	bnei	a9, 5, .L3333
	movi	a9, 0x6c0
	addx4	a8, a8, a5
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	l32i	a10, a8, 0
	addi	a11, a4, 56
	addi.n	a3, a9, 5
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_19allowanceEPKcRd
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3333
	l32i	a10, a6, 192
	l32i	a11, a6, 196
	movi.n	a12, 0
	movi.n	a13, 0
	call8	__ledf2
	blti	a10, 1, .L3333
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	movi.n	a9, 1
	s8i	a9, a8, 176
	j	.L3324
.L3333:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3324:
	movi	a6, 0xe0
	add.n	a6, sp, a6
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	movi.n	a9, 0x14
	l32r	a8, .LC1579
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a9, sp, 308
	movi.n	a8, 1
	l32r	a9, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a5, sp, 0x100
	s8i	a8, a5, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	mov.n	a11, a6
	callx8	a8
	l8ui	a9, a5, 88
	addmi	a8, a6, 0x500
	s32i	a9, a8, 136
	addi.n	a8, a3, 1
	bgeu	a8, a7, .L3335
.L3337:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3335:
	bne	a8, a7, .L3336
	movi	a8, 0x4f8
	add.n	a8, a6, a8
	addx4	a8, a3, a8
	movi	a11, 0x588
	l32i	a10, a8, 0
	add.n	a11, a6, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3337
.L3336:
	movi	a5, 0xe0
	add.n	a5, sp, a5
	addmi	a4, a5, 0x500
	l32i	a3, a4, 136
	movi	a9, 0xf6
	addi.n	a8, a3, -1
	bgeu	a9, a8, .L3338
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3338:
	addmi	a6, a5, 0x400
	movi	a12, 0x70
	movi.n	a11, 0
	addi	a10, a6, 24
	call8	memset
	movi.n	a8, 1
	s32i	a8, a6, 40
	s32i	a8, a6, 56
	s32i	a8, a6, 80
	movi	a8, 0x6c8
	movi.n	a14, 2
	add.n	a8, a8, sp
	s32i	a14, a8, 0
	movi	a8, 0x6c0
	addmi	a7, a5, 0x200
	movi.n	a15, 0
	movi.n	a13, 1
	add.n	a8, a8, sp
	movi	a9, 0x98
	s32i	a13, a8, 0
	s32i	a15, a6, 44
	s32i	a15, a6, 60
	s32i	a15, a6, 84
	s8i	a13, a6, 90
	s8i	a14, a6, 92
	s8i	a13, a6, 113
	add.n	a10, a7, a9
	movi	a12, 0x180
	movi.n	a11, 0
	call8	memset
	mov.n	a9, a10
	l32r	a10, .LC1939
	l32r	a11, .LC1940
	s32i	a10, a7, 256
	movi.n	a10, 0
	s32i	a10, a7, 272
	l32r	a10, .LC1937
	movi	a8, 0x6c0
	s32i	a11, a7, 260
	s32i	a10, a7, 276
	add.n	a8, a8, sp
	movi.n	a10, -1
	movi	a11, 0x6c8
	s32i	a10, a7, 280
	l32i	a13, a8, 0
	l32r	a10, .LC1938
	add.n	a11, a11, sp
	movi.n	a12, 1
	l32i	a14, a11, 0
	movi.n	a8, 1
	movi.n	a15, 0
	s32i	a12, a7, 172
	s32i	a12, a7, 180
	s32i	a12, a7, 192
	s32i	a12, a7, 204
	s32i	a12, a7, 216
	s32i	a12, a7, 228
	s8i	a12, a7, 244
	s8i	a12, a7, 248
	s32i	a10, a7, 284
	s32i	a8, a7, 352
	s8i	a13, a7, 152
	s32i	a15, a7, 356
	addmi	a10, a5, 0x300
	s8i	a12, a10, 106
	s8i	a12, a10, 129
	s8i	a14, a10, 108
	s32i	a8, a7, 424
	s32i	a15, a7, 428
	l32i	a8, a2, 136
	l32i	a10, a2, 0
	movi	a11, 0x418
	s8i	a12, a6, 0
	add.n	a11, a5, a11
	mov.n	a12, a9
	callx8	a8
	s32i	a10, a4, 112
	s32i	a11, a4, 116
	s32i	a12, a4, 120
	extui	a8, a10, 0, 8
	beqz.n	a8, .L3341
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1785
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3341:
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a9, a7, 172
	movi.n	a12, 0
	s32i	a9, a6, 160
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a6, 1
	s32i	a8, a4, 112
	movi.n	a8, 0xf
	movi.n	a7, 0
	beq	a10, a8, .L3342
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 36
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a14, 0x570
	movi	a13, 0x488
	add.n	a14, a5, a14
	add.n	a13, a5, a13
	mov.n	a12, a3
	callx8	a8
	mov.n	a6, a10
	bnez.n	a10, .L3342
	movi	a8, 0x6b0
	l32i	a7, a4, 112
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3342:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a15, a7
	mov.n	a14, a3
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3302:
	movi.n	a8, 0x19
	addi.n	a5, a6, 1
	bne	a3, a8, .L3343
	bgeu	a5, a7, .L3343
	movi	a8, 0xe0
	add.n	a9, sp, a8
	movi	a4, 0x4f8
	add.n	a4, a9, a4
	addx4	a8, a5, a4
	l32r	a11, .LC1823
	l32i	a10, a8, 0
	call8	strcmp
	bnez.n	a10, .L3343
	movi	a9, 0xe0
	add.n	a9, a9, sp
	addmi	a5, a9, 0x400
	s32i	a10, a5, 24
	addi.n	a8, a6, 5
	bne	a7, a8, .L3344
	addx4	a8, a6, a4
	movi	a11, 0x418
	l32i	a10, a8, 8
	add.n	a11, a9, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3344
	l32i	a7, a5, 24
	beqz.n	a7, .L3344
	addx4	a8, a6, a4
	l32r	a11, .LC1825
	l32i	a10, a8, 12
	call8	strcmp
	bnez.n	a10, .L3344
	addx4	a4, a6, a4
	l32r	a11, .LC1827
	l32i	a10, a4, 16
	call8	strcmp
	mov.n	a5, a10
	bnez.n	a10, .L3344
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3345
	j	.L4569
.L3344:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1486
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L4569:
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3348
.L3345:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3349
	addi.n	a10, a10, 1
.L3349:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3348:
	l32i	a8, a2, 32
	l32r	a4, .LC1486
	beqz.n	a8, .L3350
	l32i	a8, a2, 124
	bnez.n	a8, .L3351
.L3350:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3351:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0
	s32i	a8, sp, 888
	movi.n	a8, 0xf
	movi.n	a6, 1
	beq	a10, a8, .L3352
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 32
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a13, 0x378
	add.n	a13, sp, a13
	mov.n	a12, a7
	callx8	a8
	mov.n	a6, a10
.L3352:
	movi	a7, 0xe0
	add.n	a7, sp, a7
	movi	a12, 0x140
	movi.n	a11, 0
	mov.n	a10, a7
	call8	memset
	l32r	a8, .LC1579
	addmi	a9, sp, 0x100
	s32i	a8, sp, 228
	l32r	a8, .LC1457
	movi.n	a15, 0
	s32i	a8, sp, 404
	movi.n	a8, 1
	s8i	a8, a9, 200
	addmi	a9, a7, 0x100
	s8i	a8, a9, 56
	bnez.n	a6, .L3354
	movi	a8, 0x6b0
	l32i	a5, sp, 888
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a12, a5
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
	l32i	a8, a2, 124
	l32i	a10, a2, 0
	mov.n	a11, a5
	mov.n	a12, a7
	callx8	a8
	l32i	a15, sp, 888
	l8ui	a5, sp, 248
.L3354:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a14, a5
	mov.n	a13, a6
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3343:
	movi	a8, 0xe0
	add.n	a4, sp, a8
	addmi	a10, a4, 0x400
	movi.n	a12, 0x18
	movi.n	a11, 0
	addi	a10, a10, 24
	call8	memset
	movi.n	a8, 0x2c
	bltu	a8, a3, .L3356
	movi.n	a8, 0x14
	bgeu	a8, a3, .L3847
	addi	a8, a3, -21
	extui	a8, a8, 0, 8
	movi.n	a9, 0x17
	bltu	a9, a8, .L3847
	l32r	a9, .LC1828
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L3359:
	.word	.L3366
	.word	.L3847
	.word	.L3847
	.word	.L3848
	.word	.L3364
	.word	.L3363
	.word	.L3362
	.word	.L3847
	.word	.L3361
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3847
	.word	.L3360
	.word	.L3358
	.text
.L3356:
	movi.n	a8, 0x37
	beq	a3, a8, .L3367
	movi.n	a8, 0x38
	beq	a3, a8, .L3368
	j	.L3847
.L3364:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	movi.n	a9, 1
	l32r	a6, .LC1486
	s8i	a9, a8, 24
	j	.L3365
.L3363:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	movi.n	a9, 2
	l32r	a6, .LC1489
	s8i	a9, a8, 24
	j	.L3365
.L3361:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	movi.n	a9, 4
	l32r	a6, .LC1488
	s8i	a9, a8, 24
	j	.L3365
.L3362:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a9, a8, 0x400
	movi.n	a10, 3
	s8i	a10, a9, 24
	l32r	a4, .LC1487
	bltu	a5, a7, .L3369
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3369:
	movi	a9, 0x4f8
	add.n	a8, a8, a9
	addx4	a8, a5, a8
	l32i	a5, a8, 0
	l32r	a11, .LC1776
	mov.n	a10, a5
	call8	strcmp
	beqz.n	a10, .L3849
	l32r	a11, .LC1777
	mov.n	a10, a5
	call8	strcmp
	movi.n	a9, 2
	beqz.n	a10, .L3370
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1778
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3849:
	movi.n	a9, 1
.L3370:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	addi.n	a5, a6, 2
	s8i	a9, a8, 25
	mov.n	a6, a4
	j	.L3365
.L3848:
	l32r	a6, .LC1490
.L3365:
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	l8ui	a4, a8, 24
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3371
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3372
.L3371:
	bnei	a4, 3, .L3373
.L3372:
	l32i	a8, a2, 28
	bnez.n	a8, .L4570
	j	.L3374
.L3373:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3376
	addi.n	a10, a10, 1
.L3376:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L4570:
	l32i	a13, a2, 12
	bnez.n	a13, .L3378
.L3374:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32i	a11, a8, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3378:
	movi	a8, 0x6b8
	movi	a9, 0xe0
	add.n	a8, a8, sp
	s32i	a13, a8, 0
	add.n	a10, sp, a9
	movi	a12, 0x298
	movi.n	a11, 0
	call8	memset
	mov.n	a11, a10
	movi.n	a10, 0x14
	s32i	a10, sp, 300
	l32r	a10, .LC1620
	l32r	a3, .LC1579
	s32i	a10, sp, 308
	movi.n	a8, 1
	l32r	a10, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a10, sp, 312
	s32i	a10, sp, 316
	addmi	a12, sp, 0x100
	s32i	a3, sp, 224
	s32i	a3, sp, 232
	s32i	a3, sp, 240
	s8i	a8, a12, 88
	l32r	a8, .LC1457
	l32i	a10, a2, 0
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	callx8	a13
	movi	a9, 0xe0
	addmi	a12, sp, 0x100
	l8ui	a10, a12, 88
	add.n	a9, a9, sp
	addmi	a8, a9, 0x500
	s32i	a10, a8, 80
	addi.n	a8, a5, 1
	bgeu	a8, a7, .L3380
.L3382:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3380:
	bne	a8, a7, .L3381
	movi	a8, 0x4f8
	add.n	a8, a9, a8
	addx4	a8, a5, a8
	movi	a11, 0x550
	l32i	a10, a8, 0
	add.n	a11, a9, a11
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3382
.L3381:
	movi	a9, 0xe0
	add.n	a9, sp, a9
	addmi	a8, a9, 0x500
	l32i	a8, a8, 80
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a10, 0xf6
	addi.n	a8, a8, -1
	bgeu	a10, a8, .L3383
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32i	a11, a8, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3383:
	addi	a7, a4, -3
	nsau	a7, a7
	srli	a7, a7, 5
	mov.n	a11, a7
	movi.n	a12, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi	a9, 0xe0
	add.n	a9, a9, sp
	addmi	a15, a9, 0x400
	movi.n	a8, 0
	s32i	a8, a15, 136
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	s32i	a15, a8, 0
	movi.n	a11, 0xf
	movi.n	a5, 1
	beq	a10, a11, .L3384
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0xe0
	add.n	a9, a9, sp
	movi	a14, 0x488
	movi	a13, 0x418
	add.n	a14, a9, a14
	add.n	a13, a9, a13
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 28
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	callx8	a8
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a15, a8, 0
	mov.n	a5, a10
	bnez.n	a10, .L3384
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a12, a15, 136
	l32i	a11, a8, 0
	movi.n	a14, 0
	mov.n	a13, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3384:
	movi	a9, 0xe0
	add.n	a9, sp, a9
	movi	a8, 0x6c0
	addmi	a14, a9, 0x200
	movi	a13, 0x98
	add.n	a8, a8, sp
	add.n	a10, a14, a13
	s32i	a14, a8, 0
	movi.n	a11, 0
	movi	a12, 0x140
	call8	memset
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	mov.n	a13, a10
	movi	a9, 0xe0
	l32r	a10, .LC1457
	add.n	a9, a9, sp
	s32i	a10, a14, 332
	s32i	a3, a14, 156
	addmi	a10, a9, 0x300
	movi.n	a11, 1
	s8i	a11, a10, 128
	s8i	a11, a10, 208
	nsau	a10, a5
	srli	a10, a10, 5
	and	a7, a7, a10
	beqz.n	a7, .L3388
	l32i	a14, a2, 124
	beqz.n	a14, .L3389
	addmi	a9, a9, 0x400
	l32i	a11, a9, 136
	l32i	a10, a2, 0
	mov.n	a12, a13
	callx8	a14
	j	.L3389
.L3388:
	beqi	a4, 3, .L3389
.L3392:
	movi.n	a15, 0
	bnez.n	a5, .L3391
	j	.L3390
.L4575:
	l32r	a9, .LC1598
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L3392
.L3698:
	movi.n	a15, 0
	beqz.n	a7, .L3393
	movi	a9, 0x4e0
	add.n	a9, sp, a9
	l32i	a15, a9, 136
.L3393:
	movi	a9, 0x2e0
	add.n	a9, sp, a9
	l8ui	a10, a9, 181
	movi	a8, 0x6b8
	s32i	a10, sp, 8
	l32i	a10, a9, 184
	add.n	a8, a8, sp
	s32i	a10, sp, 4
	l8ui	a9, a9, 180
	mov.n	a13, a5
	s32i	a9, sp, 0
	l32i	a14, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15retainStopReplyEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3390:
	movi	a9, 0x4e0
	add.n	a9, sp, a9
	l32i	a15, a9, 136
.L3391:
	movi	a9, 0x2e0
	add.n	a9, sp, a9
	l8ui	a10, a9, 181
	movi	a8, 0x6b8
	s32i	a10, sp, 8
	l32i	a10, a9, 184
	add.n	a8, a8, sp
	s32i	a10, sp, 4
	l8ui	a9, a9, 180
	mov.n	a13, a5
	s32i	a9, sp, 0
	l32i	a14, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3368:
	movi	a8, 0x4f8
	add.n	a8, a4, a8
	extui	a12, a5, 0, 16
	addx4	a12, a12, a8
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	addi.n	a13, a7, -1
	l32i	a11, a8, 0
	sub	a13, a13, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5groupEmPKPKcj
	j	.L2775
.L3367:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3394
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3395
.L3394:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3396
	addi.n	a10, a10, 1
.L3396:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3395:
	addi.n	a8, a6, 3
	l32r	a3, .LC1835
	bne	a7, a8, .L3853
	movi	a8, 0x4f8
	add.n	a8, a4, a8
	addx4	a5, a5, a8
	l32i	a7, a5, 0
	l32r	a11, .LC1830
	addx4	a8, a6, a8
	mov.n	a10, a7
	l32i	a6, a8, 8
	call8	strcmp
	bnez.n	a10, .L3398
	l32r	a11, .LC1832
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3854
	l32r	a11, .LC1834
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3855
	j	.L3398
.L3853:
	l32r	a7, .LC1457
	mov.n	a6, a7
.L3398:
	l32r	a11, .LC1739
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L3400
	l32r	a11, .LC1814
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3856
.L3400:
	l32r	a11, .LC1487
	mov.n	a10, a7
	call8	strcmp
	bnez.n	a10, .L3401
	l32r	a11, .LC1776
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3857
	l32r	a11, .LC1777
	mov.n	a10, a6
	call8	strcmp
	movi.n	a7, 4
	beqz.n	a10, .L3399
.L3401:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32i	a11, a8, 0
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3854:
	movi.n	a7, 0
	j	.L3399
.L3855:
	movi.n	a7, 1
	j	.L3399
.L3856:
	movi.n	a7, 2
	j	.L3399
.L3857:
	movi.n	a7, 3
.L3399:
	l32i	a8, a2, 72
	bnez.n	a8, .L3402
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32i	a11, a8, 0
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3402:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	bne	a10, a8, .L3403
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a15, 0
	movi.n	a14, 0
	movi.n	a13, 1
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3403:
	movi.n	a8, 0
	s32i	a8, sp, 224
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	l32i	a8, a2, 72
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	movi	a13, 0xe0
	mov.n	a12, a7
	add.n	a13, sp, a13
	callx8	a8
	mov.n	a7, a10
	movi.n	a6, 0
	bnez.n	a10, .L3404
	movi	a8, 0x6b0
	l32i	a6, sp, 224
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a12, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
.L3404:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a15, a6
	movi.n	a14, 0
	mov.n	a13, a7
	mov.n	a12, a3
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3360:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3405
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a3, a8, 0
	beqz.n	a3, .L3406
.L3405:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3407
	addi.n	a10, a10, 1
.L3407:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3406:
	s32i	a3, sp, 224
	addi.n	a6, a6, 2
	l32r	a4, .LC1837
	bne	a7, a6, .L3409
	movi	a11, 0xe0
	add.n	a11, sp, a11
	movi	a8, 0x4f8
	add.n	a8, a11, a8
	addx4	a8, a5, a8
	l32i	a10, a8, 0
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3409
	l32i	a7, sp, 224
	movi	a9, 0xf6
	addi.n	a8, a7, -1
	bltu	a9, a8, .L3409
	l32i	a8, a2, 92
	bnez.n	a8, .L4571
	j	.L3410
.L3409:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1691
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3410:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L4571:
	l32i	a10, a2, 0
	mov.n	a11, a7
	callx8	a8
	movi	a8, 0x6b0
	s32i	a3, sp, 8
	s32i	a3, sp, 4
	s32i	a3, sp, 0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a13, a10
	movi.n	a15, 0
	mov.n	a14, a7
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3358:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3412
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a9, a8, 0
	beqz.n	a9, .L3413
.L3412:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3414
	addi.n	a10, a10, 1
.L3414:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3413:
	l32i	a3, a2, 96
	bnez.n	a3, .L3416
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1524
	l32r	a12, .LC1838
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3416:
	addi.n	a4, a6, 3
	sub	a11, a4, a7
	movi.n	a8, 1
	mov.n	a10, a9
	movnez	a10, a8, a11
	beqz.n	a10, .L3417
	sub	a10, a7, a5
	moveqz	a8, a9, a10
	beqz.n	a8, .L3417
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1838
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3417:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a9, a8, 0x200
	movi.n	a10, 0
	s8i	a10, a9, 152
	s8i	a10, a9, 153
	bne	a4, a7, .L3423
	movi	a9, 0x4f8
	add.n	a8, a8, a9
	addx4	a8, a5, a8
	l32i	a5, a8, 0
	mov.n	a10, a5
	call8	strlen
	bnei	a10, 2, .L3419
	l8ui	a8, a5, 0
	movi	a9, 0x78
	bne	a8, a9, .L3420
	l8ui	a10, a5, 1
	movi.n	a9, 0
	addi	a8, a10, -48
	extui	a8, a8, 0, 8
	bltui	a8, 4, .L3421
	j	.L3419
.L3420:
	movi	a9, 0x79
	bne	a8, a9, .L3419
	l8ui	a10, a5, 1
	addi	a8, a10, -48
	extui	a8, a8, 0, 8
	bltui	a8, 2, .L3860
.L3419:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1838
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3860:
	movi.n	a9, 4
.L3421:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a5, a8, 0x200
	addx4	a8, a6, a8
	addmi	a8, a8, 0x500
	l32i	a6, a8, 0
	add.n	a9, a9, a10
	addi	a9, a9, -48
	l32r	a11, .LC1839
	s8i	a9, a5, 152
	mov.n	a10, a6
	call8	strcmp
	movi.n	a8, 2
	beqz.n	a10, .L4593
.L3422:
	l32r	a11, .LC1840
	mov.n	a10, a6
	call8	strcmp
	bnez.n	a10, .L3424
	movi.n	a8, 1
.L4593:
	s8i	a8, a5, 153
	j	.L3423
.L3424:
	l32r	a11, .LC1501
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3423
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1838
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3423:
	movi	a8, 0xe0
	add.n	a10, sp, a8
	movi.n	a11, 0
	movi.n	a12, 0x18
	call8	memset
	mov.n	a8, a10
	movi.n	a11, 0
	l32i	a10, a2, 0
	bne	a4, a7, .L3426
	movi	a11, 0x298
	add.n	a11, a8, a11
.L3426:
	movi	a12, 0xe0
	add.n	a12, sp, a12
	movi	a7, 0x124
	callx8	a3
	add.n	a7, a2, a7
	beqz.n	a10, .L3862
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110actionNameENS0_6ActionE
	l32r	a14, .LC1441
	mov.n	a15, a10
	j	.L3427
.L3862:
	l32r	a14, .LC1440
	l32r	a15, .LC1450
.L3427:
	l8ui	a8, sp, 245
	l32r	a12, .LC1842
	s32i	a8, sp, 36
	l8ui	a8, sp, 244
	l32r	a11, .LC1602
	s32i	a8, sp, 32
	l8ui	a8, sp, 243
	mov.n	a10, a7
	s32i	a8, sp, 28
	l8ui	a8, sp, 242
	s32i	a8, sp, 24
	l8ui	a8, sp, 241
	s32i	a8, sp, 20
	l8ui	a8, sp, 240
	s32i	a8, sp, 16
	l32i	a8, sp, 236
	s32i	a8, sp, 12
	l32i	a8, sp, 232
	s32i	a8, sp, 8
	l8ui	a8, sp, 228
	s32i	a8, sp, 4
	l32i	a8, sp, 224
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	call8	snprintf
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3366:
	addi.n	a8, a6, 2
	movi.n	a10, 0
	bne	a7, a8, .L3357
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a5, a8
	l32r	a11, .LC1443
	l32i	a10, a8, 0
	call8	strcmp
	nsau	a10, a10
	srli	a10, a10, 5
	j	.L3357
.L3847:
	movi.n	a10, 0
.L3357:
	l32r	a8, .LC1597
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3428
	l32r	a8, .LC1598
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3429
.L3428:
	movi.n	a8, 0xd
	beq	a3, a8, .L3866
	beqz.n	a10, .L3431
.L3429:
	addi	a8, a3, -22
	extui	a8, a8, 0, 8
	bltui	a8, 2, .L3432
	j	.L4572
.L3431:
	l32r	a8, .LC1599
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L3434
	addi.n	a10, a10, 1
.L3434:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L2775
.L3432:
	l32i	a8, a2, 136
	bnez.n	a8, .L3435
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1524
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3435:
	movi	a8, 0xe0
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	add.n	a8, sp, a8
	s32i	a8, a9, 0
	l32i	a8, a9, 0
	movi	a9, 0x6c8
	addmi	a4, a8, 0x200
	movi	a8, 0x98
	add.n	a8, a4, a8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a10, a9, 0
	movi	a12, 0x70
	movi.n	a11, 0
	call8	memset
	movi.n	a8, 0
	s32i	a8, a4, 172
	s32i	a8, a4, 188
	s32i	a8, a4, 212
	movi	a8, 0x6d0
	movi.n	a14, 2
	add.n	a8, a8, sp
	s32i	a14, a8, 0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a10, 1
	s8i	a10, a4, 218
	s8i	a10, a4, 241
	movi	a10, 0x4f8
	add.n	a15, a8, a10
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	addi	a12, a3, -23
	movi.n	a9, 1
	l32i	a13, a8, 0
	addi.n	a11, a7, -1
	extui	a10, a5, 0, 16
	nsau	a12, a12
	s32i	a9, a4, 168
	s32i	a9, a4, 184
	s32i	a9, a4, 208
	s8i	a14, a4, 220
	sub	a11, a11, a6
	addx4	a10, a10, a15
	srli	a12, a12, 5
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111axisRequestEPKPcjbRNS0_11AxisCommandE$constprop$0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	extui	a7, a10, 0, 8
	addmi	a6, a8, 0x400
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	s32i	a10, a6, 136
	l32i	a10, a8, 0
	s32i	a11, a6, 140
	s32i	a12, a6, 144
	movi.n	a11, 0
	movi	a12, 0x180
	call8	memset
	movi.n	a4, 1
	s8i	a4, sp, 224
	s32i	a4, sp, 244
	s32i	a4, sp, 252
	s32i	a4, sp, 264
	s32i	a4, sp, 276
	s32i	a4, sp, 288
	s32i	a4, sp, 300
	addmi	a12, sp, 0x100
	l32r	a10, .LC1939
	s8i	a4, a12, 60
	s8i	a4, a12, 64
	s32i	a10, sp, 328
	movi.n	a10, 0
	s32i	a10, sp, 344
	l32r	a10, .LC1937
	l32r	a11, .LC1940
	s32i	a10, sp, 348
	movi.n	a10, -1
	s32i	a10, sp, 352
	l32r	a10, .LC1938
	movi.n	a8, 0
	s32i	a10, sp, 356
	movi	a10, 0x6d0
	add.n	a10, a10, sp
	movi.n	a9, 1
	l32i	a14, a10, 0
	s32i	a8, sp, 428
	s32i	a11, sp, 332
	s32i	a9, sp, 424
	s8i	a4, a12, 178
	s8i	a14, a12, 180
	s8i	a4, a12, 201
	s32i	a8, sp, 500
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a9, sp, 496
	addmi	a8, a8, 0x100
	s8i	a4, a8, 104
	beqz.n	a7, .L3439
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a6, 0x124
	l32i	a3, a8, 0
	l32r	a4, .LC1441
	add.n	a6, a2, a6
	j	.L3440
.L3439:
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	l32i	a8, a2, 136
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	callx8	a8
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a10, a6, 136
	s32i	a11, a6, 140
	s32i	a12, a6, 144
	extui	a7, a10, 0, 8
	movi	a6, 0x124
	l32i	a3, a8, 0
	l32r	a4, .LC1441
	add.n	a6, a2, a6
	bnez.n	a7, .L3440
	l32r	a4, .LC1440
.L3440:
	mov.n	a10, a7
	movi	a5, 0xe0
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	add.n	a5, sp, a5
	addmi	a8, a5, 0x400
	l32i	a8, a8, 140
	s32i	a10, sp, 0
	s32i	a8, sp, 4
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	l32r	a12, .LC1844
	l32r	a11, .LC1602
	mov.n	a15, a4
	mov.n	a14, a3
	mov.n	a10, a6
	call8	snprintf
	l32r	a8, .LC1845
	bgeu	a8, a10, .L3441
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3441:
	addmi	a8, a5, 0x500
	s32i	a10, a8, 80
	bnez.n	a7, .L3442
	addmi	a8, a5, 0x200
	l8ui	a8, a8, 152
	movi.n	a13, 1
	addi	a8, a8, -3
	movi	a11, 0x550
	movnez	a13, a7, a8
	mov.n	a12, a5
	add.n	a11, a5, a11
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18axisViewEPcjRjRKNS0_8AxisViewEb$constprop$0
	bnez.n	a10, .L3443
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3442:
	movi	a12, 0x550
	l32r	a13, .LC1847
	l32r	a11, .LC1602
	add.n	a12, a5, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3443
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3443:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L4572:
	bnei	a3, 16, .L3444
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1566
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3444:
	movi.n	a8, 0xf
	bne	a3, a8, .L3866
	bltu	a5, a7, .L3445
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1634
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3445:
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a5, a8
	l32i	a6, a8, 0
	l32r	a11, .LC1583
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3867
	l32r	a11, .LC1848
	mov.n	a10, a6
	call8	strcmp
	beqz.n	a10, .L3868
	l32r	a11, .LC1849
	mov.n	a10, a6
	call8	strcmp
	l32r	a8, .LC1493
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	beqz.n	a10, .L3430
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1634
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3866:
	mov.n	a5, a6
	j	.L3430
.L3867:
	l32r	a8, .LC1492
	j	.L4594
.L3868:
	l32r	a8, .LC1491
.L4594:
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L3430:
	movi	a9, 0x6c0
	addi.n	a7, a7, -1
	movi.n	a8, 0
	add.n	a9, a9, sp
	sub	a7, a7, a5
	s32i	a8, a9, 0
	beqz.n	a7, .L3446
	movi	a8, 0x5d8
	add.n	a8, sp, a8
	addx4	a8, a5, a8
	l32i	a8, a8, 4
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L3446:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6d0
	l8ui	a4, a8, 4
	add.n	a9, a9, sp
	addi	a8, a4, -18
	extui	a8, a8, 0, 8
	movi	a10, 0x6d0
	s32i	a8, a9, 0
	add.n	a10, a10, sp
	l32i	a10, a10, 0
	addi	a6, a4, -6
	movi.n	a9, 1
	extui	a6, a6, 0, 8
	movi.n	a8, 2
	saltu	a6, a9, a6
	saltu	a8, a8, a10
	addi.n	a6, a6, -1
	addi.n	a8, a8, -1
	neg	a8, a8
	neg	a6, a6
	addi	a3, a4, -5
	or	a6, a6, a8
	nsau	a3, a3
	movi.n	a8, 0
	srli	a3, a3, 5
	moveqz	a8, a9, a4
	or	a8, a3, a8
	extui	a6, a6, 0, 8
	bnez.n	a8, .L3447
	bnez.n	a6, .L3871
	addi	a10, a4, -12
	extui	a10, a10, 0, 8
	bltui	a10, 2, .L3872
	movi.n	a10, 0x15
	bne	a4, a10, .L3448
	bltui	a7, 3, .L3449
	j	.L3450
.L3448:
	bnei	a4, 10, .L3451
	mov.n	a8, a6
	moveqz	a8, a9, a7
	bnez.n	a8, .L3449
	addi	a8, a7, -3
	movnez	a9, a6, a8
	bnez.n	a9, .L3449
	j	.L3450
.L3451:
	movi.n	a10, 0xe
	bne	a4, a10, .L3447
	addi.n	a10, a7, -1
	mov.n	a8, a9
	movnez	a8, a6, a10
	j	.L3452
.L3871:
	mov.n	a8, a6
	j	.L3447
.L3872:
	movi.n	a8, 1
.L3447:
	saltu	a8, a8, a7
	addi.n	a8, a8, -1
	neg	a8, a8
	extui	a8, a8, 0, 8
	j	.L3452
.L3450:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3449:
	movi	a10, 0xe0
	add.n	a10, sp, a10
	movi.n	a8, 0
	addmi	a9, a10, 0x500
	s32i	a8, a9, 196
	s32i	a8, a9, 192
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a12, 1
	addi	a11, a4, -12
	moveqz	a12, a8, a8
	extui	a11, a11, 0, 8
	movi.n	a8, 2
	saltu	a8, a8, a11
	addi.n	a8, a8, -1
	neg	a8, a8
	extui	a8, a8, 0, 8
	beqz.n	a8, .L4003
	beqz.n	a12, .L3457
	j	.L3453
.L4003:
	beqz.n	a12, .L3457
	bnez.n	a6, .L3455
	j	.L3457
.L3453:
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a9, a8, 0
	movi	a8, 0x6c0
	movi	a11, 0x5c0
	add.n	a8, a8, sp
	add.n	a11, a10, a11
	l32i	a10, a8, 0
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3458
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	l32i	a8, a9, 192
	bnez.n	a8, .L3459
	j	.L3458
.L3457:
	beqz.n	a3, .L3459
	beqz.n	a12, .L3459
	j	.L3460
.L3458:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1851
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3455:
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	s32i	a9, a8, 0
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a12, a8, 0
	movi	a8, 0x6c0
	movi	a11, 0x5c4
	add.n	a8, a8, sp
	add.n	a11, a10, a11
	l32i	a10, a8, 0
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3462
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	movi	a10, 0x6c8
	l32i	a8, a9, 196
	add.n	a10, a10, sp
	addi.n	a8, a8, -1
	movi	a9, 0xf6
	l32i	a12, a10, 0
	bgeu	a9, a8, .L3457
.L3462:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1691
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3460:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32r	a11, .LC1853
	l32i	a10, a8, 0
	call8	strcmp
	beqz.n	a10, .L3459
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3459:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a3, a8, 0x500
	movi.n	a10, 0
	s32i	a10, a3, 112
	s32i	a10, a3, 116
	s32i	a10, a3, 120
	beqz.n	a7, .L3463
	bnei	a4, 10, .L3463
	movi	a9, 0x570
	movi	a10, 0x6c8
	add.n	a9, a8, a9
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	movi	a10, 0x4f8
	add.n	a8, a8, a10
	addx4	a10, a5, a8
	l32i	a10, a10, 4
	mov.n	a11, a9
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	movi	a8, 0x5d8
	add.n	a8, a8, sp
	bnez.n	a10, .L3464
.L3465:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1592
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3464:
	l32r	a11, .LC1439
	l32i	a10, a3, 112
	bltu	a11, a10, .L3465
	addx4	a10, a5, a8
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a10, a10, 8
	addi.n	a11, a8, 4
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3465
	movi.n	a11, 0x20
	l32i	a10, a3, 116
	addmi	a11, a11, 0x4e00
	bltu	a11, a10, .L3465
	movi	a8, 0x5d8
	movi	a9, 0x6c8
	add.n	a8, a8, sp
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	addx4	a8, a5, a8
	l32i	a10, a8, 12
	addi.n	a11, a9, 8
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3465
	l32i	a8, a3, 120
	movi	a9, 0x100
	bltu	a9, a8, .L3465
.L3463:
	movi	a8, 0xe0
	add.n	a3, sp, a8
	addmi	a9, a3, 0x500
	movi.n	a8, 0
	s8i	a8, a9, 80
	movi.n	a8, 0
	s32i	a8, a9, 84
	s32i	a8, a9, 88
	movi.n	a8, 0x15
	bne	a4, a8, .L3466
	beqz.n	a7, .L3472
	bnei	a7, 1, .L3468
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32r	a11, .LC1443
	l32i	a10, a8, 0
	call8	strcmp
	beqz.n	a10, .L3472
.L3469:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1592
	l32r	a12, .LC1856
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3468:
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a9, a8, 0
	bnei	a7, 2, .L3469
	movi	a8, 0x6c0
	movi	a12, 0x550
	add.n	a8, a8, sp
	add.n	a12, a3, a12
	l32i	a10, a8, 0
	addi.n	a11, a12, 4
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3469
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	l32r	a10, .LC1857
	l32i	a8, a9, 84
	movi	a12, 0x630
	addi	a8, a8, -100
	add.n	a12, a12, sp
	bltu	a10, a8, .L3469
	addx4	a8, a5, a3
	addmi	a8, a8, 0x500
	l32i	a10, a8, 0
	addi.n	a11, a12, 8
	call8	_ZN21MotorControlRSExample5Probe14ConsoleNumbers6numberEPKcRm
	beqz.n	a10, .L3469
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a9, a8, 0
	movi	a10, 0x3e7
	l32i	a8, a9, 88
	addi.n	a8, a8, -1
	bltu	a10, a8, .L3469
	movi.n	a8, 1
	s8i	a8, a9, 80
	j	.L3472
.L3466:
	beqz.n	a4, .L3470
	movi.n	a3, 0
	beqi	a4, 10, .L3471
	j	.L3472
.L3470:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	beqz.n	a8, .L3472
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_14findEPKc
	mov.n	a3, a10
	bnez.n	a10, .L3473
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1553
	l32r	a12, .LC1859
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3472:
	movi.n	a3, 0
	j	.L3474
.L3473:
	l8ui	a8, a10, 4
	bnei	a8, 10, .L3474
.L3471:
	l32i	a8, a2, 80
	bnez.n	a8, .L3474
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1524
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3474:
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	mov.n	a5, a10
	beqz.n	a10, .L3475
	bnei	a4, 5, .L3476
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	beqz.n	a8, .L3477
	l32i	a8, a2, 76
	bnez.n	a8, .L4573
	j	.L3475
.L3477:
	l32i	a8, a2, 12
	bnez.n	a8, .L4574
	j	.L3475
.L3476:
	beqz.n	a3, .L3480
.L3706:
	l8ui	a11, a3, 4
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	bnez.n	a10, .L3481
.L3475:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1524
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3480:
	beqz.n	a4, .L3875
	j	.L3483
.L3700:
	mov.n	a11, a2
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18helpTextERKNS1_5EntryERKNS0_4HostE
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	s32i	a10, a8, 136
	s32i	a11, a8, 140
	s32i	a12, a8, 144
	s32i	a13, a8, 148
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	mov.n	a14, a10
	s32i	a11, a8, 0
	mov.n	a15, a12
	extui	a4, a13, 0, 8
	j	.L3482
.L3875:
	movi	a9, 0x6b8
	movi.n	a8, 0
	add.n	a9, a9, sp
	movi.n	a15, 0
	s32i	a8, a9, 0
	movi.n	a14, 0
.L3482:
	l8ui	a8, a2, 141
	bnez.n	a8, .L3484
	movi	a7, 0xe0
	add.n	a7, sp, a7
	addmi	a9, a7, 0x500
	s32i	a8, a9, 136
	movi	a6, 0x124
	beqz.n	a3, .L3485
	movi	a5, 0x588
	add.n	a5, a7, a5
	mov.n	a15, a14
	l32r	a13, .LC1861
	l32i	a14, a3, 0
	l32r	a11, .LC1602
	add.n	a6, a2, a6
	mov.n	a12, a5
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a7, a10
	beqz.n	a10, .L3486
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32r	a13, .LC1862
	l32r	a11, .LC1602
	mov.n	a12, a5
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a7, a10
.L3486:
	l8ui	a9, a3, 4
	movi.n	a8, 0x1b
	bne	a9, a8, .L3487
	beqz.n	a7, .L3487
	l32r	a13, .LC1864
	l32r	a11, .LC1602
	movi	a12, 0x668
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a7, a10
.L3487:
	l8ui	a10, a3, 4
	mov.n	a11, a2
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_111helpExampleENS1_7CommandERKNS0_4HostE
	mov.n	a14, a10
	beqz.n	a10, .L3488
	beqz.n	a7, .L3503
	movi	a12, 0x668
	l32r	a13, .LC1866
	l32r	a11, .LC1602
	add.n	a12, sp, a12
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3503
.L3491:
	movi	a12, 0x668
	l32r	a13, .LC1868
	l32r	a11, .LC1602
	add.n	a12, sp, a12
	mov.n	a10, a6
	j	.L4596
.L3488:
	bnez.n	a7, .L3491
	j	.L3503
.L3485:
	movi	a9, 0x6b8
	add.n	a8, a2, a6
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a10, a9, 0
	l32r	a13, .LC1870
	l32r	a11, .LC1602
	movi	a12, 0x588
	add.n	a12, a7, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	l32r	a11, .LC1872
	mov.n	a6, a10
	movi.n	a12, 0x1c
	mov.n	a10, a7
	call8	memcpy
	movi	a9, 0x6c0
	movi.n	a8, 0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L3500:
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a5, .LC1494
	add.n	a9, a7, a8
	l32i	a8, a9, 0
	movi	a9, 0x6d0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi.n	a4, 0
.L3499:
	l8ui	a3, a5, 4
	mov.n	a10, a2
	mov.n	a11, a3
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a10, a8, 0
	beqz.n	a10, .L3492
	movi.n	a9, 0x38
	l32r	a10, .LC1495
	bltu	a9, a3, .L3493
	l32r	a9, .LC1873
	addx4	a3, a3, a9
	l32i	a10, a3, 0
.L3493:
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	call8	strcmp
	bnez.n	a10, .L3492
	bnez.n	a4, .L3494
	bnez.n	a6, .L3495
.L3496:
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a4, a8, 0
	movi.n	a6, 0
	j	.L3492
.L3495:
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	movi	a12, 0x588
	l32r	a13, .LC1875
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	add.n	a12, a7, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3496
.L3498:
	movi	a8, 0x6b8
	movi	a3, 0x588
	add.n	a8, a8, sp
	add.n	a3, a7, a3
	l32i	a14, a5, 0
	l32r	a13, .LC1877
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	mov.n	a12, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3496
	j	.L3497
.L3494:
	bnez.n	a6, .L3498
	j	.L3496
.L3497:
	mov.n	a11, a2
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_18helpTextERKNS1_5EntryERKNS0_4HostE
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	mov.n	a14, a11
	s32i	a10, a7, 664
	s32i	a11, a7, 668
	s32i	a13, a7, 676
	l32r	a11, .LC1602
	l32r	a13, .LC1862
	l32i	a10, a8, 0
	s32i	a12, a7, 672
	mov.n	a12, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a4, a10
	beqz.n	a10, .L3496
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a13, .LC1879
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	mov.n	a12, a3
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	mov.n	a6, a10
.L3492:
	l32r	a9, .LC1880
	addi	a5, a5, 24
	bne	a5, a9, .L3499
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6c0
	addi.n	a8, a8, 4
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a9, 0x1c
	bne	a8, a9, .L3500
	l32i	a9, a2, 44
	beqz.n	a9, .L3501
	beqz.n	a6, .L3503
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	movi	a12, 0x668
	l32r	a13, .LC1882
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3503
.L3506:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	movi	a12, 0x668
	l32r	a13, .LC1884
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	add.n	a12, sp, a12
.L4596:
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3490
	j	.L3503
.L3501:
	bnez.n	a6, .L3506
.L3503:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1859
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3490:
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3484:
	beqz.n	a3, .L3509
	movi	a10, 0x124
	l32r	a8, .LC1441
	add.n	a10, a2, a10
	beqz.n	a4, .L3510
	l32r	a8, .LC1440
.L3510:
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	l32r	a12, .LC1886
	l32r	a11, .LC1602
	call8	snprintf
	j	.L3511
.L3509:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	movi	a6, 0x124
	l32i	a13, a8, 0
	l32r	a12, .LC1888
	l32r	a11, .LC1602
	add.n	a6, a2, a6
	mov.n	a10, a6
	call8	snprintf
	mov.n	a7, a10
	l32r	a4, .LC1494
	j	.L3512
.L3517:
	l8ui	a11, a4, 4
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	beqz.n	a10, .L3513
	l32r	a13, .LC1496
	add.n	a10, a6, a7
	beqz.n	a5, .L3514
	l32r	a13, .LC1457
.L3514:
	l32i	a14, a4, 0
	l32r	a12, .LC1889
	mov.n	a11, a3
	call8	snprintf
	bltz	a10, .L3515
	bltu	a10, a3, .L3516
.L3515:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1859
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3516:
	add.n	a7, a7, a10
	movi.n	a5, 0
.L3513:
	addi	a4, a4, 24
.L3512:
	l32r	a8, .LC1880
	addmi	a3, a7, -0x4000
	neg	a3, a3
	bne	a4, a8, .L3517
	bgeui	a3, 3, .L3518
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1859
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3518:
	l32r	a12, .LC1890
	mov.n	a11, a3
	add.n	a10, a6, a7
	call8	snprintf
.L3511:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3483:
	bnei	a4, 1, .L3519
	movi.n	a8, 0xa
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a15, .LC1891
	l32i	a14, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	l32r	a12, .LC1893
	l32r	a11, .LC1602
	movi	a10, 0x124
	add.n	a10, a2, a10
	call8	snprintf
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3519:
	movi.n	a8, 0x11
	bne	a4, a8, .L3520
	call8	_ZN14MotorControlRS6ESS_RS16readCapabilitiesEv
	movi	a13, 0xe0
	add.n	a13, sp, a13
	s32i	a10, a13, 664
	s32i	a11, a13, 668
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, a13
	call8	memset
	movi.n	a9, 0x14
	l32r	a8, .LC1579
	s32i	a9, sp, 300
	l32r	a9, .LC1620
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	s32i	a9, sp, 308
	movi.n	a8, 1
	l32r	a9, .LC1621
	s8i	a8, sp, 248
	movi.n	a8, 1
	s32i	a8, sp, 252
	s32i	a9, sp, 312
	s32i	a9, sp, 316
	addmi	a9, sp, 0x100
	s8i	a8, a9, 88
	l32r	a8, .LC1457
	s32i	a8, sp, 404
	movi.n	a8, 0x40
	s32i	a8, sp, 480
	movi.n	a8, 0xa
	s32i	a8, sp, 532
	l32i	a8, a2, 12
	beqz.n	a8, .L3522
	mov.n	a11, a10
	l32i	a10, a2, 0
	callx8	a8
.L3522:
	movi	a8, 0x2e0
	l32r	a9, .LC1441
	add.n	a8, sp, a8
	movi	a10, 0x6b8
	add.n	a10, a10, sp
	l8ui	a8, a8, 152
	movi	a7, 0x124
	s32i	a9, a10, 0
	add.n	a7, a2, a7
	beqz.n	a8, .L3523
	movi.n	a11, 6
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a8, .LC1440
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	bnez.n	a10, .L3523
	l32r	a8, .LC1441
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L3523:
	movi	a8, 0x2e0
	l32r	a9, .LC1441
	add.n	a8, sp, a8
	movi	a10, 0x6c0
	add.n	a10, a10, sp
	l8ui	a8, a8, 153
	s32i	a9, a10, 0
	beqz.n	a8, .L3524
	movi.n	a11, 0x12
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a8, .LC1440
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	bnez.n	a10, .L3524
	l32r	a8, .LC1441
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
.L3524:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 154
	l32r	a5, .LC1441
	beqz.n	a8, .L3525
	movi.n	a11, 0x13
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a5, .LC1440
	bnez.n	a10, .L3525
	l32r	a5, .LC1441
.L3525:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 155
	l32r	a4, .LC1441
	beqz.n	a8, .L3526
	movi.n	a11, 0x14
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a4, .LC1440
	bnez.n	a10, .L3526
	l32r	a4, .LC1441
.L3526:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 156
	l32r	a3, .LC1441
	beqz.n	a8, .L3527
	l32i	a8, a2, 24
	beqz.n	a8, .L3527
	l32i	a8, a2, 12
	l32r	a3, .LC1440
	bnez.n	a8, .L3527
	l32r	a3, .LC1441
.L3527:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 157
	l32r	a6, .LC1441
	beqz.n	a8, .L3528
	l32i	a8, a2, 24
	beqz.n	a8, .L3528
	l32i	a8, a2, 12
	l32r	a6, .LC1440
	bnez.n	a8, .L3528
	l32r	a6, .LC1441
.L3528:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a9, a8, 158
	movi	a10, 0x6f0
	add.n	a10, a10, sp
	l8ui	a8, a8, 159
	s32i	a9, a10, 0
	movi	a9, 0x6f8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi.n	a11, 0x18
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	s32i	a10, a8, 0
	movi	a9, 0x6e8
	l32i	a8, a2, 48
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32r	a8, .LC1440
	bnez.n	a10, .L3529
	movi.n	a11, 0x1c
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a8, .LC1440
	bnez.n	a10, .L3529
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	beqz.n	a8, .L3530
	l32i	a8, a2, 12
	beqz.n	a8, .L3530
	l32i	a9, a2, 136
	l32r	a8, .LC1440
	bnez.n	a9, .L3529
.L3530:
	movi.n	a11, 0x1f
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32i	a9, a2, 56
	l32r	a8, .LC1440
	bnez.n	a10, .L3529
	beqz.n	a9, .L3531
	l32i	a8, a2, 12
	beqz.n	a8, .L3531
	l32i	a9, a2, 136
	l32r	a8, .LC1440
	bnez.n	a9, .L3529
.L3531:
	movi.n	a11, 0x26
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a8, .LC1440
	bnez.n	a10, .L3529
	movi.n	a11, 0x27
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a8, .LC1440
	bnez.n	a10, .L3529
	movi.n	a11, 0x28
	mov.n	a10, a2
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a8, .LC1440
	bnez.n	a10, .L3529
	l32r	a8, .LC1441
.L3529:
	l32i	a9, a2, 36
	l32r	a11, .LC1441
	beqz.n	a9, .L3532
	l32i	a9, a2, 12
	beqz.n	a9, .L3532
	l32i	a9, a2, 136
	l32r	a11, .LC1440
	bnez.n	a9, .L3532
	l32r	a11, .LC1441
.L3532:
	l32r	a12, .LC1441
	addmi	a9, sp, 0x100
	movi	a13, 0x6e0
	add.n	a13, a13, sp
	l8ui	a10, a9, 130
	s32i	a12, a13, 0
	beqz.n	a10, .L3533
	l32r	a10, .LC1440
	s32i	a10, a13, 0
.L3533:
	l32r	a10, .LC1441
	movi	a12, 0x6d8
	add.n	a12, a12, sp
	l8ui	a9, a9, 131
	s32i	a10, a12, 0
	beqz.n	a9, .L3534
	l32r	a9, .LC1440
	s32i	a9, a12, 0
.L3534:
	l32r	a9, .LC1500
	movi	a10, 0x6d0
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	beqz.n	a9, .L3535
	l32r	a9, .LC1498
	movi	a10, 0x6d0
	add.n	a10, a10, sp
	s32i	a9, a10, 0
.L3535:
	movi	a9, 0x6e8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	l32r	a12, .LC1441
	beqz.n	a9, .L3536
	l32i	a9, a2, 12
	beqz.n	a9, .L3536
	l32i	a9, a2, 136
	l32r	a12, .LC1440
	bnez.n	a9, .L3536
	l32r	a12, .LC1441
.L3536:
	l32i	a15, a2, 52
	l32r	a13, .LC1441
	beqz.n	a15, .L3537
	l32i	a9, a2, 12
	l32r	a13, .LC1440
	bnez.n	a9, .L3537
	l32r	a13, .LC1441
.L3537:
	l32i	a9, a2, 56
	beqz.n	a9, .L3538
	l32i	a9, a2, 12
	beqz.n	a9, .L3538
	l32i	a9, a2, 136
	bnez.n	a9, .L3539
.L3538:
	l32r	a10, .LC1441
	mov.n	a9, a10
	beqz.n	a15, .L3540
	l32i	a15, a2, 12
	beqz.n	a15, .L3540
.L3705:
	l32r	a9, .LC1440
.L3540:
	l32i	a14, a2, 104
	l32r	a15, .LC1441
	beqz.n	a14, .L3541
	l32r	a15, .LC1440
.L3541:
	s32i	a9, sp, 64
	s32i	a9, sp, 60
	s32i	a9, sp, 56
	movi	a9, 0x6d0
	s32i	a10, sp, 52
	s32i	a12, sp, 44
	s32i	a15, sp, 68
	s32i	a13, sp, 48
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	l32r	a12, .LC1895
	s32i	a9, sp, 40
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	mov.n	a10, a7
	s32i	a9, sp, 36
	movi	a9, 0x6e0
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	s32i	a8, sp, 24
	movi	a8, 0x6f8
	s32i	a9, sp, 32
	s32i	a11, sp, 28
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a11, .LC1602
	s32i	a8, sp, 20
	movi	a8, 0x6f0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a6, sp, 12
	s32i	a8, sp, 16
	movi	a8, 0x6c0
	s32i	a3, sp, 8
	s32i	a4, sp, 4
	s32i	a5, sp, 0
	add.n	a8, a8, sp
	l32i	a15, a8, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	call8	snprintf
	mov.n	a10, a7
	call8	strlen
	movi	a8, 0x4e0
	add.n	a8, sp, a8
	s32i	a10, a8, 136
	beqz.n	a10, .L3542
	addi.n	a10, a10, -1
	s32i	a10, a8, 136
.L3542:
	l32i	a8, a2, 108
	l32r	a5, .LC1441
	beqz.n	a8, .L3543
	l32r	a5, .LC1440
.L3543:
	call8	_ZN14MotorControlRS21discoveryProfileCountEv
	l32i	a8, a2, 52
	l32r	a9, .LC1441
	mov.n	a15, a10
	beqz.n	a8, .L3544
	l32i	a8, a2, 12
	l32r	a9, .LC1440
	bnez.n	a8, .L3544
	l32r	a9, .LC1441
.L3544:
	movi	a8, 0xe0
	add.n	a6, sp, a8
	movi.n	a8, 8
	s32i	a8, sp, 4
	movi	a12, 0x488
	movi.n	a8, 4
	l32r	a13, .LC1897
	l32r	a11, .LC1602
	s32i	a9, sp, 12
	s32i	a9, sp, 8
	s32i	a8, sp, 0
	mov.n	a14, a5
	add.n	a12, a6, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3545
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1647
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3545:
	mov.n	a10, a7
	call8	strlen
	addmi	a8, a6, 0x400
	s32i	a10, a8, 136
	beqz.n	a10, .L3547
	addi.n	a10, a10, -1
	s32i	a10, a8, 136
.L3547:
	movi.n	a11, 0x36
	mov.n	a10, a2
	l32i	a6, a2, 64
	call8	_ZZN21MotorControlRSExample5Probe7Console8dispatchEvENKUlNS0_12_GLOBAL__N_17CommandEE_clES3_$isra$0
	l32r	a14, .LC1441
	beqz.n	a10, .L3548
	l32r	a14, .LC1440
.L3548:
	l32r	a15, .LC1441
	beqz.n	a6, .L3549
	l32r	a15, .LC1440
.L3549:
	movi	a12, 0x568
	l32r	a13, .LC1899
	l32r	a11, .LC1602
	s32i	a15, sp, 8
	s32i	a15, sp, 4
	s32i	a15, sp, 0
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3550
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1604
	l32r	a12, .LC1647
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3550:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3520:
	bnei	a4, 5, .L3551
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	beqz.n	a8, .L3552
.L3707:
	l32i	a8, a2, 76
	l32i	a10, a2, 0
	callx8	a8
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a15, 0
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3551:
	addi	a8, a4, -8
	extui	a8, a8, 0, 8
	movi.n	a9, 0xd
	bltu	a9, a8, .L3552
	l32r	a9, .LC1900
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L3554:
	.word	.L3558
	.word	.L3552
	.word	.L3557
	.word	.L3552
	.word	.L3556
	.word	.L3555
	.word	.L3555
	.word	.L3552
	.word	.L3552
	.word	.L3552
	.word	.L3552
	.word	.L3552
	.word	.L3552
	.word	.L3553
	.text
.L3558:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	bne	a10, a8, .L3559
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a15, 0
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 1
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3559:
	movi	a9, 0x6b0
	add.n	a9, a9, sp
	movi	a7, 0xe0
	l32i	a8, a2, 68
	l32i	a11, a9, 0
	l32i	a10, a2, 0
	add.n	a7, sp, a7
	movi	a12, 0x5c0
	add.n	a12, a7, a12
	callx8	a8
	mov.n	a6, a10
	bnez.n	a10, .L3560
	addmi	a7, a7, 0x500
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a7, a7, 192
	l32i	a11, a8, 0
	mov.n	a12, a7
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a12, a8, 0
	j	.L3561
.L3560:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a7, 0
	l32i	a12, a8, 0
.L3561:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a15, a7
	movi.n	a14, 0
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3555:
	movi	a8, 0x5e0
	add.n	a8, sp, a8
	l32i	a11, a8, 192
	movi.n	a8, 0xd
	l32i	a10, a2, 0
	bne	a4, a8, .L3562
	l32i	a8, a2, 128
	j	.L4597
.L3562:
	l32i	a8, a2, 132
.L4597:
	callx8	a8
	movi.n	a9, 0
	movi	a8, 0x5e0
	s32i	a9, sp, 8
	s32i	a9, sp, 4
	s32i	a9, sp, 0
	add.n	a8, sp, a8
	l32i	a15, a8, 192
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	mov.n	a13, a10
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3556:
	movi	a7, 0xe0
	add.n	a7, sp, a7
	movi	a12, 0x140
	movi.n	a11, 0
	mov.n	a10, a7
	call8	memset
	l32r	a8, .LC1579
	addmi	a6, sp, 0x100
	s32i	a8, sp, 228
	l32r	a8, .LC1457
	addmi	a9, a7, 0x100
	s32i	a8, sp, 404
	movi.n	a8, 1
	s8i	a8, a6, 200
	s8i	a8, a9, 56
	addmi	a9, a7, 0x500
	l32i	a8, a2, 124
	l32i	a11, a9, 192
	l32i	a10, a2, 0
	mov.n	a12, a7
	callx8	a8
	bnez.n	a10, .L3565
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1524
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3565:
	l32i	a5, sp, 224
	beqz.n	a5, .L3567
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a13, 1
	mov.n	a12, a5
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18formatSimpleMotionEmRKNS0_16SimpleMotionViewEb
	j	.L2775
.L3567:
	l32i	a12, sp, 236
	addi.n	a11, a7, 4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	l32i	a14, sp, 296
	l8ui	a8, sp, 249
	l32i	a12, sp, 240
	l32i	a13, sp, 244
	beqz.n	a14, .L3568
	bnez.n	a8, .L3569
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a15, 1
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console11formatGroupEmmmRKNS0_11GroupResultEb
	bnez.n	a10, .L2775
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1901
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3569:
	l8ui	a8, a14, 0
	movi	a10, 0x124
	s32i	a5, sp, 888
	l32r	a9, .LC1501
	add.n	a10, a2, a10
	bgeui	a8, 4, .L3571
	l32r	a9, .LC1902
	addx4	a8, a8, a9
	l32i	a9, a8, 0
.L3571:
	movi	a8, 0x6b0
	s32i	a13, sp, 0
	movi	a7, 0x378
	s32i	a9, sp, 4
	add.n	a8, a8, sp
	add.n	a7, sp, a7
	l32i	a14, a8, 0
	l32r	a13, .LC1904
	l32r	a11, .LC1602
	mov.n	a15, a12
	mov.n	a12, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3572
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	beqz.n	a10, .L3572
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3572:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1901
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3568:
	l32i	a14, sp, 292
	beqz.n	a8, .L3573
	l8ui	a8, sp, 250
	movi	a7, 0x124
	l32r	a15, .LC1441
	add.n	a7, a2, a7
	beqz.n	a8, .L3574
	l32r	a15, .LC1440
.L3574:
	l8ui	a8, sp, 251
	l32r	a6, .LC1441
	beqz.n	a8, .L3575
	l32r	a6, .LC1440
.L3575:
	l32i	a8, sp, 260
	l32r	a10, .LC1504
	beqz.n	a8, .L3576
	l8ui	a8, a8, 20
	l32r	a10, .LC1503
	beqz.n	a8, .L3576
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 8
	l32r	a10, .LC1506
	bgeui	a8, 4, .L3576
	l32r	a9, .LC1905
	addx4	a8, a8, a9
	l32i	a10, a8, 0
.L3576:
	l32i	a11, sp, 264
	beqz.n	a11, .L3926
	l8ui	a5, a11, 16
	beqz.n	a5, .L3927
	addi.n	a8, a5, -1
	extui	a8, a8, 0, 8
	bgeui	a8, 4, .L3928
	l32r	a9, .LC1906
	addx4	a8, a8, a9
	l32i	a9, a8, 0
	l32r	a8, .LC1504
	bnei	a5, 3, .L3577
	l8ui	a11, a11, 17
	l32r	a8, .LC1508
	bnei	a11, 1, .L3577
	l32r	a8, .LC1507
	j	.L3577
.L3926:
	l32r	a9, .LC1504
	mov.n	a8, a9
	j	.L3577
.L3927:
	l32r	a9, .LC1512
	j	.L4598
.L3928:
	l32r	a9, .LC1510
.L4598:
	l32r	a8, .LC1504
.L3577:
	l32i	a5, sp, 268
	l32r	a11, .LC1504
	beqz.n	a5, .L3578
	l8ui	a4, a5, 99
	l32r	a11, .LC1516
	bnez.n	a4, .L3578
	l8ui	a5, a5, 98
	l32r	a11, .LC1514
	beqz.n	a5, .L3578
	l32r	a11, .LC1518
.L3578:
	l32i	a4, sp, 284
	l32r	a5, .LC1441
	beqz.n	a4, .L3579
	l32r	a5, .LC1440
.L3579:
	l32i	a3, sp, 288
	l32r	a4, .LC1441
	beqz.n	a3, .L3580
	l32r	a4, .LC1440
.L3580:
	l32r	a3, .LC1441
	beqz.n	a14, .L3581
	l32r	a3, .LC1440
.L3581:
	s32i	a8, sp, 16
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	s32i	a11, sp, 20
	s32i	a9, sp, 12
	s32i	a10, sp, 8
	s32i	a15, sp, 0
	s32i	a3, sp, 32
	s32i	a4, sp, 28
	s32i	a5, sp, 24
	s32i	a6, sp, 4
	mov.n	a15, a13
	mov.n	a14, a12
	l32i	a13, a8, 0
	l32r	a12, .LC1908
	l32r	a11, .LC1602
	mov.n	a10, a7
	call8	snprintf
	mov.n	a10, a7
	call8	strlen
	l8ui	a8, sp, 252
	s32i	a10, sp, 888
	beqz.n	a8, .L3582
	addi.n	a10, a10, -1
	l8ui	a8, sp, 253
	s32i	a10, sp, 888
	l32i	a14, sp, 256
	l32r	a15, .LC1441
	beqz.n	a8, .L3583
	l32r	a15, .LC1440
.L3583:
	movi	a12, 0x378
	l32r	a13, .LC1909
	l32r	a11, .LC1602
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3582
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1901
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3582:
	l32i	a9, sp, 268
	beqz.n	a9, .L3585
	l32i	a8, sp, 888
	l32r	a14, .LC1441
	addi.n	a8, a8, -1
	s32i	a8, sp, 888
	l8ui	a8, a9, 1
	bnei	a8, 1, .L3586
	l32r	a14, .LC1440
.L3586:
	movi	a5, 0xe0
	add.n	a5, sp, a5
	movi	a6, 0x298
	add.n	a6, a5, a6
	l32r	a13, .LC1911
	l32r	a11, .LC1602
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3587
.L3589:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1901
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3587:
	l32i	a8, sp, 272
	bnez.n	a8, .L3588
.L3590:
	movi	a12, 0x378
	l32r	a13, .LC1605
	l32r	a11, .LC1602
	add.n	a12, sp, a12
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3585
	j	.L3589
.L3588:
	addi	a12, a5, 48
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_112moveRelationEPcjRjRKNS_12MoveRelationE$constprop$0
	bnez.n	a10, .L3590
	j	.L3589
.L3585:
	movi	a11, 0x378
	add.n	a11, sp, a11
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	bnez.n	a10, .L3591
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1656
	l32r	a12, .LC1901
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3591:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3573:
	beqz.n	a14, .L3592
	l8ui	a8, a6, 44
	movi.n	a15, 1
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console10formatHomeEmmmRKN14MotorControlRS6ESS_RS11HomeContextEbb
	j	.L2775
.L3592:
	l32i	a14, sp, 288
	beqz.n	a14, .L3593
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a15, 1
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console12formatDriverEmmmRKN14MotorControlRS6ESS_RS13DriverContextEb
	j	.L2775
.L3593:
	l32i	a14, sp, 284
	beqz.n	a14, .L3594
	l8ui	a8, a6, 44
	movi.n	a15, 1
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console14formatVelocityEmmmRKN14MotorControlRS6ESS_RS15VelocityContextEbb
	j	.L2775
.L3594:
	l32i	a14, sp, 268
	beqz.n	a14, .L3595
	addi	a7, a7, 48
	s32i	a7, sp, 4
	l8ui	a8, a6, 44
	movi.n	a15, 1
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console10formatMoveEmmmRKN14MotorControlRS6ESS_RS11MoveContextEbbRKNS_12MoveRelationE
	j	.L2775
.L3595:
	l32i	a14, sp, 264
	beqz.n	a14, .L3596
	s32i	a7, sp, 4
	l8ui	a8, a6, 44
	movi.n	a15, 1
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console12formatActionEmmmRKN14MotorControlRS6ESS_RS13ActionContextEbbPKNS0_10ResultViewE
	j	.L2775
.L3596:
	l32i	a14, sp, 260
	beqz.n	a14, .L3597
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a15, 1
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console10formatReadEmmmRKN14MotorControlRS6ESS_RS11ReadContextEb
	j	.L2775
.L3597:
	l8ui	a8, sp, 250
	beqz.n	a8, .L3598
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi	a14, 0x1e8
	movi.n	a15, 1
	add.n	a14, sp, a14
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console14formatRecoveryEmmmRKNS_3Rtu14RecoveryResultEb
	j	.L2775
.L3598:
	movi.n	a8, 1
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	mov.n	a14, a13
	l32i	a11, a8, 0
	l8ui	a13, sp, 248
	movi	a15, 0x130
	add.n	a15, sp, a15
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console11formatProbeEmmhmRKNS0_11ProbeResultEb
	j	.L2775
.L3553:
	movi	a8, 0xe0
	add.n	a10, sp, a8
	movi.n	a11, 0
	movi.n	a12, 0x38
	call8	memset
	mov.n	a8, a10
	l32i	a9, a2, 84
	l32i	a10, a2, 0
	movi.n	a11, 0
	beqz.n	a7, .L3600
	movi	a11, 0x550
	add.n	a11, a8, a11
.L3600:
	movi	a12, 0xe0
	add.n	a12, sp, a12
	callx8	a9
	mov.n	a13, a10
	beqz.n	a10, .L3601
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a12, .LC1856
	l32i	a11, a8, 0
	movi.n	a15, 0
	movi.n	a14, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3601:
	l8ui	a8, sp, 224
	movi	a10, 0x124
	l32r	a14, .LC1441
	add.n	a10, a2, a10
	beqz.n	a8, .L3603
	l32r	a14, .LC1440
.L3603:
	l32i	a8, sp, 272
	l32i	a9, sp, 276
	s32i	a8, sp, 40
	l32i	a8, sp, 264
	s32i	a9, sp, 44
	s32i	a8, sp, 32
	l32i	a8, sp, 256
	l32i	a9, sp, 268
	s32i	a8, sp, 24
	l32i	a8, sp, 248
	s32i	a9, sp, 36
	s32i	a8, sp, 16
	l32i	a8, sp, 240
	l32i	a9, sp, 260
	s32i	a8, sp, 8
	l32i	a8, sp, 236
	s32i	a9, sp, 28
	s32i	a8, sp, 4
	l32i	a8, sp, 232
	l32i	a9, sp, 252
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	s32i	a9, sp, 20
	add.n	a8, a8, sp
	l32i	a15, sp, 228
	l32i	a13, a8, 0
	l32r	a12, .LC1913
	l32r	a11, .LC1602
	call8	snprintf
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3557:
	movi	a8, 0xe0
	add.n	a10, sp, a8
	movi.n	a11, 0
	movi	a12, 0x78
	call8	memset
	mov.n	a8, a10
	l32i	a9, a2, 80
	l32i	a10, a2, 0
	movi.n	a11, 0
	beqz.n	a7, .L3605
	movi	a11, 0x570
	add.n	a11, a8, a11
.L3605:
	movi	a12, 0xe0
	add.n	a12, sp, a12
	callx8	a9
	mov.n	a13, a10
	beqz.n	a10, .L3606
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a15, 0
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3606:
	addmi	a6, sp, 0x100
	l8ui	a7, a6, 79
	beqz.n	a7, .L3608
	l8ui	a9, a6, 80
	movi	a8, 0x64
	movi.n	a7, 0
	bltu	a8, a9, .L3608
	l8ui	a9, a6, 81
	saltu	a8, a8, a9
	addi.n	a8, a8, -1
	neg	a8, a8
	extui	a7, a8, 0, 8
.L3608:
	movi	a5, 0xe0
	l32r	a4, .LC1504
	add.n	a5, sp, a5
	movi	a3, 0x488
	add.n	a3, a5, a3
	movi.n	a12, 5
	mov.n	a11, a4
	mov.n	a10, a3
	call8	memcpy
	movi	a8, 0x298
	add.n	a5, a5, a8
	movi.n	a12, 5
	mov.n	a11, a4
	mov.n	a10, a5
	call8	memcpy
	beqz.n	a7, .L3609
	l32r	a4, .LC1803
	l8ui	a13, a6, 80
	mov.n	a12, a4
	movi.n	a11, 5
	mov.n	a10, a3
	call8	snprintf
	l8ui	a13, a6, 81
	mov.n	a12, a4
	movi.n	a11, 5
	mov.n	a10, a5
	call8	snprintf
.L3609:
	movi	a10, 0x124
	movi	a9, 0x6b8
	add.n	a8, a2, a10
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l8ui	a8, a6, 78
	l32r	a14, .LC1441
	beqz.n	a8, .L3610
	l32r	a14, .LC1440
.L3610:
	l8ui	a8, a6, 77
	l32r	a15, .LC1449
	beqz.n	a8, .L3611
	l32r	a15, .LC1447
.L3611:
	l32i	a8, sp, 240
	l32i	a9, sp, 244
	movi	a10, 0x6c0
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 248
	l32i	a9, sp, 252
	movi	a10, 0x6c8
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 256
	l32i	a9, sp, 260
	movi	a10, 0x6d0
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 264
	l32i	a9, sp, 268
	movi	a10, 0x6d8
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 272
	l32i	a9, sp, 276
	movi	a10, 0x6e0
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 280
	l32i	a9, sp, 284
	movi	a10, 0x6e8
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 288
	l32i	a9, sp, 292
	movi	a10, 0x6f0
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 296
	movi	a10, 0x6f8
	add.n	a10, a10, sp
	l32i	a3, sp, 224
	l32i	a12, sp, 228
	l32i	a13, sp, 232
	l32i	a9, sp, 300
	s32i	a8, a10, 0
	addmi	a8, sp, 0x100
	l8ui	a8, a8, 76
	s32i	a9, a10, 4
	l32i	a6, sp, 324
	l32r	a9, .LC1441
	beqz.n	a8, .L3612
	l32r	a9, .LC1440
.L3612:
	l32i	a10, sp, 304
	l32i	a11, sp, 308
	addmi	a8, sp, 0x700
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	l32i	a10, sp, 312
	l32i	a11, sp, 316
	movi	a8, 0x708
	add.n	a8, a8, sp
	s32i	a11, a8, 4
	s32i	a10, a8, 0
	l32i	a5, sp, 328
	l32i	a4, sp, 320
	l32r	a11, .LC1441
	beqz.n	a7, .L3613
	l32r	a11, .LC1440
.L3613:
	movi	a8, 0xe0
	add.n	a8, sp, a8
	movi	a7, 0x298
	add.n	a7, a8, a7
	s32i	a7, sp, 124
	movi	a7, 0x488
	add.n	a8, a8, a7
	s32i	a8, sp, 120
	movi	a8, 0x708
	s32i	a11, sp, 116
	s32i	a4, sp, 112
	add.n	a8, a8, sp
	l32i	a10, a8, 0
	l32i	a11, a8, 4
	s32i	a10, sp, 104
	s32i	a11, sp, 108
	addmi	a8, sp, 0x700
	l32i	a10, a8, 0
	l32i	a11, a8, 4
	movi	a8, 0x6f8
	s32i	a10, sp, 96
	s32i	a11, sp, 100
	s32i	a5, sp, 88
	s32i	a9, sp, 84
	s32i	a6, sp, 80
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 76
	s32i	a8, sp, 72
	movi	a8, 0x6f0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 60
	s32i	a8, sp, 56
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 52
	s32i	a8, sp, 48
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 44
	s32i	a8, sp, 40
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 36
	s32i	a8, sp, 32
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 24
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a12, sp, 4
	s32i	a8, sp, 16
	movi	a8, 0x6b0
	s32i	a9, sp, 20
	s32i	a13, sp, 8
	s32i	a3, sp, 0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32r	a12, .LC1915
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	call8	snprintf
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L3552:
	movi	a9, 0xe0
	add.n	a10, sp, a9
	movi	a12, 0x298
	movi.n	a11, 0
	call8	memset
	l32r	a8, .LC1579
	mov.n	a9, a10
	s32i	a8, sp, 224
	s32i	a8, sp, 232
	s32i	a8, sp, 240
	movi.n	a8, 1
	s8i	a8, sp, 248
	movi.n	a8, 0x14
	s32i	a8, sp, 300
	l32r	a8, .LC1620
	movi.n	a10, 1
	s32i	a8, sp, 308
	l32r	a8, .LC1621
	s32i	a10, sp, 252
	s32i	a8, sp, 312
	s32i	a8, sp, 316
	addmi	a3, sp, 0x100
	s8i	a10, a3, 88
	l32r	a10, .LC1457
	l32i	a12, a2, 12
	s32i	a10, sp, 404
	movi.n	a10, 0x40
	s32i	a10, sp, 480
	movi.n	a10, 0xa
	s32i	a10, sp, 532
	beqz.n	a12, .L3615
	l32i	a10, a2, 0
	mov.n	a11, a9
	callx8	a12
.L3615:
	beqz.n	a6, .L3616
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnez.n	a8, .L3617
	l8ui	a8, a3, 88
	movi	a9, 0x5e0
	add.n	a9, sp, a9
	s32i	a8, a9, 196
.L3617:
	movi	a8, 0x5e0
	add.n	a8, sp, a8
	l32i	a6, a8, 196
	movi	a9, 0xf6
	addi.n	a8, a6, -1
	bgeu	a9, a8, .L3618
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1691
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3618:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console13availableSlotEbb
	movi.n	a8, 0xf
	bne	a10, a8, .L3619
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a15, 0
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi.n	a14, 0
	movi.n	a13, 1
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3619:
	movi	a9, 0x6b8
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	l32i	a7, a2, 16
	l8ui	a9, a9, 4
	l32i	a8, a2, 20
	bnei	a9, 7, .L3620
	mov.n	a7, a8
.L3620:
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console9beginWorkEv
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a10, a2, 0
	bgeui	a8, 3, .L3621
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a11, 0x12
	l8ui	a8, a8, 4
	l32i	a9, a2, 24
	movi.n	a13, 0
	beq	a8, a11, .L3622
	movi.n	a11, 0x13
	movi.n	a13, 2
	bne	a8, a11, .L3622
	movi.n	a13, 1
.L3622:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	movi	a14, 0x6a0
	add.n	a14, sp, a14
	mov.n	a12, a6
	callx8	a9
	j	.L4599
.L3621:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	movi	a13, 0x6a0
	l32i	a11, a8, 0
	add.n	a13, sp, a13
	mov.n	a12, a6
	callx8	a7
.L4599:
	mov.n	a7, a10
	bnez.n	a10, .L3624
	movi	a8, 0x5e0
	add.n	a8, sp, a8
	l32i	a5, a8, 192
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a12, a5
	movi.n	a14, 0
	movi.n	a13, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5trackEmmbb
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a12, a8, 0
	j	.L3625
.L3624:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a5, 0
	l32i	a12, a8, 0
.L3625:
	movi.n	a8, 0
	s32i	a8, sp, 8
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a15, a5
	mov.n	a14, a6
	mov.n	a13, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console6actionEmPKcNS0_6ActionEhmbmb
	j	.L2775
.L3616:
	movi	a7, 0xe0
	add.n	a7, sp, a7
	addmi	a6, a7, 0x500
	l32r	a11, .LC1916
	movi	a10, 0x88
	movi.n	a12, 5
	add.n	a10, a6, a10
	call8	memcpy
	movi	a10, 0x8d
	movi.n	a12, 3
	movi.n	a11, 0
	add.n	a10, a6, a10
	call8	memset
	addmi	a7, a7, 0x200
	movi	a4, 0x98
	l32r	a11, .LC1917
	add.n	a5, a7, a4
	movi.n	a12, 5
	mov.n	a10, a5
	call8	memcpy
	movi	a10, 0x9d
	movi.n	a12, 0x13
	movi.n	a11, 0
	add.n	a10, a7, a10
	call8	memset
	l32r	a7, .LC1504
	movi	a10, 0xb8
	movi.n	a12, 5
	mov.n	a11, a7
	add.n	a10, a6, a10
	call8	memcpy
	movi.n	a12, 5
	mov.n	a11, a7
	add.n	a10, a6, a4
	call8	memcpy
	l8ui	a9, a3, 156
	beqz.n	a9, .L3628
	l32i	a9, sp, 432
	l32i	a10, sp, 436
	or	a9, a9, a10
	beqz.n	a9, .L3628
	l32i	a14, sp, 424
	l32i	a15, sp, 428
	l32r	a12, .LC1918
	movi.n	a11, 0x18
	mov.n	a10, a5
	call8	snprintf
.L3628:
	l8ui	a9, a3, 153
	beqz.n	a9, .L3630
	movi	a10, 0x698
	l8ui	a13, a3, 155
	l32r	a12, .LC1803
	movi.n	a11, 5
	add.n	a10, sp, a10
	call8	snprintf
.L3630:
	l8ui	a9, a3, 156
	beqz.n	a9, .L3631
	l32r	a6, .LC1803
	movi	a7, 0xe0
	l16ui	a13, sp, 420
	add.n	a7, sp, a7
	movi	a10, 0x588
	mov.n	a12, a6
	movi.n	a11, 8
	add.n	a10, a7, a10
	call8	snprintf
	movi	a10, 0x598
	l8ui	a13, a3, 157
	mov.n	a12, a6
	movi.n	a11, 5
	add.n	a10, a7, a10
	call8	snprintf
.L3631:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a10, 9
	l8ui	a9, a8, 4
	addi	a9, a9, -2
	extui	a9, a9, 0, 8
	bltu	a10, a9, .L3632
	l32r	a10, .LC1919
	addx4	a9, a9, a10
	l32i	a9, a9, 0
	jx	a9
	.section	.rodata
	.align	4
	.align	4
.L3634:
	.word	.L3639
	.word	.L3638
	.word	.L3637
	.word	.L3636
	.word	.L3632
	.word	.L3632
	.word	.L3632
	.word	.L3635
	.word	.L3632
	.word	.L3633
	.text
.L3633:
	movi	a9, 0x124
	add.n	a8, a2, a9
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	l8ui	a10, a3, 135
	s32i	a8, a9, 0
	call8	_ZN21MotorControlRSExample3Rtu9phaseNameENS0_5PhaseE
	l32r	a8, .LC1441
	mov.n	a14, a10
	movi	a10, 0x6c8
	add.n	a10, a10, sp
	l8ui	a9, a3, 132
	s32i	a8, a10, 0
	beqz.n	a9, .L3640
	l32r	a8, .LC1440
	s32i	a8, a10, 0
.L3640:
	l8ui	a9, a3, 133
	l32r	a11, .LC1441
	beqz.n	a9, .L3641
	l32r	a11, .LC1440
.L3641:
	l8ui	a8, a3, 134
	l32r	a3, .LC1441
	beqz.n	a8, .L3642
	l32r	a3, .LC1440
.L3642:
	l32i	a8, sp, 512
	movi	a9, 0x6d0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, sp, 516
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, sp, 520
	movi	a9, 0x6e0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, sp, 524
	movi	a9, 0x6e8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, sp, 528
	movi	a9, 0x6f0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, sp, 532
	movi	a9, 0x6f8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, sp, 484
	addmi	a9, sp, 0x700
	s32i	a8, a9, 0
	l32i	a8, sp, 536
	movi	a9, 0x708
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a10, 0x710
	l32i	a8, sp, 544
	l32i	a9, sp, 548
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 552
	l32i	a9, sp, 556
	movi	a10, 0x718
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 560
	l32i	a9, sp, 564
	movi	a10, 0x720
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 568
	l32i	a9, sp, 572
	movi	a10, 0x728
	add.n	a10, a10, sp
	s32i	a9, a10, 4
	s32i	a8, a10, 0
	l32i	a8, sp, 576
	movi	a10, 0x730
	l32i	a9, sp, 580
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 584
	l32i	a9, sp, 588
	movi	a10, 0x738
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 592
	movi	a9, 0x740
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a10, 0x748
	l32i	a8, sp, 456
	l32i	a9, sp, 460
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, sp, 464
	movi	a10, 0x750
	l32i	a9, sp, 468
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	addmi	a8, sp, 0x100
	s32i	a9, a10, 4
	l8ui	a9, a8, 216
	l32r	a8, .LC1449
	beqz.n	a9, .L3643
	l32r	a8, .LC1447
.L3643:
	l32i	a9, sp, 480
	movi	a10, 0x6b4
	add.n	a10, a10, sp
	s32i	a9, a10, 0
	l32i	a9, sp, 416
	movi	a10, 0x758
	add.n	a10, a10, sp
	l32i	a12, sp, 432
	l32i	a13, sp, 436
	s32i	a9, a10, 0
	movi	a9, 0x760
	add.n	a9, a9, sp
	s32i	a12, a9, 0
	s32i	a13, a9, 4
	l32i	a12, sp, 440
	l32i	a13, sp, 444
	movi	a9, 0x768
	add.n	a9, a9, sp
	s32i	a12, a9, 0
	s32i	a13, a9, 4
	l32i	a12, sp, 448
	l32i	a13, sp, 452
	movi	a9, 0x770
	add.n	a9, a9, sp
	s32i	a12, a9, 0
	s32i	a13, a9, 4
	movi	a9, 0x1e0
	add.n	a9, sp, a9
	l8ui	a10, a9, 116
	l32r	a9, .LC1441
	beqz.n	a10, .L3644
	l32r	a9, .LC1440
.L3644:
	l32i	a10, sp, 680
	movi	a15, 0x75c
	add.n	a15, a15, sp
	s32i	a10, a15, 0
	movi	a10, 0x1e0
	add.n	a10, sp, a10
	l8ui	a5, a10, 117
	l32i	a12, sp, 672
	l32i	a13, sp, 676
	l32i	a15, sp, 684
	l32i	a7, sp, 688
	l32i	a6, sp, 692
	l32r	a10, .LC1441
	beqz.n	a5, .L3645
	l32r	a10, .LC1440
.L3645:
	l32i	a5, sp, 604
	l32i	a4, sp, 656
	s32i	a5, sp, 208
	l32i	a5, sp, 660
	s32i	a4, sp, 200
	s32i	a5, sp, 204
	l32i	a5, sp, 668
	l32i	a4, sp, 664
	s32i	a5, sp, 196
	l32i	a5, sp, 608
	s32i	a10, sp, 180
	s32i	a5, sp, 188
	l32i	a5, sp, 600
	movi	a10, 0x75c
	s32i	a7, sp, 172
	s32i	a15, sp, 168
	s32i	a4, sp, 192
	s32i	a5, sp, 184
	s32i	a6, sp, 176
	add.n	a10, a10, sp
	l32i	a10, a10, 0
	s32i	a9, sp, 152
	movi	a9, 0x770
	s32i	a10, sp, 164
	s32i	a13, sp, 160
	s32i	a12, sp, 156
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	movi	a9, 0x768
	s32i	a12, sp, 144
	s32i	a13, sp, 148
	add.n	a9, a9, sp
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	movi	a9, 0x760
	add.n	a9, a9, sp
	s32i	a12, sp, 136
	s32i	a13, sp, 140
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	movi	a9, 0x758
	s32i	a12, sp, 128
	s32i	a13, sp, 132
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	movi	a7, 0xe0
	s32i	a9, sp, 124
	add.n	a7, sp, a7
	movi	a9, 0x598
	add.n	a9, a7, a9
	s32i	a9, sp, 120
	movi	a9, 0x6b4
	add.n	a9, a9, sp
	l32i	a9, a9, 0
	s32i	a8, sp, 112
	movi	a8, 0x750
	s32i	a9, sp, 116
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 108
	s32i	a8, sp, 104
	movi	a8, 0x748
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 100
	s32i	a8, sp, 96
	movi	a8, 0x740
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a8, sp, 88
	movi	a8, 0x738
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 84
	s32i	a8, sp, 80
	movi	a8, 0x730
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 76
	s32i	a8, sp, 72
	movi	a8, 0x728
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 68
	s32i	a8, sp, 64
	movi	a8, 0x720
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 60
	s32i	a8, sp, 56
	movi	a8, 0x718
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 52
	s32i	a8, sp, 48
	movi	a8, 0x710
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 44
	s32i	a8, sp, 40
	movi	a8, 0x708
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a12, .LC1921
	s32i	a8, sp, 36
	addmi	a8, sp, 0x700
	l32i	a8, a8, 0
	s32i	a8, sp, 32
	movi	a8, 0x6f8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a8, sp, 28
	movi	a8, 0x6f0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a8, sp, 24
	movi	a8, 0x6e8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a8, sp, 20
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a8, sp, 16
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a8, sp, 12
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a3, sp, 4
	s32i	a8, sp, 8
	movi	a8, 0x6c8
	s32i	a11, sp, 0
	add.n	a8, a8, sp
	l32i	a15, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	call8	snprintf
	l32r	a8, .LC1845
	bgeu	a8, a10, .L3646
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3646:
	addmi	a8, a7, 0x400
	addmi	a7, a7, 0x100
	addi.n	a10, a10, -1
	l8ui	a9, a7, 168
	s32i	a10, a8, 136
	l32i	a14, sp, 612
	l32i	a15, sp, 616
	l32i	a10, sp, 640
	l32i	a11, sp, 644
	l32r	a8, .LC1441
	beqz.n	a9, .L3648
	l32r	a8, .LC1440
.L3648:
	movi	a9, 0x1e0
	add.n	a9, sp, a9
	l8ui	a5, a9, 169
	l32i	a12, sp, 620
	l32i	a13, sp, 624
	l32i	a7, sp, 628
	l32i	a6, sp, 632
	l32r	a9, .LC1441
	beqz.n	a5, .L3649
	l32r	a9, .LC1440
.L3649:
	s32i	a8, sp, 8
	movi	a8, 0x6c0
	s32i	a13, sp, 16
	s32i	a12, sp, 12
	s32i	a11, sp, 4
	s32i	a9, sp, 28
	s32i	a6, sp, 24
	s32i	a7, sp, 20
	s32i	a10, sp, 0
	add.n	a8, a8, sp
	movi	a12, 0x568
	l32r	a13, .LC1923
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3651
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3639:
	movi	a7, 0x124
	movi	a9, 0x6c0
	add.n	a8, a2, a7
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi	a9, 0x6c8
	l32i	a8, a8, 0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l8ui	a8, a3, 88
	movi	a9, 0x6d0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, a2, 88
	l32i	a7, sp, 348
	l32r	a10, .LC1520
	beqz.n	a8, .L3652
	l8ui	a8, sp, 248
	l32r	a10, .LC1501
	beqz.n	a8, .L3652
	l8ui	a10, sp, 244
	call8	_ZN21MotorControlRSExample10formatNameENS_10HostFormatE
.L3652:
	l32i	a8, sp, 352
	movi	a9, 0x6d8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	addmi	a8, sp, 0x100
	l8ui	a11, a8, 128
	l32i	a3, sp, 356
	l32i	a4, sp, 360
	l32i	a15, sp, 364
	l32i	a6, sp, 368
	l32r	a9, .LC1441
	beqz.n	a11, .L3653
	l32r	a9, .LC1440
.L3653:
	l8ui	a8, a8, 129
	l32r	a11, .LC1441
	beqz.n	a8, .L3654
	l32r	a11, .LC1440
.L3654:
	l32i	a14, sp, 492
	l32r	a12, .LC1501
	beqz.n	a14, .L3655
	l32r	a12, .LC1522
.L3655:
	addmi	a8, sp, 0x100
	l8ui	a8, a8, 217
	l32r	a13, .LC1441
	beqz.n	a8, .L3656
	l32r	a13, .LC1440
.L3656:
	l32i	a8, sp, 508
	s32i	a8, sp, 72
	l32i	a8, sp, 504
	s32i	a8, sp, 68
	movi	a8, 0x1e0
	add.n	a8, sp, a8
	l8ui	a5, a8, 17
	s32i	a14, sp, 60
	l32i	a14, sp, 500
	s32i	a5, sp, 64
	s32i	a14, sp, 56
	l8ui	a8, a8, 16
	s32i	a12, sp, 36
	s32i	a8, sp, 52
	l32i	a8, sp, 488
	s32i	a11, sp, 32
	s32i	a8, sp, 48
	l32i	a8, sp, 476
	s32i	a13, sp, 40
	s32i	a8, sp, 44
	movi	a8, 0x6d8
	s32i	a9, sp, 28
	s32i	a6, sp, 24
	s32i	a15, sp, 20
	s32i	a4, sp, 16
	s32i	a3, sp, 12
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a10, sp, 4
	s32i	a8, sp, 8
	movi	a8, 0x6d0
	s32i	a7, sp, 0
	add.n	a8, a8, sp
	l32i	a15, a8, 0
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32r	a12, .LC1925
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	call8	snprintf
	j	.L3651
.L3638:
	movi	a9, 0x124
	add.n	a8, a2, a9
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a10, 0x6d0
	l32i	a8, sp, 376
	l32i	a9, sp, 380
	add.n	a10, a10, sp
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32r	a8, .LC1441
	movi	a10, 0x6c0
	add.n	a10, a10, sp
	l8ui	a9, a3, 128
	s32i	a8, a10, 0
	beqz.n	a9, .L3657
	l32r	a8, .LC1440
	s32i	a8, a10, 0
.L3657:
	l8ui	a9, a3, 129
	l32r	a4, .LC1441
	beqz.n	a9, .L3658
	l32r	a4, .LC1440
.L3658:
	l8ui	a9, a3, 132
	l32r	a7, .LC1441
	beqz.n	a9, .L3659
	l32r	a7, .LC1440
.L3659:
	l8ui	a9, a3, 133
	l32r	a6, .LC1441
	beqz.n	a9, .L3660
	l32r	a6, .LC1440
.L3660:
	l8ui	a9, a3, 134
	l32r	a5, .LC1441
	beqz.n	a9, .L3661
	l32r	a5, .LC1440
.L3661:
	l8ui	a10, a3, 135
	call8	_ZN21MotorControlRSExample3Rtu9phaseNameENS0_5PhaseE
	movi	a8, 0x6d8
	add.n	a8, a8, sp
	s32i	a10, a8, 0
	l8ui	a10, a3, 136
	call8	_ZN21MotorControlRSExample3Rtu10reasonNameENS0_6ReasonE
	l8ui	a9, a3, 137
	mov.n	a11, a10
	beqz.n	a9, .L3968
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	s32i	a10, a8, 0
	l8ui	a10, a3, 140
	call8	_ZN14MotorControlRS11errToStringENS_3ErrE
	movi	a8, 0x6e0
	add.n	a8, a8, sp
	l32i	a13, sp, 400
	l8ui	a14, a3, 152
	l32i	a11, a8, 0
	j	.L3662
.L3968:
	l32r	a10, .LC1523
	movi.n	a13, 0
	movi.n	a14, 0
.L3662:
	addmi	a8, sp, 0x100
	l8ui	a9, a8, 153
	beqz.n	a9, .L3969
	l8ui	a8, a8, 154
	beqz.n	a8, .L3970
	l32r	a8, .LC1440
	j	.L4600
.L3969:
	l32r	a8, .LC1441
.L4600:
	mov.n	a12, a8
	j	.L3663
.L3970:
	l32r	a8, .LC1440
	l32r	a12, .LC1441
.L3663:
	l32i	a9, sp, 368
	movi	a15, 0x298
	s32i	a9, sp, 64
	movi	a9, 0xe0
	add.n	a9, sp, a9
	add.n	a15, a9, a15
	s32i	a15, sp, 60
	movi	a15, 0x588
	add.n	a15, a9, a15
	s32i	a15, sp, 56
	movi	a15, 0x598
	add.n	a15, a9, a15
	s32i	a15, sp, 52
	movi	a15, 0x5b8
	s32i	a8, sp, 40
	add.n	a9, a9, a15
	movi	a8, 0x6d8
	s32i	a12, sp, 44
	s32i	a11, sp, 24
	s32i	a9, sp, 48
	s32i	a14, sp, 36
	s32i	a13, sp, 32
	s32i	a10, sp, 28
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	s32i	a5, sp, 16
	s32i	a8, sp, 20
	movi	a8, 0x6c0
	s32i	a6, sp, 12
	s32i	a7, sp, 8
	s32i	a4, sp, 4
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a12, .LC1927
	s32i	a8, sp, 0
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a14, a8, 0
	l32i	a15, a8, 4
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	l32r	a11, .LC1602
	l32i	a10, a8, 0
	call8	snprintf
	j	.L3651
.L3637:
	l8ui	a12, a3, 128
	l8ui	a5, a3, 153
	l32i	a6, sp, 368
	l32r	a7, .LC1524
	beqz.n	a12, .L3664
	l8ui	a9, a3, 134
	l32r	a7, .LC1525
	bnez.n	a9, .L3664
	l32r	a7, .LC1501
	beqz.n	a5, .L3664
	l8ui	a9, a3, 154
	l32r	a7, .LC1525
	beqz.n	a9, .L3664
	l32i	a9, sp, 432
	l32i	a10, sp, 436
	l32r	a7, .LC1501
	or	a9, a9, a10
	beqz.n	a9, .L3664
	l32r	a7, .LC1526
	beqz.n	a6, .L3664
	l32i	a9, sp, 428
	bnez.n	a9, .L3977
	l32i	a9, sp, 424
	bgeu	a6, a9, .L3664
.L3977:
	l32r	a7, .LC1528
.L3664:
	movi	a9, 0xe0
	l8ui	a11, a3, 88
	add.n	a9, sp, a9
	l32i	a13, sp, 508
	addmi	a10, a9, 0x400
	addmi	a9, a9, 0x200
	s32i	a11, a10, 136
	s8i	a11, a10, 140
	s32i	a13, a10, 144
	l8ui	a10, a9, 32
	beqz.n	a10, .L3667
	beqz.n	a12, .L3667
	l8ui	a10, a3, 134
	bnez.n	a10, .L3667
	l32i	a10, sp, 772
	l32r	a7, .LC1501
	bne	a11, a10, .L3667
	l8ui	a9, a9, 40
	bne	a9, a11, .L3667
	l32i	a9, sp, 780
	bne	a13, a9, .L3667
	l32i	a9, sp, 708
	l32i	a12, sp, 788
	l32i	a10, sp, 704
	l32i	a11, sp, 784
	bltu	a9, a12, .L3981
	bne	a12, a9, .L4005
	bltu	a10, a11, .L3981
.L4005:
	l32r	a7, .LC1526
	beqz.n	a6, .L3667
	sub	a9, a9, a12
	bgeu	a10, a11, .L3669
	addi.n	a9, a9, -1
.L3669:
	sub	a10, a10, a11
	movi	a11, 0x3e8
	mull	a12, a11, a6
	muluh	a11, a11, a6
	bltu	a11, a9, .L3983
	bne	a9, a11, .L4006
	bltu	a12, a10, .L3983
.L4006:
	l32r	a7, .LC1526
	j	.L3667
.L3981:
	l32r	a7, .LC1501
	j	.L3667
.L3983:
	l32r	a7, .LC1528
.L3667:
	l32i	a4, sp, 696
	bnez.n	a4, .L3671
.L3673:
	l32r	a11, .LC1501
	movi	a10, 0x124
	add.n	a10, a2, a10
	mov.n	a9, a11
	j	.L3672
.L3671:
	movi	a14, 0x3e8
	muluh	a15, a14, a6
	movi	a11, 0x568
	mull	a14, a14, a6
	l32i	a12, sp, 704
	l32i	a13, sp, 708
	add.n	a11, sp, a11
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L3673
	l8ui	a9, a4, 35
	bnez.n	a9, .L3674
	l16ui	a10, a4, 22
	addi.n	a9, a10, -1
	extui	a9, a9, 0, 16
	bgeui	a9, 5, .L3675
.L3674:
	movi	a10, 0x124
	l32r	a11, .LC1531
	add.n	a10, a2, a10
	j	.L4601
.L3675:
	bnez.n	a10, .L3676
	movi	a10, 0x124
	l32r	a11, .LC1532
	add.n	a10, a2, a10
	j	.L4601
.L3676:
	movi	a10, 0x124
	l32r	a11, .LC1501
	add.n	a10, a2, a10
.L4601:
	l32r	a9, .LC1529
.L3672:
	l32r	a12, .LC1501
	beqz.n	a5, .L3677
	l8ui	a8, a3, 154
	l32r	a12, .LC1533
	bnez.n	a8, .L3677
	l32r	a12, .LC1501
.L3677:
	movi	a13, 0xe0
	add.n	a13, sp, a13
	movi	a8, 0x298
	add.n	a8, a13, a8
	s32i	a8, sp, 4
	movi	a8, 0x598
	add.n	a8, a13, a8
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	s32i	a12, sp, 20
	s32i	a9, sp, 16
	s32i	a11, sp, 12
	s32i	a6, sp, 8
	movi	a15, 0x5b8
	add.n	a8, a8, sp
	add.n	a15, a13, a15
	l32r	a12, .LC1929
	l32i	a13, a8, 0
	mov.n	a14, a7
	j	.L4602
.L3636:
	l32i	a8, sp, 808
	movi	a9, 0x6c0
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	l32i	a8, sp, 812
	movi	a9, 0x6c8
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	movi	a7, 0x6d0
	l32i	a9, sp, 844
	add.n	a7, a7, sp
	l32i	a8, sp, 840
	s32i	a9, a7, 4
	addmi	a9, sp, 0x100
	l8ui	a5, a9, 218
	s32i	a8, a7, 0
	movi	a10, 0x124
	l32i	a14, sp, 800
	l32i	a15, sp, 804
	l32i	a3, sp, 816
	l32i	a4, sp, 820
	l32i	a11, sp, 824
	l32i	a12, sp, 828
	l32i	a13, sp, 832
	l32i	a7, sp, 848
	l32i	a6, sp, 852
	l32r	a8, .LC1441
	add.n	a10, a2, a10
	beqz.n	a5, .L3678
	l32r	a8, .LC1440
.L3678:
	l8ui	a5, a9, 219
	l32r	a9, .LC1441
	beqz.n	a5, .L3679
	l32r	a9, .LC1440
.L3679:
	s32i	a8, sp, 48
	movi	a8, 0x6d0
	s32i	a9, sp, 52
	s32i	a6, sp, 44
	s32i	a7, sp, 40
	add.n	a8, a8, sp
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a12, sp, 20
	s32i	a8, sp, 32
	movi	a8, 0x6c8
	s32i	a11, sp, 16
	s32i	a9, sp, 36
	s32i	a13, sp, 24
	s32i	a4, sp, 12
	s32i	a3, sp, 8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a12, .LC1931
	s32i	a8, sp, 4
	movi	a8, 0x6c0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a11, .LC1602
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
	call8	snprintf
	j	.L3651
.L3635:
	movi	a8, 0x2e0
	add.n	a8, sp, a8
	l8ui	a8, a8, 120
	movi	a10, 0x124
	l32r	a14, .LC1441
	add.n	a10, a2, a10
	beqz.n	a8, .L3680
	l32r	a14, .LC1440
.L3680:
	l32i	a8, sp, 884
	l32i	a15, sp, 860
	s32i	a8, sp, 20
	l32i	a8, sp, 880
	l32r	a12, .LC1933
	s32i	a8, sp, 16
	l32i	a8, sp, 876
	s32i	a8, sp, 12
	l32i	a8, sp, 872
	s32i	a8, sp, 8
	l32i	a8, sp, 868
	s32i	a8, sp, 4
	l32i	a8, sp, 864
	s32i	a8, sp, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a13, a8, 0
.L4602:
	l32r	a11, .LC1602
	call8	snprintf
	j	.L3651
.L3632:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1524
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3651:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l8ui	a8, a8, 4
	addi	a8, a8, -3
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L3681
	movi	a6, 0x124
	add.n	a7, a2, a6
	mov.n	a10, a7
	call8	strlen
	beqz.n	a10, .L3682
	addi.n	a10, a10, -1
	add.n	a8, a2, a10
	add.n	a8, a8, a6
	l8ui	a9, a8, 0
	movi	a8, 0x7d
	beq	a9, a8, .L3683
.L3682:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3683:
	movi	a12, 0xe0
	add.n	a12, sp, a12
	movi	a6, 0x488
	addmi	a8, a12, 0x400
	add.n	a6, a12, a6
	s32i	a10, a8, 136
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_110stateCacheEPcjRjRKNS0_8SnapshotE$constprop$0
	beqz.n	a10, .L3685
	l32r	a13, .LC1605
	l32r	a11, .LC1602
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	bnez.n	a10, .L3681
.L3685:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3681:
	l32i	a8, a2, 88
	beqz.n	a8, .L3686
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l8ui	a8, a8, 4
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L3686
	movi	a10, 0x124
	add.n	a10, a2, a10
	call8	strlen
	movi	a8, 0xe0
	add.n	a8, sp, a8
	addmi	a9, a8, 0x400
	s32i	a10, a9, 136
	l8ui	a9, sp, 248
	movi.n	a11, 0
	movi.n	a12, 0
	beqz.n	a9, .L3687
	l32i	a12, sp, 252
	addi	a11, a8, 16
.L3687:
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	movi	a11, 0x568
	add.n	a11, sp, a11
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console18appendReportSerialERj
	bnez.n	a10, .L3686
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1656
	l32i	a12, a8, 0
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3686:
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console4emitEmb
	j	.L2775
.L2952:
	movi	a8, 0x378
	add.n	a7, sp, a8
	j	.L2948
.L3013:
	movi.n	a8, 2
	movi.n	a9, 4
	movnez	a8, a9, a3
	j	.L3690
.L3692:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	movi.n	a10, 4
	l8ui	a11, a8, 4
	movi.n	a8, 0x30
	bne	a11, a8, .L3691
	movi.n	a10, 3
	j	.L3691
.L4567:
	bgei	a8, 1, .L4007
	bnez.n	a8, .L3692
	movi	a8, 0x7d0
	bgeu	a8, a9, .L3692
.L4007:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32r	a13, .LC1476
	l32i	a12, a8, 0
	j	.L3267
.L3694:
	movi.n	a10, 2
	j	.L3691
.L3270:
	bgei	a8, 1, .L4008
	bnez.n	a8, .L3694
	movi	a8, 0xb8
	addmi	a8, a8, 0xb00
	bgeu	a8, a9, .L3694
.L4008:
	movi	a8, 0x6b8
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	l32i	a12, a8, 0
	j	.L3696
.L3261:
	bnei	a14, 2, .L3264
	j	.L3697
.L3389:
	l32r	a8, .LC1597
	add.n	a4, a2, a8
	l8ui	a9, a4, 0
	bnez.n	a9, .L3698
	j	.L4575
.L3481:
	beqz.n	a4, .L3700
	j	.L3483
.L4560:
	movi	a12, 0x630
	l32r	a13, .LC1890
	l32r	a11, .LC1602
	add.n	a12, sp, a12
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe13ConsoleReport6appendEPcjRjPKcz
	beqz.n	a10, .L3701
	j	.L3702
.L3131:
	movi	a8, 0x6b0
	add.n	a8, a8, sp
	l32r	a13, .LC1936
	l32i	a11, a8, 0
	mov.n	a12, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L2775
.L3138:
	movi.n	a6, 1
	movi.n	a9, 0x24
	ssl	a5
	sll	a6, a6
	bne	a3, a9, .L4576
	j	.L3140
.L4563:
	movi	a8, 0x6c8
	add.n	a8, a8, sp
	movi	a9, 0x6b8
	s32i	a6, a8, 0
	add.n	a9, a9, sp
	movi.n	a8, 3
	s32i	a8, a9, 0
	movi	a8, 0x6d0
	add.n	a8, a8, sp
	l32i	a8, a8, 0
	bnei	a8, 2, .L3124
	movi	a9, 0x6b8
	movi.n	a8, 4
	add.n	a9, a9, sp
	s32i	a8, a9, 0
	j	.L3124
.L3539:
	l32r	a10, .LC1440
	l32r	a9, .LC1441
	beqz.n	a15, .L3540
	j	.L3705
.L4574:
	bnez.n	a3, .L3706
	j	.L3552
.L4573:
	bnez.n	a3, .L3706
	j	.L3707
.L3452:
	bnez.n	a8, .L3449
	j	.L3450
.L2959:
	movi	a12, 0xe0
	add.n	a12, sp, a12
	l32i	a8, a2, 88
	l32i	a10, a2, 0
	movi	a11, 0x298
	add.n	a11, a12, a11
	movi	a7, 0x124
	callx8	a8
	add.n	a7, a2, a7
	bnez.n	a10, .L4577
	j	.L3995
.L2775:
	retw.n
.LFE1095:
	.section	.gcc_except_table
.LLSDA1095:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE1095-.LLSDACSB1095
.LLSDACSB1095:
.LLSDACSE1095:
	.text
	.size	_ZN21MotorControlRSExample5Probe7Console8dispatchEv, .-_ZN21MotorControlRSExample5Probe7Console8dispatchEv
	.section	.rodata.str1.1
.LC1944:
	.string	"line_too_long"
.LC1948:
	.string	"invalid_input"
	.text
	.literal_position
	.literal .LC1941, 35587
	.literal .LC1942, 35188
	.literal .LC1943, 35585
	.literal .LC1945, .LC1944
	.literal .LC1946, .LC1536
	.literal .LC1947, 35586
	.literal .LC1949, .LC1948
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console4feedEc
	.type	_ZN21MotorControlRSExample5Probe7Console4feedEc, @function
_ZN21MotorControlRSExample5Probe7Console4feedEc:
.LFB1061:
	entry	sp, 32
.LCFI89:
	extui	a3, a3, 0, 8
	l32r	a8, .LC1941
	bnei	a3, 10, .L4606
	add.n	a9, a2, a8
	l8ui	a10, a9, 0
	beqz.n	a10, .L4606
	movi.n	a8, 0
	s8i	a8, a9, 0
	j	.L4605
.L4606:
	addi	a9, a3, -13
	nsau	a9, a9
	srli	a9, a9, 5
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	movi.n	a11, 1
	beqi	a3, 10, .L4624
	beqz.n	a9, .L4608
.L4624:
	l32r	a3, .LC1942
	movi.n	a9, 0
	add.n	a8, a2, a3
	l32i	a8, a8, 0
	movi.n	a14, 1
	j	.L4610
.L4614:
	addi.n	a9, a9, 1
.L4610:
	bne	a8, a9, .L4611
	j	.L4612
.L4634:
	bltu	a9, a8, .L4633
	j	.L4612
.L4611:
	add.n	a12, a2, a9
	l8ui	a11, a12, 164
	addi	a13, a11, -32
	nsau	a10, a13
	srli	a10, a10, 5
	beqz.n	a13, .L4614
	addi	a11, a11, -9
	moveqz	a10, a14, a11
	bnez.n	a10, .L4614
	j	.L4634
.L4633:
	l8ui	a10, a12, 164
	movi.n	a9, 1
	beqi	a10, 64, .L4616
.L4612:
	l8ui	a9, a2, 140
.L4616:
	l32r	a7, .LC1943
	s8i	a9, a2, 141
	movi.n	a9, 0
	s32i	a9, a2, 148
	s32i	a9, a2, 144
	add.n	a9, a2, a7
	l8ui	a9, a9, 0
	l32r	a6, .LC1947
	l32r	a13, .LC1945
	bnez.n	a9, .L4635
.L4617:
	add.n	a9, a2, a6
	l8ui	a9, a9, 0
	beqz.n	a9, .L4619
	l32r	a13, .LC1949
.L4635:
	l32r	a12, .LC1946
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	j	.L4618
.L4619:
	beqz.n	a8, .L4618
	add.n	a8, a2, a8
	s8i	a9, a8, 164
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console8dispatchEv
.L4618:
	movi.n	a8, 0
	add.n	a3, a2, a3
	s32i	a8, a3, 0
	add.n	a6, a2, a6
	s8i	a8, a6, 0
	add.n	a7, a2, a7
	s8i	a8, a7, 0
	j	.L4605
.L4608:
	movi.n	a8, 0x1f
	saltu	a8, a8, a3
	addi.n	a8, a8, -1
	addi	a10, a3, -9
	neg	a8, a8
	movnez	a9, a11, a10
	and	a8, a8, a9
	extui	a8, a8, 0, 8
	bnez.n	a8, .L4625
	movi	a8, 0x7e
	bgeu	a8, a3, .L4620
.L4625:
	l32r	a8, .LC1947
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	j	.L4605
.L4620:
	l32r	a9, .LC1942
	l32r	a8, .LC1943
	add.n	a9, a2, a9
	l32i	a10, a9, 0
	movi	a13, 0x7f
	addi.n	a12, a10, 1
	add.n	a8, a2, a8
	bgeu	a13, a12, .L4622
	s8i	a11, a8, 0
	j	.L4605
.L4622:
	l8ui	a8, a8, 0
	bnez.n	a8, .L4605
	l32r	a8, .LC1947
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L4605
	s32i	a12, a9, 0
	add.n	a2, a2, a10
	s8i	a3, a2, 164
.L4605:
	retw.n
.LFE1061:
	.size	_ZN21MotorControlRSExample5Probe7Console4feedEc, .-_ZN21MotorControlRSExample5Probe7Console4feedEc
	.literal_position
	.literal .LC1950, .LC1377
	.literal .LC1951, 35584
	.literal .LC1952, 35380
	.literal .LC1953, 35196
	.literal .LC1954, 35376
	.literal .LC1955, CSWTCH$1369
	.literal .LC1956, .LC772
	.align	4
	.global	_ZN21MotorControlRSExample5Probe7Console11reportGroupEmmRKNS0_11GroupResultEPKNS_9HostTupleEm
	.type	_ZN21MotorControlRSExample5Probe7Console11reportGroupEmmRKNS0_11GroupResultEPKNS_9HostTupleEm, @function
_ZN21MotorControlRSExample5Probe7Console11reportGroupEmmRKNS0_11GroupResultEPKNS_9HostTupleEm:
.LFB1231:
	entry	sp, 32
.LCFI90:
	mov.n	a12, a7
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console15setReportSerialEPKNS_9HostTupleEm
	l32r	a8, .LC1951
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	mov.n	a7, a2
	bnez.n	a8, .L4646
	l32r	a9, .LC1952
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4637
	l8ui	a8, a5, 12
	bnez.n	a8, .L4646
	l32i	a9, a5, 4
	bne	a9, a4, .L4637
	l32r	a6, .LC1953
	add.n	a6, a2, a6
	l32r	a2, .LC1954
	add.n	a10, a7, a2
	j	.L4638
.L4644:
	l32i	a9, a6, 0
	bne	a9, a3, .L4639
	l32i	a9, a6, 4
	bne	a9, a4, .L4639
	l8ui	a9, a6, 8
	bnez.n	a9, .L4639
	l8ui	a8, a6, 9
	movi.n	a15, 0
	s8i	a8, a7, 141
	s32i	a9, a7, 148
	s32i	a9, a7, 144
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a12, a3
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console11formatGroupEmmmRKNS0_11GroupResultEb
	bnez.n	a10, .L4640
	l8ui	a8, a5, 0
	l32r	a12, .LC1950
	bgeui	a8, 4, .L4641
	l32r	a9, .LC1955
	addx4	a8, a8, a9
	l32i	a12, a8, 0
.L4641:
	l32r	a13, .LC1956
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console5errorEmPKcS3_
	l32r	a8, .LC1951
	add.n	a5, a7, a8
	l8ui	a8, a5, 0
	beqz.n	a8, .L4642
	add.n	a2, a7, a2
	s32i	a4, a2, 0
	j	.L4640
.L4642:
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe7Console7untrackEm
.L4640:
	l32i	a8, a6, 4
	bne	a8, a4, .L4643
	movi.n	a8, 1
	s8i	a8, a6, 8
	j	.L4643
.L4639:
	addi.n	a6, a6, 12
.L4638:
	bne	a6, a10, .L4644
	j	.L4637
.L4643:
	movi.n	a8, 1
	j	.L4637
.L4646:
	movi.n	a8, 0
.L4637:
	mov.n	a2, a8
	retw.n
.LFE1231:
	.size	_ZN21MotorControlRSExample5Probe7Console11reportGroupEmmRKNS0_11GroupResultEPKNS_9HostTupleEm, .-_ZN21MotorControlRSExample5Probe7Console11reportGroupEmmRKNS0_11GroupResultEPKNS_9HostTupleEm
	.section	.rodata.str1.1
.LC1957:
	.string	"\"release\""
.LC1958:
	.string	"\"clear_alarm\""
.LC1959:
	.string	"\"clear_position\""
	.section	.rodata
	.align	4
	.type	CSWTCH$1625, @object
	.size	CSWTCH$1625, 16
CSWTCH$1625:
	.word	.LC1957
	.word	.LC1958
	.word	.LC1509
	.word	.LC1959
	.section	.rodata.str1.1
.LC1960:
	.string	"\"config\""
.LC1961:
	.string	"\"velocity_parameters\""
.LC1962:
	.string	"\"homing_parameters\""
	.section	.rodata
	.align	4
	.type	CSWTCH$1624, @object
	.size	CSWTCH$1624, 16
CSWTCH$1624:
	.word	.LC1960
	.word	.LC1505
	.word	.LC1961
	.word	.LC1962
	.align	4
	.type	CSWTCH$1623, @object
	.size	CSWTCH$1623, 88
CSWTCH$1623:
	.word	.LC580
	.word	.LC578
	.word	.LC582
	.word	.LC584
	.word	.LC586
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC578
	.word	.LC17
	.section	.rodata.str1.1
.LC1963:
	.string	"recovered"
.LC1964:
	.string	"read_error"
.LC1965:
	.string	"transport_error"
	.section	.rodata
	.align	4
	.type	CSWTCH$1607, @object
	.size	CSWTCH$1607, 16
CSWTCH$1607:
	.word	.LC1963
	.word	.LC1268
	.word	.LC1964
	.word	.LC1965
	.align	4
	.type	CSWTCH$1591, @object
	.size	CSWTCH$1591, 20
CSWTCH$1591:
	.word	.LC580
	.word	.LC582
	.word	.LC582
	.word	.LC582
	.word	.LC584
	.section	.rodata.str1.1
.LC1966:
	.string	"accel_300"
.LC1967:
	.string	"accel_301"
.LC1968:
	.string	"start_relative"
.LC1969:
	.string	"stop_normal"
.LC1970:
	.string	"stop_fast"
	.section	.rodata
	.align	4
	.type	CSWTCH$1586, @object
	.size	CSWTCH$1586, 20
CSWTCH$1586:
	.word	.LC1966
	.word	.LC1967
	.word	.LC1968
	.word	.LC1969
	.word	.LC1970
	.section	.rodata.str1.1
.LC1971:
	.string	"reply_error"
.LC1972:
	.string	"cancelled"
.LC1973:
	.string	"deadline"
.LC1974:
	.string	"timing_unqualified"
.LC1975:
	.string	"unconfirmed_response"
.LC1976:
	.string	"observation_limit"
.LC1977:
	.string	"acknowledged"
	.section	.rodata
	.align	4
	.type	CSWTCH$1535, @object
	.size	CSWTCH$1535, 40
CSWTCH$1535:
	.word	.LC337
	.word	.LC962
	.word	.LC1971
	.word	.LC1965
	.word	.LC1972
	.word	.LC1973
	.word	.LC1974
	.word	.LC1975
	.word	.LC1976
	.word	.LC1977
	.section	.rodata.str1.1
.LC1978:
	.string	"not_transmitted"
.LC1979:
	.string	"rejected"
	.section	.rodata
	.align	4
	.type	CSWTCH$1533, @object
	.size	CSWTCH$1533, 12
CSWTCH$1533:
	.word	.LC1978
	.word	.LC1977
	.word	.LC1979
	.section	.rodata.str1.1
.LC1980:
	.string	"8N2"
.LC1981:
	.string	"8E1"
.LC1982:
	.string	"8O1"
	.section	.rodata
	.align	4
	.type	CSWTCH$1501, @object
	.size	CSWTCH$1501, 16
CSWTCH$1501:
	.word	.LC1519
	.word	.LC1980
	.word	.LC1981
	.word	.LC1982
	.section	.rodata.str1.1
.LC1983:
	.string	"INVALID_CONFIG"
.LC1984:
	.string	"ILLEGAL_VALUE"
.LC1985:
	.string	"UNSUPPORTED"
.LC1986:
	.string	"CRC_ERROR"
.LC1987:
	.string	"FRAME_ERROR"
.LC1988:
	.string	"EXCEPTION"
	.section	.rodata
	.align	4
	.type	CSWTCH$1411, @object
	.size	CSWTCH$1411, 28
CSWTCH$1411:
	.word	.LC413
	.word	.LC1983
	.word	.LC1984
	.word	.LC1985
	.word	.LC1986
	.word	.LC1987
	.word	.LC1988
	.section	.rodata.str1.1
.LC1989:
	.string	"request"
.LC1990:
	.string	"generation"
	.section	.rodata
	.align	4
	.type	CSWTCH$1384, @object
	.size	CSWTCH$1384, 16
CSWTCH$1384:
	.word	.LC337
	.word	.LC1989
	.word	.LC1990
	.word	.LC1272
	.section	.rodata.str1.1
.LC1991:
	.string	"queue_expired"
.LC1992:
	.string	"transport"
.LC1993:
	.string	"success"
.LC1994:
	.string	"device_rejected"
.LC1995:
	.string	"invalid_reply"
.LC1996:
	.string	"dispatch_expired"
.LC1997:
	.string	"sent"
	.section	.rodata
	.align	4
	.type	CSWTCH$1382, @object
	.size	CSWTCH$1382, 32
CSWTCH$1382:
	.word	.LC1991
	.word	.LC1992
	.word	.LC1993
	.word	.LC1994
	.word	.LC1995
	.word	.LC1972
	.word	.LC1996
	.word	.LC1997
	.section	.rodata.str1.1
.LC1998:
	.string	"not_read"
.LC1999:
	.string	"match"
.LC2000:
	.string	"mismatch"
	.section	.rodata
	.align	4
	.type	CSWTCH$1377, @object
	.size	CSWTCH$1377, 12
CSWTCH$1377:
	.word	.LC1998
	.word	.LC1999
	.word	.LC2000
	.align	4
	.type	CSWTCH$1375, @object
	.size	CSWTCH$1375, 16
CSWTCH$1375:
	.word	.LC337
	.word	.LC1969
	.word	.LC1970
	.word	.LC1375
	.section	.rodata.str1.1
.LC2001:
	.string	"joined"
.LC2002:
	.string	"unexpected"
	.section	.rodata
	.align	4
	.type	CSWTCH$1373, @object
	.size	CSWTCH$1373, 16
CSWTCH$1373:
	.word	.LC1998
	.word	.LC2001
	.word	.LC411
	.word	.LC2002
	.section	.rodata.str1.1
.LC2003:
	.string	"not_sent"
.LC2004:
	.string	"started"
	.section	.rodata
	.align	4
	.type	CSWTCH$1371, @object
	.size	CSWTCH$1371, 16
CSWTCH$1371:
	.word	.LC2003
	.word	.LC2004
	.word	.LC107
	.word	.LC1979
	.align	4
	.type	CSWTCH$1369, @object
	.size	CSWTCH$1369, 16
CSWTCH$1369:
	.word	.LC588
	.word	.LC590
	.word	.LC592
	.word	.LC594
	.section	.rodata.str1.1
.LC2005:
	.string	"read_state"
	.section	.rodata
	.align	4
	.type	CSWTCH$1367, @object
	.size	CSWTCH$1367, 16
CSWTCH$1367:
	.word	.LC324
	.word	.LC1066
	.word	.LC570
	.word	.LC2005
	.section	.rodata.str1.1
.LC2006:
	.string	"accepted"
.LC2007:
	.string	"busy"
.LC2008:
	.string	"recovery_required"
.LC2009:
	.string	"queue_full"
.LC2010:
	.string	"results_full"
.LC2011:
	.string	"ids_exhausted"
.LC2012:
	.string	"already_terminal"
.LC2013:
	.string	"axis_conflict"
.LC2014:
	.string	"qualification_required"
	.section	.rodata
	.align	4
	.type	CSWTCH$1365, @object
	.size	CSWTCH$1365, 64
CSWTCH$1365:
	.word	.LC2006
	.word	.LC2007
	.word	.LC2008
	.word	.LC754
	.word	.LC263
	.word	.LC2009
	.word	.LC2010
	.word	.LC2011
	.word	.LC775
	.word	.LC2012
	.word	.LC1974
	.word	.LC343
	.word	.LC2013
	.word	.LC679
	.word	.LC780
	.word	.LC2014
	.section	.rodata.str1.1
.LC2015:
	.string	"release"
.LC2016:
	.string	"clear_alarm"
.LC2017:
	.string	"clear_position"
	.section	.rodata
	.align	4
	.type	CSWTCH$1361, @object
	.size	CSWTCH$1361, 20
CSWTCH$1361:
	.word	.LC562
	.word	.LC2015
	.word	.LC2016
	.word	.LC570
	.word	.LC2017
	.align	4
	.type	CSWTCH$1352, @object
	.size	CSWTCH$1352, 228
CSWTCH$1352:
	.word	.LC57
	.word	.LC57
	.word	.LC54
	.word	.LC52
	.word	.LC52
	.word	.LC56
	.word	.LC52
	.word	.LC56
	.word	.LC56
	.word	.LC56
	.word	.LC56
	.word	.LC56
	.word	.LC55
	.word	.LC55
	.word	.LC55
	.word	.LC52
	.word	.LC57
	.word	.LC57
	.word	.LC52
	.word	.LC52
	.word	.LC52
	.word	.LC52
	.word	.LC54
	.word	.LC54
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC53
	.word	.LC53
	.word	.LC51
	.word	.LC53
	.word	.LC53
	.word	.LC53
	.word	.LC54
	.word	.LC54
	.word	.LC53
	.word	.LC53
	.word	.LC56
	.word	.LC54
	.word	.LC54
	.word	.LC54
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC51
	.word	.LC54
	.word	.LC52
	.word	.LC53
	.word	.LC51
	.word	.LC56
	.word	.LC51
	.section	.rodata.str1.1
.LC2018:
	.string	"adapter"
.LC2019:
	.string	"runner"
	.section	.rodata
	.align	4
	.type	CSWTCH$1347, @object
	.size	CSWTCH$1347, 16
CSWTCH$1347:
	.word	.LC337
	.word	.LC2018
	.word	.LC2019
	.word	.LC1561
	.section	.rodata.str1.1
.LC2020:
	.string	"readback_mismatch"
.LC2021:
	.string	"update_not_admitted"
	.section	.rodata
	.align	4
	.type	CSWTCH$1345, @object
	.size	CSWTCH$1345, 40
CSWTCH$1345:
	.word	.LC337
	.word	.LC1993
	.word	.LC1971
	.word	.LC1965
	.word	.LC1972
	.word	.LC1973
	.word	.LC1974
	.word	.LC1975
	.word	.LC2020
	.word	.LC2021
	.align	4
	.type	CSWTCH$1343, @object
	.size	CSWTCH$1343, 28
CSWTCH$1343:
	.word	.LC337
	.word	.LC1993
	.word	.LC1971
	.word	.LC1965
	.word	.LC1972
	.word	.LC1973
	.word	.LC1974
	.section	.rodata.str1.1
.LC2022:
	.string	"empty"
	.section	.rodata
	.align	4
	.type	CSWTCH$1341, @object
	.size	CSWTCH$1341, 16
CSWTCH$1341:
	.word	.LC2022
	.word	.LC1023
	.word	.LC959
	.word	.LC263
	.align	4
	.type	CSWTCH$1339, @object
	.size	CSWTCH$1339, 20
CSWTCH$1339:
	.word	.LC546
	.word	.LC548
	.word	.LC550
	.word	.LC552
	.word	.LC554
	.section	.rodata.str1.1
.LC2023:
	.string	"velocity_parameters"
.LC2024:
	.string	"homing_parameters"
	.section	.rodata
	.align	4
	.type	CSWTCH$1337, @object
	.size	CSWTCH$1337, 20
CSWTCH$1337:
	.word	.LC1582
	.word	.LC320
	.word	.LC1347
	.word	.LC2023
	.word	.LC2024
	.section	.rodata.str1.1
.LC2025:
	.string	"current_loop"
	.section	.rodata
	.align	4
	.type	CSWTCH$1335, @object
	.size	CSWTCH$1335, 16
CSWTCH$1335:
	.word	.LC1726
	.word	.LC2025
	.word	.LC1730
	.word	.LC1732
	.section	.rodata.str1.1
.LC2026:
	.string	"read state [address]"
.LC2027:
	.string	"checked_nonconsuming_state_read"
.LC2028:
	.string	"Read drive state."
	.section	.rodata
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L11STATE_ENTRYE, @object
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L11STATE_ENTRYE, 24
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L11STATE_ENTRYE:
	.word	.LC550
	.byte	20
	.zero	3
	.word	.LC2026
	.word	.LC2027
	.byte	1
	.zero	3
	.word	.LC2028
	.section	.rodata.str1.1
.LC2029:
	.string	"read config [address]"
.LC2030:
	.string	"checked_configuration_read"
.LC2031:
	.string	"Read drive configuration."
	.section	.rodata
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L12CONFIG_ENTRYE, @object
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L12CONFIG_ENTRYE, 24
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L12CONFIG_ENTRYE:
	.word	.LC548
	.byte	19
	.zero	3
	.word	.LC2029
	.word	.LC2030
	.byte	1
	.zero	3
	.word	.LC2031
	.section	.rodata.str1.1
.LC2032:
	.string	"read identity [address]"
.LC2033:
	.string	"checked_identity_read"
.LC2034:
	.string	"Read drive identity."
	.section	.rodata
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L14IDENTITY_ENTRYE, @object
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L14IDENTITY_ENTRYE, 24
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L14IDENTITY_ENTRYE:
	.word	.LC546
	.byte	18
	.zero	3
	.word	.LC2032
	.word	.LC2033
	.byte	1
	.zero	3
	.word	.LC2034
	.section	.rodata.str1.1
.LC2035:
	.string	"moveby VALUE [steps|deg|turn|mm]"
.LC2036:
	.string	"finite_relative_move_with_readonly_preparation"
.LC2037:
	.string	"Move by an amount; default unit is command steps. Round to nearest command step, ties to even."
.LC2038:
	.string	"moveto VALUE [steps|deg|turn|mm]"
.LC2039:
	.string	"finite_absolute_move_with_readonly_preparation"
.LC2040:
	.string	"Move relative to this boot's stationary zero; no device counter clear or NVS. Round to nearest command step, ties to even. Requires valid position confidence."
.LC2041:
	.string	"speed [VALUE [rpm]]"
.LC2042:
	.string	"host_intent_applied_by_next_simple_move"
.LC2043:
	.string	"Show or set speed for the next move (0..3000 rpm; default 60; zero prevents a move). Position default: <=2000 rpm and <=50000 increments/s; settings shows subdivision limit."
.LC2044:
	.string	"accel [VALUE [ms]]"
.LC2045:
	.string	"host_intent_native_ramp_applied_by_next_simple_move"
.LC2046:
	.string	"Show or set acceleration ramp time in ms (0..2000 native; position default admits 100..2000)."
.LC2047:
	.string	"decel"
.LC2048:
	.string	"decel [VALUE [ms]]"
.LC2049:
	.string	"Show or set deceleration ramp time in ms (0..2000 native; position default admits 100..2000)."
.LC2050:
	.string	"motion"
.LC2051:
	.string	"motion [write|stored]"
.LC2052:
	.string	"inspect_or_select_simple_motion_setup"
.LC2053:
	.string	"Choose setup policy: write parameters before start, or explicitly reuse stored parameters."
.LC2054:
	.string	"subdivision [INTEGER|options]"
.LC2055:
	.string	"typed_drive_subdivision_read_write_with_checked_readback"
.LC2056:
	.string	"Read or set motor subdivision (400..51200); options shows useful examples. Automatically checks stopped state and reads back the setting."
.LC2057:
	.string	"stepsperturn"
.LC2058:
	.string	"stepsperturn POSITIVE_NUMBER"
.LC2059:
	.string	"host_command_scale_only_no_motor_settings"
.LC2060:
	.string	"Declare command steps per motor turn for angle conversion."
.LC2061:
	.ascii	"discover [profile ess_rs|manufacturer stepperonline] [addres"
	.ascii	"ses FIRST LAST] [tuple BAUD FORMAT] [query-ms 1..5000] "
	.string	"[overall-ms 1..60000] [requests 1..256] [results 1..8] [identity] | discover inspect|cancel|restore|finish; max4 distinct tuples,128bytes,20tokens; defaults selected endpoint/current tuple,query500ms,overall5000ms,requests16,results8,no identity,no retries"
.LC2062:
	.string	"bounded_nonchanging_queries_retained_findings_host_restoration"
.LC2063:
	.string	"Find responding drives within explicit address, serial and time limits."
.LC2064:
	.string	"debug [off|raw|decoded]"
.LC2065:
	.string	"observe_regular_operations_and_cached_diagnostics"
.LC2066:
	.string	"Show diagnostics; select raw or decoded traffic while ordinary commands run."
.LC2067:
	.string	"position interrupt <original-id>"
.LC2068:
	.string	"qualified_stored_position_start_or_interrupt_ack_only"
.LC2069:
	.string	"Retrigger the exact stored native move. Acknowledgement does not prove interruption or arrival; use a checked stop to settle motion."
.LC2070:
	.string	"motion-profile read|inspect|restore|forget | motion-profile start-speed <native>"
.LC2071:
	.string	"snapshot_restore_or_explicit_native_start_speed_setting"
.LC2072:
	.string	"Read, inspect or restore position parameters; explicitly set native start speed; forget releases the snapshot."
.LC2073:
	.string	"help [command]"
.LC2074:
	.string	"show_callable_commands"
.LC2075:
	.string	"Show all commands once, or detailed syntax for one command."
.LC2076:
	.string	"version"
.LC2077:
	.string	"show_build"
.LC2078:
	.string	"Show the firmware version and console protocol."
.LC2079:
	.string	"show_host_settings"
.LC2080:
	.string	"Show the selected address and host communication settings."
.LC2081:
	.string	"settings"
.LC2082:
	.string	"read_actual_motor_settings_and_next_move_choices"
.LC2083:
	.string	"Read actual motor settings and show the next move choices together."
.LC2084:
	.string	"useaddr 1..247"
.LC2085:
	.string	"idle_host_selection_invalidates_dependent_confidence_no_motor_io"
.LC2086:
	.string	"Select a host target while idle; this does not change the drive address."
.LC2087:
	.string	"wiring [x0|x1|x2|x3|y0|y1 unknown|unconnected|connected]"
.LC2088:
	.string	"declare_external_wiring_only_no_device_assignment_or_io"
.LC2089:
	.string	"Declare connected or unconnected terminals without changing their functions."
.LC2090:
	.string	"host [baud RATE | fmt 8N1|8N2|8E1|8O1 | set RATE FORMAT | restore | caps]"
.LC2091:
	.string	"settled_host_serial_only_no_motor_settings"
.LC2092:
	.string	"Show or change host UART settings; drive settings stay separate."
.LC2093:
	.string	"communication [inspect | plan|begin address|baud|format VALUE [address] | host before|requested | confirm before|requested | finish]"
.LC2094:
	.string	"explicit_communication_session_no_save_restart_or_replay"
.LC2095:
	.string	"Plan and apply a drive communication change, then check its responding endpoint."
.LC2096:
	.string	"persistence [inspect | snapshot | plan|begin save|factory-restore | verify | host before | finish]"
.LC2097:
	.string	"one_explicit_save_or_factory_restore_no_retry_or_inferred_durability"
.LC2098:
	.string	"Inspect, plan or attempt an explicit save or factory restoration."
.LC2099:
	.string	"show_cached_observations"
.LC2100:
	.string	"Show cached drive and transport observations, including their age."
.LC2101:
	.string	"health"
.LC2102:
	.string	"show_cached_health"
.LC2103:
	.string	"Show cached health; use read state to refresh observations."
.LC2104:
	.string	"stats [reset]"
.LC2105:
	.string	"show_or_clear_host_counters"
.LC2106:
	.string	"Show diagnostic counters; stats reset clears host counters only."
.LC2107:
	.string	"probe [address]"
.LC2108:
	.string	"read_model_word_only"
.LC2109:
	.string	"Read one model word to check communication."
.LC2110:
	.string	"capture-read [address]"
.LC2111:
	.string	"read_0x0130_16_words_for_capture_qualification"
.LC2112:
	.string	"Read a fixed 16-word window for transport timing diagnostics."
.LC2113:
	.string	"read identity|config|state [address]"
.LC2114:
	.string	"checked_nonchanging_read"
.LC2115:
	.string	"Refresh drive identity, configuration or state through checked reads."
.LC2116:
	.string	"list_available_profiles"
.LC2117:
	.string	"List available drive profiles."
.LC2118:
	.string	"driver read [address] | driver set field integer [field integer ...] [address]"
.LC2119:
	.string	"typed_drive_settings_with_checked_readback"
.LC2120:
	.string	"Read or update supported drive settings and check their readback."
.LC2121:
	.string	"io read [address] | io set input-polarity|x0|x1|x2|x3|output-polarity|y0|y1|custom value [field value ...] [address]; none assigns function 0"
.LC2122:
	.string	"explicit_typed_terminal_settings_and_readback"
.LC2123:
	.string	"Read or update terminal functions and polarity; none selects function zero."
.LC2124:
	.string	"segment position|speed|start INDEX read [address] | segment position|speed|start INDEX set FIELD INTEGER [FIELD INTEGER ...] [address]"
.LC2125:
	.string	"indexed_stored_records_only_external_execution"
.LC2126:
	.string	"Read or update stored segment settings; this does not execute a segment."
.LC2127:
	.string	"control read [address] | control set algorithm|encoder-resolution|maximum-effective-current|closed-maximum-current|closed-base-current|open-maximum-current|lock-current|lock-delay INTEGER [field integer ...] [address]; algorithm open-loop|algorithm-1"
.LC2128:
	.string	"stopped_native_control_settings_and_checked_readback"
.LC2129:
	.string	"Read or update supported control settings while the drive is stopped."
.LC2130:
	.ascii	"tuning filters|current-loop|la|collision read [address] | tu"
	.ascii	"ning GROUP se"
	.string	"t FIELD INTEGER [FIELD INTEGER ...] [address]; filters: input-filter pulse-low-pass deviation-threshold arrival-window arrival-time pulse-mean; current-loop: multiplier kp ki kc; la: kp1 kv1 node1 kp2 kv2 node2 kvf position-ki; collision: threshold current"
.LC2131:
	.string	"qualified_stopped_native_tuning_and_checked_readback"
.LC2132:
	.string	"Read or update named filter, current-loop, LA or collision parameters."
.LC2133:
	.string	"home methods | home read [address] | home auxiliary <0..11> | home method search_native return_native ramp_native zero [address]"
.LC2134:
	.string	"checked_parameter_read_auxiliary_setting_or_qualified_homing"
.LC2135:
	.string	"Read homing parameters, select auxiliary configuration, list methods or request qualified homing."
.LC2136:
	.string	"enable [address]"
.LC2137:
	.string	"request_enable_then_observe_flags"
.LC2138:
	.string	"Request motor enable and observe the resulting flags."
.LC2139:
	.string	"motor-release [address] | motor-release after-stop ID mechanics-permit-release triggers-inhibited"
.LC2140:
	.string	"request_release_then_observe_flags"
.LC2141:
	.string	"Request motor release; after-stop requires explicit mechanical and trigger facts."
.LC2142:
	.string	"alarm-clear [address]"
.LC2143:
	.string	"request_clear_resettable_alarm_then_observe_flags"
.LC2144:
	.string	"Request alarm clearing and check the drive flags."
.LC2145:
	.string	"stop normal|fast [address]"
.LC2146:
	.string	"priority_stop_with_explicit_policy_then_observe_flags"
.LC2147:
	.ascii	"normal: stop with deceleration; f"
	.string	"ast: ESS emergency stop without the ramp. An admitted ordinary stop may recover once before its first send; target, tuple, lease and capacity checks still apply. A sent stop whose reply is lost is never resent; stop fast can escalate a running stop normal."
.LC2148:
	.ascii	"move relative|absolute value unit frame native_rpm configure"
	.ascii	"d [setup write|verify|sto"
	.string	"red] [basis actual|commanded|queued] [round mode error [approx error]] [address] | move angle value unit frame positive|negative|shortest reject|positive|negative native_rpm configured [setup write|verify|stored] [round mode error [approx error]] [address]"
.LC2149:
	.string	"finite_move_through_public_coordinate_preparation"
.LC2150:
	.string	"Advanced move: explicit frame, rounding and setup policy; ordinary moves use moveby/moveto."
.LC2151:
	.string	"position-clear [address]"
.LC2152:
	.string	"explicit_device_position_zero_only"
.LC2153:
	.string	"Explicitly set the drive position counter to zero."
.LC2154:
	.string	"velocity read [address] | velocity value rpm|steps/s|fullsteps/s|counts/s|turns/s|deg/s|rad/s|mm/s native|motor|load duration_ms configured normal|fast [round mode error [approx error]] [address]"
.LC2155:
	.string	"checked_parameter_read_or_finite_serial_velocity_with_explicit_stop"
.LC2156:
	.string	"Read native velocity parameters or request finite velocity with an explicit stop policy."
.LC2157:
	.string	"monitor [off | interval_ms count]"
.LC2158:
	.string	"finite_nonconsuming_state_polling"
.LC2159:
	.string	"Read drive state a finite number of times; off ends local polling."
.LC2160:
	.string	"show_implemented_routes_and_explicit_capability_gaps"
.LC2161:
	.string	"Show implemented operations and unsupported or unresolved capabilities."
.LC2162:
	.string	"axis"
.LC2163:
	.string	"axis config [set field value [maximum]] | axis origin exact_native"
.LC2164:
	.string	"configure_host_coordinates_only"
.LC2165:
	.string	"Configure host coordinates, units and origin without motor traffic."
.LC2166:
	.string	"prepare"
.LC2167:
	.string	"prepare absolute value unit frame [round [max_error [radian_error]]] | prepare relative value unit frame basis [round [max_error [radian_error]]] | prepare angle value unit frame path tie [round [max_error [radian_error]]]"
.LC2168:
	.string	"preview_public_target_arithmetic_without_motion"
.LC2169:
	.string	"Preview coordinate conversion and rounding without moving the motor."
.LC2170:
	.string	"recover_host_transport_only"
.LC2171:
	.string	"Recover the host transport; this does not stop or reset the motor. A held stop is sent afterwards; nothing else resumes."
.LC2172:
	.string	"memory"
.LC2173:
	.string	"show_cached_memory"
.LC2174:
	.string	"Show cached memory and stack measurements."
.LC2175:
	.string	"load [work_us owner_delay_us console_bytes]"
.LC2176:
	.string	"configure_or_report_host_load"
.LC2177:
	.string	"Show or configure the optional host workload used for timing checks."
.LC2178:
	.string	"drv"
.LC2179:
	.string	"show_owner_queue_and_output"
.LC2180:
	.string	"Show the bus owner, queues, retained results and console pressure."
.LC2181:
	.string	"result [operation_id]"
.LC2182:
	.string	"inspect_retained_result_without_consuming"
.LC2183:
	.string	"Inspect an operation without consuming its retained result."
.LC2184:
	.string	"cancel [operation_id]"
.LC2185:
	.string	"cancel_local_work_not_motor_stop"
.LC2186:
	.string	"Cancel local work; use stop to request a motor stop."
.LC2187:
	.ascii	"group show|status|clear | group set ADDR [ADDR ...] (1..15) "
	.ascii	"| "
	.string	"group wiring ADDR x0|x1|x2|x3|y0|y1 unknown|unconnected|connected | group read state | group move relative value unit frame native_rpm configured [setup write|verify] [start staged|sequential] on-failure leave|stop normal|stop fast | group stop normal|fast"
.LC2188:
	.string	"unicast_drive_group_independent_member_operations"
.LC2189:
	.string	"Declare up to 15 drives, read their state, stage every move and then send only the starts, or stop each one. Each member keeps its own result."
.LC2190:
	.string	"broadcast accel 300|301 | broadcast start relative | broadcast stop normal|fast"
.LC2191:
	.string	"fixture_only_unconfirmed_address_0_frame_then_silent_window"
.LC2192:
	.string	"Bench fixture only: send one fixed address-0 frame to every drive, then listen 200 ms. No drive confirms it; read each drive back."
.LC2193:
	.string	"release operation_id"
.LC2194:
	.string	"release_retained_terminal_result"
.LC2195:
	.string	"Release an inspected terminal result to free its storage."
	.section	.rodata
	.align	4
	.type	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L8COMMANDSE, @object
	.size	_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L8COMMANDSE, 1296
_ZN21MotorControlRSExample5Probe12_GLOBAL__N_1L8COMMANDSE:
	.word	.LC1019
	.byte	45
	.zero	3
	.word	.LC2035
	.word	.LC2036
	.byte	1
	.zero	3
	.word	.LC2037
	.word	.LC1021
	.byte	46
	.zero	3
	.word	.LC2038
	.word	.LC2039
	.byte	1
	.zero	3
	.word	.LC2040
	.word	.LC36
	.byte	47
	.zero	3
	.word	.LC2041
	.word	.LC2042
	.byte	0
	.zero	3
	.word	.LC2043
	.word	.LC1829
	.byte	48
	.zero	3
	.word	.LC2044
	.word	.LC2045
	.byte	0
	.zero	3
	.word	.LC2046
	.word	.LC2047
	.byte	49
	.zero	3
	.word	.LC2048
	.word	.LC2045
	.byte	0
	.zero	3
	.word	.LC2049
	.word	.LC2050
	.byte	50
	.zero	3
	.word	.LC2051
	.word	.LC2052
	.byte	0
	.zero	3
	.word	.LC2053
	.word	.LC17
	.byte	53
	.zero	3
	.word	.LC2054
	.word	.LC2055
	.byte	1
	.zero	3
	.word	.LC2056
	.word	.LC2057
	.byte	51
	.zero	3
	.word	.LC2058
	.word	.LC2059
	.byte	0
	.zero	3
	.word	.LC2060
	.word	.LC1554
	.byte	42
	.zero	3
	.word	.LC2061
	.word	.LC2062
	.byte	1
	.zero	3
	.word	.LC2063
	.word	.LC1618
	.byte	41
	.zero	3
	.word	.LC2064
	.word	.LC2065
	.byte	0
	.zero	3
	.word	.LC2066
	.word	.LC1736
	.byte	54
	.zero	3
	.word	.LC2067
	.word	.LC2068
	.byte	1
	.zero	3
	.word	.LC2069
	.word	.LC1632
	.byte	40
	.zero	3
	.word	.LC2070
	.word	.LC2071
	.byte	1
	.zero	3
	.word	.LC2072
	.word	.LC1858
	.byte	0
	.zero	3
	.word	.LC2073
	.word	.LC2074
	.byte	0
	.zero	3
	.word	.LC2075
	.word	.LC2076
	.byte	1
	.zero	3
	.word	.LC2076
	.word	.LC2077
	.byte	0
	.zero	3
	.word	.LC2078
	.word	.LC320
	.byte	2
	.zero	3
	.word	.LC320
	.word	.LC2079
	.byte	0
	.zero	3
	.word	.LC2080
	.word	.LC2081
	.byte	52
	.zero	3
	.word	.LC2081
	.word	.LC2082
	.byte	1
	.zero	3
	.word	.LC2083
	.word	.LC1836
	.byte	43
	.zero	3
	.word	.LC2084
	.word	.LC2085
	.byte	0
	.zero	3
	.word	.LC2086
	.word	.LC1341
	.byte	44
	.zero	3
	.word	.LC2087
	.word	.LC2088
	.byte	0
	.zero	3
	.word	.LC2089
	.word	.LC1644
	.byte	37
	.zero	3
	.word	.LC2090
	.word	.LC2091
	.byte	0
	.zero	3
	.word	.LC2092
	.word	.LC1682
	.byte	38
	.zero	3
	.word	.LC2093
	.word	.LC2094
	.byte	1
	.zero	3
	.word	.LC2095
	.word	.LC1657
	.byte	39
	.zero	3
	.word	.LC2096
	.word	.LC2097
	.byte	1
	.zero	3
	.word	.LC2098
	.word	.LC1332
	.byte	3
	.zero	3
	.word	.LC1332
	.word	.LC2099
	.byte	0
	.zero	3
	.word	.LC2100
	.word	.LC2101
	.byte	4
	.zero	3
	.word	.LC2101
	.word	.LC2102
	.byte	0
	.zero	3
	.word	.LC2103
	.word	.LC245
	.byte	5
	.zero	3
	.word	.LC2104
	.word	.LC2105
	.byte	0
	.zero	3
	.word	.LC2106
	.word	.LC596
	.byte	6
	.zero	3
	.word	.LC2107
	.word	.LC2108
	.byte	1
	.zero	3
	.word	.LC2109
	.word	.LC598
	.byte	7
	.zero	3
	.word	.LC2110
	.word	.LC2111
	.byte	1
	.zero	3
	.word	.LC2112
	.word	.LC867
	.byte	15
	.zero	3
	.word	.LC2113
	.word	.LC2114
	.byte	1
	.zero	3
	.word	.LC2115
	.word	.LC1565
	.byte	16
	.zero	3
	.word	.LC163
	.word	.LC2116
	.byte	0
	.zero	3
	.word	.LC2117
	.word	.LC578
	.byte	31
	.zero	3
	.word	.LC2118
	.word	.LC2119
	.byte	1
	.zero	3
	.word	.LC2120
	.word	.LC580
	.byte	32
	.zero	3
	.word	.LC2121
	.word	.LC2122
	.byte	1
	.zero	3
	.word	.LC2123
	.word	.LC582
	.byte	34
	.zero	3
	.word	.LC2124
	.word	.LC2125
	.byte	1
	.zero	3
	.word	.LC2126
	.word	.LC584
	.byte	35
	.zero	3
	.word	.LC2127
	.word	.LC2128
	.byte	1
	.zero	3
	.word	.LC2129
	.word	.LC586
	.byte	36
	.zero	3
	.word	.LC2130
	.word	.LC2131
	.byte	1
	.zero	3
	.word	.LC2132
	.word	.LC576
	.byte	33
	.zero	3
	.word	.LC2133
	.word	.LC2134
	.byte	1
	.zero	3
	.word	.LC2135
	.word	.LC562
	.byte	24
	.zero	3
	.word	.LC2136
	.word	.LC2137
	.byte	1
	.zero	3
	.word	.LC2138
	.word	.LC564
	.byte	25
	.zero	3
	.word	.LC2139
	.word	.LC2140
	.byte	1
	.zero	3
	.word	.LC2141
	.word	.LC566
	.byte	26
	.zero	3
	.word	.LC2142
	.word	.LC2143
	.byte	1
	.zero	3
	.word	.LC2144
	.word	.LC570
	.byte	27
	.zero	3
	.word	.LC2145
	.word	.LC2146
	.byte	1
	.zero	3
	.word	.LC2147
	.word	.LC1066
	.byte	28
	.zero	3
	.word	.LC2148
	.word	.LC2149
	.byte	1
	.zero	3
	.word	.LC2150
	.word	.LC568
	.byte	29
	.zero	3
	.word	.LC2151
	.word	.LC2152
	.byte	1
	.zero	3
	.word	.LC2153
	.word	.LC574
	.byte	30
	.zero	3
	.word	.LC2154
	.word	.LC2155
	.byte	1
	.zero	3
	.word	.LC2156
	.word	.LC1855
	.byte	21
	.zero	3
	.word	.LC2157
	.word	.LC2158
	.byte	1
	.zero	3
	.word	.LC2159
	.word	.LC1646
	.byte	17
	.zero	3
	.word	.LC1646
	.word	.LC2160
	.byte	0
	.zero	3
	.word	.LC2161
	.word	.LC2162
	.byte	22
	.zero	3
	.word	.LC2163
	.word	.LC2164
	.byte	0
	.zero	3
	.word	.LC2165
	.word	.LC2166
	.byte	23
	.zero	3
	.word	.LC2167
	.word	.LC2168
	.byte	0
	.zero	3
	.word	.LC2169
	.word	.LC600
	.byte	8
	.zero	3
	.word	.LC600
	.word	.LC2170
	.byte	0
	.zero	3
	.word	.LC2171
	.word	.LC2172
	.byte	9
	.zero	3
	.word	.LC2172
	.word	.LC2173
	.byte	0
	.zero	3
	.word	.LC2174
	.word	.LC270
	.byte	10
	.zero	3
	.word	.LC2175
	.word	.LC2176
	.byte	0
	.zero	3
	.word	.LC2177
	.word	.LC2178
	.byte	11
	.zero	3
	.word	.LC2178
	.word	.LC2179
	.byte	0
	.zero	3
	.word	.LC2180
	.word	.LC809
	.byte	12
	.zero	3
	.word	.LC2181
	.word	.LC2182
	.byte	0
	.zero	3
	.word	.LC2183
	.word	.LC1559
	.byte	13
	.zero	3
	.word	.LC2184
	.word	.LC2185
	.byte	0
	.zero	3
	.word	.LC2186
	.word	.LC1377
	.byte	56
	.zero	3
	.word	.LC2187
	.word	.LC2188
	.byte	1
	.zero	3
	.word	.LC2189
	.word	.LC602
	.byte	55
	.zero	3
	.word	.LC2190
	.word	.LC2191
	.byte	1
	.zero	3
	.word	.LC2192
	.word	.LC2015
	.byte	14
	.zero	3
	.word	.LC2193
	.word	.LC2194
	.byte	0
	.zero	3
	.word	.LC2195
	.weak	_ZZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcjE6DIGITS
	.section	.rodata._ZZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcjE6DIGITS,"aG",@progbits,_ZZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcjE6DIGITS,comdat
	.type	_ZZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcjE6DIGITS, @object
	.size	_ZZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcjE6DIGITS, 17
_ZZN21MotorControlRSExample5Probe13ConsoleReport3hexEPKhjPcjE6DIGITS:
	.string	"0123456789ABCDEF"
	.section	.rodata.str1.1
.LC2196:
	.string	"clear-semantics"
	.section	.rodata
	.align	4
	.type	_ZN21MotorControlRSExample5Probe18QualificationFactsL14POSITION_CLEARE, @object
	.size	_ZN21MotorControlRSExample5Probe18QualificationFactsL14POSITION_CLEARE, 12
_ZN21MotorControlRSExample5Probe18QualificationFactsL14POSITION_CLEARE:
	.word	.LC2196
	.word	42
	.byte	1
	.zero	3
	.section	.rodata.str1.1
.LC2197:
	.string	"ramp"
.LC2198:
	.string	"inputs"
	.section	.rodata
	.align	4
	.type	_ZN21MotorControlRSExample5Probe18QualificationFactsL8VELOCITYE, @object
	.size	_ZN21MotorControlRSExample5Probe18QualificationFactsL8VELOCITYE, 48
_ZN21MotorControlRSExample5Probe18QualificationFactsL8VELOCITYE:
	.word	.LC300
	.word	40
	.byte	1
	.zero	3
	.word	.LC2197
	.word	34
	.byte	1
	.zero	3
	.word	.LC2198
	.word	37
	.byte	1
	.zero	3
	.word	.LC274
	.word	41
	.byte	0
	.zero	3
	.section	.rodata.str1.1
.LC2199:
	.string	"mechanics"
.LC2200:
	.string	"rates"
.LC2201:
	.string	"zero-offset"
.LC2202:
	.string	"reference"
	.section	.rodata
	.align	4
	.type	_ZN21MotorControlRSExample5Probe18QualificationFactsL4HOMEE, @object
	.size	_ZN21MotorControlRSExample5Probe18QualificationFactsL4HOMEE, 96
_ZN21MotorControlRSExample5Probe18QualificationFactsL4HOMEE:
	.word	.LC2199
	.word	32
	.byte	1
	.zero	3
	.word	.LC2200
	.word	33
	.byte	1
	.zero	3
	.word	.LC2197
	.word	34
	.byte	1
	.zero	3
	.word	.LC2201
	.word	35
	.byte	1
	.zero	3
	.word	.LC1709
	.word	36
	.byte	1
	.zero	3
	.word	.LC2198
	.word	37
	.byte	1
	.zero	3
	.word	.LC800
	.word	38
	.byte	0
	.zero	3
	.word	.LC2202
	.word	39
	.byte	0
	.zero	3
	.section	.eh_frame,"a",@progbits
.Lframe1:
	.4byte	.LECIE1-.LSCIE1
.LSCIE1:
	.4byte	0
	.byte	0x3
	.string	"zPL"
	.uleb128 0x1
	.sleb128 -4
	.uleb128 0
	.uleb128 0x6
	.byte	0
	.4byte	__gxx_personality_v0
	.byte	0
	.byte	0xc
	.uleb128 0x1
	.uleb128 0
	.align	4
.LECIE1:
.LSFDE1:
	.4byte	.LEFDE1-.LASFDE1
.LASFDE1:
	.4byte	.LASFDE1-.Lframe1
	.4byte	.LFB1021
	.4byte	.LFE1021-.LFB1021
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI14-.LFB1021
	.byte	0xe
	.uleb128 0x50
	.align	4
.LEFDE1:
.LSFDE3:
	.4byte	.LEFDE3-.LASFDE3
.LASFDE3:
	.4byte	.LASFDE3-.Lframe1
	.4byte	.LFB1246
	.4byte	.LFE1246-.LFB1246
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI15-.LFB1246
	.byte	0xe
	.uleb128 0x90
	.align	4
.LEFDE3:
.LSFDE5:
	.4byte	.LEFDE5-.LASFDE5
.LASFDE5:
	.4byte	.LASFDE5-.Lframe1
	.4byte	.LFB1047
	.4byte	.LFE1047-.LFB1047
	.uleb128 0x4
	.4byte	.LLSDA1047
	.byte	0x4
	.4byte	.LCFI37-.LFB1047
	.byte	0xe
	.uleb128 0x4f0
	.align	4
.LEFDE5:
.LSFDE7:
	.4byte	.LEFDE7-.LASFDE7
.LASFDE7:
	.4byte	.LASFDE7-.Lframe1
	.4byte	.LFB1057
	.4byte	.LFE1057-.LFB1057
	.uleb128 0x4
	.4byte	.LLSDA1057
	.byte	0x4
	.4byte	.LCFI45-.LFB1057
	.byte	0xe
	.uleb128 0x70
	.align	4
.LEFDE7:
.LSFDE9:
	.4byte	.LEFDE9-.LASFDE9
.LASFDE9:
	.4byte	.LASFDE9-.Lframe1
	.4byte	.LFB1073
	.4byte	.LFE1073-.LFB1073
	.uleb128 0x4
	.4byte	.LLSDA1073
	.byte	0x4
	.4byte	.LCFI60-.LFB1073
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE9:
.LSFDE11:
	.4byte	.LEFDE11-.LASFDE11
.LASFDE11:
	.4byte	.LASFDE11-.Lframe1
	.4byte	.LFB1074
	.4byte	.LFE1074-.LFB1074
	.uleb128 0x4
	.4byte	.LLSDA1074
	.byte	0x4
	.4byte	.LCFI61-.LFB1074
	.byte	0xe
	.uleb128 0x2e0
	.align	4
.LEFDE11:
.LSFDE13:
	.4byte	.LEFDE13-.LASFDE13
.LASFDE13:
	.4byte	.LASFDE13-.Lframe1
	.4byte	.LFB1088
	.4byte	.LFE1088-.LFB1088
	.uleb128 0x4
	.4byte	.LLSDA1088
	.byte	0x4
	.4byte	.LCFI63-.LFB1088
	.byte	0xe
	.uleb128 0xb0
	.align	4
.LEFDE13:
.LSFDE15:
	.4byte	.LEFDE15-.LASFDE15
.LASFDE15:
	.4byte	.LASFDE15-.Lframe1
	.4byte	.LFB1204
	.4byte	.LFE1204-.LFB1204
	.uleb128 0x4
	.4byte	.LLSDA1204
	.byte	0x4
	.4byte	.LCFI71-.LFB1204
	.byte	0xe
	.uleb128 0x180
	.align	4
.LEFDE15:
.LSFDE17:
	.4byte	.LEFDE17-.LASFDE17
.LASFDE17:
	.4byte	.LASFDE17-.Lframe1
	.4byte	.LFB1229
	.4byte	.LFE1229-.LFB1229
	.uleb128 0x4
	.4byte	.LLSDA1229
	.byte	0x4
	.4byte	.LCFI86-.LFB1229
	.byte	0xe
	.uleb128 0x70
	.align	4
.LEFDE17:
.LSFDE19:
	.4byte	.LEFDE19-.LASFDE19
.LASFDE19:
	.4byte	.LASFDE19-.Lframe1
	.4byte	.LFB1095
	.4byte	.LFE1095-.LFB1095
	.uleb128 0x4
	.4byte	.LLSDA1095
	.byte	0x4
	.4byte	.LCFI88-.LFB1095
	.byte	0xe
	.uleb128 0x7a0
	.align	4
.LEFDE19:
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	__udivdi3
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	__gxx_personality_v0
	.global	memset
	.global	__ledf2
	.ident	"GCC: (crosstool-NG esp-14.2.0_20241119) 14.2.0"
