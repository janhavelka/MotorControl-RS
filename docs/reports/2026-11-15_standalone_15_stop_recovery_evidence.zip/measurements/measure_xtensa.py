from pathlib import Path
import json
import subprocess

repo = Path(__file__).resolve().parents[2]
work = Path(__file__).resolve().parent
compiler = Path('C:/Users/Honza/.platformio/packages/toolchain-xtensa-esp-elf/bin/xtensa-esp32s3-elf-g++.exe')
source = work / 'xtensa_sizes.cpp'
source.write_text('#include "../../examples/probe_cli/ProbeApp.cpp"\n'
    'extern "C" const size_t measured_sizes[] = {sizeof(App), sizeof(App::Record), sizeof(ActionResult)};\n')
commands = []
for input_source, name in ((source, 'xtensa_app'), (repo / 'examples/probe_cli/ProbeConsole.cpp', 'xtensa_console')):
    command = [str(compiler), '-std=c++11', '-Os', '-S', '-fstack-usage',
               '-I' + str(repo / 'include'), '-I' + str(repo / 'test/fakes/esp32_uart'),
               '-DCONFIG_IDF_TARGET_ESP32S3=1', str(input_source), '-o', str(work / (name + '.s'))]
    commands.append(command)
    subprocess.run(command, cwd=repo, check=True)
assembly = (work / 'xtensa_app.s').read_text().splitlines()
start = assembly.index('measured_sizes:')
sizes = [int(line.split()[1]) for line in assembly[start + 1:start + 4]]
frames = []
for name in ('xtensa_app', 'xtensa_console'):
    for line in (work / (name + '.su')).read_text().splitlines():
        if any(symbol in line for symbol in ('startActionIn(', 'startReleaseAfterStop(', 'submitStop(',
             'copyActionResult(', 'cancelInvalidReleases(', 'Console::reportAction(', 'Console::dispatch(')):
            frames.append(line)
output = {'compiler': subprocess.check_output([str(compiler), '--version'], text=True).splitlines()[0],
          'scope': 'Compile-only ESP32-S3 ABI using SDK stubs, -Os, C++11; static individual function frames only. No runtime, call-chain or task headroom measurement.',
          'sizes': dict(zip(('App', 'Record', 'ActionResult'), sizes)), 'frames': frames, 'commands': commands}
(work / 'xtensa_stage15_measurements.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({key: value for key, value in output.items() if key != 'commands'}, indent=2))
