	.file	"xtensa_sizes.cpp"
	.text
	.section	.rodata.str1.1,"aMS",@progbits,1
.LC12:
	.string	""
	.text
	.literal_position
	.literal .LC13, .LC12
	.align	4
	.type	_ZN12_GLOBAL__N_13App12StageSessionC2Ev, @function
_ZN12_GLOBAL__N_13App12StageSessionC2Ev:
.LFB2024:
	entry	sp, 32
.LCFI0:
	movi.n	a7, 0
	movi.n	a6, 0
	s32i	a7, a2, 0
	s8i	a7, a2, 4
	s32i	a7, a2, 8
	s32i	a7, a2, 12
	s32i	a7, a2, 16
	s32i	a7, a2, 20
	s16i	a7, a2, 24
	s8i	a6, a2, 26
	movi.n	a12, 0xa
	movi.n	a11, 0
	addi	a10, a2, 28
	call8	memset
	movi.n	a12, 0xa
	s8i	a6, a2, 38
	movi.n	a11, 0
	addi	a10, a2, 40
	call8	memset
	l32r	a10, .LC13
	movi.n	a9, 0
	movi.n	a8, 0
	s32i	a10, a2, 128
	movi	a10, 0x9a
	s16i	a7, a2, 50
	s32i	a9, a2, 56
	s32i	a8, a2, 60
	s32i	a7, a2, 64
	s16i	a7, a2, 68
	s32i	a9, a2, 72
	s32i	a8, a2, 76
	s32i	a9, a2, 80
	s32i	a8, a2, 84
	s32i	a9, a2, 88
	s32i	a8, a2, 92
	s32i	a9, a2, 96
	s32i	a8, a2, 100
	s32i	a9, a2, 104
	s32i	a8, a2, 108
	s32i	a9, a2, 112
	s32i	a8, a2, 116
	s8i	a6, a2, 120
	s32i	a7, a2, 124
	s32i	a7, a2, 136
	s32i	a7, a2, 140
	s32i	a9, a2, 144
	s32i	a8, a2, 148
	s8i	a6, a2, 152
	s8i	a6, a2, 153
	movi.n	a12, 0x20
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	retw.n
.LFE2024:
	.size	_ZN12_GLOBAL__N_13App12StageSessionC2Ev, .-_ZN12_GLOBAL__N_13App12StageSessionC2Ev
	.set	_ZN12_GLOBAL__N_13App12StageSessionC1Ev,_ZN12_GLOBAL__N_13App12StageSessionC2Ev
	.literal_position
	.literal .LC14, 813496
	.literal .LC15, 774016
	.align	4
	.type	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh, @function
_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh:
.LFB2050:
	entry	sp, 32
.LCFI1:
	l32r	a8, .LC14
	l32r	a10, .LC15
	add.n	a8, a2, a8
	movi.n	a11, 0x48
	l8ui	a12, a8, 0
	add.n	a9, a2, a10
	movi.n	a8, 0
	addmi	a11, a11, 0xa00
	j	.L4
.L6:
	l8ui	a14, a9, 0
	addi.n	a13, a8, 1
	add.n	a9, a9, a11
	bne	a14, a3, .L7
	mul16u	a8, a8, a11
	add.n	a8, a8, a10
	add.n	a2, a2, a8
	j	.L3
.L7:
	mov.n	a8, a13
.L4:
	extui	a13, a8, 0, 8
	bltu	a13, a12, .L6
	movi.n	a2, 0
.L3:
	retw.n
.LFE2050:
	.size	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh, .-_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	.literal_position
	.literal .LC18, 625324
	.literal .LC19, 626188
	.align	4
	.type	_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb, @function
_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb:
.LFB2053:
	entry	sp, 32
.LCFI2:
	l32r	a8, .LC18
	l32r	a9, .LC19
	mov.n	a10, a2
	mov.n	a11, a3
	add.n	a8, a2, a8
	add.n	a9, a2, a9
	movi	a12, 0x120
	j	.L9
.L12:
	beqz.n	a6, .L10
	l8ui	a13, a8, 212
	beqz.n	a13, .L11
.L10:
	l8ui	a13, a8, 0
	bne	a13, a11, .L11
	s32i	a4, a8, 260
	s32i	a5, a8, 264
.L11:
	add.n	a8, a8, a12
.L9:
	bne	a8, a9, .L12
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L8
	movi	a8, 0x5f8
	add.n	a8, a10, a8
	s32i	a4, a8, 264
	s32i	a5, a8, 268
	addmi	a8, a10, 0x700
	s32i	a4, a8, 288
	s32i	a5, a8, 292
	addmi	a10, a10, 0x800
	s32i	a4, a10, 320
	s32i	a5, a10, 324
.L8:
	retw.n
.LFE2053:
	.size	_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb, .-_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb
	.literal_position
	.literal .LC20, 764508
	.literal .LC21, 771828
	.align	4
	.type	_ZN12_GLOBAL__N_118storedWordsChangedERNS_3AppEh, @function
_ZN12_GLOBAL__N_118storedWordsChangedERNS_3AppEh:
.LFB2054:
	entry	sp, 32
.LCFI3:
	l32r	a8, .LC20
	mov.n	a10, a2
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	mov.n	a11, a3
	bne	a8, a3, .L22
	l32r	a8, .LC21
	movi.n	a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
.L22:
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L21
	addmi	a10, a10, 0xa00
	movi.n	a8, 0
	s8i	a8, a10, 48
.L21:
	retw.n
.LFE2054:
	.size	_ZN12_GLOBAL__N_118storedWordsChangedERNS_3AppEh, .-_ZN12_GLOBAL__N_118storedWordsChangedERNS_3AppEh
	.align	4
	.type	_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy, @function
_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy:
.LFB2055:
	entry	sp, 32
.LCFI4:
	mov.n	a10, a2
	mov.n	a11, a3
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L27
	addmi	a8, a10, 0xa00
	movi.n	a9, 0
	s8i	a9, a8, 48
	l32i	a9, a10, 20
	movi.n	a8, 0
	s32i	a8, a10, 372
	addi.n	a11, a9, -1
	movi.n	a12, -3
	bltu	a12, a11, .L29
	addi.n	a8, a9, 1
.L29:
	s32i	a8, a10, 20
	movi	a8, 0x5f8
	add.n	a8, a10, a8
	s32i	a4, a8, 264
	s32i	a5, a8, 268
	addmi	a8, a10, 0x700
	s32i	a4, a8, 288
	s32i	a5, a8, 292
	addmi	a10, a10, 0x800
	s32i	a4, a10, 320
	s32i	a5, a10, 324
.L27:
	retw.n
.LFE2055:
	.size	_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy, .-_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy
	.literal_position
	.literal .LC22, 774016
	.literal .LC23, 39500
	.literal .LC24, 41820
	.literal .LC25, 44140
	.literal .LC26, 46444
	.literal .LC27, 44233
	.literal .LC28, 46442
	.align	4
	.type	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE, @function
_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE:
.LFB2057:
	entry	sp, 32
.LCFI5:
	l32r	a9, .LC22
	add.n	a8, a2, a9
	l32r	a9, .LC23
	add.n	a9, a8, a9
	l8ui	a2, a9, 0
	bnez.n	a2, .L33
	l32r	a9, .LC24
	add.n	a9, a8, a9
	l8ui	a2, a9, 0
	bnez.n	a2, .L33
	l32r	a9, .LC25
	add.n	a9, a8, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L33
	l32r	a9, .LC26
	add.n	a9, a8, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L33
	l32r	a9, .LC27
	add.n	a9, a8, a9
	l8ui	a2, a9, 0
	bnez.n	a2, .L33
	l32r	a9, .LC28
	add.n	a8, a8, a9
	l8ui	a2, a8, 0
	movi.n	a8, 1
	xor	a2, a2, a8
	extui	a2, a2, 0, 8
.L33:
	retw.n
.LFE2057:
	.size	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE, .-_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	.literal_position
	.literal .LC29, 101000
	.literal .LC30, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm, @function
_ZN12_GLOBAL__N_110findRecordERNS_3AppEm:
.LFB2061:
	entry	sp, 32
.LCFI6:
	l32r	a8, .LC29
	mov.n	a9, a2
	add.n	a2, a2, a8
	l32r	a8, .LC30
	movi.n	a10, 0x50
	add.n	a9, a9, a8
	addmi	a10, a10, 0x2300
	j	.L39
.L42:
	l32i	a8, a2, 4
	bne	a8, a3, .L43
	bnez.n	a8, .L38
.L43:
	add.n	a2, a2, a10
.L39:
	bne	a2, a9, .L42
	movi.n	a2, 0
.L38:
	retw.n
.LFE2061:
	.size	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm, .-_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	.set	_ZN12_GLOBAL__N_110findRecordERKNS_3AppEm,_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	.literal_position
	.literal .LC32, 101000
	.literal .LC33, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_17readingERKNS_3AppE, @function
_ZN12_GLOBAL__N_17readingERKNS_3AppE:
.LFB2067:
	entry	sp, 32
.LCFI7:
	l32r	a9, .LC33
	l32r	a8, .LC32
	add.n	a8, a2, a8
	add.n	a2, a2, a9
	movi.n	a9, 0x50
	addmi	a9, a9, 0x2300
	j	.L48
.L51:
	l32i	a10, a8, 4
	beqz.n	a10, .L49
	l8ui	a10, a8, 0
	bnei	a10, 2, .L49
	l8ui	a10, a8, 101
	beqi	a10, 1, .L52
.L49:
	add.n	a8, a8, a9
.L48:
	bne	a8, a2, .L51
	movi.n	a2, 0
	j	.L50
.L52:
	movi.n	a2, 1
.L50:
	retw.n
.LFE2067:
	.size	_ZN12_GLOBAL__N_17readingERKNS_3AppE, .-_ZN12_GLOBAL__N_17readingERKNS_3AppE
	.literal_position
	.literal .LC35, .L60
	.align	4
	.type	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE, @function
_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE:
.LFB2089:
	entry	sp, 32
.LCFI8:
	movi.n	a12, 0x48
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	l8ui	a8, a3, 0
	addi	a8, a8, -3
	extui	a8, a8, 0, 8
	bgeui	a8, 5, .L58
	l32r	a9, .LC35
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L60:
	.word	.L64
	.word	.L63
	.word	.L62
	.word	.L61
	.word	.L59
	.text
.L59:
	addmi	a9, a3, 0x1f00
	addi	a8, a9, 96
	l32i	a8, a8, 8
	l32i	a10, a9, 96
	l32i	a9, a9, 100
	s32i	a8, a2, 8
	addmi	a8, a3, 0x2000
	l8ui	a8, a8, 96
	s32i	a10, a2, 0
	s32i	a9, a2, 4
	j	.L68
.L61:
	movi	a9, 0xbc
	addmi	a8, a3, 0x1000
	add.n	a8, a8, a9
	l32i	a10, a8, 0
	l32i	a9, a8, 4
	l32i	a8, a8, 8
	s32i	a10, a2, 0
	s32i	a8, a2, 8
	addmi	a8, a3, 0x1700
	l8ui	a8, a8, 40
	s32i	a9, a2, 4
	j	.L68
.L62:
	addmi	a9, a3, 0xd00
	l8ui	a8, a9, 25
	bnei	a8, 3, .L65
	movi.n	a8, 0x18
	addmi	a8, a8, 0xf00
	j	.L67
.L65:
	movi.n	a8, 8
	addmi	a8, a8, 0xc00
.L67:
	add.n	a8, a3, a8
	l32i	a11, a8, 0
	l32i	a10, a8, 4
	l32i	a8, a8, 8
	s32i	a11, a2, 0
	s32i	a8, a2, 8
	s32i	a10, a2, 4
	l8ui	a8, a9, 88
	j	.L68
.L63:
	addmi	a9, a3, 0x700
	addi	a8, a9, 48
	l32i	a8, a8, 8
	l32i	a10, a9, 48
	l32i	a9, a9, 52
	s32i	a8, a2, 8
	addmi	a8, a3, 0x900
	l8ui	a8, a8, 120
	s32i	a10, a2, 0
	s32i	a9, a2, 4
	j	.L68
.L64:
	addmi	a8, a3, 0x500
	l32i	a11, a8, 48
	l32i	a10, a8, 52
	l32i	a9, a8, 56
	l8ui	a8, a8, 136
	s32i	a11, a2, 0
	s32i	a10, a2, 4
	s32i	a9, a2, 8
.L68:
	s8i	a8, a2, 16
.L58:
	l32i	a8, a3, 4
	s8i	a4, a2, 17
	s32i	a8, a2, 12
	retw.n
.LFE2089:
	.size	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE, .-_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	.align	4
	.type	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE, @function
_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE:
.LFB2096:
	entry	sp, 32
.LCFI9:
	l32i	a8, a3, 16
	s32i	a8, a2, 0
	l8ui	a8, a3, 30
	s8i	a8, a2, 4
	l32i	a8, a3, 20
	l16ui	a9, a3, 138
	s32i	a8, a2, 8
	l16ui	a8, a3, 136
	s32i	a8, a2, 52
	l8ui	a8, a3, 204
	s8i	a8, a2, 56
	l8ui	a8, a3, 112
	s32i	a8, a2, 48
	movi.n	a8, 0
	beqz.n	a9, .L70
	movi	a8, 0xcf
	add.n	a8, a3, a8
.L70:
	s32i	a8, a2, 20
	l8ui	a8, a2, 17
	s32i	a9, a2, 24
	beqz.n	a8, .L71
	movi.n	a8, 0
	s8i	a8, a2, 28
	j	.L72
.L71:
	l8ui	a8, a3, 160
	s8i	a8, a2, 28
	bnez.n	a8, .L73
.L72:
	movi.n	a8, 0
	movi.n	a10, 0
	movi.n	a9, 0
	j	.L74
.L73:
	l32i	a10, a3, 144
	l32i	a9, a3, 148
.L74:
	s32i	a10, a2, 32
	s32i	a9, a2, 36
	movi.n	a10, 0
	movi.n	a9, 0
	beqz.n	a8, .L75
	l32i	a10, a3, 152
	l32i	a9, a3, 156
.L75:
	s32i	a10, a2, 40
	s32i	a9, a2, 44
	retw.n
.LFE2096:
	.size	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE, .-_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	.literal_position
	.literal .LC38, 764768
	.literal .LC39, 764760
	.align	4
	.type	_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy, @function
_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy:
.LFB2098:
	entry	sp, 32
.LCFI10:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	l32r	a8, .LC38
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bne	a8, a3, .L81
	l32r	a8, .LC39
	add.n	a2, a2, a8
	l32i	a8, a2, 4
	bltu	a5, a8, .L86
	bne	a8, a5, .L81
	l32i	a8, a2, 0
	bltu	a4, a8, .L86
.L81:
	movi.n	a2, 0
	beqz.n	a10, .L82
	addmi	a10, a10, 0x900
	l32i	a8, a10, 100
	movi.n	a2, 1
	bltu	a5, a8, .L84
	bne	a8, a5, .L85
	l32i	a8, a10, 96
	bltu	a4, a8, .L84
.L85:
	movi.n	a2, 0
.L84:
	extui	a2, a2, 0, 8
	j	.L82
.L86:
	movi.n	a2, 1
.L82:
	retw.n
.LFE2098:
	.size	_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy, .-_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy
	.literal_position
	.literal .LC40, CSWTCH$1256
	.align	4
	.type	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE, @function
_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE:
.LFB2136:
	entry	sp, 32
.LCFI11:
	mov.n	a8, a2
	movi.n	a2, 8
	bltu	a2, a8, .L90
	l32r	a9, .LC40
	add.n	a8, a9, a8
	l8ui	a2, a8, 0
.L90:
	retw.n
.LFE2136:
	.size	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE, .-_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	.align	4
	.type	_ZZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEyENKUlRKNS4_19ReadStepObservationEE_clES9_, @function
_ZZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEyENKUlRKNS4_19ReadStepObservationEE_clES9_:
.LFB2162:
	entry	sp, 32
.LCFI12:
	l32i	a11, a2, 0
	l32i	a10, a3, 60
	l32i	a8, a11, 116
	l32i	a13, a3, 56
	l32i	a9, a11, 112
	mov.n	a12, a2
	bltu	a10, a8, .L94
	bne	a8, a10, .L93
	bgeu	a13, a9, .L93
.L94:
	mov.n	a9, a13
	mov.n	a8, a10
.L93:
	l8ui	a2, a3, 52
	s32i	a9, a11, 112
	s32i	a8, a11, 116
	beqz.n	a2, .L95
	l8ui	a8, a3, 100
	bnez.n	a8, .L106
	l32i	a14, a3, 60
	l32i	a8, a3, 68
	l32i	a13, a3, 56
	l32i	a9, a3, 64
	bltu	a8, a14, .L106
	bne	a14, a8, .L107
	bltu	a9, a13, .L106
.L107:
	l32i	a10, a3, 76
	l32i	a15, a3, 72
	bltu	a10, a8, .L106
	bne	a8, a10, .L108
	bltu	a15, a9, .L106
.L108:
	l32i	a8, a12, 4
	l32i	a9, a8, 0
	l32i	a8, a8, 4
	bltu	a8, a10, .L106
	bne	a10, a8, .L109
	bltu	a9, a15, .L106
.L109:
	l32i	a12, a11, 56
	l32i	a10, a11, 60
	or	a11, a12, a10
	beqz.n	a11, .L95
	sub	a8, a8, a14
	bgeu	a9, a13, .L100
	addi.n	a8, a8, -1
.L100:
	sub	a9, a9, a13
	movi.n	a2, 1
	bltu	a8, a10, .L101
	bne	a10, a8, .L102
	bltu	a9, a12, .L101
.L102:
	movi.n	a2, 0
.L101:
	extui	a2, a2, 0, 8
	j	.L95
.L106:
	movi.n	a2, 0
.L95:
	retw.n
.LFE2162:
	.size	_ZZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEyENKUlRKNS4_19ReadStepObservationEE_clES9_, .-_ZZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEyENKUlRKNS4_19ReadStepObservationEE_clES9_
	.align	4
	.type	_ZN12_GLOBAL__N_119driverConfigEffectsERKN14MotorControlRS6ESS_RS9RawConfigERKNS1_17DriverObservationE, @function
_ZN12_GLOBAL__N_119driverConfigEffectsERKN14MotorControlRS6ESS_RS9RawConfigERKNS1_17DriverObservationE:
.LFB2204:
	entry	sp, 32
.LCFI13:
	l16ui	a9, a2, 0
	l16ui	a10, a3, 24
	mov.n	a8, a2
	sub	a9, a9, a10
	movi.n	a2, 1
	moveqz	a2, a9, a9
	l16ui	a10, a8, 2
	l16ui	a9, a3, 26
	beq	a10, a9, .L117
	movi.n	a9, 2
	or	a2, a2, a9
.L117:
	l16ui	a10, a8, 14
	l16ui	a9, a3, 28
	beq	a10, a9, .L118
	movi.n	a9, 4
	or	a2, a2, a9
.L118:
	l16ui	a10, a8, 12
	l16ui	a9, a3, 30
	beq	a10, a9, .L119
	movi.n	a9, 8
	or	a2, a2, a9
.L119:
	l16ui	a9, a8, 10
	l16ui	a8, a3, 32
	beq	a9, a8, .L120
	movi.n	a8, 0x10
	or	a2, a2, a8
.L120:
	retw.n
.LFE2204:
	.size	_ZN12_GLOBAL__N_119driverConfigEffectsERKN14MotorControlRS6ESS_RS9RawConfigERKNS1_17DriverObservationE, .-_ZN12_GLOBAL__N_119driverConfigEffectsERKN14MotorControlRS6ESS_RS9RawConfigERKNS1_17DriverObservationE
	.align	4
	.type	_ZN12_GLOBAL__N_119changedConfigWindowERKN14MotorControlRS6ESS_RS9RawConfigEtPKtj, @function
_ZN12_GLOBAL__N_119changedConfigWindowERKN14MotorControlRS6ESS_RS9RawConfigEtPKtj:
.LFB2207:
	entry	sp, 128
.LCFI14:
	movi.n	a8, 0x10
	s16i	a8, sp, 0
	movi.n	a8, 1
	s32i	a8, sp, 4
	movi.n	a8, 0x11
	s16i	a8, sp, 8
	movi.n	a8, 2
	s32i	a8, sp, 12
	movi.n	a8, 0x19
	s16i	a8, sp, 16
	movi.n	a8, 4
	s32i	a8, sp, 20
	movi.n	a8, 0x18
	s16i	a8, sp, 24
	movi.n	a8, 8
	s32i	a8, sp, 28
	movi.n	a8, 0x17
	s16i	a8, sp, 32
	movi.n	a8, 0x10
	s32i	a8, sp, 36
	movi.n	a8, 0x40
	s16i	a8, sp, 40
	movi	a8, 0x200
	s32i	a8, sp, 44
	movi.n	a8, 0x41
	s16i	a8, sp, 48
	movi	a8, 0x400
	s32i	a8, sp, 52
	movi.n	a8, 0x42
	s16i	a8, sp, 56
	movi.n	a8, 1
	slli	a8, a8, 11
	s32i	a8, sp, 60
	movi.n	a8, 0x43
	s16i	a8, sp, 64
	movi.n	a8, 1
	slli	a8, a8, 12
	s32i	a8, sp, 68
	movi.n	a8, 0x44
	s16i	a8, sp, 72
	movi.n	a8, 1
	slli	a8, a8, 13
	s32i	a8, sp, 76
	movi	a8, 0x100
	s16i	a8, sp, 80
	movi.n	a8, 1
	slli	a8, a8, 23
	s32i	a8, sp, 84
	movi	a8, 0x101
	s16i	a8, sp, 88
	movi.n	a8, 1
	slli	a8, a8, 24
	s32i	a8, sp, 92
	l16ui	a8, a2, 0
	mov.n	a9, sp
	s16i	a8, sp, 2
	l16ui	a8, a2, 2
	movi.n	a10, 0xc
	s16i	a8, sp, 10
	l16ui	a8, a2, 14
	s16i	a8, sp, 18
	l16ui	a8, a2, 12
	s16i	a8, sp, 26
	l16ui	a8, a2, 10
	s16i	a8, sp, 34
	l16ui	a8, a2, 16
	s16i	a8, sp, 42
	l16ui	a8, a2, 18
	s16i	a8, sp, 50
	l16ui	a8, a2, 20
	s16i	a8, sp, 58
	l16ui	a8, a2, 22
	s16i	a8, sp, 66
	l16ui	a8, a2, 24
	s16i	a8, sp, 74
	l16ui	a8, a2, 26
	s16i	a8, sp, 82
	l16ui	a8, a2, 28
	movi.n	a2, 0
	s16i	a8, sp, 90
	loop	a10, .L123_LEND
.L123:
	l16ui	a8, a9, 0
	movi.n	a11, 0
	bltu	a8, a3, .L122
	sub	a8, a8, a3
	bgeu	a8, a5, .L122
	addx2	a8, a8, a4
	l16ui	a12, a9, 2
	l16ui	a8, a8, 0
	beq	a12, a8, .L122
	l32i	a11, a9, 4
.L122:
	or	a2, a2, a11
	addi.n	a9, a9, 8
	.L123_LEND:
	retw.n
.LFE2207:
	.size	_ZN12_GLOBAL__N_119changedConfigWindowERKN14MotorControlRS6ESS_RS9RawConfigEtPKtj, .-_ZN12_GLOBAL__N_119changedConfigWindowERKN14MotorControlRS6ESS_RS9RawConfigEtPKtj
	.align	4
	.type	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE, @function
_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE:
.LFB2215:
	entry	sp, 32
.LCFI15:
	movi.n	a12, 0x30
	movi.n	a11, 0
	addi	a10, a2, 16
	call8	memset
	l32i	a8, a3, 88
	l32i	a10, a3, 80
	s32i	a8, a2, 8
	l32i	a8, a3, 4
	l32i	a9, a3, 84
	s32i	a8, a2, 12
	l8ui	a8, a3, 128
	s32i	a10, a2, 0
	s32i	a9, a2, 4
	s8i	a8, a2, 16
	s8i	a4, a2, 17
	retw.n
.LFE2215:
	.size	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE, .-_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	.literal_position
	.literal .LC46, 101004
	.literal .LC48, 101000
	.literal .LC49, 9040
	.align	4
	.type	_ZN12_GLOBAL__N_110freeRecordERNS_3AppE, @function
_ZN12_GLOBAL__N_110freeRecordERNS_3AppE:
.LFB2267:
	entry	sp, 32
.LCFI16:
	l32r	a9, .LC46
	l32r	a11, .LC49
	add.n	a9, a2, a9
	movi.n	a8, 0
	movi.n	a10, 8
	loop	a10, .L134_LEND
.L134:
	l32i	a12, a9, 0
	bnez.n	a12, .L132
	l32r	a9, .LC49
	mul16u	a8, a8, a9
	l32r	a9, .LC48
	add.n	a8, a8, a9
	add.n	a2, a2, a8
	j	.L131
.L132:
	addi.n	a8, a8, 1
	add.n	a9, a9, a11
	.L134_LEND:
	movi.n	a2, 0
.L131:
	retw.n
.LFE2267:
	.size	_ZN12_GLOBAL__N_110freeRecordERNS_3AppE, .-_ZN12_GLOBAL__N_110freeRecordERNS_3AppE
	.align	4
	.type	_ZN12_GLOBAL__N_113classifyStartERKN14MotorControlRS6ESS_RS11MoveContextE, @function
_ZN12_GLOBAL__N_113classifyStartERKN14MotorControlRS6ESS_RS11MoveContextE:
.LFB2275:
	entry	sp, 32
.LCFI17:
	l32i	a9, a2, 896
	mov.n	a8, a2
	bnez.n	a9, .L138
	addmi	a9, a2, 0x300
	l8ui	a9, a9, 135
	movi.n	a2, 0
	beqz.n	a9, .L139
.L138:
	addmi	a8, a8, 0x100
	l8ui	a2, a8, 239
	beqi	a2, 1, .L139
	bnei	a2, 2, .L141
	movi.n	a2, 3
	j	.L139
.L141:
	movi.n	a2, 2
.L139:
	retw.n
.LFE2275:
	.size	_ZN12_GLOBAL__N_113classifyStartERKN14MotorControlRS6ESS_RS11MoveContextE, .-_ZN12_GLOBAL__N_113classifyStartERKN14MotorControlRS6ESS_RS11MoveContextE
	.align	4
	.type	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE, @function
_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE:
.LFB2329:
	entry	sp, 64
.LCFI18:
	addi.n	a10, sp, 12
	movi.n	a12, 0xc
	movi.n	a11, 0
	call8	memset
	l8ui	a8, a2, 4
	l32i	a3, a2, 0
	mov.n	a9, a10
	beqi	a8, 1, .L150
	movi.n	a10, 1
	beqi	a8, 2, .L149
	beqi	a8, 3, .L149
	j	.L148
.L150:
	movi.n	a10, 2
.L148:
	movi.n	a8, 1
.L149:
	movi.n	a11, 1
	s8i	a11, sp, 12
	movi.n	a11, 8
	s8i	a11, sp, 20
	s8i	a8, sp, 21
	s8i	a10, sp, 22
	l32i	a2, sp, 12
	l32i	a4, a9, 8
	movi.n	a5, 0
	retw.n
.LFE2329:
	.size	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE, .-_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	.align	4
	.type	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE, @function
_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE:
.LFB2330:
	entry	sp, 48
.LCFI19:
	mov.n	a9, a2
	l8ui	a8, a9, 9
	l32i	a2, a2, 4
	beqi	a8, 2, .L156
	beqi	a8, 3, .L156
	l8ui	a8, a9, 10
	addi	a8, a8, -2
	nsau	a8, a8
	srli	a8, a8, 5
.L156:
	s8i	a8, sp, 4
	l32i	a3, sp, 4
	retw.n
.LFE2330:
	.size	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE, .-_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE
	.literal_position
	.literal .LC52, 47848
	.literal .LC54, 45672
	.literal .LC55, 47834
	.align	4
	.type	_ZN12_GLOBAL__N_117communicationViewERKNS_3AppERN21MotorControlRSExample5Probe17CommunicationViewE, @function
_ZN12_GLOBAL__N_117communicationViewERKNS_3AppERN21MotorControlRSExample5Probe17CommunicationViewE:
.LFB2331:
	entry	sp, 32
.LCFI20:
	movi	a8, 0x2cd
	slli	a8, a8, 6
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	movi.n	a8, 0
	beqz.n	a9, .L164
	movi	a8, 0x597
	slli	a8, a8, 5
	add.n	a8, a2, a8
.L164:
	s32i	a8, a3, 0
	l32r	a8, .LC52
	movi.n	a10, 0
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	movi.n	a8, 1
	moveqz	a8, a10, a9
	s8i	a8, a3, 4
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a2, a8
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	l32r	a11, .LC54
	or	a9, a9, a8
	movi.n	a8, 1
	moveqz	a8, a10, a9
	s8i	a8, a3, 5
	add.n	a11, a2, a11
	movi	a12, 0x78
	addi.n	a10, a3, 8
	call8	memcpy
	l32r	a8, .LC55
	add.n	a2, a2, a8
	l8ui	a8, a2, 0
	s8i	a8, a3, 6
	retw.n
.LFE2331:
	.size	_ZN12_GLOBAL__N_117communicationViewERKNS_3AppERN21MotorControlRSExample5Probe17CommunicationViewE, .-_ZN12_GLOBAL__N_117communicationViewERKNS_3AppERN21MotorControlRSExample5Probe17CommunicationViewE
	.literal_position
	.literal .LC56, 47900
	.literal .LC57, 47888
	.literal .LC58, 64909
	.literal .LC61, 64907
	.literal .LC63, 45672
	.literal .LC64, 60244
	.literal .LC65, 64912
	.literal .LC66, 64913
	.literal .LC67, 64905
	.literal .LC68, 64910
	.literal .LC69, 64906
	.align	4
	.type	_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE, @function
_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE:
.LFB2341:
	entry	sp, 32
.LCFI21:
	l32r	a8, .LC56
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	movi.n	a8, 0
	beqz.n	a9, .L168
	l32r	a8, .LC57
	add.n	a8, a2, a8
.L168:
	s32i	a8, a3, 0
	l32r	a8, .LC58
	add.n	a8, a2, a8
	l8ui	a9, a8, 0
	movi.n	a8, 0
	beqz.n	a9, .L169
	movi	a8, 0x75b
	slli	a8, a8, 5
	add.n	a8, a2, a8
.L169:
	s32i	a8, a3, 4
	movi	a8, 0x3f5
	slli	a8, a8, 6
	add.n	a8, a2, a8
	s8i	a9, a3, 11
	l32i	a9, a8, 0
	movi.n	a8, 1
	bnez.n	a9, .L170
	l32r	a8, .LC61
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
.L170:
	s8i	a8, a3, 8
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a2, a8
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	l32r	a11, .LC63
	or	a8, a9, a8
	movi.n	a9, 1
	moveqz	a9, a8, a8
	add.n	a11, a2, a11
	s8i	a9, a3, 9
	movi	a12, 0x78
	addi	a10, a3, 20
	call8	memcpy
	l32r	a8, .LC64
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	s8i	a8, a3, 10
	l32r	a8, .LC65
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	s8i	a8, a3, 12
	l32r	a8, .LC66
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	s8i	a8, a3, 13
	l32r	a8, .LC67
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	s8i	a8, a3, 14
	l32r	a8, .LC68
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	s8i	a8, a3, 15
	l32r	a8, .LC69
	add.n	a2, a2, a8
	l8ui	a8, a2, 0
	s8i	a8, a3, 16
	retw.n
.LFE2341:
	.size	_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE, .-_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE
	.literal_position
	.literal .LC70, 53801
	.literal .LC71, 53800
	.align	4
	.type	_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE, @function
_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE:
.LFB2353:
	entry	sp, 32
.LCFI22:
	l32r	a8, .LC70
	add.n	a8, a2, a8
	l8ui	a9, a8, 0
	bnez.n	a9, .L177
	s8i	a3, a8, 0
.L177:
	l32r	a8, .LC71
	add.n	a2, a2, a8
	movi.n	a8, 3
	s8i	a8, a2, 0
	retw.n
.LFE2353:
	.size	_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE, .-_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE
	.literal_position
	.literal .LC72, .L181
	.align	4
	.type	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE, @function
_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE:
.LFB2064:
	entry	sp, 32
.LCFI23:
	l8ui	a8, a3, 0
	mov.n	a10, a2
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 8
	movi.n	a2, 0
	bgeui	a8, 7, .L179
	l32r	a9, .LC72
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L181:
	.word	.L187
	.word	.L186
	.word	.L185
	.word	.L184
	.word	.L183
	.word	.L182
	.word	.L180
	.text
.L187:
	movi	a8, 0x7f7
	slli	a8, a8, 5
	addi	a11, a3, 32
	add.n	a10, a10, a8
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	movi.n	a2, 1
	moveqz	a2, a10, a10
	j	.L179
.L186:
	l8ui	a8, a3, 101
	j	.L189
.L185:
	addmi	a3, a3, 0x500
	l8ui	a8, a3, 100
	j	.L189
.L184:
	addmi	a3, a3, 0x800
	l8ui	a8, a3, 220
	j	.L189
.L183:
	addmi	a3, a3, 0xd00
	l8ui	a8, a3, 20
	j	.L189
.L182:
	addmi	a3, a3, 0x1000
	l8ui	a8, a3, 209
	j	.L189
.L180:
	addmi	a3, a3, 0x2000
	l8ui	a8, a3, 12
.L189:
	addi.n	a8, a8, -1
	movi.n	a2, 1
	moveqz	a2, a8, a8
.L179:
	retw.n
.LFE2064:
	.size	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE, .-_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	.literal_position
	.literal .LC74, 771250
	.literal .LC75, 771808
	.literal .LC76, 771248
	.literal .LC77, 772616
	.literal .LC78, 813496
	.literal .LC79, 774016
	.literal .LC80, 772596
	.literal .LC83, 770856
	.literal .LC84, 770860
	.literal .LC85, 770862
	.literal .LC86, 772460
	.literal .LC87, 772492
	.literal .LC88, 101000
	.literal .LC89, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb, @function
_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb:
.LFB2065:
	entry	sp, 32
.LCFI24:
	l32r	a8, .LC74
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L191
	l32r	a8, .LC75
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L191
	bnez.n	a3, .L192
.L194:
	movi.n	a2, 1
	j	.L193
.L192:
	l32r	a8, .LC76
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beq	a8, a3, .L194
.L191:
	l32r	a8, .LC77
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L195
.L197:
	l32r	a8, .LC78
	movi	a11, 0x88
	add.n	a8, a2, a8
	l8ui	a10, a8, 0
	l32r	a8, .LC79
	movi.n	a12, 0x48
	add.n	a8, a2, a8
	movi.n	a9, 0
	addmi	a11, a11, 0x900
	addmi	a12, a12, 0xa00
	j	.L196
.L195:
	beqz.n	a3, .L194
	l32r	a8, .LC80
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bne	a8, a3, .L197
	j	.L194
.L199:
	add.n	a13, a8, a11
	l8ui	a13, a13, 0
	beqz.n	a13, .L198
	beqz.n	a3, .L194
	l8ui	a13, a8, 0
	beq	a13, a3, .L194
.L198:
	addi.n	a9, a9, 1
	extui	a9, a9, 0, 8
	add.n	a8, a8, a12
.L196:
	bne	a10, a9, .L199
	l32r	a8, .LC83
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L200
	l32r	a8, .LC84
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L201
.L200:
	beqz.n	a3, .L194
	l32r	a8, .LC85
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beq	a8, a3, .L194
.L201:
	beqz.n	a3, .L202
	beqz.n	a4, .L203
	l32r	a9, .LC86
	srli	a8, a3, 3
	add.n	a8, a2, a8
	add.n	a8, a8, a9
	l8ui	a9, a8, 0
	extui	a8, a3, 0, 3
	bbc	a9, a8, .L203
	j	.L194
.L202:
	beqz.n	a4, .L203
	l32r	a8, .LC86
	l32r	a9, .LC87
	add.n	a8, a2, a8
	add.n	a9, a2, a9
	j	.L204
.L205:
	l8ui	a10, a8, 0
	bnez.n	a10, .L194
	addi.n	a8, a8, 1
.L204:
	bne	a8, a9, .L205
.L203:
	l32r	a7, .LC88
	l32r	a6, .LC89
	movi.n	a5, 0x50
	add.n	a7, a2, a7
	add.n	a6, a2, a6
	addmi	a5, a5, 0x2300
	j	.L206
.L212:
	movi	a8, 0x308
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L207
.L210:
	add.n	a7, a7, a5
	j	.L206
.L207:
	beqz.n	a4, .L208
.L211:
	bnez.n	a3, .L240
	j	.L194
.L208:
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L210
	j	.L211
.L240:
	l8ui	a8, a7, 24
	bne	a8, a3, .L210
	j	.L194
.L206:
	bne	a7, a6, .L212
	movi.n	a2, 0
.L193:
	retw.n
.LFE2065:
	.size	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb, .-_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	.literal_position
	.literal .LC92, 101000
	.literal .LC93, 9040
	.literal .LC95, -65281
	.literal .LC96, 16842754
	.align	4
	.type	_ZN12_GLOBAL__N_119availableStopRecordERNS_3AppEjj, @function
_ZN12_GLOBAL__N_119availableStopRecordERNS_3AppEjj:
.LFB2125:
	entry	sp, 48
.LCFI25:
	l32r	a7, .LC93
	l32r	a8, .LC92
	mul16u	a7, a3, a7
	l32r	a12, .LC93
	add.n	a7, a7, a8
	mov.n	a6, a2
	add.n	a7, a2, a7
	add.n	a4, a3, a4
	movi.n	a5, 0
	movi.n	a2, 0
	movi.n	a9, 0
.L247:
	l32i	a8, a7, 4
	bnez.n	a8, .L242
	moveqz	a9, a7, a9
	j	.L243
.L242:
	mov.n	a11, a7
	mov.n	a10, a6
	s32i	a9, sp, 0
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	l32i	a9, sp, 0
	l32r	a12, .LC93
	beqz.n	a10, .L243
	l8ui	a8, a7, 65
	beqz.n	a8, .L243
	mull	a8, a3, a12
	movi	a10, 0x31f
	slli	a10, a10, 7
	add.n	a8, a6, a8
	add.n	a8, a8, a10
	l32i	a8, a8, 108
	l32r	a10, .LC95
	and	a8, a8, a10
	l32r	a10, .LC96
	bne	a8, a10, .L246
	beqz.n	a5, .L251
	l32i	a10, a7, 4
	l32i	a8, a5, 4
	bltu	a10, a8, .L251
	j	.L243
.L246:
	beqz.n	a2, .L252
	l32i	a10, a7, 4
	l32i	a8, a2, 4
	bgeu	a10, a8, .L243
	j	.L252
.L251:
	mov.n	a5, a7
	j	.L243
.L252:
	mov.n	a2, a7
.L243:
	addi.n	a3, a3, 1
	add.n	a7, a7, a12
	bltu	a3, a4, .L247
	movnez	a2, a9, a9
	beqz.n	a5, .L241
.L253:
	mov.n	a2, a5
.L241:
	retw.n
.LFE2125:
	.size	_ZN12_GLOBAL__N_119availableStopRecordERNS_3AppEjj, .-_ZN12_GLOBAL__N_119availableStopRecordERNS_3AppEjj
	.literal_position
	.literal .LC98, 101000
	.literal .LC99, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_111pendingStopERKNS_3AppEh, @function
_ZN12_GLOBAL__N_111pendingStopERKNS_3AppEh:
.LFB2146:
	entry	sp, 32
.LCFI26:
	l32r	a7, .LC98
	l32r	a6, .LC99
	movi.n	a5, 0x50
	add.n	a7, a2, a7
	add.n	a6, a2, a6
	addmi	a5, a5, 0x2300
	j	.L261
.L265:
	l8ui	a8, a7, 0
	beqi	a8, 3, .L262
.L263:
	add.n	a7, a7, a5
	j	.L261
.L262:
	l8ui	a8, a7, 24
	bne	a8, a3, .L263
	movi	a8, 0x540
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnei	a8, 3, .L263
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L263
	movi.n	a2, 1
	j	.L264
.L261:
	bne	a7, a6, .L265
	movi.n	a2, 0
.L264:
	retw.n
.LFE2146:
	.size	_ZN12_GLOBAL__N_111pendingStopERKNS_3AppEh, .-_ZN12_GLOBAL__N_111pendingStopERKNS_3AppEh
	.section	.rodata.str1.1
.LC105:
	.string	"record has no action sequence"
	.text
	.literal_position
	.literal .LC101, .L269
	.literal .LC106, .LC105
	.align	4
	.type	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy, @function
_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy:
.LFB2220:
	entry	sp, 48
.LCFI27:
	l8ui	a8, a2, 0
	mov.n	a11, a3
	addi	a8, a8, -3
	extui	a8, a8, 0, 8
	mov.n	a12, a4
	mov.n	a13, a5
	bgeui	a8, 5, .L267
	l32r	a9, .LC101
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L269:
	.word	.L273
	.word	.L272
	.word	.L271
	.word	.L270
	.word	.L268
	.text
.L268:
	movi	a10, 0x60
	addmi	a10, a10, 0x1f00
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS11advanceHomeERNS0_11HomeContextERKNS_11ActionEventEy
	j	.L275
.L270:
	movi	a10, 0xb8
	addmi	a10, a10, 0x1000
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS13advanceDriverERNS0_13DriverContextERKNS_11ActionEventEy
.L275:
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	j	.L274
.L271:
	movi.n	a10, 8
	addmi	a10, a10, 0xc00
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS15advanceVelocityERNS0_15VelocityContextERKNS_11ActionEventEy
	j	.L275
.L272:
	movi	a10, 0x6f0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS11advanceMoveERNS0_11MoveContextERKNS_11ActionEventEy
	j	.L275
.L273:
	movi	a10, 0x530
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS13advanceActionERNS0_13ActionContextERKNS_11ActionEventEy
	j	.L275
.L267:
	movi.n	a8, 1
	s8i	a8, sp, 0
	movi.n	a8, 0
	s32i	a8, sp, 4
	l32r	a8, .LC106
	s32i	a8, sp, 8
.L274:
	l32i	a2, sp, 0
	l32i	a3, sp, 4
	l32i	a4, sp, 8
	movi.n	a5, 0
	retw.n
.LFE2220:
	.size	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy, .-_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	.align	4
	.type	_ZN12_GLOBAL__N_111endHeldStopERNS_3App6RecordEN14MotorControlRS13ReadEventKindEly, @function
_ZN12_GLOBAL__N_111endHeldStopERNS_3App6RecordEN14MotorControlRS13ReadEventKindEly:
.LFB2224:
	entry	sp, 112
.LCFI28:
	addmi	a8, a2, 0x300
	movi.n	a9, 0
	mov.n	a12, a3
	mov.n	a11, a2
	mov.n	a10, sp
	s8i	a9, a8, 13
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	mov.n	a10, a2
	s32i	a4, sp, 48
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	retw.n
.LFE2224:
	.size	_ZN12_GLOBAL__N_111endHeldStopERNS_3App6RecordEN14MotorControlRS13ReadEventKindEly, .-_ZN12_GLOBAL__N_111endHeldStopERNS_3App6RecordEN14MotorControlRS13ReadEventKindEly
	.literal_position
	.literal .LC107, 772456
	.literal .LC108, 45700
	.align	4
	.type	_ZN12_GLOBAL__N_118memberWitnessValidERKNS_3AppERKNS0_11GroupMemberEPKt, @function
_ZN12_GLOBAL__N_118memberWitnessValidERKNS_3AppERKNS0_11GroupMemberEPKt:
.LFB2281:
	entry	sp, 32
.LCFI29:
	addmi	a9, a3, 0xa00
	mov.n	a8, a2
	l8ui	a2, a9, 48
	mov.n	a11, a4
	beqz.n	a2, .L278
	l32i	a12, a9, 60
	l32i	a10, a3, 20
	movi.n	a2, 0
	bne	a12, a10, .L278
	l32r	a12, .LC107
	add.n	a12, a8, a12
	l32i	a10, a12, 0
	l32i	a12, a9, 64
	bne	a12, a10, .L278
	l32i	a10, a3, 16
	bne	a12, a10, .L278
	l32r	a10, .LC108
	l32i	a9, a9, 68
	add.n	a8, a8, a10
	l32i	a8, a8, 0
	bne	a9, a8, .L278
	movi.n	a10, 0x32
	addmi	a10, a10, 0xa00
	movi.n	a12, 0xa
	add.n	a10, a3, a10
	call8	memcmp
	nsau	a2, a10
	srli	a2, a2, 5
.L278:
	retw.n
.LFE2281:
	.size	_ZN12_GLOBAL__N_118memberWitnessValidERKNS_3AppERKNS0_11GroupMemberEPKt, .-_ZN12_GLOBAL__N_118memberWitnessValidERKNS_3AppERKNS0_11GroupMemberEPKt
	.literal_position
	.literal .LC110, 764508
	.literal .LC111, 764714
	.literal .LC112, 764771
	.literal .LC113, 764772
	.align	4
	.type	_ZN12_GLOBAL__N_128invalidateMotionObservationsERNS_3AppEh, @function
_ZN12_GLOBAL__N_128invalidateMotionObservationsERNS_3AppEh:
.LFB2070:
	entry	sp, 32
.LCFI30:
	l32r	a8, .LC110
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bne	a8, a3, .L287
	l32r	a8, .LC111
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC112
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC113
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 0
.L287:
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	movi.n	a14, 0
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb
	retw.n
.LFE2070:
	.size	_ZN12_GLOBAL__N_128invalidateMotionObservationsERNS_3AppEh, .-_ZN12_GLOBAL__N_128invalidateMotionObservationsERNS_3AppEh
	.literal_position
	.literal .LC114, 772456
	.literal .LC115, 772584
	.literal .LC116, 772576
	.literal .LC117, 772492
	.literal .LC118, 772556
	.literal .LC119, 772560
	.literal .LC120, 772564
	.literal .LC121, 772568
	.align	4
	.type	_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE, @function
_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE:
.LFB2214:
	entry	sp, 32
.LCFI31:
	l8ui	a8, a3, 105
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L288
	l8ui	a8, a3, 160
	beqz.n	a8, .L288
	l16ui	a9, a3, 136
	l32i	a8, a3, 88
	bne	a9, a8, .L288
	l32i	a8, a3, 148
	l32i	a10, a3, 124
	l32i	a9, a3, 144
	bltu	a8, a10, .L288
	bne	a10, a8, .L297
	l32i	a10, a3, 120
	bltu	a9, a10, .L288
.L297:
	l32i	a7, a3, 156
	l32i	a6, a3, 152
	bltu	a7, a8, .L288
	bne	a8, a7, .L298
	bltu	a6, a9, .L288
.L298:
	call8	_Z18esp_timer_get_timev
	bltu	a11, a7, .L288
	bne	a7, a11, .L299
	bltu	a10, a6, .L288
.L299:
	l32r	a8, .LC114
	l32i	a9, a3, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L288
	l32r	a8, .LC115
	l32r	a11, .LC116
	add.n	a9, a2, a8
	l8ui	a9, a9, 0
	beqz.n	a9, .L295
	add.n	a9, a2, a11
	l32i	a12, a9, 4
	l32i	a10, a3, 156
	bltu	a10, a12, .L288
	bne	a12, a10, .L295
	l32i	a9, a9, 0
	l32i	a10, a3, 152
	bltu	a10, a9, .L288
.L295:
	add.n	a8, a2, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
	l8ui	a9, a3, 30
	l32r	a10, .LC117
	srli	a8, a9, 3
	add.n	a8, a2, a8
	add.n	a8, a8, a10
	extui	a10, a9, 0, 3
	movi.n	a9, 1
	ssl	a10
	sll	a9, a9
	l8ui	a10, a8, 0
	or	a9, a9, a10
	s8i	a9, a8, 0
	l32r	a8, .LC118
	l32i	a9, a3, 16
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC119
	l8ui	a9, a3, 30
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC120
	l32i	a9, a3, 20
	add.n	a8, a2, a8
	l32r	a10, .LC121
	s32i	a9, a8, 0
	l32i	a8, a3, 120
	l32i	a9, a3, 124
	add.n	a10, a2, a10
	s32i	a8, a10, 0
	s32i	a9, a10, 4
	l32i	a8, a3, 152
	l32i	a9, a3, 156
	add.n	a2, a2, a11
	s32i	a8, a2, 0
	s32i	a9, a2, 4
.L288:
	retw.n
.LFE2214:
	.size	_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE, .-_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE
	.align	4
	.type	_ZN12_GLOBAL__N_18holdStopERNS_3AppERNS0_6RecordEy, @function
_ZN12_GLOBAL__N_18holdStopERNS_3AppERNS0_6RecordEy:
.LFB2223:
	entry	sp, 48
.LCFI32:
	l8ui	a8, a3, 0
	mov.n	a12, a4
	mov.n	a13, a5
	bnei	a8, 3, .L307
	addmi	a8, a3, 0x500
	l8ui	a8, a8, 64
	bnei	a8, 3, .L306
	movi	a8, 0x530
	j	.L326
.L307:
	bnei	a8, 5, .L306
	addmi	a8, a3, 0xd00
	l8ui	a8, a8, 25
	bnei	a8, 3, .L306
	movi.n	a8, 0x18
	addmi	a8, a8, 0xf00
.L326:
	add.n	a8, a3, a8
	l8ui	a9, a8, 52
	s32i	a13, sp, 4
	s32i	a12, sp, 0
	bnei	a9, 1, .L306
	l8ui	a9, a8, 88
	bnez.n	a9, .L306
	l8ui	a9, a8, 54
	bnez.n	a9, .L306
	l32i	a9, a8, 144
	bnez.n	a9, .L306
	l8ui	a8, a8, 151
	bnez.n	a8, .L306
	addmi	a5, a3, 0x300
	l8ui	a8, a5, 13
	bnez.n	a8, .L306
	l32i	a8, a3, 784
	l32i	a9, a3, 788
	or	a8, a8, a9
	bnez.n	a8, .L306
	l8ui	a8, a5, 12
	bnez.n	a8, .L306
	l8ui	a8, a3, 71
	bnez.n	a8, .L306
	l32i	a8, a3, 32
	beqz.n	a8, .L312
	movi	a6, 0x7f7
	slli	a6, a6, 5
	add.n	a6, a2, a6
	addi	a4, a3, 32
	mov.n	a11, a4
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	l32i	a12, sp, 0
	l32i	a13, sp, 4
	mov.n	a7, a10
	bnez.n	a10, .L313
	mov.n	a11, a4
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
	beqz.n	a10, .L306
	mov.n	a11, a4
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a7, a10
	beqz.n	a10, .L306
.L313:
	l16ui	a8, a7, 136
	bnez.n	a8, .L306
	l8ui	a8, a7, 142
	bnez.n	a8, .L306
	l8ui	a8, a7, 204
	s32i	a8, sp, 0
	bnez.n	a8, .L306
	movi	a12, 0x1cf
	mov.n	a11, a7
	addi	a10, a5, 96
	call8	memcpy
	movi.n	a9, 1
	mov.n	a11, a7
	mov.n	a10, a2
	s8i	a9, a5, 88
	call8	_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE
	mov.n	a11, a4
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	beqz.n	a10, .L306
	l32i	a8, sp, 0
	s32i	a8, a3, 32
	s32i	a8, a3, 36
	movi.n	a8, 0
	s32i	a8, a3, 40
	s32i	a8, a3, 44
.L312:
	movi.n	a8, 1
	s8i	a8, a5, 13
.L306:
	retw.n
.LFE2223:
	.size	_ZN12_GLOBAL__N_18holdStopERNS_3AppERNS0_6RecordEy, .-_ZN12_GLOBAL__N_18holdStopERNS_3AppERNS0_6RecordEy
	.literal_position
	.literal .LC125, 764769
	.literal .LC126, 764770
	.literal .LC127, 764772
	.literal .LC128, 764696
	.literal .LC129, 764504
	.literal .LC130, 764516
	.literal .LC131, 764512
	.literal .LC132, 772456
	.literal .LC133, 101000
	.literal .LC134, 625320
	.literal .LC136, 764508
	.align	4
	.type	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy, @function
_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy:
.LFB2068:
	entry	sp, 64
.LCFI33:
	l32r	a9, .LC125
	movi.n	a10, 0
	add.n	a9, a2, a9
	s8i	a10, a9, 0
	l32r	a9, .LC126
	movi.n	a10, 0
	add.n	a9, a2, a9
	s16i	a10, a9, 0
	l32r	a9, .LC127
	add.n	a9, a2, a9
	s8i	a10, a9, 0
	or	a9, a4, a5
	bnez.n	a9, .L328
	call8	_Z18esp_timer_get_timev
	mov.n	a4, a10
	mov.n	a5, a11
.L328:
	l32r	a11, .LC128
	l32r	a10, .LC129
	add.n	a11, a2, a11
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS23invalidateAxisReferenceERNS_10AxisConfigERNS_13AxisReferenceE
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L329
	l32r	a9, .LC130
	movi.n	a10, 0
	add.n	a9, a2, a9
	s32i	a10, a9, 0
.L329:
	l32r	a10, .LC132
	l32r	a9, .LC131
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	add.n	a9, a2, a9
	s32i	a10, a9, 0
	movi	a10, 0x7f7
	l32r	a9, .LC133
	l32r	a7, .LC134
	slli	a10, a10, 5
	add.n	a8, a2, a10
	add.n	a6, a2, a9
	add.n	a7, a2, a7
	s32i	a8, sp, 16
	j	.L330
.L338:
	beq	a6, a3, .L332
	movi	a10, 0x30d
	add.n	a10, a6, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L332
	movi.n	a8, 0x39
	addmi	a8, a8, 0x2300
	add.n	a10, a6, a8
	l8ui	a10, a10, 0
	beqz.n	a10, .L334
	l32r	a10, .LC136
	l8ui	a11, a6, 24
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bne	a11, a10, .L332
.L334:
	l8ui	a11, a6, 0
	movi.n	a12, 1
	addi	a10, a11, -4
	extui	a10, a10, 0, 8
	saltu	a10, a12, a10
	addi.n	a10, a10, -1
	neg	a10, a10
	extui	a10, a10, 0, 8
	bnez.n	a10, .L335
	addi	a13, a11, -7
	movnez	a12, a10, a13
	bnez.n	a12, .L335
	bnei	a11, 6, .L336
	movi	a8, 0xd0
	addmi	a8, a8, 0x1000
	add.n	a10, a6, a8
	l8ui	a10, a10, 0
	bnei	a10, 1, .L332
	j	.L335
.L336:
	bnei	a11, 2, .L332
	l8ui	a10, a6, 100
	bnei	a10, 2, .L332
.L335:
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L332
	movi.n	a10, 1
	s8i	a10, a6, 71
	l8ui	a10, a6, 0
	bnei	a10, 7, .L337
	movi	a10, 0x60
	addmi	a10, a10, 0x1f00
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS10revokeHomeERNS0_11HomeContextE
.L337:
	l32i	a10, a6, 32
	beqz.n	a10, .L332
	l32i	a10, sp, 16
	mov.n	a12, a4
	mov.n	a13, a5
	addi	a11, a6, 32
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L332:
	movi.n	a10, 0x50
	addmi	a10, a10, 0x2300
	add.n	a6, a6, a10
.L330:
	bne	a6, a7, .L338
	retw.n
.LFE2068:
	.size	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy, .-_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	.align	4
	.type	_ZN12_GLOBAL__N_110checkProbeERKN21MotorControlRSExample3Rtu11ExpectationEPKhj, @function
_ZN12_GLOBAL__N_110checkProbeERKN21MotorControlRSExample3Rtu11ExpectationEPKhj:
.LFB2079:
	entry	sp, 48
.LCFI34:
	l8ui	a12, a2, 14
	movi.n	a8, 0
	mov.n	a10, a3
	mov.n	a11, a4
	movi.n	a14, 0
	addi.n	a13, sp, 12
	s16i	a8, sp, 12
	call8	_ZN14MotorControlRS6ESS_RS10parseProbeEPKhjhRtPNS0_10FrameErrorE
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2079:
	.size	_ZN12_GLOBAL__N_110checkProbeERKN21MotorControlRSExample3Rtu11ExpectationEPKhj, .-_ZN12_GLOBAL__N_110checkProbeERKN21MotorControlRSExample3Rtu11ExpectationEPKhj
	.literal_position
	.literal .LC141, 45756
	.literal .LC142, 45752
	.align	4
	.type	_ZN12_GLOBAL__N_115admitActionStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedActionEy, @function
_ZN12_GLOBAL__N_115admitActionStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedActionEy:
.LFB2097:
	entry	sp, 144
.LCFI35:
	movi	a12, 0x60
	movi.n	a11, 0
	addi.n	a10, sp, 8
	call8	memset
	addi	a8, a4, 21
	s32i	a8, sp, 0
	l32i	a8, a4, 32
	s32i	a8, sp, 4
	l8ui	a8, a4, 36
	movi.n	a10, 8
	bnez.n	a8, .L354
	l16ui	a10, a4, 42
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L354:
	l32r	a8, .LC141
	l32i	a9, a4, 52
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 12
	l32r	a8, .LC142
	l8ui	a9, a4, 36
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 8
	s32i	a8, sp, 16
	l32i	a8, a4, 48
	movi.n	a10, 6
	s32i	a8, sp, 24
	l8ui	a8, a4, 8
	s8i	a8, sp, 54
	movi.n	a8, 3
	movnez	a8, a10, a9
	s8i	a8, sp, 55
	l32i	a8, a4, 4
	s32i	a8, sp, 40
	l32i	a8, a4, 12
	s32i	a8, sp, 44
	l16ui	a8, a4, 38
	s16i	a8, sp, 48
	movi.n	a8, 1
	bnez.n	a9, .L356
	l16ui	a8, a4, 42
.L356:
	s16i	a8, sp, 50
	l16ui	a8, a4, 40
	s16i	a8, sp, 52
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	addmi	a8, a3, 0x500
	s32i	a10, sp, 56
	l8ui	a8, a8, 64
	movi	a10, 0x7f7
	s32i	a11, sp, 60
	slli	a10, a10, 5
	addi	a14, a3, 32
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	add.n	a10, a2, a10
	bnei	a8, 3, .L357
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner11admitUrgentERKNS0_10BusRequestEyRNS0_9RequestIdE
	j	.L362
.L357:
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
.L362:
	mov.n	a2, a10
	retw.n
.LFE2097:
	.size	_ZN12_GLOBAL__N_115admitActionStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedActionEy, .-_ZN12_GLOBAL__N_115admitActionStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedActionEy
	.literal_position
	.literal .LC144, 101032
	.literal .LC145, 625352
	.literal .LC148, 65248
	.align	4
	.type	_ZN12_GLOBAL__N_115triggeredMotionERKNS_3AppEh, @function
_ZN12_GLOBAL__N_115triggeredMotionERKNS_3AppEh:
.LFB2071:
	entry	sp, 32
.LCFI36:
	l32r	a7, .LC144
	l32r	a6, .LC145
	movi	a5, 0xb8
	add.n	a7, a2, a7
	add.n	a6, a2, a6
	addmi	a5, a5, 0xd00
	j	.L364
.L375:
	addi	a8, a7, -8
	l8ui	a8, a8, 0
	bne	a8, a3, .L366
	addi	a4, a7, -32
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L367
	movi	a8, 0x2eb
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L366
.L367:
	l8ui	a8, a4, 0
	beqi	a8, 5, .L369
	beqi	a8, 7, .L370
	beqi	a8, 4, .L371
	j	.L366
.L369:
	add.n	a8, a7, a5
	l32i	a8, a8, 0
	beqz.n	a8, .L372
.L374:
	movi.n	a2, 1
	j	.L373
.L372:
	movi.n	a8, -7
	addmi	a8, a8, 0xd00
	j	.L398
.L370:
	movi	a8, 0xc0
	addmi	a8, a8, 0x2000
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L374
	movi.n	a8, -0xf
	addmi	a8, a8, 0x2000
.L398:
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnei	a8, 1, .L366
	j	.L395
.L371:
	movi.n	a8, 0x50
	addmi	a8, a8, 0xa00
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L374
	movi.n	a9, 0x58
	movi.n	a8, 0x5a
	addmi	a9, a9, 0x900
	addmi	a8, a8, 0x900
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	l8ui	a9, a9, 0
	l8ui	a8, a8, 0
	bne	a9, a8, .L366
.L395:
	l32i	a8, a7, 0
	beqz.n	a8, .L366
	l32r	a10, .LC148
	mov.n	a11, a7
	add.n	a10, a2, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	bnez.n	a10, .L374
.L366:
	movi.n	a8, 0x50
	addmi	a8, a8, 0x2300
	add.n	a7, a7, a8
.L364:
	bne	a7, a6, .L375
	movi.n	a2, 0
.L373:
	retw.n
.LFE2071:
	.size	_ZN12_GLOBAL__N_115triggeredMotionERKNS_3AppEh, .-_ZN12_GLOBAL__N_115triggeredMotionERKNS_3AppEh
	.literal_position
	.literal .LC155, 772492
	.literal .LC156, 757972
	.literal .LC157, 757804
	.literal .LC158, 762112
	.literal .LC159, 759752
	.literal .LC160, 759280
	.literal .LC161, 758808
	.literal .LC162, 760208
	.literal .LC163, 760680
	.literal .LC164, 761152
	.literal .LC165, 761624
	.literal .LC166, 625320
	.literal .LC167, 625608
	.literal .LC168, 625896
	.literal .LC170, 774220
	.literal .LC171, 774016
	.literal .LC172, 813496
	.literal .LC173, 764496
	.literal .LC174, 771877
	.literal .LC175, 772092
	.literal .LC176, 771986
	.align	4
	.type	_ZN12_GLOBAL__N_125invalidateTargetKnowledgeERNS_3AppEy, @function
_ZN12_GLOBAL__N_125invalidateTargetKnowledgeERNS_3AppEy:
.LFB2321:
	entry	sp, 32
.LCFI37:
	l32r	a10, .LC155
	movi.n	a12, 0x20
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a9, .LC156
	movi.n	a8, 0
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC157
	l32r	a6, .LC172
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC158
	movi.n	a7, 0
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC159
	add.n	a6, a2, a6
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC160
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC161
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC162
	add.n	a9, a2, a9
	s32i	a8, a9, 16
	l32r	a9, .LC163
	add.n	a9, a2, a9
	s32i	a8, a9, 16
	l32r	a9, .LC164
	add.n	a9, a2, a9
	s32i	a8, a9, 16
	l32r	a9, .LC165
	add.n	a9, a2, a9
	s32i	a8, a9, 16
	l32r	a8, .LC166
	add.n	a8, a2, a8
	s32i	a4, a8, 264
	s32i	a5, a8, 268
	l32r	a8, .LC167
	add.n	a8, a2, a8
	s32i	a4, a8, 264
	s32i	a5, a8, 268
	l32r	a8, .LC168
	add.n	a8, a2, a8
	s32i	a4, a8, 264
	s32i	a5, a8, 268
	j	.L401
.L402:
	movi.n	a8, 0x48
	addmi	a8, a8, 0xa00
	mull	a8, a7, a8
	l32r	a9, .LC170
	add.n	a8, a2, a8
	add.n	a9, a8, a9
	movi.n	a10, 0
	s32i	a10, a9, 0
	l32r	a9, .LC171
	mov.n	a12, a4
	add.n	a8, a8, a9
	l8ui	a11, a8, 0
	mov.n	a13, a5
	mov.n	a10, a2
	addi.n	a7, a7, 1
	call8	_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy
	extui	a7, a7, 0, 8
.L401:
	l8ui	a8, a6, 0
	bltu	a7, a8, .L402
	l32r	a9, .LC173
	movi.n	a8, 0
	add.n	a9, a2, a9
	s8i	a8, a9, 0
	l32r	a9, .LC174
	add.n	a9, a2, a9
	s8i	a8, a9, 0
	l32r	a9, .LC175
	add.n	a9, a2, a9
	s8i	a8, a9, 0
	l32r	a9, .LC176
	add.n	a2, a2, a9
	s8i	a8, a2, 0
	retw.n
.LFE2321:
	.size	_ZN12_GLOBAL__N_125invalidateTargetKnowledgeERNS_3AppEy, .-_ZN12_GLOBAL__N_125invalidateTargetKnowledgeERNS_3AppEy
	.literal_position
	.literal .LC177, 772584
	.literal .LC178, 757772
	.align	4
	.type	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy, @function
_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy:
.LFB2322:
	entry	sp, 32
.LCFI38:
	l32r	a8, .LC177
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC178
	movi.n	a9, 0
	add.n	a8, a2, a8
	mov.n	a10, a2
	mov.n	a12, a4
	mov.n	a13, a5
	s32i	a9, a8, 0
	call8	_ZN12_GLOBAL__N_125invalidateTargetKnowledgeERNS_3AppEy
	retw.n
.LFE2322:
	.size	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy, .-_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy
	.literal_position
	.literal .LC179, 64904
	.literal .LC180, 62744
	.literal .LC181, 45688
	.literal .LC182, 64888
	.literal .LC183, 64864
	.literal .LC184, 64880
	.literal .LC185, 762568
	.literal .LC186, 61496
	.literal .LC187, 63440
	.align	4
	.type	_ZN12_GLOBAL__N_122persistencePrepareReadERNS_3AppEy, @function
_ZN12_GLOBAL__N_122persistencePrepareReadERNS_3AppEy:
.LFB2344:
	entry	sp, 80
.LCFI39:
	l32r	a8, .LC179
	l32r	a10, .LC181
	add.n	a8, a2, a8
	l8ui	a3, a8, 0
	movi	a6, 0x2b8
	l32r	a8, .LC180
	mul16u	a6, a6, a3
	add.n	a10, a2, a10
	add.n	a6, a6, a8
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	s32i	a10, sp, 28
	s32i	a11, sp, 32
	s32i	a12, sp, 36
	mov.n	a7, a2
	add.n	a6, a2, a6
	bnez.n	a3, .L405
	addi	a8, sp, 28
	s32i	a8, sp, 8
	l32r	a8, .LC184
	l32r	a10, .LC182
	add.n	a8, a2, a8
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	add.n	a10, a2, a10
	l32r	a11, .LC183
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	l32i	a12, a10, 0
	add.n	a11, a2, a11
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS15prepareIdentityERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	extui	a10, a10, 0, 8
	movi.n	a2, 1
	movnez	a2, a3, a10
	j	.L406
.L405:
	bnei	a3, 1, .L407
	l32r	a8, .LC185
	l32r	a10, .LC182
	add.n	a8, a2, a8
	s32i	a8, sp, 12
	addi	a8, sp, 28
	s32i	a8, sp, 8
	l32r	a8, .LC184
	add.n	a10, a2, a10
	add.n	a8, a2, a8
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	l32r	a11, .LC183
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	l32i	a12, a10, 0
	mov.n	a14, a4
	mov.n	a15, a5
	add.n	a11, a2, a11
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS13prepareConfigERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleEPKNS_11InputWiringE
	j	.L409
.L407:
	l32r	a3, .LC186
	l32r	a10, .LC187
	add.n	a3, a2, a3
	add.n	a10, a2, a10
	mov.n	a11, a3
	call8	_ZN14MotorControlRS6ESS_RS9getConfigERKNS0_11ReadContextERNS0_17ConfigObservationE
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	movi.n	a2, 0
	bnez.n	a10, .L406
	addi	a8, sp, 28
	s32i	a8, sp, 8
	l32r	a8, .LC184
	s32i	a3, sp, 12
	add.n	a8, a7, a8
	l32i	a9, a8, 4
	l32r	a10, .LC182
	l32i	a8, a8, 0
	add.n	a10, a7, a10
	l32r	a11, .LC183
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	l32i	a12, a10, 0
	mov.n	a14, a4
	mov.n	a15, a5
	add.n	a11, a7, a11
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS12prepareStateERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleEPKNS0_17ConfigObservationE
.L409:
	extui	a2, a10, 0, 8
	nsau	a2, a2
	srli	a2, a2, 5
.L406:
	retw.n
.LFE2344:
	.size	_ZN12_GLOBAL__N_122persistencePrepareReadERNS_3AppEy, .-_ZN12_GLOBAL__N_122persistencePrepareReadERNS_3AppEy
	.literal_position
	.literal .LC188, 64904
	.literal .LC189, 62744
	.literal .LC190, 45756
	.literal .LC191, 45752
	.literal .LC192, 47864
	.literal .LC194, 64848
	.align	4
	.type	_ZN12_GLOBAL__N_119persistenceReadStepERNS_3AppEy, @function
_ZN12_GLOBAL__N_119persistenceReadStepERNS_3AppEy:
.LFB2343:
	entry	sp, 208
.LCFI40:
	l32r	a8, .LC188
	movi	a6, 0x2b8
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	addi	a3, sp, 120
	mul16u	a6, a6, a8
	l32r	a8, .LC189
	movi.n	a12, 0x30
	add.n	a6, a6, a8
	movi.n	a11, 0
	mov.n	a10, a3
	call8	memset
	add.n	a6, a2, a6
	mov.n	a14, a3
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS8nextReadERKNS0_11ReadContextEyRNS0_12PreparedReadE
	extui	a10, a10, 0, 8
	mov.n	a7, a2
	movi.n	a2, 4
	bnez.n	a10, .L412
	movi	a12, 0x60
	movi.n	a11, 0
	addi	a10, sp, 24
	call8	memset
	l32i	a8, sp, 152
	l16ui	a10, sp, 140
	addi	a3, a3, 22
	s32i	a8, sp, 20
	s32i	a3, sp, 16
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
	l32i	a8, sp, 160
	l32i	a9, sp, 164
	s32i	a8, sp, 40
	l32r	a8, .LC190
	s32i	a9, sp, 44
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 24
	s32i	a8, sp, 28
	l32r	a8, .LC191
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, sp, 32
	l8ui	a8, sp, 124
	s8i	a8, sp, 70
	l32i	a8, sp, 120
	s32i	a8, sp, 56
	l32i	a8, sp, 128
	s32i	a8, sp, 60
	movi.n	a8, 3
	s8i	a8, sp, 71
	l16ui	a8, sp, 138
	s16i	a8, sp, 64
	l16ui	a8, sp, 140
	s16i	a8, sp, 66
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32r	a8, .LC192
	s32i	a10, sp, 72
	add.n	a8, a7, a8
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	l32r	a8, .LC194
	movi	a10, 0x7f7
	add.n	a8, a7, a8
	slli	a10, a10, 5
	s32i	a11, sp, 76
	s32i	a8, sp, 0
	mov.n	a14, a4
	mov.n	a15, a5
	addi	a11, sp, 16
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner18admitCommissioningERKNS0_10BusRequestEyyRNS0_9RequestIdE
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
.L412:
	retw.n
.LFE2343:
	.size	_ZN12_GLOBAL__N_119persistenceReadStepERNS_3AppEy, .-_ZN12_GLOBAL__N_119persistenceReadStepERNS_3AppEy
	.literal_position
	.literal .LC195, 757624
	.literal .LC196, 64908
	.literal .LC197, 64904
	.literal .LC198, 64907
	.literal .LC199, 64910
	.literal .LC200, 64880
	.literal .LC202, 64888
	.literal .LC203, 64892
	.literal .LC204, 45700
	.literal .LC206, 772456
	.literal .LC207, 64900
	.literal .LC208, 64909
	.literal .LC209, 3000000
	.align	4
	.type	_ZN12_GLOBAL__N_123persistenceCaptureStartERNS_3AppEyb, @function
_ZN12_GLOBAL__N_123persistenceCaptureStartERNS_3AppEyb:
.LFB2346:
	entry	sp, 48
.LCFI41:
	l32r	a9, .LC195
	mov.n	a7, a2
	add.n	a10, a2, a9
	l32i	a11, a10, 0
	mov.n	a12, a4
	mov.n	a8, a6
	movi.n	a2, 7
	beqz.n	a11, .L416
	l32r	a10, .LC196
	movi.n	a13, 0
	add.n	a10, a7, a10
	s8i	a6, a10, 0
	l32r	a10, .LC197
	l32r	a6, .LC198
	add.n	a10, a7, a10
	l32r	a3, .LC199
	s8i	a13, a10, 0
	movi.n	a14, 1
	add.n	a10, a7, a6
	s8i	a14, a10, 0
	l32r	a15, .LC209
	add.n	a10, a7, a3
	s8i	a13, a10, 0
	l32r	a10, .LC200
	add.n	a14, a4, a15
	add.n	a10, a7, a10
	mov.n	a13, a5
	bgeu	a14, a15, .L417
	addi.n	a13, a5, 1
.L417:
	s32i	a14, a10, 0
	s32i	a13, a10, 4
	add.n	a9, a7, a9
	addi.n	a10, a11, 1
	s32i	a10, a9, 0
	l32r	a9, .LC202
	l32r	a10, .LC204
	add.n	a9, a7, a9
	s32i	a11, a9, 0
	add.n	a10, a7, a10
	l32r	a9, .LC203
	l32i	a10, a10, 0
	add.n	a9, a7, a9
	s32i	a10, a9, 0
	l32r	a10, .LC206
	movi	a9, 0x1fb
	add.n	a10, a7, a10
	l32i	a10, a10, 0
	l32r	a4, .LC207
	slli	a9, a9, 7
	add.n	a9, a7, a9
	s32i	a10, a9, 0
	add.n	a9, a7, a4
	movi.n	a10, 0
	s32i	a10, a9, 0
	bnez.n	a8, .L418
	l32r	a9, .LC208
	add.n	a9, a7, a9
	s8i	a8, a9, 0
.L418:
	mov.n	a13, a5
	mov.n	a10, a7
	s32i	a12, sp, 0
	call8	_ZN12_GLOBAL__N_122persistencePrepareReadERNS_3AppEy
	l32i	a12, sp, 0
	bnez.n	a10, .L419
	add.n	a6, a7, a6
	s8i	a10, a6, 0
	add.n	a3, a7, a3
	movi.n	a8, 1
	s8i	a8, a3, 0
	add.n	a4, a7, a4
	s32i	a10, a4, 0
	movi.n	a2, 8
	j	.L416
.L419:
	mov.n	a13, a5
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119persistenceReadStepERNS_3AppEy
	mov.n	a2, a10
	beqz.n	a10, .L416
	add.n	a6, a7, a6
	movi.n	a8, 0
	s8i	a8, a6, 0
	add.n	a3, a7, a3
	movi.n	a8, 1
	s8i	a8, a3, 0
	add.n	a7, a7, a4
	movi.n	a8, 0
	s32i	a8, a7, 0
.L416:
	retw.n
.LFE2346:
	.size	_ZN12_GLOBAL__N_123persistenceCaptureStartERNS_3AppEyb, .-_ZN12_GLOBAL__N_123persistenceCaptureStartERNS_3AppEyb
	.literal_position
	.literal .LC210, 764792
	.align	4
	.type	_ZN12_GLOBAL__N_112debugCommandEPvPKN21MotorControlRSExample5Probe9DebugModeERNS2_13DebugSnapshotE, @function
_ZN12_GLOBAL__N_112debugCommandEPvPKN21MotorControlRSExample5Probe9DebugModeERNS2_13DebugSnapshotE:
.LFB2357:
	entry	sp, 32
.LCFI42:
	l32r	a10, .LC210
	mov.n	a11, a3
	mov.n	a12, a4
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe12DebugSession7commandEPKNS0_9DebugModeERNS0_13DebugSnapshotE
	mov.n	a2, a10
	retw.n
.LFE2357:
	.size	_ZN12_GLOBAL__N_112debugCommandEPvPKN21MotorControlRSExample5Probe9DebugModeERNS2_13DebugSnapshotE, .-_ZN12_GLOBAL__N_112debugCommandEPvPKN21MotorControlRSExample5Probe9DebugModeERNS2_13DebugSnapshotE
	.literal_position
	.literal .LC211, 758028
	.literal .LC212, 45756
	.literal .LC213, 45752
	.literal .LC214, 772456
	.align	4
	.type	_ZN12_GLOBAL__N_119submitMotionProfileERNS_3AppERNS0_18MotionProfileStateEby, @function
_ZN12_GLOBAL__N_119submitMotionProfileERNS_3AppERNS0_18MotionProfileStateEby:
.LFB2118:
	entry	sp, 160
.LCFI43:
	movi	a12, 0x68
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	beqz.n	a4, .L427
	l32r	a5, .LC211
	movi.n	a8, 0
	s32i	a8, sp, 124
	l32i	a8, a3, 40
	add.n	a5, a2, a5
	s32i	a8, sp, 116
	l16ui	a12, a5, 0
	l32i	a8, a3, 44
	addi	a13, sp, 124
	movi.n	a11, 2
	addi	a10, a3, 48
	s32i	a8, sp, 120
	call8	_ZN14MotorControlRS6ESS_RS12decodeUint32EPKtjNS0_9WordOrderERm
	s32i	a10, sp, 104
	s32i	a11, sp, 108
	s32i	a12, sp, 112
	extui	a10, a10, 0, 8
	bnez.n	a10, .L429
	l16ui	a12, a5, 0
	l8ui	a10, a3, 6
	movi.n	a14, 0x13
	addi	a13, a3, 64
	addi	a11, sp, 116
	call8	_ZN14MotorControlRS6ESS_RS25buildWritePositionProfileEhRKNS0_15PositionProfileENS0_9WordOrderEPhj
	j	.L437
.L427:
	l8ui	a10, a3, 6
	movi.n	a12, 0x13
	addi	a11, a3, 64
	call8	_ZN14MotorControlRS6ESS_RS24buildReadPositionProfileEhPhj
.L437:
	addi	a8, a3, 64
	s32i	a10, sp, 4
	s32i	a10, a3, 176
	s32i	a8, sp, 0
	movi.n	a10, 8
	bnez.n	a4, .L431
	movi.n	a10, 6
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L431:
	l32r	a8, .LC212
	l32i	a9, a3, 220
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 8
	s32i	a8, sp, 12
	l32r	a8, .LC213
	s32i	a9, sp, 28
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	movi.n	a10, 0x10
	s32i	a8, sp, 16
	l32i	a8, a3, 216
	movi.n	a9, 0x21
	s32i	a8, sp, 24
	l8ui	a8, a3, 6
	s32i	a8, sp, 40
	s8i	a8, sp, 54
	l32r	a8, .LC214
	add.n	a8, a2, a8
	l32i	a11, a8, 0
	movi.n	a8, 5
	bnez.n	a4, .L432
	movi.n	a10, 3
	movi.n	a9, 0x20
	movi.n	a8, 6
.L432:
	s16i	a8, sp, 50
	s32i	a11, sp, 44
	s8i	a10, sp, 55
	s16i	a9, sp, 48
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32i	a8, sp, 4
	s32i	a10, sp, 56
	s32i	a11, sp, 60
	bnez.n	a8, .L433
.L429:
	movi.n	a2, 0
	j	.L434
.L433:
	movi	a10, 0x7f7
	movi	a14, 0x138
	slli	a10, a10, 5
	add.n	a10, a2, a10
	add.n	a14, a3, a14
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	nsau	a2, a10
	srli	a2, a2, 5
.L434:
	retw.n
.LFE2118:
	.size	_ZN12_GLOBAL__N_119submitMotionProfileERNS_3AppERNS0_18MotionProfileStateEby, .-_ZN12_GLOBAL__N_119submitMotionProfileERNS_3AppERNS0_18MotionProfileStateEby
	.literal_position
	.literal .LC216, 45756
	.literal .LC217, 45752
	.literal .LC218, 327713
	.align	4
	.type	_ZN12_GLOBAL__N_116submitStageFrameERNS_3AppERNS0_12StageSessionEby, @function
_ZN12_GLOBAL__N_116submitStageFrameERNS_3AppERNS0_12StageSessionEby:
.LFB2251:
	entry	sp, 144
.LCFI44:
	movi	a12, 0x68
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l8ui	a10, a3, 4
	mov.n	a5, a2
	beqz.n	a4, .L440
	movi	a14, 0x9a
	movi.n	a15, 0x20
	add.n	a14, a3, a14
	movi.n	a13, 5
	addi	a12, a3, 28
	movi.n	a11, 0x21
	call8	_ZN14MotorControlRS6ESS_RS27buildWriteMultipleRegistersEhtPKttPhj
	j	.L441
.L440:
	movi	a13, 0x9a
	movi.n	a14, 0x20
	add.n	a13, a3, a13
	movi.n	a12, 5
	movi.n	a11, 0x21
	call8	_ZN14MotorControlRS6ESS_RS18buildReadRegistersEhttPhj
.L441:
	s32i	a10, sp, 4
	movi.n	a2, 8
	beqz.n	a10, .L442
	movi	a8, 0x9a
	add.n	a8, a3, a8
	s32i	a8, sp, 0
	movi.n	a10, 8
	bnez.n	a4, .L443
	movi.n	a10, 5
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L443:
	l32r	a8, .LC216
	l32i	a9, a3, 108
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 12
	l32r	a8, .LC217
	movi.n	a9, 0x10
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 8
	s32i	a8, sp, 16
	l32i	a8, a3, 104
	s32i	a8, sp, 24
	l8ui	a8, a3, 4
	s8i	a8, sp, 54
	l32i	a8, a3, 0
	s32i	a8, sp, 40
	l32i	a8, a3, 8
	s32i	a8, sp, 44
	movi.n	a8, 3
	movnez	a8, a9, a4
	s8i	a8, sp, 55
	l32r	a8, .LC218
	s32i	a8, sp, 48
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	s32i	a10, sp, 56
	movi	a10, 0x7f7
	movi	a14, 0x88
	slli	a10, a10, 5
	s32i	a11, sp, 60
	add.n	a14, a3, a14
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	add.n	a10, a5, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
.L442:
	retw.n
.LFE2251:
	.size	_ZN12_GLOBAL__N_116submitStageFrameERNS_3AppERNS0_12StageSessionEby, .-_ZN12_GLOBAL__N_116submitStageFrameERNS_3AppERNS0_12StageSessionEby
	.literal_position
	.literal .LC220, 757648
	.literal .LC221, 757620
	.literal .LC222, 757664
	.literal .LC223, 757680
	.literal .LC224, 300000
	.align	4
	.type	_ZN12_GLOBAL__N_114watchUsbOutputERNS_3AppEb, @function
_ZN12_GLOBAL__N_114watchUsbOutputERNS_3AppEb:
.LFB2059:
	entry	sp, 32
.LCFI45:
	call8	_Z18esp_timer_get_timev
	l32r	a5, .LC220
	mov.n	a7, a10
	add.n	a9, a2, a5
	l8ui	a10, a9, 32
	mov.n	a6, a11
	bnez.n	a3, .L450
	l32r	a8, .LC221
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L451
.L450:
	beqz.n	a10, .L452
	add.n	a10, a2, a5
	l32i	a8, a10, 12
	l32i	a9, a10, 8
	sub	a8, a6, a8
	bgeu	a7, a9, .L453
	addi.n	a8, a8, -1
.L453:
	l32r	a11, .LC222
	sub	a9, a7, a9
	add.n	a11, a2, a11
	l32i	a12, a11, 0
	l32i	a11, a11, 4
	bltu	a8, a11, .L455
	bne	a11, a8, .L454
	bgeu	a9, a12, .L454
.L455:
	mov.n	a9, a12
	mov.n	a8, a11
.L454:
	s32i	a9, a10, 16
	s32i	a8, a10, 20
.L452:
	l32r	a8, .LC223
	movi.n	a9, 0
	add.n	a8, a2, a8
	s16i	a9, a8, 0
	add.n	a5, a2, a5
	s32i	a7, a5, 0
	s32i	a6, a5, 4
	j	.L449
.L451:
	beqz.n	a10, .L457
.L463:
	add.n	a8, a2, a5
	l8ui	a9, a8, 33
	bnez.n	a9, .L449
	j	.L473
.L457:
	l32i	a8, a9, 0
	l32i	a10, a9, 4
	sub	a9, a11, a10
	bgeu	a7, a8, .L461
	addi.n	a9, a9, -1
.L461:
	sub	a11, a7, a8
	bnez.n	a9, .L460
	l32r	a9, .LC224
	bgeu	a9, a11, .L449
.L460:
	add.n	a4, a2, a5
	s32i	a8, a4, 8
	l32i	a8, a4, 24
	movi.n	a9, 1
	addi.n	a8, a8, 1
	s32i	a10, a4, 12
	s32i	a8, a4, 24
	s8i	a9, a4, 32
	addi	a10, a4, 36
	call8	_ZN21MotorControlRSExample8Platform13sampleConsoleERNS0_16ConsoleUsbSampleE
	l8ui	a8, a4, 32
	beqz.n	a8, .L449
	j	.L463
.L473:
	l32i	a9, a8, 8
	l32i	a8, a8, 12
	sub	a6, a6, a8
	bgeu	a7, a9, .L464
	addi.n	a6, a6, -1
.L464:
	sub	a7, a7, a9
	bnez.n	a6, .L466
	movi	a8, 0x3e8
	mull	a8, a8, a8
	bgeu	a8, a7, .L449
.L466:
	add.n	a2, a2, a5
	movi.n	a8, 1
	s8i	a8, a2, 33
	call8	_ZN21MotorControlRSExample8Platform12nudgeConsoleEv
	beqz.n	a10, .L449
	l32i	a8, a2, 28
	addi.n	a8, a8, 1
	s32i	a8, a2, 28
.L449:
	retw.n
.LFE2059:
	.size	_ZN12_GLOBAL__N_114watchUsbOutputERNS_3AppEb, .-_ZN12_GLOBAL__N_114watchUsbOutputERNS_3AppEb
	.literal_position
	.literal .LC226, 764504
	.literal .LC227, 764508
	.literal .LC228, 772456
	.literal .LC229, 764516
	.align	4
	.type	_ZN12_GLOBAL__N_117releaseFactsValidERKNS_3AppERKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesEy, @function
_ZN12_GLOBAL__N_117releaseFactsValidERKNS_3AppERKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesEy:
.LFB2128:
	entry	sp, 32
.LCFI46:
	l32r	a9, .LC226
	l32i	a10, a3, 0
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	mov.n	a8, a2
	movi.n	a2, 0
	bne	a10, a9, .L475
	l32r	a9, .LC227
	l8ui	a10, a3, 4
	add.n	a9, a8, a9
	l8ui	a9, a9, 0
	bne	a10, a9, .L475
	l32r	a9, .LC228
	l32i	a10, a3, 8
	add.n	a9, a8, a9
	l32i	a9, a9, 0
	bne	a10, a9, .L475
	l32r	a9, .LC229
	l32i	a11, a3, 12
	add.n	a9, a8, a9
	l32i	a10, a9, 0
	mov.n	a12, a2
	movi.n	a9, 1
	sub	a10, a10, a11
	moveqz	a12, a9, a10
	moveqz	a9, a2, a11
	and	a2, a12, a9
	beqz.n	a2, .L475
	l32i	a10, a3, 20
	l32i	a9, a3, 16
	bltu	a5, a10, .L485
	bne	a10, a5, .L486
	bltu	a4, a9, .L485
.L486:
	l32i	a12, a8, 0
	movi	a8, 0x3e8
	mull	a11, a8, a12
	muluh	a8, a8, a12
	or	a12, a11, a8
	beqz.n	a12, .L477
	sub	a5, a5, a10
	bgeu	a4, a9, .L479
	addi.n	a5, a5, -1
.L479:
	sub	a4, a4, a9
	bltu	a8, a5, .L485
	bne	a5, a8, .L477
	bltu	a11, a4, .L485
.L477:
	l8ui	a2, a3, 24
	beqz.n	a2, .L475
	l8ui	a2, a3, 25
	j	.L475
.L485:
	movi.n	a2, 0
.L475:
	retw.n
.LFE2128:
	.size	_ZN12_GLOBAL__N_117releaseFactsValidERKNS_3AppERKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesEy, .-_ZN12_GLOBAL__N_117releaseFactsValidERKNS_3AppERKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesEy
	.literal_position
	.literal .LC230, 774016
	.literal .LC231, 39492
	.literal .LC233, 41812
	.literal .LC234, 41808
	.literal .LC235, 44132
	.literal .LC237, 820464
	.align	4
	.type	_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm, @function
_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm:
.LFB2263:
	entry	sp, 32
.LCFI47:
	mov.n	a8, a2
	movi.n	a2, 0
	beqz.n	a3, .L496
	l32r	a9, .LC230
	l32r	a10, .LC231
	add.n	a9, a8, a9
	add.n	a10, a9, a10
	l32i	a10, a10, 0
	bne	a10, a3, .L498
	movi	a2, 0x269
	slli	a2, a2, 6
	j	.L505
.L498:
	l32r	a10, .LC233
	add.n	a10, a9, a10
	l32i	a10, a10, 0
	bne	a10, a3, .L499
	l32r	a2, .LC234
.L505:
	add.n	a2, a9, a2
	j	.L496
.L499:
	l32r	a10, .LC235
	add.n	a10, a9, a10
	l32i	a10, a10, 0
	bne	a10, a3, .L500
	movi	a2, 0x563
	slli	a2, a2, 5
	j	.L505
.L500:
	l32r	a9, .LC237
	add.n	a9, a8, a9
	l32i	a10, a9, 4
	bne	a3, a10, .L501
	mov.n	a2, a9
	j	.L496
.L501:
	movi	a9, 0x647
	slli	a9, a9, 9
	add.n	a8, a8, a9
	l32i	a9, a8, 4
	bne	a3, a9, .L496
	mov.n	a2, a8
.L496:
	retw.n
.LFE2263:
	.size	_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm, .-_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm
	.literal_position
	.literal .LC240, 771192
	.literal .LC241, 65248
	.literal .LC242, 770856
	.align	4
	.type	_ZN12_GLOBAL__N_123cancelSimplePreparationERNS_3AppEhy, @function
_ZN12_GLOBAL__N_123cancelSimplePreparationERNS_3AppEhy:
.LFB2239:
	entry	sp, 32
.LCFI48:
	l32r	a7, .LC240
	add.n	a8, a2, a7
	l8ui	a9, a8, 58
	beqz.n	a9, .L506
	l8ui	a9, a8, 56
	bne	a9, a3, .L506
	movi.n	a6, 1
	addmi	a9, a8, 0x200
	s8i	a6, a9, 105
	l32i	a11, a8, 68
	s8i	a6, a8, 110
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L511
	l32i	a8, a10, 32
	s8i	a6, a10, 71
	beqz.n	a8, .L511
	addi	a11, a10, 32
	l32r	a10, .LC241
	mov.n	a12, a4
	mov.n	a13, a5
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L511:
	add.n	a8, a2, a7
	l32i	a11, a8, 44
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L514
	movi.n	a8, 1
	s8i	a8, a10, 71
	l32i	a8, a10, 32
	beqz.n	a8, .L514
	addi	a11, a10, 32
	l32r	a10, .LC241
	mov.n	a12, a4
	mov.n	a13, a5
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L514:
	add.n	a8, a2, a7
	l8ui	a9, a8, 72
	beqz.n	a9, .L516
	movi	a9, 0xc8
	add.n	a8, a8, a9
	j	.L517
.L516:
	l32r	a8, .LC242
	add.n	a8, a2, a8
.L517:
	add.n	a7, a2, a7
	l8ui	a9, a7, 57
	bnei	a9, 2, .L506
	l32i	a9, a8, 312
	beqz.n	a9, .L506
	l32r	a10, .LC241
	movi	a11, 0x138
	mov.n	a12, a4
	mov.n	a13, a5
	add.n	a11, a8, a11
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L506:
	retw.n
.LFE2239:
	.size	_ZN12_GLOBAL__N_123cancelSimplePreparationERNS_3AppEhy, .-_ZN12_GLOBAL__N_123cancelSimplePreparationERNS_3AppEhy
	.literal_position
	.literal .LC244, 757620
	.literal .LC245, 757704
	.literal .LC246, 757616
	.literal .LC247, 626448
	.literal .LC248, 642836
	.literal .LC249, 642840
	.align	4
	.type	_ZN12_GLOBAL__N_14emitEPvPKcj, @function
_ZN12_GLOBAL__N_14emitEPvPKcj:
.LFB2058:
	entry	sp, 32
.LCFI49:
	movi.n	a8, 1
	slli	a8, a8, 14
	mov.n	a11, a3
	bltu	a8, a4, .L528
	l32r	a7, .LC244
	add.n	a7, a2, a7
	l32i	a8, a7, 0
	bnei	a8, 8, .L529
.L528:
	l32r	a8, .LC245
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L530
	addi.n	a10, a10, 1
.L530:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	movi.n	a2, 0
	j	.L531
.L529:
	l32r	a9, .LC246
	l32r	a5, .LC247
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	mov.n	a12, a4
	add.n	a8, a8, a9
	extui	a6, a8, 0, 3
	slli	a10, a6, 11
	add.n	a10, a10, a6
	addx2	a10, a10, a6
	addx4	a10, a10, a5
	add.n	a10, a2, a10
	call8	memcpy
	slli	a8, a6, 11
	add.n	a8, a8, a6
	addx2	a8, a8, a6
	addx4	a2, a8, a2
	add.n	a8, a2, a4
	add.n	a8, a8, a5
	movi.n	a9, 0xa
	s8i	a9, a8, 0
	l32r	a8, .LC248
	addi.n	a4, a4, 1
	add.n	a8, a2, a8
	s32i	a4, a8, 0
	l32r	a8, .LC249
	add.n	a2, a2, a8
	movi.n	a8, 0
	s32i	a8, a2, 0
	l32i	a8, a7, 0
	movi.n	a2, 1
	addi.n	a8, a8, 1
	s32i	a8, a7, 0
.L531:
	retw.n
.LFE2058:
	.size	_ZN12_GLOBAL__N_14emitEPvPKcj, .-_ZN12_GLOBAL__N_14emitEPvPKcj
	.align	4
	.type	_ZZN12_GLOBAL__N_113homeFirstReadERKNS_3AppEyENKUlRKN14MotorControlRS6ESS_RS19ReadStepObservationEE_clES7_, @function
_ZZN12_GLOBAL__N_113homeFirstReadERKNS_3AppEyENKUlRKN14MotorControlRS6ESS_RS19ReadStepObservationEE_clES7_:
.LFB2363:
	entry	sp, 32
.LCFI50:
	mov.n	a10, a2
	l8ui	a2, a3, 52
	beqz.n	a2, .L533
	l8ui	a8, a3, 100
	bnez.n	a8, .L542
	l32i	a8, a10, 0
	l32i	a11, a3, 76
	l32i	a9, a8, 0
	l32i	a8, a8, 4
	bltu	a8, a11, .L542
	bne	a11, a8, .L543
	l32i	a11, a3, 72
	bltu	a9, a11, .L542
.L543:
	l32i	a12, a3, 60
	l32i	a11, a3, 56
	bltu	a8, a12, .L542
	bne	a12, a8, .L544
	bltu	a9, a11, .L542
.L544:
	l32i	a10, a10, 4
	l32i	a13, a10, 0
	l32i	a10, a10, 4
	or	a14, a13, a10
	beqz.n	a14, .L533
	sub	a8, a8, a12
	bgeu	a9, a11, .L537
	addi.n	a8, a8, -1
.L537:
	sub	a9, a9, a11
	movi.n	a2, 1
	bltu	a8, a10, .L538
	bne	a10, a8, .L539
	bltu	a9, a13, .L538
.L539:
	movi.n	a2, 0
.L538:
	extui	a2, a2, 0, 8
	j	.L533
.L542:
	movi.n	a2, 0
.L533:
	retw.n
.LFE2363:
	.size	_ZZN12_GLOBAL__N_113homeFirstReadERKNS_3AppEyENKUlRKN14MotorControlRS6ESS_RS19ReadStepObservationEE_clES7_, .-_ZZN12_GLOBAL__N_113homeFirstReadERKNS_3AppEyENKUlRKN14MotorControlRS6ESS_RS19ReadStepObservationEE_clES7_
	.literal_position
	.literal .LC251, 45756
	.literal .LC252, 45752
	.literal .LC253, 47864
	.literal .LC255, 47848
	.literal .LC256, 47876
	.literal .LC257, 772456
	.align	4
	.type	_ZN12_GLOBAL__N_119submitCommunicationERNS_3AppEy$constprop$0, @function
_ZN12_GLOBAL__N_119submitCommunicationERNS_3AppEy$constprop$0:
.LFB2466:
	entry	sp, 288
.LCFI51:
	mov.n	a7, a2
	addi	a6, sp, 16
	movi	a2, 0xb0
	add.n	a2, a6, a2
	movi	a3, 0x597
	movi.n	a12, 0x40
	movi.n	a11, 0
	mov.n	a10, a2
	slli	a3, a3, 5
	call8	memset
	add.n	a3, a7, a3
	movi.n	a8, 2
	mov.n	a14, a2
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a3
	s8i	a8, sp, 192
	call8	_ZN14MotorControlRS6ESS_RS17nextCommunicationERKNS0_20CommunicationContextEyRNS0_21PreparedCommunicationE
	l8ui	a8, sp, 192
	or	a10, a10, a8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L553
	movi.n	a2, 8
	j	.L554
.L553:
	movi	a12, 0x60
	movi.n	a11, 0
	addi	a10, sp, 24
	call8	memset
	l32i	a8, sp, 240
	addi	a2, a2, 40
	s32i	a8, sp, 20
	l8ui	a8, sp, 225
	s32i	a2, sp, 16
	movi.n	a10, 8
	bnez.n	a8, .L556
	l16ui	a10, sp, 230
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L556:
	l32i	a8, sp, 248
	l32i	a9, sp, 252
	s32i	a8, sp, 40
	l32r	a8, .LC251
	s32i	a9, sp, 44
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	l8ui	a9, sp, 225
	s32i	a8, sp, 28
	l32r	a8, .LC252
	s32i	a10, sp, 24
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	movi.n	a10, 6
	s32i	a8, sp, 32
	l8ui	a8, sp, 200
	s8i	a8, sp, 70
	l32i	a8, sp, 196
	s32i	a8, sp, 56
	l32i	a8, sp, 204
	s32i	a8, sp, 60
	movi.n	a8, 3
	movnez	a8, a10, a9
	s8i	a8, sp, 71
	l16ui	a8, sp, 226
	s16i	a8, sp, 64
	movi.n	a8, 1
	bnez.n	a9, .L558
	l16ui	a8, sp, 230
.L558:
	s16i	a8, sp, 66
	l16ui	a8, sp, 228
	s16i	a8, sp, 68
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32r	a8, .LC253
	s32i	a10, sp, 72
	add.n	a8, a7, a8
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	l32r	a8, .LC255
	movi	a10, 0x7f7
	add.n	a8, a7, a8
	slli	a10, a10, 5
	s32i	a11, sp, 76
	s32i	a8, sp, 0
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a11, a6
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner18admitCommissioningERKNS0_10BusRequestEyyRNS0_9RequestIdE
	mov.n	a2, a10
	bnez.n	a10, .L559
	l32r	a9, .LC257
	l32r	a8, .LC256
	add.n	a8, a7, a8
	add.n	a7, a7, a9
	l32i	a9, a7, 0
	s32i	a9, a8, 0
	j	.L554
.L559:
	movi.n	a11, 0
	movi.n	a12, 0x38
	addi	a10, a6, 120
	call8	memset
	movi	a8, 0xb4
	add.n	a6, a6, a8
	l32i	a8, a6, 0
	addi	a11, sp, 120
	s32i	a8, sp, 120
	l32i	a8, a6, 8
	l32i	a9, a6, 4
	s32i	a8, a11, 8
	l32i	a8, sp, 220
	s32i	a9, a11, 4
	s32i	a8, sp, 132
	l8ui	a8, sp, 224
	mov.n	a12, a4
	s8i	a8, sp, 136
	mov.n	a13, a5
	movi.n	a8, 1
	mov.n	a10, a3
	s8i	a8, sp, 137
	s32i	a2, sp, 168
	call8	_ZN14MotorControlRS6ESS_RS20advanceCommunicationERNS0_20CommunicationContextERKNS_11ActionEventEy
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
.L554:
	retw.n
.LFE2466:
	.size	_ZN12_GLOBAL__N_119submitCommunicationERNS_3AppEy$constprop$0, .-_ZN12_GLOBAL__N_119submitCommunicationERNS_3AppEy$constprop$0
	.align	4
	.type	_ZZN12_GLOBAL__N_120cancelPositionStagesERNS_3AppEhyENKUlRNS0_12StageSessionEE_clES3_, @function
_ZZN12_GLOBAL__N_120cancelPositionStagesERNS_3AppEhyENKUlRNS0_12StageSessionEE_clES3_:
.LFB2256:
	entry	sp, 32
.LCFI52:
	l8ui	a8, a3, 24
	beqz.n	a8, .L564
	l32i	a8, a2, 0
	l8ui	a9, a3, 4
	l8ui	a8, a8, 0
	bne	a9, a8, .L564
	movi.n	a8, 1
	s8i	a8, a3, 26
	l32i	a8, a3, 136
	beqz.n	a8, .L564
	l32i	a10, a2, 4
	movi	a8, 0x88
	movi	a7, 0x7f7
	add.n	a3, a3, a8
	slli	a7, a7, 5
	mov.n	a11, a3
	add.n	a10, a10, a7
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	bnez.n	a10, .L564
	l32i	a8, a2, 8
	l32i	a10, a2, 4
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	mov.n	a11, a3
	add.n	a10, a10, a7
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L564:
	retw.n
.LFE2256:
	.size	_ZZN12_GLOBAL__N_120cancelPositionStagesERNS_3AppEhyENKUlRNS0_12StageSessionEE_clES3_, .-_ZZN12_GLOBAL__N_120cancelPositionStagesERNS_3AppEhyENKUlRNS0_12StageSessionEE_clES3_
	.align	4
	.type	_ZZN12_GLOBAL__N_120settledInterruptPairERKNS_3App6RecordES3_ENKUlS3_E_clES3_$isra$0, @function
_ZZN12_GLOBAL__N_120settledInterruptPairERKNS_3App6RecordES3_ENKUlS3_E_clES3_$isra$0:
.LFB2468:
	entry	sp, 32
.LCFI53:
	l8ui	a9, a2, 0
	mov.n	a8, a2
	movi.n	a2, 0
	bnei	a9, 4, .L572
	l8ui	a2, a8, 67
	beqz.n	a2, .L572
	l8ui	a2, a8, 65
	beqz.n	a2, .L572
	addmi	a9, a8, 0x600
	l8ui	a2, a9, 232
	bnez.n	a2, .L575
	l8ui	a9, a8, 69
	bnez.n	a9, .L572
	addmi	a8, a8, 0x300
	l8ui	a2, a8, 8
	bnez.n	a2, .L575
	l8ui	a9, a8, 11
	bnez.n	a9, .L572
	l8ui	a2, a8, 10
	movi.n	a8, 1
	xor	a2, a2, a8
	extui	a2, a2, 0, 8
	j	.L572
.L575:
	movi.n	a2, 0
.L572:
	retw.n
.LFE2468:
	.size	_ZZN12_GLOBAL__N_120settledInterruptPairERKNS_3App6RecordES3_ENKUlS3_E_clES3_$isra$0, .-_ZZN12_GLOBAL__N_120settledInterruptPairERKNS_3App6RecordES3_ENKUlS3_E_clES3_$isra$0
	.section	.rodata.str1.1
.LC259:
	.string	"qualification_rejected"
	.text
	.literal_position
	.literal .LC260, .LC259
	.align	4
	.type	_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0, @function
_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0:
.LFB2469:
	entry	sp, 48
.LCFI54:
	mov.n	a8, a3
	movi.n	a3, 0
	beqz.n	a2, .L583
	movi.n	a2, 1
	beqi	a8, 1, .L583
.L586:
	l32r	a3, .LC260
	movi.n	a2, 3
.L583:
	s8i	a2, sp, 0
	l32i	a2, sp, 0
	movi.n	a4, 0
	movi.n	a5, 0
	retw.n
.LFE2469:
	.size	_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0, .-_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0
	.literal_position
	.literal .LC262, _ZN12_GLOBAL__N_14uartE
	.literal .LC263, 65072
	.align	4
	.type	_ZN12_GLOBAL__N_15resetEPv, @function
_ZN12_GLOBAL__N_15resetEPv:
.LFB2320:
	entry	sp, 32
.LCFI55:
	l32r	a10, .LC263
	movi.n	a12, 0x24
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a10, .LC262
	call8	_ZN21MotorControlRSExample11Esp32S3Uart10resetStatsEv
	retw.n
.LFE2320:
	.size	_ZN12_GLOBAL__N_15resetEPv, .-_ZN12_GLOBAL__N_15resetEPv
	.literal_position
	.literal .LC264, 771912
	.literal .LC265, 771920
	.literal .LC266, 771877
	.literal .LC267, 771885
	.align	4
	.type	_ZN12_GLOBAL__N_132revokePositionStartSpeedRelationERNS_3AppE, @function
_ZN12_GLOBAL__N_132revokePositionStartSpeedRelationERNS_3AppE:
.LFB2109:
	entry	sp, 32
.LCFI56:
	l32r	a8, .LC264
	l32r	a10, .LC265
	add.n	a8, a2, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
	add.n	a10, a2, a10
	movi.n	a12, 0x20
	movi.n	a11, 0
	call8	memset
	l32r	a8, .LC266
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC267
	add.n	a2, a2, a8
	s8i	a9, a2, 0
	retw.n
.LFE2109:
	.size	_ZN12_GLOBAL__N_132revokePositionStartSpeedRelationERNS_3AppE, .-_ZN12_GLOBAL__N_132revokePositionStartSpeedRelationERNS_3AppE
	.literal_position
	.literal .LC268, 772524
	.literal .LC269, 764508
	.literal .LC270, 764516
	.literal .LC271, 764696
	.literal .LC272, 757972
	.literal .LC273, 764771
	.literal .LC274, 771828
	.literal .LC275, 50000
	.literal .LC276, 771840
	.literal .LC279, 772072
	.literal .LC280, 771952
	.literal .LC281, 764788
	.literal .LC282, 101000
	.literal .LC283, 625320
	.literal .LC287, 764520
	.literal .LC288, 764524
	.literal .LC289, 764528
	.literal .LC290, 771384
	.literal .LC291, 764688
	.literal .LC293, 764568
	.literal .LC294, 764572
	.literal .LC295, 764576
	.literal .LC296, 764580
	.literal .LC297, 764584
	.literal .LC298, 764588
	.literal .LC299, 758800
	.literal .LC300, 758808
	.literal .LC301, 759272
	.literal .LC302, 759280
	.literal .LC303, 762104
	.literal .LC304, 762112
	.literal .LC305, 759744
	.literal .LC306, 759752
	.literal .LC307, 760216
	.literal .LC308, 261728
	.literal .LC309, 764496
	.literal .LC310, -3000
	.literal .LC311, 3000
	.align	4
	.type	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE, @function
_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE:
.LFB2202:
	entry	sp, 176
.LCFI57:
	l8ui	a5, sp, 180
	s32i	a7, sp, 128
	mov.n	a7, a2
	bnei	a5, 10, .L593
	l32r	a10, .LC268
	srli	a9, a3, 3
	add.n	a9, a2, a9
	add.n	a9, a9, a10
	extui	a11, a3, 0, 3
	movi.n	a10, 1
	ssl	a11
	sll	a10, a10
	l8ui	a11, a9, 0
	or	a10, a10, a11
	s8i	a10, a9, 0
.L593:
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L594
	bnei	a5, 10, .L595
	addmi	a10, a10, 0x900
	movi.n	a9, 1
	s8i	a9, a10, 104
.L595:
	l32i	a13, sp, 128
	mov.n	a12, a6
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy
.L594:
	addi	a10, a5, -10
	extui	a10, a10, 0, 8
	l32r	a9, .LC269
	bgeui	a10, 2, .L596
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a3, .L592
	bnei	a5, 10, .L598
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_132revokePositionStartSpeedRelationERNS_3AppE
.L598:
	l32r	a9, .LC270
	movi.n	a13, -3
	add.n	a10, a7, a9
	l32i	a11, a10, 0
	movi.n	a10, 0
	addi.n	a12, a11, -1
	bltu	a13, a12, .L599
	addi.n	a10, a11, 1
.L599:
	add.n	a9, a7, a9
	s32i	a10, a9, 0
	l32r	a10, .LC271
	movi.n	a12, 0x40
	movi.n	a11, 0
	add.n	a10, a7, a10
	call8	memset
	l32r	a9, .LC272
	movi.n	a5, 0
	add.n	a9, a7, a9
	s32i	a5, a9, 0
	l32r	a9, .LC273
	movi.n	a12, 0x48
	add.n	a9, a7, a9
	s8i	a5, a9, 0
	l32r	a9, .LC274
	movi.n	a11, 0
	add.n	a9, a7, a9
	s32i	a5, a9, 0
	mov.n	a10, sp
	call8	memset
	movi	a9, 0x7d0
	s16i	a9, sp, 16
	l32r	a9, .LC275
	l32r	a10, .LC276
	s32i	a9, sp, 20
	movi	a9, 0x64
	s16i	a9, sp, 24
	movi.n	a12, 0x48
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a9, .LC310
	l32r	a10, .LC279
	s16i	a9, sp, 26
	l32r	a9, .LC311
	movi.n	a12, 0x38
	s16i	a9, sp, 28
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a10, .LC280
	movi.n	a9, 0x23
	s16i	a9, sp, 20
	movi.n	a9, 7
	s16i	a9, sp, 30
	movi	a12, 0x78
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a9, .LC281
	movi	a10, 0x7f7
	add.n	a9, a7, a9
	s8i	a5, a9, 0
	slli	a10, a10, 5
	l32r	a9, .LC282
	l32r	a5, .LC283
	add.n	a8, a7, a10
	movi.n	a2, 0x50
	add.n	a4, a7, a9
	add.n	a5, a7, a5
	s32i	a8, sp, 132
	addmi	a2, a2, 0x2300
	j	.L604
.L609:
	l32i	a8, sp, 176
	beq	a4, a8, .L606
	movi	a10, 0x308
	add.n	a10, a4, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L606
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L606
	movi.n	a8, 0x39
	addmi	a8, a8, 0x2300
	add.n	a10, a4, a8
	l8ui	a10, a10, 0
	beqz.n	a10, .L608
	l8ui	a10, a4, 24
	bne	a10, a3, .L606
.L608:
	movi.n	a10, 1
	s8i	a10, a4, 71
	l32i	a10, a4, 32
	beqz.n	a10, .L606
	l32i	a13, sp, 128
	l32i	a10, sp, 132
	mov.n	a12, a6
	addi	a11, a4, 32
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L606:
	add.n	a4, a4, a2
.L604:
	bne	a4, a5, .L609
	j	.L629
.L596:
	mov.n	a10, a5
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	l32r	a9, .LC269
	mov.n	a2, a10
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a3, .L610
	l32i	a13, sp, 128
	l32i	a11, sp, 176
	mov.n	a12, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	bnez.n	a2, .L612
	extui	a9, a4, 0, 2
	beqz.n	a9, .L614
	l32r	a9, .LC287
	movi.n	a10, 1
	add.n	a9, a7, a9
	s8i	a2, a9, 0
	s8i	a2, a9, 1
	s8i	a2, a9, 2
	s8i	a2, a9, 3
	l32r	a9, .LC288
	add.n	a9, a7, a9
	s8i	a10, a9, 0
	s8i	a2, a9, 1
	s8i	a2, a9, 2
	s8i	a2, a9, 3
	l32r	a9, .LC289
	add.n	a9, a7, a9
	s8i	a2, a9, 0
	l32r	a9, .LC290
	add.n	a9, a7, a9
	s8i	a2, a9, 0
	bbci	a4, 0, .L614
	l32r	a9, .LC291
	add.n	a9, a7, a9
	s8i	a2, a9, 0
.L614:
	bbci	a4, 24, .L612
	l32r	a10, .LC293
	movi.n	a9, 0
	add.n	a10, a7, a10
	s8i	a9, a10, 0
	s8i	a9, a10, 1
	s8i	a9, a10, 2
	s8i	a9, a10, 3
	l32r	a10, .LC294
	movi.n	a11, 1
	add.n	a10, a7, a10
	s8i	a11, a10, 0
	s8i	a9, a10, 1
	s8i	a9, a10, 2
	s8i	a9, a10, 3
	l32r	a10, .LC295
	add.n	a10, a7, a10
	s8i	a9, a10, 0
	l32r	a10, .LC296
	add.n	a10, a7, a10
	s8i	a9, a10, 0
	l32r	a10, .LC297
	add.n	a10, a7, a10
	s8i	a9, a10, 0
	s8i	a9, a10, 1
	s8i	a9, a10, 2
	s8i	a9, a10, 3
	l32r	a9, .LC298
	add.n	a9, a7, a9
	s8i	a11, a9, 0
.L612:
	l32r	a9, .LC272
	movi.n	a13, 0
	add.n	a9, a7, a9
	s32i	a13, a9, 0
	movi.n	a12, 0x48
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi	a9, 0x7d0
	s16i	a9, sp, 16
	l32r	a9, .LC275
	l32r	a10, .LC276
	s32i	a9, sp, 20
	movi	a9, 0x64
	s16i	a9, sp, 24
	movi.n	a12, 0x48
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a9, .LC310
	l32r	a10, .LC279
	s16i	a9, sp, 26
	l32r	a9, .LC311
	movi.n	a12, 0x38
	s16i	a9, sp, 28
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a10, .LC280
	movi.n	a9, 0x23
	s16i	a9, sp, 20
	movi.n	a9, 7
	s16i	a9, sp, 30
	movi	a12, 0x78
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a9, .LC281
	movi.n	a13, 0
	add.n	a9, a7, a9
	s8i	a13, a9, 0
.L610:
	l32r	a9, .LC299
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a3, .L620
	l32r	a9, .LC300
	movi.n	a10, 0
	add.n	a9, a7, a9
	s32i	a10, a9, 0
.L620:
	l32r	a9, .LC301
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a3, .L621
	l32r	a9, .LC302
	movi.n	a10, 0
	add.n	a9, a7, a9
	s32i	a10, a9, 0
.L621:
	l32r	a10, .LC303
	add.n	a9, a7, a10
	l8ui	a9, a9, 0
	bne	a9, a3, .L622
	l32r	a9, .LC304
	movi.n	a11, 0
	add.n	a9, a7, a9
	s32i	a11, a9, 0
.L622:
	l32r	a9, .LC305
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a3, .L623
	l32r	a9, .LC306
	movi.n	a11, 0
	add.n	a9, a7, a9
	s32i	a11, a9, 0
.L623:
	l32r	a9, .LC307
	add.n	a10, a7, a10
	add.n	a9, a7, a9
	movi.n	a11, 0
	movi	a12, 0x1d8
	j	.L624
.L626:
	l8ui	a13, a9, 0
	bne	a13, a3, .L625
	s32i	a11, a9, 8
.L625:
	add.n	a9, a9, a12
.L624:
	bne	a10, a9, .L626
	bnei	a5, 6, .L627
	beqz.n	a2, .L631
	bbsi	a4, 0, .L628
	j	.L629
.L627:
	bnez.n	a2, .L629
.L631:
	l32r	a9, .LC308
	bnone	a4, a9, .L629
.L628:
	l32r	a9, .LC309
	movi.n	a10, 0
	add.n	a9, a7, a9
	s8i	a10, a9, 0
.L629:
	l32i	a13, sp, 128
	movi.n	a14, 0
	mov.n	a12, a6
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb
.L592:
	retw.n
.LFE2202:
	.size	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE, .-_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE
	.literal_position
	.literal .LC312, 764516
	.align	4
	.type	_ZN12_GLOBAL__N_113driverEffectsERNS_3AppERNS0_6RecordEmy, @function
_ZN12_GLOBAL__N_113driverEffectsERNS_3AppERNS0_6RecordEmy:
.LFB2203:
	entry	sp, 48
.LCFI58:
	addmi	a5, a3, 0x1000
	l32i	a8, a5, 180
	mov.n	a15, a7
	and	a12, a8, a4
	xor	a12, a12, a4
	mov.n	a14, a6
	beqz.n	a12, .L656
	or	a8, a8, a4
	s32i	a8, a5, 180
	l8ui	a8, a5, 184
	s32i	a3, sp, 0
	s32i	a8, sp, 4
	l8ui	a11, a3, 24
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE
	addmi	a3, a3, 0x1f00
	l8ui	a8, a3, 88
	beqz.n	a8, .L656
	l32r	a8, .LC312
	add.n	a2, a2, a8
	l32i	a8, a2, 0
	s32i	a8, a5, 176
.L656:
	retw.n
.LFE2203:
	.size	_ZN12_GLOBAL__N_113driverEffectsERNS_3AppERNS0_6RecordEmy, .-_ZN12_GLOBAL__N_113driverEffectsERNS_3AppERNS0_6RecordEmy
	.literal_position
	.literal .LC313, 757628
	.literal .LC314, 115200
	.literal .LC315, .LC12
	.literal .LC317, 771228
	.literal .LC318, 771240
	.literal .LC319, 771248
	.literal .LC320, 771250
	.literal .LC321, 771192
	.literal .LC322, 626240
	.literal .LC323, 626244
	.literal .LC324, 626248
	.literal .LC325, 626256
	.literal .LC326, 626264
	.literal .LC327, 65248
	.literal .LC328, 626344
	.literal .LC329, 626348
	.literal .LC330, 626352
	.literal .LC331, 626360
	.literal .LC332, 626392
	.literal .LC333, .L680
	.literal .LC338, 200000
	.literal .LC339, _ZN12_GLOBAL__N_1L16BROADCAST_FRAMESE
	.align	4
	.type	_ZN12_GLOBAL__N_16lookupEPvmRN21MotorControlRSExample5Probe10ResultViewE, @function
_ZN12_GLOBAL__N_16lookupEPvmRN21MotorControlRSExample5Probe10ResultViewE:
.LFB2309:
	entry	sp, 384
.LCFI59:
	bnez.n	a3, .L664
	l32r	a8, .LC313
	add.n	a8, a2, a8
	l32i	a3, a8, 0
.L664:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm
	mov.n	a7, a10
	beqz.n	a10, .L665
	movi	a12, 0x140
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a9, .LC314
	mov.n	a8, a10
	s32i	a9, sp, 20
	l32r	a9, .LC315
	addmi	a10, a10, 0x100
	s32i	a9, sp, 196
	movi.n	a9, 1
	s8i	a9, sp, 248
	s8i	a9, a10, 56
	mov.n	a11, a8
	movi	a12, 0x140
	mov.n	a10, a4
	call8	memcpy
	l32i	a8, a7, 8
	movi.n	a11, -8
	addmi	a11, a11, 0x900
	s32i	a8, a4, 16
	s32i	a3, a4, 20
	movi.n	a12, 5
	add.n	a11, a7, a11
	addi.n	a10, a4, 4
	call8	memcpy
	addmi	a8, a7, 0x900
	l32i	a8, a8, 0
	s32i	a7, a4, 72
	s32i	a8, a4, 12
	l8ui	a8, a7, 12
	j	.L707
.L665:
	beqz.n	a3, .L668
	l32r	a8, .LC317
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a8, a3, .L669
	movi	a12, 0x140
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a9, .LC314
	mov.n	a8, a10
	s32i	a9, sp, 20
	l32r	a9, .LC315
	s32i	a7, sp, 192
	s32i	a9, sp, 196
	movi.n	a9, 1
	s8i	a9, sp, 248
	addmi	a10, a10, 0x100
	s8i	a9, a10, 56
	mov.n	a11, a8
	movi	a12, 0x140
	mov.n	a10, a4
	call8	memcpy
	l32r	a8, .LC318
	s32i	a3, a4, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a8, a4, 16
	l32r	a8, .LC319
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	s8i	a8, a4, 24
	l32r	a8, .LC320
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	s8i	a8, a4, 25
	l32r	a8, .LC321
	add.n	a8, a2, a8
	s32i	a8, a4, 0
.L667:
	movi.n	a2, 1
	j	.L671
.L669:
	l32r	a8, .LC322
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a8, a3, .L672
	movi	a12, 0x140
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a9, .LC314
	movi.n	a6, 1
	s32i	a9, sp, 20
	l32r	a9, .LC315
	s32i	a7, sp, 192
	s32i	a9, sp, 196
	s8i	a6, sp, 248
	addmi	a9, a10, 0x100
	s8i	a6, a9, 56
	mov.n	a11, a10
	movi	a12, 0x140
	mov.n	a10, a4
	call8	memcpy
	l32r	a8, .LC323
	s32i	a3, a4, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	l32r	a11, .LC324
	s32i	a8, a4, 16
	add.n	a11, a2, a11
	movi.n	a12, 5
	addi.n	a10, a4, 4
	call8	memcpy
	l32r	a8, .LC325
	l32r	a10, .LC327
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	add.n	a10, a2, a10
	s32i	a8, a4, 12
	l32r	a8, .LC326
	s8i	a6, a4, 26
	add.n	a8, a2, a8
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner14recoveryResultEy
	movi.n	a8, 1
	movnez	a8, a7, a10
	mov.n	a11, a10
	s8i	a8, a4, 25
	addmi	a10, a4, 0x100
	movi.n	a12, 0x32
	bnez.n	a11, .L706
	j	.L667
.L672:
	l32r	a8, .LC328
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a8, a3, .L668
	movi	a12, 0x140
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a9, .LC314
	s32i	a7, sp, 192
	s32i	a9, sp, 20
	l32r	a9, .LC315
	movi.n	a7, 1
	s32i	a9, sp, 196
	s8i	a7, sp, 248
	addmi	a9, a10, 0x100
	mov.n	a11, a10
	s8i	a7, a9, 56
	movi	a12, 0x140
	mov.n	a10, a4
	call8	memcpy
	l32r	a8, .LC329
	s32i	a3, a4, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	l32r	a11, .LC330
	s32i	a8, a4, 16
	movi.n	a12, 5
	add.n	a11, a2, a11
	addi.n	a10, a4, 4
	call8	memcpy
	l32r	a8, .LC331
	l32r	a11, .LC332
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	addmi	a10, a4, 0x100
	s32i	a8, a4, 12
	s8i	a7, a4, 26
	movi.n	a12, 0x32
	add.n	a11, a2, a11
.L706:
	addi.n	a10, a10, 8
	call8	memcpy
	j	.L667
.L668:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a10
	beqz.n	a10, .L676
	l8ui	a5, a10, 68
	bnez.n	a5, .L676
	addi	a6, sp, 16
	movi	a12, 0x140
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	l32r	a8, .LC314
	addmi	a9, a6, 0x100
	s32i	a8, sp, 20
	l32r	a8, .LC315
	s32i	a5, sp, 192
	s32i	a8, sp, 196
	movi.n	a8, 1
	s8i	a8, sp, 248
	s8i	a8, a9, 56
	movi	a12, 0x140
	mov.n	a11, a6
	mov.n	a10, a4
	call8	memcpy
	movi.n	a12, 5
	addi.n	a11, a7, 12
	addi.n	a10, a4, 4
	call8	memcpy
	l32i	a8, a7, 20
	s32i	a8, a4, 12
	l32i	a8, a7, 8
	s32i	a3, a4, 20
	s32i	a8, a4, 16
	l8ui	a8, a7, 24
	s8i	a8, a4, 24
	l8ui	a8, a7, 66
	s8i	a8, a4, 27
	l8ui	a8, a7, 0
	bgeui	a8, 8, .L678
	l32r	a9, .LC333
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L680:
	.word	.L676
	.word	.L678
	.word	.L685
	.word	.L684
	.word	.L683
	.word	.L682
	.word	.L681
	.word	.L679
	.text
.L676:
	movi.n	a2, 0
	j	.L671
.L679:
	movi	a8, 0x60
	addmi	a8, a8, 0x1f00
	add.n	a8, a7, a8
	s32i	a8, a4, 68
	j	.L709
.L681:
	movi	a8, 0xb8
	addmi	a8, a8, 0x1000
	add.n	a8, a7, a8
	s32i	a8, a4, 64
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	movi.n	a8, 1
	xor	a10, a10, a8
	s8i	a10, a4, 25
	j	.L667
.L682:
	movi.n	a8, 8
	addmi	a8, a8, 0xc00
	add.n	a8, a7, a8
	s32i	a8, a4, 60
.L709:
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	movi.n	a8, 1
	xor	a10, a10, a8
	s8i	a10, a4, 25
	j	.L708
.L683:
	movi	a8, 0x6f0
	add.n	a8, a7, a8
	s32i	a8, a4, 44
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	movi.n	a8, 1
	movi.n	a11, -8
	xor	a10, a10, a8
	addmi	a11, a11, 0xc00
	s8i	a10, a4, 25
	movi.n	a12, 9
	add.n	a11, a7, a11
	addi	a10, a4, 48
	call8	memcpy
	j	.L708
.L684:
	movi	a8, 0x530
	add.n	a8, a7, a8
	s32i	a8, a4, 40
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	movi.n	a8, 1
	addmi	a9, a7, 0x500
	xor	a10, a10, a8
	l8ui	a9, a9, 64
	s8i	a10, a4, 25
	bnei	a9, 3, .L686
	addmi	a9, a7, 0x2300
	l8ui	a5, a9, 57
	xor	a5, a5, a8
	extui	a5, a5, 0, 8
.L686:
	addmi	a8, a7, 0x600
	s8i	a5, a4, 28
	l8ui	a9, a8, 185
	l32i	a8, a8, 188
	s8i	a9, a4, 29
	s32i	a8, a4, 32
.L708:
	addmi	a7, a7, 0x300
	l8ui	a8, a7, 10
	s8i	a8, a4, 76
	j	.L667
.L685:
	addi	a8, a7, 80
	s32i	a8, a4, 36
	l8ui	a8, a7, 101
	addi.n	a8, a8, -1
	nsau	a8, a8
	srli	a8, a8, 5
.L707:
	s8i	a8, a4, 25
	j	.L667
.L678:
	l32r	a10, .LC327
	addi	a11, a7, 32
	add.n	a10, a2, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	movi.n	a5, 1
	movi.n	a9, 0
	moveqz	a9, a5, a10
	s8i	a9, a4, 25
	mov.n	a3, a10
	beqz.n	a10, .L667
	l8ui	a9, a7, 66
	addi	a11, a10, 112
	s8i	a9, a4, 80
	movi.n	a12, 0x50
	addi	a10, a4, 88
	call8	memcpy
	l8ui	a9, a3, 105
	movi.n	a8, 0
	s8i	a9, a4, 232
	l8ui	a9, a3, 204
	s8i	a9, a4, 233
	l8ui	a9, a3, 206
	s8i	a9, a4, 234
	l8ui	a9, a4, 88
	addi.n	a9, a9, -1
	moveqz	a8, a5, a9
	movi	a9, 0xc0
	add.n	a9, a3, a9
	l32i	a11, a9, 0
	s8i	a8, a4, 168
	movi	a8, 0xac
	add.n	a8, a4, a8
	l32i	a10, a9, 4
	s32i	a11, a8, 0
	l32i	a9, a9, 8
	s32i	a10, a8, 4
	s32i	a9, a8, 8
	movi	a8, 0xcf
	add.n	a3, a3, a8
	l16ui	a8, a4, 114
	s32i	a3, a4, 196
	s32i	a8, a4, 200
	l8ui	a8, a7, 72
	beqz.n	a8, .L688
	s8i	a5, a4, 81
	l8ui	a8, a7, 72
	l32r	a11, .LC339
	addi.n	a8, a8, -1
	s8i	a8, a4, 82
	l32r	a8, .LC338
	movi	a10, 0xc8
	s32i	a8, a4, 84
	movi.n	a8, 8
	s32i	a8, a4, 192
	l8ui	a8, a7, 72
	movi.n	a12, 8
	addi.n	a8, a8, -1
	addx8	a11, a8, a11
	add.n	a10, a2, a10
	call8	memcpy
	j	.L689
.L688:
	l8ui	a8, a7, 66
	l8ui	a10, a7, 24
	beqz.n	a8, .L690
	movi	a13, 0xc8
	movi.n	a14, 8
	add.n	a13, a2, a13
	movi.n	a12, 0x10
	movi	a11, 0x130
	call8	_ZN14MotorControlRS6ESS_RS18buildReadRegistersEhttPhj
	j	.L691
.L690:
	movi	a11, 0xc8
	movi.n	a12, 8
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS10buildProbeEhPhj
.L691:
	s32i	a10, a4, 192
.L689:
	movi	a8, 0xc8
	add.n	a2, a2, a8
	l8ui	a8, a4, 168
	s32i	a2, a4, 188
	beqz.n	a8, .L692
	l8ui	a8, a7, 66
	l32i	a10, a4, 196
	l32i	a11, a4, 200
	l8ui	a12, a7, 24
	addi	a13, a4, 80
	beqz.n	a8, .L693
	movi.n	a8, 0
	s32i	a8, sp, 336
	movi	a8, 0x140
	addi	a13, a13, 104
	add.n	a8, a6, a8
	s32i	a13, sp, 4
	s32i	a8, sp, 0
	movi.n	a15, 0x10
	mov.n	a14, a6
	movi.n	a13, 0x10
	call8	_ZN14MotorControlRS6ESS_RS14parseRegistersEPKhjhtPtjRjPNS0_10FrameErrorE
	j	.L692
.L693:
	addi	a14, a13, 104
	addi	a13, a13, 106
	call8	_ZN14MotorControlRS6ESS_RS10parseProbeEPKhjhRtPNS0_10FrameErrorE
.L692:
	l8ui	a8, a4, 136
	l32i	a9, a4, 148
	s8i	a8, a4, 204
	l32i	a8, a4, 144
	s32i	a9, a4, 220
	s32i	a8, a4, 216
	l32i	a8, a4, 160
	l32i	a9, a4, 156
	s32i	a8, a4, 208
	l32i	a8, a4, 152
	s32i	a9, a4, 228
	s32i	a8, a4, 224
	l32i	a8, a4, 164
	l32i	a9, a4, 124
	s32i	a8, a4, 212
	l32i	a8, a4, 120
	s32i	a9, a4, 244
	s32i	a8, a4, 240
	l32i	a9, a4, 132
	l32i	a8, a4, 128
	s32i	a9, a4, 252
	s32i	a8, a4, 248
	l32i	a8, a7, 48
	l32i	a9, a7, 52
	s32i	a8, a4, 256
	s32i	a9, a4, 260
	j	.L667
.L671:
	retw.n
.LFE2309:
	.size	_ZN12_GLOBAL__N_16lookupEPvmRN21MotorControlRSExample5Probe10ResultViewE, .-_ZN12_GLOBAL__N_16lookupEPvmRN21MotorControlRSExample5Probe10ResultViewE
	.literal_position
	.literal .LC340, 771250
	.literal .LC341, 771808
	.literal .LC342, 772616
	.literal .LC343, 101000
	.literal .LC344, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_16actingERKNS_3AppE, @function
_ZN12_GLOBAL__N_16actingERKNS_3AppE:
.LFB2066:
	entry	sp, 32
.LCFI60:
	l32r	a8, .LC340
	mov.n	a7, a2
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L711
	l32r	a8, .LC341
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L711
.L713:
	movi.n	a2, 1
	j	.L712
.L711:
	l32r	a8, .LC342
	add.n	a8, a7, a8
	l8ui	a2, a8, 0
	bnez.n	a2, .L713
	l32r	a6, .LC343
	l32r	a5, .LC344
	movi.n	a4, 0x50
	add.n	a6, a7, a6
	add.n	a5, a7, a5
	addmi	a4, a4, 0x2300
	j	.L714
.L717:
	l8ui	a8, a6, 0
	addi	a8, a8, -3
	extui	a8, a8, 0, 8
	bltui	a8, 5, .L715
.L716:
	add.n	a6, a6, a4
	j	.L714
.L715:
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L716
	j	.L713
.L714:
	bne	a6, a5, .L717
.L712:
	retw.n
.LFE2066:
	.size	_ZN12_GLOBAL__N_16actingERKNS_3AppE, .-_ZN12_GLOBAL__N_16actingERKNS_3AppE
	.literal_position
	.literal .LC346, 774016
	.literal .LC347, 39500
	.literal .LC348, 41820
	.literal .LC349, 44140
	.literal .LC350, 820464
	.literal .LC352, 45698
	.literal .LC354, 53807
	.literal .LC355, 64920
	.literal .LC356, 626184
	.literal .LC357, 64907
	.literal .LC359, 64848
	.literal .LC360, 47848
	.literal .LC361, 770856
	.literal .LC362, 771168
	.literal .LC363, 771250
	.align	4
	.type	_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE, @function
_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE:
.LFB2266:
	entry	sp, 32
.LCFI61:
	l32r	a8, .LC346
	l32r	a9, .LC347
	add.n	a8, a2, a8
	add.n	a9, a8, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L722
.L724:
	movi.n	a2, 1
	j	.L723
.L722:
	l32r	a9, .LC348
	add.n	a9, a8, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L724
	l32r	a9, .LC349
	add.n	a8, a8, a9
	l8ui	a8, a8, 0
	bnez.n	a8, .L724
	l32r	a8, .LC350
	add.n	a8, a2, a8
	l8ui	a8, a8, 12
	bnez.n	a8, .L724
	movi	a8, 0x647
	slli	a8, a8, 9
	add.n	a8, a2, a8
	l8ui	a8, a8, 12
	bnez.n	a8, .L724
	l32r	a8, .LC352
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L724
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a9, a2, a8
	l8ui	a10, a9, 137
	bnez.n	a10, .L724
	l32i	a10, a9, 152
	l32i	a11, a9, 156
	or	a10, a10, a11
	bnez.n	a10, .L724
	l32r	a10, .LC354
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L724
	l32i	a9, a9, 52
	bnei	a9, -1, .L724
	add.n	a8, a2, a8
	l32i	a9, a8, 48
	bnez.n	a9, .L724
	l8ui	a8, a8, 60
	beqi	a8, 1, .L724
	l32r	a7, .LC355
	add.n	a7, a2, a7
	mov.n	a10, a7
	call8	_ZNK21MotorControlRSExample3Rtu6Runner4busyEv
	bnez.n	a10, .L724
	addmi	a7, a7, 0x100
	l8ui	a8, a7, 67
	bnez.n	a8, .L724
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L724
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L724
	l32r	a8, .LC356
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L724
	l32r	a8, .LC357
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L724
	movi	a8, 0x3f5
	slli	a8, a8, 6
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L724
	l32r	a8, .LC359
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L724
	l32r	a8, .LC360
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L724
	l32r	a8, .LC361
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L724
	l32r	a8, .LC362
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L724
	l32r	a8, .LC363
	add.n	a2, a2, a8
	l8ui	a2, a2, 0
.L723:
	retw.n
.LFE2266:
	.size	_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE, .-_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE
	.literal_position
	.literal .LC365, 53807
	.literal .LC366, 45698
	.literal .LC367, 45697
	.align	4
	.type	_ZN12_GLOBAL__N_117qualificationIdleERKNS_3AppE, @function
_ZN12_GLOBAL__N_117qualificationIdleERKNS_3AppE:
.LFB2358:
	entry	sp, 32
.LCFI62:
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a2, a8
	l32i	a9, a8, 52
	beqi	a9, -1, .L729
.L731:
	movi.n	a2, 0
	j	.L730
.L729:
	l32i	a9, a8, 48
	bnez.n	a9, .L731
	l8ui	a9, a8, 60
	beqi	a9, 1, .L731
	l8ui	a9, a8, 137
	bnez.n	a9, .L731
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	or	a9, a9, a8
	bnez.n	a9, .L731
	l32r	a8, .LC365
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L731
	l32r	a8, .LC366
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L731
	l32r	a8, .LC367
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L731
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L731
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L731
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	movi.n	a8, 1
	xor	a2, a10, a8
	extui	a2, a2, 0, 8
.L730:
	retw.n
.LFE2358:
	.size	_ZN12_GLOBAL__N_117qualificationIdleERKNS_3AppE, .-_ZN12_GLOBAL__N_117qualificationIdleERKNS_3AppE
	.literal_position
	.literal .LC368, 764504
	.literal .LC369, 764516
	.literal .LC370, 762568
	.literal .LC371, 762572
	.literal .LC372, 45698
	.literal .LC374, 53807
	.literal .LC375, 64920
	.literal .LC376, 626184
	.literal .LC377, 64907
	.literal .LC379, 64848
	.literal .LC380, 47848
	.literal .LC381, 770856
	.literal .LC382, 771168
	.literal .LC383, 764496
	.literal .LC384, 764788
	.literal .LC385, 50000
	.literal .LC386, 771840
	.literal .LC389, 772072
	.literal .LC390, 771952
	.literal .LC391, 625584
	.literal .LC392, 626448
	.align	4
	.type	_ZN12_GLOBAL__N_16wiringEPvPKN21MotorControlRSExample5Probe13WiringRequestERNS2_14WiringSnapshotE, @function
_ZN12_GLOBAL__N_16wiringEPvPKN21MotorControlRSExample5Probe13WiringRequestERNS2_14WiringSnapshotE:
.LFB2325:
	entry	sp, 176
.LCFI63:
	l32r	a10, .LC368
	mov.n	a6, a2
	add.n	a10, a6, a10
	l32i	a12, a10, 0
	l32i	a11, a10, 4
	s32i	a12, a4, 0
	l32i	a10, a10, 8
	l32r	a8, .LC369
	s32i	a11, a4, 4
	s32i	a10, a4, 8
	add.n	a10, a6, a8
	l32i	a10, a10, 0
	l32r	a12, .LC370
	s32i	a10, a4, 12
	addi	a8, a4, 16
	mov.n	a2, a4
	add.n	a4, a6, a12
	l8ui	a11, a4, 0
	l8ui	a10, a4, 1
	s8i	a11, a2, 16
	l8ui	a11, a4, 2
	s8i	a10, a8, 1
	l8ui	a10, a4, 3
	l32r	a7, .LC371
	s8i	a11, a8, 2
	s8i	a10, a8, 3
	add.n	a7, a6, a7
	l8ui	a11, a7, 0
	l8ui	a10, a7, 1
	s32i	a8, sp, 128
	s8i	a11, a2, 20
	addi	a8, a2, 20
	s32i	a8, sp, 132
	s8i	a10, a8, 1
	beqz.n	a3, .L736
	l8ui	a13, a3, 0
	movi.n	a15, 8
	bgeui	a13, 6, .L737
	l8ui	a11, a3, 1
	bgeui	a11, 3, .L737
	add.n	a10, a6, a13
	add.n	a10, a10, a12
	l8ui	a10, a10, 0
	add.n	a5, a13, a12
	add.n	a5, a6, a5
	beq	a11, a10, .L736
	l32r	a10, .LC372
	add.n	a10, a6, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L740
.L741:
	movi.n	a15, 1
	j	.L737
.L740:
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a6, a10
	l8ui	a11, a10, 137
	bnez.n	a11, .L741
	l32i	a11, a10, 152
	l32i	a12, a10, 156
	or	a11, a11, a12
	bnez.n	a11, .L741
	l32r	a11, .LC374
	add.n	a11, a6, a11
	l8ui	a11, a11, 0
	bnez.n	a11, .L741
	l32i	a11, a10, 52
	bnei	a11, -1, .L741
	l32i	a11, a10, 48
	bnez.n	a11, .L741
	l8ui	a10, a10, 60
	beqi	a10, 1, .L741
	l32r	a11, .LC375
	add.n	a11, a6, a11
	mov.n	a10, a11
	s32i	a11, sp, 136
	call8	_ZNK21MotorControlRSExample3Rtu6Runner4busyEv
	bnez.n	a10, .L741
	l32i	a11, sp, 136
	addmi	a11, a11, 0x100
	l8ui	a10, a11, 67
	bnez.n	a10, .L741
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L741
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L741
	l32r	a10, .LC376
	add.n	a10, a6, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L741
	l32r	a10, .LC377
	add.n	a10, a6, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L741
	movi	a10, 0x3f5
	slli	a10, a10, 6
	add.n	a10, a6, a10
	l32i	a10, a10, 0
	bnez.n	a10, .L741
	l32r	a10, .LC379
	add.n	a10, a6, a10
	l32i	a10, a10, 0
	bnez.n	a10, .L741
	l32r	a10, .LC380
	add.n	a10, a6, a10
	l32i	a10, a10, 0
	bnez.n	a10, .L741
	l32r	a10, .LC381
	add.n	a10, a6, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L741
	l32r	a10, .LC382
	add.n	a10, a6, a10
	l32i	a10, a10, 0
	bnez.n	a10, .L741
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L741
	l32r	a8, .LC369
	movi.n	a11, -3
	add.n	a10, a6, a8
	l32i	a10, a10, 0
	movi.n	a15, 7
	addi.n	a10, a10, -1
	bltu	a11, a10, .L737
	l8ui	a10, a3, 1
	movi.n	a13, 0
	s8i	a10, a5, 0
	movi.n	a12, 0
	movi.n	a11, 0
	mov.n	a10, a6
	s32i	a15, sp, 136
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	l32r	a10, .LC383
	movi.n	a11, 0
	add.n	a10, a6, a10
	s8i	a11, a10, 0
	l32r	a10, .LC384
	movi.n	a12, 0x48
	add.n	a10, a6, a10
	s8i	a11, a10, 0
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi	a10, 0x7d0
	s16i	a10, sp, 16
	l32r	a10, .LC385
	movi.n	a12, 0x48
	s32i	a10, sp, 20
	movi	a10, 0x64
	s16i	a10, sp, 24
	l32r	a10, .LC386
	mov.n	a11, sp
	add.n	a10, a6, a10
	call8	memcpy
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi.n	a10, 0x48
	addmi	a10, a10, -0xc00
	s16i	a10, sp, 26
	movi	a10, 0xb8
	addmi	a10, a10, 0xb00
	s16i	a10, sp, 28
	l32r	a10, .LC389
	movi.n	a12, 0x38
	mov.n	a11, sp
	add.n	a10, a6, a10
	call8	memcpy
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi.n	a10, 0x23
	l32i	a15, sp, 136
	s16i	a10, sp, 20
	l32r	a10, .LC390
	s16i	a15, sp, 30
	movi	a12, 0x78
	mov.n	a11, sp
	add.n	a10, a6, a10
	call8	memcpy
	l32r	a5, .LC391
	l32r	a3, .LC392
	add.n	a5, a6, a5
	add.n	a3, a6, a3
	j	.L745
.L746:
	call8	_Z18esp_timer_get_timev
	movi	a12, 0x120
	s32i	a10, a5, 0
	s32i	a11, a5, 4
	add.n	a5, a5, a12
.L745:
	bne	a3, a5, .L746
	l32r	a8, .LC369
	l32i	a9, sp, 128
	add.n	a8, a6, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 12
	l8ui	a10, a4, 0
	l8ui	a8, a4, 1
	s8i	a10, a2, 16
	l8ui	a10, a4, 2
	s8i	a8, a9, 1
	l8ui	a8, a4, 3
	s8i	a10, a9, 2
	s8i	a8, a9, 3
	l8ui	a10, a7, 0
	l8ui	a8, a7, 1
	l32i	a9, sp, 132
	s8i	a10, a2, 20
	s8i	a8, a9, 1
.L736:
	movi.n	a15, 0
.L737:
	mov.n	a2, a15
	retw.n
.LFE2325:
	.size	_ZN12_GLOBAL__N_16wiringEPvPKN21MotorControlRSExample5Probe13WiringRequestERNS2_14WiringSnapshotE, .-_ZN12_GLOBAL__N_16wiringEPvPKN21MotorControlRSExample5Probe13WiringRequestERNS2_14WiringSnapshotE
	.section	.rodata
	.align	8
.LC7:
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	1
	.word	0
	.word	1
	.byte	0
	.zero	3
	.word	0
	.word	1
	.byte	0
	.zero	3
	.word	0
	.word	1
	.byte	0
	.zero	3
	.word	0
	.word	1
	.byte	0
	.zero	3
	.word	0
	.word	1
	.byte	0
	.zero	3
	.byte	0
	.zero	3
	.word	0
	.byte	1
	.zero	3
	.byte	1
	.zero	7
	.word	-1598689907
	.word	1051772663
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.zero	2
	.word	0
	.word	-2147483648
	.word	-1
	.word	2147483647
	.byte	0
	.byte	0
	.zero	6
	.word	0
	.word	0
	.byte	0
	.byte	0
	.zero	6
	.word	0
	.word	0
	.byte	0
	.byte	0
	.zero	6
	.word	0
	.word	0
	.word	0
	.word	0
	.text
	.literal_position
	.literal .LC393, 764508
	.literal .LC394, 45698
	.literal .LC396, 53807
	.literal .LC397, 64920
	.literal .LC398, 626184
	.literal .LC399, 64907
	.literal .LC401, 64848
	.literal .LC402, 47848
	.literal .LC403, 770856
	.literal .LC404, 770860
	.literal .LC405, 764516
	.literal .LC406, 772456
	.literal .LC407, .LC7
	.literal .LC408, 764608
	.literal .LC409, 764504
	.literal .LC410, 771384
	.literal .LC411, 771368
	.literal .LC413, 771376
	.literal .LC415, 764696
	.literal .LC416, 764688
	.literal .LC417, 764788
	.literal .LC418, 50000
	.literal .LC419, 771840
	.literal .LC422, 772072
	.literal .LC423, 771952
	.literal .LC424, 64900
	.literal .LC426, 64909
	.literal .LC427, 762568
	.literal .LC428, 762569
	.literal .LC429, 762570
	.literal .LC430, 762571
	.literal .LC431, 762572
	.literal .LC432, 762573
	.align	4
	.type	_ZN12_GLOBAL__N_112selectTargetEPvh, @function
_ZN12_GLOBAL__N_112selectTargetEPvh:
.LFB2324:
	entry	sp, 352
.LCFI64:
	extui	a3, a3, 0, 8
	mov.n	a10, a3
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	mov.n	a7, a2
	movi.n	a2, 8
	beqz.n	a10, .L757
	l32r	a8, .LC393
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beq	a8, a3, .L758
	l32r	a8, .LC394
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L759
.L760:
	movi.n	a2, 1
	j	.L757
.L759:
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a7, a8
	l8ui	a9, a8, 137
	bnez.n	a9, .L760
	l32i	a9, a8, 152
	l32i	a10, a8, 156
	or	a9, a9, a10
	bnez.n	a9, .L760
	l32r	a9, .LC396
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L760
	l32i	a9, a8, 52
	bnei	a9, -1, .L760
	l32i	a9, a8, 48
	bnez.n	a9, .L760
	l8ui	a8, a8, 60
	beqi	a8, 1, .L760
	l32r	a6, .LC397
	add.n	a10, a7, a6
	call8	_ZNK21MotorControlRSExample3Rtu6Runner4busyEv
	bnez.n	a10, .L760
	add.n	a6, a7, a6
	addmi	a6, a6, 0x100
	l8ui	a8, a6, 67
	bnez.n	a8, .L760
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L760
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L760
	l32r	a8, .LC398
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L760
	l32r	a8, .LC399
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L760
	movi	a8, 0x3f5
	slli	a8, a8, 6
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L760
	l32r	a8, .LC401
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L760
	l32r	a8, .LC402
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L760
	l32r	a8, .LC403
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L760
	l32r	a8, .LC404
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L760
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	mov.n	a6, a10
	bnez.n	a10, .L760
	l32r	a8, .LC405
	movi.n	a9, -3
	add.n	a8, a7, a8
	l32i	a4, a8, 0
	movi.n	a2, 7
	addi.n	a8, a4, -1
	bltu	a9, a8, .L757
	l32r	a8, .LC406
	add.n	a8, a7, a8
	l32i	a5, a8, 0
	s32i	a8, sp, 304
	beqi	a5, -1, .L757
	l32r	a11, .LC407
	movi	a12, 0xb8
	mov.n	a10, sp
	call8	memcpy
	l32r	a9, .LC408
	l32i	a8, sp, 304
	add.n	a9, a7, a9
	l32i	a10, a9, 0
	addi.n	a5, a5, 1
	s32i	a10, sp, 104
	l32r	a10, .LC409
	l16ui	a9, a9, 4
	s32i	a5, sp, 8
	s32i	a5, a8, 0
	movi	a12, 0xb8
	movi.n	a5, 1
	mov.n	a11, sp
	addi.n	a4, a4, 1
	add.n	a10, a7, a10
	s16i	a9, sp, 108
	s8i	a5, sp, 128
	s32i	a3, sp, 0
	s8i	a3, sp, 4
	s32i	a4, sp, 12
	call8	memcpy
	l32r	a8, .LC410
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	l32r	a8, .LC411
	l32r	a10, .LC415
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC413
	movi.n	a9, 1
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	movi.n	a9, 0
	s32i	a9, a8, 4
	movi.n	a12, 0x40
	movi.n	a11, 0
	add.n	a10, a7, a10
	call8	memset
	l32r	a8, .LC416
	movi.n	a12, 0x48
	add.n	a8, a7, a8
	s8i	a5, a8, 0
	l32r	a8, .LC417
	movi	a5, 0xb8
	add.n	a5, sp, a5
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi	a8, 0x7d0
	s16i	a8, sp, 200
	l32r	a8, .LC418
	l32r	a10, .LC419
	s32i	a8, sp, 204
	movi	a8, 0x64
	s16i	a8, sp, 208
	movi.n	a12, 0x48
	mov.n	a11, a5
	add.n	a10, a7, a10
	call8	memcpy
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a8, 0x48
	addmi	a8, a8, -0xc00
	l32r	a10, .LC422
	s16i	a8, sp, 210
	movi	a8, 0xb8
	addmi	a8, a8, 0xb00
	s16i	a8, sp, 212
	movi.n	a12, 0x38
	mov.n	a11, a5
	add.n	a10, a7, a10
	call8	memcpy
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	l32r	a10, .LC423
	movi.n	a8, 0x23
	movi	a12, 0x78
	s16i	a8, sp, 204
	mov.n	a11, a5
	s16i	a2, sp, 214
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a8, .LC424
	add.n	a8, a7, a8
	s32i	a6, a8, 0
	movi	a8, 0xbb
	slli	a8, a8, 8
	add.n	a8, a7, a8
	s32i	a6, a8, 0
	l32r	a8, .LC426
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	l32r	a8, .LC427
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	l32r	a8, .LC428
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	l32r	a8, .LC429
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	l32r	a8, .LC430
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	l32r	a8, .LC431
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	l32r	a8, .LC432
	add.n	a8, a7, a8
	s8i	a6, a8, 0
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy
.L758:
	movi.n	a2, 0
.L757:
	retw.n
.LFE2324:
	.size	_ZN12_GLOBAL__N_112selectTargetEPvh, .-_ZN12_GLOBAL__N_112selectTargetEPvh
	.section	.rodata
	.align	2
.LC10:
	.short	16
	.short	17
	.short	25
	.short	24
	.short	23
	.short	81
	.short	80
	.short	64
	.short	65
	.short	66
	.short	67
	.short	68
	.short	75
	.short	76
	.short	77
	.short	79
	.text
	.literal_position
	.literal .LC433, .LC10
	.align	4
	.type	_ZN12_GLOBAL__N_119changedDriverWindowERKN14MotorControlRS6ESS_RS17DriverObservationEtPKtj, @function
_ZN12_GLOBAL__N_119changedDriverWindowERKN14MotorControlRS6ESS_RS17DriverObservationEtPKtj:
.LFB2208:
	entry	sp, 112
.LCFI65:
	l8ui	a6, a2, 0
	s32i	a4, sp, 52
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	l32r	a11, .LC433
	s32i	a10, sp, 48
	movi.n	a12, 0x20
	mov.n	a10, sp
	mov.n	a7, a2
	call8	memcpy
	bnei	a6, 1, .L801
	j	.L774
.L797:
	movi.n	a2, 0
.L787:
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS16tuningFieldCountENS0_11DriverGroupE
	mov.n	a4, a10
	j	.L776
.L802:
	movi.n	a2, 0
	movi.n	a4, 7
	bnei	a6, 5, .L776
	movi.n	a4, 8
.L776:
	mov.n	a8, a2
	movi.n	a2, 0
	j	.L777
.L782:
	movi.n	a9, 6
	s16i	a9, sp, 32
	movi.n	a9, 0
	s16i	a9, sp, 34
	s16i	a9, sp, 36
	s16i	a9, sp, 38
	s8i	a9, sp, 40
	l32i	a9, sp, 48
	add.n	a14, a8, a8
	beqz.n	a9, .L778
	mov.n	a11, a8
	mov.n	a10, a6
	s32i	a14, sp, 60
	s32i	a8, sp, 56
	call8	_ZN14MotorControlRS6ESS_RS15tuningParameterENS0_11DriverGroupEh
	addi	a11, sp, 32
	call8	_ZN14MotorControlRS6ESS_RS19tuningParameterInfoENS0_15TuningParameterERNS0_19TuningParameterInfoE
	l32i	a8, sp, 56
	l32i	a14, sp, 60
	movi.n	a9, 0
	beqz.n	a10, .L779
	l16ui	a9, sp, 34
	j	.L779
.L778:
	addmi	a9, a8, 0x100
	extui	a9, a9, 0, 16
	beqi	a6, 5, .L779
.L780:
	add.n	a9, sp, a14
	l16ui	a9, a9, 0
.L779:
	add.n	a14, a7, a14
	l16ui	a14, a14, 24
	mov.n	a10, a8
	mov.n	a11, a6
	s32i	a9, sp, 64
	s32i	a8, sp, 56
	s32i	a14, sp, 60
	call8	_ZN14MotorControlRS6ESS_RS13driverFieldAtEhNS0_11DriverGroupE
	l32i	a9, sp, 64
	l32i	a8, sp, 56
	bltu	a9, a3, .L792
	sub	a9, a9, a3
	bgeu	a9, a5, .L792
	l32i	a11, sp, 52
	l32i	a14, sp, 60
	addx2	a9, a9, a11
	l16ui	a9, a9, 0
	bne	a9, a14, .L781
.L792:
	movi.n	a10, 0
.L781:
	or	a2, a2, a10
	addi.n	a8, a8, 1
.L777:
	extui	a9, a8, 0, 8
	bltu	a9, a4, .L782
	bnez.n	a6, .L773
	l32i	a9, sp, 52
	addi	a8, a3, -55
	neg	a8, a8
	addx2	a8, a8, a9
	addi	a9, a3, -57
	addi	a7, a7, 64
	neg	a9, a9
	movi.n	a11, 0x37
	movi.n	a15, 0x39
.L786:
	movi.n	a12, 0
	bltu	a11, a3, .L784
	addi	a10, a9, -2
	bgeu	a10, a5, .L784
	l16ui	a12, a8, 0
	l16ui	a10, a7, 0
	sub	a10, a10, a12
	movi.n	a12, 1
	moveqz	a12, a10, a10
	slli	a12, a12, 7
.L784:
	addi.n	a14, a11, 2
	movi.n	a10, 0
	bltu	a14, a3, .L785
	bgeu	a9, a5, .L785
	l16ui	a10, a8, 4
	l16ui	a14, a7, 4
	sub	a14, a14, a10
	movi.n	a10, 1
	moveqz	a10, a14, a14
	slli	a10, a10, 8
.L785:
	or	a10, a10, a12
	or	a2, a2, a10
	addi.n	a10, a11, 1
	addi.n	a7, a7, 2
	addi.n	a8, a8, 2
	addi.n	a9, a9, 1
	movi.n	a11, 0x38
	bne	a10, a15, .L786
	j	.L773
.L801:
	l32i	a8, sp, 48
	beqz.n	a8, .L802
	j	.L797
.L774:
	l32i	a8, sp, 48
	movi.n	a2, 7
	movi.n	a4, 0x10
	beqz.n	a8, .L776
	j	.L787
.L773:
	retw.n
.LFE2208:
	.size	_ZN12_GLOBAL__N_119changedDriverWindowERKN14MotorControlRS6ESS_RS17DriverObservationEtPKtj, .-_ZN12_GLOBAL__N_119changedDriverWindowERKN14MotorControlRS6ESS_RS17DriverObservationEtPKtj
	.section	.rodata.str1.1
.LC435:
	.string	"none"
	.text
	.literal_position
	.literal .LC436, .LC435
	.align	4
	.type	_ZN12_GLOBAL__N_13App18MotionProfileStateC2Ev, @function
_ZN12_GLOBAL__N_13App18MotionProfileStateC2Ev:
.LFB2006:
	entry	sp, 32
.LCFI66:
	movi.n	a7, 0
	movi.n	a4, 0
	movi.n	a5, 0
	movi.n	a8, 0
	s8i	a8, a2, 6
	movi.n	a12, 0xc
	movi.n	a11, 0
	s32i	a7, a2, 0
	s16i	a7, a2, 4
	s32i	a7, a2, 8
	s32i	a7, a2, 12
	s32i	a7, a2, 16
	s32i	a7, a2, 20
	s32i	a7, a2, 24
	s32i	a4, a2, 32
	s32i	a5, a2, 36
	addi	a10, a2, 40
	call8	memset
	movi.n	a12, 0xc
	movi.n	a11, 0
	addi	a10, a2, 52
	call8	memset
	movi.n	a12, 0x13
	movi.n	a11, 0
	addi	a10, a2, 64
	call8	memset
	movi.n	a12, 0x40
	movi.n	a11, 0
	addi	a10, a2, 83
	call8	memset
	movi	a10, 0x93
	movi.n	a12, 8
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	movi	a10, 0x9b
	movi.n	a12, 0x13
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a8, .LC436
	s32i	a7, a2, 176
	s32i	a8, a2, 272
	s32i	a7, a2, 180
	s32i	a7, a2, 184
	s32i	a7, a2, 188
	s32i	a4, a2, 192
	s32i	a5, a2, 196
	s32i	a4, a2, 200
	s32i	a5, a2, 204
	s32i	a4, a2, 208
	s32i	a5, a2, 212
	s32i	a4, a2, 216
	s32i	a5, a2, 220
	s32i	a4, a2, 224
	s32i	a5, a2, 228
	s32i	a4, a2, 232
	s32i	a5, a2, 236
	s32i	a4, a2, 240
	s32i	a5, a2, 244
	s32i	a4, a2, 248
	s32i	a5, a2, 252
	s32i	a4, a2, 256
	s32i	a5, a2, 260
	s32i	a7, a2, 264
	s16i	a7, a2, 268
	addmi	a6, a2, 0x100
	s16i	a7, a2, 280
	s16i	a7, a2, 282
	s16i	a7, a2, 284
	s16i	a7, a2, 286
	s16i	a7, a2, 288
	s16i	a7, a2, 290
	s16i	a7, a2, 292
	movi.n	a12, 8
	s16i	a7, a2, 294
	s16i	a7, a2, 296
	movi.n	a11, 0
	addi	a10, a6, 42
	call8	memset
	s16i	a7, a2, 306
	s16i	a7, a2, 308
	s32i	a7, a2, 312
	s32i	a7, a2, 316
	s32i	a4, a2, 320
	s32i	a5, a2, 324
	s32i	a7, a2, 328
	retw.n
.LFE2006:
	.size	_ZN12_GLOBAL__N_13App18MotionProfileStateC2Ev, .-_ZN12_GLOBAL__N_13App18MotionProfileStateC2Ev
	.set	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev,_ZN12_GLOBAL__N_13App18MotionProfileStateC2Ev
	.section	.text._ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_,"axG",@progbits,_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	.type	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_, @function
_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_:
.LFB22:
	entry	sp, 32
.LCFI67:
	l32i	a10, a2, 0
	l32i	a9, a3, 0
	mov.n	a8, a2
	movi.n	a2, 0
	bne	a10, a9, .L811
	l8ui	a2, a8, 4
	l8ui	a8, a3, 4
	sub	a2, a2, a8
	nsau	a2, a2
	srli	a2, a2, 5
.L811:
	retw.n
.LFE22:
	.size	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_, .-_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	.text
	.literal_position
	.literal .LC437, 772460
	.literal .LC438, 764508
	.literal .LC439, 45688
	.align	4
	.type	_ZN12_GLOBAL__N_121failedTransmittedStopERNS_3AppEm, @function
_ZN12_GLOBAL__N_121failedTransmittedStopERNS_3AppEm:
.LFB2127:
	entry	sp, 32
.LCFI68:
	mov.n	a10, a2
	mov.n	a11, a3
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a2
	movi.n	a2, 0
	beqz.n	a10, .L814
	l8ui	a8, a10, 0
	bnei	a8, 3, .L814
	addmi	a8, a10, 0x2300
	l8ui	a2, a8, 57
	bnez.n	a2, .L817
	addmi	a8, a10, 0x500
	l8ui	a9, a8, 64
	bnei	a9, 3, .L814
	l8ui	a9, a8, 100
	bnei	a9, 3, .L814
	l8ui	a9, a8, 102
	movi	a11, 0xfd
	and	a9, a9, a11
	bnei	a9, 1, .L814
	l8ui	a9, a8, 103
	bnez.n	a9, .L814
	l8ui	a11, a10, 24
	l32r	a12, .LC437
	srli	a9, a11, 3
	add.n	a9, a7, a9
	add.n	a9, a9, a12
	l8ui	a12, a9, 0
	extui	a9, a11, 0, 3
	bbc	a12, a9, .L814
	l32i	a8, a8, 192
	beqz.n	a8, .L814
	l32r	a8, .LC438
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bne	a8, a11, .L814
	l32r	a11, .LC439
	addi.n	a10, a10, 12
	add.n	a11, a7, a11
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	mov.n	a2, a10
	j	.L814
.L817:
	movi.n	a2, 0
.L814:
	retw.n
.LFE2127:
	.size	_ZN12_GLOBAL__N_121failedTransmittedStopERNS_3AppEm, .-_ZN12_GLOBAL__N_121failedTransmittedStopERNS_3AppEm
	.literal_position
	.literal .LC440, 101032
	.literal .LC441, 625352
	.align	4
	.type	_ZN12_GLOBAL__N_121cancelInvalidReleasesERNS_3AppEy, @function
_ZN12_GLOBAL__N_121cancelInvalidReleasesERNS_3AppEy:
.LFB2226:
	entry	sp, 48
.LCFI69:
	l32r	a8, .LC440
	l32r	a3, .LC441
	movi	a7, 0x7f7
	slli	a7, a7, 5
	s32i	a5, sp, 0
	add.n	a3, a2, a3
	add.n	a5, a2, a8
	add.n	a7, a2, a7
	j	.L826
.L834:
	movi	a6, 0x6a0
	add.n	a6, a5, a6
	l32i	a9, a6, 0
	beqz.n	a9, .L828
	addi	a11, a5, -32
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L828
	movi	a9, 0x568
	add.n	a9, a5, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L828
	l32i	a9, a5, 0
	bnez.n	a9, .L830
.L833:
	movi	a11, 0x6a8
	l32i	a13, sp, 0
	mov.n	a12, a4
	add.n	a11, a5, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_117releaseFactsValidERKNS_3AppERKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesEy
	bnez.n	a10, .L831
	j	.L832
.L830:
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L833
	j	.L828
.L831:
	l32i	a11, a6, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_121failedTransmittedStopERNS_3AppEm
	bnez.n	a10, .L828
.L832:
	movi.n	a9, 1
	s8i	a9, a5, 39
	l32i	a9, a5, 0
	beqz.n	a9, .L828
	l32i	a13, sp, 0
	mov.n	a12, a4
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L828:
	movi.n	a9, 0x50
	addmi	a9, a9, 0x2300
	add.n	a5, a5, a9
.L826:
	bne	a5, a3, .L834
	retw.n
.LFE2226:
	.size	_ZN12_GLOBAL__N_121cancelInvalidReleasesERNS_3AppEy, .-_ZN12_GLOBAL__N_121cancelInvalidReleasesERNS_3AppEy
	.section	.text._ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE,"axG",@progbits,_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	.type	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE, @function
_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE:
.LFB25:
	entry	sp, 32
.LCFI70:
	l8ui	a9, a2, 4
	mov.n	a8, a2
	movi.n	a2, 0
	bgeui	a9, 4, .L839
	l32i	a9, a8, 0
	movi.n	a10, 0x4b
	slli	a10, a10, 7
	movi.n	a8, 1
	sub	a10, a9, a10
	mov.n	a11, a2
	moveqz	a11, a8, a10
	addmi	a12, a9, -0x4b00
	mov.n	a10, a2
	moveqz	a10, a8, a12
	movi.n	a12, 0x4b
	slli	a12, a12, 9
	or	a11, a11, a10
	sub	a12, a9, a12
	mov.n	a10, a2
	moveqz	a10, a8, a12
	or	a10, a10, a11
	movi	a11, 0xe1
	slli	a11, a11, 9
	sub	a9, a9, a11
	movnez	a8, a2, a9
	or	a2, a8, a10
.L839:
	retw.n
.LFE25:
	.size	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE, .-_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	.section	.rodata
	.align	4
.LC3:
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	20
	.word	0
	.word	200000
	.word	500000
	.word	500000
	.section	.text._ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE,"axG",@progbits,_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE,comdat
	.literal_position
	.literal .LC448, .LC3
	.literal .LC449, 100000000
	.literal .LC450, 100000
	.align	4
	.weak	_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE
	.type	_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE, @function
_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE:
.LFB26:
	entry	sp, 112
.LCFI71:
	mov.n	a10, a2
	mov.n	a4, a2
	s32i	a3, sp, 64
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	bnez.n	a10, .L842
.L845:
	movi.n	a2, 0
	j	.L843
.L842:
	l32r	a11, .LC448
	movi.n	a12, 0x3c
	mov.n	a10, sp
	call8	memcpy
	l8ui	a8, a2, 4
	movi.n	a7, 0xa
	beqz.n	a8, .L844
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 8
	movi.n	a7, 0
	bgeui	a8, 3, .L844
	movi.n	a7, 0xb
.L844:
	l32i	a6, a4, 0
	mov.n	a12, sp
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample3Rtu12setRtuTimingEmhRNS0_6TimingE
	mov.n	a2, a10
	beqz.n	a10, .L845
	l32r	a3, .LC449
	movi	a12, 0x66
	mull	a9, a7, a3
	muluh	a7, a7, a3
	muluh	a13, a12, a6
	mull	a12, a12, a6
	mov.n	a10, a9
	s32i	a9, sp, 68
	mov.n	a11, a7
	call8	__udivdi3
	movi	a13, 0x62
	mull	a12, a13, a6
	muluh	a13, a13, a6
	l32i	a9, sp, 68
	addi.n	a5, a13, -1
	addi.n	a8, a12, -1
	s32i	a10, sp, 28
	movnez	a5, a13, a12
	add.n	a10, a9, a8
	add.n	a11, a7, a5
	bgeu	a10, a8, .L847
	addi.n	a11, a11, 1
.L847:
	s32i	a8, sp, 76
	s32i	a12, sp, 72
	s32i	a13, sp, 68
	call8	__udivdi3
	l8ui	a4, a4, 4
	s32i	a10, sp, 32
	l32i	a13, sp, 68
	l32i	a12, sp, 72
	l32i	a8, sp, 76
	mov.n	a7, a10
	movi.n	a9, 1
	bnei	a4, 1, .L848
	movi.n	a9, 2
.L848:
	mull	a9, a9, a3
	mov.n	a11, a5
	add.n	a10, a9, a8
	bgeu	a10, a9, .L849
	addi.n	a11, a5, 1
.L849:
	call8	__udivdi3
	movi.n	a8, 0x14
	s32i	a8, sp, 12
	s32i	a8, sp, 8
	l32r	a8, .LC450
	slli	a7, a7, 5
	s32i	a8, sp, 16
	movi.n	a8, 0x10
	addmi	a8, a8, 0x2700
	s32i	a8, sp, 24
	movi.n	a8, 0x38
	addmi	a8, a8, 0x2700
	add.n	a7, a7, a8
	movi.n	a8, 0x20
	addmi	a8, a8, 0x4e00
	addi.n	a10, a10, 2
	maxu	a7, a7, a8
	movi.n	a9, 1
	s32i	a10, sp, 36
	s32i	a7, sp, 20
	moveqz	a9, a4, a4
	bnez.n	a4, .L856
	movi	a8, 0xe1
	slli	a8, a8, 9
	sub	a6, a6, a8
	movi.n	a8, 1
	moveqz	a8, a9, a6
	movi	a9, 0x130
	beqz.n	a8, .L850
.L856:
	l32i	a9, sp, 4
.L850:
	l32i	a10, sp, 64
	movi.n	a12, 0x3c
	mov.n	a11, sp
	s32i	a9, sp, 44
	call8	memcpy
.L843:
	retw.n
.LFE26:
	.size	_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE, .-_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE
	.section	.text._ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv,"axG",@progbits,_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv,comdat
	.align	4
	.weak	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	.type	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv, @function
_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv:
.LFB36:
	entry	sp, 112
.LCFI72:
	mov.n	a11, a2
	mov.n	a10, sp
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart5statsEv
	l8ui	a2, sp, 65
	retw.n
.LFE36:
	.size	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv, .-_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	.section	.text._ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv,"axG",@progbits,_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv,comdat
	.align	4
	.weak	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	.type	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv, @function
_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv:
.LFB54:
	entry	sp, 32
.LCFI73:
	l8ui	a9, a2, 60
	mov.n	a8, a2
	movi.n	a2, 1
	beqi	a9, 1, .L864
	l32i	a9, a8, 0
	l8ui	a9, a9, 192
	beqi	a9, 7, .L864
	l32i	a11, a8, 52
	movi.n	a2, 0
	beqi	a11, -1, .L864
	l32i	a9, a8, 64
	l32i	a10, a8, 68
	or	a9, a9, a10
	beqz.n	a9, .L864
	l32i	a9, a8, 96
	bne	a9, a8, .L864
	l32i	a8, a9, 100
	bne	a11, a8, .L864
	slli	a8, a11, 4
	l32i	a10, a9, 12
	sub	a8, a8, a11
	slli	a8, a8, 5
	add.n	a8, a10, a8
	l32i	a2, a8, 8
	l32i	a10, a9, 104
	l32i	a8, a8, 12
	l32i	a9, a9, 108
	xor	a2, a2, a10
	xor	a8, a8, a9
	or	a2, a2, a8
	nsau	a2, a2
	srli	a2, a2, 5
.L864:
	retw.n
.LFE54:
	.size	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv, .-_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	.text
	.literal_position
	.literal .LC455, 53807
	.literal .LC456, 772456
	.literal .LC457, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC458, 45697
	.literal .LC459, 45698
	.literal .LC461, _ZN12_GLOBAL__N_14uartE
	.literal .LC462, 772492
	.align	4
	.type	_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE, @function
_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE:
.LFB2137:
	entry	sp, 32
.LCFI74:
	l32r	a8, .LC455
	mov.n	a7, a2
	add.n	a8, a2, a8
	l8ui	a6, a8, 0
	movi.n	a2, 1
	bnez.n	a6, .L877
	l8ui	a10, a3, 54
	movi.n	a2, 8
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	beqz.n	a10, .L877
	l8ui	a9, a3, 55
	movi.n	a8, 1
	addi	a11, a9, -6
	mov.n	a10, a6
	movnez	a10, a8, a11
	beqz.n	a10, .L889
	addi	a9, a9, -16
	moveqz	a8, a6, a9
	bnez.n	a8, .L877
.L889:
	l8ui	a8, a3, 54
	l32i	a9, a3, 40
	movi.n	a2, 8
	bne	a9, a8, .L877
	l32r	a8, .LC456
	l32i	a9, a3, 44
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L877
	l32r	a8, .LC457
	l8ui	a8, a8, 0
	bnez.n	a8, .L879
.L882:
	movi.n	a2, 3
	j	.L877
.L879:
	l32r	a8, .LC458
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L880
.L881:
	movi.n	a2, 2
	j	.L877
.L880:
	l32r	a8, .LC459
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L881
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a7, a10
	l8ui	a8, a10, 137
	bnez.n	a8, .L881
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L881
	l32r	a10, .LC461
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	mov.n	a6, a10
	bnez.n	a10, .L881
	l8ui	a11, a3, 54
	l32r	a9, .LC462
	srli	a8, a11, 3
	add.n	a8, a7, a8
	add.n	a8, a8, a9
	l8ui	a9, a8, 0
	extui	a8, a11, 0, 3
	bbc	a9, a8, .L882
	movi.n	a12, 1
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a2, 0xc
	moveqz	a2, a6, a10
.L877:
	retw.n
.LFE2137:
	.size	_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE, .-_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE
	.literal_position
	.literal .LC463, 45756
	.literal .LC464, 45752
	.align	4
	.type	_ZN12_GLOBAL__N_113admitHomeStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedHomeEy, @function
_ZN12_GLOBAL__N_113admitHomeStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedHomeEy:
.LFB2160:
	entry	sp, 144
.LCFI75:
	movi	a12, 0x60
	movi.n	a11, 0
	addi.n	a10, sp, 8
	call8	memset
	addi	a8, a4, 22
	s32i	a8, sp, 0
	l32i	a8, a4, 44
	s32i	a8, sp, 4
	l8ui	a8, a4, 54
	mov.n	a5, a2
	movi.n	a10, 8
	bnez.n	a8, .L899
	l16ui	a10, a4, 50
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L899:
	l32r	a8, .LC463
	l32i	a9, a4, 60
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 12
	l32r	a8, .LC464
	l32i	a9, a4, 48
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 8
	s32i	a8, sp, 16
	l32i	a8, a4, 56
	s32i	a9, sp, 48
	s32i	a8, sp, 24
	l8ui	a8, a4, 8
	s8i	a8, sp, 54
	l8ui	a8, a4, 21
	s8i	a8, sp, 55
	l32i	a8, a4, 4
	s32i	a8, sp, 40
	l32i	a8, a4, 12
	s32i	a8, sp, 44
	l16ui	a8, a4, 52
	s16i	a8, sp, 52
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32i	a8, a3, 4
	s32i	a10, sp, 56
	s32i	a11, sp, 60
	beqz.n	a8, .L900
.L902:
	movi	a10, 0x7f7
	slli	a10, a10, 5
	addi	a14, a3, 32
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	add.n	a10, a5, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
	j	.L901
.L900:
	mov.n	a11, sp
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE
	mov.n	a2, a10
	beqz.n	a10, .L902
.L901:
	retw.n
.LFE2160:
	.size	_ZN12_GLOBAL__N_113admitHomeStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedHomeEy, .-_ZN12_GLOBAL__N_113admitHomeStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedHomeEy
	.literal_position
	.literal .LC466, 45756
	.literal .LC467, 45752
	.align	4
	.type	_ZN12_GLOBAL__N_117admitVelocityStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS16PreparedVelocityEy, @function
_ZN12_GLOBAL__N_117admitVelocityStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS16PreparedVelocityEy:
.LFB2154:
	entry	sp, 144
.LCFI76:
	movi	a12, 0x60
	movi.n	a11, 0
	addi.n	a10, sp, 8
	call8	memset
	addi	a8, a4, 22
	s32i	a8, sp, 0
	l32i	a8, a4, 40
	s32i	a8, sp, 4
	l8ui	a8, a4, 50
	mov.n	a5, a2
	movi.n	a10, 8
	bnez.n	a8, .L909
	l16ui	a10, a4, 46
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L909:
	l32r	a8, .LC466
	l32i	a9, a4, 60
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 12
	l32r	a8, .LC467
	l32i	a9, a4, 76
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 100
	s32i	a8, sp, 16
	l32i	a8, a4, 56
	l32i	a9, a4, 44
	s32i	a8, sp, 24
	l32i	a8, a4, 72
	s32i	a10, sp, 8
	s32i	a8, sp, 96
	l8ui	a8, a4, 8
	s32i	a9, sp, 48
	s8i	a8, sp, 54
	l8ui	a8, a4, 21
	s8i	a8, sp, 55
	l32i	a8, a4, 4
	s32i	a8, sp, 40
	l32i	a8, a4, 12
	s32i	a8, sp, 44
	l16ui	a8, a4, 48
	s16i	a8, sp, 52
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32i	a8, a3, 4
	s32i	a10, sp, 56
	s32i	a11, sp, 60
	beqz.n	a8, .L910
.L914:
	l8ui	a8, a4, 51
	movi	a10, 0x7f7
	addi	a14, a3, 32
	slli	a10, a10, 5
	bnez.n	a8, .L911
	j	.L917
.L910:
	mov.n	a11, sp
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE
	mov.n	a2, a10
	beqz.n	a10, .L914
	j	.L913
.L911:
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	add.n	a10, a5, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner11admitUrgentERKNS0_10BusRequestEyRNS0_9RequestIdE
	j	.L915
.L917:
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	add.n	a10, a5, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
.L915:
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
.L913:
	retw.n
.LFE2154:
	.size	_ZN12_GLOBAL__N_117admitVelocityStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS16PreparedVelocityEy, .-_ZN12_GLOBAL__N_117admitVelocityStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS16PreparedVelocityEy
	.literal_position
	.literal .LC469, 45756
	.literal .LC470, 45752
	.align	4
	.type	_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy, @function
_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy:
.LFB2138:
	entry	sp, 144
.LCFI77:
	movi	a12, 0x60
	movi.n	a11, 0
	addi.n	a10, sp, 8
	call8	memset
	addi	a8, a4, 22
	s32i	a8, sp, 0
	l32i	a8, a4, 44
	s32i	a8, sp, 4
	l8ui	a8, a4, 54
	mov.n	a5, a2
	movi.n	a10, 8
	bnez.n	a8, .L920
	l16ui	a10, a4, 50
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L920:
	l32r	a8, .LC469
	l32i	a9, a4, 60
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 12
	l32r	a8, .LC470
	l32i	a9, a4, 48
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 8
	s32i	a8, sp, 16
	l32i	a8, a4, 56
	s32i	a9, sp, 48
	s32i	a8, sp, 24
	l8ui	a8, a4, 8
	s8i	a8, sp, 54
	l8ui	a8, a4, 21
	s8i	a8, sp, 55
	l32i	a8, a4, 4
	s32i	a8, sp, 40
	l32i	a8, a4, 12
	s32i	a8, sp, 44
	l16ui	a8, a4, 52
	s16i	a8, sp, 52
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32i	a8, a3, 4
	s32i	a10, sp, 56
	s32i	a11, sp, 60
	beqz.n	a8, .L921
.L923:
	movi	a10, 0x7f7
	slli	a10, a10, 5
	addi	a14, a3, 32
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, sp
	add.n	a10, a5, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
	j	.L922
.L921:
	l8ui	a8, a4, 54
	beqz.n	a8, .L923
	mov.n	a11, sp
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE
	mov.n	a2, a10
	beqz.n	a10, .L923
.L922:
	retw.n
.LFE2138:
	.size	_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy, .-_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy
	.literal_position
	.literal .LC473, 53807
	.literal .LC474, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC475, 45697
	.literal .LC477, 45698
	.literal .LC478, _ZN12_GLOBAL__N_14uartE
	.literal .LC479, 757624
	.align	4
	.type	_ZN12_GLOBAL__N_119groupAdmissionReadyERKNS_3AppE, @function
_ZN12_GLOBAL__N_119groupAdmissionReadyERKNS_3AppE:
.LFB2290:
	entry	sp, 32
.LCFI78:
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a2, a10
	l32i	a8, a10, 152
	l32i	a9, a10, 156
	mov.n	a7, a2
	or	a8, a8, a9
	movi.n	a2, 1
	bnez.n	a8, .L932
	l32r	a8, .LC473
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L932
	l32r	a8, .LC474
	movi.n	a2, 3
	l8ui	a8, a8, 0
	beqz.n	a8, .L932
	l32r	a8, .LC475
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L933
.L934:
	movi.n	a2, 2
	j	.L932
.L933:
	movi	a8, 0x165
	slli	a8, a8, 7
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L934
	l32r	a8, .LC477
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L934
	l8ui	a8, a10, 137
	bnez.n	a8, .L934
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L934
	l32r	a10, .LC478
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L934
	l32r	a8, .LC479
	movi.n	a2, 7
	add.n	a7, a7, a8
	l32i	a8, a7, 0
	movnez	a2, a10, a8
.L932:
	retw.n
.LFE2290:
	.size	_ZN12_GLOBAL__N_119groupAdmissionReadyERKNS_3AppE, .-_ZN12_GLOBAL__N_119groupAdmissionReadyERKNS_3AppE
	.literal_position
	.literal .LC480, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC481, 45672
	.literal .LC483, 53807
	.literal .LC484, .LC3
	.literal .LC485, 45698
	.literal .LC486, 64920
	.literal .LC487, 183140
	.literal .LC490, 626184
	.literal .LC491, 770856
	.literal .LC492, 771168
	.literal .LC493, 45697
	.literal .LC494, 45700
	.literal .LC495, _ZN12_GLOBAL__N_14uartE
	.literal .LC496, 45696
	.literal .LC497, 45688
	.literal .LC498, 45680
	.literal .LC499, 64900
	.literal .LC500, 64909
	.literal .LC501, 45704
	.literal .LC502, 45708
	.literal .LC503, 45768
	.align	4
	.type	_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb, @function
_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb:
.LFB2327:
	entry	sp, 192
.LCFI79:
	s32i	a4, sp, 144
	mov.n	a7, a2
	bnez.n	a3, .L944
	l32r	a8, .LC480
	l8ui	a8, a8, 0
	bnez.n	a8, .L945
.L953:
	movi.n	a8, 3
	j	.L946
.L945:
	l32r	a11, .LC481
	l32i	a10, sp, 144
	movi	a12, 0x78
	add.n	a11, a7, a11
	call8	memcpy
	movi.n	a8, 0
	j	.L946
.L944:
	movi	a2, 0x7f7
	slli	a2, a2, 5
	add.n	a9, a7, a2
	l32i	a8, a9, 152
	l32i	a9, a9, 156
	or	a8, a8, a9
	bnez.n	a8, .L947
	l32r	a8, .LC483
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L948
.L947:
	bnez.n	a5, .L948
.L954:
	movi.n	a8, 1
	j	.L946
.L948:
	l8ui	a9, a3, 8
	mov.n	a8, a3
	beqz.n	a9, .L950
	l32r	a8, .LC481
	add.n	a8, a7, a8
.L950:
	l32i	a9, a8, 0
	movi	a6, 0x84
	l32i	a8, a8, 4
	add.n	a6, sp, a6
	l32r	a11, .LC484
	s32i	a9, a6, 0
	s32i	a8, a6, 4
	movi.n	a12, 0x3c
	addi	a10, sp, 72
	call8	memcpy
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	bnez.n	a10, .L951
.L952:
	movi.n	a8, 0xb
	j	.L946
.L951:
	addi	a11, sp, 72
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE
	beqz.n	a10, .L952
	l32r	a8, .LC480
	l8ui	a8, a8, 0
	beqz.n	a8, .L953
	l32r	a4, .LC485
	add.n	a8, a7, a4
	l8ui	a8, a8, 0
	bnez.n	a8, .L954
	add.n	a8, a7, a2
	l32i	a9, a8, 52
	bnei	a9, -1, .L954
	l32i	a9, a8, 48
	bnez.n	a9, .L954
	l8ui	a8, a8, 60
	beqi	a8, 1, .L954
	l32r	a6, .LC486
	add.n	a6, a7, a6
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample3Rtu6Runner4busyEv
	bnez.n	a10, .L954
	addmi	a6, a6, 0x100
	l8ui	a8, a6, 67
	bnez.n	a8, .L954
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L954
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	beqz.n	a10, .L955
	beqz.n	a5, .L954
	l32r	a8, .LC487
	movi.n	a10, 0x50
	add.n	a8, a7, a8
	addmi	a10, a10, 0x2300
	movi.n	a9, 0x22
	loop	a9, .L956_LEND
.L956:
	l8ui	a11, a8, 0
	bnez.n	a11, .L955
	add.n	a8, a8, a10
	.L956_LEND:
	j	.L954
.L955:
	l32r	a8, .LC490
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L954
	l32r	a8, .LC491
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L954
	l32r	a8, .LC492
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L954
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	mov.n	a6, a10
	bnez.n	a10, .L954
	l32r	a5, .LC493
	add.n	a8, a7, a5
	s32i	a8, sp, 148
	l8ui	a8, a8, 0
	beqz.n	a8, .L957
.L961:
	l32r	a8, .LC494
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	movi.n	a8, 7
	bnei	a9, -1, .L998
	j	.L946
.L957:
	add.n	a10, a7, a2
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L959
.L960:
	movi.n	a8, 2
	j	.L946
.L959:
	l32r	a10, .LC495
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L960
	add.n	a8, a7, a5
	l8ui	a8, a8, 0
	bnez.n	a8, .L961
	l32r	a8, .LC496
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L961
	l32r	a11, .LC497
	movi	a10, 0x84
	add.n	a11, a7, a11
	add.n	a10, sp, a10
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	beqz.n	a10, .L961
	j	.L945
.L998:
	add.n	a8, a7, a2
	l8ui	a9, a8, 137
	beqz.n	a9, .L962
.L965:
	l32r	a10, .LC498
	add.n	a8, a7, a4
	movi.n	a9, 1
	movi	a11, 0x84
	s8i	a9, a8, 0
	movi.n	a12, 5
	add.n	a11, sp, a11
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a8, .LC494
	add.n	a9, a7, a8
	l32i	a8, a9, 0
	addi.n	a8, a8, 1
	s32i	a8, a9, 0
	l32r	a8, .LC499
	movi.n	a9, 0
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	l32r	a8, .LC500
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy
	add.n	a8, a7, a5
	l8ui	a8, a8, 0
	bnez.n	a8, .L963
	j	.L964
.L962:
	s32i	a8, sp, 148
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	l32i	a10, sp, 148
	mov.n	a13, a11
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner18beginConfigurationEy
	bnez.n	a10, .L965
	j	.L954
.L964:
	movi	a11, 0x84
	l32r	a10, .LC495
	add.n	a11, sp, a11
	call8	_ZN21MotorControlRSExample11Esp32S3Uart11reconfigureERKNS_9HostTupleE
	beqz.n	a10, .L967
	j	.L966
.L963:
	l32r	a10, .LC495
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart20configurationBlockedEv
	bnez.n	a10, .L964
	l32r	a10, .LC495
	call8	_ZN21MotorControlRSExample11Esp32S3Uart5clearEv
	bnez.n	a10, .L964
.L967:
	movi.n	a8, 0
	j	.L968
.L966:
	s32i	a10, sp, 148
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	add.n	a10, a7, a2
	addi	a11, sp, 72
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner19finishConfigurationERKNS0_6TimingEy
	l32i	a8, sp, 148
	mov.n	a6, a10
.L968:
	movi.n	a9, 0
	add.n	a4, a7, a4
	movi.n	a2, 1
	s8i	a9, a4, 0
	xor	a2, a6, a2
	l32r	a9, .LC496
	add.n	a5, a7, a5
	extui	a2, a2, 0, 8
	s8i	a2, a5, 0
	add.n	a9, a7, a9
	s8i	a6, a9, 0
	l32r	a5, .LC501
	bnez.n	a6, .L969
	add.n	a5, a7, a5
	l8ui	a10, a3, 8
	s32i	a6, a5, 0
	movi.n	a9, 3
	bnez.n	a10, .L972
	j	.L999
.L969:
	l32r	a11, .LC495
	mov.n	a10, sp
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart5statsEv
	l32i	a8, sp, 60
	l32r	a10, .LC497
	add.n	a5, a7, a5
	movi	a11, 0x84
	s32i	a8, a5, 0
	movi.n	a12, 5
	add.n	a11, sp, a11
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a10, .LC502
	movi.n	a12, 0x3c
	addi	a11, sp, 72
	add.n	a10, a7, a10
	call8	memcpy
	movi.n	a9, 0
	j	.L972
.L999:
	addi.n	a8, a8, 1
	extui	a9, a8, 0, 8
.L972:
	l32r	a8, .LC503
	l32r	a11, .LC481
	add.n	a8, a7, a8
	l32i	a10, sp, 144
	s8i	a9, a8, 0
	movi	a12, 0x78
	add.n	a11, a7, a11
	call8	memcpy
	slli	a2, a2, 2
	extui	a8, a2, 0, 8
.L946:
	mov.n	a2, a8
	retw.n
.LFE2327:
	.size	_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb, .-_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb
	.align	4
	.type	_ZN12_GLOBAL__N_110hostSerialEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotE, @function
_ZN12_GLOBAL__N_110hostSerialEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotE:
.LFB2328:
	entry	sp, 32
.LCFI80:
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a12, a4
	movi.n	a13, 0
	call8	_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb
	mov.n	a2, a10
	retw.n
.LFE2328:
	.size	_ZN12_GLOBAL__N_110hostSerialEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotE, .-_ZN12_GLOBAL__N_110hostSerialEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotE
	.literal_position
	.literal .LC504, 58992
	.literal .LC506, 53696
	.literal .LC507, 45697
	.literal .LC508, _ZN12_GLOBAL__N_14uartE
	.literal .LC510, 45672
	.literal .LC512, 45688
	.literal .LC513, 53800
	.align	4
	.type	_ZN12_GLOBAL__N_116discoveryRestoreERNS_3AppE, @function
_ZN12_GLOBAL__N_116discoveryRestoreERNS_3AppE:
.LFB2354:
	entry	sp, 48
.LCFI81:
	l32r	a8, .LC504
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L1002
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a2, a10
	l32i	a8, a10, 52
	bnei	a8, -1, .L1002
	l32i	a8, a10, 48
	bnez.n	a8, .L1002
	l8ui	a8, a10, 60
	beqi	a8, 1, .L1002
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L1006
.L1008:
	l32r	a8, .LC506
	movi.n	a9, 4
	add.n	a8, a2, a8
	s8i	a9, a8, 104
	j	.L1002
.L1006:
	l32r	a8, .LC507
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1007
	l32r	a10, .LC508
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1008
.L1007:
	movi	a11, 0x69
	slli	a11, a11, 9
	movi.n	a8, 0
	movi.n	a12, 5
	add.n	a11, a2, a11
	mov.n	a10, sp
	s8i	a8, sp, 8
	call8	memcpy
	l32r	a12, .LC510
	movi.n	a13, 1
	add.n	a12, a2, a12
	mov.n	a11, sp
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb
	mov.n	a6, a10
	beqi	a10, 1, .L1002
	bnez.n	a10, .L1009
	movi	a8, 0x165
	slli	a8, a8, 7
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1009
	l32r	a7, .LC506
	l32r	a10, .LC512
	add.n	a7, a2, a7
	addi	a11, a7, 64
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	beqz.n	a10, .L1009
	movi.n	a8, 1
	s8i	a8, a7, 112
	movi.n	a8, 5
	s8i	a6, a7, 111
	s8i	a8, a7, 104
	call8	_Z18esp_timer_get_timev
	s32i	a10, a7, 96
	s32i	a11, a7, 100
	j	.L1002
.L1009:
	l32r	a8, .LC513
	add.n	a2, a2, a8
	movi	a8, 0x704
	s16i	a8, a2, 0
.L1002:
	retw.n
.LFE2354:
	.size	_ZN12_GLOBAL__N_116discoveryRestoreERNS_3AppE, .-_ZN12_GLOBAL__N_116discoveryRestoreERNS_3AppE
	.literal_position
	.literal .LC515, _ZN12_GLOBAL__N_14uartE
	.literal .LC516, 45697
	.literal .LC517, 45698
	.literal .LC518, 53807
	.literal .LC519, 764508
	.literal .LC520, 764504
	.literal .LC521, 772456
	.literal .LC522, 764516
	.align	4
	.type	_ZN12_GLOBAL__N_114inspectReleaseERNS_3AppEmRN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE, @function
_ZN12_GLOBAL__N_114inspectReleaseERNS_3AppEmRN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE:
.LFB2134:
	entry	sp, 64
.LCFI82:
	mov.n	a10, a2
	mov.n	a11, a3
	call8	_ZN12_GLOBAL__N_121failedTransmittedStopERNS_3AppEm
	mov.n	a7, a2
	movi.n	a2, 8
	beqz.n	a10, .L1024
	movi	a6, 0x7f7
	slli	a6, a6, 5
	add.n	a6, a7, a6
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L1025
.L1026:
	movi.n	a2, 2
	j	.L1024
.L1025:
	l32r	a10, .LC515
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1026
	l32r	a8, .LC516
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1026
	l32r	a8, .LC517
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1026
	l32r	a8, .LC518
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1027
.L1028:
	movi.n	a2, 1
	j	.L1024
.L1027:
	l32i	a8, a6, 152
	l32i	a9, a6, 156
	or	a8, a8, a9
	bnez.n	a8, .L1028
	l32r	a8, .LC519
	movi.n	a12, 0
	add.n	a8, a7, a8
	l8ui	a11, a8, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L1028
	l32r	a8, .LC520
	s32i	a10, sp, 24
	add.n	a8, a7, a8
	l32i	a9, a8, 4
	s32i	a10, sp, 28
	l32i	a10, a8, 0
	l32i	a8, a8, 8
	s32i	a10, sp, 0
	s32i	a8, sp, 8
	l32r	a8, .LC521
	l32r	a10, .LC515
	add.n	a8, a7, a8
	l32i	a6, a8, 0
	l32r	a8, .LC522
	s32i	a9, sp, 4
	add.n	a7, a7, a8
	l32i	a7, a7, 0
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	movi.n	a12, 0x1a
	mov.n	a11, sp
	mov.n	a10, a4
	s32i	a6, sp, 8
	s32i	a7, sp, 12
	movi.n	a2, 0
	call8	memcpy
.L1024:
	retw.n
.LFE2134:
	.size	_ZN12_GLOBAL__N_114inspectReleaseERNS_3AppEmRN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE, .-_ZN12_GLOBAL__N_114inspectReleaseERNS_3AppEmRN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	.section	.rodata.str1.1
.LC523:
	.string	"staged words differ on readback"
.LC525:
	.string	"stage readback failed"
.LC532:
	.string	"stage cancelled"
.LC534:
	.string	"stage write not acknowledged"
.LC536:
	.string	"stage cancelled before its readback"
.LC538:
	.string	"stage deadline expired"
.LC541:
	.string	"stage readback not admitted"
	.text
	.literal_position
	.literal .LC524, .LC523
	.literal .LC526, .LC525
	.literal .LC527, .LC12
	.literal .LC528, 772456
	.literal .LC529, 45700
	.literal .LC530, 65248
	.literal .LC533, .LC532
	.literal .LC535, .LC534
	.literal .LC537, .LC536
	.literal .LC539, .LC538
	.literal .LC540, _ZN12_GLOBAL__N_14uartE
	.literal .LC542, .LC541
	.align	4
	.type	_ZN12_GLOBAL__N_120servicePositionStageERNS_3AppERNS0_12StageSessionEy$part$0, @function
_ZN12_GLOBAL__N_120servicePositionStageERNS_3AppERNS0_12StageSessionEy$part$0:
.LFB2458:
	entry	sp, 80
.LCFI83:
	l32r	a8, .LC528
	movi.n	a10, 1
	add.n	a8, a2, a8
	l32i	a9, a3, 8
	l32i	a8, a8, 0
	s32i	a10, sp, 36
	bne	a9, a8, .L1033
	l32r	a9, .LC529
	l32i	a8, a3, 20
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	sub	a8, a8, a9
	movi.n	a9, 1
	moveqz	a9, a8, a8
	s32i	a9, sp, 36
.L1033:
	l32i	a8, a3, 136
	beqz.n	a8, .L1034
	l32r	a7, .LC530
	movi	a6, 0x88
	add.n	a8, a3, a6
	add.n	a7, a2, a7
	mov.n	a11, a8
	mov.n	a10, a7
	s32i	a8, sp, 32
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	l8ui	a9, a3, 152
	mov.n	a6, a10
	bnei	a9, 1, .L1035
	beqz.n	a10, .L1035
	l8ui	a9, a3, 50
	bnez.n	a9, .L1035
	movi.n	a9, 3
	l8ui	a11, a3, 4
	s8i	a9, a3, 50
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118storedWordsChangedERNS_3AppEh
.L1035:
	l8ui	a9, a3, 26
	bnez.n	a9, .L1069
	l32i	a8, sp, 36
	beqz.n	a8, .L1036
.L1069:
	bnez.n	a6, .L1036
	l32i	a11, sp, 32
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L1036:
	l32i	a11, sp, 32
	mov.n	a10, a7
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	beqz.n	a10, .L1032
	l8ui	a6, a10, 105
	l8ui	a9, a10, 160
	movi.n	a8, 0
	bnei	a6, 2, .L1040
	l8ui	a11, a10, 112
	bnei	a11, 1, .L1040
	beqz.n	a9, .L1040
	l8ui	a8, a10, 142
.L1040:
	l8ui	a11, a3, 152
	l32i	a12, a10, 152
	l32i	a13, a10, 156
	bnei	a11, 1, .L1041
	l8ui	a14, a10, 142
	l32i	a15, a10, 172
	s8i	a14, a3, 51
	l32i	a14, a10, 168
	s32i	a15, a3, 60
	s32i	a14, a3, 56
	l32i	a14, a10, 184
	s8i	a9, a3, 68
	s32i	a14, a3, 64
	s32i	a12, a3, 72
	s32i	a13, a3, 76
	l16ui	a9, a10, 136
	bnez.n	a8, .L1042
	beqi	a6, 3, .L1065
	bnez.n	a9, .L1043
	s8i	a8, a3, 50
	j	.L1044
.L1043:
	movi.n	a8, 3
	s8i	a8, a3, 50
	j	.L1045
.L1065:
	movi.n	a11, 2
.L1042:
	s8i	a11, a3, 50
	beqz.n	a9, .L1044
.L1045:
	l8ui	a11, a3, 4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118storedWordsChangedERNS_3AppEh
	j	.L1044
.L1041:
	l32i	a14, a10, 144
	l32i	a15, a10, 148
	s8i	a9, a3, 69
	movi.n	a9, 0
	s32i	a14, a3, 80
	s32i	a15, a3, 84
	s32i	a12, a3, 88
	s32i	a13, a3, 92
	s32i	a9, sp, 28
	bnez.n	a8, .L1046
.L1048:
	movi.n	a8, 0
	j	.L1047
.L1046:
	addi	a8, sp, 28
	l16ui	a11, a10, 138
	s32i	a8, sp, 0
	s32i	a9, sp, 4
	movi	a8, 0xcf
	l8ui	a12, a3, 4
	movi.n	a15, 5
	addi	a14, a3, 40
	movi.n	a13, 5
	add.n	a10, a10, a8
	call8	_ZN14MotorControlRS6ESS_RS14parseRegistersEPKhjhtPtjRjPNS0_10FrameErrorE
	extui	a10, a10, 0, 8
	bnez.n	a10, .L1048
	l32i	a9, sp, 28
	movi.n	a8, 1
	addi	a9, a9, -5
	movnez	a8, a10, a9
.L1047:
	s8i	a8, a3, 38
.L1044:
	l32i	a11, sp, 32
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	movi.n	a8, 0
	s32i	a8, a3, 136
	s32i	a8, a3, 140
	s32i	a8, a3, 144
	s32i	a8, a3, 148
	l8ui	a8, a3, 26
	bnez.n	a8, .L1070
	l32i	a8, sp, 36
	beqz.n	a8, .L1049
.L1070:
	movi.n	a9, 1
	movi.n	a8, 0
	s8i	a9, a3, 26
	s8i	a9, a3, 120
	movi.n	a9, 0
	s32i	a9, a3, 124
	s16i	a8, a3, 24
	l32r	a9, .LC533
	j	.L1090
.L1049:
	l8ui	a7, a3, 152
	bnei	a7, 2, .L1051
	l8ui	a8, a3, 38
	beqz.n	a8, .L1066
	movi.n	a12, 0xa
	addi	a11, a3, 28
	addi	a10, a3, 40
	call8	memcmp
	l32r	a8, .LC524
	bnez.n	a10, .L1052
	j	.L1067
.L1066:
	l32r	a8, .LC526
	movi.n	a7, 5
.L1052:
	movi.n	a9, 0
	j	.L1053
.L1067:
	l32r	a8, .LC527
	movi.n	a7, 0
	movi.n	a9, 1
.L1053:
	movi.n	a10, 0
	s8i	a9, a3, 25
	movi.n	a9, 0
	s8i	a10, a3, 24
	s8i	a7, a3, 120
	s32i	a9, a3, 124
	s32i	a8, a3, 128
	s32i	a4, a3, 112
	s32i	a5, a3, 116
	s8i	a9, a3, 152
	j	.L1032
.L1051:
	l8ui	a8, a3, 50
	beqi	a8, 1, .L1054
	movi.n	a9, 5
	bnei	a6, 3, .L1055
	movi.n	a9, 6
.L1055:
	movi.n	a8, 0
	s8i	a9, a3, 120
	s16i	a8, a3, 24
	l32r	a9, .LC535
	s32i	a6, a3, 124
	j	.L1090
.L1054:
	movi.n	a8, 2
	s8i	a8, a3, 152
	j	.L1056
.L1034:
	l8ui	a8, a3, 26
	bnez.n	a8, .L1071
	l32i	a8, sp, 36
	beqz.n	a8, .L1056
.L1071:
	movi.n	a9, 1
	movi.n	a8, 0
	s8i	a9, a3, 26
	s8i	a9, a3, 120
	movi.n	a9, 0
	s32i	a9, a3, 124
	s16i	a8, a3, 24
	l32r	a9, .LC537
	j	.L1090
.L1056:
	l32i	a8, a3, 108
	bltu	a5, a8, .L1058
	bne	a8, a5, .L1072
	l32i	a8, a3, 104
	bltu	a4, a8, .L1058
.L1072:
	movi.n	a9, 1
	s8i	a9, a3, 120
	movi.n	a9, 0
	movi.n	a8, 0
	s32i	a9, a3, 124
	l32r	a9, .LC539
	s16i	a8, a3, 24
.L1090:
	s32i	a9, a3, 128
	s32i	a4, a3, 112
	s32i	a5, a3, 116
	j	.L1089
.L1058:
	l8ui	a8, a3, 152
	bnei	a8, 2, .L1032
	l32i	a8, a3, 136
	bnez.n	a8, .L1032
	l32r	a10, .LC530
	add.n	a10, a2, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1032
	l32r	a10, .LC540
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1032
	mov.n	a14, a4
	mov.n	a15, a5
	movi.n	a12, 0
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116submitStageFrameERNS_3AppERNS0_12StageSessionEby
	movi	a8, 0x61
	ssr	a10
	srl	a8, a8
	extui	a8, a8, 0, 1
	bnez.n	a8, .L1032
	s16i	a8, a3, 24
	movi.n	a8, 1
	s8i	a8, a3, 120
	l32r	a8, .LC542
	s32i	a10, a3, 124
	s32i	a8, a3, 128
	s32i	a4, a3, 112
	s32i	a5, a3, 116
	movi.n	a8, 0
.L1089:
	s8i	a8, a3, 152
.L1032:
	retw.n
.LFE2458:
	.size	_ZN12_GLOBAL__N_120servicePositionStageERNS_3AppERNS0_12StageSessionEy$part$0, .-_ZN12_GLOBAL__N_120servicePositionStageERNS_3AppERNS0_12StageSessionEy$part$0
	.literal_position
	.literal .LC543, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC544, 45697
	.literal .LC545, 45698
	.literal .LC547, _ZN12_GLOBAL__N_14uartE
	.literal .LC548, 772492
	.literal .LC549, 772456
	.literal .LC550, 45700
	.align	4
	.type	_ZN12_GLOBAL__N_118beginPositionStageERNS_3AppERNS0_12StageSessionERKN14MotorControlRS10ReadTargetEmPKtmy$part$0, @function
_ZN12_GLOBAL__N_118beginPositionStageERNS_3AppERNS0_12StageSessionERKN14MotorControlRS10ReadTargetEmPKtmy$part$0:
.LFB2462:
	entry	sp, 64
.LCFI84:
	l32r	a9, .LC543
	s32i	a7, sp, 20
	l8ui	a9, a9, 0
	s32i	a5, sp, 16
	mov.n	a7, a4
	l32i	a5, sp, 68
	l32i	a4, sp, 64
	bnez.n	a9, .L1092
.L1096:
	movi.n	a9, 3
	j	.L1093
.L1092:
	l32r	a9, .LC544
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L1094
.L1095:
	movi.n	a9, 2
	j	.L1093
.L1094:
	l32r	a9, .LC545
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L1095
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a2, a10
	l8ui	a9, a10, 137
	bnez.n	a9, .L1095
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1095
	l32r	a10, .LC547
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1095
	l8ui	a10, a7, 4
	l32r	a11, .LC548
	srli	a9, a10, 3
	add.n	a9, a2, a9
	add.n	a9, a9, a11
	l8ui	a11, a9, 0
	extui	a9, a10, 0, 3
	bbc	a11, a9, .L1096
	l32r	a9, .LC549
	l32i	a11, a7, 8
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	bne	a11, a9, .L1096
	movi.n	a13, 5
	mov.n	a12, a6
	movi.n	a11, 0x21
	call8	_ZN14MotorControlRS6ESS_RS37validateWriteMultipleRegistersRequestEhtPKtt
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	movi.n	a9, 8
	bnez.n	a10, .L1093
	movi	a12, 0xc0
	movi.n	a11, 0
	mov.n	a10, a3
	call8	memset
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_13App12StageSessionC1Ev
	l32i	a10, a7, 0
	l32i	a9, a7, 4
	s32i	a10, a3, 0
	l32i	a8, a7, 8
	s32i	a9, a3, 4
	s32i	a8, a3, 8
	l32i	a8, sp, 20
	movi.n	a12, 0xa
	s32i	a8, a3, 12
	l32i	a8, sp, 16
	mov.n	a11, a6
	s32i	a8, a3, 16
	l32r	a8, .LC550
	addi	a10, a3, 28
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a8, a3, 20
	call8	memcpy
	movi	a10, 0x3e8
	mull	a10, a10, a10
	s32i	a4, a3, 96
	s32i	a5, a3, 100
	add.n	a9, a4, a10
	mov.n	a8, a5
	bgeu	a9, a10, .L1098
	addi.n	a8, a5, 1
.L1098:
	movi.n	a7, 1
	s32i	a9, a3, 104
	s32i	a8, a3, 108
	s8i	a7, a3, 152
	mov.n	a14, a4
	mov.n	a15, a5
	movi.n	a12, 1
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116submitStageFrameERNS_3AppERNS0_12StageSessionEby
	mov.n	a9, a10
	beqz.n	a10, .L1099
	s32i	a10, sp, 16
	movi	a12, 0xc0
	movi.n	a11, 0
	mov.n	a10, a3
	call8	memset
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_13App12StageSessionC1Ev
	l32i	a9, sp, 16
	j	.L1093
.L1099:
	s8i	a7, a3, 24
.L1093:
	mov.n	a2, a9
	retw.n
.LFE2462:
	.size	_ZN12_GLOBAL__N_118beginPositionStageERNS_3AppERNS0_12StageSessionERKN14MotorControlRS10ReadTargetEmPKtmy$part$0, .-_ZN12_GLOBAL__N_118beginPositionStageERNS_3AppERNS0_12StageSessionERKN14MotorControlRS10ReadTargetEmPKtmy$part$0
	.literal_position
	.literal .LC554, 200000
	.literal .LC555, 500000
	.literal .LC556, .LC12
	.literal .LC557, 772456
	.literal .LC558, 625320
	.literal .LC559, 626184
	.literal .LC560, 772584
	.literal .LC561, 772556
	.literal .LC562, 772568
	.literal .LC563, 772576
	.literal .LC564, 757804
	.literal .LC565, 757796
	.literal .LC566, 757800
	.literal .LC567, 757972
	.literal .LC568, 757964
	.literal .LC569, 757968
	.literal .LC570, 764508
	.literal .LC571, 757768
	.literal .LC573, 45688
	.literal .LC574, 45756
	.literal .LC575, 45672
	.literal .LC576, _ZN21MotorControlRSExample14RuntimeWitnessL8retainedE
	.literal .LC577, _ZN21MotorControlRSExample14RuntimeWitnessL8previousE
	.literal .LC578, 1296257585
	.literal .LC579, _ZN21MotorControlRSExample13OwnerWatchdogL10subscribedE
	.literal .LC580, _ZN21MotorControlRSExample13OwnerWatchdogL5errorE
	.literal .LC582, _ZN21MotorControlRSExample13OwnerWatchdogL11resetReasonE
	.literal .LC583, 757672
	.literal .LC584, 757676
	.literal .LC585, 757664
	.literal .LC586, 757680
	.literal .LC587, 757684
	.literal .LC588, 757688
	.literal .LC589, 757692
	.literal .LC590, 757696
	.literal .LC591, 757700
	.literal .LC592, _ZN21MotorControlRSExample13OwnerWatchdogL14completedLoopsE
	.literal .LC593, _ZN21MotorControlRSExample13OwnerWatchdogL10lastFeedUsE
	.literal .LC594, 45752
	.literal .LC595, 45708
	.literal .LC596, 45712
	.literal .LC597, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC598, 45697
	.literal .LC599, _ZN12_GLOBAL__N_122writeResponseConfirmedE
	.literal .LC600, 53807
	.literal .LC602, _ZN12_GLOBAL__N_14uartE
	.literal .LC603, 64920
	.literal .LC605, 757775
	.literal .LC606, 757776
	.literal .LC607, 772585
	.literal .LC608, 757772
	.literal .LC609, 757773
	.literal .LC610, 757770
	.literal .LC611, 757774
	.literal .LC612, 757769
	.literal .LC613, 757636
	.literal .LC614, 757736
	.literal .LC615, 757744
	.literal .LC616, 757752
	.literal .LC618, 757628
	.literal .LC619, 101000
	.literal .LC620, 9040
	.literal .LC621, 757620
	.literal .LC622, 757704
	.literal .LC623, 757712
	.literal .LC624, 757720
	.literal .LC625, 757728
	.literal .LC626, 65072
	.literal .LC628, 35576
	.literal .LC629, 757640
	.literal .LC630, 626282
	.literal .LC631, 626240
	.literal .LC632, 626272
	.literal .LC633, 53784
	.literal .LC634, 100000
	.align	4
	.type	_ZN12_GLOBAL__N_18snapshotEPvRN21MotorControlRSExample5Probe8SnapshotE, @function
_ZN12_GLOBAL__N_18snapshotEPvRN21MotorControlRSExample5Probe8SnapshotE:
.LFB2075:
	entry	sp, 720
.LCFI85:
	movi	a12, 0x298
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi	a10, 0xe1
	slli	a10, a10, 9
	s32i	a10, sp, 0
	s32i	a10, sp, 8
	s32i	a10, sp, 16
	movi.n	a10, 1
	s8i	a10, sp, 24
	movi.n	a11, 0x14
	movi.n	a10, 1
	s32i	a10, sp, 28
	s32i	a11, sp, 76
	s8i	a10, sp, 120
	l32r	a11, .LC554
	l32r	a10, .LC556
	s32i	a11, sp, 84
	s32i	a10, sp, 180
	l32r	a11, .LC555
	movi.n	a10, 0x40
	s32i	a10, sp, 256
	movi.n	a10, 0xa
	movi	a12, 0x298
	s32i	a11, sp, 88
	s32i	a11, sp, 92
	s32i	a10, sp, 308
	mov.n	a11, sp
	mov.n	a10, a3
	call8	memcpy
	l32i	a10, a2, 0
	mov.n	a6, a3
	s32i	a10, a3, 144
	l32r	a10, .LC557
	movi	a7, 0x165
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	slli	a7, a7, 7
	s32i	a10, a3, 284
	call8	_Z18esp_timer_get_timev
	l32r	a4, .LC558
	s32i	a11, a3, 484
	l32r	a11, .LC559
	s32i	a10, a3, 480
	add.n	a4, a2, a4
	movi	a10, 0x1e8
	s32i	a4, a3, 472
	add.n	a11, a2, a11
	movi.n	a12, 0x38
	add.n	a10, a3, a10
	call8	memcpy
	l32r	a10, .LC560
	addmi	a8, a3, 0x200
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	addi	a11, a8, 36
	s8i	a10, a8, 32
	l32r	a10, .LC561
	addmi	a3, a3, 0x100
	add.n	a10, a2, a10
	l32i	a13, a10, 0
	l32i	a12, a10, 4
	s32i	a13, a8, 36
	l32i	a10, a10, 8
	s32i	a12, a11, 4
	s32i	a10, a11, 8
	l32r	a10, .LC562
	s32i	a8, sp, 672
	add.n	a10, a2, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a3, 308
	s32i	a10, a3, 304
	l32r	a10, .LC563
	mov.n	a5, a2
	add.n	a10, a2, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a3, 316
	s32i	a10, a3, 312
	l32r	a10, .LC564
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a10, a3, 8
	l32r	a10, .LC565
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	s8i	a10, a3, 16
	l32r	a10, .LC566
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 276
	l32r	a10, .LC567
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 268
	l32r	a10, .LC568
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	s8i	a10, a3, 17
	l32r	a10, .LC569
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 280
	l32r	a10, .LC570
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	s8i	a10, a6, 120
	l32r	a10, .LC571
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	s8i	a10, a6, 187
	add.n	a10, a2, a7
	l8ui	a11, a10, 0
	movi.n	a10, 0
	beqz.n	a11, .L1107
	l32r	a10, .LC573
	add.n	a10, a2, a10
	l32i	a10, a10, 0
.L1107:
	s32i	a10, a6, 124
	l32r	a10, .LC574
	l32r	a11, .LC575
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	movi	a12, 0x78
	s32i	a10, a6, 128
	add.n	a11, a5, a11
	mov.n	a10, a6
	call8	memcpy
	l32r	a8, .LC576
	movi.n	a10, 8
	memw
	s32i	a10, a8, 4
	l32r	a10, .LC577
	l32r	a12, .LC578
	l32i	a11, a10, 0
	sub	a11, a11, a12
	nsau	a11, a11
	srli	a11, a11, 5
	s8i	a11, a3, 116
	l32i	a11, a10, 4
	s32i	a11, a6, 448
	l32i	a11, a10, 8
	s32i	a11, a6, 452
	l32i	a11, a10, 12
	s32i	a11, a6, 456
	l32i	a11, a10, 16
	s32i	a11, a6, 460
	l32i	a11, a10, 20
	l32i	a10, a10, 24
	s32i	a11, a6, 464
	s32i	a10, a6, 468
	l32r	a10, .LC579
	l8ui	a10, a10, 0
	s8i	a10, a3, 117
	l32r	a10, .LC580
	l32i	a10, a10, 0
	s32i	a10, a6, 376
	movi	a10, 0x88
	addmi	a10, a10, 0x1300
	s32i	a10, a6, 384
	l32r	a10, .LC582
	l32i	a10, a10, 0
	s32i	a10, a6, 380
	l32r	a10, .LC583
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 388
	l32r	a10, .LC584
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 392
	l32r	a10, .LC585
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 420
	s32i	a10, a6, 416
	l32r	a10, .LC586
	add.n	a10, a5, a10
	l8ui	a10, a10, 0
	s8i	a10, a3, 168
	l32r	a10, .LC587
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 396
	l32r	a10, .LC588
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 400
	l32r	a10, .LC589
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 404
	l32r	a10, .LC590
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 408
	l32r	a10, .LC591
	add.n	a10, a5, a10
	l8ui	a10, a10, 0
	s8i	a10, a3, 169
	l32r	a10, .LC592
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 436
	s32i	a10, a6, 432
	l32r	a10, .LC593
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 444
	s32i	a10, a6, 440
	l32r	a10, .LC594
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 132
	l32r	a10, .LC595
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 136
	l32r	a10, .LC596
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	s32i	a10, a6, 140
	call8	_Z18esp_timer_get_timev
	movi	a12, 0x3e8
	movi.n	a13, 0
	call8	__udivdi3
	s32i	a10, a6, 152
	l32r	a10, .LC597
	s32i	a11, a6, 156
	l8ui	a10, a10, 0
	l32r	a2, .LC598
	beqz.n	a10, .L1108
	add.n	a7, a5, a7
	l8ui	a10, a7, 0
	beqz.n	a10, .L1108
	add.n	a10, a5, a2
	l8ui	a10, a10, 0
	movi.n	a11, 1
	xor	a10, a10, a11
	extui	a10, a10, 0, 8
.L1108:
	s8i	a10, a6, 160
	movi.n	a10, 0
	s8i	a10, a6, 161
	l32r	a10, .LC599
	movi.n	a12, 1
	l8ui	a10, a10, 0
	movi.n	a11, 0
	s8i	a10, a6, 162
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	l32r	a3, .LC600
	s8i	a10, a6, 163
	add.n	a10, a5, a3
	l8ui	a10, a10, 0
	movi	a7, 0x7f7
	slli	a7, a7, 5
	bnez.n	a10, .L1109
	add.n	a11, a5, a7
	l32i	a10, a11, 156
	l32i	a12, a11, 152
	or	a12, a12, a10
	movi.n	a10, 1
	bnez.n	a12, .L1109
	l32i	a12, a11, 52
	bnei	a12, -1, .L1109
	l32i	a12, a11, 48
	bnez.n	a12, .L1109
	l8ui	a11, a11, 60
	beqi	a11, 1, .L1109
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L1109
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
.L1109:
	s8i	a10, a6, 164
	add.n	a2, a5, a2
	l8ui	a10, a2, 0
	bnez.n	a10, .L1110
	add.n	a10, a5, a7
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1110
	l32r	a10, .LC602
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
.L1110:
	s8i	a10, a6, 166
	l32r	a10, .LC603
	add.n	a10, a5, a10
	l8ui	a11, a10, 192
	addmi	a10, a10, 0x100
	s8i	a11, a6, 167
	movi	a11, 0x7ef
	l8ui	a10, a10, 67
	slli	a11, a11, 5
	add.n	a11, a5, a11
	l8ui	a11, a11, 0
	s8i	a10, a6, 165
	l32r	a10, .LC605
	s8i	a11, a6, 168
	add.n	a10, a5, a10
	l32r	a11, .LC606
	l8ui	a10, a10, 0
	add.n	a11, a5, a11
	l32i	a13, a11, 0
	s8i	a10, a6, 169
	movi	a10, 0xac
	add.n	a10, a6, a10
	l32i	a12, a11, 4
	s32i	a13, a10, 0
	l32i	a11, a11, 8
	s32i	a12, a10, 4
	s32i	a11, a10, 8
	l32r	a10, .LC607
	add.n	a10, a5, a10
	l8ui	a10, a10, 0
	s8i	a10, a6, 184
	l32r	a10, .LC608
	add.n	a10, a5, a10
	l8ui	a10, a10, 0
	s8i	a10, a6, 185
	l32r	a10, .LC609
	add.n	a10, a5, a10
	l8ui	a10, a10, 0
	s8i	a10, a6, 186
	l32r	a10, .LC610
	add.n	a10, a5, a10
	l16ui	a10, a10, 0
	s16i	a10, a6, 196
	l32r	a10, .LC611
	add.n	a10, a5, a10
	l8ui	a11, a10, 0
	s8i	a11, a6, 188
	l32r	a11, .LC612
	l32r	a2, .LC614
	add.n	a11, a5, a11
	l8ui	a11, a11, 0
	s8i	a11, a6, 189
	l8ui	a10, a10, 0
	beqz.n	a10, .L1111
	l32r	a10, .LC613
	add.n	a12, a5, a2
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	l32i	a11, a12, 4
	s32i	a10, a6, 192
	l32i	a10, a12, 0
	or	a10, a10, a11
	beqz.n	a10, .L1113
	j	.L1112
.L1111:
	s32i	a10, a6, 192
.L1113:
	movi.n	a10, 0
	movi.n	a11, 0
	j	.L1114
.L1112:
	s32i	a12, sp, 676
	call8	_Z18esp_timer_get_timev
	l32i	a12, sp, 676
	l32i	a14, a12, 0
	l32i	a12, a12, 4
	sub	a11, a11, a12
	bgeu	a10, a14, .L1115
	addi.n	a11, a11, -1
.L1115:
	movi	a12, 0x3e8
	movi.n	a13, 0
	sub	a10, a10, a14
	call8	__udivdi3
.L1114:
	s32i	a10, a6, 200
	s32i	a11, a6, 204
	add.n	a2, a5, a2
	l32i	a10, a2, 0
	l32i	a11, a2, 4
	s32i	a10, a6, 208
	l32r	a10, .LC615
	s32i	a11, a6, 212
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 220
	s32i	a10, a6, 216
	l32r	a10, .LC616
	l32r	a2, .LC619
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 228
	s32i	a10, a6, 224
	movi	a10, 0xb9
	slli	a10, a10, 12
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	add.n	a2, a5, a2
	s32i	a10, a6, 232
	l32r	a10, .LC618
	s32i	a11, a6, 236
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	l32r	a12, .LC620
	s32i	a10, a6, 260
	add.n	a10, a5, a7
	l32i	a10, a10, 48
	mov.n	a11, a2
	s32i	a10, a6, 288
	movi.n	a10, 4
	s32i	a10, a6, 300
	movi.n	a10, 8
	s32i	a10, a6, 304
	j	.L1116
.L1119:
	l32i	a10, a11, 4
	beqz.n	a10, .L1117
	l8ui	a10, a11, 68
	bnez.n	a10, .L1117
	mov.n	a10, a5
	s32i	a11, sp, 676
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	l32i	a11, sp, 676
	l32r	a12, .LC620
	beqz.n	a10, .L1118
	l32i	a10, a6, 292
	addi.n	a10, a10, 1
	s32i	a10, a6, 292
	j	.L1117
.L1118:
	l32i	a10, a6, 296
	addi.n	a10, a10, 1
	s32i	a10, a6, 296
.L1117:
	add.n	a11, a11, a12
.L1116:
	bne	a4, a11, .L1119
	l32r	a10, .LC621
	l32i	a8, sp, 672
	add.n	a10, a5, a10
	l32i	a10, a10, 0
	movi.n	a12, 0x24
	s32i	a10, a6, 312
	l32r	a10, .LC622
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 324
	s32i	a10, a6, 320
	l32r	a10, .LC623
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 332
	s32i	a10, a6, 328
	l32r	a10, .LC624
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 340
	s32i	a10, a6, 336
	l32r	a10, .LC625
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 348
	l32r	a11, .LC626
	s32i	a10, a6, 344
	add.n	a11, a5, a11
	addi	a10, a8, 64
	call8	memcpy
	movi	a10, 0x1ff
	l32r	a11, .LC628
	slli	a10, a10, 7
	add.n	a10, a5, a10
	add.n	a10, a10, a11
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 356
	s32i	a10, a6, 352
	l32r	a10, .LC629
	add.n	a10, a5, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a6, 364
	s32i	a10, a6, 360
	l32r	a10, .LC630
	add.n	a10, a5, a10
	l8ui	a11, a10, 0
	movi.n	a10, 0
	beqz.n	a11, .L1120
	l32r	a10, .LC631
	add.n	a10, a5, a10
	l32i	a10, a10, 0
.L1120:
	l32r	a8, .LC576
	s32i	a10, a6, 368
	l32r	a11, .LC602
	movi.n	a10, 9
	memw
	s32i	a10, a8, 4
	mov.n	a10, sp
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart5statsEv
	l8ui	a10, sp, 66
	l32r	a13, .LC620
	s8i	a10, a6, 248
	j	.L1121
.L1128:
	l32i	a10, a2, 4
	beqz.n	a10, .L1123
	mov.n	a11, a2
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	l32r	a13, .LC620
	bnez.n	a10, .L1123
	l32i	a14, a6, 240
	l32i	a11, a6, 244
	l32i	a12, a2, 56
	or	a15, a14, a11
	l32i	a10, a2, 60
	beqz.n	a15, .L1125
	bltu	a10, a11, .L1125
	bne	a11, a10, .L1123
	bgeu	a12, a14, .L1123
.L1125:
	s32i	a12, a6, 240
	s32i	a10, a6, 244
.L1123:
	add.n	a2, a2, a13
.L1121:
	bne	a4, a2, .L1128
	add.n	a7, a5, a7
	l8ui	a10, a7, 60
	bnei	a10, 1, .L1129
	l32i	a13, a6, 240
	l32i	a11, a6, 244
	l32r	a10, .LC632
	or	a14, a13, a11
	add.n	a10, a5, a10
	l32i	a12, a10, 0
	l32i	a10, a10, 4
	beqz.n	a14, .L1130
	bltu	a10, a11, .L1130
	bne	a11, a10, .L1129
	bgeu	a12, a13, .L1129
.L1130:
	s32i	a12, a6, 240
	s32i	a10, a6, 244
.L1129:
	add.n	a3, a5, a3
	l8ui	a10, a3, 0
	beqz.n	a10, .L1133
	l32r	a11, .LC633
	l32i	a12, a6, 240
	l32i	a10, a6, 244
	add.n	a9, a5, a11
	or	a13, a12, a10
	l32i	a11, a9, 0
	l32i	a9, a9, 4
	beqz.n	a13, .L1134
	bltu	a9, a10, .L1134
	bne	a10, a9, .L1133
	bgeu	a11, a12, .L1133
.L1134:
	s32i	a11, a6, 240
	s32i	a9, a6, 244
.L1133:
	l32r	a11, .LC602
	mov.n	a10, sp
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart5statsEv
	l32i	a10, sp, 36
	l32i	a9, sp, 32
	s32i	a10, a6, 624
	l32i	a10, sp, 40
	s32i	a9, a6, 616
	s32i	a10, a6, 628
	movi.n	a9, 0
	l8ui	a10, sp, 66
	s32i	a9, a6, 620
	s8i	a9, a6, 249
	beqz.n	a10, .L1137
	l32i	a9, sp, 56
.L1137:
	s32i	a9, a6, 252
	l8ui	a9, sp, 67
	l32i	a8, sp, 672
	s8i	a9, a6, 250
	l8ui	a9, sp, 68
	movi	a10, 0x12c
	s8i	a9, a6, 251
	movi.n	a9, 1
	s8i	a9, a8, 120
	l32r	a8, .LC576
	movi.n	a9, 0xa
	memw
	s32i	a9, a8, 4
	movi	a9, 0x271
	slli	a9, a9, 7
	s32i	a9, a6, 644
	s32i	a9, a6, 656
	movi.n	a9, 0xb
	memw
	s32i	a9, a8, 4
	movi.n	a9, 1
	slli	a9, a9, 12
	l32r	a11, .LC634
	mull	a10, a10, a10
	s32i	a9, a6, 660
	l32r	a9, .LC576
	movi.n	a8, 4
	s32i	a11, a6, 636
	s32i	a10, a6, 640
	s32i	a11, a6, 648
	s32i	a10, a6, 652
	memw
	s32i	a8, a9, 4
	retw.n
.LFE2075:
	.size	_ZN12_GLOBAL__N_18snapshotEPvRN21MotorControlRSExample5Probe8SnapshotE, .-_ZN12_GLOBAL__N_18snapshotEPvRN21MotorControlRSExample5Probe8SnapshotE
	.literal_position
	.literal .LC638, 45756
	.literal .LC639, 45752
	.literal .LC640, 65248
	.literal .LC641, 47135
	.literal .LC642, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC643, 45697
	.literal .LC644, 45698
	.literal .LC645, 764508
	.literal .LC646, 772456
	.literal .LC647, _ZN12_GLOBAL__N_14uartE
	.literal .LC648, 772492
	.literal .LC649, C$524$1
	.literal .LC650, C$525$2
	.literal .LC651, C$538$3
	.align	4
	.type	_ZN12_GLOBAL__N_115admitDriverStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedDriverEy, @function
_ZN12_GLOBAL__N_115admitDriverStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedDriverEy:
.LFB2192:
	entry	sp, 176
.LCFI86:
	movi	a12, 0x60
	movi.n	a11, 0
	addi.n	a10, sp, 8
	s32i	a7, sp, 132
	s32i	a6, sp, 128
	call8	memset
	addi	a8, a4, 28
	s32i	a8, sp, 0
	l32i	a8, a4, 36
	s32i	a8, sp, 4
	l8ui	a8, a4, 21
	mov.n	a5, a2
	movi.n	a10, 8
	bnez.n	a8, .L1172
	l16ui	a10, a4, 26
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
.L1172:
	l32r	a8, .LC638
	l32i	a9, a4, 44
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 8
	s32i	a8, sp, 12
	l32r	a8, .LC639
	l8ui	a10, a4, 21
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 16
	l32i	a8, a4, 40
	movi.n	a9, 6
	s32i	a8, sp, 24
	l8ui	a8, a4, 8
	s8i	a8, sp, 54
	movi.n	a8, 3
	movnez	a8, a9, a10
	s8i	a8, sp, 55
	l32i	a8, a4, 4
	s32i	a8, sp, 40
	l32i	a8, a4, 12
	s32i	a8, sp, 44
	l16ui	a8, a4, 22
	s16i	a8, sp, 48
	l16ui	a8, a4, 26
	s16i	a8, sp, 50
	l16ui	a8, a4, 24
	s16i	a8, sp, 52
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32i	a7, a3, 4
	s32i	a10, sp, 56
	s32i	a11, sp, 60
	beqz.n	a7, .L1174
.L1176:
	l32r	a10, .LC640
	l32i	a12, sp, 128
	l32i	a13, sp, 132
	addi	a14, a3, 32
	mov.n	a11, sp
	add.n	a10, a5, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
	j	.L1175
.L1174:
	l8ui	a8, a4, 21
	beqz.n	a8, .L1176
	addmi	a8, a3, 0x1000
	l8ui	a10, a8, 184
	bnei	a10, 1, .L1177
	l16ui	a8, sp, 48
	movi.n	a9, 0xf
	addi	a8, a8, -64
	extui	a8, a8, 0, 16
	bltu	a9, a8, .L1178
	l32r	a9, .LC641
	bbc	a9, a8, .L1178
	l16ui	a8, sp, 50
	beqi	a8, 1, .L1179
.L1178:
	movi.n	a2, 8
	j	.L1175
.L1179:
	l32r	a8, .LC642
	l8ui	a8, a8, 0
	bnez.n	a8, .L1180
.L1184:
	movi.n	a2, 3
	j	.L1175
.L1180:
	l32r	a8, .LC643
	add.n	a8, a5, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1181
.L1182:
	movi.n	a2, 2
	j	.L1175
.L1181:
	l32r	a8, .LC644
	add.n	a8, a5, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1182
	l32r	a10, .LC640
	add.n	a8, a5, a10
	l8ui	a8, a8, 137
	bnez.n	a8, .L1182
	l32r	a8, .LC645
	l8ui	a9, sp, 54
	add.n	a8, a5, a8
	l8ui	a8, a8, 0
	bne	a8, a9, .L1178
	l8ui	a9, sp, 55
	bnei	a9, 6, .L1178
	l32i	a9, sp, 40
	bne	a9, a8, .L1178
	l32r	a8, .LC646
	l32i	a9, sp, 44
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	add.n	a10, a5, a10
	beq	a9, a8, .L1274
	j	.L1178
.L1177:
	addi	a8, a10, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 3, .L1260
	j	.L1203
.L1189:
	l32r	a8, .LC649
	mov.n	a10, a4
	add.n	a8, a7, a8
	l8ui	a11, a8, 0
	call8	_ZN14MotorControlRS6ESS_RS23positionSegmentRegisterEhNS0_20PositionSegmentFieldE
	beqz.n	a10, .L1188
	l16ui	a8, a10, 0
	l16ui	a10, sp, 48
	sub	a8, a8, a10
	nsau	a8, a8
	srli	a8, a8, 5
	or	a2, a2, a8
.L1188:
	addi.n	a7, a7, 1
.L1194:
	bnei	a7, 3, .L1189
	movi.n	a7, 0
.L1191:
	l32r	a8, .LC650
	mov.n	a10, a4
	add.n	a8, a7, a8
	l8ui	a11, a8, 0
	call8	_ZN14MotorControlRS6ESS_RS20speedSegmentRegisterEhNS0_17SpeedSegmentFieldE
	beqz.n	a10, .L1190
	l16ui	a8, a10, 0
	l16ui	a10, sp, 48
	sub	a8, a8, a10
	nsau	a8, a8
	srli	a8, a8, 5
	or	a2, a2, a8
.L1190:
	addi.n	a7, a7, 1
	bnei	a7, 3, .L1191
	mov.n	a10, a4
	call8	_ZN14MotorControlRS6ESS_RS25segmentStartSpeedRegisterEh
	beqz.n	a10, .L1192
	l16ui	a8, a10, 0
	l16ui	a9, sp, 48
	sub	a8, a8, a9
	nsau	a8, a8
	srli	a8, a8, 5
	or	a2, a2, a8
.L1192:
	addi.n	a4, a4, 1
	movi.n	a8, 0x11
	bne	a4, a8, .L1186
	j	.L1193
.L1203:
	movi.n	a4, 1
	movi.n	a2, 0
.L1186:
	movi.n	a7, 0
	j	.L1194
.L1193:
	beqz.n	a2, .L1178
.L1302:
	l16ui	a8, sp, 50
	bnei	a8, 1, .L1178
	l8ui	a8, sp, 55
	bnei	a8, 6, .L1178
	l32r	a8, .LC645
	l8ui	a9, sp, 54
	add.n	a8, a5, a8
	l8ui	a8, a8, 0
	bne	a8, a9, .L1178
	l32i	a9, sp, 40
	bne	a9, a8, .L1178
	l32r	a8, .LC646
	l32i	a9, sp, 44
	add.n	a8, a5, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L1178
	l32r	a8, .LC642
	l8ui	a8, a8, 0
	beqz.n	a8, .L1184
	l32r	a8, .LC643
	add.n	a8, a5, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1182
	l32r	a8, .LC644
	add.n	a8, a5, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1182
	l32r	a10, .LC640
	add.n	a10, a5, a10
	l8ui	a8, a10, 137
	bnez.n	a8, .L1182
.L1274:
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1182
	l32r	a10, .LC647
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1182
	l8ui	a11, sp, 54
	l32r	a9, .LC648
	srli	a8, a11, 3
	add.n	a8, a5, a8
	add.n	a8, a8, a9
	l8ui	a9, a8, 0
	extui	a8, a11, 0, 3
	bbc	a9, a8, .L1184
	movi.n	a12, 1
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a2, 0xc
	bnez.n	a10, .L1175
	j	.L1176
.L1260:
	bnei	a10, 5, .L1195
	l16ui	a8, sp, 48
	addmi	a8, a8, -0x100
	extui	a8, a8, 0, 16
	bgeui	a8, 8, .L1178
	j	.L1302
.L1195:
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	beqz.n	a10, .L1196
	movi.n	a2, 0
.L1200:
	l32r	a8, .LC651
	movi.n	a6, 0
	add.n	a8, a7, a8
	l8ui	a4, a8, 0
	j	.L1197
.L1199:
	movi.n	a8, 6
	s16i	a8, sp, 104
	mov.n	a11, a6
	movi.n	a8, 0
	mov.n	a10, a4
	s16i	a8, sp, 106
	s16i	a8, sp, 108
	s16i	a8, sp, 110
	s8i	a8, sp, 112
	call8	_ZN14MotorControlRS6ESS_RS15tuningParameterENS0_11DriverGroupEh
	addi	a11, sp, 104
	call8	_ZN14MotorControlRS6ESS_RS19tuningParameterInfoENS0_15TuningParameterERNS0_19TuningParameterInfoE
	beqz.n	a10, .L1198
	l8ui	a8, sp, 112
	beqz.n	a8, .L1198
	l16ui	a8, sp, 106
	l16ui	a10, sp, 48
	sub	a8, a8, a10
	nsau	a8, a8
	srli	a8, a8, 5
	or	a2, a2, a8
.L1198:
	addi.n	a9, a6, 1
	extui	a6, a9, 0, 8
.L1197:
	mov.n	a10, a4
	call8	_ZN14MotorControlRS6ESS_RS16tuningFieldCountENS0_11DriverGroupE
	bltu	a6, a10, .L1199
	addi.n	a7, a7, 1
	bnei	a7, 4, .L1200
	j	.L1193
.L1196:
	mov.n	a11, sp
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_114checkAxisWriteERKNS_3AppERKN21MotorControlRSExample3Rtu10BusRequestE
	mov.n	a2, a10
	beqz.n	a10, .L1176
.L1175:
	retw.n
.LFE2192:
	.size	_ZN12_GLOBAL__N_115admitDriverStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedDriverEy, .-_ZN12_GLOBAL__N_115admitDriverStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedDriverEy
	.section	.text._ZN14MotorControlRS10UnitConfigC2Ev,"axG",@progbits,_ZN14MotorControlRS10UnitConfigC5Ev,comdat
	.literal_position
	.literal .LC653, -1598689907
	.literal .LC654, 1051772663
	.align	4
	.weak	_ZN14MotorControlRS10UnitConfigC2Ev
	.type	_ZN14MotorControlRS10UnitConfigC2Ev, @function
_ZN14MotorControlRS10UnitConfigC2Ev:
.LFB267:
	entry	sp, 32
.LCFI87:
	l32r	a10, .LC653
	l32r	a11, .LC654
	movi.n	a8, 0
	movi.n	a9, 1
	s32i	a8, a2, 0
	s32i	a9, a2, 4
	s32i	a8, a2, 8
	s32i	a8, a2, 12
	s32i	a9, a2, 16
	s32i	a8, a2, 20
	s32i	a8, a2, 24
	s32i	a9, a2, 28
	s32i	a8, a2, 32
	s32i	a8, a2, 36
	s32i	a9, a2, 40
	s32i	a8, a2, 44
	s32i	a8, a2, 48
	s32i	a9, a2, 52
	s32i	a8, a2, 56
	s32i	a8, a2, 60
	s32i	a8, a2, 64
	s32i	a9, a2, 68
	s32i	a9, a2, 72
	s32i	a10, a2, 80
	s32i	a11, a2, 84
	s32i	a8, a2, 88
	s16i	a8, a2, 92
	retw.n
.LFE267:
	.size	_ZN14MotorControlRS10UnitConfigC2Ev, .-_ZN14MotorControlRS10UnitConfigC2Ev
	.weak	_ZN14MotorControlRS10UnitConfigC1Ev
	.set	_ZN14MotorControlRS10UnitConfigC1Ev,_ZN14MotorControlRS10UnitConfigC2Ev
	.section	.text._ZN14MotorControlRS17ActiveSerialTupleC2Ev,"axG",@progbits,_ZN14MotorControlRS17ActiveSerialTupleC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS17ActiveSerialTupleC2Ev
	.type	_ZN14MotorControlRS17ActiveSerialTupleC2Ev, @function
_ZN14MotorControlRS17ActiveSerialTupleC2Ev:
.LFB291:
	entry	sp, 32
.LCFI88:
	movi.n	a8, 0
	s8i	a8, a2, 0
	movi.n	a8, 0
	s32i	a8, a2, 4
	s16i	a8, a2, 8
	s8i	a8, a2, 10
	retw.n
.LFE291:
	.size	_ZN14MotorControlRS17ActiveSerialTupleC2Ev, .-_ZN14MotorControlRS17ActiveSerialTupleC2Ev
	.weak	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	.set	_ZN14MotorControlRS17ActiveSerialTupleC1Ev,_ZN14MotorControlRS17ActiveSerialTupleC2Ev
	.section	.text._ZN21MotorControlRSExample14RuntimeWitness5beginEv,"axG",@progbits,_ZN21MotorControlRSExample14RuntimeWitness5beginEv,comdat
	.literal_position
	.literal .LC655, _ZN21MotorControlRSExample14RuntimeWitnessL8retainedE
	.literal .LC656, 1296257585
	.literal .LC657, _ZN21MotorControlRSExample14RuntimeWitnessL8previousE
	.align	4
	.weak	_ZN21MotorControlRSExample14RuntimeWitness5beginEv
	.type	_ZN21MotorControlRSExample14RuntimeWitness5beginEv, @function
_ZN21MotorControlRSExample14RuntimeWitness5beginEv:
.LFB297:
	entry	sp, 32
.LCFI89:
	l32r	a7, .LC655
	l32r	a6, .LC656
	memw
	l32i	a8, a7, 0
	l32r	a10, .LC657
	bne	a8, a6, .L1308
	memw
	l32i	a8, a7, 4
	beqz.n	a8, .L1308
	memw
	l32i	a8, a7, 4
	movi.n	a9, 0xb
	bltu	a9, a8, .L1308
	memw
	l32i	a14, a7, 4
	memw
	l32i	a13, a7, 8
	memw
	l32i	a12, a7, 12
	memw
	l32i	a11, a7, 16
	memw
	l32i	a9, a7, 20
	memw
	l32i	a8, a7, 24
	s32i	a6, a10, 0
	s32i	a14, a10, 4
	s32i	a13, a10, 8
	s32i	a12, a10, 12
	s32i	a11, a10, 16
	s32i	a9, a10, 20
	s32i	a8, a10, 24
	j	.L1309
.L1308:
	movi.n	a12, 0x1c
	movi.n	a11, 0
	call8	memset
.L1309:
	movi.n	a8, 0
	memw
	s32i	a8, a7, 0
	movi.n	a9, 1
	memw
	s32i	a9, a7, 4
	memw
	s32i	a8, a7, 8
	memw
	s32i	a8, a7, 12
	memw
	s32i	a8, a7, 16
	memw
	s32i	a8, a7, 20
	memw
	s32i	a8, a7, 24
	memw
	s32i	a6, a7, 0
	retw.n
.LFE297:
	.size	_ZN21MotorControlRSExample14RuntimeWitness5beginEv, .-_ZN21MotorControlRSExample14RuntimeWitness5beginEv
	.section	.rodata._Z18esp_task_wdt_resetv.str1.1,"aMS",@progbits,1
.LC659:
	.string	"hardware.watchdogSubscribed"
.LC661:
	.string	"esp_err_t esp_task_wdt_reset()"
.LC663:
	.string	"C:\\Users\\Honza\\Documents\\Projects\\MotorControl-RS\\test\\fakes\\esp32_uart/esp_task_wdt.h"
	.section	.text._Z18esp_task_wdt_resetv,"axG",@progbits,_Z18esp_task_wdt_resetv,comdat
	.literal_position
	.literal .LC658, hardware
	.literal .LC660, .LC659
	.literal .LC662, .LC661
	.literal .LC664, .LC663
	.align	4
	.weak	_Z18esp_task_wdt_resetv
	.type	_Z18esp_task_wdt_resetv, @function
_Z18esp_task_wdt_resetv:
.LFB1452:
	entry	sp, 32
.LCFI90:
	l32r	a8, .LC658
	addmi	a9, a8, 0x100
	l8ui	a9, a9, 89
	bnez.n	a9, .L1315
	l32r	a13, .LC660
	l32r	a12, .LC662
	l32r	a10, .LC664
	movi.n	a11, 0x18
	call8	__assert_func
.L1315:
	l32i	a9, a8, 360
	l32i	a10, a8, 0
	l32i	a11, a8, 4
	addi.n	a9, a9, 1
	l32i	a2, a8, 356
	s32i	a9, a8, 360
	s32i	a10, a8, 376
	s32i	a11, a8, 380
	retw.n
.LFE1452:
	.size	_Z18esp_task_wdt_resetv, .-_Z18esp_task_wdt_resetv
	.section	.text._ZN21MotorControlRSExample13OwnerWatchdog5beginEv,"axG",@progbits,_ZN21MotorControlRSExample13OwnerWatchdog5beginEv,comdat
	.literal_position
	.literal .LC665, _ZN21MotorControlRSExample13OwnerWatchdogL10subscribedE
	.literal .LC666, _ZN21MotorControlRSExample13OwnerWatchdogL5errorE
	.literal .LC667, _ZN21MotorControlRSExample13OwnerWatchdogL14completedLoopsE
	.literal .LC669, _ZN21MotorControlRSExample13OwnerWatchdogL10lastFeedUsE
	.literal .LC670, _ZN21MotorControlRSExample13OwnerWatchdogL11resetReasonE
	.literal .LC671, hardware
	.align	4
	.weak	_ZN21MotorControlRSExample13OwnerWatchdog5beginEv
	.type	_ZN21MotorControlRSExample13OwnerWatchdog5beginEv, @function
_ZN21MotorControlRSExample13OwnerWatchdog5beginEv:
.LFB1454:
	entry	sp, 32
.LCFI91:
	l32r	a14, .LC665
	movi.n	a8, 0
	s8i	a8, a14, 0
	l32r	a8, .LC667
	movi.n	a11, 0
	movi.n	a9, 0
	s32i	a11, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC669
	l32r	a7, .LC666
	s32i	a11, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC671
	l32r	a9, .LC670
	l32i	a11, a8, 384
	movi.n	a10, 0
	s32i	a11, a9, 0
	addmi	a9, a8, 0x100
	l8ui	a12, a9, 88
	s32i	a10, a7, 0
	movi	a11, 0x103
	beqz.n	a12, .L1317
	l8ui	a12, a9, 89
	movi	a11, 0x105
	movnez	a11, a10, a12
.L1317:
	movi	a15, 0x88
	addmi	a15, a15, 0x1300
	s32i	a15, a8, 364
	l32i	a10, a8, 348
	movi.n	a12, 1
	beqz.n	a11, .L1318
	movi	a13, -0x105
	add.n	a13, a11, a13
	beqz.n	a13, .L1318
	s32i	a12, a8, 368
	s8i	a12, a9, 90
	beqz.n	a10, .L1319
.L1322:
	movi.n	a2, 0
	j	.L1320
.L1319:
	s8i	a12, a9, 88
	j	.L1321
.L1318:
	movi.n	a12, 1
	s32i	a12, a8, 368
	s8i	a12, a9, 90
	bnez.n	a10, .L1322
	s8i	a12, a9, 88
	beqz.n	a11, .L1323
.L1321:
	l32i	a10, a8, 352
	movi.n	a2, 0
	bnez.n	a10, .L1320
	movi.n	a8, 1
	s8i	a8, a9, 89
.L1323:
	movi.n	a8, 1
	s8i	a8, a14, 0
	call8	_Z18esp_task_wdt_resetv
	nsau	a2, a10
	srli	a2, a2, 5
.L1320:
	s32i	a10, a7, 0
	retw.n
.LFE1454:
	.size	_ZN21MotorControlRSExample13OwnerWatchdog5beginEv, .-_ZN21MotorControlRSExample13OwnerWatchdog5beginEv
	.section	.text._ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE,"axG",@progbits,_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE,comdat
	.align	4
	.weak	_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	.type	_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE, @function
_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE:
.LFB1456:
	entry	sp, 96
.LCFI92:
	movi.n	a12, 0x12
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	extui	a3, a3, 0, 8
	addi	a11, sp, 16
	mov.n	a10, a3
	call8	_ZN14MotorControlRS24getDiscoveryCapabilitiesENS_12DriveProfileERNS_21DiscoveryCapabilitiesE
	s32i	a11, sp, 52
	s32i	a12, sp, 56
	extui	a8, a10, 0, 8
	bnez.n	a8, .L1338
	l32i	a8, sp, 104
	l32i	a9, sp, 100
	s32i	a8, sp, 8
	l32i	a8, sp, 96
	s32i	a9, sp, 4
	s32i	a8, sp, 0
	mov.n	a14, a6
	mov.n	a15, a7
	mov.n	a12, a5
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZN14MotorControlRS6ESS_RS12prepareProbeERNS0_13PreparedProbeERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	s32i	a10, sp, 36
	s32i	a11, sp, 40
	s32i	a12, sp, 44
	j	.L1339
.L1338:
	l32i	a11, sp, 52
	l32i	a9, sp, 56
	s32i	a10, sp, 36
	s32i	a11, sp, 40
	s32i	a9, sp, 44
.L1339:
	l32i	a2, sp, 36
	l32i	a3, sp, 40
	l32i	a4, sp, 44
	movi.n	a5, 0
	retw.n
.LFE1456:
	.size	_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE, .-_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	.text
	.literal_position
	.literal .LC675, 53807
	.literal .LC676, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC677, 45697
	.literal .LC678, 45698
	.literal .LC679, _ZN12_GLOBAL__N_14uartE
	.literal .LC680, 757624
	.literal .LC681, 101004
	.literal .LC683, 9040
	.literal .LC684, 772456
	.literal .LC685, 45688
	.literal .LC686, 45756
	.literal .LC687, 45752
	.literal .LC688, _ZN12_GLOBAL__N_110checkProbeERKN21MotorControlRSExample3Rtu11ExpectationEPKhj
	.literal .LC691, 101000
	.literal .LC692, 45700
	.literal .LC693, 757628
	.literal .LC694, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_19startReadEPvmhRmb, @function
_ZN12_GLOBAL__N_19startReadEPvmhRmb:
.LFB2080:
	entry	sp, 304
.LCFI93:
	s32i	a6, sp, 244
	movi	a6, 0x7f7
	slli	a6, a6, 5
	add.n	a6, a2, a6
	l32i	a8, a6, 152
	l32i	a9, a6, 156
	s32i	a3, sp, 256
	s32i	a5, sp, 260
	or	a8, a8, a9
	mov.n	a7, a2
	movi.n	a2, 1
	bnez.n	a8, .L1341
	l32r	a8, .LC675
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1341
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L1341
	l32r	a8, .LC676
	movi.n	a2, 3
	l8ui	a8, a8, 0
	beqz.n	a8, .L1341
	l32r	a8, .LC677
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1342
.L1344:
	movi.n	a2, 2
	j	.L1341
.L1342:
	l32r	a8, .LC678
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1344
	l8ui	a8, a6, 137
	bnez.n	a8, .L1344
	l32r	a3, .LC679
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	s32i	a10, sp, 252
	mov.n	a10, a6
	mov.n	a5, a11
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1344
	mov.n	a10, a3
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1344
	l32r	a8, .LC680
	add.n	a8, a7, a8
	l32i	a2, a8, 0
	beqz.n	a2, .L1345
	l32r	a8, .LC681
	movi.n	a9, 0
	l32r	a10, .LC683
	s32i	a9, sp, 240
	add.n	a8, a7, a8
	movi.n	a9, 8
	loop	a9, .L1351_LEND
.L1351:
	l32i	a11, a8, 0
	bnez.n	a11, .L1346
	movi	a12, 0x68
	addi	a10, sp, 16
	call8	memset
	l32r	a8, .LC694
	l32i	a9, sp, 252
	s32i	a5, sp, 248
	add.n	a3, a9, a8
	bgeu	a3, a8, .L1348
	addi.n	a8, a5, 1
	s32i	a8, sp, 248
.L1348:
	l32i	a8, sp, 244
	bnez.n	a8, .L1349
	j	.L1375
.L1346:
	l32i	a11, sp, 240
	add.n	a8, a8, a10
	addi.n	a11, a11, 1
	s32i	a11, sp, 240
	.L1351_LEND:
	j	.L1352
.L1349:
	addi	a8, sp, 16
	movi	a13, 0xcc
	add.n	a13, a8, a13
	movi.n	a14, 8
	movi.n	a12, 0x10
	movi	a11, 0x130
	mov.n	a10, a4
	s32i	a13, sp, 16
	call8	_ZN14MotorControlRS6ESS_RS18buildReadRegistersEhttPhj
	s32i	a10, sp, 20
	movi.n	a2, 0x10
	movi	a9, 0x130
	j	.L1353
.L1375:
	addi	a9, sp, 16
	movi	a8, 0xcc
	add.n	a8, a9, a8
	movi.n	a12, 0x40
	movi.n	a11, 0
	addi	a10, sp, 120
	s32i	a8, sp, 16
	s32i	a8, sp, 264
	call8	memset
	l32r	a9, .LC684
	l32r	a10, .LC685
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	add.n	a10, a7, a10
	s32i	a9, sp, 216
	s32i	a4, sp, 208
	s8i	a4, sp, 212
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	addi	a8, sp, 16
	movi	a9, 0xa8
	add.n	a9, a8, a9
	l32i	a8, sp, 248
	s32i	a12, sp, 192
	s32i	a8, sp, 4
	l32i	a14, sp, 252
	addi	a8, sp, 16
	movi	a12, 0xc0
	s32i	a10, sp, 184
	s32i	a11, sp, 188
	mov.n	a13, a2
	add.n	a12, a8, a12
	s32i	a9, sp, 8
	s32i	a3, sp, 0
	mov.n	a15, a5
	movi.n	a11, 0
	addi	a10, sp, 120
	call8	_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	s32i	a10, sp, 196
	s32i	a11, sp, 200
	s32i	a12, sp, 204
	extui	a10, a10, 0, 8
	l32i	a8, sp, 264
	movi.n	a2, 8
	bnez.n	a10, .L1341
.L1355:
	l32i	a2, sp, 180
	addi	a9, sp, 120
	mov.n	a12, a2
	addi	a11, a9, 52
	mov.n	a10, a8
	call8	memcpy
	movi.n	a9, 0
	s32i	a2, sp, 20
	movi.n	a2, 1
.L1353:
	mov.n	a10, a2
	s32i	a9, sp, 264
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
	l32r	a8, .LC686
	l32i	a9, sp, 264
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 24
	s32i	a8, sp, 28
	l32r	a8, .LC687
	s32i	a3, sp, 40
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s8i	a4, sp, 70
	s32i	a8, sp, 32
	l32i	a8, sp, 248
	s16i	a9, sp, 64
	s32i	a8, sp, 44
	movi.n	a8, 3
	s8i	a8, sp, 71
	l32r	a8, .LC684
	s16i	a2, sp, 66
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a4, sp, 56
	s32i	a8, sp, 60
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32i	a8, sp, 244
	s32i	a10, sp, 72
	s32i	a11, sp, 76
	bnez.n	a8, .L1356
	l32r	a8, .LC688
	s32i	a8, sp, 76
.L1356:
	movi.n	a8, 0
	l32i	a12, sp, 252
	addi	a3, sp, 120
	s32i	a8, sp, 120
	s32i	a8, sp, 124
	s32i	a8, sp, 128
	s32i	a8, sp, 132
	mov.n	a14, a3
	mov.n	a13, a5
	addi	a11, sp, 16
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	mov.n	a2, a10
	beqi	a10, 4, .L1352
	bgeui	a10, 5, .L1357
	beqz.n	a10, .L1358
	bnei	a10, 3, .L1363
	movi.n	a2, 5
	j	.L1341
.L1357:
	beqi	a10, 5, .L1345
	j	.L1363
.L1352:
	movi.n	a2, 6
	j	.L1341
.L1345:
	movi.n	a2, 7
	j	.L1341
.L1358:
	l32r	a8, .LC683
	l32i	a9, sp, 240
	l32r	a11, .LC685
	mul16u	a6, a9, a8
	l32r	a8, .LC691
	add.n	a11, a7, a11
	add.n	a6, a6, a8
	add.n	a6, a7, a6
	movi.n	a12, 5
	addi.n	a10, a6, 12
	call8	memcpy
	l32r	a8, .LC692
	l32r	a9, .LC680
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	add.n	a9, a7, a9
	s32i	a8, a6, 20
	l32i	a8, a9, 0
	l32i	a11, sp, 120
	addi.n	a10, a8, 1
	s32i	a10, a9, 0
	l32i	a9, sp, 256
	l32i	a10, a3, 4
	s32i	a9, a6, 8
	s32i	a11, a6, 32
	s32i	a10, a6, 36
	l32r	a9, .LC693
	l32i	a11, a3, 8
	l32i	a10, a3, 12
	s32i	a8, a6, 4
	s8i	a4, a6, 24
	s32i	a11, a6, 40
	s32i	a10, a6, 44
	add.n	a7, a7, a9
	l32i	a9, sp, 260
	s32i	a8, a7, 0
	s32i	a8, a9, 0
	l32i	a8, sp, 40
	l32i	a9, sp, 44
	s32i	a8, a6, 56
	movi.n	a8, 1
	s8i	a8, a6, 0
	l32i	a8, sp, 244
	s32i	a9, a6, 60
	s8i	a8, a6, 66
	j	.L1341
.L1363:
	movi.n	a2, 4
.L1341:
	retw.n
.LFE2080:
	.size	_ZN12_GLOBAL__N_19startReadEPvmhRmb, .-_ZN12_GLOBAL__N_19startReadEPvmhRmb
	.align	4
	.type	_ZN12_GLOBAL__N_111captureReadEPvmhRm, @function
_ZN12_GLOBAL__N_111captureReadEPvmhRm:
.LFB2082:
	entry	sp, 32
.LCFI94:
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a13, a5
	movi.n	a14, 1
	extui	a12, a4, 0, 8
	call8	_ZN12_GLOBAL__N_19startReadEPvmhRmb
	mov.n	a2, a10
	retw.n
.LFE2082:
	.size	_ZN12_GLOBAL__N_111captureReadEPvmhRm, .-_ZN12_GLOBAL__N_111captureReadEPvmhRm
	.align	4
	.type	_ZN12_GLOBAL__N_15probeEPvmhRm, @function
_ZN12_GLOBAL__N_15probeEPvmhRm:
.LFB2081:
	entry	sp, 32
.LCFI95:
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a13, a5
	movi.n	a14, 0
	extui	a12, a4, 0, 8
	call8	_ZN12_GLOBAL__N_19startReadEPvmhRmb
	mov.n	a2, a10
	retw.n
.LFE2081:
	.size	_ZN12_GLOBAL__N_15probeEPvmhRm, .-_ZN12_GLOBAL__N_15probeEPvmhRm
	.literal_position
	.literal .LC695, 53696
	.literal .LC696, 58992
	.literal .LC697, 65248
	.literal .LC698, _ZN12_GLOBAL__N_14uartE
	.literal .LC699, 59008
	.literal .LC700, 53816
	.literal .LC701, 58308
	.literal .LC702, 58296
	.literal .LC703, 58392
	.literal .LC704, 54056
	.literal .LC705, 58232
	.literal .LC706, 53880
	.literal .LC707, 58996
	.literal .LC708, 59000
	.literal .LC710, 53700
	.literal .LC711, 45672
	.literal .LC712, 757624
	.literal .LC713, 45688
	.literal .LC714, 58284
	.literal .LC715, 58292
	.literal .LC716, 45756
	.literal .LC717, 45752
	.literal .LC718, 58328
	.align	4
	.type	_ZN12_GLOBAL__N_116serviceDiscoveryERNS_3AppEy, @function
_ZN12_GLOBAL__N_116serviceDiscoveryERNS_3AppEy:
.LFB2355:
	entry	sp, 304
.LCFI96:
	s32i	a4, sp, 240
	l32r	a4, .LC695
	add.n	a8, a2, a4
	l8ui	a3, a8, 111
	beqz.n	a3, .L1379
	l8ui	a8, a8, 104
	beqi	a8, 4, .L1379
	l32r	a8, .LC696
	add.n	a8, a2, a8
	s32i	a8, sp, 248
	l32i	a8, a8, 0
	beqz.n	a8, .L1382
	l32r	a8, .LC697
	l32i	a11, sp, 248
	add.n	a8, a2, a8
	mov.n	a10, a8
	s32i	a8, sp, 244
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a6, a10
	beqz.n	a10, .L1379
	l32i	a10, sp, 244
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	mov.n	a7, a10
	bnez.n	a10, .L1383
	l32r	a10, .LC698
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	mov.n	a7, a10
.L1383:
	l32r	a8, .LC699
	add.n	a9, a2, a4
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	l8ui	a4, a9, 108
	s32i	a8, sp, 260
	beqz.n	a8, .L1384
	addi.n	a3, a4, -1
	slli	a4, a3, 4
	add.n	a4, a4, a3
	l32r	a9, .LC700
	addx4	a4, a4, a3
	slli	a4, a4, 3
	add.n	a9, a4, a9
	add.n	a8, a2, a9
	l32r	a9, .LC701
	movi.n	a12, 0x40
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	movi.n	a11, 0
	addi	a10, sp, 16
	s32i	a8, sp, 252
	s32i	a9, sp, 256
	call8	memset
	l32i	a9, sp, 256
	l8ui	a10, a6, 112
	s32i	a9, sp, 28
	l32i	a8, sp, 260
	movi.n	a9, 0
	beqi	a10, 1, .L1386
	l8ui	a10, a6, 105
	movi.n	a9, 1
	bnei	a10, 5, .L1386
	movi.n	a9, 2
.L1386:
	mov.n	a11, a6
	s8i	a9, sp, 33
	addi	a10, sp, 16
	s32i	a8, sp, 260
	call8	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	l32r	a9, .LC702
	l32i	a12, sp, 240
	add.n	a9, a2, a9
	mov.n	a10, a9
	mov.n	a13, a5
	addi	a11, sp, 16
	s32i	a9, sp, 256
	movi.n	a6, 0
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	movi.n	a14, 1
	s32i	a10, sp, 120
	s32i	a11, sp, 124
	extui	a10, a10, 0, 8
	mov.n	a11, a6
	movnez	a11, a14, a10
	l32i	a8, sp, 252
	or	a10, a7, a11
	l32r	a11, .LC703
	extui	a7, a10, 0, 8
	movi	a10, 0x198
	add.n	a10, a8, a10
	s32i	a12, sp, 128
	add.n	a11, a2, a11
	movi	a12, 0x71
	call8	memcpy
	l32r	a10, .LC704
	add.n	a11, a4, a10
	l32i	a10, sp, 256
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS11getIdentityERKNS0_11ReadContextERNS0_19IdentityObservationE
	s32i	a12, sp, 128
	slli	a9, a3, 4
	l32r	a12, .LC695
	s32i	a11, sp, 124
	add.n	a11, a9, a3
	add.n	a13, a2, a12
	addx4	a11, a11, a3
	addx8	a11, a11, a13
	s32i	a10, sp, 120
	movi	a13, 0x299
	extui	a10, a10, 0, 8
	movi.n	a14, 1
	add.n	a13, a11, a13
	moveqz	a6, a14, a10
	s8i	a6, a13, 0
	movi.n	a8, 0
	bnez.n	a10, .L1387
	l16ui	a15, a11, 376
	l16ui	a13, a11, 220
	l32i	a8, sp, 260
	bne	a15, a13, .L1387
	l16ui	a8, a11, 380
	l8ui	a11, a11, 128
	sub	a11, a8, a11
	mov.n	a8, a10
	movnez	a8, a14, a11
	j	.L1387
.L1387:
	add.n	a9, a9, a3
	add.n	a12, a2, a12
	addx4	a9, a9, a3
	addx8	a9, a9, a12
	movi	a10, 0x29a
	add.n	a9, a9, a10
	s8i	a8, a9, 0
	l32r	a8, .LC699
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	movi.n	a8, 1
	s8i	a8, a12, 104
	j	.L1388
.L1384:
	addi.n	a8, a4, 1
	s8i	a8, a9, 108
	slli	a8, a4, 4
	add.n	a8, a8, a4
	l32r	a11, .LC705
	addx4	a8, a8, a4
	addx8	a8, a8, a9
	movi.n	a12, 0x40
	add.n	a11, a2, a11
	addi	a10, a8, 120
	s32i	a8, sp, 252
	call8	memcpy
	l32i	a8, sp, 252
	movi.n	a12, 0x40
	l32i	a8, a8, 136
	movi.n	a11, 0
	addi	a10, sp, 16
	s32i	a8, sp, 252
	call8	memset
	l32i	a8, sp, 252
	l8ui	a9, a6, 112
	s32i	a8, sp, 28
	movi.n	a8, 0
	beqi	a9, 1, .L1390
	l8ui	a9, a6, 105
	movi.n	a8, 1
	bnei	a9, 5, .L1390
	movi.n	a8, 2
.L1390:
	s8i	a8, sp, 33
	mov.n	a11, a6
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	slli	a10, a4, 4
	add.n	a10, a10, a4
	l32r	a8, .LC700
	l32r	a14, .LC706
	addx4	a10, a10, a4
	slli	a10, a10, 3
	add.n	a14, a10, a14
	l32i	a12, sp, 240
	add.n	a10, a10, a8
	add.n	a14, a2, a14
	mov.n	a13, a5
	addi	a11, sp, 16
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS10checkProbeERKNS0_13PreparedProbeERKNS_9ReadEventEyRNS0_16ProbeObservationE
	addi	a9, sp, 16
	movi	a8, 0xa4
	add.n	a8, a9, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	s32i	a10, sp, 168
	s32i	a11, sp, 172
	s32i	a12, sp, 176
	s32i	a10, sp, 120
	s32i	a11, sp, 124
	s32i	a12, sp, 128
	extui	a9, a10, 0, 8
	l32r	a8, .LC695
	beqz.n	a9, .L1391
	slli	a9, a4, 4
	add.n	a9, a9, a4
	add.n	a13, a2, a8
	addx4	a9, a9, a4
	addx8	a9, a9, a13
	movi	a13, 0xd0
	add.n	a13, a9, a13
	s32i	a10, a13, 16
	s32i	a11, a13, 20
	s32i	a12, a13, 24
	movi.n	a10, 8
	s8i	a10, a9, 216
	mov.n	a7, a3
	j	.L1392
.L1391:
	l8ui	a11, sp, 33
	bnei	a11, 1, .L1392
	l8ui	a10, a6, 112
	bnei	a10, 2, .L1394
	slli	a9, a4, 4
	add.n	a9, a9, a4
	add.n	a10, a2, a8
	addx4	a9, a9, a4
	addx8	a9, a9, a10
	movi.n	a10, 5
	j	.L1471
.L1394:
	movi.n	a12, 0x12
	beq	a10, a12, .L1395
	l8ui	a12, a6, 105
	addi	a13, a12, -6
	moveqz	a9, a11, a13
	bnez.n	a9, .L1395
	moveqz	a9, a11, a12
	beqz.n	a9, .L1396
.L1395:
	slli	a9, a4, 4
	add.n	a9, a9, a4
	add.n	a10, a2, a8
	addx4	a9, a9, a4
	addx8	a9, a9, a10
	movi.n	a10, 7
	j	.L1471
.L1396:
	bnei	a10, 4, .L1398
	slli	a9, a4, 4
	add.n	a9, a9, a4
	add.n	a10, a2, a8
	addx4	a9, a9, a4
	addx8	a9, a9, a10
	movi.n	a10, 3
	j	.L1471
.L1398:
	addi	a12, a10, -17
	moveqz	a9, a11, a12
	bnez.n	a9, .L1438
	addi	a10, a10, -5
	moveqz	a9, a11, a10
	beqz.n	a9, .L1392
.L1438:
	slli	a9, a4, 4
	add.n	a9, a9, a4
	add.n	a10, a2, a8
	addx4	a9, a9, a4
	addx8	a9, a9, a10
	movi.n	a10, 9
.L1471:
	s8i	a10, a9, 216
.L1392:
	add.n	a8, a2, a8
	l8ui	a9, a8, 51
	beqz.n	a9, .L1388
	slli	a9, a4, 4
	add.n	a9, a9, a4
	addx4	a9, a9, a4
	addx8	a9, a9, a8
	l8ui	a9, a9, 216
	bnei	a9, 1, .L1388
	bnez.n	a7, .L1388
	l8ui	a9, a8, 114
	bnez.n	a9, .L1388
	movi.n	a9, 2
	s8i	a9, a8, 104
.L1388:
	l32i	a11, sp, 248
	l32i	a10, sp, 244
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	l32r	a8, .LC696
	movi.n	a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC707
	movi.n	a11, 6
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC708
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s32i	a9, a8, 4
	bnez.n	a7, .L1472
.L1401:
	l32r	a8, .LC695
	movi.n	a11, 2
	add.n	a9, a2, a8
	l8ui	a10, a9, 114
	bnez.n	a10, .L1472
.L1402:
	l32i	a10, a9, 92
	bltu	a5, a10, .L1403
	bne	a10, a5, .L1439
	l32i	a9, a9, 88
	l32i	a10, sp, 240
	bltu	a10, a9, .L1403
.L1439:
	movi.n	a11, 3
	j	.L1472
.L1403:
	add.n	a8, a2, a8
	l8ui	a9, a8, 104
	beqi	a9, 2, .L1382
	l8ui	a9, a8, 110
	l8ui	a10, a8, 2
	bgeu	a9, a10, .L1406
	addi.n	a9, a9, 1
	j	.L1473
.L1406:
	l8ui	a9, a8, 109
	l8ui	a10, a8, 36
	addi.n	a9, a9, 1
	bge	a9, a10, .L1407
	s8i	a9, a8, 109
	l8ui	a9, a8, 1
.L1473:
	s8i	a9, a8, 110
	j	.L1382
.L1407:
	movi.n	a11, 1
.L1472:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE
.L1382:
	l32r	a6, .LC695
	add.n	a8, a2, a6
	l8ui	a9, a8, 104
	bnei	a9, 3, .L1408
	j	.L1475
.L1408:
	l8ui	a10, a8, 114
	movi.n	a11, 2
	bnez.n	a10, .L1474
.L1410:
	l32i	a10, a8, 92
	bltu	a5, a10, .L1412
	bne	a10, a5, .L1440
	l32i	a8, a8, 88
	l32i	a10, sp, 240
	bltu	a10, a8, .L1412
.L1440:
	movi.n	a11, 3
	j	.L1474
.L1412:
	add.n	a8, a2, a6
	l16ui	a11, a8, 106
	l16ui	a10, a8, 48
	bltu	a11, a10, .L1414
	movi.n	a11, 4
	j	.L1474
.L1414:
	bnei	a9, 1, .L1415
	l8ui	a9, a8, 108
	l8ui	a8, a8, 50
	bltu	a9, a8, .L1415
	movi.n	a11, 5
.L1474:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE
	add.n	a8, a2, a6
	l8ui	a8, a8, 104
	beqi	a8, 3, .L1475
.L1415:
	l32r	a8, .LC697
	add.n	a4, a2, a8
	mov.n	a10, a4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L1417
.L1418:
	movi.n	a11, 6
.L1476:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE
.L1475:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116discoveryRestoreERNS_3AppE
	j	.L1379
.L1417:
	l32r	a7, .LC698
	mov.n	a10, a7
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1418
	l32i	a8, a4, 52
	bnei	a8, -1, .L1379
	l32i	a9, a4, 48
	bnez.n	a9, .L1379
	l8ui	a8, a4, 60
	beqi	a8, 1, .L1379
	movi	a8, 0xe4
	add.n	a8, sp, a8
	add.n	a3, a2, a6
	s8i	a9, a8, 8
	l8ui	a9, a3, 109
	l32r	a11, .LC710
	addx8	a9, a9, a2
	movi.n	a12, 5
	add.n	a11, a9, a11
	mov.n	a10, a8
	call8	memcpy
	l32r	a12, .LC711
	mov.n	a11, a10
	movi.n	a13, 1
	add.n	a12, a2, a12
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb
	beqi	a10, 1, .L1379
	movi.n	a11, 9
	bnez.n	a10, .L1476
.L1419:
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32i	a8, a3, 92
	s32i	a10, sp, 240
	l32i	a9, a3, 88
	mov.n	a5, a11
	bltu	a11, a8, .L1420
	bne	a8, a11, .L1441
	bltu	a10, a9, .L1420
.L1441:
	movi.n	a11, 3
	j	.L1476
.L1420:
	l32r	a10, .LC712
	movi.n	a11, 4
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a10, sp, 244
	beqz.n	a10, .L1476
.L1422:
	add.n	a10, a2, a6
	l32i	a11, a10, 40
	movi	a7, 0x3e8
	mull	a10, a7, a11
	muluh	a7, a7, a11
	l32i	a11, sp, 240
	add.n	a7, a7, a5
	add.n	a3, a10, a11
	bgeu	a3, a10, .L1423
	addi.n	a7, a7, 1
.L1423:
	bltu	a8, a7, .L1425
	bne	a7, a8, .L1424
	bgeu	a9, a3, .L1424
.L1425:
	mov.n	a3, a9
	mov.n	a7, a8
.L1424:
	add.n	a8, a2, a6
	l8ui	a9, a8, 110
	addi	a10, sp, 16
	movi	a6, 0xc8
	add.n	a6, a10, a6
	s8i	a9, a6, 4
	s32i	a9, a6, 0
	l32i	a9, a8, 60
	movi	a12, 0x68
	s32i	a9, a6, 8
	movi.n	a11, 0
	s32i	a8, sp, 248
	call8	memset
	movi.n	a12, 0x30
	movi.n	a11, 0
	addi	a10, sp, 120
	call8	memset
	l32i	a8, sp, 248
	l32r	a10, .LC713
	l8ui	a9, a8, 104
	bnei	a9, 2, .L1428
	l32r	a8, .LC702
	add.n	a10, a2, a10
	add.n	a8, a2, a8
	s32i	a8, sp, 248
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	addi	a9, sp, 16
	movi	a8, 0xbc
	s32i	a10, sp, 204
	s32i	a12, sp, 212
	add.n	a8, a9, a8
	l32i	a14, sp, 240
	l32i	a12, sp, 244
	l32i	a10, sp, 248
	s32i	a11, sp, 208
	s32i	a8, sp, 8
	s32i	a3, sp, 0
	s32i	a7, sp, 4
	mov.n	a15, a5
	mov.n	a11, a6
	call8	_ZN14MotorControlRS6ESS_RS15prepareIdentityERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	s32i	a10, sp, 192
	s32i	a11, sp, 196
	s32i	a12, sp, 200
	extui	a10, a10, 0, 8
	bnez.n	a10, .L1432
	l32i	a12, sp, 240
	l32i	a10, sp, 248
	addi	a14, sp, 120
	mov.n	a13, a5
	call8	_ZN14MotorControlRS6ESS_RS8nextReadERKNS0_11ReadContextEyRNS0_12PreparedReadE
	s32i	a10, sp, 180
	s32i	a11, sp, 184
	s32i	a12, sp, 188
	extui	a10, a10, 0, 8
	bnez.n	a10, .L1432
	addi	a8, sp, 120
	addi	a8, a8, 22
	s32i	a8, sp, 16
	movi.n	a10, 4
	l32i	a8, sp, 152
	j	.L1430
.L1428:
	l8ui	a8, a8, 0
	add.n	a10, a2, a10
	s32i	a8, sp, 248
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	s32i	a10, sp, 192
	addi	a9, sp, 16
	l32r	a10, .LC705
	movi	a8, 0xb0
	s32i	a11, sp, 196
	add.n	a8, a9, a8
	l32i	a14, sp, 240
	l32i	a13, sp, 244
	l32i	a11, sp, 248
	s32i	a12, sp, 200
	s32i	a8, sp, 8
	s32i	a3, sp, 0
	s32i	a7, sp, 4
	mov.n	a15, a5
	mov.n	a12, a6
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS12prepareProbeERNS_6ESS_RS13PreparedProbeENS_12DriveProfileERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	s32i	a10, sp, 180
	s32i	a11, sp, 184
	s32i	a12, sp, 188
	extui	a10, a10, 0, 8
	beqz.n	a10, .L1431
.L1432:
	movi.n	a11, 9
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112discoveryEndERNS_3AppEN21MotorControlRSExample5Probe16DiscoveryOutcomeE
	j	.L1379
.L1431:
	l32r	a8, .LC714
	movi.n	a10, 1
	add.n	a8, a2, a8
	s32i	a8, sp, 16
	l32r	a8, .LC715
	add.n	a8, a2, a8
	l32i	a8, a8, 0
.L1430:
	s32i	a8, sp, 20
	s16i	a10, sp, 66
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
	l32r	a8, .LC716
	addi	a9, sp, 16
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 24
	s32i	a8, sp, 28
	l32r	a8, .LC717
	s32i	a3, sp, 40
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a7, sp, 44
	s32i	a8, sp, 32
	movi	a8, 0xc8
	add.n	a8, a9, a8
	l8ui	a9, a8, 4
	s8i	a9, sp, 70
	l32i	a9, a8, 0
	l32i	a8, a8, 8
	s32i	a9, sp, 56
	s32i	a8, sp, 60
	movi.n	a8, 3
	s8i	a8, sp, 71
	movi.n	a8, 0
	s16i	a8, sp, 64
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32r	a14, .LC696
	l32i	a12, sp, 240
	s32i	a10, sp, 72
	s32i	a11, sp, 76
	add.n	a14, a2, a14
	mov.n	a13, a5
	addi	a11, sp, 16
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	addi	a8, a10, -3
	extui	a8, a8, 0, 8
	bltui	a8, 2, .L1379
	bnez.n	a10, .L1432
	l32r	a8, .LC712
	l32r	a11, .LC695
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	add.n	a11, a2, a11
	addi.n	a9, a9, 1
	s32i	a9, a8, 0
	l16ui	a8, a11, 106
	l8ui	a9, a11, 104
	addi.n	a8, a8, 1
	s16i	a8, a11, 106
	l32r	a8, .LC699
	addi	a13, a9, -2
	movi.n	a12, 1
	add.n	a8, a2, a8
	moveqz	a10, a12, a13
	s8i	a10, a8, 0
	bnei	a9, 2, .L1379
	l8ui	a8, a11, 108
	addi.n	a8, a8, -1
	slli	a9, a8, 4
	add.n	a9, a9, a8
	addx4	a9, a9, a8
	addx8	a9, a9, a11
	movi	a8, 0x298
	add.n	a8, a9, a8
	s8i	a12, a8, 0
	l32r	a8, .LC701
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a8, a9, 648
	l32r	a8, .LC718
	add.n	a8, a2, a8
	l32i	a10, a8, 0
	l32i	a11, a8, 4
	s32i	a10, a9, 656
	s32i	a11, a9, 660
.L1379:
	retw.n
.LFE2355:
	.size	_ZN12_GLOBAL__N_116serviceDiscoveryERNS_3AppEy, .-_ZN12_GLOBAL__N_116serviceDiscoveryERNS_3AppEy
	.section	.text._ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_,"axG",@progbits,_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	.type	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_, @function
_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_:
.LFB1715:
	entry	sp, 32
.LCFI97:
	l32i	a10, a2, 0
	l32i	a9, a3, 0
	mov.n	a8, a2
	movi.n	a2, 0
	bne	a10, a9, .L1478
	l8ui	a10, a8, 4
	l8ui	a9, a3, 4
	bne	a10, a9, .L1478
	l32i	a2, a8, 8
	l32i	a8, a3, 8
	sub	a2, a2, a8
	nsau	a2, a2
	srli	a2, a2, 5
.L1478:
	retw.n
.LFE1715:
	.size	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_, .-_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	.text
	.align	4
	.type	_ZN12_GLOBAL__N_121motionProfileEndpointERKNS_11MotionFactsERKNS_3App18MotionProfileStateE, @function
_ZN12_GLOBAL__N_121motionProfileEndpointERKNS_11MotionFactsERKNS_3App18MotionProfileStateE:
.LFB2105:
	entry	sp, 32
.LCFI98:
	mov.n	a8, a2
	l8ui	a2, a3, 1
	beqz.n	a2, .L1482
	l32i	a11, a8, 0
	l8ui	a10, a3, 6
	l8ui	a9, a11, 4
	movi.n	a2, 0
	bne	a10, a9, .L1482
	l32i	a10, a3, 12
	l32i	a9, a8, 28
	bne	a10, a9, .L1482
	l32i	a10, a3, 328
	l32i	a9, a8, 24
	bne	a10, a9, .L1482
	l32i	a7, a8, 4
	l32i	a8, a7, 12
	beqz.n	a8, .L1482
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a2, a10
	beqz.n	a10, .L1482
	movi	a10, 0x118
	movi.n	a12, 0x1e
	addi	a11, a7, 16
	add.n	a10, a3, a10
	call8	memcmp
	nsau	a2, a10
	srli	a2, a2, 5
.L1482:
	retw.n
.LFE2105:
	.size	_ZN12_GLOBAL__N_121motionProfileEndpointERKNS_11MotionFactsERKNS_3App18MotionProfileStateE, .-_ZN12_GLOBAL__N_121motionProfileEndpointERKNS_11MotionFactsERKNS_3App18MotionProfileStateE
	.align	4
	.type	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE, @function
_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE:
.LFB2107:
	entry	sp, 32
.LCFI99:
	l32i	a6, a2, 8
	mov.n	a10, a2
	mov.n	a11, a6
	call8	_ZN12_GLOBAL__N_121motionProfileEndpointERKNS_11MotionFactsERKNS_3App18MotionProfileStateE
	mov.n	a7, a2
	mov.n	a2, a10
	beqz.n	a10, .L1495
	l32i	a8, a7, 0
	l32i	a2, a8, 12
	l32i	a8, a6, 8
	sub	a2, a2, a8
	nsau	a2, a2
	srli	a2, a2, 5
.L1495:
	retw.n
.LFE2107:
	.size	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE, .-_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE
	.literal_position
	.literal .LC719, 771912
	.literal .LC720, 772456
	.literal .LC721, 45700
	.literal .LC722, 764504
	.literal .LC723, 757960
	.literal .LC724, 770856
	.literal .LC725, 625320
	.literal .LC726, 771920
	.align	4
	.type	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE, @function
_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE:
.LFB2108:
	entry	sp, 80
.LCFI100:
	l32r	a8, .LC719
	l32i	a9, a2, 0
	add.n	a8, a2, a8
	l8ui	a13, a8, 0
	l32r	a8, .LC720
	s8i	a13, sp, 16
	add.n	a8, a2, a8
	l32i	a12, a8, 0
	l32r	a8, .LC721
	s32i	a12, sp, 24
	add.n	a8, a2, a8
	l32i	a11, a8, 0
	movi	a8, 0x3e8
	mull	a10, a8, a9
	muluh	a8, a8, a9
	l32r	a9, .LC722
	s32i	a10, sp, 32
	add.n	a9, a2, a9
	s32i	a9, sp, 0
	l32r	a9, .LC723
	s32i	a8, sp, 36
	add.n	a9, a2, a9
	s32i	a9, sp, 4
	l32r	a9, .LC724
	movi.n	a8, 0
	add.n	a9, a2, a9
	s32i	a9, sp, 8
	l32r	a9, .LC725
	mov.n	a10, sp
	add.n	a9, a2, a9
	s32i	a9, sp, 12
	l32r	a9, .LC726
	s32i	a11, sp, 28
	add.n	a2, a2, a9
	s32i	a2, sp, 20
	s32i	a8, sp, 40
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE
	mov.n	a2, a10
	retw.n
.LFE2108:
	.size	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE, .-_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE
	.literal_position
	.literal .LC727, 770856
	.align	4
	.type	_ZN12_GLOBAL__N_118simpleProfileReadyERKNS_3AppEy, @function
_ZN12_GLOBAL__N_118simpleProfileReadyERKNS_3AppEy:
.LFB2240:
	entry	sp, 32
.LCFI101:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE
	mov.n	a7, a2
	mov.n	a2, a10
	beqz.n	a10, .L1501
	l32r	a8, .LC727
	add.n	a8, a7, a8
	l8ui	a2, a8, 3
	beqz.n	a2, .L1501
	l8ui	a2, a8, 0
	bnez.n	a2, .L1508
	l8ui	a9, a8, 4
	bnez.n	a9, .L1501
	addmi	a9, a8, 0x100
	l8ui	a2, a9, 12
	beqz.n	a2, .L1501
	l32i	a10, a8, 204
	l32i	a9, a8, 200
	bltu	a5, a10, .L1508
	bne	a10, a5, .L1509
	bltu	a4, a9, .L1508
.L1509:
	l32i	a12, a7, 0
	movi	a8, 0x3e8
	mull	a11, a8, a12
	muluh	a8, a8, a12
	or	a12, a11, a8
	beqz.n	a12, .L1501
	sub	a5, a5, a10
	bgeu	a4, a9, .L1504
	addi.n	a5, a5, -1
.L1504:
	sub	a4, a4, a9
	movi.n	a2, 1
	bltu	a5, a8, .L1505
	bne	a8, a5, .L1506
	bltu	a4, a11, .L1505
.L1506:
	movi.n	a2, 0
.L1505:
	extui	a2, a2, 0, 8
	j	.L1501
.L1508:
	movi.n	a2, 0
.L1501:
	retw.n
.LFE2240:
	.size	_ZN12_GLOBAL__N_118simpleProfileReadyERKNS_3AppEy, .-_ZN12_GLOBAL__N_118simpleProfileReadyERKNS_3AppEy
	.literal_position
	.literal .LC728, 813497
	.literal .LC729, 772456
	.literal .LC730, 772492
	.literal .LC731, 2707178
	.literal .LC732, 45700
	.literal .LC733, _ZN12_GLOBAL__N_1L23NO_START_SPEED_RELATIONE
	.align	4
	.type	_ZN12_GLOBAL__N_113memberCurrentERKNS_3AppERKNS0_11GroupMemberE, @function
_ZN12_GLOBAL__N_113memberCurrentERKNS_3AppERKNS0_11GroupMemberE:
.LFB2262:
	entry	sp, 80
.LCFI102:
	l32r	a8, .LC728
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1523
.L1525:
	movi.n	a2, 0
	j	.L1524
.L1523:
	l32i	a8, a3, 20
	beqz.n	a8, .L1525
	l32r	a8, .LC729
	add.n	a8, a2, a8
	l32i	a7, a8, 0
	l32i	a8, a3, 16
	bne	a8, a7, .L1525
	l8ui	a6, a3, 0
	l32r	a9, .LC730
	srli	a8, a6, 3
	add.n	a8, a2, a8
	add.n	a8, a8, a9
	l8ui	a9, a8, 0
	extui	a8, a6, 0, 3
	bbc	a9, a8, .L1525
	l32i	a8, a3, 204
	beqz.n	a8, .L1525
	addi.n	a5, a3, 8
	movi	a10, 0xc0
	mov.n	a11, a5
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L1525
	l16ui	a8, a3, 212
	bne	a8, a6, .L1525
	l32r	a8, .LC731
	l32i	a9, a3, 208
	bne	a9, a8, .L1525
	l32i	a8, a3, 372
	beqz.n	a8, .L1525
	movi	a6, 0x168
	add.n	a6, a3, a6
	mov.n	a11, a5
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L1525
	addmi	a8, a3, 0x900
	l8ui	a10, a8, 104
	l32r	a8, .LC732
	l32i	a9, a2, 0
	add.n	a8, a2, a8
	l32i	a11, a8, 0
	movi	a8, 0x3e8
	mull	a12, a8, a9
	muluh	a8, a8, a9
	movi	a9, 0x4a8
	add.n	a9, a3, a9
	s32i	a9, sp, 8
	movi	a9, 0x5f8
	add.n	a9, a3, a9
	s32i	a9, sp, 12
	l32r	a9, .LC733
	s8i	a10, sp, 16
	s32i	a8, sp, 36
	mov.n	a10, sp
	movi.n	a8, 0
	s32i	a5, sp, 0
	s32i	a6, sp, 4
	s32i	a9, sp, 20
	s32i	a7, sp, 24
	s32i	a11, sp, 28
	s32i	a12, sp, 32
	s32i	a8, sp, 40
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE
	beqz.n	a10, .L1525
	addmi	a3, a3, 0x400
	l8ui	a8, a3, 171
	beqz.n	a8, .L1525
	l8ui	a2, a3, 168
	movi.n	a8, 1
	xor	a2, a2, a8
	extui	a2, a2, 0, 8
.L1524:
	retw.n
.LFE2262:
	.size	_ZN12_GLOBAL__N_113memberCurrentERKNS_3AppERKNS0_11GroupMemberE, .-_ZN12_GLOBAL__N_113memberCurrentERKNS_3AppERKNS0_11GroupMemberE
	.literal_position
	.literal .LC734, 53807
	.literal .LC735, _ZN12_GLOBAL__N_14uartE
	.literal .LC736, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC738, 64907
	.literal .LC739, 65248
	.literal .LC740, 45697
	.literal .LC741, 45696
	.literal .LC742, 626184
	.literal .LC743, 626240
	.literal .LC744, 626282
	.literal .LC745, 757624
	.literal .LC746, 45700
	.literal .LC747, 772456
	.literal .LC749, 757960
	.literal .LC750, 45688
	.literal .LC752, 764504
	.literal .LC753, 46384
	.literal .LC755, 47864
	.literal .LC756, 45792
	.literal .LC757, 64912
	.literal .LC758, 64909
	.literal .LC759, 47880
	.literal .LC760, 47872
	.literal .LC761, 47881
	.literal .LC762, _ZN12_GLOBAL__N_122writeResponseConfirmedE
	.literal .LC764, 47848
	.literal .LC765, 45840
	.literal .LC766, 45852
	.literal .LC767, 45804
	.literal .LC768, 47900
	.literal .LC769, 64913
	.literal .LC771, 764508
	.literal .LC772, 764512
	.literal .LC773, 757768
	.literal .LC774, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_113communicationEPvPKN21MotorControlRSExample5Probe20CommunicationCommandERNS2_17CommunicationViewE, @function
_ZN12_GLOBAL__N_113communicationEPvPKN21MotorControlRSExample5Probe20CommunicationCommandERNS2_17CommunicationViewE:
.LFB2337:
	entry	sp, 96
.LCFI103:
	mov.n	a11, a4
	mov.n	a10, a2
	mov.n	a7, a2
	s32i	a4, sp, 48
	call8	_ZN12_GLOBAL__N_117communicationViewERKNS_3AppERN21MotorControlRSExample5Probe17CommunicationViewE
	beqz.n	a3, .L1552
	l32r	a8, .LC734
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1553
.L1556:
	movi.n	a2, 1
	j	.L1554
.L1553:
	l32r	a10, .LC735
	movi.n	a2, 3
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32r	a8, .LC736
	mov.n	a5, a10
	l8ui	a8, a8, 0
	mov.n	a6, a11
	beqz.n	a8, .L1554
	l8ui	a2, a3, 0
	beqz.n	a2, .L1552
	movi	a8, 0x3f5
	slli	a8, a8, 6
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L1556
	l32r	a8, .LC738
	add.n	a8, a7, a8
	l8ui	a4, a8, 0
	bnez.n	a4, .L1556
	l32r	a8, .LC739
	add.n	a10, a7, a8
	l32i	a8, a10, 152
	l32i	a10, a10, 156
	or	a8, a8, a10
	bnei	a2, 1, .L1557
	bnez.n	a8, .L1554
	l32r	a8, .LC740
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1554
	l32r	a8, .LC741
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1554
	l32r	a8, .LC739
	add.n	a8, a7, a8
	l32i	a10, a8, 52
	bnei	a10, -1, .L1554
	l32i	a8, a8, 48
	bnez.n	a8, .L1554
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L1554
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L1554
	l32r	a8, .LC742
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1554
	l32r	a8, .LC743
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L1562
	l32r	a8, .LC744
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1554
.L1562:
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L1554
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L1554
	l32r	a8, .LC745
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	s32i	a9, sp, 60
	beqz.n	a9, .L1591
	l32r	a8, .LC746
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqi	a8, -1, .L1591
	l32r	a8, .LC747
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqi	a8, -1, .L1591
	movi	a8, 0x16f
	slli	a8, a8, 7
	add.n	a14, a7, a8
	addmi	a8, a14, 0x300
	l8ui	a8, a8, 90
	beqz.n	a8, .L1592
	l32r	a8, .LC749
	mov.n	a10, a14
	add.n	a8, a7, a8
	mov.n	a11, a8
	movi	a12, 0x340
	s32i	a14, sp, 52
	s32i	a8, sp, 56
	call8	memcpy
	l32r	a10, .LC750
	addi	a4, sp, 28
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	s32i	a10, sp, 16
	movi	a10, 0x2eb
	slli	a10, a10, 6
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	addi	a11, sp, 16
	movi.n	a12, 0xb
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a10, .LC752
	add.n	a10, a7, a10
	l32i	a12, a10, 0
	l32i	a11, a10, 4
	l32i	a10, a10, 8
	s32i	a12, sp, 28
	s32i	a10, a4, 8
	l8ui	a10, a3, 10
	s32i	a11, a4, 4
	l32i	a11, sp, 56
	s8i	a10, sp, 32
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	l32i	a14, sp, 52
	l32i	a9, sp, 60
	bnez.n	a10, .L1563
	j	.L1567
.L1563:
	l32r	a12, .LC774
	addi.n	a13, a3, 2
	l32r	a3, .LC753
	add.n	a11, a5, a12
	add.n	a10, a7, a3
	mov.n	a8, a6
	bgeu	a11, a12, .L1564
	addi.n	a8, a6, 1
.L1564:
	s32i	a11, sp, 8
	s32i	a8, sp, 12
	mov.n	a11, a4
	s32i	a5, sp, 0
	s32i	a6, sp, 4
	mov.n	a12, a9
	call8	_ZN14MotorControlRS6ESS_RS20prepareCommunicationERNS0_20CommunicationContextERKNS_10ReadTargetEmRKNS0_20CommunicationRequestERKNS0_26CommunicationPrerequisitesEyy
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a4, a10, 0, 8
	bnez.n	a4, .L1567
	l32r	a14, .LC755
	l32r	a8, .LC739
	add.n	a14, a7, a14
	mov.n	a12, a5
	mov.n	a13, a6
	add.n	a10, a7, a8
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner18beginCommissioningEyRy
	beqz.n	a10, .L1554
	l32r	a10, .LC756
	movi	a12, 0x24c
	add.n	a11, a7, a3
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a8, .LC745
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	addi.n	a9, a9, 1
	s32i	a9, a8, 0
	l32r	a8, .LC757
	movi.n	a9, 1
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	l32r	a8, .LC758
	l32r	a9, .LC762
	add.n	a8, a7, a8
	s8i	a4, a8, 0
	l32r	a8, .LC759
	l8ui	a9, a9, 0
	add.n	a8, a7, a8
	s8i	a4, a8, 0
	l32r	a8, .LC760
	add.n	a8, a7, a8
	s32i	a4, a8, 0
	l32r	a8, .LC761
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	j	.L1637
.L1591:
	movi.n	a2, 7
	j	.L1554
.L1592:
	movi.n	a2, 3
	j	.L1554
.L1557:
	bnez.n	a8, .L1566
.L1567:
	movi.n	a2, 8
	j	.L1554
.L1566:
	l32r	a8, .LC757
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1567
	movi	a8, 0x2cd
	slli	a8, a8, 6
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L1567
	l32r	a8, .LC764
	add.n	a8, a7, a8
	l32i	a10, a8, 0
	bnez.n	a10, .L1556
	addi	a8, a2, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L1568
	s8i	a10, sp, 24
	l32r	a10, .LC765
	beqi	a2, 2, .L1632
.L1569:
	l32r	a10, .LC766
.L1632:
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE
	l32i	a8, sp, 48
	l32r	a6, .LC746
	s32i	a10, sp, 28
	s32i	a11, sp, 32
	s32i	a10, sp, 16
	s8i	a11, sp, 20
	add.n	a6, a7, a6
	movi.n	a13, 1
	addi.n	a12, a8, 8
	addi	a11, sp, 16
	mov.n	a10, a7
	l32i	a5, a6, 0
	call8	_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb
	mov.n	a2, a10
	bnez.n	a10, .L1571
	l32i	a8, a6, 0
	beq	a8, a5, .L1636
.L1571:
	l32r	a8, .LC760
	movi.n	a10, 0
	add.n	a8, a7, a8
	s32i	a10, a8, 0
	j	.L1636
.L1568:
	addi	a8, a2, -4
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L1573
	bnei	a2, 4, .L1574
	l32r	a3, .LC756
	l32r	a4, .LC765
	add.n	a3, a7, a3
	j	.L1633
.L1574:
	l32r	a3, .LC767
	l32r	a4, .LC766
	add.n	a3, a7, a3
.L1633:
	l32r	a8, .LC741
	add.n	a4, a7, a4
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1576
.L1582:
	movi.n	a2, 2
	j	.L1554
.L1576:
	l32r	a8, .LC740
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1582
	l32r	a8, .LC739
	add.n	a10, a7, a8
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1582
	l32r	a10, .LC735
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1582
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE
	s32i	a10, sp, 16
	l32r	a10, .LC750
	s32i	a11, sp, 20
	add.n	a10, a7, a10
	addi	a11, sp, 16
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	beqz.n	a10, .L1567
	l32r	a11, .LC774
	l32r	a10, .LC756
	add.n	a9, a5, a11
	add.n	a10, a7, a10
	mov.n	a8, a6
	bgeu	a9, a11, .L1578
	addi.n	a8, a6, 1
.L1578:
	s32i	a9, sp, 0
	s32i	a8, sp, 4
	mov.n	a14, a5
	mov.n	a15, a6
	mov.n	a12, a4
	mov.n	a11, a3
	call8	_ZN14MotorControlRS6ESS_RS32prepareCommunicationConfirmationERNS0_20CommunicationContextERKNS_10ReadTargetERKNS_17ActiveSerialTupleEyy
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	bnez.n	a10, .L1567
	l32r	a8, .LC760
	add.n	a8, a7, a8
	s32i	a10, a8, 0
.L1637:
	mov.n	a12, a5
	mov.n	a13, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119submitCommunicationERNS_3AppEy$constprop$0
	mov.n	a2, a10
.L1636:
	l32i	a11, sp, 48
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_117communicationViewERKNS_3AppERN21MotorControlRSExample5Probe17CommunicationViewE
	j	.L1554
.L1573:
	bnei	a2, 6, .L1567
	l32r	a8, .LC768
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L1579
	l32r	a8, .LC769
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1582
.L1579:
	l32r	a8, .LC756
	add.n	a8, a7, a8
	l8ui	a9, a8, 111
	bnez.n	a9, .L1580
	l8ui	a4, a8, 122
	movi.n	a8, 1
	xor	a4, a4, a8
	extui	a4, a4, 0, 8
.L1580:
	l32r	a8, .LC741
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1582
	l32r	a8, .LC740
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1582
	l32r	a8, .LC739
	add.n	a8, a7, a8
	mov.n	a10, a8
	s32i	a8, sp, 52
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1582
	l32r	a10, .LC735
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1582
	l32r	a8, .LC756
	add.n	a10, a7, a8
	bnez.n	a4, .L1584
	l8ui	a8, a10, 121
	bnez.n	a8, .L1585
	j	.L1582
.L1584:
	addi	a10, a10, 48
	j	.L1635
.L1585:
	l32r	a9, .LC760
	l32r	a8, .LC746
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L1582
	addi	a10, a10, 84
.L1635:
	call8	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE
	s32i	a10, sp, 16
	l32r	a10, .LC750
	s32i	a11, sp, 20
	add.n	a10, a7, a10
	addi	a11, sp, 16
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	beqz.n	a10, .L1582
	l32r	a8, .LC747
	movi.n	a2, 7
	add.n	a3, a7, a8
	l32i	a10, a3, 0
	beqi	a10, -1, .L1554
	l32r	a9, .LC755
	l32i	a10, sp, 52
	add.n	a2, a7, a9
	l32i	a12, a2, 0
	l32i	a13, a2, 4
	mov.n	a14, a5
	mov.n	a15, a6
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner16endCommissioningEyy
	beqz.n	a10, .L1556
	l32r	a8, .LC757
	movi.n	a10, 0
	s32i	a10, a2, 0
	s32i	a10, a2, 4
	add.n	a9, a7, a8
	s8i	a10, a9, 0
	l32r	a9, .LC758
	add.n	a9, a7, a9
	s8i	a10, a9, 0
	bnez.n	a4, .L1587
	l32r	a8, .LC756
	l32i	a9, a3, 0
	add.n	a2, a7, a8
	addi.n	a9, a9, 1
	l8ui	a4, a2, 40
	movi.n	a12, 0
	s32i	a9, a3, 0
	movi.n	a13, 0
	mov.n	a10, a7
	movi.n	a11, 0
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	l32r	a9, .LC752
	mov.n	a12, a5
	add.n	a9, a7, a9
	s32i	a4, a9, 0
	l32r	a9, .LC771
	mov.n	a13, a6
	add.n	a9, a7, a9
	s8i	a4, a9, 0
	l32r	a9, .LC772
	l32i	a8, a3, 0
	add.n	a9, a7, a9
	s32i	a8, a9, 0
	l32r	a8, .LC773
	mov.n	a10, a7
	add.n	a8, a7, a8
	s8i	a4, a8, 0
	call8	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy
.L1587:
	l32i	a11, sp, 48
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_117communicationViewERKNS_3AppERN21MotorControlRSExample5Probe17CommunicationViewE
.L1552:
	movi.n	a2, 0
.L1554:
	retw.n
.LFE2337:
	.size	_ZN12_GLOBAL__N_113communicationEPvPKN21MotorControlRSExample5Probe20CommunicationCommandERNS2_17CommunicationViewE, .-_ZN12_GLOBAL__N_113communicationEPvPKN21MotorControlRSExample5Probe20CommunicationCommandERNS2_17CommunicationViewE
	.literal_position
	.literal .LC775, 764516
	.literal .LC776, 764504
	.literal .LC777, 772456
	.literal .LC778, 770859
	.literal .LC779, 770856
	.literal .LC780, 770908
	.literal .LC781, 764665
	.literal .LC782, 758011
	.literal .LC783, 758028
	.literal .LC784, 757978
	.literal .LC785, 757988
	.literal .LC786, 625320
	.literal .LC787, 625608
	.literal .LC788, 757994
	.literal .LC789, 625656
	.literal .LC791, 771056
	.literal .LC792, 770916
	.literal .LC793, 770910
	.literal .LC794, 770912
	.align	4
	.type	_ZN12_GLOBAL__N_121storedPositionCurrentERKNS_3AppERKN14MotorControlRS6ESS_RS27StoredPositionQualificationEy, @function
_ZN12_GLOBAL__N_121storedPositionCurrentERKNS_3AppERKN14MotorControlRS6ESS_RS27StoredPositionQualificationEy:
.LFB2145:
	entry	sp, 64
.LCFI104:
	l8ui	a8, a3, 37
	mov.n	a7, a2
	mov.n	a6, a4
	beqz.n	a8, .L1649
	l32r	a8, .LC775
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L1649
	l32i	a9, a3, 12
	bne	a8, a9, .L1649
	l32r	a11, .LC776
	mov.n	a10, a3
	add.n	a11, a2, a11
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L1649
	l32r	a8, .LC777
	l32i	a9, a3, 8
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L1649
	l32i	a4, a3, 44
	l32i	a2, a3, 40
	bltu	a5, a4, .L1649
	bne	a4, a5, .L1658
	bltu	a6, a2, .L1649
.L1658:
	l32i	a10, a3, 48
	l32i	a8, a3, 52
	or	a11, a10, a8
	beqz.n	a11, .L1641
	sub	a5, a5, a4
	bgeu	a6, a2, .L1643
	addi.n	a5, a5, -1
.L1643:
	sub	a6, a6, a2
	bltu	a5, a8, .L1641
	bne	a8, a5, .L1649
	bgeu	a6, a10, .L1649
.L1641:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE
	beqz.n	a10, .L1649
	l32r	a8, .LC778
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1649
	l32r	a8, .LC779
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1649
	l32r	a8, .LC780
	add.n	a8, a7, a8
	l16ui	a10, a8, 0
	l16ui	a8, a3, 24
	bne	a10, a8, .L1649
	l32r	a8, .LC781
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1649
	l32r	a8, .LC782
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	s32i	a8, sp, 16
	beqz.n	a8, .L1649
	l32r	a8, .LC783
	l16ui	a5, a3, 22
	add.n	a8, a7, a8
	l16ui	a8, a8, 0
	bne	a8, a5, .L1649
	l32r	a8, .LC784
	add.n	a8, a7, a8
	l16ui	a10, a8, 0
	l16ui	a8, a3, 20
	bne	a10, a8, .L1649
	l32r	a8, .LC785
	add.n	a8, a7, a8
	l16ui	a8, a8, 0
	bnez.n	a8, .L1649
	l32r	a6, .LC786
	add.n	a8, a7, a6
	l8ui	a8, a8, 216
	beqz.n	a8, .L1645
	add.n	a8, a7, a6
	mov.n	a11, a3
	mov.n	a10, a8
	s32i	a8, sp, 20
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L1645
	l32i	a8, sp, 20
	l32i	a10, a8, 252
	bltu	a10, a4, .L1645
	bne	a10, a4, .L1659
	l32i	a8, a8, 248
	bltu	a8, a2, .L1645
.L1659:
	add.n	a8, a7, a6
	l16ui	a10, a8, 22
	bnez.n	a10, .L1649
	l8ui	a10, a8, 35
	bnez.n	a10, .L1649
	l8ui	a10, a8, 36
	bnez.n	a10, .L1649
	l8ui	a10, a8, 38
	bnez.n	a10, .L1649
	l8ui	a8, a8, 39
	bnez.n	a8, .L1649
.L1645:
	l32r	a6, .LC787
	add.n	a8, a7, a6
	l8ui	a10, a8, 216
	beqz.n	a10, .L1647
	mov.n	a11, a3
	mov.n	a10, a8
	s32i	a8, sp, 20
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L1647
	l32i	a8, sp, 20
	l32i	a10, a8, 252
	bltu	a10, a4, .L1647
	bne	a10, a4, .L1660
	l32i	a8, a8, 248
	bltu	a8, a2, .L1647
.L1660:
	add.n	a6, a7, a6
	l16ui	a8, a6, 44
	bnez.n	a8, .L1649
	l32r	a9, .LC788
	l32r	a8, .LC789
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	movi.n	a10, 4
	loop	a10, .L1651_LEND
.L1651:
	l16ui	a11, a9, 0
	bgeui	a11, 4, .L1649
	beqz.n	a11, .L1650
	l8ui	a11, a8, 0
	bnez.n	a11, .L1649
.L1650:
	addi.n	a9, a9, 2
	addi.n	a8, a8, 1
	.L1651_LEND:
.L1647:
	l32i	a11, a3, 16
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERKNS_3AppEm
	beqz.n	a10, .L1649
	l32r	a8, .LC791
	addmi	a10, a10, 0xa00
	add.n	a8, a7, a8
	l32i	a11, a8, 4
	l32i	a9, a10, 132
	bltu	a9, a11, .L1652
	bne	a11, a9, .L1654
	l32i	a8, a8, 0
	l32i	a9, a10, 128
	bgeu	a9, a8, .L1654
.L1652:
	l32r	a10, .LC792
	movi.n	a8, 0
	addi.n	a13, sp, 12
	mov.n	a12, a5
	movi.n	a11, 2
	add.n	a10, a7, a10
	s32i	a8, sp, 12
	call8	_ZN14MotorControlRS6ESS_RS12decodeUint32EPKtjNS0_9WordOrderERm
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	bnez.n	a10, .L1649
	l32i	a9, a3, 32
	l32i	a8, sp, 12
	bne	a9, a8, .L1649
	l32r	a8, .LC793
	add.n	a8, a7, a8
	l16ui	a9, a8, 0
	l16ui	a8, a3, 26
	bne	a9, a8, .L1649
	l32r	a8, .LC794
	add.n	a7, a7, a8
	l32i	a9, a7, 0
	l32i	a8, a3, 28
	beq	a9, a8, .L1654
.L1649:
	movi.n	a8, 0
	s32i	a8, sp, 16
.L1654:
	l32i	a2, sp, 16
	retw.n
.LFE2145:
	.size	_ZN12_GLOBAL__N_121storedPositionCurrentERKNS_3AppERKN14MotorControlRS6ESS_RS27StoredPositionQualificationEy, .-_ZN12_GLOBAL__N_121storedPositionCurrentERKNS_3AppERKN14MotorControlRS6ESS_RS27StoredPositionQualificationEy
	.literal_position
	.literal .LC795, 772460
	.literal .LC796, 764516
	.literal .LC797, 764508
	.literal .LC798, 772456
	.literal .LC800, 764696
	.literal .LC801, 760208
	.literal .LC802, 762096
	.literal .LC803, 759264
	.literal .LC804, 759736
	.literal .LC805, 758792
	.literal .LC806, 757972
	.literal .LC807, 762576
	.literal .LC809, 762600
	.literal .LC810, 757960
	.literal .LC811, 757976
	.literal .LC812, 758002
	.literal .LC813, 758004
	.literal .LC814, 762602
	.literal .LC816, 757992
	.literal .LC817, 757994
	.literal .LC819, 771828
	.literal .LC820, 101000
	.literal .LC821, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE, @function
_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE:
.LFB2219:
	entry	sp, 144
.LCFI105:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	mov.n	a4, a3
	mov.n	a6, a10
	beqz.n	a10, .L1702
	l8ui	a10, a3, 0
	addmi	a7, a3, 0x300
	bnei	a10, 4, .L1705
	addmi	a10, a3, 0x800
	l8ui	a10, a10, 226
	bnez.n	a10, .L1706
	addmi	a11, a3, 0x600
	l8ui	a11, a11, 241
	bnei	a11, 1, .L1707
.L1706:
	addmi	a10, a4, 0xa00
	l32i	a11, a10, 112
	bnez.n	a11, .L1708
	l8ui	a10, a10, 119
	beqz.n	a10, .L1707
.L1708:
	movi.n	a10, 1
	j	.L1707
.L1705:
	bnei	a10, 5, .L1711
	addmi	a10, a3, 0xd00
	l8ui	a11, a10, 27
	bnez.n	a11, .L1712
	l8ui	a11, a10, 28
	beqz.n	a11, .L1713
.L1712:
	l32i	a10, a10, 216
	beqz.n	a10, .L1714
	movi.n	a10, 1
	s8i	a10, a7, 11
	j	.L1715
.L1711:
	bnei	a10, 7, .L1716
	addmi	a12, a3, 0x2000
	l8ui	a10, a12, 19
	movi.n	a11, 0
	beqz.n	a10, .L1717
	l32i	a12, a12, 224
	movi.n	a11, 1
	moveqz	a11, a12, a12
	j	.L1717
.L1713:
	s8i	a11, a7, 11
	j	.L1819
.L1714:
	s8i	a10, a7, 11
	j	.L1819
.L1707:
	s8i	a10, a7, 11
	j	.L1710
.L1716:
	movi.n	a5, 0
	s8i	a5, a7, 11
	bltui	a10, 3, .L1702
	beqi	a10, 6, .L1720
	j	.L1820
.L1717:
	s8i	a11, a7, 11
	movi.n	a11, 0
	s8i	a11, a7, 8
	beqz.n	a10, .L1722
	l8ui	a11, a4, 24
	l32r	a12, .LC795
	srli	a10, a11, 3
	add.n	a10, a2, a10
	add.n	a10, a10, a12
	extui	a12, a11, 0, 3
	movi.n	a11, 1
	ssl	a12
	sll	a11, a11
	l8ui	a12, a10, 0
	or	a11, a11, a12
	s8i	a11, a10, 0
.L1722:
	l8ui	a10, a4, 71
	bnez.n	a10, .L1702
	l32r	a6, .LC796
	add.n	a6, a2, a6
	l32i	a11, a6, 0
	beqz.n	a11, .L1702
	l32r	a10, .LC797
	l8ui	a12, a4, 24
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bne	a12, a10, .L1702
	addmi	a10, a4, 0x1000
	l32i	a10, a10, 176
	bne	a11, a10, .L1702
	l32r	a10, .LC798
	addmi	a11, a4, 0x1f00
	add.n	a10, a2, a10
	l32i	a11, a11, 104
	l32i	a10, a10, 0
	bne	a11, a10, .L1702
	addi	a7, sp, 16
	movi.n	a12, 0x40
	movi.n	a11, 0
	mov.n	a10, a7
	call8	memset
	call8	_Z18esp_timer_get_timev
	mov.n	a13, a11
	l32i	a11, a2, 0
	mov.n	a12, a10
	movi	a14, 0x3e8
	movi	a10, 0x60
	muluh	a15, a14, a11
	addmi	a10, a10, 0x1f00
	mull	a14, a14, a11
	s32i	a7, sp, 0
	add.n	a10, a4, a10
	call8	_ZN14MotorControlRS6ESS_RS16getHomeReferenceERKNS0_11HomeContextEyyRNS_13AxisReferenceE
	s32i	a10, sp, 80
	s32i	a11, sp, 84
	s32i	a12, sp, 88
	extui	a10, a10, 0, 8
	bnez.n	a10, .L1702
	l32i	a9, a6, 0
	l32r	a10, .LC800
	s32i	a9, sp, 28
	movi.n	a12, 0x40
	mov.n	a11, a7
	add.n	a10, a2, a10
	j	.L1830
.L1720:
	addmi	a6, a3, 0x1f00
	l32i	a3, a6, 64
	call8	_Z18esp_timer_get_timev
	mov.n	a14, a10
	mov.n	a15, a11
	mov.n	a10, a2
	mov.n	a12, a3
	mov.n	a11, a4
	call8	_ZN12_GLOBAL__N_113driverEffectsERNS_3AppERNS0_6RecordEmy
	s8i	a5, a7, 8
	l8ui	a10, a6, 88
	bnez.n	a10, .L1702
	addmi	a6, a4, 0x1000
	l8ui	a10, a6, 184
	addi	a11, a10, -2
	extui	a8, a11, 0, 8
	s32i	a8, sp, 96
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	mov.n	a5, a10
	beqz.n	a10, .L1726
	l8ui	a10, a6, 184
	addi	a10, a10, -6
	slli	a7, a10, 4
	sub	a7, a7, a10
	subx4	a7, a7, a10
	l32r	a10, .LC801
	addx8	a7, a7, a10
	j	.L1826
.L1726:
	l32i	a8, sp, 96
	l32r	a7, .LC802
	bltui	a8, 3, .L1826
.L1728:
	l8ui	a10, a6, 184
	l32r	a7, .LC803
	beqi	a10, 1, .L1826
.L1729:
	l32r	a7, .LC804
	beqi	a10, 5, .L1826
.L1730:
	l32r	a7, .LC805
.L1826:
	l8ui	a10, a6, 208
	add.n	a7, a2, a7
	bnez.n	a10, .L1702
	l32r	a10, .LC797
	l8ui	a11, a4, 24
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bne	a11, a10, .L1702
	l32r	a8, .LC796
	l32i	a11, a6, 176
	add.n	a10, a2, a8
	l32i	a10, a10, 0
	bne	a11, a10, .L1702
	l32r	a10, .LC798
	l32i	a11, a6, 196
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L1702
	l32i	a10, a4, 4
	l32i	a11, a7, 16
	bgeu	a11, a10, .L1702
	l32r	a3, .LC806
	add.n	a11, a2, a3
	l32i	a11, a11, 0
	bgeu	a11, a10, .L1702
	l32r	a8, .LC807
	movi	a10, 0xb8
	add.n	a8, a2, a8
	addmi	a10, a10, 0x1000
	mov.n	a11, a8
	add.n	a10, a4, a10
	s32i	a8, sp, 100
	call8	_ZN14MotorControlRS6ESS_RS9getDriverERKNS0_13DriverContextERNS0_17DriverObservationE
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a8, a10, 0, 8
	bnez.n	a8, .L1702
	l8ui	a10, a6, 184
	bnei	a10, 1, .L1821
	j	.L1732
.L1767:
	s32i	a8, sp, 104
	call8	_ZN14MotorControlRS6ESS_RS16tuningFieldCountENS0_11DriverGroupE
	l32i	a8, sp, 104
	mov.n	a13, a10
	j	.L1734
.L1824:
	movi.n	a13, 7
	bnei	a10, 5, .L1734
	movi.n	a13, 8
.L1734:
	l32i	a9, sp, 96
	bgeui	a9, 3, .L1735
	l32r	a8, .LC807
	movi	a12, 0x1d8
	add.n	a11, a2, a8
	mov.n	a10, a7
.L1830:
	call8	memcpy
	j	.L1702
.L1735:
	l32i	a10, a7, 4
	beqz.n	a10, .L1736
	l32i	a10, a7, 16
	bnez.n	a10, .L1737
	add.n	a3, a2, a3
	l32i	a10, a3, 0
	bnez.n	a10, .L1736
.L1737:
	l32r	a9, .LC807
	l8ui	a14, a7, 0
	add.n	a11, a2, a9
	l8ui	a10, a11, 0
	bne	a14, a10, .L1736
	addi.n	a11, a11, 4
	addi.n	a10, a7, 4
	s32i	a13, sp, 104
	s32i	a8, sp, 96
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L1736
	l32i	a5, sp, 96
	l32r	a8, .LC809
	l32i	a13, sp, 104
	movi.n	a3, 0
	j	.L1738
.L1736:
	movi.n	a3, 0
	bnez.n	a5, .L1739
	j	.L1822
.L1742:
	add.n	a10, a5, a5
	add.n	a12, a7, a10
	add.n	a10, a10, a8
	add.n	a10, a2, a10
	l16ui	a12, a12, 24
	l16ui	a10, a10, 0
	beq	a12, a10, .L1741
	mov.n	a10, a5
	s32i	a13, sp, 96
	call8	_ZN14MotorControlRS6ESS_RS13driverFieldAtEhNS0_11DriverGroupE
	l32r	a8, .LC809
	l32i	a13, sp, 96
	or	a3, a3, a10
.L1741:
	addi.n	a5, a5, 1
.L1738:
	extui	a10, a5, 0, 8
	l8ui	a11, a6, 184
	bltu	a10, a13, .L1742
	bnez.n	a11, .L1739
	l32r	a8, .LC807
	movi.n	a12, 4
	add.n	a5, a2, a8
	addi	a11, a5, 64
	addi	a10, a7, 64
	call8	memcmp
	bnez.n	a10, .L1743
	movi.n	a12, 4
	addi	a11, a5, 68
	addi	a10, a7, 68
	call8	memcmp
	beqz.n	a10, .L1739
.L1743:
	movi	a10, 0x180
	j	.L1827
.L1822:
	l32r	a10, .LC810
	add.n	a10, a2, a10
	l32i	a3, a10, 0
	beqz.n	a3, .L1739
	l32r	a8, .LC807
	movi.n	a3, 0
	add.n	a5, a2, a8
	addi.n	a11, a5, 4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L1739
	l8ui	a10, a6, 184
	bnez.n	a10, .L1744
	l32r	a10, .LC811
	l32i	a11, sp, 100
	add.n	a10, a2, a10
	call8	_ZN12_GLOBAL__N_119driverConfigEffectsERKN14MotorControlRS6ESS_RS9RawConfigERKNS1_17DriverObservationE
	mov.n	a3, a10
	j	.L1739
.L1744:
	bnei	a10, 5, .L1745
	l32r	a11, .LC812
	l32r	a10, .LC809
	add.n	a11, a2, a11
	add.n	a10, a2, a10
	l16ui	a10, a10, 0
	l16ui	a11, a11, 0
	sub	a11, a11, a10
	movi.n	a10, 1
	moveqz	a10, a3, a11
	slli	a3, a10, 23
	l32r	a11, .LC813
	l32r	a10, .LC814
	add.n	a11, a2, a11
	add.n	a10, a2, a10
	l16ui	a11, a11, 0
	l16ui	a10, a10, 0
	beq	a11, a10, .L1739
	movi.n	a10, 1
	slli	a10, a10, 24
.L1827:
	or	a3, a3, a10
	j	.L1739
.L1745:
	l32r	a10, .LC816
	movi.n	a14, 0xe
	add.n	a10, a2, a10
	l16ui	a11, a10, 0
	l16ui	a10, a5, 38
	movi.n	a12, 0xa
	sub	a11, a11, a10
	movi.n	a10, 1
	moveqz	a10, a3, a11
	slli	a3, a10, 9
	l32r	a10, .LC817
	addmi	a14, a14, 0x1200
	add.n	a10, a2, a10
	movi.n	a15, 1
	movi.n	a11, 4
	loop	a11, .L1747_LEND
.L1747:
	add.n	a13, a10, a14
	l16ui	a5, a10, 0
	l16ui	a13, a13, 0
	beq	a5, a13, .L1746
	ssl	a12
	sll	a13, a15
	or	a3, a3, a13
.L1746:
	addi.n	a10, a10, 2
	addi.n	a12, a12, 1
	.L1747_LEND:
.L1739:
	l32i	a10, a6, 180
	and	a10, a10, a3
	xor	a3, a10, a3
	beqz.n	a3, .L1748
	l8ui	a5, a4, 24
	call8	_Z18esp_timer_get_timev
	l8ui	a12, a6, 184
	mov.n	a14, a10
	s32i	a12, sp, 4
	mov.n	a15, a11
	s32i	a4, sp, 0
	mov.n	a12, a3
	mov.n	a11, a5
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE
.L1748:
	l32r	a8, .LC807
	movi	a12, 0x1d8
	add.n	a11, a2, a8
	mov.n	a10, a7
	call8	memcpy
	l32r	a8, .LC796
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a8, a7, 20
	j	.L1702
.L1820:
	bnei	a10, 4, .L1823
	j	.L1710
.L1715:
	l8ui	a11, a4, 24
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_128invalidateMotionObservationsERNS_3AppEh
	j	.L1750
.L1823:
	bnei	a10, 5, .L1750
.L1819:
	addmi	a10, a4, 0xd00
	l32i	a10, a10, 216
	j	.L1828
.L1750:
	movi.n	a10, 0
	l8ui	a11, a4, 0
	s8i	a10, a7, 8
	bnei	a11, 4, .L1752
	addmi	a10, a4, 0x800
	l8ui	a10, a10, 226
	beqz.n	a10, .L1752
	l32r	a10, .LC819
	movi.n	a12, 0
	add.n	a10, a2, a10
	s32i	a12, a10, 0
.L1752:
	l8ui	a12, a4, 24
	movi.n	a10, 1
	extui	a13, a12, 0, 3
	ssl	a13
	sll	a10, a10
	extui	a10, a10, 0, 8
	beqi	a11, 4, .L1753
	beqi	a11, 5, .L1754
	beqi	a11, 3, .L1755
	j	.L1702
.L1754:
	addmi	a11, a4, 0xd00
	l8ui	a6, a11, 28
	bnez.n	a6, .L1756
	l8ui	a6, a11, 27
.L1756:
	addmi	a11, a4, 0xf00
	l8ui	a11, a11, 79
	j	.L1829
.L1753:
	addmi	a11, a4, 0x800
	l8ui	a11, a11, 226
	bnez.n	a11, .L1775
	l8ui	a13, a7, 11
	bnez.n	a13, .L1758
	j	.L1702
.L1755:
	addmi	a11, a4, 0x500
	l8ui	a13, a11, 102
	beqi	a13, 3, .L1759
	movi.n	a6, 0
	bnei	a13, 1, .L1759
	l8ui	a13, a11, 103
	movi.n	a6, 1
	addi.n	a13, a13, -1
	moveqz	a6, a13, a13
.L1759:
	l8ui	a13, a11, 64
	bnei	a13, 3, .L1760
	l8ui	a11, a11, 103
.L1829:
	addi.n	a11, a11, -1
	nsau	a11, a11
	srli	a11, a11, 5
	bnez.n	a6, .L1758
	j	.L1761
.L1775:
	movi.n	a11, 0
.L1758:
	l32r	a13, .LC795
	srli	a12, a12, 3
	add.n	a12, a2, a12
	add.n	a12, a12, a13
	l8ui	a13, a12, 0
	or	a13, a10, a13
	s8i	a13, a12, 0
.L1761:
	beqz.n	a11, .L1702
	l8ui	a11, a4, 24
	l32r	a12, .LC795
	srli	a11, a11, 3
	add.n	a11, a2, a11
	add.n	a11, a11, a12
	l8ui	a12, a11, 0
	l32r	a7, .LC820
	l32r	a6, .LC821
	and	a10, a10, a12
	xor	a10, a10, a12
	movi.n	a5, 0x50
	s8i	a10, a11, 0
	add.n	a7, a2, a7
	add.n	a6, a2, a6
	addmi	a5, a5, 0x2300
	j	.L1762
.L1766:
	l8ui	a10, a7, 24
	bne	a10, a11, .L1764
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L1764
	movi	a10, 0x30b
	add.n	a10, a7, a10
	movi.n	a11, 0
	s8i	a11, a10, 0
.L1764:
	add.n	a7, a7, a5
.L1762:
	l8ui	a11, a4, 24
	bne	a6, a7, .L1766
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_128invalidateMotionObservationsERNS_3AppEh
	j	.L1702
.L1760:
	beqz.n	a6, .L1702
	j	.L1775
.L1710:
	addmi	a10, a4, 0xa00
	l32i	a10, a10, 112
.L1828:
	bnez.n	a10, .L1715
	j	.L1750
.L1732:
	movi.n	a8, 7
	movi.n	a13, 0x10
	beqz.n	a5, .L1734
	j	.L1767
.L1821:
	beqz.n	a5, .L1824
	j	.L1767
.L1702:
	retw.n
.LFE2219:
	.size	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE, .-_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
	.literal_position
	.literal .LC823, 53807
	.literal .LC824, 53768
	.literal .LC825, 53800
	.literal .LC826, 53810
	.literal .LC827, 58992
	.literal .LC828, 65248
	.literal .LC829, 757628
	.literal .LC830, 771228
	.literal .LC831, 771250
	.literal .LC832, 771248
	.literal .LC833, 771302
	.literal .LC834, 771232
	.literal .LC836, _ZN12_GLOBAL__N_14uartE
	.align	4
	.type	_ZN12_GLOBAL__N_16cancelEPvm, @function
_ZN12_GLOBAL__N_16cancelEPvm:
.LFB2316:
	entry	sp, 128
.LCFI106:
	bnez.n	a3, .L1832
	l32r	a8, .LC823
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1833
	j	.L1879
.L1832:
	l32r	a8, .LC824
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a8, a3, .L1835
	l32r	a8, .LC823
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1833
.L1837:
	movi.n	a2, 9
	j	.L1836
.L1833:
	l32r	a8, .LC825
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqi	a8, 4, .L1837
	l32r	a8, .LC826
	l32r	a7, .LC827
	add.n	a8, a2, a8
	movi.n	a9, 1
	add.n	a7, a2, a7
	s8i	a9, a8, 0
	l32i	a8, a7, 0
	beqz.n	a8, .L1839
	call8	_Z18esp_timer_get_timev
	mov.n	a13, a11
	mov.n	a12, a10
	mov.n	a11, a7
	j	.L1883
.L1879:
	l32r	a8, .LC829
	add.n	a8, a2, a8
	l32i	a3, a8, 0
	beqz.n	a3, .L1840
.L1835:
	l32r	a8, .LC830
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a8, a3, .L1840
	l32r	a8, .LC831
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L1837
	l32r	a8, .LC832
	add.n	a8, a2, a8
	l8ui	a7, a8, 0
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a2
	mov.n	a11, a7
	call8	_ZN12_GLOBAL__N_123cancelSimplePreparationERNS_3AppEhy
	l32r	a8, .LC833
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC834
	add.n	a8, a2, a8
	l32i	a3, a8, 0
	beqz.n	a3, .L1839
.L1840:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a10
	bnez.n	a10, .L1842
.L1854:
	movi.n	a2, 8
	j	.L1836
.L1842:
	l8ui	a6, a10, 0
	addi	a8, a6, -3
	extui	a8, a8, 0, 8
	bgeui	a8, 5, .L1843
	mov.n	a11, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L1880
	j	.L1837
.L1843:
	bnei	a6, 2, .L1881
	j	.L1845
.L1880:
	addmi	a8, a7, 0xb00
	l32i	a9, a8, 248
	bne	a9, a3, .L1848
	l32i	a11, a8, 252
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a3, a10
	beqz.n	a10, .L1848
	mov.n	a11, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L1848
	movi.n	a8, 1
	s8i	a8, a3, 71
	l32i	a8, a3, 32
	beqz.n	a8, .L1848
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	l32r	a10, .LC828
	mov.n	a13, a11
	add.n	a10, a2, a10
	addi	a11, a3, 32
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L1848:
	movi.n	a8, 1
	s8i	a8, a7, 71
	l8ui	a8, a7, 0
	bnei	a8, 7, .L1850
	movi	a10, 0x60
	addmi	a10, a10, 0x1f00
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS10revokeHomeERNS0_11HomeContextE
	s32i	a10, sp, 72
	s32i	a11, sp, 76
	s32i	a12, sp, 80
.L1850:
	l32i	a8, a7, 32
	beqz.n	a8, .L1851
	j	.L1882
.L1851:
	movi.n	a12, 2
	mov.n	a11, a7
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a7
	mov.n	a11, sp
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
	j	.L1839
.L1845:
	l8ui	a8, a10, 101
	bnei	a8, 1, .L1837
	l32i	a9, a10, 32
	bnez.n	a9, .L1852
	movi.n	a12, 2
	mov.n	a11, a10
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	addi	a10, a7, 80
	mov.n	a11, sp
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	j	.L1839
.L1852:
	s8i	a8, a10, 71
.L1882:
	l32r	a10, .LC836
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a13, a11
	mov.n	a12, a10
	addi	a11, a7, 32
.L1883:
	l32r	a10, .LC828
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
	j	.L1839
.L1881:
	bnei	a6, 1, .L1853
	l8ui	a8, a10, 72
	bnez.n	a8, .L1853
	mov.n	a11, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L1837
	s8i	a6, a7, 71
	j	.L1882
.L1853:
	l32r	a10, .LC836
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a12, a10
	l32r	a10, .LC828
	mov.n	a13, a11
	add.n	a10, a2, a10
	addi	a11, a7, 32
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner6cancelERKNS0_9RequestIdEy
	beqz.n	a10, .L1839
	bnei	a10, 1, .L1854
	j	.L1837
.L1839:
	movi.n	a2, 0
.L1836:
	retw.n
.LFE2316:
	.size	_ZN12_GLOBAL__N_16cancelEPvm, .-_ZN12_GLOBAL__N_16cancelEPvm
	.literal_position
	.literal .LC837, 626184
	.literal .LC838, 626196
	.literal .LC839, 173320
	.literal .LC840, 626232
	.literal .LC842, 53807
	.literal .LC843, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC844, 45697
	.literal .LC845, 45698
	.literal .LC846, 59900
	.literal .LC847, 173324
	.literal .LC848, _ZN12_GLOBAL__N_14uartE
	.literal .LC849, 626208
	.align	4
	.type	_ZN12_GLOBAL__N_17monitorEPvPKN21MotorControlRSExample5Probe15MonitorSettingsERNS2_15MonitorSnapshotE, @function
_ZN12_GLOBAL__N_17monitorEPvPKN21MotorControlRSExample5Probe15MonitorSettingsERNS2_15MonitorSnapshotE:
.LFB2318:
	entry	sp, 32
.LCFI107:
	mov.n	a7, a2
	bnez.n	a3, .L1885
.L1888:
	l32r	a11, .LC837
	movi.n	a12, 0x38
	add.n	a11, a7, a11
	j	.L1906
.L1885:
	l8ui	a9, a3, 0
	bnez.n	a9, .L1887
	l32r	a8, .LC837
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC838
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC839
	add.n	a8, a2, a8
	l32i	a11, a8, 4
	beqz.n	a11, .L1888
	l8ui	a9, a8, 101
	bnei	a9, 1, .L1888
	l8ui	a8, a8, 71
	bnez.n	a8, .L1888
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_16cancelEPvm
	l32r	a8, .LC840
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L1889
	addi.n	a10, a10, 1
.L1889:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L1888
.L1887:
	movi	a5, 0x7f7
	slli	a5, a5, 5
	add.n	a8, a2, a5
	l32i	a9, a8, 152
	l32i	a10, a8, 156
	movi.n	a2, 1
	or	a9, a9, a10
	bnez.n	a9, .L1890
	l32r	a9, .LC842
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L1890
	l32r	a9, .LC843
	movi.n	a2, 3
	l8ui	a9, a9, 0
	beqz.n	a9, .L1890
	l32r	a9, .LC844
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L1891
.L1892:
	movi.n	a2, 2
	j	.L1890
.L1891:
	l32r	a9, .LC845
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L1892
	l8ui	a8, a8, 137
	bnez.n	a8, .L1892
	l32i	a8, a3, 4
	l32r	a9, .LC846
	addi	a8, a8, -100
	movi.n	a2, 8
	bltu	a9, a8, .L1890
	l32i	a8, a3, 8
	movi	a9, 0x3e7
	addi.n	a8, a8, -1
	bltu	a9, a8, .L1890
	l32r	a6, .LC837
	movi.n	a2, 1
	add.n	a6, a7, a6
	l8ui	a8, a6, 0
	bnez.n	a8, .L1890
	l32r	a8, .LC847
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L1890
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L1890
	add.n	a10, a7, a5
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L1892
	l32r	a10, .LC848
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L1892
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	l32i	a8, a3, 0
	l32i	a9, a3, 4
	s32i	a8, a6, 0
	l32i	a8, a3, 8
	s32i	a9, a6, 4
	s32i	a8, a6, 8
	l32r	a8, .LC838
	l32i	a9, a3, 8
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	call8	_Z18esp_timer_get_timev
	l32r	a8, .LC849
	movi.n	a12, 0x38
	add.n	a7, a7, a8
	s32i	a11, a7, 4
	s32i	a10, a7, 0
	mov.n	a11, a6
.L1906:
	mov.n	a10, a4
	call8	memcpy
	movi.n	a2, 0
.L1890:
	retw.n
.LFE2318:
	.size	_ZN12_GLOBAL__N_17monitorEPvPKN21MotorControlRSExample5Probe15MonitorSettingsERNS2_15MonitorSnapshotE, .-_ZN12_GLOBAL__N_17monitorEPvPKN21MotorControlRSExample5Probe15MonitorSettingsERNS2_15MonitorSnapshotE
	.align	4
	.type	_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy, @function
_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy:
.LFB2277:
	entry	sp, 112
.LCFI108:
	addmi	a8, a3, 0x2300
	movi.n	a9, 0
	s8i	a9, a8, 58
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L1907
	movi.n	a8, 1
	s8i	a8, a3, 71
	movi.n	a12, 2
	mov.n	a11, a3
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a11, sp
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
.L1907:
	retw.n
.LFE2277:
	.size	_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy, .-_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy
	.literal_position
	.literal .LC850, 772456
	.literal .LC851, 626344
	.literal .LC852, 626384
	.literal .LC853, 626240
	.literal .LC854, 65248
	.literal .LC855, 626264
	.literal .LC856, 626280
	.literal .LC857, 101784
	.literal .LC858, 626104
	.literal .LC859, 9040
	.literal .LC860, 626288
	.literal .LC862, _ZN12_GLOBAL__N_14uartE
	.literal .LC864, 101000
	.literal .LC865, 625320
	.literal .LC867, 53807
	.literal .LC868, 53810
	.literal .LC870, 64900
	.literal .LC871, 64909
	.literal .LC873, 774220
	.literal .LC874, 774016
	.literal .LC875, 813496
	.literal .LC876, 626184
	.literal .LC877, 626196
	.literal .LC878, 626248
	.literal .LC879, 45688
	.literal .LC880, 626256
	.literal .LC881, 45700
	.literal .LC882, 626244
	.literal .LC883, 757624
	.literal .LC884, 626272
	.literal .LC885, 626282
	.literal .LC888, 757628
	.literal .LC889, 2000000
	.literal .LC890, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm$part$0, @function
_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm$part$0:
.LFB2465:
	entry	sp, 224
.LCFI109:
	l32r	a9, .LC850
	s32i	a3, sp, 180
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	s32i	a5, sp, 168
	s32i	a4, sp, 160
	mov.n	a6, a2
	movi.n	a2, 7
	beqi	a9, -1, .L1910
	bnez.n	a4, .L1911
	l32r	a9, .LC851
	add.n	a9, a6, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L1911
	l32r	a9, .LC852
	add.n	a9, a6, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L1911
.L1913:
	movi.n	a2, 6
	j	.L1910
.L1911:
	l32r	a5, .LC853
	add.n	a9, a6, a5
	l32i	a9, a9, 0
	beqz.n	a9, .L1912
	l32r	a3, .LC855
	l32r	a8, .LC854
	add.n	a9, a6, a3
	add.n	a4, a6, a8
	l32i	a12, a9, 0
	l32i	a13, a9, 4
	mov.n	a10, a4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner14recoveryResultEy
	mov.n	a11, a10
	beqz.n	a10, .L1913
	l32r	a9, .LC856
	l32i	a8, sp, 160
	add.n	a9, a6, a9
	l8ui	a14, a9, 0
	bnez.n	a8, .L1950
	beqz.n	a14, .L1913
.L1950:
	l32r	a7, .LC857
	l32r	a2, .LC858
	add.n	a7, a6, a7
	add.n	a2, a6, a2
	add.n	a3, a6, a3
	j	.L1915
.L1917:
	l32i	a10, a7, 0
	bne	a10, a9, .L1916
	l32i	a9, a7, 4
	bne	a9, a13, .L1916
	movi.n	a12, 0x32
	addi	a10, a7, 16
	s32i	a14, sp, 172
	s32i	a11, sp, 164
	call8	memcpy
	l32i	a14, sp, 172
	l32i	a11, sp, 164
.L1916:
	l32r	a9, .LC859
	add.n	a7, a7, a9
.L1915:
	l32i	a9, a3, 0
	l32i	a13, a3, 4
	bne	a7, a2, .L1917
	bnez.n	a14, .L1918
	l32r	a10, .LC860
	movi.n	a12, 0x32
	add.n	a10, a6, a10
	s32i	a13, sp, 172
	s32i	a9, sp, 164
	call8	memcpy
	l32r	a10, .LC851
	movi	a12, 0x68
	add.n	a11, a6, a5
	add.n	a10, a6, a10
	call8	memcpy
	l32i	a13, sp, 172
	l32i	a9, sp, 164
.L1918:
	mov.n	a12, a9
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner15releaseRecoveryEy
	movi	a12, 0x68
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi	a9, 0xe1
	slli	a9, a9, 9
	s32i	a9, sp, 24
	movi.n	a9, 1
	s8i	a9, sp, 112
	movi	a12, 0x68
	addi	a11, sp, 16
	add.n	a10, a6, a5
	call8	memcpy
.L1912:
	l32r	a10, .LC862
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	movi.n	a9, 0
	l32r	a7, .LC864
	s32i	a9, sp, 144
	s32i	a9, sp, 148
	l32r	a9, .LC865
	add.n	a7, a6, a7
	add.n	a8, a6, a9
	l32r	a3, .LC859
	mov.n	a5, a10
	mov.n	a4, a11
	s32i	a8, sp, 164
	mov.n	a2, a7
	j	.L1920
.L1922:
	mov.n	a11, a2
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L1921
	mov.n	a12, a5
	mov.n	a13, a4
	mov.n	a11, a2
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_18holdStopERNS_3AppERNS0_6RecordEy
.L1921:
	add.n	a2, a2, a3
.L1920:
	l32i	a8, sp, 164
	bne	a8, a2, .L1922
	l32r	a9, .LC889
	s32i	a4, sp, 172
	add.n	a8, a5, a9
	s32i	a8, sp, 176
	bgeu	a8, a9, .L1923
	addi.n	a8, a4, 1
	s32i	a8, sp, 172
.L1923:
	l32r	a10, .LC854
	movi	a9, 0x90
	add.n	a9, sp, a9
	l32i	a14, sp, 176
	l32i	a15, sp, 172
	s32i	a9, sp, 0
	mov.n	a12, a5
	mov.n	a13, a4
	add.n	a10, a6, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7recoverEyyRy
	mov.n	a2, a10
	bnez.n	a10, .L1947
	l32r	a9, .LC867
	add.n	a9, a6, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L1924
	l32r	a9, .LC868
	movi.n	a10, 1
	add.n	a9, a6, a9
	s8i	a10, a9, 0
.L1924:
	movi	a9, 0xbb
	slli	a9, a9, 8
	movi.n	a10, 0
	add.n	a9, a6, a9
	s32i	a10, a9, 0
	l32r	a9, .LC870
	movi.n	a12, 0
	add.n	a9, a6, a9
	s32i	a10, a9, 0
	l32r	a9, .LC871
	movi.n	a13, 0
	add.n	a9, a6, a9
	s8i	a10, a9, 0
	l32r	a9, .LC850
	movi.n	a11, 0
	add.n	a9, a6, a9
	l32i	a10, a9, 0
	movi.n	a3, 0
	addi.n	a10, a10, 1
	s32i	a10, a9, 0
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	l32r	a14, .LC875
	add.n	a14, a6, a14
	j	.L1925
.L1926:
	movi.n	a9, 0x48
	addmi	a9, a9, 0xa00
	mull	a9, a3, a9
	l32r	a10, .LC873
	add.n	a9, a6, a9
	add.n	a10, a9, a10
	movi.n	a11, 0
	s32i	a11, a10, 0
	l32r	a10, .LC874
	mov.n	a12, a5
	add.n	a9, a9, a10
	l8ui	a11, a9, 0
	mov.n	a13, a4
	mov.n	a10, a6
	s32i	a14, sp, 184
	call8	_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy
	addi.n	a3, a3, 1
	l32i	a14, sp, 184
	extui	a3, a3, 0, 8
.L1925:
	l8ui	a9, a14, 0
	bltu	a3, a9, .L1926
	l32r	a9, .LC876
	movi.n	a10, 0
	add.n	a9, a6, a9
	s8i	a10, a9, 0
	l32r	a9, .LC877
	movi.n	a10, 0
	add.n	a9, a6, a9
	s32i	a10, a9, 0
	mov.n	a3, a7
	l32r	a9, .LC859
	j	.L1927
.L1929:
	l32i	a10, a3, 4
	beqz.n	a10, .L1928
	l8ui	a10, a3, 0
	bnei	a10, 2, .L1928
	l8ui	a10, a3, 101
	bnei	a10, 1, .L1928
	l32i	a10, a3, 32
	bnez.n	a10, .L1928
	movi.n	a12, 2
	mov.n	a11, a3
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	mov.n	a12, a5
	mov.n	a13, a4
	addi	a11, sp, 16
	addi	a10, a3, 80
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	l32r	a9, .LC859
	s32i	a10, sp, 120
	s32i	a11, sp, 124
	s32i	a12, sp, 128
.L1928:
	add.n	a3, a3, a9
.L1927:
	l32i	a8, sp, 164
	bne	a8, a3, .L1929
	mov.n	a3, a7
	j	.L1930
.L1934:
	l8ui	a10, a3, 0
	addi	a10, a10, -3
	extui	a10, a10, 0, 8
	bgeui	a10, 5, .L1932
	mov.n	a11, a3
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L1932
	movi	a10, 0x30d
	add.n	a10, a3, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L1932
	movi.n	a10, 1
	s8i	a10, a3, 71
	l32i	a10, a3, 32
	bnez.n	a10, .L1932
	movi.n	a12, 2
	mov.n	a11, a3
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	mov.n	a12, a5
	mov.n	a13, a4
	addi	a11, sp, 16
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, sp, 132
	s32i	a11, sp, 136
	mov.n	a10, a6
	mov.n	a11, a3
	s32i	a12, sp, 140
	call8	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
.L1932:
	l32r	a8, .LC859
	add.n	a3, a3, a8
.L1930:
	l32i	a8, sp, 164
	bne	a8, a3, .L1934
	l32r	a11, .LC879
	l32r	a10, .LC878
	movi.n	a12, 5
	add.n	a11, a6, a11
	add.n	a10, a6, a10
	call8	memcpy
	l32r	a11, .LC881
	l32r	a10, .LC880
	add.n	a11, a6, a11
	l32i	a11, a11, 0
	add.n	a10, a6, a10
	l32r	a12, .LC855
	s32i	a11, a10, 0
	l32i	a10, sp, 144
	add.n	a12, a6, a12
	s32i	a10, a12, 0
	l32i	a11, sp, 148
	l32r	a10, .LC882
	l32i	a8, sp, 180
	s32i	a11, a12, 4
	add.n	a10, a6, a10
	s32i	a8, a10, 0
	l32r	a10, .LC883
	l32i	a8, sp, 176
	add.n	a10, a6, a10
	l32i	a13, a10, 0
	mov.n	a12, a4
	addi.n	a11, a13, 1
	s32i	a11, a10, 0
	l32r	a10, .LC853
	l32r	a11, .LC890
	add.n	a10, a6, a10
	s32i	a13, a10, 0
	l32r	a10, .LC884
	add.n	a15, a5, a11
	add.n	a10, a6, a10
	s32i	a8, a10, 0
	l32i	a8, sp, 172
	s32i	a8, a10, 4
	l32r	a10, .LC856
	l32i	a8, sp, 160
	add.n	a10, a6, a10
	s8i	a8, a10, 0
	l32r	a10, .LC885
	add.n	a10, a6, a10
	s8i	a8, a10, 0
	movi	a10, 0xb9
	slli	a10, a10, 12
	add.n	a10, a6, a10
	bgeu	a15, a11, .L1935
	addi.n	a12, a4, 1
.L1935:
	l32i	a11, a10, 4
	l32i	a14, a10, 0
	bltu	a11, a12, .L1937
	bne	a12, a11, .L1936
	bgeu	a14, a15, .L1936
.L1937:
	mov.n	a14, a15
	mov.n	a11, a12
.L1936:
	l32i	a8, sp, 168
	s32i	a14, a10, 0
	s32i	a11, a10, 4
	s32i	a13, a8, 0
	l32r	a8, .LC859
	j	.L1938
.L1944:
	movi	a10, 0x30d
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L1939
	l32i	a10, a7, 784
	l32i	a11, a7, 788
	or	a10, a10, a11
	beqz.n	a10, .L1940
	l8ui	a10, a7, 71
	movi.n	a11, 2
	bnez.n	a10, .L1942
	l32i	a10, a7, 60
	bltu	a4, a10, .L1949
	bne	a10, a4, .L1951
	l32i	a10, a7, 56
	bltu	a5, a10, .L1949
.L1951:
	movi.n	a11, 3
	j	.L1942
.L1949:
	movi.n	a11, 1
.L1942:
	mov.n	a14, a5
	mov.n	a15, a4
	movi.n	a12, -2
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111endHeldStopERNS_3App6RecordEN14MotorControlRS13ReadEventKindEly
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
	l32r	a8, .LC859
	j	.L1939
.L1940:
	l32i	a10, sp, 144
	l32i	a9, sp, 168
	l32i	a11, sp, 148
	s32i	a10, a7, 784
	l32i	a10, a9, 0
	s32i	a11, a7, 788
	s32i	a10, a7, 792
.L1939:
	add.n	a7, a7, a8
.L1938:
	bne	a3, a7, .L1944
	l32i	a8, sp, 160
	bnez.n	a8, .L1910
	l32i	a8, sp, 168
	l32r	a10, .LC888
	l32i	a9, a8, 0
	add.n	a8, a6, a10
	s32i	a9, a8, 0
	j	.L1910
.L1947:
	movi.n	a2, 4
.L1910:
	retw.n
.LFE2465:
	.size	_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm$part$0, .-_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm$part$0
	.literal_position
	.literal .LC891, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC892, 45697
	.literal .LC893, 45698
	.literal .LC895, 757624
	.align	4
	.type	_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm, @function
_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm:
.LFB2228:
	entry	sp, 32
.LCFI110:
	l32r	a8, .LC891
	mov.n	a10, a2
	l8ui	a8, a8, 0
	mov.n	a11, a3
	mov.n	a13, a5
	mov.n	a12, a4
	movi.n	a2, 3
	beqz.n	a8, .L1974
	l32r	a8, .LC892
	movi.n	a2, 2
	add.n	a8, a10, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1974
	l32r	a8, .LC893
	add.n	a8, a10, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L1974
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a10, a8
	l8ui	a8, a8, 137
	bnez.n	a8, .L1974
	l32r	a8, .LC895
	movi.n	a2, 7
	add.n	a8, a10, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L1974
	call8	_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm$part$0
	mov.n	a2, a10
.L1974:
	retw.n
.LFE2228:
	.size	_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm, .-_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm
	.align	4
	.type	_ZN12_GLOBAL__N_17recoverEPvmRm, @function
_ZN12_GLOBAL__N_17recoverEPvmRm:
.LFB2229:
	entry	sp, 32
.LCFI111:
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a13, a4
	movi.n	a12, 0
	call8	_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm
	mov.n	a2, a10
	retw.n
.LFE2229:
	.size	_ZN12_GLOBAL__N_17recoverEPvmRm, .-_ZN12_GLOBAL__N_17recoverEPvmRm
	.align	4
	.type	_ZN12_GLOBAL__N_121positionStartingSpeedERKNS_11MotionFactsEyRt$constprop$0, @function
_ZN12_GLOBAL__N_121positionStartingSpeedERKNS_11MotionFactsEyRt$constprop$0:
.LFB2477:
	entry	sp, 48
.LCFI112:
	l8ui	a8, a2, 16
	s32i	a6, sp, 0
	l32i	a3, a2, 8
	mov.n	a7, a2
	bnez.n	a8, .L1984
	l16ui	a8, a3, 52
	mov.n	a9, a6
	j	.L2020
.L1984:
	l32i	a6, a2, 20
	l32i	a11, a2, 0
	mov.n	a10, a6
	s32i	a11, sp, 4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a2, a10
	beqz.n	a10, .L1986
	l32i	a11, sp, 4
	l32i	a8, a6, 12
	l32i	a12, a11, 12
	movi.n	a10, 1
	sub	a8, a8, a12
	movi.n	a11, 0
	moveqz	a10, a11, a8
	movi.n	a8, 1
	movnez	a8, a11, a12
	or	a8, a10, a8
	movi.n	a2, 0
	bnez.n	a8, .L1986
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE
	mov.n	a2, a10
	beqz.n	a10, .L1986
	l8ui	a2, a3, 3
	beqz.n	a2, .L1986
	l8ui	a2, a3, 0
	bnez.n	a2, .L1998
	addmi	a8, a3, 0x100
	l8ui	a8, a8, 12
	beqz.n	a8, .L1986
	l32i	a8, a3, 204
	l32i	a11, a3, 200
	bltu	a5, a8, .L1986
	bne	a8, a5, .L2000
	bltu	a4, a11, .L1986
.L2000:
	l32i	a12, a7, 32
	l32i	a10, a7, 36
	or	a13, a12, a10
	beqz.n	a13, .L1988
	sub	a8, a5, a8
	bgeu	a4, a11, .L1990
	addi.n	a8, a8, -1
.L1990:
	sub	a11, a4, a11
	bltu	a8, a10, .L1988
	bne	a10, a8, .L1986
	bgeu	a11, a12, .L1986
.L1988:
	l16ui	a11, a6, 16
	l16ui	a8, a3, 52
	bne	a11, a8, .L1986
	l32i	a11, a6, 28
	l32i	a8, a6, 24
	bltu	a5, a11, .L1986
	bne	a11, a5, .L2001
	bltu	a4, a8, .L1986
.L2001:
	beqz.n	a13, .L1993
	sub	a5, a5, a11
	bgeu	a4, a8, .L1995
	addi.n	a5, a5, -1
.L1995:
	sub	a4, a4, a8
	bltu	a5, a10, .L1993
	bne	a10, a5, .L1986
	bgeu	a4, a12, .L1986
.L1993:
	l16ui	a8, a6, 18
	l32i	a9, sp, 0
.L2020:
	s16i	a8, a9, 0
	movi.n	a2, 1
	j	.L1986
.L1998:
	movi.n	a2, 0
.L1986:
	retw.n
.LFE2477:
	.size	_ZN12_GLOBAL__N_121positionStartingSpeedERKNS_11MotionFactsEyRt$constprop$0, .-_ZN12_GLOBAL__N_121positionStartingSpeedERKNS_11MotionFactsEyRt$constprop$0
	.section	.text._ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE,"axG",@progbits,_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	.type	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE, @function
_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE:
.LFB1716:
	entry	sp, 32
.LCFI113:
	mov.n	a7, a2
	l8ui	a2, a2, 216
	mov.n	a11, a3
	beqz.n	a2, .L2022
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a2, a10
	beqz.n	a10, .L2022
	l32i	a9, a7, 264
	l32i	a8, a7, 268
	or	a10, a9, a8
	beqz.n	a10, .L2022
	l32i	a11, a7, 244
	movi.n	a10, 1
	bltu	a8, a11, .L2024
	bne	a11, a8, .L2025
	l32i	a8, a7, 240
	bltu	a9, a8, .L2024
.L2025:
	movi.n	a10, 0
.L2024:
	extui	a2, a10, 0, 8
.L2022:
	retw.n
.LFE1716:
	.size	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE, .-_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	.text
	.literal_position
	.literal .LC896, 764516
	.literal .LC897, 764504
	.literal .LC898, 757960
	.literal .LC899, 772280
	.literal .LC900, 758013
	.literal .LC901, 757994
	.literal .LC904, 758792
	.literal .LC905, 625320
	.literal .LC906, 625608
	.align	4
	.type	_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy, @function
_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy:
.LFB2161:
	entry	sp, 80
.LCFI114:
	l32r	a8, .LC896
	s32i	a4, sp, 32
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a5, sp, 36
	bnez.n	a8, .L2036
.L2038:
	movi.n	a2, 0
	j	.L2037
.L2036:
	l32i	a9, a3, 12
	s32i	a8, sp, 40
	bne	a8, a9, .L2038
	l32r	a11, .LC897
	mov.n	a10, a3
	add.n	a11, a2, a11
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2038
	l32r	a7, .LC898
	add.n	a5, a2, a7
	l32i	a6, a5, 12
	beqz.n	a6, .L2038
	mov.n	a11, a3
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2038
	l16ui	a9, a5, 84
	bnez.n	a9, .L2038
	l32r	a5, .LC899
	add.n	a4, a2, a5
	l32i	a9, a4, 12
	beqz.n	a9, .L2038
	l32i	a9, a4, 16
	l32i	a8, sp, 40
	bne	a8, a9, .L2038
	mov.n	a11, a3
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2038
	l16ui	a9, a4, 20
	l16ui	a8, a3, 30
	bne	a9, a8, .L2038
	l16ui	a9, a4, 30
	bnez.n	a9, .L2038
	l16ui	a8, a4, 32
	bnez.n	a8, .L2038
	add.n	a8, a2, a7
	l16ui	a9, a3, 90
	l16ui	a8, a8, 32
	bne	a9, a8, .L2038
	l32r	a8, .LC900
	l32r	a9, .LC901
	movi	a14, 0xcb
	add.n	a8, a2, a8
	addi	a12, a3, 92
	addi	a11, a3, 82
	add.n	a9, a2, a9
	addmi	a14, a14, 0x1100
	movi.n	a10, 4
	loop	a10, .L2039_LEND
.L2039:
	l8ui	a13, a8, 0
	beqz.n	a13, .L2038
	l16ui	a15, a11, 0
	l16ui	a13, a9, 0
	bne	a15, a13, .L2038
	l8ui	a15, a12, 0
	l8ui	a13, a8, 33
	bne	a13, a15, .L2038
	add.n	a15, a8, a14
	l8ui	a15, a15, 0
	bne	a15, a13, .L2038
	addi.n	a8, a8, 1
	addi.n	a12, a12, 1
	addi.n	a11, a11, 2
	addi.n	a9, a9, 2
	.L2039_LEND:
	l32i	a8, sp, 32
	l32i	a9, sp, 36
	l32r	a4, .LC904
	s32i	a8, a3, 112
	addi	a8, sp, 32
	s32i	a8, sp, 16
	add.n	a7, a2, a7
	movi	a8, 0xe8
	s32i	a9, a3, 116
	s32i	a3, sp, 12
	add.n	a7, a7, a8
	add.n	a4, a2, a4
	j	.L2040
.L2041:
	mov.n	a11, a7
	addi.n	a10, sp, 12
	call8	_ZZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEyENKUlRKNS4_19ReadStepObservationEE_clES9_
	beqz.n	a10, .L2038
	addi	a7, a7, 120
.L2040:
	bne	a7, a4, .L2041
	add.n	a11, a2, a5
	addi	a11, a11, 56
	addi.n	a10, sp, 12
	call8	_ZZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEyENKUlRKNS4_19ReadStepObservationEE_clES9_
	beqz.n	a10, .L2038
	l32r	a7, .LC905
	mov.n	a11, a3
	add.n	a4, a2, a7
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	beqz.n	a10, .L2038
	l32r	a5, .LC906
	mov.n	a11, a3
	add.n	a8, a2, a5
	mov.n	a10, a8
	s32i	a8, sp, 40
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	beqz.n	a10, .L2038
	l32i	a9, a4, 16
	bne	a6, a9, .L2038
	l32i	a8, sp, 40
	l32i	a8, a8, 16
	bne	a6, a8, .L2038
	l32i	a11, a4, 244
	l32i	a13, sp, 36
	l32i	a14, a4, 240
	l32i	a12, sp, 32
	bltu	a13, a11, .L2038
	bne	a11, a13, .L2052
	bltu	a12, a14, .L2038
.L2052:
	l32i	a15, a3, 56
	l32i	a10, a3, 60
	or	a6, a15, a10
	beqz.n	a6, .L2043
	sub	a8, a13, a11
	bgeu	a12, a14, .L2045
	addi.n	a8, a8, -1
.L2045:
	sub	a9, a12, a14
	bltu	a8, a10, .L2043
	bne	a10, a8, .L2038
	bgeu	a9, a15, .L2038
.L2043:
	add.n	a8, a2, a5
	l32i	a9, a8, 240
	l32i	a8, a8, 244
	bltu	a13, a8, .L2038
	bne	a8, a13, .L2053
	bltu	a12, a9, .L2038
.L2053:
	beqz.n	a6, .L2048
	sub	a8, a13, a8
	bgeu	a12, a9, .L2050
	addi.n	a8, a8, -1
.L2050:
	sub	a9, a12, a9
	bltu	a8, a10, .L2048
	bne	a10, a8, .L2038
	bgeu	a9, a15, .L2038
.L2048:
	add.n	a7, a2, a7
	l16ui	a8, a7, 26
	bnez.n	a8, .L2038
	add.n	a5, a2, a5
	l16ui	a8, a5, 44
	bnez.n	a8, .L2038
	l16ui	a8, a7, 22
	bnez.n	a8, .L2038
	l16ui	a6, a7, 24
	movi	a8, 0x7c
	and	a6, a6, a8
	bnez.n	a6, .L2038
	s32i	a14, a3, 48
	s32i	a11, a3, 52
	l32i	a8, a5, 240
	l32i	a9, a5, 244
	s16i	a6, a3, 38
	s32i	a8, a3, 104
	l16ui	a8, a7, 24
	s32i	a9, a3, 108
	s16i	a8, a3, 40
	l16ui	a8, a5, 40
	mov.n	a10, a3
	s16i	a8, a3, 96
	movi.n	a8, 1
	s8i	a8, a3, 80
	call8	_ZN14MotorControlRS6ESS_RS22checkHomeQualificationERKNS0_17HomePrerequisitesEy
	extui	a10, a10, 0, 8
	movi.n	a2, 1
	movnez	a2, a6, a10
.L2037:
	retw.n
.LFE2161:
	.size	_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy, .-_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy
	.literal_position
	.literal .LC907, 771952
	.align	4
	.type	_ZZN12_GLOBAL__N_14hostEPNS_3AppEENUlPvRN14MotorControlRS6ESS_RS17HomePrerequisitesERbE_4_FUNES2_S6_S7_, @function
_ZZN12_GLOBAL__N_14hostEPNS_3AppEENUlPvRN14MotorControlRS6ESS_RS17HomePrerequisitesERbE_4_FUNES2_S6_S7_:
.LFB2373:
	entry	sp, 160
.LCFI115:
	l32r	a7, .LC907
	mov.n	a6, a2
	add.n	a7, a2, a7
	l32i	a8, a7, 0
	movi.n	a2, 0
	beqz.n	a8, .L2093
	movi	a12, 0x78
	mov.n	a11, a7
	mov.n	a10, sp
	call8	memcpy
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a6
	mov.n	a11, sp
	call8	_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy
	s8i	a10, a4, 0
	movi	a12, 0x78
	mov.n	a11, a7
	mov.n	a10, a3
	call8	memcpy
	movi.n	a2, 1
.L2093:
	retw.n
.LFE2373:
	.size	_ZZN12_GLOBAL__N_14hostEPNS_3AppEENUlPvRN14MotorControlRS6ESS_RS17HomePrerequisitesERbE_4_FUNES2_S6_S7_, .-_ZZN12_GLOBAL__N_14hostEPNS_3AppEENUlPvRN14MotorControlRS6ESS_RS17HomePrerequisitesERbE_4_FUNES2_S6_S7_
	.literal_position
	.literal .LC908, 625320
	.literal .LC909, 101032
	.literal .LC910, 109032
	.literal .LC911, 625352
	.literal .LC912, 764516
	.literal .LC914, 772456
	.literal .LC915, 45700
	.literal .LC916, 65248
	.literal .LC917, 625608
	.align	4
	.type	_ZN12_GLOBAL__N_118cancelInvalidHomesERNS_3AppEy, @function
_ZN12_GLOBAL__N_118cancelInvalidHomesERNS_3AppEy:
.LFB2165:
	entry	sp, 208
.LCFI116:
	l32r	a3, .LC908
	l32r	a9, .LC911
	add.n	a8, a2, a3
	s32i	a8, sp, 148
	l32r	a8, .LC910
	s32i	a5, sp, 144
	add.n	a5, a2, a8
	add.n	a8, a2, a9
	l32r	a9, .LC916
	s32i	a8, sp, 152
	add.n	a8, a2, a9
	l32r	a9, .LC912
	l32r	a7, .LC909
	s32i	a8, sp, 156
	add.n	a8, a2, a9
	add.n	a7, a2, a7
	s32i	a8, sp, 160
	j	.L2097
.L2117:
	addi	a9, a7, -32
	l8ui	a9, a9, 0
	bnei	a9, 7, .L2099
	l8ui	a9, a5, 172
	bnei	a9, 1, .L2099
	l8ui	a9, a7, 39
	bnez.n	a9, .L2102
	l8ui	a9, a5, 183
	bnez.n	a9, .L2102
	l32i	a8, sp, 160
	l32i	a10, a8, 0
	beqz.n	a10, .L2102
	movi	a9, 0x90
	addmi	a9, a9, 0x1000
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	bne	a10, a9, .L2102
	l32r	a9, .LC914
	l32i	a10, a5, 8
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	bne	a10, a9, .L2102
	l32r	a9, .LC915
	addi	a10, a7, -12
	add.n	a9, a2, a9
	l32i	a10, a10, 0
	l32i	a9, a9, 0
	bne	a10, a9, .L2102
	movi	a9, 0x2e9
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L2104
.L2108:
	l32i	a10, sp, 148
	mov.n	a11, a5
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	bnez.n	a10, .L2105
	j	.L2106
.L2104:
	l32i	a9, a7, 0
	bnez.n	a9, .L2107
.L2109:
	movi	a12, 0x78
	addi	a11, a5, 40
	mov.n	a10, sp
	call8	memcpy
	l32i	a13, sp, 144
	mov.n	a12, a4
	mov.n	a11, sp
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy
	bnez.n	a10, .L2108
	j	.L2102
.L2107:
	l32r	a10, .LC916
	mov.n	a11, a7
	add.n	a10, a2, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L2109
	j	.L2108
.L2105:
	add.n	a9, a2, a3
	l32i	a12, a9, 244
	l32i	a11, a5, 212
	bltu	a11, a12, .L2110
	bne	a12, a11, .L2106
	l32i	a9, a9, 240
	l32i	a11, a5, 208
	bltu	a11, a9, .L2110
.L2106:
	l32r	a6, .LC917
	mov.n	a11, a5
	add.n	a9, a2, a6
	mov.n	a10, a9
	s32i	a9, sp, 164
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	l32i	a9, sp, 164
	bnez.n	a10, .L2112
	j	.L2099
.L2110:
	addmi	a9, a5, 0x100
	l8ui	a9, a9, 0
	bltui	a9, 2, .L2113
	l16si	a10, a5, 16
	addi	a10, a10, -35
	nsau	a10, a10
	srli	a10, a10, 5
.L2113:
	add.n	a9, a2, a3
	l16ui	a11, a9, 26
	bnez.n	a11, .L2102
	l16ui	a11, a9, 22
	bnez.n	a11, .L2102
	l16ui	a11, a9, 24
	movi	a12, 0x7c
	movi	a9, 0x78
	movnez	a9, a12, a10
	bany	a11, a9, .L2102
	j	.L2106
.L2112:
	l32i	a13, a5, 212
	l32i	a10, a9, 244
	l32i	a14, a5, 208
	bltu	a13, a10, .L2119
	bne	a10, a13, .L2099
	l32i	a9, a9, 240
	bgeu	a14, a9, .L2099
.L2119:
	movi	a12, 0x78
	addi	a11, a5, 40
	mov.n	a10, sp
	s32i	a13, sp, 168
	s32i	a14, sp, 164
	add.n	a6, a2, a6
	call8	memcpy
	l16ui	a9, a6, 40
	l32i	a14, sp, 164
	s16i	a9, sp, 96
	l16ui	a9, a6, 44
	l32i	a13, sp, 168
	bnez.n	a9, .L2102
	mov.n	a12, a14
	mov.n	a10, sp
	call8	_ZN14MotorControlRS6ESS_RS22checkHomeQualificationERKNS0_17HomePrerequisitesEy
	s32i	a10, sp, 132
	s32i	a11, sp, 136
	s32i	a12, sp, 140
	extui	a10, a10, 0, 8
	beqz.n	a10, .L2099
.L2102:
	mov.n	a10, a5
	call8	_ZN14MotorControlRS6ESS_RS10revokeHomeERNS0_11HomeContextE
	movi.n	a9, 1
	s8i	a9, a7, 39
	l32i	a9, a7, 0
	s32i	a10, sp, 120
	s32i	a11, sp, 124
	s32i	a12, sp, 128
	beqz.n	a9, .L2099
	l32i	a13, sp, 144
	l32i	a10, sp, 156
	mov.n	a12, a4
	mov.n	a11, a7
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L2099:
	movi.n	a9, 0x50
	addmi	a9, a9, 0x2300
	add.n	a7, a7, a9
	add.n	a5, a5, a9
.L2097:
	l32i	a8, sp, 152
	bne	a7, a8, .L2117
	retw.n
.LFE2165:
	.size	_ZN12_GLOBAL__N_118cancelInvalidHomesERNS_3AppEy, .-_ZN12_GLOBAL__N_118cancelInvalidHomesERNS_3AppEy
	.section	.text._ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy,"axG",@progbits,_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	.type	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy, @function
_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy:
.LFB1718:
	entry	sp, 48
.LCFI117:
	mov.n	a10, a2
	mov.n	a11, a3
	s32i	a2, sp, 0
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	mov.n	a2, a10
	beqz.n	a10, .L2130
	l32i	a8, sp, 0
	l32i	a10, a8, 244
	l32i	a9, a8, 240
	bltu	a5, a10, .L2136
	bne	a10, a5, .L2137
	bltu	a4, a9, .L2136
.L2137:
	or	a11, a6, a7
	beqz.n	a11, .L2130
	l8ui	a8, a8, 216
	beqz.n	a8, .L2130
	sub	a5, a5, a10
	bgeu	a4, a9, .L2133
	addi.n	a5, a5, -1
.L2133:
	sub	a4, a4, a9
	movi.n	a2, 1
	bltu	a7, a5, .L2135
	bne	a5, a7, .L2134
	bgeu	a6, a4, .L2134
.L2135:
	movi.n	a2, 0
.L2134:
	extui	a2, a2, 0, 8
	j	.L2130
.L2136:
	movi.n	a2, 0
.L2130:
	retw.n
.LFE1718:
	.size	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy, .-_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	.text
	.align	4
	.type	_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy, @function
_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy:
.LFB2112:
	entry	sp, 32
.LCFI118:
	l32i	a7, a2, 12
	l32i	a14, a2, 32
	l32i	a15, a2, 36
	l32i	a11, a2, 0
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	mov.n	a2, a10
	beqz.n	a10, .L2148
	l16ui	a8, a7, 22
	movi.n	a2, 0
	bnez.n	a8, .L2148
	l8ui	a2, a7, 35
	bnez.n	a2, .L2150
	l8ui	a8, a7, 34
	bnez.n	a8, .L2148
	l8ui	a8, a7, 38
	bnez.n	a8, .L2148
	l8ui	a2, a7, 39
	movi.n	a8, 1
	xor	a2, a2, a8
	extui	a2, a2, 0, 8
	j	.L2148
.L2150:
	movi.n	a2, 0
.L2148:
	retw.n
.LFE2112:
	.size	_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy, .-_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy
	.section	.rodata.str1.1
.LC948:
	.string	"admission"
	.text
	.literal_position
	.literal .LC919, 65248
	.literal .LC920, 53807
	.literal .LC921, 45698
	.literal .LC922, 64920
	.literal .LC923, 626184
	.literal .LC924, 64907
	.literal .LC926, 64848
	.literal .LC927, 47848
	.literal .LC928, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC930, 45697
	.literal .LC931, _ZN12_GLOBAL__N_14uartE
	.literal .LC932, 757972
	.literal .LC933, 757960
	.literal .LC934, 764504
	.literal .LC935, 764508
	.literal .LC936, 772492
	.literal .LC937, 771912
	.literal .LC938, 772456
	.literal .LC939, 45700
	.literal .LC940, 770856
	.literal .LC941, 625320
	.literal .LC942, 771920
	.literal .LC943, 757976
	.literal .LC944, 764516
	.literal .LC946, .LC435
	.literal .LC949, .LC948
	.literal .LC950, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_122motionProfileOperationERNS_3AppERNS0_18MotionProfileStateEN21MotorControlRSExample5Probe20MotionProfileCommandERNS5_17MotionProfileViewE, @function
_ZN12_GLOBAL__N_122motionProfileOperationERNS_3AppERNS0_18MotionProfileStateEN21MotorControlRSExample5Probe20MotionProfileCommandERNS5_17MotionProfileViewE:
.LFB2119:
	entry	sp, 128
.LCFI119:
	s32i	a5, sp, 52
	mov.n	a7, a2
	movi.n	a2, 8
	bgeui	a4, 4, .L2156
	movi	a12, 0x114
	mov.n	a11, a3
	mov.n	a10, a5
	call8	memcpy
	beqz.n	a4, .L2157
	bnei	a4, 3, .L2158
	l8ui	a8, a3, 4
	beqz.n	a8, .L2159
.L2160:
	movi.n	a2, 1
	j	.L2156
.L2159:
	l8ui	a8, a3, 0
	bnez.n	a8, .L2160
	l32i	a8, a3, 312
	bnez.n	a8, .L2160
	l32r	a8, .LC919
	add.n	a9, a7, a8
	l32i	a10, a9, 52
	bnei	a10, -1, .L2160
	l32i	a10, a9, 48
	bnez.n	a10, .L2160
	l8ui	a10, a9, 60
	beqi	a10, 1, .L2160
	l8ui	a9, a9, 137
	bnez.n	a9, .L2160
	add.n	a8, a7, a8
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	or	a9, a9, a8
	bnez.n	a9, .L2160
	l32r	a8, .LC920
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2160
	l32r	a8, .LC921
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2160
	l32r	a6, .LC922
	add.n	a6, a7, a6
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample3Rtu6Runner4busyEv
	bnez.n	a10, .L2160
	addmi	a6, a6, 0x100
	l8ui	a8, a6, 67
	bnez.n	a8, .L2160
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L2160
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L2160
	l32r	a8, .LC923
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2160
	l32r	a8, .LC924
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2160
	movi	a8, 0x3f5
	slli	a8, a8, 6
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2160
	l32r	a8, .LC926
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2160
	l32r	a8, .LC927
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2160
	movi	a12, 0x150
	movi.n	a11, 0
	mov.n	a10, a3
	call8	memset
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev
.L2214:
	l32i	a10, sp, 52
	movi	a12, 0x114
	mov.n	a11, a3
	call8	memcpy
.L2157:
	movi.n	a2, 0
	j	.L2156
.L2158:
	l32r	a8, .LC928
	l8ui	a8, a8, 0
	bnez.n	a8, .L2162
.L2163:
	movi.n	a2, 2
	j	.L2156
.L2162:
	movi	a8, 0x165
	slli	a8, a8, 7
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2163
	l32r	a8, .LC930
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2163
	l32r	a6, .LC919
	add.n	a2, a7, a6
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L2163
	l32r	a10, .LC931
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L2163
	l8ui	a8, a3, 0
	bnez.n	a8, .L2160
	l32i	a8, a2, 52
	bnei	a8, -1, .L2160
	l32i	a9, a2, 48
	s32i	a9, sp, 56
	bnez.n	a9, .L2160
	l8ui	a9, a2, 137
	bnez.n	a9, .L2160
	l32i	a8, a2, 156
	l32i	a9, a2, 152
	s32i	a8, sp, 84
	s32i	a9, sp, 80
	mov.n	a8, a9
	l32i	a9, sp, 84
	or	a8, a8, a9
	bnez.n	a8, .L2160
	l32r	a8, .LC920
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2160
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L2160
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L2160
	l32r	a8, .LC923
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2160
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L2160
	l32r	a8, .LC932
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2164
.L2165:
	movi.n	a2, 3
	j	.L2156
.L2164:
	l32r	a8, .LC933
	add.n	a5, a7, a8
	l32r	a8, .LC934
	mov.n	a10, a5
	add.n	a8, a7, a8
	mov.n	a11, a8
	s32i	a8, sp, 48
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2165
	l32r	a8, .LC935
	l32r	a9, .LC936
	add.n	a8, a7, a8
	l8ui	a2, a8, 0
	srli	a8, a2, 3
	add.n	a8, a7, a8
	add.n	a8, a8, a9
	l8ui	a9, a8, 0
	extui	a8, a2, 0, 3
	bbc	a9, a8, .L2165
	l8ui	a8, a3, 4
	s32i	a8, sp, 60
	beqi	a4, 2, .L2166
	l32i	a8, a3, 188
	movi.n	a6, 1
	moveqz	a6, a8, a8
	j	.L2167
.L2166:
	l32i	a8, sp, 60
	bnez.n	a8, .L2160
	movi.n	a6, 0
.L2167:
	l8ui	a8, a3, 1
	bnez.n	a8, .L2168
.L2171:
	bnei	a4, 2, .L2170
	j	.L2169
.L2168:
	l32r	a8, .LC937
	l32i	a9, a7, 0
	add.n	a8, a7, a8
	l8ui	a13, a8, 0
	l32r	a8, .LC938
	s32i	a5, sp, 4
	add.n	a8, a7, a8
	l32i	a12, a8, 0
	l32r	a8, .LC939
	s8i	a13, sp, 16
	add.n	a8, a7, a8
	l32i	a11, a8, 0
	movi	a8, 0x3e8
	mull	a10, a8, a9
	muluh	a8, a8, a9
	l32i	a9, sp, 48
	s32i	a8, sp, 36
	s32i	a9, sp, 0
	l32r	a9, .LC940
	movi.n	a8, 0
	add.n	a9, a7, a9
	s32i	a9, sp, 8
	l32r	a9, .LC941
	s32i	a11, sp, 28
	add.n	a9, a7, a9
	s32i	a9, sp, 12
	l32r	a9, .LC942
	s32i	a10, sp, 32
	add.n	a9, a7, a9
	s32i	a9, sp, 20
	s32i	a12, sp, 24
	s32i	a8, sp, 40
	mov.n	a11, a3
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_121motionProfileEndpointERKNS_11MotionFactsERKNS_3App18MotionProfileStateE
	bnez.n	a10, .L2171
	l32i	a8, sp, 60
	beqz.n	a8, .L2165
	l8ui	a8, a3, 6
	bne	a8, a2, .L2165
	l32r	a11, .LC943
	movi	a10, 0x118
	movi.n	a12, 0x1e
	add.n	a11, a7, a11
	add.n	a10, a3, a10
	call8	memcmp
	beqz.n	a10, .L2171
	j	.L2165
.L2170:
	l8ui	a8, a3, 1
	bnez.n	a8, .L2172
	j	.L2213
.L2169:
	l32r	a8, .LC940
	l32r	a12, .LC938
	add.n	a8, a7, a8
	s32i	a8, sp, 64
	l32r	a8, .LC941
	l32r	a9, .LC939
	add.n	a8, a7, a8
	s32i	a8, sp, 68
	l32r	a8, .LC937
	l32i	a10, a7, 0
	add.n	a8, a7, a8
	l8ui	a13, a8, 0
	s32i	a8, sp, 76
	l32r	a8, .LC942
	add.n	a12, a7, a12
	add.n	a8, a7, a8
	s32i	a8, sp, 72
	l32i	a8, sp, 48
	add.n	a9, a7, a9
	s32i	a8, sp, 0
	l32i	a8, sp, 64
	movi	a2, 0x3e8
	s32i	a8, sp, 8
	l32i	a8, sp, 68
	mull	a11, a2, a10
	s32i	a8, sp, 12
	l32i	a8, sp, 72
	muluh	a10, a2, a10
	l32i	a14, a12, 0
	l32i	a15, a9, 0
	s32i	a8, sp, 20
	movi.n	a8, 0
	s32i	a11, sp, 32
	s32i	a10, sp, 36
	s32i	a12, sp, 92
	s32i	a9, sp, 88
	s32i	a5, sp, 4
	s8i	a13, sp, 16
	s32i	a14, sp, 24
	s32i	a15, sp, 28
	s32i	a8, sp, 40
	mov.n	a11, a3
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_121motionProfileEndpointERKNS_11MotionFactsERKNS_3App18MotionProfileStateE
	beqz.n	a10, .L2165
	call8	_Z18esp_timer_get_timev
	l32i	a9, sp, 76
	mov.n	a15, a11
	l8ui	a11, a9, 0
	l32i	a9, sp, 88
	mov.n	a14, a10
	l32i	a13, a9, 0
	l32i	a9, a7, 0
	l32i	a12, sp, 92
	mull	a10, a2, a9
	muluh	a8, a2, a9
	l32i	a9, sp, 48
	l32i	a12, a12, 0
	s32i	a9, sp, 0
	l32i	a9, sp, 64
	s32i	a8, sp, 36
	s32i	a9, sp, 8
	l32i	a9, sp, 68
	movi.n	a8, 0
	s32i	a9, sp, 12
	l32i	a9, sp, 72
	s32i	a12, sp, 24
	s32i	a13, sp, 28
	s32i	a10, sp, 32
	s32i	a5, sp, 4
	s8i	a11, sp, 16
	s32i	a9, sp, 20
	s32i	a8, sp, 40
	mov.n	a12, a14
	mov.n	a13, a15
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy
	beqz.n	a10, .L2165
	l32r	a8, .LC935
	movi.n	a12, 1
	add.n	a8, a7, a8
	l8ui	a11, a8, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	beqz.n	a10, .L2170
	j	.L2165
.L2213:
	l32r	a11, .LC943
	addmi	a10, a3, 0x100
	movi.n	a12, 0x1e
	add.n	a11, a7, a11
	addi	a10, a10, 24
	call8	memcpy
.L2172:
	l32r	a8, .LC935
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	s8i	a8, a3, 6
	l32r	a8, .LC944
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a3, 8
	l32r	a8, .LC939
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a3, 12
	l32r	a8, .LC938
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a3, 328
	call8	_Z18esp_timer_get_timev
	l32r	a8, .LC950
	add.n	a10, a10, a8
	bgeu	a10, a8, .L2174
	addi.n	a11, a11, 1
.L2174:
	s32i	a10, a3, 216
	s32i	a11, a3, 220
	movi.n	a8, 2
	beqi	a4, 2, .L2175
	l32i	a12, sp, 60
	movi.n	a8, 1
	movi.n	a9, 3
	movnez	a8, a9, a12
.L2175:
	s8i	a8, a3, 5
	movi.n	a8, 1
	s8i	a8, a3, 0
	l32r	a8, .LC946
	movi.n	a13, 0
	s32i	a8, a3, 272
	movi.n	a12, 0
	movi.n	a8, 0
	movi.n	a9, 0
	s32i	a8, a3, 180
	s16i	a13, a3, 2
	s32i	a12, a3, 192
	s32i	a9, a3, 196
	addmi	a8, a3, 0x100
	s8i	a13, a8, 10
	bnez.n	a6, .L2176
	s8i	a13, a8, 13
	s32i	a6, a3, 188
	s32i	a6, a3, 184
	s8i	a13, a8, 11
	s32i	a12, a3, 232
	s32i	a9, a3, 236
	s32i	a12, a3, 240
	s32i	a9, a3, 244
	s32i	a12, a3, 248
	s32i	a9, a3, 252
	s32i	a12, a3, 256
	s32i	a9, a3, 260
	s16i	a6, a3, 264
	beqi	a4, 2, .L2177
	l32i	a10, sp, 80
	l32i	a11, sp, 84
	j	.L2177
.L2176:
	l8ui	a9, a8, 9
	s8i	a9, a8, 13
	j	.L2178
.L2177:
	s32i	a10, a3, 32
	s32i	a11, a3, 36
	beqi	a4, 2, .L2179
	movi.n	a9, 0
	s32i	a9, a3, 16
	s32i	a9, a3, 20
	j	.L2180
.L2179:
	l32i	a9, a3, 8
	s32i	a9, a3, 16
	l32i	a9, a3, 12
	s32i	a9, a3, 20
	l32i	a9, a3, 328
	s32i	a9, sp, 56
.L2180:
	l32i	a9, sp, 56
	s32i	a9, a3, 24
.L2178:
	movi.n	a10, 0
	movi.n	a9, 0
	s32i	a10, a3, 224
	s32i	a9, a3, 228
	movi.n	a11, 0
	s8i	a11, a8, 12
	s32i	a10, a3, 208
	s32i	a9, a3, 212
	s32i	a10, a3, 200
	s32i	a9, a3, 204
	call8	_Z18esp_timer_get_timev
	addi	a12, a4, -2
	nsau	a12, a12
	mov.n	a14, a10
	mov.n	a15, a11
	srli	a12, a12, 5
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119submitMotionProfileERNS_3AppERNS0_18MotionProfileStateEby
	bnez.n	a10, .L2214
	l32r	a8, .LC949
	s8i	a10, a3, 0
	l32i	a10, sp, 52
	s32i	a8, a3, 272
	movi	a12, 0x114
	mov.n	a11, a3
	call8	memcpy
	movi.n	a2, 4
.L2156:
	retw.n
.LFE2119:
	.size	_ZN12_GLOBAL__N_122motionProfileOperationERNS_3AppERNS0_18MotionProfileStateEN21MotorControlRSExample5Probe20MotionProfileCommandERNS5_17MotionProfileViewE, .-_ZN12_GLOBAL__N_122motionProfileOperationERNS_3AppERNS0_18MotionProfileStateEN21MotorControlRSExample5Probe20MotionProfileCommandERNS5_17MotionProfileViewE
	.literal_position
	.literal .LC951, 770856
	.align	4
	.type	_ZN12_GLOBAL__N_120motionProfileCommandEPvN21MotorControlRSExample5Probe20MotionProfileCommandERNS2_17MotionProfileViewE, @function
_ZN12_GLOBAL__N_120motionProfileCommandEPvN21MotorControlRSExample5Probe20MotionProfileCommandERNS2_17MotionProfileViewE:
.LFB2120:
	entry	sp, 32
.LCFI120:
	l32r	a11, .LC951
	mov.n	a10, a2
	add.n	a11, a2, a11
	mov.n	a13, a4
	extui	a12, a3, 0, 8
	call8	_ZN12_GLOBAL__N_122motionProfileOperationERNS_3AppERNS0_18MotionProfileStateEN21MotorControlRSExample5Probe20MotionProfileCommandERNS5_17MotionProfileViewE
	mov.n	a2, a10
	retw.n
.LFE2120:
	.size	_ZN12_GLOBAL__N_120motionProfileCommandEPvN21MotorControlRSExample5Probe20MotionProfileCommandERNS2_17MotionProfileViewE, .-_ZN12_GLOBAL__N_120motionProfileCommandEPvN21MotorControlRSExample5Probe20MotionProfileCommandERNS2_17MotionProfileViewE
	.section	.rodata.str1.1
.LC964:
	.string	"transaction"
.LC966:
	.string	"readback_admission"
.LC968:
	.string	"decode"
.LC970:
	.string	"word_order"
.LC981:
	.string	"readback_mismatch"
.LC988:
	.string	"stationary_required"
	.text
	.literal_position
	.literal .LC953, 764516
	.literal .LC954, 764696
	.literal .LC955, 764771
	.literal .LC956, 50000
	.literal .LC957, 771840
	.literal .LC960, 772072
	.literal .LC961, 771952
	.literal .LC962, 764788
	.literal .LC965, .LC964
	.literal .LC967, .LC966
	.literal .LC969, .LC968
	.literal .LC971, .LC970
	.literal .LC972, 770856
	.literal .LC973, 771920
	.literal .LC974, 771936
	.literal .LC975, 771816
	.literal .LC976, 771828
	.literal .LC977, 771832
	.literal .LC978, 772456
	.literal .LC979, 771836
	.literal .LC980, 45700
	.literal .LC982, .LC981
	.literal .LC983, 771912
	.literal .LC984, 764504
	.literal .LC985, 757960
	.literal .LC986, 625320
	.literal .LC987, 625560
	.literal .LC989, .LC988
	.align	4
	.type	_ZN12_GLOBAL__N_120serviceMotionProfileERNS_3AppERNS0_18MotionProfileStateEyRKN14MotorControlRS6ESS_RS17ConfigObservationE, @function
_ZN12_GLOBAL__N_120serviceMotionProfileERNS_3AppERNS0_18MotionProfileStateEyRKN14MotorControlRS6ESS_RS17ConfigObservationE:
.LFB2121:
	entry	sp, 192
.LCFI121:
	l8ui	a8, a3, 0
	s32i	a6, sp, 148
	beqz.n	a8, .L2216
	l8ui	a8, a3, 5
	movi	a7, 0x7f7
	slli	a7, a7, 5
	bnei	a8, 2, .L2219
	l8ui	a8, a3, 4
	bnez.n	a8, .L2219
	movi	a11, 0x138
	add.n	a11, a3, a11
	add.n	a10, a2, a7
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L2219
	movi.n	a8, 1
	s8i	a8, a3, 4
	l32r	a8, .LC953
	movi.n	a11, -3
	add.n	a9, a2, a8
	l32i	a9, a9, 0
	movi.n	a6, 0
	addi.n	a10, a9, -1
	bltu	a11, a10, .L2221
	addi.n	a6, a9, 1
.L2221:
	l32r	a10, .LC954
	add.n	a8, a2, a8
	s32i	a6, a8, 0
	movi.n	a12, 0x40
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a8, .LC955
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	movi.n	a12, 0x48
	movi.n	a11, 0
	s32i	a6, a3, 8
	mov.n	a10, sp
	s32i	a9, sp, 144
	call8	memset
	movi	a8, 0x7d0
	s16i	a8, sp, 16
	l32r	a8, .LC956
	l32r	a10, .LC957
	s32i	a8, sp, 20
	movi	a8, 0x64
	s16i	a8, sp, 24
	movi.n	a12, 0x48
	mov.n	a11, sp
	add.n	a10, a2, a10
	call8	memcpy
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi.n	a8, 0x48
	addmi	a8, a8, -0xc00
	l32r	a10, .LC960
	s16i	a8, sp, 26
	movi	a8, 0xb8
	addmi	a8, a8, 0xb00
	s16i	a8, sp, 28
	movi.n	a12, 0x38
	mov.n	a11, sp
	add.n	a10, a2, a10
	call8	memcpy
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a10, .LC961
	movi.n	a8, 0x23
	s16i	a8, sp, 20
	movi.n	a8, 7
	s16i	a8, sp, 30
	movi	a12, 0x78
	mov.n	a11, sp
	add.n	a10, a2, a10
	call8	memcpy
	l32r	a8, .LC962
	l32i	a9, sp, 144
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l8ui	a11, a3, 6
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_129invalidateMemberConfigurationERNS_3AppEhy
.L2219:
	add.n	a8, a2, a7
	movi	a7, 0x138
	add.n	a7, a3, a7
	mov.n	a10, a8
	mov.n	a11, a7
	s32i	a8, sp, 144
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a8, a10
	beqz.n	a10, .L2216
	l8ui	a10, a10, 142
	addmi	a6, a3, 0x100
	s8i	a10, a6, 10
	l16ui	a10, a8, 136
	s32i	a4, a3, 224
	s32i	a10, a3, 192
	movi.n	a10, 0
	s32i	a10, a3, 196
	l8ui	a10, a6, 13
	s32i	a5, a3, 228
	bnez.n	a10, .L2226
	l8ui	a10, a8, 204
.L2226:
	l16ui	a12, a8, 138
	s8i	a10, a6, 13
	movi.n	a10, 0x40
	minu	a12, a12, a10
	movi	a11, 0xcf
	add.n	a11, a8, a11
	s32i	a12, a3, 180
	addi	a10, a3, 83
	s32i	a8, sp, 152
	call8	memcpy
	l32i	a8, sp, 152
	l8ui	a12, a8, 160
	l32i	a10, a8, 144
	l32i	a11, a8, 148
	l8ui	a9, a8, 105
	s8i	a12, a6, 12
	s32i	a10, a3, 200
	s32i	a11, a3, 204
	addi	a9, a9, -2
	l32i	a11, a8, 152
	l32i	a10, a8, 156
	nsau	a9, a9
	srli	a9, a9, 5
	s32i	a11, a3, 208
	s32i	a10, a3, 212
	and	a6, a12, a9
	beqz.n	a6, .L2227
	l32i	a9, a3, 220
	bltu	a9, a10, .L2252
	bne	a9, a10, .L2253
	l32i	a9, a3, 216
	bltu	a9, a11, .L2252
.L2253:
	l8ui	a6, a8, 142
	j	.L2227
.L2252:
	movi.n	a6, 0
.L2227:
	l32i	a10, sp, 144
	mov.n	a11, a7
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	movi.n	a7, 0
	movi.n	a13, 0
	movi.n	a8, 0
	l8ui	a10, a3, 5
	s32i	a7, a3, 312
	s32i	a7, a3, 316
	s32i	a13, a3, 320
	s32i	a8, a3, 324
	bnei	a10, 2, .L2229
	l32i	a12, a3, 176
	movi	a10, 0x9b
	s32i	a12, a3, 188
	addi	a11, a3, 64
	add.n	a10, a3, a10
	call8	memcpy
	addmi	a14, a3, 0x100
	l8ui	a10, a14, 10
	l32i	a11, a3, 196
	s8i	a10, a14, 11
	l32i	a10, a3, 192
	s32i	a11, a3, 236
	s32i	a10, a3, 232
	l16ui	a10, a3, 268
	l32i	a11, a3, 204
	s16i	a10, a3, 264
	l32i	a10, a3, 200
	s32i	a11, a3, 244
	s32i	a10, a3, 240
	l32i	a10, a3, 208
	l32i	a11, a3, 212
	s32i	a10, a3, 248
	l32i	a10, a3, 180
	movi.n	a12, 8
	minu	a12, a12, a10
	movi	a10, 0x93
	s32i	a11, a3, 252
	s32i	a4, a3, 256
	s32i	a5, a3, 260
	s32i	a12, a3, 184
	addi	a11, a3, 83
	add.n	a10, a3, a10
	s32i	a14, sp, 144
	call8	memcpy
	l32i	a14, sp, 144
	movi.n	a13, 0
	movi.n	a8, 0
	bnez.n	a6, .L2230
.L2250:
	movi.n	a8, 0
	s8i	a8, a3, 0
	l32r	a8, .LC965
	j	.L2278
.L2230:
	movi.n	a9, 3
	s8i	a9, a3, 5
	s32i	a7, a3, 180
	s32i	a13, a3, 192
	s32i	a8, a3, 196
	s32i	a13, a3, 224
	s32i	a8, a3, 228
	s8i	a7, a14, 12
	s8i	a7, a14, 10
	s32i	a13, a3, 208
	s32i	a8, a3, 212
	s32i	a13, a3, 200
	s32i	a8, a3, 204
	mov.n	a14, a4
	mov.n	a15, a5
	movi.n	a12, 0
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_119submitMotionProfileERNS_3AppERNS0_18MotionProfileStateEby
	bnez.n	a10, .L2216
	l32r	a8, .LC967
	s8i	a10, a3, 0
	j	.L2278
.L2249:
	movi	a14, 0x84
	add.n	a10, sp, a14
	movi.n	a12, 0xc
	movi.n	a11, 0
	call8	memset
	l32i	a8, sp, 148
	l8ui	a12, a3, 6
	l16ui	a13, a8, 68
	l32i	a11, a3, 180
	mov.n	a14, a10
	addi	a10, a3, 83
	call8	_ZN14MotorControlRS6ESS_RS20parsePositionProfileEPKhjhNS0_9WordOrderERNS0_15PositionProfileE
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a6, a10, 0, 8
	beqz.n	a6, .L2233
	l32r	a8, .LC969
	s8i	a7, a3, 0
	j	.L2278
.L2233:
	l16ui	a8, sp, 132
	l32i	a10, sp, 140
	s16i	a8, sp, 120
	l16ui	a8, sp, 134
	addi	a7, sp, 120
	s16i	a8, sp, 122
	l16ui	a8, sp, 136
	movi.n	a13, 2
	s16i	a8, sp, 124
	l16ui	a8, sp, 138
	addi.n	a12, a7, 8
	s16i	a8, sp, 126
	l32i	a8, sp, 148
	s32i	a6, sp, 128
	l16ui	a11, a8, 68
	call8	_ZN14MotorControlRS6ESS_RS12encodeUint32EmNS0_9WordOrderEPtj
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L2234
	l32r	a8, .LC971
	s8i	a6, a3, 0
	j	.L2278
.L2234:
	l32r	a6, .LC972
	add.n	a6, a2, a6
	bne	a6, a3, .L2235
	l8ui	a8, a3, 1
	beqz.n	a8, .L2236
	l16ui	a9, a3, 52
	l16ui	a8, sp, 120
	bne	a9, a8, .L2237
.L2236:
	l32r	a8, .LC973
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2235
	l32r	a8, .LC974
	add.n	a8, a2, a8
	l16ui	a9, a8, 0
	l16ui	a8, sp, 120
	beq	a9, a8, .L2235
.L2237:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_132revokePositionStartSpeedRelationERNS_3AppE
.L2235:
	movi.n	a12, 0xc
	mov.n	a11, a7
	addi	a10, a3, 52
	call8	memcpy
	bne	a6, a3, .L2238
	l32r	a10, .LC975
	movi.n	a12, 0xa
	addi	a11, sp, 122
	add.n	a10, a2, a10
	call8	memcpy
	l32r	a9, .LC953
	l32r	a8, .LC976
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a9, .LC978
	l32r	a8, .LC977
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a9, .LC980
	l32r	a8, .LC979
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
.L2238:
	l8ui	a8, a3, 1
	bnez.n	a8, .L2239
	movi.n	a12, 0xc
	mov.n	a11, a7
	addi	a10, a3, 40
	call8	memcpy
	movi.n	a8, 1
	s8i	a8, a3, 1
.L2239:
	movi.n	a8, 0
	l8ui	a7, a3, 5
	s8i	a8, a3, 0
	beqi	a7, 3, .L2240
.L2246:
	addi	a10, a7, -3
	movi.n	a9, 0
	movi.n	a8, 1
	movnez	a8, a9, a10
	s8i	a8, a3, 2
	bnei	a7, 3, .L2242
	j	.L2241
.L2240:
	movi.n	a12, 0xa
	addi	a11, a3, 54
	addi	a10, a3, 42
	call8	memcmp
	l32r	a8, .LC982
	bnez.n	a10, .L2278
.L2243:
	l32r	a8, .LC983
	l32i	a9, a2, 0
	add.n	a8, a2, a8
	l8ui	a14, a8, 0
	l32r	a8, .LC978
	s32i	a10, sp, 40
	add.n	a8, a2, a8
	l32i	a13, a8, 0
	l32r	a8, .LC980
	s32i	a13, sp, 24
	add.n	a8, a2, a8
	l32i	a12, a8, 0
	movi	a8, 0x3e8
	mull	a11, a8, a9
	muluh	a8, a8, a9
	l32r	a9, .LC984
	s32i	a12, sp, 28
	add.n	a9, a2, a9
	s32i	a9, sp, 0
	l32r	a9, .LC985
	s32i	a6, sp, 8
	add.n	a9, a2, a9
	s32i	a9, sp, 4
	l32r	a9, .LC986
	s8i	a14, sp, 16
	add.n	a9, a2, a9
	s32i	a9, sp, 12
	l32r	a9, .LC973
	s32i	a11, sp, 32
	add.n	a9, a2, a9
	s32i	a9, sp, 20
	s32i	a8, sp, 36
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy
	beqz.n	a10, .L2244
	addmi	a8, a3, 0x100
	l8ui	a9, a8, 9
	bnez.n	a9, .L2245
	l8ui	a9, a8, 8
	beqz.n	a9, .L2245
	l8ui	a8, a8, 11
	bnez.n	a8, .L2246
.L2245:
	l32r	a8, .LC987
	l32i	a10, a3, 260
	add.n	a8, a2, a8
	l32i	a9, a8, 4
	bltu	a9, a10, .L2244
	bne	a10, a9, .L2246
	l32i	a9, a3, 256
	l32i	a8, a8, 0
	bgeu	a8, a9, .L2246
.L2244:
	l32r	a8, .LC989
.L2278:
	s32i	a8, a3, 272
	j	.L2216
.L2241:
	s8i	a9, a3, 4
.L2242:
	movi.n	a8, 1
	s8i	a8, a3, 3
	j	.L2216
.L2229:
	bnez.n	a6, .L2249
	j	.L2250
.L2216:
	retw.n
.LFE2121:
	.size	_ZN12_GLOBAL__N_120serviceMotionProfileERNS_3AppERNS0_18MotionProfileStateEyRKN14MotorControlRS6ESS_RS17ConfigObservationE, .-_ZN12_GLOBAL__N_120serviceMotionProfileERNS_3AppERNS0_18MotionProfileStateEyRKN14MotorControlRS6ESS_RS17ConfigObservationE
	.literal_position
	.literal .LC990, _ZN14MotorControlRS6ESS_RS11prepareSaveERNS0_18PersistenceContextERKNS_10ReadTargetEmRKNS0_24PersistencePrerequisitesEyy
	.literal .LC991, _ZN14MotorControlRS6ESS_RS21prepareFactoryRestoreERNS0_18PersistenceContextERKNS_10ReadTargetEmRKNS0_24PersistencePrerequisitesEyy
	.literal .LC992, 53807
	.literal .LC993, _ZN12_GLOBAL__N_14uartE
	.literal .LC994, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC995, 64832
	.literal .LC996, 64907
	.literal .LC997, 47848
	.literal .LC998, 65248
	.literal .LC999, 47864
	.literal .LC1001, 47900
	.literal .LC1002, 64913
	.literal .LC1003, 49112
	.literal .LC1004, 61456
	.literal .LC1005, 45697
	.literal .LC1007, 64912
	.literal .LC1008, 45913
	.literal .LC1010, 45700
	.literal .LC1011, 64864
	.literal .LC1012, 45828
	.literal .LC1013, 764504
	.literal .LC1014, 626184
	.literal .LC1015, 626240
	.literal .LC1016, 626282
	.literal .LC1017, 45688
	.literal .LC1018, 64905
	.literal .LC1019, 757624
	.literal .LC1020, 772456
	.literal .LC1021, 59016
	.literal .LC1022, 64909
	.literal .LC1023, 64896
	.literal .LC1024, 64892
	.literal .LC1027, 61256
	.literal .LC1028, 60216
	.literal .LC1029, 61468
	.literal .LC1030, 757960
	.literal .LC1031, 757792
	.literal .LC1032, 625320
	.literal .LC1033, 764516
	.literal .LC1034, 50792
	.literal .LC1036, 47888
	.literal .LC1038, 64911
	.literal .LC1039, 64900
	.literal .LC1040, 64906
	.literal .LC1041, 45756
	.literal .LC1042, 45752
	.literal .LC1043, 50403
	.literal .LC1045, 50406
	.literal .LC1046, 50407
	.literal .LC1049, 764512
	.literal .LC1050, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_111persistenceEPvPKN21MotorControlRSExample5Probe18PersistenceCommandERNS2_15PersistenceViewE, @function
_ZN12_GLOBAL__N_111persistenceEPvPKN21MotorControlRSExample5Probe18PersistenceCommandERNS2_15PersistenceViewE:
.LFB2348:
	entry	sp, 304
.LCFI122:
	mov.n	a11, a4
	mov.n	a10, a2
	mov.n	a7, a2
	s32i	a4, sp, 260
	call8	_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE
	beqz.n	a3, .L2281
	l32r	a8, .LC992
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2283
	l32r	a5, .LC993
	movi.n	a2, 3
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32r	a8, .LC994
	s32i	a10, sp, 256
	l8ui	a8, a8, 0
	mov.n	a6, a11
	beqz.n	a8, .L2284
	l8ui	a9, a3, 0
	beqz.n	a9, .L2281
	l32r	a8, .LC995
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2283
	l32r	a8, .LC996
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2283
	l32r	a8, .LC997
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2283
	bnei	a9, 5, .L2287
	l32r	a8, .LC998
	add.n	a8, a7, a8
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	or	a9, a9, a8
	bnez.n	a9, .L2288
	j	.L2326
.L2288:
	l32r	a8, .LC999
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	l32i	a8, a8, 4
	or	a9, a9, a8
	beqz.n	a9, .L2326
	movi	a8, 0xe1
	slli	a8, a8, 9
	s32i	a8, sp, 16
	movi.n	a8, 0
	s8i	a8, sp, 20
	s8i	a8, sp, 24
	l32r	a8, .LC1001
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2292
	l32r	a8, .LC1002
	l32r	a10, .LC1003
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2424
.L2292:
	l32r	a10, .LC1004
.L2424:
	add.n	a10, a7, a10
	l8ui	a8, a10, 0
	beqz.n	a8, .L2326
	call8	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE
	l32i	a8, sp, 260
	s32i	a10, sp, 120
	s32i	a11, sp, 124
	s32i	a10, sp, 16
	s8i	a11, sp, 20
	movi.n	a13, 1
	addi	a12, a8, 20
	addi	a11, sp, 16
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114hostSerialImplEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotEb
	j	.L2427
.L2287:
	l32r	a8, .LC1005
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2294
.L2332:
	movi.n	a2, 2
	j	.L2284
.L2294:
	movi	a8, 0x165
	slli	a8, a8, 7
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2332
	l32r	a4, .LC998
	add.n	a8, a7, a4
	mov.n	a10, a8
	s32i	a8, sp, 264
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L2332
	mov.n	a10, a5
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L2332
	l8ui	a2, a3, 0
	bnei	a2, 4, .L2296
	l32r	a8, .LC1001
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2297
	l32r	a8, .LC1002
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2283
.L2297:
	add.n	a4, a7, a4
	l32i	a8, a4, 152
	l32i	a9, a4, 156
	or	a8, a8, a9
	beqz.n	a8, .L2298
	l32r	a9, .LC999
	l32r	a10, .LC1007
	add.n	a9, a7, a9
	add.n	a10, a7, a10
	l32i	a8, a9, 0
	l32i	a11, a9, 4
	l8ui	a9, a10, 0
	or	a8, a8, a11
	beqz.n	a9, .L2300
	beqz.n	a8, .L2332
	l32r	a8, .LC1008
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2332
	l32r	a8, .LC1010
	movi	a9, 0xbb
	slli	a9, a9, 8
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L2332
	l32r	a9, .LC1012
	l32r	a8, .LC1011
	add.n	a9, a7, a9
	l32i	a12, a9, 0
	add.n	a8, a7, a8
	l32i	a11, a9, 4
	s32i	a12, a8, 0
	l32i	a9, a9, 8
	s32i	a11, a8, 4
	s32i	a9, a8, 8
	movi.n	a8, 1
	s8i	a8, a10, 0
	j	.L2302
.L2300:
	beqz.n	a8, .L2332
	l32r	a9, .LC1013
	l32r	a8, .LC1011
	add.n	a9, a7, a9
	l32i	a11, a9, 0
	add.n	a8, a7, a8
	l32i	a10, a9, 4
	s32i	a11, a8, 0
	l32i	a9, a9, 8
	s32i	a10, a8, 4
	s32i	a9, a8, 8
	j	.L2302
.L2298:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L2283
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L2283
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L2283
	l32r	a8, .LC1014
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2283
	l32r	a8, .LC1015
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2304
	l32r	a8, .LC1016
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2283
.L2304:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	mov.n	a5, a10
	bnez.n	a10, .L2283
	l32r	a14, .LC999
	l32i	a12, sp, 256
	l32i	a10, sp, 264
	add.n	a14, a7, a14
	mov.n	a13, a6
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner18beginCommissioningEyRy
	beqz.n	a10, .L2283
	l32r	a8, .LC1007
	l32r	a9, .LC1013
	add.n	a8, a7, a8
	s8i	a5, a8, 0
	add.n	a9, a7, a9
	l32r	a8, .LC1011
	l32i	a11, a9, 0
	l32i	a10, a9, 4
	add.n	a8, a7, a8
	s32i	a11, a8, 0
	l32i	a9, a9, 8
	s32i	a10, a8, 4
	l32r	a10, .LC1017
	s32i	a9, a8, 8
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	s32i	a10, sp, 16
	l32r	a10, .LC1004
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	addi	a11, sp, 16
	movi.n	a12, 0xb
	add.n	a10, a7, a10
	call8	memcpy
.L2302:
	movi.n	a14, 0
	j	.L2428
.L2296:
	bnei	a2, 1, .L2305
	l8ui	a8, a3, 1
	bltui	a8, 2, .L2306
	j	.L2326
.L2306:
	l32r	a8, .LC1001
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2308
	l32r	a8, .LC1002
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2284
.L2308:
	l32r	a8, .LC1018
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqi	a8, 2, .L2342
	l32r	a8, .LC1019
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, sp, 268
	beqz.n	a8, .L2344
	l32r	a8, .LC1020
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	beqi	a9, -1, .L2344
	l32r	a5, .LC1021
	add.n	a5, a7, a5
	addmi	a8, a5, 0x400
	l8ui	a10, a8, 204
	beqz.n	a10, .L2346
	l32i	a8, a8, 208
	beqz.n	a8, .L2346
	l32r	a10, .LC1022
	add.n	a4, a7, a4
	add.n	a10, a7, a10
	l32i	a8, a4, 152
	l32i	a11, a4, 156
	l8ui	a10, a10, 0
	or	a8, a8, a11
	beqz.n	a10, .L2309
	bnez.n	a8, .L2310
	j	.L2311
.L2309:
	bnez.n	a8, .L2326
	j	.L2311
.L2310:
	l32r	a8, .LC1023
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L2326
	l32r	a9, .LC1024
	l32r	a8, .LC1010
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L2326
	movi	a11, 0x75b
	slli	a11, a11, 5
	movi	a12, 0x340
	add.n	a11, a7, a11
	mov.n	a10, a5
	call8	memcpy
	movi	a11, 0x775
	addmi	a10, a5, 0x300
	slli	a11, a11, 5
	movi	a12, 0xa8
	add.n	a11, a7, a11
	addi	a10, a10, 64
	call8	memcpy
	l32r	a11, .LC1027
	movi	a10, 0x3e8
	movi	a12, 0xc8
	add.n	a11, a7, a11
	add.n	a10, a5, a10
	call8	memcpy
	l32r	a11, .LC1004
	l32r	a10, .LC1028
	movi.n	a12, 0xb
	add.n	a11, a7, a11
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a8, .LC1029
	j	.L2425
.L2311:
	l32r	a5, .LC1021
	l32r	a11, .LC1030
	add.n	a5, a7, a5
	movi	a12, 0x340
	add.n	a11, a7, a11
	mov.n	a10, a5
	call8	memcpy
	l32r	a11, .LC1031
	addmi	a10, a5, 0x300
	movi	a12, 0xa8
	add.n	a11, a7, a11
	addi	a10, a10, 64
	call8	memcpy
	l32r	a9, .LC1032
	addmi	a8, a5, 0x400
	l32r	a11, .LC1013
	add.n	a4, a7, a9
	l32i	a14, a8, 192
	l32i	a15, a8, 196
	l32i	a12, sp, 256
	mov.n	a13, a6
	add.n	a11, a7, a11
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2326
	movi	a10, 0x3e8
	movi	a12, 0xc8
	mov.n	a11, a4
	add.n	a10, a5, a10
	call8	memcpy
	l32r	a10, .LC1017
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	s32i	a10, sp, 16
	l32r	a10, .LC1028
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	addi	a11, sp, 16
	movi.n	a12, 0xb
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a8, .LC1033
.L2425:
	l32r	a11, .LC1021
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	add.n	a8, a7, a11
	addmi	a8, a8, 0x400
	s32i	a9, a8, 188
	l8ui	a9, a3, 1
	l32r	a8, .LC991
	bnez.n	a9, .L2314
	l32r	a8, .LC990
.L2314:
	l32r	a13, .LC1050
	l32i	a12, sp, 256
	l32r	a5, .LC1034
	add.n	a12, a12, a13
	add.n	a11, a7, a11
	add.n	a10, a7, a5
	mov.n	a9, a6
	bgeu	a12, a13, .L2315
	addi.n	a9, a6, 1
.L2315:
	s32i	a12, sp, 0
	l32i	a14, sp, 256
	l32i	a12, sp, 268
	s32i	a9, sp, 4
	mov.n	a15, a6
	mov.n	a13, a11
	callx8	a8
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2326
	l32r	a8, .LC998
	add.n	a8, a7, a8
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	or	a9, a9, a8
	bnez.n	a9, .L2316
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L2284
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L2284
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L2284
	l32r	a8, .LC1014
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2284
	l32r	a8, .LC1015
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2320
	l32r	a8, .LC1016
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2284
.L2320:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	mov.n	a4, a10
	bnez.n	a10, .L2284
	l32r	a14, .LC999
	l32i	a12, sp, 256
	l32i	a10, sp, 264
	add.n	a14, a7, a14
	mov.n	a13, a6
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner18beginCommissioningEyRy
	beqz.n	a10, .L2284
	l32r	a8, .LC1007
	add.n	a8, a7, a8
	s8i	a4, a8, 0
.L2316:
	l32r	a3, .LC1036
	movi.n	a12, 0x54
	add.n	a3, a7, a3
	add.n	a11, a7, a5
	addmi	a12, a12, 0xb00
	mov.n	a10, a3
	call8	memcpy
	l32r	a8, .LC1019
	addi	a5, sp, 16
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	movi	a4, 0xb0
	addi.n	a9, a9, 1
	s32i	a9, a8, 0
	l32r	a8, .LC1018
	add.n	a4, a5, a4
	add.n	a8, a7, a8
	l8ui	a9, a8, 0
	movi.n	a12, 0x40
	addi.n	a9, a9, 1
	s8i	a9, a8, 0
	l32r	a8, .LC1002
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	l32r	a8, .LC1038
	movi.n	a11, 0
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	l32r	a8, .LC1039
	movi.n	a9, 0
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	l32r	a8, .LC1040
	mov.n	a10, a4
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	call8	memset
	l32i	a12, sp, 256
	movi.n	a8, 2
	mov.n	a14, a4
	mov.n	a13, a6
	mov.n	a10, a3
	s8i	a8, sp, 192
	call8	_ZN14MotorControlRS6ESS_RS15nextPersistenceERKNS0_18PersistenceContextEyRNS0_19PreparedPersistenceE
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2326
	movi.n	a12, 0x54
	movi.n	a11, 0
	addi	a10, sp, 36
	call8	memset
	l32i	a8, sp, 240
	l32i	a9, sp, 252
	s32i	a8, sp, 20
	movi.n	a8, 8
	s32i	a8, sp, 24
	l32i	a8, sp, 248
	addi	a4, a4, 38
	s32i	a8, sp, 40
	l32r	a8, .LC1041
	movi.n	a2, 1
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a4, sp, 16
	s32i	a8, sp, 28
	l32r	a8, .LC1042
	s32i	a9, sp, 44
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s16i	a2, sp, 66
	s32i	a8, sp, 32
	l8ui	a8, sp, 200
	s8i	a8, sp, 70
	l32i	a8, sp, 196
	s32i	a8, sp, 56
	l32i	a8, sp, 204
	s32i	a8, sp, 60
	movi.n	a8, 6
	s8i	a8, sp, 71
	l16ui	a8, sp, 226
	s16i	a8, sp, 64
	l16ui	a8, sp, 228
	s16i	a8, sp, 68
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	l32r	a8, .LC999
	s32i	a10, sp, 72
	add.n	a8, a7, a8
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	l32r	a8, .LC995
	l32i	a14, sp, 256
	add.n	a8, a7, a8
	l32i	a10, sp, 264
	s32i	a11, sp, 76
	s32i	a8, sp, 0
	mov.n	a15, a6
	mov.n	a11, a5
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner18admitCommissioningERKNS0_10BusRequestEyyRNS0_9RequestIdE
	mov.n	a4, a10
	beqz.n	a10, .L2323
	movi.n	a11, 0
	movi.n	a12, 0x38
	addi	a10, a5, 120
	call8	memset
	movi	a8, 0xb4
	add.n	a5, a5, a8
	l32i	a8, a5, 0
	addi	a11, sp, 120
	s32i	a8, sp, 120
	l32i	a8, a5, 8
	l32i	a9, a5, 4
	s32i	a8, a11, 8
	l32i	a8, sp, 220
	s32i	a9, a11, 4
	l32i	a12, sp, 256
	s32i	a8, sp, 132
	s8i	a2, sp, 137
	s32i	a4, sp, 168
	mov.n	a13, a6
	mov.n	a10, a3
	call8	_ZN14MotorControlRS6ESS_RS18advancePersistenceERNS0_18PersistenceContextERKNS_11ActionEventEy
.L2323:
	l32i	a11, sp, 260
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_115admissionResultEN21MotorControlRSExample3Rtu12BusAdmissionE
	mov.n	a2, a10
	j	.L2284
.L2342:
	movi.n	a2, 6
	j	.L2284
.L2344:
	movi.n	a2, 7
	j	.L2284
.L2346:
	movi.n	a2, 3
	j	.L2284
.L2305:
	l32i	a8, sp, 264
	l32i	a9, sp, 264
	l32i	a8, a8, 152
	l32i	a9, a9, 156
	or	a8, a8, a9
	bnez.n	a8, .L2325
.L2326:
	movi.n	a2, 8
	j	.L2284
.L2325:
	l32r	a5, .LC999
	add.n	a8, a7, a5
	l32i	a12, a8, 0
	l32i	a3, a8, 4
	or	a8, a12, a3
	beqz.n	a8, .L2326
	bnei	a2, 2, .L2328
	l32r	a8, .LC1001
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2326
	l32r	a8, .LC1002
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2326
	l32r	a5, .LC1040
	add.n	a8, a7, a5
	l8ui	a4, a8, 0
	bgeui	a4, 2, .L2326
	l32r	a10, .LC1003
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE
	s32i	a10, sp, 16
	l32r	a10, .LC1017
	s32i	a11, sp, 20
	add.n	a10, a7, a10
	addi	a11, sp, 16
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	beqz.n	a10, .L2326
	l32r	a9, .LC1036
	l32r	a8, .LC1011
	add.n	a9, a7, a9
	l32i	a11, a9, 0
	add.n	a8, a7, a8
	l32i	a10, a9, 4
	s32i	a11, a8, 0
	l32i	a9, a9, 8
	add.n	a5, a7, a5
	s32i	a10, a8, 4
	s32i	a9, a8, 8
	addi.n	a4, a4, 1
	s8i	a4, a5, 0
	movi.n	a14, 1
.L2428:
	l32i	a12, sp, 256
	mov.n	a13, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_123persistenceCaptureStartERNS_3AppEyb
.L2427:
	l32i	a11, sp, 260
	mov.n	a2, a10
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE
	j	.L2284
.L2328:
	bnei	a2, 3, .L2326
	l32r	a8, .LC1001
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2329
	l32r	a8, .LC1002
	add.n	a8, a7, a8
	l8ui	a4, a8, 0
	bnez.n	a4, .L2329
	l32r	a8, .LC1043
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2330
	movi	a8, 0x5d9
	slli	a8, a8, 5
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnei	a8, 1, .L2331
	l32r	a8, .LC1045
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2332
.L2331:
	l32r	a8, .LC1007
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2333
	l32r	a8, .LC1046
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2332
.L2333:
	l32r	a9, .LC1039
	l32r	a8, .LC1010
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L2332
	l32r	a9, .LC1023
	l32r	a8, .LC1020
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L2332
	movi	a8, 0x627
	slli	a8, a8, 5
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2334
	j	.L2332
.L2330:
	l32r	a10, .LC1003
	j	.L2426
.L2329:
	l32r	a10, .LC1004
.L2426:
	add.n	a10, a7, a10
	l8ui	a8, a10, 0
	s32i	a12, sp, 268
	beqz.n	a8, .L2332
	call8	_ZN12_GLOBAL__N_117communicationHostERKN14MotorControlRS17ActiveSerialTupleE
	s32i	a10, sp, 16
	l32r	a10, .LC1017
	s32i	a11, sp, 20
	add.n	a10, a7, a10
	addi	a11, sp, 16
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	l32i	a12, sp, 268
	mov.n	a4, a10
	beqz.n	a10, .L2332
.L2334:
	l32r	a8, .LC1007
	add.n	a8, a7, a8
	l8ui	a2, a8, 0
	bnez.n	a2, .L2338
	l32i	a14, sp, 256
	l32i	a10, sp, 264
	mov.n	a15, a6
	mov.n	a13, a3
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner16endCommissioningEyy
	bnez.n	a10, .L2339
.L2283:
	movi.n	a2, 1
	j	.L2284
.L2339:
	movi.n	a8, 0
	add.n	a5, a7, a5
	s32i	a8, a5, 0
	s32i	a8, a5, 4
	l32r	a8, .LC1022
	add.n	a8, a7, a8
	s8i	a2, a8, 0
	bnez.n	a4, .L2338
	l32r	a9, .LC1020
	l32i	a12, sp, 256
	add.n	a9, a7, a9
	l32i	a8, a9, 0
	mov.n	a13, a6
	addi.n	a8, a8, 1
	s32i	a8, a9, 0
	l32r	a9, .LC1049
	mov.n	a10, a7
	add.n	a9, a7, a9
	s32i	a8, a9, 0
	call8	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy
.L2338:
	l32r	a8, .LC1002
	movi.n	a9, 1
	add.n	a8, a7, a8
	l32i	a11, sp, 260
	s8i	a9, a8, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115persistenceViewERKNS_3AppERN21MotorControlRSExample5Probe15PersistenceViewE
.L2281:
	movi.n	a2, 0
.L2284:
	retw.n
.LFE2348:
	.size	_ZN12_GLOBAL__N_111persistenceEPvPKN21MotorControlRSExample5Probe18PersistenceCommandERNS2_15PersistenceViewE, .-_ZN12_GLOBAL__N_111persistenceEPvPKN21MotorControlRSExample5Probe18PersistenceCommandERNS2_15PersistenceViewE
	.literal_position
	.literal .LC1052, 50000
	.literal .LC1053, 16843009
	.align	4
	.type	_ZN12_GLOBAL__N_116moveRequirementsERKNS_11MotionFactsERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE, @function
_ZN12_GLOBAL__N_116moveRequirementsERKNS_11MotionFactsERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE:
.LFB2116:
	entry	sp, 272
.LCFI123:
	mov.n	a10, a2
	mov.n	a7, a2
	s32i	a3, sp, 212
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE
	beqz.n	a10, .L2431
	l32i	a3, a2, 8
	l8ui	a8, a3, 3
	beqz.n	a8, .L2431
	l8ui	a8, a3, 0
	bnez.n	a8, .L2431
	addmi	a8, a3, 0x100
	l8ui	a8, a8, 12
	beqz.n	a8, .L2431
	l32i	a8, a3, 204
	l32i	a9, a3, 200
	bltu	a5, a8, .L2431
	bne	a8, a5, .L2447
	bltu	a4, a9, .L2431
.L2447:
	l32i	a10, a7, 32
	s32i	a10, sp, 216
	l32i	a10, a7, 36
	s32i	a10, sp, 208
	l32i	a11, sp, 208
	l32i	a10, sp, 216
	or	a10, a10, a11
	beqz.n	a10, .L2434
	sub	a8, a5, a8
	bgeu	a4, a9, .L2436
	addi.n	a8, a8, -1
.L2436:
	l32i	a10, sp, 208
	sub	a9, a4, a9
	bltu	a8, a10, .L2434
	bne	a10, a8, .L2431
	l32i	a8, sp, 216
	bgeu	a9, a8, .L2431
.L2434:
	l32i	a8, sp, 212
	l8ui	a8, a8, 19
	bnez.n	a8, .L2431
	l32i	a8, sp, 212
	l8ui	a2, a8, 22
	bnez.n	a2, .L2431
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy
	beqz.n	a10, .L2431
	l32i	a9, a7, 12
	s16i	a2, sp, 204
	l32i	a2, a7, 0
	l32i	a8, a7, 4
	movi	a10, 0x120
	l32i	a14, sp, 216
	l32i	a15, sp, 208
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a11, a2
	add.n	a10, a9, a10
	s32i	a8, sp, 220
	s32i	a9, sp, 224
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2431
	l32i	a9, sp, 224
	l16ui	a10, a9, 332
	bnez.n	a10, .L2431
	l32i	a8, sp, 220
	l16ui	a10, a8, 28
	bnez.n	a10, .L2431
	l8ui	a10, a8, 51
	beqz.n	a10, .L2431
	l8ui	a10, a9, 36
	s32i	a9, sp, 232
	bnez.n	a10, .L2431
	movi	a14, 0xcc
	add.n	a14, sp, a14
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_121positionStartingSpeedERKNS_11MotionFactsEyRt$constprop$0
	s32i	a10, sp, 224
	beqz.n	a10, .L2431
	l16ui	a8, sp, 204
	s32i	a8, sp, 228
	l32i	a8, sp, 212
	l16ui	a10, a8, 64
	l32i	a8, sp, 228
	bltu	a10, a8, .L2431
	l16ui	a11, a3, 54
	movi	a10, 0x7d0
	bltu	a10, a11, .L2431
	l16ui	a11, a3, 56
	bltu	a10, a11, .L2431
	l32i	a8, sp, 220
	l32i	a9, sp, 232
	movi	a11, 0x150
	add.n	a9, a9, a11
	addi	a10, a8, 34
	movi.n	a11, 4
	loop	a11, .L2439_LEND
.L2439:
	l16ui	a12, a10, 0
	bgeui	a12, 4, .L2431
	beqz.n	a12, .L2438
	l8ui	a12, a9, 0
	bnez.n	a12, .L2431
.L2438:
	addi.n	a10, a10, 2
	addi.n	a9, a9, 1
	.L2439_LEND:
	l32i	a8, sp, 212
	l8ui	a14, a8, 18
	bnez.n	a14, .L2440
	l32i	a9, a7, 40
	bnez.n	a9, .L2441
.L2431:
	movi.n	a8, 0
	s32i	a8, sp, 224
	j	.L2442
.L2441:
	movi	a12, 0xc0
	movi.n	a11, 0
	mov.n	a10, sp
	s32i	a14, sp, 216
	s32i	a9, sp, 208
	call8	memset
	l32i	a9, sp, 208
	movi.n	a12, 1
	l32i	a14, sp, 216
	s32i	a12, sp, 8
	s32i	a12, sp, 80
	l8ui	a12, a9, 18
	movi.n	a10, 1
	movi.n	a11, 0
	s8i	a10, sp, 18
	movi.n	a13, 2
	s8i	a10, sp, 41
	s8i	a10, sp, 168
	movnez	a14, a9, a12
	l32i	a10, sp, 212
	s32i	a11, sp, 12
	s8i	a13, sp, 20
	s32i	a11, sp, 84
	mov.n	a13, sp
	mov.n	a12, a14
	mov.n	a11, a2
	call8	_ZN14MotorControlRS15preparePositionERKNS_15PositionRequestERKNS_10AxisConfigEPKNS_13AxisReferenceERNS_14PreparedTargetE
	s32i	a10, sp, 192
	s32i	a11, sp, 196
	s32i	a12, sp, 200
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2431
	l32i	a8, sp, 212
	l8ui	a8, a8, 18
	bnez.n	a8, .L2431
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE
	beqz.n	a10, .L2431
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_123motionProfileStationaryERKNS_11MotionFactsEy
	beqz.n	a10, .L2431
	l32i	a8, a7, 32
	l32i	a9, a7, 12
	s32i	a8, sp, 216
	l32i	a2, a7, 0
	l32i	a8, a7, 36
	movi	a10, 0x240
	l32i	a14, sp, 216
	mov.n	a15, a8
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a11, a2
	add.n	a10, a9, a10
	s32i	a8, sp, 208
	s32i	a9, sp, 212
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2431
	l32i	a9, sp, 212
	addmi	a9, a9, 0x200
	l8ui	a10, a9, 124
	beqz.n	a10, .L2431
	l16ui	a9, a9, 122
	bnez.n	a9, .L2431
.L2440:
	movi.n	a12, 0x48
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi	a9, 0x7d0
	s16i	a9, sp, 16
	l32r	a9, .LC1052
	movi.n	a12, 0x48
	s32i	a9, sp, 20
	movi	a9, 0x64
	s16i	a9, sp, 24
	mov.n	a11, sp
	mov.n	a10, a6
	call8	memcpy
	l32i	a9, a2, 0
	l32i	a8, a2, 12
	l32i	a10, a2, 4
	s32i	a9, a6, 0
	l32i	a9, a2, 8
	s32i	a8, a6, 28
	l32r	a8, .LC1053
	s32i	a10, a6, 4
	s32i	a8, a6, 32
	movi	a8, 0x101
	s16i	a8, a6, 36
	l16ui	a8, a3, 54
	s32i	a9, a6, 8
	s16i	a8, a6, 40
	l16ui	a8, a3, 56
	s16i	a8, a6, 42
	movi.n	a8, 1
	s8i	a8, a6, 45
	l32i	a8, sp, 228
	s16i	a8, a6, 46
	l32i	a8, sp, 216
	s32i	a8, a6, 64
	l32i	a8, sp, 208
	s32i	a8, a6, 68
.L2442:
	l32i	a2, sp, 224
	retw.n
.LFE2116:
	.size	_ZN12_GLOBAL__N_116moveRequirementsERKNS_11MotionFactsERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE, .-_ZN12_GLOBAL__N_116moveRequirementsERKNS_11MotionFactsERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE
	.literal_position
	.literal .LC1054, 764696
	.literal .LC1055, 764504
	.literal .LC1056, 764516
	.literal .LC1058, _ZN12_GLOBAL__N_14uartE
	.literal .LC1059, 626184
	.literal .LC1060, 764508
	.literal .LC1061, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE, @function
_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE:
.LFB2073:
	entry	sp, 48
.LCFI124:
	l32r	a11, .LC1054
	movi.n	a12, 0x40
	add.n	a11, a3, a11
	mov.n	a10, a2
	call8	memcpy
	l32r	a7, .LC1055
	mov.n	a10, a2
	add.n	a4, a3, a7
	mov.n	a11, a4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	l32r	a8, .LC1056
	add.n	a8, a3, a8
	l32i	a6, a8, 0
	beqz.n	a10, .L2487
	l32i	a8, a2, 12
	beq	a8, a6, .L2488
.L2487:
	movi.n	a12, 0x40
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
.L2488:
	add.n	a8, a3, a7
	l32i	a10, a8, 0
	l32i	a9, a8, 4
	l32i	a8, a8, 8
	s32i	a6, a2, 12
	s32i	a10, a2, 0
	s32i	a9, a2, 4
	s32i	a8, a2, 8
	call8	_Z18esp_timer_get_timev
	l8ui	a5, a2, 18
	s32i	a10, a2, 48
	s32i	a11, a2, 52
	mov.n	a6, a10
	mov.n	a7, a11
	bnez.n	a5, .L2490
	l32i	a9, a3, 0
	movi	a8, 0x3e8
	mull	a10, a8, a9
	muluh	a8, a8, a9
	s32i	a10, a2, 56
	s32i	a8, a2, 60
.L2490:
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a3, a10
	l32i	a8, a10, 52
	beqi	a8, -1, .L2491
.L2493:
	movi.n	a10, 0
	j	.L2492
.L2491:
	l32i	a8, a10, 48
	bnez.n	a8, .L2493
	l8ui	a8, a10, 60
	beqi	a8, 1, .L2493
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L2493
	l32r	a10, .LC1058
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L2493
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L2493
	l32r	a8, .LC1059
	add.n	a8, a3, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2493
	l32r	a8, .LC1060
	movi.n	a12, 1
	add.n	a8, a3, a8
	l8ui	a11, a8, 0
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a8, 1
	xor	a10, a10, a8
	extui	a10, a10, 0, 8
.L2492:
	movi.n	a8, 0
	s8i	a8, a2, 17
	l32r	a8, .LC1061
	l32i	a14, a2, 56
	add.n	a9, a3, a8
	l32i	a15, a2, 60
	s8i	a10, a2, 16
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a11, a4
	mov.n	a10, a9
	s32i	a9, sp, 0
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2486
	l32r	a8, .LC1061
	bnez.n	a5, .L2495
	l32i	a9, sp, 0
	l32i	a10, a9, 240
	l32i	a11, a9, 244
	movi.n	a9, 3
	s32i	a10, a2, 40
	s32i	a11, a2, 44
	s8i	a9, a2, 33
.L2495:
	add.n	a3, a3, a8
	l8ui	a8, a3, 34
	bnez.n	a8, .L2497
	l8ui	a9, a3, 36
	bnez.n	a9, .L2496
	l8ui	a9, a3, 35
	bnez.n	a9, .L2496
	l16ui	a10, a3, 22
	movi.n	a9, 1
	moveqz	a8, a9, a10
	j	.L2496
.L2497:
	movi.n	a8, 0
.L2496:
	s8i	a8, a2, 17
.L2486:
	retw.n
.LFE2073:
	.size	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE, .-_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE
	.section	.rodata.str1.1
.LC1068:
	.string	"bus session owns the endpoint"
.LC1071:
	.string	"simple move owns the axis"
.LC1073:
	.string	"host polarity requires reconciliation"
	.text
	.literal_position
	.literal .LC1062, 764688
	.literal .LC1063, 764504
	.literal .LC1064, .LC12
	.literal .LC1066, 53807
	.literal .LC1067, 771250
	.literal .LC1069, .LC1068
	.literal .LC1070, 771808
	.literal .LC1072, .LC1071
	.literal .LC1074, .LC1073
	.literal .LC1075, 764516
	.literal .LC1076, 764696
	.literal .LC1077, 764708
	.literal .LC1078, .L2523
	.literal .LC1079, 764520
	.literal .LC1080, 771384
	.literal .LC1081, 771368
	.literal .LC1082, 771376
	.align	4
	.type	_ZN12_GLOBAL__N_111axisCommandEPvRKN21MotorControlRSExample5Probe11AxisCommandERNS2_8AxisViewE, @function
_ZN12_GLOBAL__N_111axisCommandEPvRKN21MotorControlRSExample5Probe11AxisCommandERNS2_8AxisViewE:
.LFB2074:
	entry	sp, 304
.LCFI125:
	l32r	a7, .LC1062
	l8ui	a6, a3, 0
	add.n	a8, a2, a7
	l8ui	a8, a8, 0
	s8i	a8, a4, 0
	bnez.n	a6, .L2509
	l32r	a11, .LC1063
	movi	a12, 0xb8
	add.n	a11, a2, a11
	addi.n	a10, a4, 8
	call8	memcpy
	movi	a8, 0xf8
	add.n	a8, sp, a8
	l32r	a9, .LC1064
	s8i	a6, a8, 0
	s32i	a6, a8, 4
	j	.L2549
.L2509:
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a2, a8
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	or	a9, a9, a8
	bnez.n	a9, .L2511
	l32r	a8, .LC1066
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2511
	l32r	a8, .LC1067
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2512
	j	.L2513
.L2511:
	movi.n	a8, 1
	s8i	a8, sp, 248
	movi	a8, 0xf8
	movi.n	a9, 0
	add.n	a8, sp, a8
	s32i	a9, a8, 4
	l32r	a9, .LC1069
	j	.L2549
.L2512:
	l32r	a8, .LC1070
	add.n	a8, a2, a8
	l8ui	a9, a8, 0
	bnez.n	a9, .L2513
	movi.n	a8, 1
	s8i	a8, sp, 248
	movi	a8, 0xf8
	add.n	a8, sp, a8
	s32i	a9, a8, 4
	l32r	a9, .LC1072
	j	.L2549
.L2513:
	movi	a5, 0xb8
	add.n	a5, sp, a5
	mov.n	a11, a2
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE
	l8ui	a8, a3, 0
	bnei	a8, 3, .L2514
	add.n	a7, a2, a7
	l8ui	a9, a7, 0
	bnez.n	a9, .L2515
	l8ui	a8, a3, 65
	beqz.n	a8, .L2515
	movi.n	a8, 1
	s8i	a8, sp, 248
	movi	a8, 0xf8
	add.n	a8, sp, a8
	s32i	a9, a8, 4
	l32r	a9, .LC1074
	j	.L2549
.L2515:
	movi.n	a12, 0x40
	addi	a11, a3, 48
	mov.n	a10, sp
	call8	memcpy
	l32r	a8, .LC1075
	l32r	a6, .LC1063
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	add.n	a11, a2, a6
	s32i	a8, sp, 24
	l8ui	a8, sp, 202
	movi.n	a12, 0
	beqz.n	a8, .L2517
	movi	a12, 0xb8
	add.n	a12, sp, a12
.L2517:
	movi	a13, 0xc0
	add.n	a13, a4, a13
	mov.n	a10, sp
	call8	_ZN14MotorControlRS15preparePositionERKNS_15PositionRequestERKNS_10AxisConfigEPKNS_13AxisReferenceERNS_14PreparedTargetE
	s32i	a10, sp, 260
	s32i	a11, sp, 264
	extui	a10, a10, 0, 8
	s32i	a12, sp, 268
	addmi	a7, sp, 0x100
	bnez.n	a10, .L2518
	movi	a12, 0xb8
	add.n	a11, a2, a6
	addi.n	a10, a4, 8
	call8	memcpy
.L2518:
	l32i	a11, a7, 4
	movi	a8, 0xf8
	add.n	a8, sp, a8
	l32i	a10, a7, 8
	l32i	a9, a7, 12
	s32i	a11, a8, 0
	j	.L2550
.L2514:
	l32r	a6, .LC1063
	bnei	a8, 2, .L2519
	l32i	a12, a3, 8
	l32i	a13, a3, 12
	add.n	a6, a2, a6
	mov.n	a14, a5
	mov.n	a10, a6
	call8	_ZN14MotorControlRS13setAxisOriginERNS_10AxisConfigExRKNS_13AxisReferenceE
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2520
	l32r	a10, .LC1076
	movi.n	a12, 0x40
	mov.n	a11, a5
	add.n	a10, a2, a10
	call8	memcpy
	l32r	a9, .LC1075
	l32r	a8, .LC1077
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	movi	a12, 0xb8
	mov.n	a11, a6
	addi.n	a10, a4, 8
	call8	memcpy
.L2520:
	l32i	a9, sp, 0
	movi	a8, 0xf8
	add.n	a8, sp, a8
	s32i	a9, a8, 0
	l32i	a9, sp, 4
	s32i	a9, a8, 4
	l32i	a9, sp, 8
	j	.L2549
.L2519:
	movi	a12, 0xb8
	add.n	a11, a2, a6
	mov.n	a10, sp
	call8	memcpy
	l8ui	a8, a3, 1
	movi.n	a9, 0xe
	bltu	a9, a8, .L2521
	l32r	a9, .LC1078
	addx4	a8, a8, a9
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L2523:
	.word	.L2537
	.word	.L2536
	.word	.L2535
	.word	.L2534
	.word	.L2543
	.word	.L2532
	.word	.L2531
	.word	.L2530
	.word	.L2529
	.word	.L2528
	.word	.L2527
	.word	.L2526
	.word	.L2525
	.word	.L2524
	.word	.L2522
	.text
.L2537:
	addi	a8, sp, 16
	j	.L2533
.L2532:
	l32i	a8, a3, 8
	s32i	a8, sp, 80
	j	.L2521
.L2531:
	l8ui	a8, a3, 41
	s8i	a8, sp, 76
	j	.L2521
.L2530:
	l32i	a8, a3, 8
	s8i	a8, sp, 84
	j	.L2521
.L2529:
	l32i	a8, a3, 8
	s8i	a8, sp, 88
	j	.L2521
.L2528:
	l8ui	a8, a3, 42
	s8i	a8, sp, 104
	j	.L2521
.L2527:
	l8ui	a9, a3, 43
	l8ui	a8, a3, 44
	s8i	a9, sp, 105
	s8i	a8, sp, 106
	j	.L2521
.L2526:
	l8ui	a11, a3, 45
	l8ui	a10, a3, 46
	l8ui	a8, a3, 47
	s8i	a11, sp, 107
	s8i	a10, sp, 108
	s8i	a8, sp, 109
	j	.L2521
.L2525:
	l32i	a8, a3, 8
	l32i	a9, a3, 12
	s32i	a8, sp, 112
	s32i	a9, sp, 116
	l32i	a8, a3, 24
	l32i	a9, a3, 28
	s32i	a8, sp, 120
	s32i	a9, sp, 124
	j	.L2521
.L2524:
	l8ui	a8, a3, 40
	movi.n	a9, 1
	xor	a8, a8, a9
	s8i	a8, sp, 161
	l32i	a9, a3, 12
	l32i	a8, a3, 8
	s32i	a9, sp, 172
	s32i	a8, sp, 168
	l32i	a9, a3, 28
	l32i	a8, a3, 24
	s32i	a9, sp, 180
	s32i	a8, sp, 176
	j	.L2521
.L2522:
	l32i	a8, a3, 8
	s8i	a8, sp, 128
	j	.L2521
.L2534:
	addi	a8, sp, 52
	j	.L2533
.L2535:
	addi	a8, sp, 40
	j	.L2533
.L2536:
	addi	a8, sp, 28
	j	.L2533
.L2543:
	addi	a8, sp, 64
.L2533:
	l8ui	a12, a3, 40
	movi.n	a9, 0
	movi.n	a10, 1
	movi.n	a11, 0
	bnez.n	a12, .L2538
	l32i	a11, a3, 8
	l32i	a10, a3, 16
	movi.n	a9, 1
.L2538:
	s32i	a11, a8, 0
	s32i	a10, a8, 4
	s8i	a9, a8, 8
.L2521:
	l32r	a13, .LC1076
	movi	a12, 0xb8
	add.n	a13, a2, a13
	add.n	a12, sp, a12
	mov.n	a11, sp
	add.n	a10, a2, a6
	call8	_ZN14MotorControlRS13configureAxisERNS_10AxisConfigERKS0_RKNS_13AxisReferenceEPS4_
	s32i	a10, sp, 260
	s32i	a11, sp, 264
	extui	a10, a10, 0, 8
	s32i	a12, sp, 268
	addmi	a5, sp, 0x100
	bnez.n	a10, .L2539
	l8ui	a8, a3, 1
	bnez.n	a8, .L2540
	l32r	a9, .LC1079
	l32r	a10, .LC1080
	add.n	a9, a2, a9
	l32i	a12, a9, 0
	movi.n	a11, 1
	add.n	a10, a2, a10
	moveqz	a11, a8, a12
	s8i	a11, a10, 0
	l32i	a10, a9, 4
	l32r	a9, .LC1081
	add.n	a9, a2, a9
	s32i	a12, a9, 0
	s32i	a8, a9, 4
	l32r	a9, .LC1082
	add.n	a9, a2, a9
	s32i	a10, a9, 0
	s32i	a8, a9, 4
	j	.L2541
.L2540:
	bnei	a8, 8, .L2541
	add.n	a8, a2, a7
	movi.n	a9, 1
	s8i	a9, a8, 0
.L2541:
	add.n	a7, a2, a7
	l8ui	a8, a7, 0
	movi	a12, 0xb8
	s8i	a8, a4, 0
	add.n	a11, a2, a6
	addi.n	a10, a4, 8
	call8	memcpy
.L2539:
	l32i	a11, a5, 4
	movi	a8, 0xf8
	add.n	a8, sp, a8
	l32i	a10, a5, 8
	l32i	a9, a5, 12
	s32i	a11, a8, 0
.L2550:
	s32i	a10, a8, 4
.L2549:
	s32i	a9, a8, 8
	movi	a8, 0xf8
	add.n	a8, sp, a8
	l32i	a2, a8, 0
	l32i	a3, a8, 4
	l32i	a4, a8, 8
	movi.n	a5, 0
	retw.n
.LFE2074:
	.size	_ZN12_GLOBAL__N_111axisCommandEPvRKN21MotorControlRSExample5Probe11AxisCommandERNS2_8AxisViewE, .-_ZN12_GLOBAL__N_111axisCommandEPvRKN21MotorControlRSExample5Probe11AxisCommandERNS2_8AxisViewE
	.literal_position
	.literal .LC1083, 771912
	.literal .LC1084, 772456
	.literal .LC1085, 45700
	.literal .LC1086, 764504
	.literal .LC1087, 757960
	.literal .LC1088, 770856
	.literal .LC1089, 625320
	.literal .LC1090, 771920
	.align	4
	.type	_ZN12_GLOBAL__N_116moveRequirementsERKNS_3AppERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE, @function
_ZN12_GLOBAL__N_116moveRequirementsERKNS_3AppERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE:
.LFB2117:
	entry	sp, 208
.LCFI126:
	movi.n	a12, 0x40
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l8ui	a8, a3, 18
	beqz.n	a8, .L2553
.L2555:
	movi.n	a10, 0
	j	.L2554
.L2553:
	mov.n	a11, a2
	addi	a10, sp, 112
	call8	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE
	movi.n	a12, 0x40
	addi	a11, sp, 112
	mov.n	a10, sp
	call8	memcpy
	l8ui	a8, a3, 18
	bnez.n	a8, .L2555
	mov.n	a10, sp
.L2554:
	l32r	a8, .LC1083
	l32i	a9, a2, 0
	add.n	a8, a2, a8
	l8ui	a14, a8, 0
	l32r	a8, .LC1084
	s8i	a14, sp, 80
	add.n	a8, a2, a8
	l32i	a13, a8, 0
	l32r	a8, .LC1085
	s32i	a13, sp, 88
	add.n	a8, a2, a8
	l32i	a12, a8, 0
	movi	a8, 0x3e8
	mull	a11, a8, a9
	muluh	a8, a8, a9
	l32r	a9, .LC1086
	s32i	a12, sp, 92
	add.n	a9, a2, a9
	s32i	a9, sp, 64
	l32r	a9, .LC1087
	s32i	a11, sp, 96
	add.n	a9, a2, a9
	s32i	a9, sp, 68
	l32r	a9, .LC1088
	s32i	a10, sp, 104
	add.n	a9, a2, a9
	s32i	a9, sp, 72
	l32r	a9, .LC1089
	mov.n	a14, a6
	add.n	a9, a2, a9
	s32i	a9, sp, 76
	l32r	a9, .LC1090
	mov.n	a12, a4
	add.n	a2, a2, a9
	mov.n	a13, a5
	mov.n	a11, a3
	addi	a10, sp, 64
	s32i	a2, sp, 84
	s32i	a8, sp, 100
	call8	_ZN12_GLOBAL__N_116moveRequirementsERKNS_11MotionFactsERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE
	mov.n	a2, a10
	retw.n
.LFE2117:
	.size	_ZN12_GLOBAL__N_116moveRequirementsERKNS_3AppERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE, .-_ZN12_GLOBAL__N_116moveRequirementsERKNS_3AppERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE
	.section	.rodata
	.align	4
.LC4:
	.word	10000
	.byte	20
	.zero	3
	.word	0
	.text
	.literal_position
	.literal .LC1091, _ZN14MotorControlRS6ESS_RS16prepareMoveAngleERNS0_11MoveContextERKNS_10AxisConfigEPKNS_13AxisReferenceEmRKNS_11MoveRequestERKNS0_17MovePrerequisitesEyyRKNS_13ActionOptionsE
	.literal .LC1092, _ZN14MotorControlRS6ESS_RS19prepareMoveAbsoluteERNS0_11MoveContextERKNS_10AxisConfigEPKNS_13AxisReferenceEmRKNS_11MoveRequestERKNS0_17MovePrerequisitesEyyRKNS_13ActionOptionsE
	.literal .LC1093, _ZN14MotorControlRS6ESS_RS19prepareMoveRelativeERNS0_11MoveContextERKNS_10AxisConfigEPKNS_13AxisReferenceEmRKNS_11MoveRequestERKNS0_17MovePrerequisitesEyyRKNS_13ActionOptionsE
	.literal .LC1094, 771840
	.literal .LC1095, 625320
	.literal .LC1096, 764504
	.literal .LC1097, 771912
	.literal .LC1098, 772456
	.literal .LC1099, 45700
	.literal .LC1100, 757960
	.literal .LC1101, 770856
	.literal .LC1102, 771920
	.literal .LC1103, 771944
	.literal .LC1104, 758011
	.literal .LC1105, 758028
	.literal .LC1106, 757978
	.literal .LC1107, 771808
	.literal .LC1108, 771198
	.literal .LC1109, 771194
	.literal .LC1110, 771199
	.literal .LC1111, 771196
	.literal .LC1112, 764770
	.literal .LC1113, .LC4
	.literal .LC1115, 500000
	.literal .LC1116, 757624
	.literal .LC1117, 771332
	.align	4
	.type	_ZN12_GLOBAL__N_119prepareSelectedMoveERNS_3AppERKN14MotorControlRS11MoveRequestEyyRNS2_6ESS_RS11MoveContextE, @function
_ZN12_GLOBAL__N_119prepareSelectedMoveERNS_3AppERKN14MotorControlRS11MoveRequestEyyRNS2_6ESS_RS11MoveContextE:
.LFB2143:
	entry	sp, 256
.LCFI127:
	l32r	a11, .LC1094
	movi.n	a12, 0x48
	add.n	a11, a2, a11
	addi	a10, sp, 32
	s32i	a7, sp, 200
	s32i	a6, sp, 196
	call8	memcpy
	l8ui	a8, sp, 64
	mov.n	a7, a2
	beqz.n	a8, .L2557
.L2560:
	l32r	a6, .LC1096
	l32r	a8, .LC1095
	add.n	a9, a7, a6
	l32i	a2, sp, 96
	l32i	a6, sp, 100
	add.n	a8, a7, a8
	mov.n	a10, a8
	mov.n	a14, a2
	mov.n	a15, a6
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a11, a9
	s32i	a8, sp, 204
	s32i	a9, sp, 192
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	l32i	a8, sp, 204
	bnez.n	a10, .L2558
	j	.L2611
.L2557:
	addi	a14, sp, 32
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116moveRequirementsERKNS_3AppERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE
	bnez.n	a10, .L2560
	j	.L2561
.L2611:
	s8i	a10, sp, 69
	j	.L2562
.L2558:
	l16ui	a9, a8, 22
	l32i	a10, a8, 240
	l32i	a11, a8, 244
	s16i	a9, sp, 82
	l16ui	a9, a8, 24
	s32i	a10, sp, 88
	s16i	a9, sp, 84
	s32i	a11, sp, 92
.L2562:
	l32r	a9, .LC1097
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L2563
	movi.n	a9, 0
	s16i	a9, sp, 168
	l32r	a9, .LC1098
	l32i	a10, a7, 0
	add.n	a9, a7, a9
	l32i	a13, a9, 0
	l32r	a9, .LC1099
	s32i	a8, sp, 116
	add.n	a9, a7, a9
	l32i	a12, a9, 0
	movi	a9, 0x3e8
	mull	a11, a9, a10
	muluh	a9, a9, a10
	l32i	a10, sp, 192
	movi.n	a8, 1
	s32i	a10, sp, 104
	l32r	a10, .LC1100
	movi	a14, 0xa8
	add.n	a10, a7, a10
	s32i	a10, sp, 108
	l32r	a10, .LC1101
	s8i	a8, sp, 120
	add.n	a10, a7, a10
	s32i	a10, sp, 112
	l32r	a10, .LC1102
	s32i	a13, sp, 128
	add.n	a10, a7, a10
	s32i	a10, sp, 124
	movi.n	a10, 0
	s32i	a12, sp, 132
	s32i	a11, sp, 136
	s32i	a9, sp, 140
	s32i	a10, sp, 144
	add.n	a14, sp, a14
	mov.n	a12, a4
	mov.n	a13, a5
	addi	a10, sp, 104
	s32i	a8, sp, 212
	s32i	a11, sp, 208
	s32i	a9, sp, 204
	call8	_ZN12_GLOBAL__N_121positionStartingSpeedERKNS_11MotionFactsEyRt$constprop$0
	l32i	a9, sp, 204
	l32i	a11, sp, 208
	l32i	a8, sp, 212
	bnez.n	a10, .L2564
.L2561:
	movi.n	a10, 3
	j	.L2565
.L2564:
	s8i	a8, sp, 77
	l16ui	a8, sp, 168
	l32i	a12, sp, 92
	s16i	a8, sp, 78
	l32r	a8, .LC1103
	l32i	a13, sp, 88
	add.n	a8, a7, a8
	l32i	a10, a8, 0
	l32i	a8, a8, 4
	bltu	a12, a8, .L2567
	bne	a8, a12, .L2566
	bgeu	a13, a10, .L2566
.L2567:
	mov.n	a10, a13
	mov.n	a8, a12
.L2566:
	s32i	a8, sp, 92
	s32i	a10, sp, 88
	or	a8, a11, a9
	beqz.n	a8, .L2563
	addi.n	a8, a6, -1
	movnez	a8, a6, a2
	addi.n	a10, a2, -1
	bltu	a8, a9, .L2563
	bne	a9, a8, .L2585
	bltu	a10, a11, .L2563
.L2585:
	s32i	a11, sp, 96
	s32i	a9, sp, 100
.L2563:
	l32r	a8, .LC1104
	l32r	a2, .LC1107
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	s8i	a8, sp, 76
	l32r	a8, .LC1105
	add.n	a8, a7, a8
	l16ui	a8, a8, 0
	s16i	a8, sp, 80
	l32r	a8, .LC1106
	add.n	a8, a7, a8
	l16ui	a8, a8, 0
	s16i	a8, sp, 44
	add.n	a8, a7, a2
	l8ui	a8, a8, 0
	beqz.n	a8, .L2573
	l32r	a8, .LC1108
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2574
	l32r	a8, .LC1109
	add.n	a8, a7, a8
	l16ui	a8, a8, 0
	s16i	a8, sp, 72
.L2574:
	l32r	a8, .LC1110
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2573
	l32r	a8, .LC1111
	add.n	a8, a7, a8
	l16ui	a8, a8, 0
	s16i	a8, sp, 74
.L2573:
	mov.n	a11, a7
	addi	a10, sp, 104
	call8	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE
	add.n	a8, a7, a2
	l8ui	a8, a8, 0
	l8ui	a9, sp, 122
	beqz.n	a8, .L2576
	l32r	a8, .LC1112
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2576
	movi.n	a8, 0
	beqz.n	a9, .L2576
	l8ui	a8, sp, 121
.L2576:
	s8i	a8, sp, 70
	l32r	a8, .LC1113
	l8ui	a10, a3, 19
	l32i	a8, a8, 4
	s32i	a8, sp, 184
	movi.n	a8, 0x40
	s8i	a8, sp, 184
	movi.n	a8, 0x20
	addmi	a8, a8, 0x4e00
	s32i	a8, sp, 180
	l32r	a8, .LC1115
	s32i	a8, sp, 188
	l32r	a8, .LC1091
	bnez.n	a10, .L2577
	l8ui	a10, a3, 18
	l32r	a8, .LC1092
	beqz.n	a10, .L2577
	l32r	a8, .LC1093
.L2577:
	movi.n	a10, 0
	addi	a12, sp, 104
	moveqz	a12, a10, a9
	addi	a11, sp, 32
	movi	a10, 0x94
	add.n	a10, a11, a10
	s32i	a10, sp, 16
	l32i	a10, sp, 196
	l32r	a9, .LC1116
	s32i	a10, sp, 8
	l32i	a10, sp, 200
	add.n	a9, a7, a9
	s32i	a10, sp, 12
	s32i	a4, sp, 0
	s32i	a5, sp, 4
	mov.n	a15, a11
	l32i	a13, a9, 0
	l32i	a11, sp, 192
	l32i	a10, sp, 256
	mov.n	a14, a3
	callx8	a8
	s32i	a10, sp, 168
	s32i	a11, sp, 172
	s32i	a12, sp, 176
	extui	a10, a10, 0, 8
	beqz.n	a10, .L2565
	add.n	a2, a7, a2
	l8ui	a8, a2, 0
	beqz.n	a8, .L2579
	l32r	a8, .LC1117
	addi	a9, sp, 32
	add.n	a7, a7, a8
	movi	a8, 0x88
	add.n	a8, a9, a8
	l32i	a11, a8, 0
	l32i	a9, a8, 4
	l32i	a8, a8, 8
	s32i	a11, a7, 0
	s32i	a9, a7, 4
	s32i	a8, a7, 8
.L2579:
	bnei	a10, 3, .L2584
	movi.n	a10, 0xb
	j	.L2565
.L2584:
	movi.n	a10, 8
.L2565:
	mov.n	a2, a10
	retw.n
.LFE2143:
	.size	_ZN12_GLOBAL__N_119prepareSelectedMoveERNS_3AppERKN14MotorControlRS11MoveRequestEyyRNS2_6ESS_RS11MoveContextE, .-_ZN12_GLOBAL__N_119prepareSelectedMoveERNS_3AppERKN14MotorControlRS11MoveRequestEyyRNS2_6ESS_RS11MoveContextE
	.section	.text._ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy,"axG",@progbits,_ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy,comdat
	.literal_position
	.literal .LC1118, .LC12
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy
	.type	_ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy, @function
_ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy:
.LFB1719:
	entry	sp, 32
.LCFI128:
	extui	a5, a5, 0, 8
	bgeui	a5, 3, .L2612
	addx8	a5, a5, a5
	slli	a5, a5, 5
	add.n	a2, a2, a5
	movi.n	a8, 1
	l32i	a11, a3, 0
	s8i	a8, a2, 217
	movi	a8, 0xc0
	add.n	a8, a2, a8
	l32i	a10, a3, 4
	s32i	a11, a8, 8
	addi.n	a9, a8, 8
	l32i	a8, a3, 8
	s32i	a10, a9, 4
	s32i	a8, a9, 8
	movi	a8, 0xe0
	s32i	a4, a2, 212
	add.n	a8, a2, a8
	s32i	a6, a8, 0
	s32i	a7, a8, 4
	movi	a8, 0xda
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	movi	a8, 0x110
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	movi	a8, 0x114
	add.n	a8, a2, a8
	movi.n	a9, 0
	s32i	a9, a8, 0
	l32r	a8, .LC1118
	s32i	a8, a2, 280
.L2612:
	retw.n
.LFE1719:
	.size	_ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy, .-_ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy
	.text
	.literal_position
	.literal .LC1119, 45756
	.literal .LC1120, 45752
	.literal .LC1122, 625320
	.align	4
	.type	_ZN12_GLOBAL__N_19admitStepERNS_3AppERNS0_6RecordEy, @function
_ZN12_GLOBAL__N_19admitStepERNS_3AppERNS0_6RecordEy:
.LFB2083:
	entry	sp, 192
.LCFI129:
	movi.n	a12, 0x30
	movi.n	a11, 0
	addi	a10, sp, 104
	call8	memset
	addi	a6, a3, 80
	addi	a14, sp, 104
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS8nextReadERKNS0_11ReadContextEyRNS0_12PreparedReadE
	extui	a10, a10, 0, 8
	mov.n	a7, a2
	movi.n	a2, 2
	bnez.n	a10, .L2616
	movi	a12, 0x60
	movi.n	a11, 0
	addi.n	a10, sp, 8
	call8	memset
	addi	a8, sp, 126
	s32i	a8, sp, 0
	l32i	a8, sp, 136
	l16ui	a10, sp, 124
	s32i	a8, sp, 4
	call8	_ZN14MotorControlRS6ESS_RS24expectedReadRegistersLenEt
	l32r	a8, .LC1119
	l32i	a9, sp, 148
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a9, sp, 28
	s32i	a8, sp, 12
	l32r	a8, .LC1120
	s32i	a10, sp, 8
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, sp, 16
	l32i	a8, sp, 144
	s32i	a8, sp, 24
	l8ui	a8, sp, 108
	s8i	a8, sp, 54
	movi.n	a8, 3
	s8i	a8, sp, 55
	l32i	a8, sp, 104
	s32i	a8, sp, 40
	l32i	a8, sp, 112
	s32i	a8, sp, 44
	l16ui	a8, sp, 122
	s16i	a8, sp, 48
	l16ui	a8, sp, 124
	s16i	a8, sp, 50
	call8	_ZN21MotorControlRSExample3Rtu12essValidatorEv
	s32i	a10, sp, 56
	movi	a10, 0x7f7
	slli	a10, a10, 5
	s32i	a11, sp, 60
	addi	a14, a3, 32
	mov.n	a12, a4
	mov.n	a13, a5
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner5admitERKNS0_10BusRequestEyRNS0_9RequestIdE
	mov.n	a2, a10
	bnez.n	a10, .L2616
	l8ui	a8, a3, 100
	bnei	a8, 2, .L2616
	addmi	a8, a3, 0x2300
	l8ui	a8, a8, 57
	beqz.n	a8, .L2619
	l8ui	a11, a3, 84
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	mov.n	a7, a10
	bnez.n	a10, .L2620
	j	.L2616
.L2619:
	l8ui	a13, a3, 128
	l32i	a12, a3, 92
	l32r	a10, .LC1122
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a11, a6
	j	.L2625
.L2620:
	mov.n	a11, a6
	addi.n	a10, a10, 8
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2616
	l8ui	a13, a3, 128
	l32i	a12, a3, 92
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a11, a6
	movi	a10, 0x5f8
.L2625:
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe12stateAttemptERNS0_10StateCacheERKN14MotorControlRS10ReadTargetEmhy
.L2616:
	retw.n
.LFE2083:
	.size	_ZN12_GLOBAL__N_19admitStepERNS_3AppERNS0_6RecordEy, .-_ZN12_GLOBAL__N_19admitStepERNS_3AppERNS0_6RecordEy
	.section	.text._ZN14MotorControlRS6ESS_RS19ReadStepObservationC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS19ReadStepObservationC5Ev,comdat
	.literal_position
	.literal .LC1124, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC2Ev
	.type	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC2Ev, @function
_ZN14MotorControlRS6ESS_RS19ReadStepObservationC2Ev:
.LFB1726:
	entry	sp, 32
.LCFI130:
	movi.n	a7, 0
	s16i	a7, a2, 0
	s16i	a7, a2, 2
	s8i	a7, a2, 4
	movi.n	a12, 0x25
	movi.n	a11, 0
	addi.n	a10, a2, 5
	call8	memset
	movi.n	a8, 0
	s32i	a8, a2, 44
	s32i	a8, a2, 48
	s32i	a8, a2, 88
	s32i	a8, a2, 92
	s32i	a8, a2, 104
	l32r	a8, .LC1124
	movi.n	a10, 0
	movi.n	a9, 0
	s8i	a7, a2, 52
	s32i	a10, a2, 56
	s32i	a9, a2, 60
	s32i	a10, a2, 64
	s32i	a9, a2, 68
	s32i	a10, a2, 72
	s32i	a9, a2, 76
	s32i	a10, a2, 80
	s32i	a9, a2, 84
	s8i	a7, a2, 96
	s8i	a7, a2, 100
	s32i	a8, a2, 108
	s8i	a7, a2, 112
	retw.n
.LFE1726:
	.size	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC2Ev, .-_ZN14MotorControlRS6ESS_RS19ReadStepObservationC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC1Ev
	.set	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC1Ev,_ZN14MotorControlRS6ESS_RS19ReadStepObservationC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS16StateObservationC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS16StateObservationC5Ev,comdat
	.literal_position
	.literal .LC1125, 118098176
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS16StateObservationC2Ev
	.type	_ZN14MotorControlRS6ESS_RS16StateObservationC2Ev, @function
_ZN14MotorControlRS6ESS_RS16StateObservationC2Ev:
.LFB1728:
	entry	sp, 32
.LCFI131:
	movi.n	a8, 0
	s32i	a8, a2, 0
	s8i	a8, a2, 4
	s32i	a8, a2, 8
	s32i	a8, a2, 12
	s32i	a8, a2, 16
	s8i	a8, a2, 20
	s16i	a8, a2, 22
	s32i	a8, a2, 24
	s16i	a8, a2, 30
	s32i	a8, a2, 32
	s32i	a8, a2, 36
	s32i	a8, a2, 40
	s32i	a8, a2, 44
	s32i	a8, a2, 48
	s32i	a8, a2, 52
	s32i	a8, a2, 56
	s32i	a8, a2, 64
	l32r	a8, .LC1125
	movi.n	a9, 0
	s32i	a8, a2, 68
	movi	a8, 0x705
	s16i	a8, a2, 72
	movi.n	a8, 8
	s8i	a9, a2, 28
	s8i	a9, a2, 60
	s8i	a8, a2, 74
	addi	a10, a2, 80
	call8	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC1Ev
	retw.n
.LFE1728:
	.size	_ZN14MotorControlRS6ESS_RS16StateObservationC2Ev, .-_ZN14MotorControlRS6ESS_RS16StateObservationC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS16StateObservationC1Ev
	.set	_ZN14MotorControlRS6ESS_RS16StateObservationC1Ev,_ZN14MotorControlRS6ESS_RS16StateObservationC2Ev
	.section	.text._ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy,"axG",@progbits,_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy,comdat
	.literal_position
	.literal .LC1126, .LC12
	.literal .LC1127, 118098176
	.literal .LC1128, 526085
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy
	.type	_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy, @function
_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy:
.LFB1720:
	entry	sp, 272
.LCFI132:
	l8ui	a10, a3, 20
	movi.n	a8, 1
	addi	a10, a10, -2
	moveqz	a8, a10, a10
	extui	a4, a4, 0, 8
	movi.n	a10, 2
	saltu	a10, a10, a4
	s32i	a6, sp, 224
	mov.n	a6, a3
	or	a3, a8, a10
	bnez.n	a3, .L2629
	slli	a5, a4, 3
	add.n	a10, a5, a4
	slli	a10, a10, 5
	add.n	a10, a2, a10
	l32i	a11, a10, 212
	l32i	a10, a6, 12
	bne	a11, a10, .L2631
	addx8	a10, a4, a4
	movi	a8, 0xc8
	slli	a10, a10, 5
	add.n	a10, a10, a8
	mov.n	a11, a6
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a3, a10
.L2631:
	movi	a12, 0xc8
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a10, .LC1127
	l32r	a8, .LC1126
	s32i	a10, sp, 68
	l32r	a10, .LC1128
	mov.n	a12, sp
	s32i	a10, sp, 72
	mov.n	a11, a4
	mov.n	a10, a6
	s32i	a8, sp, 188
	call8	_ZN14MotorControlRS6ESS_RS13getStateBlockERKNS0_11ReadContextEhRNS0_16StateObservationE
	movi	a13, 0xd4
	add.n	a13, sp, a13
	s32i	a12, a13, 8
	s32i	a10, a13, 0
	s32i	a11, a13, 4
	extui	a12, a10, 0, 8
	beqz.n	a3, .L2633
	add.n	a8, a5, a4
	slli	a8, a8, 5
	nsau	a10, a12
	srli	a10, a10, 5
	add.n	a8, a2, a8
	s8i	a10, a8, 218
	l32r	a3, .LC1126
	movi.n	a11, 0
	movi.n	a10, 0
	beqz.n	a12, .L2634
	slli	a8, a4, 4
	sub	a8, a8, a4
	addx8	a8, a8, a6
	movi	a11, 0xc0
	add.n	a11, a8, a11
	addi.n	a13, a11, 4
	movi	a10, 0xc8
	l32i	a11, a11, 4
	add.n	a10, sp, a10
	s32i	a11, a10, 0
	l32i	a14, a13, 4
	l32i	a11, a13, 8
	s32i	a14, a10, 4
	s32i	a11, a10, 8
	l32i	a3, a8, 204
	l8ui	a11, a8, 196
	l32i	a10, a8, 200
.L2634:
	s8i	a11, sp, 200
	add.n	a8, a5, a4
	movi	a11, 0xc8
	add.n	a11, sp, a11
	slli	a8, a8, 5
	s32i	a10, a11, 4
	s32i	a3, a11, 8
	add.n	a8, a2, a8
	l32i	a11, a11, 0
	movi	a13, 0x110
	add.n	a8, a8, a13
	s32i	a11, a8, 0
	s32i	a10, a8, 4
	s32i	a3, a8, 8
	extui	a11, a11, 0, 8
	bnez.n	a11, .L2633
	beqz.n	a12, .L2655
	l32i	a9, a6, 52
	l32i	a11, a6, 56
	s32i	a9, a8, 0
	l32i	a9, a6, 60
	s32i	a11, a8, 4
	s32i	a9, a8, 8
	j	.L2629
.L2633:
	bnez.n	a12, .L2629
.L2655:
	l32i	a8, sp, 148
	bltu	a8, a7, .L2629
	bne	a8, a7, .L2641
	l32i	a8, sp, 144
	l32i	a9, sp, 224
	bltu	a8, a9, .L2629
.L2641:
	add.n	a8, a5, a4
	slli	a8, a8, 5
	add.n	a8, a2, a8
	l8ui	a10, a8, 216
	l32i	a9, sp, 152
	l32i	a3, sp, 156
	beqz.n	a10, .L2637
	movi	a10, 0xf8
	add.n	a8, a8, a10
	l32i	a10, a8, 4
	bltu	a3, a10, .L2629
	bne	a10, a3, .L2642
	l32i	a8, a8, 0
	bltu	a9, a8, .L2629
.L2642:
	addx8	a8, a4, a4
	slli	a8, a8, 5
	add.n	a8, a2, a8
	l32i	a11, a8, 0
	l32i	a10, sp, 0
	bne	a11, a10, .L2637
	l8ui	a11, a8, 4
	l8ui	a10, sp, 4
	bne	a11, a10, .L2637
	l32i	a10, sp, 8
	l32i	a8, a8, 8
	bltu	a10, a8, .L2629
.L2637:
	add.n	a5, a5, a4
	slli	a5, a5, 5
	add.n	a2, a2, a5
	movi	a12, 0xc8
	mov.n	a11, sp
	mov.n	a10, a2
	s32i	a9, sp, 228
	call8	memcpy
	movi.n	a8, 1
	s8i	a8, a2, 216
	l32i	a9, sp, 228
	movi	a8, 0xf8
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s32i	a3, a8, 4
	movi	a8, 0xe8
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s32i	a3, a8, 4
	l32i	a9, sp, 224
	movi	a8, 0xf0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s32i	a7, a8, 4
	l32i	a9, sp, 164
	l32i	a8, sp, 160
	s32i	a9, a2, 260
	s32i	a8, a2, 256
.L2629:
	retw.n
.LFE1720:
	.size	_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy, .-_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy
	.text
	.literal_position
	.literal .LC1129, 101000
	.literal .LC1130, 625320
	.literal .LC1131, 105272
	.literal .LC1132, 65248
	.literal .LC1133, 9017
	.literal .LC1134, 764508
	.literal .LC1135, 764516
	.literal .LC1136, 772456
	.literal .LC1137, 757972
	.literal .LC1138, 758808
	.literal .LC1139, 759280
	.literal .LC1140, 759752
	.literal .LC1141, 757960
	.literal .LC1142, 757976
	.literal .LC1143, 758792
	.literal .LC1144, 759264
	.literal .LC1145, 759736
	.literal .LC1146, 45700
	.literal .LC1147, 764504
	.literal .LC1148, 772140
	.literal .LC1149, 328967
	.literal .LC1150, .LC12
	.literal .LC1151, 772128
	.literal .LC1152, 772072
	.literal .LC1153, 772292
	.literal .LC1154, 2293767
	.literal .LC1155, 118031621
	.literal .LC1156, 772280
	.literal .LC1157, 771952
	.literal .LC1161, 9040
	.literal .LC1162, 109032
	.literal .LC1163, 633352
	.literal .LC1164, 625568
	.literal .LC1165, 625380
	.literal .LC1166, 764696
	.literal .LC1167, 625384
	.literal .LC1168, 625374
	.literal .LC1169, 625376
	.literal .LC1170, 626144
	.literal .LC1171, 625956
	.literal .LC1172, 625960
	.literal .LC1173, 764633
	.literal .LC1174, 764649
	.literal .LC1175, 764665
	.literal .LC1176, 764770
	.literal .LC1177, 764772
	.literal .LC1178, 625896
	.literal .LC1180, _ZN12_GLOBAL__N_14uartE
	.align	4
	.type	_ZN12_GLOBAL__N_112advanceReadsERNS_3AppEy, @function
_ZN12_GLOBAL__N_112advanceReadsERNS_3AppEy:
.LFB2218:
	entry	sp, 416
.LCFI133:
	l32r	a8, .LC1130
	l32r	a7, .LC1129
	add.n	a8, a2, a8
	s32i	a8, sp, 348
	l32r	a8, .LC1131
	s32i	a4, sp, 328
	add.n	a3, a2, a8
	l32r	a8, .LC1136
	s32i	a5, sp, 324
	add.n	a8, a2, a8
	add.n	a7, a2, a7
	s32i	a8, sp, 368
	j	.L2657
.L2734:
	l32i	a8, a7, 4
	beqz.n	a8, .L2659
	l8ui	a8, a7, 0
	bnei	a8, 2, .L2659
	l8ui	a5, a7, 101
	bnei	a5, 1, .L2659
	l32i	a8, a7, 32
	beqz.n	a8, .L2661
	l32r	a8, .LC1132
	add.n	a8, a2, a8
	s32i	a8, sp, 344
	l32i	a10, sp, 344
	addi	a8, a7, 32
	mov.n	a11, a8
	s32i	a8, sp, 360
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	s32i	a10, sp, 332
	beqz.n	a10, .L2659
	l8ui	a8, a7, 128
	s32i	a8, sp, 336
	l8ui	a8, a10, 112
	beqi	a8, 1, .L2735
	movi.n	a9, 0x12
	beq	a8, a9, .L2737
	l8ui	a8, a10, 105
	beqz.n	a8, .L2737
	beqi	a8, 6, .L2737
	bnei	a8, 5, .L2663
	movi.n	a5, 2
	j	.L2663
.L2735:
	movi.n	a5, 0
	j	.L2663
.L2737:
	movi.n	a5, 3
.L2663:
	addi	a8, sp, 16
	movi	a6, 0xb0
	add.n	a6, a8, a6
	mov.n	a12, a5
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a11, sp, 332
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	addi	a8, a7, 80
	l32i	a12, sp, 328
	l32i	a13, sp, 324
	mov.n	a11, a6
	mov.n	a10, a8
	s32i	a8, sp, 320
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	beqz.n	a10, .L2664
	movi.n	a12, 1
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	movi.n	a8, -1
	s32i	a8, sp, 64
	l32i	a8, sp, 244
	l32i	a12, sp, 328
	s32i	a8, sp, 68
	movi.n	a8, 1
	s8i	a8, sp, 72
	l32i	a8, sp, 212
	l32i	a13, sp, 324
	s32i	a8, sp, 36
	l32i	a8, sp, 216
	l32i	a10, sp, 320
	s32i	a8, sp, 40
	addi	a11, sp, 16
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	s32i	a10, sp, 256
	s32i	a11, sp, 260
	s32i	a12, sp, 264
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2659
.L2664:
	l32i	a11, sp, 332
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE
	l32r	a8, .LC1133
	l8ui	a5, a7, 100
	add.n	a8, a7, a8
	s32i	a8, sp, 340
	l8ui	a8, a8, 0
	beqz.n	a8, .L2667
	l8ui	a11, a7, 84
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	mov.n	a6, a10
	bnei	a5, 2, .L2668
	beqz.n	a10, .L2668
	l32i	a11, sp, 320
	addi.n	a10, a10, 8
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2668
	l32i	a9, a3, 0
	l32i	a8, a6, 20
	bne	a9, a8, .L2668
	l32i	a8, sp, 332
	l32i	a12, sp, 336
	l32i	a14, a8, 120
	l32i	a15, a8, 124
	l32i	a11, sp, 320
	movi	a10, 0x5f8
	add.n	a10, a6, a10
	call8	_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy
	j	.L2669
.L2667:
	bnei	a5, 1, .L2671
	l32r	a8, .LC1134
	l8ui	a9, a7, 24
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bne	a9, a8, .L2671
	l32r	a8, .LC1135
	l32i	a9, a3, 0
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L2671
	l32r	a8, .LC1136
	l32i	a9, a7, 88
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L2671
	l32r	a5, .LC1137
	l32i	a8, a7, 4
	add.n	a5, a2, a5
	l32i	a9, a5, 0
	bgeu	a9, a8, .L2671
	l32r	a9, .LC1138
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	bgeu	a9, a8, .L2671
	l32r	a9, .LC1139
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	bgeu	a9, a8, .L2671
	l32r	a9, .LC1140
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	bgeu	a9, a8, .L2671
	movi.n	a4, 0
	movi.n	a6, 0
	j	.L2673
.L2680:
	movi.n	a12, 0xa
	movi.n	a11, 0
	addmi	a10, sp, 0x100
	call8	memset
	slli	a9, a4, 4
	sub	a9, a9, a4
	movi.n	a11, 0
	addx8	a9, a9, a7
	l16ui	a13, a9, 178
	l8ui	a12, a7, 24
	s32i	a11, sp, 304
	s32i	a11, sp, 4
	addi	a8, sp, 16
	movi	a11, 0x120
	add.n	a11, a8, a11
	slli	a10, a4, 4
	movi	a14, 0xb5
	s32i	a11, sp, 0
	sub	a10, a10, a4
	addx8	a10, a10, a14
	l32i	a11, a9, 220
	movi.n	a15, 5
	addmi	a14, sp, 0x100
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS14parseRegistersEPKhjhtPtjRjPNS0_10FrameErrorE
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2674
	l32i	a9, a5, 0
	bnez.n	a9, .L2675
	movi	a9, 0x309
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L2676
.L2675:
	l32r	a10, .LC1141
	l32i	a11, sp, 320
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2676
	slli	a9, a4, 4
	sub	a9, a9, a4
	addx8	a9, a9, a7
	l32r	a10, .LC1142
	l32i	a13, sp, 304
	l16ui	a11, a9, 176
	addmi	a12, sp, 0x100
	add.n	a10, a2, a10
	call8	_ZN12_GLOBAL__N_119changedConfigWindowERKN14MotorControlRS6ESS_RS9RawConfigEtPKtj
	or	a6, a6, a10
.L2676:
	l32r	a9, .LC1143
	add.n	a9, a2, a9
	s32i	a9, sp, 16
	l32r	a9, .LC1144
	add.n	a9, a2, a9
	s32i	a9, sp, 20
	l32r	a9, .LC1145
	add.n	a9, a2, a9
	s32i	a9, sp, 24
	movi.n	a9, 0
.L2679:
	addi	a8, sp, 16
	add.n	a10, a8, a9
	l32i	a14, a10, 0
	l32i	a10, a14, 16
	bnez.n	a10, .L2677
	movi	a10, 0x309
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L2678
.L2677:
	l32i	a11, sp, 320
	addi.n	a10, a14, 4
	s32i	a9, sp, 356
	s32i	a14, sp, 352
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	l32i	a14, sp, 352
	l32i	a9, sp, 356
	beqz.n	a10, .L2678
	slli	a10, a4, 4
	sub	a10, a10, a4
	addx8	a10, a10, a7
	l16ui	a11, a10, 176
	l32i	a13, sp, 304
	addmi	a12, sp, 0x100
	mov.n	a10, a14
	s32i	a9, sp, 352
	call8	_ZN12_GLOBAL__N_119changedDriverWindowERKN14MotorControlRS6ESS_RS17DriverObservationEtPKtj
	l32i	a9, sp, 352
	or	a6, a6, a10
.L2678:
	addi.n	a9, a9, 4
	bnei	a9, 12, .L2679
.L2674:
	addi.n	a8, a4, 1
	extui	a4, a8, 0, 8
.L2673:
	l8ui	a9, a7, 129
	bltu	a4, a9, .L2680
	l32i	a8, a3, 4
	and	a12, a8, a6
	xor	a12, a12, a6
	beqz.n	a12, .L2671
	or	a6, a6, a8
	movi	a8, 0x309
	s32i	a6, a3, 4
	add.n	a8, a7, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
	l8ui	a11, a7, 24
	movi.n	a8, 0
	l32i	a14, sp, 328
	l32i	a15, sp, 324
	s32i	a8, sp, 4
	s32i	a7, sp, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE
	l32r	a8, .LC1135
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a8, a3, 0
.L2671:
	l32r	a8, .LC1146
	l32i	a9, a7, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L2669
	l32r	a8, .LC1136
	l32i	a9, a7, 88
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L2669
	j	.L2876
.L2877:
	l32r	a8, .LC1136
	l32i	a9, a7, 88
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beq	a9, a8, .L2683
	j	.L2669
.L2876:
	l8ui	a8, a7, 100
	bnei	a8, 3, .L2683
	l32r	a11, .LC1147
	l32i	a10, sp, 320
	add.n	a11, a2, a11
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2683
	l32r	a8, .LC1135
	l32i	a9, a7, 96
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L2683
	l32r	a8, .LC1148
	l32i	a9, a7, 4
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bgeu	a8, a9, .L2683
	movi	a12, 0x98
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a8, .LC1149
	l32i	a10, sp, 320
	s32i	a8, sp, 44
	l32r	a8, .LC1150
	addi	a11, sp, 16
	s32i	a8, sp, 156
	call8	_ZN14MotorControlRS6ESS_RS21getVelocityParametersERKNS0_11ReadContextERNS0_29VelocityParametersObservationE
	s32i	a10, sp, 256
	s32i	a11, sp, 260
	s32i	a12, sp, 264
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2685
	l32r	a6, .LC1151
	add.n	a6, a2, a6
	l32i	a8, a6, 12
	beqz.n	a8, .L2739
	addi	a11, sp, 16
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2686
	l32i	a9, a6, 16
	l32i	a8, sp, 32
	bne	a9, a8, .L2739
	l16ui	a11, a6, 22
	l16ui	a9, sp, 38
	bne	a11, a9, .L2687
	l16ui	a9, a6, 24
	l16ui	a8, sp, 40
	bne	a9, a8, .L2687
	j	.L2686
.L2739:
	movi.n	a10, 0
.L2686:
	l32r	a8, .LC1152
	add.n	a8, a2, a8
	l8ui	a9, a8, 18
	beqz.n	a9, .L2688
	l16ui	a11, a8, 22
	l16ui	a9, sp, 38
	bne	a11, a9, .L2687
	l16ui	a9, a8, 24
	l16ui	a8, sp, 40
	bne	a9, a8, .L2687
.L2688:
	bnez.n	a10, .L2689
	j	.L2690
.L2687:
	l32r	a8, .LC1152
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 18
	j	.L2691
.L2689:
	l32r	a8, .LC1151
	add.n	a8, a2, a8
	l16ui	a9, a8, 20
	l16ui	a8, sp, 36
	beq	a9, a8, .L2690
.L2691:
	l32r	a8, .LC1152
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 20
.L2690:
	l32r	a10, .LC1151
	movi	a12, 0x98
	addi	a11, sp, 16
	add.n	a10, a2, a10
	call8	memcpy
.L2685:
	l32r	a8, .LC1146
	l32i	a9, a7, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beq	a9, a8, .L2877
	j	.L2669
.L2683:
	l8ui	a8, a7, 100
	bnei	a8, 4, .L2669
	l32r	a11, .LC1147
	l32i	a10, sp, 320
	add.n	a11, a2, a11
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a6, a10
	beqz.n	a10, .L2669
	l32r	a8, .LC1135
	l32i	a9, a7, 96
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L2669
	l32r	a8, .LC1153
	l32i	a9, a7, 4
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bgeu	a8, a9, .L2669
	movi	a12, 0xb0
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a8, .LC1154
	l32i	a10, sp, 320
	s32i	a8, sp, 52
	movi.n	a8, 2
	s8i	a8, sp, 56
	l32r	a8, .LC1155
	addi	a11, sp, 16
	s32i	a8, sp, 60
	movi.n	a8, 5
	s8i	a8, sp, 64
	l32r	a8, .LC1150
	s32i	a8, sp, 180
	call8	_ZN14MotorControlRS6ESS_RS19getHomingParametersERKNS0_11ReadContextERNS0_27HomingParametersObservationE
	s32i	a10, sp, 256
	s32i	a11, sp, 260
	s32i	a12, sp, 264
	extui	a10, a10, 0, 8
	bnez.n	a10, .L2669
	l32r	a5, .LC1156
	add.n	a5, a2, a5
	l32i	a8, a5, 12
	beqz.n	a8, .L2741
	addi	a11, sp, 16
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a8, a10
	beqz.n	a10, .L2694
	l32i	a10, a5, 16
	l32i	a9, sp, 32
	bne	a10, a9, .L2741
	l16ui	a11, a5, 20
	l16ui	a9, sp, 36
	mov.n	a10, a8
	bne	a11, a9, .L2695
	j	.L2694
.L2741:
	movi.n	a8, 0
.L2694:
	l32r	a9, .LC1157
	add.n	a9, a2, a9
	l8ui	a10, a9, 29
	beqz.n	a10, .L2696
	l16ui	a10, sp, 36
	l16ui	a9, a9, 30
	sub	a9, a10, a9
	movi.n	a10, 1
	moveqz	a10, a9, a9
.L2696:
	movi.n	a11, 0
	movi.n	a12, 0
	beqz.n	a8, .L2697
.L2695:
	l32r	a9, .LC1156
	l16ui	a8, sp, 38
	add.n	a9, a2, a9
	l16ui	a11, a9, 22
	l32i	a12, sp, 40
	sub	a11, a11, a8
	movi.n	a8, 1
	moveqz	a8, a11, a11
	l32i	a11, a9, 24
	l16ui	a13, a9, 28
	sub	a11, a11, a12
	movi.n	a12, 1
	moveqz	a12, a11, a11
	l16ui	a11, sp, 44
	l16ui	a14, a9, 30
	sub	a13, a13, a11
	movi.n	a11, 1
	moveqz	a11, a13, a13
	l16ui	a13, sp, 46
	bne	a14, a13, .L2698
	l16ui	a13, a9, 32
	l16ui	a9, sp, 48
	bne	a13, a9, .L2698
.L2697:
	l32r	a9, .LC1157
	add.n	a9, a2, a9
	l8ui	a6, a9, 28
	beqz.n	a6, .L2698
	l16ui	a9, sp, 46
	l16ui	a13, sp, 48
	movi.n	a6, 1
	or	a9, a9, a13
	extui	a9, a9, 0, 16
	moveqz	a6, a9, a9
.L2698:
	beqz.n	a10, .L2699
	l32r	a9, .LC1157
	movi.n	a13, 0
	add.n	a9, a2, a9
	s8i	a13, a9, 29
.L2699:
	beqz.n	a8, .L2700
	l32r	a9, .LC1157
	movi.n	a13, 0
	add.n	a9, a2, a9
	s8i	a13, a9, 16
.L2700:
	beqz.n	a12, .L2701
	l32r	a9, .LC1157
	movi.n	a13, 0
	add.n	a9, a2, a9
	s8i	a13, a9, 17
.L2701:
	beqz.n	a11, .L2702
	l32r	a9, .LC1157
	movi.n	a13, 0
	add.n	a9, a2, a9
	s8i	a13, a9, 18
.L2702:
	beqz.n	a6, .L2703
	l32r	a9, .LC1157
	movi.n	a13, 0
	add.n	a9, a2, a9
	s8i	a13, a9, 28
.L2703:
	bnez.n	a10, .L2704
	bnez.n	a8, .L2704
	beqz.n	a6, .L2705
.L2704:
	l32r	a8, .LC1157
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 35
	j	.L2706
.L2705:
	bnez.n	a12, .L2706
	beqz.n	a11, .L2707
.L2706:
	l32r	a8, .LC1157
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 34
	j	.L2707
.L2714:
	movi	a8, 0xa0
	addmi	a8, a8, -0x2000
	add.n	a9, a4, a8
	l8ui	a9, a9, 0
	bnei	a9, 7, .L2710
	l8ui	a9, a4, 172
	bnei	a9, 1, .L2710
	l16ui	a10, sp, 36
	l16ui	a9, a4, 70
	bne	a10, a9, .L2712
	l16ui	a10, sp, 38
	l16ui	a9, a4, 60
	bne	a10, a9, .L2712
	l16ui	a10, sp, 40
	l16ui	a9, a4, 62
	bne	a10, a9, .L2712
	l16ui	a10, sp, 42
	l16ui	a9, a4, 64
	bne	a10, a9, .L2712
	l16ui	a10, sp, 44
	l16ui	a9, a4, 66
	bne	a10, a9, .L2712
	l16ui	a9, sp, 46
	l16ui	a10, sp, 48
	or	a9, a9, a10
	extui	a9, a9, 0, 16
	beqz.n	a9, .L2710
.L2712:
	mov.n	a10, a4
	call8	_ZN14MotorControlRS6ESS_RS10revokeHomeERNS0_11HomeContextE
	movi.n	a9, -0x19
	addmi	a9, a9, -0x1f00
	add.n	a9, a4, a9
	s32i	a10, a5, 0
	movi.n	a10, 1
	s8i	a10, a9, 0
	movi	a9, 0xc0
	addmi	a9, a9, -0x2000
	add.n	a9, a4, a9
	l32i	a10, a9, 0
	s32i	a11, a5, 4
	s32i	a12, a5, 8
	s32i	a9, sp, 352
	beqz.n	a10, .L2710
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	l32i	a10, sp, 344
	l32i	a11, sp, 352
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L2710:
	l32r	a9, .LC1161
	add.n	a4, a4, a9
	j	.L2713
.L2707:
	l32r	a4, .LC1162
	l32r	a6, .LC1163
	movi	a8, 0x10c
	add.n	a4, a2, a4
	add.n	a6, a2, a6
	add.n	a5, sp, a8
.L2713:
	bne	a6, a4, .L2714
	l32r	a10, .LC1156
	movi	a12, 0xb0
	addi	a11, sp, 16
	add.n	a10, a2, a10
	call8	memcpy
.L2669:
	l32i	a8, sp, 340
	l8ui	a4, a8, 0
	bnez.n	a4, .L2668
	l8ui	a8, a7, 100
	bnei	a8, 2, .L2668
	l32r	a8, .LC1135
	l32i	a10, a3, 0
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a10, a8, .L2668
	l32i	a8, sp, 336
	addx8	a5, a8, a8
	l32r	a8, .LC1130
	slli	a5, a5, 5
	add.n	a5, a5, a8
	add.n	a8, a2, a5
	s32i	a8, sp, 352
	l32r	a8, .LC1147
	l32i	a10, sp, 352
	add.n	a8, a2, a8
	mov.n	a11, a8
	s32i	a8, sp, 340
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	l32i	a8, sp, 336
	mov.n	a6, a10
	addx8	a8, a8, a8
	l32r	a10, .LC1164
	slli	a8, a8, 5
	add.n	a8, a2, a8
	add.n	a10, a8, a10
	l32i	a9, a10, 0
	l32i	a5, a10, 4
	s32i	a9, sp, 356
	beqz.n	a6, .L2715
	l32r	a10, .LC1165
	add.n	a8, a8, a10
	l8ui	a6, a8, 0
	beqz.n	a6, .L2715
	l32r	a8, .LC1166
	add.n	a8, a2, a8
	l8ui	a10, a8, 18
	beqz.n	a10, .L2715
	l32i	a10, a8, 44
	movi.n	a6, 1
	bltu	a5, a10, .L2717
	bne	a10, a5, .L2716
	l32i	a8, a8, 40
	bgeu	a9, a8, .L2716
.L2717:
	movi.n	a6, 0
.L2716:
	extui	a6, a6, 0, 8
.L2715:
	l32i	a8, sp, 336
	l32r	a10, .LC1167
	addx8	a8, a8, a8
	slli	a8, a8, 5
	add.n	a8, a2, a8
	add.n	a10, a8, a10
	s32i	a8, sp, 372
	l32i	a8, a10, 0
	l32i	a12, sp, 336
	s32i	a8, sp, 364
	l32i	a8, sp, 332
	l32i	a10, sp, 348
	l32i	a14, a8, 120
	l32i	a15, a8, 124
	l32i	a11, sp, 320
	call8	_ZN21MotorControlRSExample5Probe11stateResultERNS0_10StateCacheERKN14MotorControlRS6ESS_RS11ReadContextEhy
	l32r	a10, .LC1166
	add.n	a10, a2, a10
	l8ui	a12, a10, 18
	beqz.n	a12, .L2744
	l32i	a11, a10, 24
	l32i	a14, a10, 28
	or	a11, a11, a14
	bnez.n	a11, .L2718
	l32r	a11, .LC1164
	l32i	a8, sp, 372
	l32i	a14, a10, 44
	add.n	a8, a8, a11
	l32i	a11, a8, 4
	bltu	a11, a14, .L2718
	bne	a14, a11, .L2747
	l32i	a10, a10, 40
	l32i	a8, a8, 0
	bltu	a8, a10, .L2718
.L2747:
	l32i	a8, sp, 336
	l32r	a9, .LC1168
	addx8	a8, a8, a8
	slli	a8, a8, 5
	add.n	a8, a2, a8
	add.n	a9, a8, a9
	l16ui	a10, a9, 0
	mov.n	a4, a12
	bnez.n	a10, .L2718
	l32r	a9, .LC1169
	movi.n	a4, 1
	add.n	a8, a8, a9
	l16ui	a8, a8, 0
	moveqz	a4, a8, a8
	j	.L2718
.L2744:
	movi.n	a4, 0
.L2718:
	l32i	a8, sp, 336
	bnei	a8, 2, .L2721
	l32i	a11, sp, 340
	l32i	a10, sp, 352
	s32i	a12, sp, 320
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	beqz.n	a10, .L2721
	l32r	a8, .LC1170
	l32i	a12, sp, 320
	add.n	a8, a2, a8
	l32i	a10, a8, 4
	bltu	a5, a10, .L2748
	bne	a10, a5, .L2721
	l32i	a8, a8, 0
	l32i	a9, sp, 356
	bgeu	a9, a8, .L2721
.L2748:
	beqz.n	a6, .L2724
	l32r	a8, .LC1171
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2724
	l32r	a8, .LC1172
	l32i	a9, sp, 364
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a8, a9, .L2725
.L2724:
	beqz.n	a4, .L2721
.L2725:
	l32r	a8, .LC1173
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2726
	l32r	a8, .LC1174
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2726
	l32r	a8, .LC1175
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2726
	beqz.n	a12, .L2721
.L2726:
	l32r	a8, .LC1176
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2721
	l32r	a8, .LC1177
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2721
	l32r	a8, .LC1134
	mov.n	a10, a2
	add.n	a8, a2, a8
	l8ui	a11, a8, 0
	call8	_ZN12_GLOBAL__N_115triggeredMotionERKNS_3AppEh
	bnez.n	a10, .L2721
	movi.n	a12, 0
	movi.n	a13, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
.L2721:
	l8ui	a8, a7, 101
	bnei	a8, 2, .L2668
	l32r	a6, .LC1177
	add.n	a6, a2, a6
	l8ui	a8, a6, 0
	beqz.n	a8, .L2659
	l32i	a8, a2, 0
	movi	a9, 0x3e8
	muluh	a4, a9, a8
	mull	a14, a9, a8
	l32i	a12, sp, 328
	l32i	a13, sp, 324
	l32i	a11, sp, 340
	l32i	a10, sp, 348
	mov.n	a15, a4
	s32i	a14, sp, 320
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2659
	l32r	a5, .LC1178
	l32i	a14, sp, 320
	add.n	a5, a2, a5
	l32i	a12, sp, 328
	l32i	a13, sp, 324
	l32i	a11, sp, 340
	mov.n	a15, a4
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2659
	l8ui	a8, a5, 60
	beqz.n	a8, .L2659
	l32r	a8, .LC1130
	add.n	a8, a2, a8
	l8ui	a8, a8, 34
	bnez.n	a8, .L2659
	l16ui	a8, a5, 58
	bnez.n	a8, .L2659
	s8i	a8, a6, 0
	j	.L2659
.L2668:
	l8ui	a8, a7, 101
	bnei	a8, 1, .L2659
	l32i	a11, sp, 360
	l32i	a10, sp, 344
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	movi.n	a8, 0
	s32i	a8, a7, 32
	s32i	a8, a7, 36
	s32i	a8, a7, 40
	s32i	a8, a7, 44
.L2661:
	l8ui	a8, a7, 71
	bnez.n	a8, .L2728
	l32i	a8, sp, 368
	l32i	a9, a7, 88
	l32i	a8, a8, 0
	bne	a9, a8, .L2728
	l8ui	a8, a7, 100
	bnei	a8, 2, .L2729
	l32r	a8, .LC1133
	l32i	a6, a3, 0
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2730
	l32r	a8, .LC1135
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	j	.L2731
.L2730:
	l8ui	a11, a7, 24
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	movi.n	a8, 0
	beqz.n	a10, .L2731
	l32i	a8, a10, 20
.L2731:
	beq	a6, a8, .L2729
.L2728:
	movi.n	a12, 2
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 328
	l32i	a13, sp, 324
	addi	a11, sp, 16
	addi	a10, a7, 80
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	s32i	a10, sp, 292
	s32i	a11, sp, 296
	s32i	a12, sp, 300
	j	.L2659
.L2729:
	l32i	a8, a7, 60
	l32i	a9, sp, 324
	bltu	a9, a8, .L2732
	bne	a8, a9, .L2749
	l32i	a8, a7, 56
	l32i	a9, sp, 328
	bltu	a9, a8, .L2732
.L2749:
	addi	a6, sp, 16
	mov.n	a10, a6
	movi.n	a12, 3
	mov.n	a11, a7
	call8	_ZN12_GLOBAL__N_19readEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 328
	l32i	a13, sp, 324
	mov.n	a11, a6
	addi	a10, a7, 80
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	s32i	a10, sp, 280
	s32i	a11, sp, 284
	s32i	a12, sp, 288
	addmi	a6, a6, 0x100
	j	.L2659
.L2732:
	l32r	a10, .LC1132
	add.n	a10, a2, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L2659
	l32r	a10, .LC1180
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L2659
	l32i	a12, sp, 328
	l32i	a13, sp, 324
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_19admitStepERNS_3AppERNS0_6RecordEy
.L2659:
	l32r	a8, .LC1161
	add.n	a7, a7, a8
	add.n	a3, a3, a8
.L2657:
	l32i	a8, sp, 348
	bne	a7, a8, .L2734
	retw.n
.LFE2218:
	.size	_ZN12_GLOBAL__N_112advanceReadsERNS_3AppEy, .-_ZN12_GLOBAL__N_112advanceReadsERNS_3AppEy
	.section	.text._ZN14MotorControlRS15PositionRequestC2Ev,"axG",@progbits,_ZN14MotorControlRS15PositionRequestC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS15PositionRequestC2Ev
	.type	_ZN14MotorControlRS15PositionRequestC2Ev, @function
_ZN14MotorControlRS15PositionRequestC2Ev:
.LFB1735:
	entry	sp, 32
.LCFI134:
	movi.n	a8, 0
	s32i	a8, a2, 0
	s32i	a8, a2, 4
	movi.n	a8, 1
	s32i	a8, a2, 8
	movi.n	a8, 0
	s32i	a8, a2, 12
	movi.n	a8, 1
	slli	a8, a8, 16
	s32i	a8, a2, 16
	movi.n	a8, 2
	s16i	a8, a2, 20
	movi.n	a8, 0
	s8i	a8, a2, 22
	movi.n	a8, 0
	movi.n	a9, 0
	s32i	a8, a2, 24
	s8i	a8, a2, 28
	movi	a10, 0x100
	movi.n	a8, 0
	s32i.n	a8, a2, 32
	s32i.n	a9, a2, 36
	s16i	a10, a2, 40
	s32i.n	a8, a2, 48
	s32i.n	a9, a2, 52
	s32i.n	a8, a2, 56
	s32i.n	a9, a2, 60
	retw.n
.LFE1735:
	.size	_ZN14MotorControlRS15PositionRequestC2Ev, .-_ZN14MotorControlRS15PositionRequestC2Ev
	.weak	_ZN14MotorControlRS15PositionRequestC1Ev
	.set	_ZN14MotorControlRS15PositionRequestC1Ev,_ZN14MotorControlRS15PositionRequestC2Ev
	.text
	.literal_position
	.literal .LC1188, .LC12
	.align	4
	.type	_ZN12_GLOBAL__N_13App14GroupOperationC2Ev, @function
_ZN12_GLOBAL__N_13App14GroupOperationC2Ev:
.LFB2037:
	entry	sp, 32
.LCFI135:
	movi.n	a7, 0
	movi.n	a8, 0
	s8i	a8, a2, 0
	addi	a10, a2, 24
	s32i	a7, a2, 4
	s32i	a7, a2, 8
	s16i	a7, a2, 12
	s32i	a7, a2, 16
	s32i	a7, a2, 20
	call8	_ZN14MotorControlRS15PositionRequestC1Ev
	movi.n	a9, 0
	movi.n	a8, 0
	movi.n	a6, 0
	movi	a12, 0x70
	movi	a10, 0x88
	s32i	a9, a2, 112
	s32i	a8, a2, 116
	s32i	a9, a2, 120
	s32i	a8, a2, 124
	movi.n	a11, 0
	s32i	a7, a2, 88
	s16i	a7, a2, 96
	s16i	a7, a2, 104
	s8i	a6, a2, 106
	s8i	a6, a2, 128
	addmi	a12, a12, 0x800
	add.n	a10, a2, a10
	call8	memset
	movi	a8, 0xa0
	l32r	a10, .LC1188
	add.n	a8, a2, a8
	movi	a11, 0x90
	movi.n	a9, 0xf
	loop	a9, .L2881_LEND
.L2881:
	s32i	a10, a8, 0
	s32i	a10, a8, 88
	add.n	a8, a8, a11
	.L2881_LEND:
	movi.n	a8, -8
	addmi	a8, a8, 0x900
	movi	a9, 0xe1
	add.n	a8, a2, a8
	slli	a9, a9, 9
	s32i	a9, a8, 0
	movi.n	a9, 0
	s8i	a9, a8, 4
	addmi	a2, a2, 0x900
	movi.n	a8, 0
	s32i	a8, a2, 0
	s32i	a8, a2, 4
	s32i	a8, a2, 8
	s32i	a8, a2, 12
	retw.n
.LFE2037:
	.size	_ZN12_GLOBAL__N_13App14GroupOperationC2Ev, .-_ZN12_GLOBAL__N_13App14GroupOperationC2Ev
	.set	_ZN12_GLOBAL__N_13App14GroupOperationC1Ev,_ZN12_GLOBAL__N_13App14GroupOperationC2Ev
	.align	4
	.type	_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE, @function
_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE:
.LFB2264:
	entry	sp, 32
.LCFI136:
	movi.n	a12, 0x10
	addmi	a12, a12, 0x900
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_13App14GroupOperationC1Ev
	retw.n
.LFE2264:
	.size	_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE, .-_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE
	.section	.text._ZN14MotorControlRS6ESS_RS19IdentityObservationC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS19IdentityObservationC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS19IdentityObservationC2Ev
	.type	_ZN14MotorControlRS6ESS_RS19IdentityObservationC2Ev, @function
_ZN14MotorControlRS6ESS_RS19IdentityObservationC2Ev:
.LFB1750:
	entry	sp, 32
.LCFI137:
	movi	a9, 0x181
	slli	a9, a9, 17
	movi.n	a8, 0
	s32i	a9, a2, 24
	movi.n	a9, 4
	addi	a10, a2, 36
	s32i	a8, a2, 0
	s8i	a8, a2, 4
	s32i	a8, a2, 8
	s32i	a8, a2, 12
	s32i	a8, a2, 16
	s32i	a8, a2, 20
	s8i	a9, a2, 28
	s32i	a8, a2, 32
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	addi	a10, a2, 48
	call8	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC1Ev
	retw.n
.LFE1750:
	.size	_ZN14MotorControlRS6ESS_RS19IdentityObservationC2Ev, .-_ZN14MotorControlRS6ESS_RS19IdentityObservationC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev
	.set	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev,_ZN14MotorControlRS6ESS_RS19IdentityObservationC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS17ConfigObservationC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS17ConfigObservationC5Ev,comdat
	.literal_position
	.literal .LC1194, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS17ConfigObservationC2Ev
	.type	_ZN14MotorControlRS6ESS_RS17ConfigObservationC2Ev, @function
_ZN14MotorControlRS6ESS_RS17ConfigObservationC2Ev:
.LFB1756:
	entry	sp, 32
.LCFI138:
	movi.n	a8, 0
	s32i	a8, a2, 0
	s8i	a8, a2, 4
	s32i	a8, a2, 8
	s32i	a8, a2, 12
	s32i	a8, a2, 16
	s32i	a8, a2, 20
	s32i	a8, a2, 24
	s32i	a8, a2, 28
	s32i	a8, a2, 32
	s32i	a8, a2, 36
	s32i	a8, a2, 40
	s32i	a8, a2, 44
	s32i	a8, a2, 48
	s32i	a8, a2, 52
	s8i	a8, a2, 56
	s16i	a8, a2, 58
	s32i	a8, a2, 60
	s32i	a8, a2, 64
	s32i	a8, a2, 72
	s32i	a8, a2, 76
	s32i	a8, a2, 80
	s32i	a8, a2, 84
	s32i	a8, a2, 88
	s32i	a8, a2, 92
	s16i	a8, a2, 96
	movi.n	a8, 4
	s32i	a8, a2, 100
	movi.n	a8, 0x40
	s32i	a8, a2, 104
	movi	a8, 0x400
	s32i	a8, a2, 108
	movi.n	a9, 1
	movi	a8, 0x100
	slli	a9, a9, 16
	s32i	a8, a2, 112
	movi	a8, 0x605
	s16i	a8, a2, 116
	s32i	a9, a2, 68
	addi	a10, a2, 120
	call8	_ZN14MotorControlRS10UnitConfigC1Ev
	movi	a10, 0xd8
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	movi	a10, 0xe8
	movi	a12, 0x258
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a8, .LC1194
	s32i	a8, a2, 340
	s32i	a8, a2, 460
	s32i	a8, a2, 580
	s32i	a8, a2, 700
	s32i	a8, a2, 820
	retw.n
.LFE1756:
	.size	_ZN14MotorControlRS6ESS_RS17ConfigObservationC2Ev, .-_ZN14MotorControlRS6ESS_RS17ConfigObservationC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev
	.set	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev,_ZN14MotorControlRS6ESS_RS17ConfigObservationC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS27HomingParametersObservationC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC5Ev,comdat
	.literal_position
	.literal .LC1195, 2293767
	.literal .LC1196, 118031621
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC2Ev
	.type	_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC2Ev, @function
_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC2Ev:
.LFB1762:
	entry	sp, 32
.LCFI139:
	movi.n	a8, 0
	s32i	a8, a2, 0
	s8i	a8, a2, 4
	s32i	a8, a2, 8
	s32i	a8, a2, 12
	s32i	a8, a2, 16
	s32i	a8, a2, 20
	s32i	a8, a2, 24
	s32i	a8, a2, 28
	s32i	a8, a2, 32
	l32r	a8, .LC1195
	addi	a10, a2, 56
	s32i	a8, a2, 36
	movi.n	a8, 2
	s32i	a8, a2, 40
	l32r	a8, .LC1196
	s32i	a8, a2, 44
	movi.n	a8, 5
	s8i	a8, a2, 48
	call8	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC1Ev
	retw.n
.LFE1762:
	.size	_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC2Ev, .-_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC1Ev
	.set	_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC1Ev,_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS17DriverObservationC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS17DriverObservationC5Ev,comdat
	.literal_position
	.literal .LC1197, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS17DriverObservationC2Ev
	.type	_ZN14MotorControlRS6ESS_RS17DriverObservationC2Ev, @function
_ZN14MotorControlRS6ESS_RS17DriverObservationC2Ev:
.LFB1768:
	entry	sp, 32
.LCFI140:
	movi.n	a7, 0
	movi.n	a8, 0
	s8i	a8, a2, 0
	movi.n	a12, 0x20
	movi.n	a11, 0
	s32i	a7, a2, 4
	s8i	a7, a2, 8
	s32i	a7, a2, 12
	s32i	a7, a2, 16
	s32i	a7, a2, 20
	addi	a10, a2, 24
	call8	memset
	movi.n	a8, 1
	s8i	a8, a2, 56
	s32i	a7, a2, 60
	s32i	a7, a2, 64
	s32i	a7, a2, 68
	s8i	a7, a2, 72
	s32i	a7, a2, 76
	s32i	a7, a2, 80
	movi	a12, 0x180
	movi.n	a11, 0
	addi	a10, a2, 88
	call8	memset
	l32r	a8, .LC1197
	s32i	a8, a2, 172
	s32i	a8, a2, 268
	s32i	a8, a2, 364
	s32i	a8, a2, 460
	retw.n
.LFE1768:
	.size	_ZN14MotorControlRS6ESS_RS17DriverObservationC2Ev, .-_ZN14MotorControlRS6ESS_RS17DriverObservationC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	.set	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev,_ZN14MotorControlRS6ESS_RS17DriverObservationC2Ev
	.section	.text._ZN21MotorControlRSExample5Probe12GroupCommandC2Ev,"axG",@progbits,_ZN21MotorControlRSExample5Probe12GroupCommandC5Ev,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe12GroupCommandC2Ev
	.type	_ZN21MotorControlRSExample5Probe12GroupCommandC2Ev, @function
_ZN21MotorControlRSExample5Probe12GroupCommandC2Ev:
.LFB1777:
	entry	sp, 32
.LCFI141:
	movi.n	a8, 0
	s8i	a8, a2, 0
	movi.n	a12, 0xf
	movi.n	a11, 0
	addi.n	a10, a2, 1
	call8	memset
	movi.n	a7, 0
	s32i	a7, a2, 16
	s8i	a7, a2, 20
	s8i	a7, a2, 21
	s8i	a7, a2, 22
	addi	a10, a2, 24
	call8	_ZN14MotorControlRS15PositionRequestC1Ev
	movi.n	a8, 0
	s32i	a7, a2, 88
	s16i	a7, a2, 96
	s8i	a8, a2, 104
	retw.n
.LFE1777:
	.size	_ZN21MotorControlRSExample5Probe12GroupCommandC2Ev, .-_ZN21MotorControlRSExample5Probe12GroupCommandC2Ev
	.weak	_ZN21MotorControlRSExample5Probe12GroupCommandC1Ev
	.set	_ZN21MotorControlRSExample5Probe12GroupCommandC1Ev,_ZN21MotorControlRSExample5Probe12GroupCommandC2Ev
	.text
	.literal_position
	.literal .LC1198, _ZN12_GLOBAL__N_13appE
	.literal .LC1199, 826592
	.align	4
	.type	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE, @function
_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE:
.LFB2415:
	entry	sp, 32
.LCFI142:
	l32r	a8, .LC1198
	mov.n	a6, a2
	l32i	a2, a8, 0
	beqz.n	a2, .L2896
	l32r	a8, .LC1199
	movi	a12, 0x70
	add.n	a2, a2, a8
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe12GroupCommandC1Ev
	s8i	a6, a2, 0
.L2896:
	retw.n
.LFE2415:
	.size	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE, .-_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE
	.section	.text._ZN14MotorControlRS6ESS_RS14ActionEvidenceC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS14ActionEvidenceC5Ev,comdat
	.literal_position
	.literal .LC1201, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC2Ev
	.type	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC2Ev, @function
_ZN14MotorControlRS6ESS_RS14ActionEvidenceC2Ev:
.LFB1855:
	entry	sp, 32
.LCFI143:
	movi.n	a8, 0
	s8i	a8, a2, 0
	s8i	a8, a2, 1
	movi.n	a12, 0x13
	movi.n	a11, 0
	addi.n	a10, a2, 2
	call8	memset
	movi.n	a9, 0
	s32i	a9, a2, 44
	s32i	a9, a2, 52
	s32i	a9, a2, 60
	l32r	a9, .LC1201
	movi.n	a8, 0
	movi.n	a10, 0
	s32i	a8, a2, 24
	s32i	a8, a2, 28
	s32i	a8, a2, 32
	s32i	a8, a2, 36
	s32i	a10, a2, 40
	s32i	a10, a2, 48
	s32i	a10, a2, 56
	s32i	a8, a2, 64
	s32i	a8, a2, 68
	s32i	a8, a2, 72
	s32i	a9, a2, 76
	s8i	a8, a2, 80
	retw.n
.LFE1855:
	.size	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC2Ev, .-_ZN14MotorControlRS6ESS_RS14ActionEvidenceC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	.set	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev,_ZN14MotorControlRS6ESS_RS14ActionEvidenceC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS20CommunicationContextC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS20CommunicationContextC5Ev,comdat
	.literal_position
	.literal .LC1202, 65793
	.literal .LC1204, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS20CommunicationContextC2Ev
	.type	_ZN14MotorControlRS6ESS_RS20CommunicationContextC2Ev, @function
_ZN14MotorControlRS6ESS_RS20CommunicationContextC2Ev:
.LFB1859:
	entry	sp, 32
.LCFI144:
	movi.n	a7, 0
	addi	a10, a2, 48
	s32i	a7, a2, 0
	s8i	a7, a2, 4
	s32i	a7, a2, 8
	s32i	a7, a2, 12
	s8i	a7, a2, 16
	s32i	a7, a2, 20
	s32i	a7, a2, 24
	s8i	a7, a2, 28
	s32i	a7, a2, 32
	s32i	a7, a2, 36
	s8i	a7, a2, 40
	s32i	a7, a2, 44
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	addi	a10, a2, 60
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	addi	a10, a2, 72
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	addi	a10, a2, 84
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	l32r	a8, .LC1202
	movi	a3, 0xa8
	movi.n	a5, 0
	movi.n	a6, 0
	add.n	a3, a2, a3
	movi.n	a4, 0
	s32i	a8, a2, 124
	s32i	a7, a2, 96
	s8i	a7, a2, 100
	s16i	a7, a2, 102
	s32i	a7, a2, 104
	s32i	a7, a2, 108
	s32i	a7, a2, 112
	s32i	a7, a2, 116
	s32i	a7, a2, 120
	s8i	a4, a2, 128
	s32i	a5, a2, 136
	s32i	a6, a2, 140
	s32i	a5, a2, 144
	s32i	a6, a2, 148
	s32i	a5, a2, 152
	s32i	a6, a2, 156
	s32i	a5, a2, 160
	s32i	a6, a2, 164
	s32i	a7, a2, 168
	s8i	a4, a2, 172
	s32i	a7, a2, 176
	addi.n	a10, a3, 12
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	addi	a10, a3, 40
	s32i	a5, a2, 192
	s32i	a6, a2, 196
	s32i	a5, a2, 200
	s32i	a6, a2, 204
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	addmi	a10, a2, 0x100
	s16i	a7, a2, 296
	s8i	a4, a10, 42
	movi	a12, 0x110
	movi.n	a11, 0
	addi	a10, a10, 48
	call8	memset
	l32r	a8, .LC1204
	s32i	a8, a2, 556
	s32i	a8, a2, 420
	addmi	a2, a2, 0x200
	s8i	a4, a2, 64
	s32i	a7, a2, 68
	s32i	a8, a2, 72
	retw.n
.LFE1859:
	.size	_ZN14MotorControlRS6ESS_RS20CommunicationContextC2Ev, .-_ZN14MotorControlRS6ESS_RS20CommunicationContextC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS20CommunicationContextC1Ev
	.set	_ZN14MotorControlRS6ESS_RS20CommunicationContextC1Ev,_ZN14MotorControlRS6ESS_RS20CommunicationContextC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC2Ev
	.type	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC2Ev, @function
_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC2Ev:
.LFB1866:
	entry	sp, 32
.LCFI145:
	mov.n	a10, a2
	call8	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev
	movi	a10, 0x340
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev
	movi	a10, 0x3e8
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS16StateObservationC1Ev
	movi	a10, 0x4b0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	addmi	a2, a2, 0x400
	movi.n	a8, 0
	movi.n	a9, 0
	s32i	a8, a2, 188
	s32i	a9, a2, 192
	s32i	a9, a2, 196
	s32i	a8, a2, 200
	s8i	a8, a2, 204
	s32i	a8, a2, 208
	retw.n
.LFE1866:
	.size	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC2Ev, .-_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC1Ev
	.set	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC1Ev,_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS23PersistenceVerificationC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC2Ev
	.type	_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC2Ev, @function
_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC2Ev:
.LFB1869:
	entry	sp, 32
.LCFI146:
	mov.n	a10, a2
	call8	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev
	movi	a10, 0x340
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev
	movi	a10, 0x3e8
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS16StateObservationC1Ev
	movi	a10, 0x4b0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	addmi	a2, a2, 0x400
	movi.n	a8, 0
	movi.n	a10, 0
	movi.n	a9, 0
	s32i	a8, a2, 188
	s32i	a10, a2, 192
	s32i	a9, a2, 196
	s8i	a8, a2, 200
	s32i	a10, a2, 208
	s32i	a9, a2, 212
	s32i	a8, a2, 216
	retw.n
.LFE1869:
	.size	_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC2Ev, .-_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC1Ev
	.set	_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC1Ev,_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS18PersistenceContextC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS18PersistenceContextC5Ev,comdat
	.literal_position
	.literal .LC1208, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS18PersistenceContextC2Ev
	.type	_ZN14MotorControlRS6ESS_RS18PersistenceContextC2Ev, @function
_ZN14MotorControlRS6ESS_RS18PersistenceContextC2Ev:
.LFB1874:
	entry	sp, 32
.LCFI147:
	movi.n	a7, 0
	addi	a10, a2, 24
	s32i	a7, a2, 0
	s8i	a7, a2, 4
	s32i	a7, a2, 8
	s32i	a7, a2, 12
	s32i	a7, a2, 16
	s8i	a7, a2, 20
	call8	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC1Ev
	movi	a10, 0x4f0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC1Ev
	addmi	a8, a2, 0x900
	movi	a9, 0x100
	s32i	a9, a8, 212
	movi.n	a10, 0
	movi.n	a9, 0
	addmi	a5, a2, 0xa00
	movi.n	a6, 0
	s32i	a10, a8, 232
	s32i	a10, a8, 240
	s32i	a10, a8, 248
	s32i	a7, a8, 208
	s8i	a7, a8, 216
	s16i	a7, a8, 218
	s16i	a7, a8, 220
	s8i	a6, a8, 222
	s32i	a7, a8, 224
	s32i	a9, a8, 236
	s32i	a9, a8, 244
	s32i	a9, a8, 252
	mov.n	a10, a5
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a12, 0xf0
	movi.n	a11, 0
	addi	a10, a5, 88
	call8	memset
	l32r	a8, .LC1208
	addmi	a2, a2, 0xb00
	s8i	a6, a2, 72
	s32i	a7, a2, 76
	s32i	a8, a2, 80
	retw.n
.LFE1874:
	.size	_ZN14MotorControlRS6ESS_RS18PersistenceContextC2Ev, .-_ZN14MotorControlRS6ESS_RS18PersistenceContextC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS18PersistenceContextC1Ev
	.set	_ZN14MotorControlRS6ESS_RS18PersistenceContextC1Ev,_ZN14MotorControlRS6ESS_RS18PersistenceContextC2Ev
	.section	.rodata
	.align	4
.LC2:
	.word	115200
	.byte	0
	.zero	3
	.word	115200
	.byte	0
	.zero	3
	.word	115200
	.byte	0
	.zero	3
	.word	115200
	.byte	0
	.zero	3
	.section	.text._ZN21MotorControlRSExample5Probe13DiscoveryScanC2Ev,"axG",@progbits,_ZN21MotorControlRSExample5Probe13DiscoveryScanC5Ev,comdat
	.literal_position
	.literal .LC1209, .LC2
	.literal .LC1211, 524304
	.literal .LC1215, .LC12
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe13DiscoveryScanC2Ev
	.type	_ZN21MotorControlRSExample5Probe13DiscoveryScanC2Ev, @function
_ZN21MotorControlRSExample5Probe13DiscoveryScanC2Ev:
.LFB1889:
	entry	sp, 32
.LCFI148:
	movi.n	a7, 0
	l32r	a11, .LC1209
	s16i	a7, a2, 0
	s8i	a7, a2, 2
	movi.n	a12, 0x20
	addi.n	a10, a2, 4
	call8	memcpy
	movi	a8, 0x1f4
	s32i	a8, a2, 40
	movi	a8, 0x88
	addmi	a8, a8, 0x1300
	s32i	a8, a2, 44
	movi	a9, 0xe1
	l32r	a8, .LC1211
	slli	a9, a9, 9
	movi.n	a10, 0
	s32i	a8, a2, 48
	s32i	a9, a2, 64
	movi.n	a8, 0
	movi.n	a9, 0
	movi.n	a12, 0x45
	s8i	a7, a2, 36
	s32i	a8, a2, 52
	s8i	a7, a2, 56
	s32i	a8, a2, 60
	s8i	a7, a2, 68
	s32i	a8, a2, 72
	s32i	a8, a2, 76
	s32i	a10, a2, 80
	s32i	a9, a2, 84
	s32i	a10, a2, 88
	s32i	a9, a2, 92
	s32i	a10, a2, 96
	s32i	a9, a2, 100
	s32i	a8, a2, 104
	s32i	a8, a2, 108
	s16i	a8, a2, 112
	s8i	a7, a2, 114
	movi.n	a11, 0
	slli	a12, a12, 6
	addi	a10, a2, 120
	call8	memset
	l32r	a8, .LC1215
	movi.n	a10, 2
	movi	a6, 0x182
	movi	a7, 0x183
	movi.n	a15, 3
	movi	a14, 0x184
	movi.n	a13, 4
	movi	a11, 0x228
	movi.n	a9, 8
	loop	a9, .L2911_LEND
.L2911:
	s8i	a10, a2, 222
	s32i	a8, a2, 232
	s32i	a8, a2, 348
	add.n	a12, a2, a6
	s8i	a10, a12, 0
	add.n	a12, a2, a7
	s8i	a15, a12, 0
	add.n	a12, a2, a14
	s8i	a13, a12, 0
	s32i	a8, a2, 516
	s32i	a8, a2, 636
	add.n	a2, a2, a11
	.L2911_LEND:
	retw.n
.LFE1889:
	.size	_ZN21MotorControlRSExample5Probe13DiscoveryScanC2Ev, .-_ZN21MotorControlRSExample5Probe13DiscoveryScanC2Ev
	.weak	_ZN21MotorControlRSExample5Probe13DiscoveryScanC1Ev
	.set	_ZN21MotorControlRSExample5Probe13DiscoveryScanC1Ev,_ZN21MotorControlRSExample5Probe13DiscoveryScanC2Ev
	.text
	.literal_position
	.literal .LC1216, 53696
	.literal .LC1217, 58992
	.literal .LC1218, 65248
	.literal .LC1219, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1220, 45697
	.literal .LC1222, _ZN12_GLOBAL__N_14uartE
	.literal .LC1223, 626184
	.literal .LC1224, 64907
	.literal .LC1226, 47848
	.literal .LC1227, 770856
	.literal .LC1228, 757624
	.literal .LC1230, 764508
	.literal .LC1232, 59999
	.literal .LC1233, 45688
	.literal .LC1235, 764504
	.literal .LC1237, 45700
	.literal .LC1238, 59009
	.literal .LC1239, 772492
	.align	4
	.type	_ZN12_GLOBAL__N_116discoveryCommandEPvPKN21MotorControlRSExample5Probe16DiscoveryCommandERNS2_13DiscoveryViewE, @function
_ZN12_GLOBAL__N_116discoveryCommandEPvPKN21MotorControlRSExample5Probe16DiscoveryCommandERNS2_13DiscoveryViewE:
.LFB2356:
	entry	sp, 144
.LCFI149:
	l32r	a6, .LC1216
	mov.n	a7, a2
	add.n	a6, a2, a6
	s32i	a6, a4, 0
	beqz.n	a3, .L2916
	l8ui	a8, a3, 0
	bnei	a8, 1, .L2917
	l8ui	a9, a6, 111
	movi.n	a2, 9
	beqz.n	a9, .L2918
	l8ui	a9, a6, 104
	beqi	a9, 4, .L2918
	s8i	a8, a6, 114
	l32r	a6, .LC1217
	add.n	a6, a7, a6
	l32i	a8, a6, 0
	beqz.n	a8, .L2916
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	l32r	a10, .LC1218
	mov.n	a13, a11
	add.n	a10, a7, a10
	mov.n	a11, a6
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L2916:
	movi.n	a2, 0
	j	.L2918
.L2917:
	bnei	a8, 2, .L2920
	l8ui	a8, a6, 104
	bnei	a8, 4, .L2921
	movi.n	a8, 3
	s8i	a8, a6, 104
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116discoveryRestoreERNS_3AppE
	l8ui	a2, a6, 112
	movi.n	a8, 1
	xor	a2, a2, a8
	add.n	a2, a2, a2
	extui	a2, a2, 0, 8
	j	.L2918
.L2920:
	bnei	a8, 3, .L2922
	l8ui	a8, a6, 104
	beqi	a8, 5, .L2923
.L2924:
	movi.n	a2, 1
	j	.L2918
.L2923:
	l8ui	a8, a6, 111
	bnez.n	a8, .L2924
	movi.n	a8, 1
	s8i	a8, a6, 113
	j	.L2916
.L2922:
	bnez.n	a8, .L2921
	l8ui	a8, a6, 111
	bnez.n	a8, .L2924
	l32i	a8, a6, 72
	beqz.n	a8, .L2925
	l8ui	a8, a6, 113
	beqz.n	a8, .L2924
.L2925:
	l32r	a8, .LC1219
	movi.n	a2, 3
	l8ui	a8, a8, 0
	beqz.n	a8, .L2918
	l32r	a8, .LC1220
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2926
.L2927:
	movi.n	a2, 2
	j	.L2918
.L2926:
	movi	a8, 0x165
	slli	a8, a8, 7
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L2927
	l32r	a2, .LC1218
	add.n	a2, a7, a2
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L2927
	l32r	a10, .LC1222
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L2927
	l8ui	a8, a2, 137
	bnez.n	a8, .L2924
	l32i	a8, a2, 152
	l32i	a9, a2, 156
	or	a8, a8, a9
	bnez.n	a8, .L2924
	l32i	a8, a2, 52
	bnei	a8, -1, .L2924
	l32i	a8, a2, 48
	bnez.n	a8, .L2924
	l8ui	a8, a2, 60
	beqi	a8, 1, .L2924
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L2924
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L2924
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L2924
	l32r	a8, .LC1223
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2924
	l32r	a8, .LC1224
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2924
	movi	a8, 0x3f5
	slli	a8, a8, 6
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2924
	l32r	a8, .LC1226
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L2924
	l32r	a8, .LC1227
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L2924
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L2924
	l32r	a8, .LC1228
	movi.n	a2, 7
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L2918
	movi.n	a12, 0x34
	addi.n	a11, a3, 4
	mov.n	a10, sp
	call8	memcpy
	movi.n	a12, 0x12
	movi.n	a11, 0
	addi	a10, sp, 52
	call8	memset
	l8ui	a10, sp, 0
	addi	a11, sp, 52
	call8	_ZN14MotorControlRS24getDiscoveryCapabilitiesENS_12DriveProfileERNS_21DiscoveryCapabilitiesE
	s32i	a10, sp, 72
	s32i	a11, sp, 76
	s32i	a12, sp, 80
	extui	a10, a10, 0, 8
	beqz.n	a10, .L2928
.L2934:
	movi.n	a2, 0xb
	j	.L2918
.L2928:
	l32i	a8, sp, 0
	extui	a8, a8, 8, 16
	bnez.n	a8, .L2929
	l32r	a8, .LC1230
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	s8i	a8, sp, 2
	s8i	a8, sp, 1
.L2929:
	l8ui	a3, sp, 1
	l8ui	a8, sp, 57
	bltu	a3, a8, .L2921
	l8ui	a8, sp, 2
	l8ui	a9, sp, 58
	bltu	a9, a8, .L2921
	bltu	a8, a3, .L2921
	l32i	a8, sp, 40
	movi	a9, 0x87
	addi.n	a8, a8, -1
	addmi	a9, a9, 0x1300
	bltu	a9, a8, .L2921
	l32i	a4, sp, 44
	l32r	a9, .LC1232
	addi.n	a8, a4, -1
	bltu	a9, a8, .L2921
	l16ui	a8, sp, 48
	movi	a9, 0xff
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 16
	bltu	a9, a8, .L2921
	l8ui	a8, sp, 50
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 8
	bgeui	a8, 8, .L2921
	l8ui	a5, sp, 36
	bgeui	a5, 5, .L2921
	bnez.n	a5, .L2932
	l32r	a11, .LC1233
	movi.n	a8, 1
	movi.n	a12, 5
	add.n	a11, a7, a11
	addi.n	a10, sp, 4
	s8i	a8, sp, 36
	movi.n	a5, 1
	call8	memcpy
.L2932:
	movi.n	a12, 0
	addi.n	a9, sp, 4
.L2936:
	mov.n	a10, a9
	s32i	a12, sp, 100
	s32i	a9, sp, 96
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	l32i	a9, sp, 96
	l32i	a12, sp, 100
	bnez.n	a10, .L2943
	j	.L2934
.L2935:
	mov.n	a10, a9
	s32i	a11, sp, 100
	s32i	a12, sp, 104
	s32i	a9, sp, 96
	call8	_ZN21MotorControlRSExample9sameTupleERKNS_9HostTupleES2_
	l32i	a11, sp, 100
	addi.n	a11, a11, 8
	bnez.n	a10, .L2921
	addi.n	a2, a2, 1
	l32i	a9, sp, 96
	l32i	a12, sp, 104
	extui	a2, a2, 0, 8
	j	.L2933
.L2943:
	addi.n	a11, sp, 4
	movi.n	a2, 0
.L2933:
	bne	a2, a12, .L2935
	addi.n	a2, a2, 1
	extui	a12, a2, 0, 8
	addi.n	a9, a9, 8
	bne	a12, a5, .L2936
	l32r	a9, .LC1216
	movi	a12, 0xb8
	add.n	a2, a7, a9
	addmi	a12, a12, 0x1100
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe13DiscoveryScanC1Ev
	movi.n	a12, 0x34
	mov.n	a11, sp
	mov.n	a10, a2
	call8	memcpy
	l32r	a8, .LC1235
	movi	a10, 0x69
	add.n	a8, a7, a8
	l32i	a12, a8, 0
	l32i	a11, a8, 4
	s32i	a12, a2, 52
	l32i	a8, a8, 8
	s32i	a11, a2, 56
	l32r	a11, .LC1233
	slli	a10, a10, 9
	movi.n	a12, 5
	s32i	a8, a2, 60
	add.n	a11, a7, a11
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a8, .LC1237
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 76
	l32r	a8, .LC1228
	add.n	a5, a7, a8
	l32i	a8, a5, 0
	addi.n	a10, a8, 1
	s32i	a10, a5, 0
	s32i	a8, a2, 72
	call8	_Z18esp_timer_get_timev
	movi	a8, 0x3e8
	mull	a12, a8, a4
	muluh	a8, a8, a4
	s32i	a10, a2, 80
	s32i	a11, a2, 84
	add.n	a10, a12, a10
	l32r	a9, .LC1216
	add.n	a11, a8, a11
	bgeu	a10, a12, .L2938
	addi.n	a11, a11, 1
.L2938:
	s32i	a10, a2, 88
	add.n	a8, a7, a9
	s32i	a11, a2, 92
	movi.n	a9, 1
	s8i	a9, a8, 111
	s8i	a9, a8, 104
	l8ui	a9, a8, 56
	l32r	a10, .LC1238
	s8i	a3, a8, 110
	srli	a8, a9, 3
	add.n	a10, a7, a10
	add.n	a7, a7, a8
	l32r	a8, .LC1239
	extui	a9, a9, 0, 3
	add.n	a7, a7, a8
	l8ui	a8, a7, 0
	ssr	a9
	srl	a8, a8
	extui	a8, a8, 0, 1
	s8i	a8, a10, 0
	j	.L2916
.L2921:
	movi.n	a2, 8
.L2918:
	retw.n
.LFE2356:
	.size	_ZN12_GLOBAL__N_116discoveryCommandEPvPKN21MotorControlRSExample5Probe16DiscoveryCommandERNS2_13DiscoveryViewE, .-_ZN12_GLOBAL__N_116discoveryCommandEPvPKN21MotorControlRSExample5Probe16DiscoveryCommandERNS2_13DiscoveryViewE
	.section	.text._ZN14MotorControlRS6ESS_RS11ReadContextC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS11ReadContextC5Ev,comdat
	.literal_position
	.literal .LC1241, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS11ReadContextC2Ev
	.type	_ZN14MotorControlRS6ESS_RS11ReadContextC2Ev, @function
_ZN14MotorControlRS6ESS_RS11ReadContextC2Ev:
.LFB1892:
	entry	sp, 32
.LCFI150:
	l32r	a6, .LC1241
	movi.n	a7, 0
	movi.n	a9, 0
	movi.n	a8, 0
	movi.n	a10, 0
	s8i	a10, a2, 22
	s32i	a9, a2, 24
	s32i	a8, a2, 28
	s32i	a9, a2, 32
	s32i	a8, a2, 36
	s32i	a9, a2, 40
	s32i	a8, a2, 44
	s8i	a10, a2, 52
	s32i	a7, a2, 0
	addi	a10, a2, 64
	s8i	a7, a2, 4
	s32i	a7, a2, 8
	s32i	a7, a2, 12
	s32i	a7, a2, 16
	s16i	a7, a2, 20
	s16i	a7, a2, 48
	s32i	a7, a2, 56
	s32i	a6, a2, 60
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	movi.n	a8, 1
	s32i	a7, a2, 76
	s32i	a7, a2, 80
	s32i	a7, a2, 84
	s16i	a8, a2, 88
	movi	a12, 0x258
	movi.n	a11, 0
	addi	a10, a2, 96
	call8	memset
	s32i	a6, a2, 204
	s32i	a6, a2, 324
	s32i	a6, a2, 444
	s32i	a6, a2, 564
	s32i	a6, a2, 684
	retw.n
.LFE1892:
	.size	_ZN14MotorControlRS6ESS_RS11ReadContextC2Ev, .-_ZN14MotorControlRS6ESS_RS11ReadContextC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS11ReadContextC1Ev
	.set	_ZN14MotorControlRS6ESS_RS11ReadContextC1Ev,_ZN14MotorControlRS6ESS_RS11ReadContextC2Ev
	.section	.text._ZN21MotorControlRSExample3Rtu14RecoveryResultC2Ev,"axG",@progbits,_ZN21MotorControlRSExample3Rtu14RecoveryResultC5Ev,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample3Rtu14RecoveryResultC2Ev
	.type	_ZN21MotorControlRSExample3Rtu14RecoveryResultC2Ev, @function
_ZN21MotorControlRSExample3Rtu14RecoveryResultC2Ev:
.LFB1896:
	entry	sp, 32
.LCFI151:
	movi.n	a8, 0
	movi.n	a9, 0
	movi.n	a10, 0
	s32i	a8, a2, 4
	s32i	a8, a2, 12
	s32i	a8, a2, 20
	s32i	a8, a2, 28
	s32i	a8, a2, 44
	movi.n	a8, 1
	s32i	a9, a2, 0
	s32i	a9, a2, 8
	s32i	a9, a2, 16
	s32i	a9, a2, 24
	s32i	a10, a2, 32
	s32i	a10, a2, 36
	s32i	a9, a2, 40
	s16i	a8, a2, 48
	retw.n
.LFE1896:
	.size	_ZN21MotorControlRSExample3Rtu14RecoveryResultC2Ev, .-_ZN21MotorControlRSExample3Rtu14RecoveryResultC2Ev
	.weak	_ZN21MotorControlRSExample3Rtu14RecoveryResultC1Ev
	.set	_ZN21MotorControlRSExample3Rtu14RecoveryResultC1Ev,_ZN21MotorControlRSExample3Rtu14RecoveryResultC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS13ActionContextC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS13ActionContextC5Ev,comdat
	.literal_position
	.literal .LC1245, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS13ActionContextC2Ev
	.type	_ZN14MotorControlRS6ESS_RS13ActionContextC2Ev, @function
_ZN14MotorControlRS6ESS_RS13ActionContextC2Ev:
.LFB1905:
	entry	sp, 32
.LCFI152:
	movi.n	a10, 0x10
	addmi	a10, a10, 0x2700
	movi.n	a7, 0
	movi.n	a8, 0
	movi.n	a9, 0
	s32i	a10, a2, 40
	movi.n	a6, 0
	movi.n	a10, 0x14
	s32i	a8, a2, 28
	s32i	a8, a2, 60
	s32i	a8, a2, 68
	s32i	a8, a2, 76
	s32i	a8, a2, 84
	s32i	a9, a2, 24
	s32i	a9, a2, 56
	s32i	a9, a2, 64
	s32i	a9, a2, 72
	s32i	a9, a2, 80
	s8i	a10, a2, 44
	s32i	a7, a2, 0
	addi	a10, a2, 112
	s8i	a7, a2, 4
	s32i	a7, a2, 8
	s32i	a7, a2, 12
	s32i	a7, a2, 16
	s8i	a7, a2, 32
	s32i	a7, a2, 48
	s32i	a7, a2, 52
	s32i	a7, a2, 88
	s16i	a7, a2, 92
	s8i	a6, a2, 94
	s32i	a7, a2, 96
	s32i	a7, a2, 100
	s32i	a7, a2, 104
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0xc8
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x120
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	l32r	a8, .LC1245
	addmi	a2, a2, 0x100
	s8i	a6, a2, 120
	s32i	a7, a2, 124
	s32i	a8, a2, 128
	retw.n
.LFE1905:
	.size	_ZN14MotorControlRS6ESS_RS13ActionContextC2Ev, .-_ZN14MotorControlRS6ESS_RS13ActionContextC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS13ActionContextC1Ev
	.set	_ZN14MotorControlRS6ESS_RS13ActionContextC1Ev,_ZN14MotorControlRS6ESS_RS13ActionContextC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS11MoveContextC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS11MoveContextC5Ev,comdat
	.literal_position
	.literal .LC1247, 50000
	.literal .LC1252, .LC12
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS11MoveContextC2Ev
	.type	_ZN14MotorControlRS6ESS_RS11MoveContextC2Ev, @function
_ZN14MotorControlRS6ESS_RS11MoveContextC2Ev:
.LFB1929:
	entry	sp, 32
.LCFI153:
	movi.n	a7, 0
	movi.n	a5, 0
	movi.n	a6, 0
	movi.n	a4, 0
	movi.n	a3, 1
	s16i	a3, a2, 44
	addi	a10, a2, 80
	s16i	a4, a2, 0
	s32i	a7, a2, 8
	s8i	a4, a2, 12
	s32i	a7, a2, 16
	s32i	a7, a2, 20
	s32i	a7, a2, 24
	s32i	a7, a2, 28
	s32i	a7, a2, 32
	s32i	a7, a2, 36
	s32i	a7, a2, 40
	s32i	a5, a2, 48
	s32i	a6, a2, 52
	s32i	a5, a2, 56
	s32i	a6, a2, 60
	s32i	a7, a2, 64
	s8i	a4, a2, 68
	s32i	a7, a2, 72
	s32i	a7, a2, 76
	call8	_ZN14MotorControlRS15PositionRequestC1Ev
	movi	a8, 0x7d0
	s16i	a8, a2, 168
	l32r	a8, .LC1247
	s32i	a7, a2, 144
	s32i	a8, a2, 172
	movi	a8, 0x64
	s16i	a8, a2, 176
	movi	a8, 0xe0
	add.n	a8, a2, a8
	s32i	a7, a2, 152
	s8i	a4, a2, 156
	s32i	a7, a2, 160
	s16i	a7, a2, 164
	s32i	a7, a2, 180
	s32i	a7, a2, 184
	s16i	a7, a2, 188
	s8i	a4, a2, 190
	s32i	a7, a2, 192
	s32i	a7, a2, 196
	s32i	a7, a2, 200
	s16i	a7, a2, 204
	s32i	a5, a2, 208
	s32i	a6, a2, 212
	s32i	a5, a2, 216
	s32i	a6, a2, 220
	s32i	a7, a8, 0
	s8i	a4, a8, 4
	s32i	a7, a8, 8
	s32i	a7, a8, 12
	s16i	a7, a2, 240
	s8i	a4, a8, 18
	s32i	a5, a8, 24
	s32i	a6, a8, 28
	s16i	a7, a2, 256
	s32i	a5, a8, 40
	s32i	a6, a8, 44
	movi	a10, 0x120
	s32i	a5, a8, 48
	add.n	a10, a2, a10
	s32i	a6, a8, 52
	s32i	a5, a8, 56
	s32i	a6, a8, 60
	call8	_ZN14MotorControlRS15PositionRequestC1Ev
	movi.n	a9, 1
	s32i	a9, a2, 368
	movi.n	a9, 0
	addmi	a8, a2, 0x100
	s32i	a9, a8, 116
	movi.n	a11, 0
	movi.n	a10, 0
	movi	a9, 0x1cc
	s32i	a10, a8, 128
	s32i	a11, a8, 132
	s32i	a10, a8, 184
	s32i	a11, a8, 188
	s32i	a10, a8, 192
	s32i	a11, a8, 196
	s8i	a3, a8, 200
	s8i	a4, a8, 120
	s8i	a4, a8, 144
	s8i	a4, a8, 160
	s8i	a4, a8, 176
	s32i	a5, a8, 96
	s32i	a6, a8, 100
	s32i	a5, a8, 104
	s32i	a6, a8, 108
	s32i	a5, a8, 136
	s32i	a6, a8, 140
	s32i	a5, a8, 152
	s32i	a6, a8, 156
	s32i	a5, a8, 168
	s32i	a6, a8, 172
	add.n	a9, a2, a9
	s32i	a7, a9, 0
	s8i	a4, a9, 4
	s32i	a7, a9, 8
	movi.n	a10, 0x10
	movi	a9, 0x1e0
	add.n	a9, a2, a9
	s32i	a7, a8, 216
	addmi	a10, a10, 0x2700
	s32i	a10, a9, 0
	movi.n	a10, 0x14
	s8i	a10, a9, 4
	s32i	a7, a9, 8
	s32i	a7, a2, 492
	s32i	a7, a2, 496
	addmi	a3, a2, 0x200
	s16i	a7, a2, 500
	s8i	a4, a8, 246
	s32i	a7, a2, 504
	s16i	a7, a2, 508
	mov.n	a10, a3
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi.n	a12, 0xa
	movi.n	a11, 0
	addi	a10, a3, 88
	call8	memset
	movi.n	a8, 1
	s16i	a7, a3, 98
	s16i	a7, a3, 100
	slli	a8, a8, 16
	s32i	a8, a2, 648
	movi	a10, 0x98
	movi.n	a8, 5
	s32i	a8, a2, 652
	movi.n	a12, 0xf
	movi.n	a11, 0
	s32i	a5, a2, 616
	s32i	a6, a2, 620
	s32i	a5, a2, 624
	s32i	a6, a2, 628
	s32i	a5, a2, 632
	s32i	a6, a2, 636
	s32i	a5, a2, 640
	s32i	a6, a2, 644
	s32i	a7, a2, 656
	s32i	a7, a2, 660
	add.n	a10, a3, a10
	call8	memset
	movi	a10, 0x2b0
	add.n	a10, a2, a10
	s32i	a7, a2, 680
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x308
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x360
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x3b8
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x410
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x468
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	l32r	a8, .LC1252
	addmi	a2, a2, 0x400
	s8i	a4, a2, 192
	s32i	a7, a2, 196
	s32i	a8, a2, 200
	retw.n
.LFE1929:
	.size	_ZN14MotorControlRS6ESS_RS11MoveContextC2Ev, .-_ZN14MotorControlRS6ESS_RS11MoveContextC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS11MoveContextC1Ev
	.set	_ZN14MotorControlRS6ESS_RS11MoveContextC1Ev,_ZN14MotorControlRS6ESS_RS11MoveContextC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS13DriverRequestC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS13DriverRequestC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS13DriverRequestC2Ev
	.type	_ZN14MotorControlRS6ESS_RS13DriverRequestC2Ev, @function
_ZN14MotorControlRS6ESS_RS13DriverRequestC2Ev:
.LFB1945:
	entry	sp, 32
.LCFI154:
	movi.n	a9, 7
	slli	a9, a9, 16
	s32i	a9, a2, 12
	movi.n	a9, 0x19
	slli	a9, a9, 20
	movi.n	a8, 0
	s32i	a9, a2, 16
	movi.n	a9, 0
	movi.n	a10, 0
	s8i	a8, a2, 0
	s32i	a9, a2, 36
	movi.n	a8, 0
	s32i	a9, a2, 44
	movi.n	a11, 1
	s32i	a9, a2, 84
	movi.n	a9, 2
	s32i	a10, a2, 32
	s32i	a10, a2, 40
	s8i	a11, a2, 66
	s32i	a10, a2, 80
	s32i	a8, a2, 4
	s32i	a8, a2, 8
	s32i	a8, a2, 20
	s32i	a8, a2, 24
	s16i	a8, a2, 28
	s32i	a8, a2, 48
	s32i	a8, a2, 52
	s32i	a8, a2, 56
	s32i	a8, a2, 60
	s16i	a8, a2, 64
	s32i	a8, a2, 68
	s32i	a8, a2, 72
	s32i	a8, a2, 76
	s32i	a9, a2, 88
	s32i	a8, a2, 92
	s32i	a8, a2, 96
	s32i	a8, a2, 100
	movi.n	a12, 0x20
	movi.n	a11, 0
	addi	a10, a2, 104
	call8	memset
	retw.n
.LFE1945:
	.size	_ZN14MotorControlRS6ESS_RS13DriverRequestC2Ev, .-_ZN14MotorControlRS6ESS_RS13DriverRequestC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS13DriverRequestC1Ev
	.set	_ZN14MotorControlRS6ESS_RS13DriverRequestC1Ev,_ZN14MotorControlRS6ESS_RS13DriverRequestC2Ev
	.section	.text._ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC2Ev
	.type	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC2Ev, @function
_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC2Ev:
.LFB1948:
	entry	sp, 32
.LCFI155:
	movi.n	a7, 0
	addi.n	a10, a2, 8
	s32i	a7, a2, 0
	call8	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	movi	a8, 0x1e4
	s16i	a7, a2, 480
	movi.n	a3, 0
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	s8i	a3, a8, 4
	s32i	a7, a8, 8
	movi.n	a5, 0
	movi.n	a6, 0
	addmi	a8, a2, 0x200
	s32i	a7, a2, 496
	s32i	a5, a2, 504
	s32i	a6, a2, 508
	s32i	a5, a2, 512
	s32i	a6, a2, 516
	s32i	a5, a2, 520
	s32i	a6, a2, 524
	s16i	a7, a8, 16
	s32i	a7, a2, 532
	s8i	a3, a8, 24
	s32i	a7, a2, 540
	s32i	a7, a2, 544
	s32i	a7, a2, 548
	s32i	a7, a2, 552
	s32i	a5, a2, 560
	s32i	a6, a2, 564
	s32i	a5, a2, 568
	s32i	a6, a2, 572
	s32i	a7, a2, 576
	s16i	a7, a8, 68
	s8i	a3, a8, 70
	s32i	a7, a2, 584
	s8i	a3, a8, 76
	s32i	a7, a2, 592
	s32i	a7, a2, 596
	s32i	a7, a2, 600
	s32i	a5, a2, 608
	s32i	a6, a2, 612
	movi	a10, 0x278
	s32i	a5, a2, 616
	add.n	a10, a2, a10
	s32i	a6, a2, 620
	s32i	a7, a2, 624
	call8	_ZN14MotorControlRS6ESS_RS13DriverRequestC1Ev
	addmi	a8, a2, 0x300
	s16i	a7, a8, 0
	s32i	a7, a2, 772
	s8i	a3, a8, 8
	movi	a10, 0x328
	add.n	a10, a2, a10
	s32i	a7, a2, 780
	s32i	a7, a2, 784
	s32i	a5, a2, 792
	s32i	a6, a2, 796
	s32i	a5, a2, 800
	s32i	a6, a2, 804
	call8	_ZN14MotorControlRS6ESS_RS13DriverRequestC1Ev
	movi	a10, 0x3b0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev
	addmi	a4, a2, 0x400
	movi	a10, 0x470
	s8i	a3, a4, 88
	s32i	a7, a4, 92
	s32i	a7, a4, 96
	s8i	a3, a4, 100
	s16i	a7, a4, 102
	s8i	a3, a4, 104
	s32i	a7, a4, 108
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS13DriverRequestC1Ev
	movi	a10, 0x510
	s32i	a5, a4, 248
	s32i	a6, a4, 252
	addmi	a4, a2, 0x500
	s32i	a5, a4, 0
	s32i	a6, a4, 4
	s32i	a7, a4, 8
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS13DriverRequestC1Ev
	s32i	a5, a4, 152
	s32i	a6, a4, 156
	s32i	a5, a4, 160
	s32i	a6, a4, 164
	retw.n
.LFE1948:
	.size	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC2Ev, .-_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC1Ev
	.set	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC1Ev,_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC2Ev
	.text
	.literal_position
	.literal .LC1257, 763048
	.literal .LC1258, 764504
	.literal .LC1259, 764516
	.literal .LC1260, 763820
	.literal .LC1261, 625320
	.literal .LC1262, 757972
	.literal .LC1263, 757960
	.literal .LC1264, 758044
	.literal .LC1265, 625608
	.literal .LC1266, 625896
	.literal .LC1267, 625848
	.literal .LC1268, 626136
	.literal .LC1269, 626144
	.literal .LC1270, 625856
	.literal .LC1271, 758244
	.literal .LC1272, 758844
	.literal .LC1273, 763840
	.literal .LC1274, 762568
	.literal .LC1275, 757994
	.align	4
	.type	_ZN12_GLOBAL__N_119singleSettingPolicyERNS_3AppEy, @function
_ZN12_GLOBAL__N_119singleSettingPolicyERNS_3AppEy:
.LFB2194:
	entry	sp, 64
.LCFI156:
	s32i	a4, sp, 4
	l32r	a4, .LC1257
	movi	a12, 0x5a8
	add.n	a6, a2, a4
	movi.n	a11, 0
	mov.n	a10, a6
	s32i	a5, sp, 8
	call8	memset
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC1Ev
	l32r	a8, .LC1259
	l32r	a11, .LC1258
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	add.n	a11, a2, a11
	s32i	a8, a6, 0
	l32i	a12, a11, 0
	l32i	a10, a11, 4
	addmi	a9, a6, 0x300
	s32i	a12, a6, 772
	s32i	a8, sp, 12
	addi.n	a8, a9, 4
	l32i	a9, a11, 8
	s32i	a10, a8, 4
	s32i	a9, a8, 8
	l32r	a9, .LC1260
	movi	a8, 0x1e4
	add.n	a9, a2, a9
	l32i	a12, a9, 0
	add.n	a8, a6, a8
	l32i	a10, a9, 4
	s32i	a12, a8, 0
	l32i	a9, a9, 8
	s32i	a10, a8, 4
	s32i	a9, a8, 8
	l32i	a8, sp, 12
	movi	a5, 0x3e8
	s32i	a8, a6, 784
	l32i	a8, a2, 0
	l32r	a10, .LC1261
	mull	a9, a5, a8
	muluh	a5, a5, a8
	add.n	a10, a2, a10
	s32i	a9, a6, 520
	s32i	a5, a6, 524
	l32i	a8, a10, 240
	s32i	a9, sp, 0
	l32i	a9, a10, 244
	s32i	a8, a6, 504
	s32i	a9, a6, 508
	l32i	a8, a10, 248
	l32i	a9, a10, 252
	s32i	a8, a6, 512
	s32i	a9, a6, 516
	l16ui	a3, a10, 22
	mov.n	a7, a2
	s16i	a3, a6, 496
	l16ui	a2, a10, 24
	l32i	a14, sp, 0
	l32i	a12, sp, 4
	l32i	a13, sp, 8
	s16i	a2, a6, 498
	mov.n	a15, a5
	s32i	a11, sp, 16
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	l32i	a11, sp, 16
	mov.n	a6, a10
	beqz.n	a10, .L2975
	movi.n	a8, -0x14
	and	a2, a2, a8
	or	a3, a3, a2
	nsau	a6, a3
	srli	a6, a6, 5
.L2975:
	l32r	a8, .LC1262
	add.n	a4, a7, a4
	add.n	a8, a7, a8
	addmi	a4, a4, 0x100
	l32i	a8, a8, 0
	s8i	a6, a4, 224
	movi.n	a10, 0
	beqz.n	a8, .L2976
	l32r	a10, .LC1263
	s32i	a11, sp, 16
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L2976
	l32r	a8, .LC1264
	movi.n	a10, 0
	add.n	a8, a7, a8
	l16ui	a8, a8, 0
	bnez.n	a8, .L2976
	l32r	a4, .LC1265
	l32i	a14, sp, 0
	add.n	a4, a7, a4
	l32i	a12, sp, 4
	l32i	a13, sp, 8
	l32i	a11, sp, 16
	mov.n	a15, a5
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2976
	l16ui	a8, a4, 44
	movi.n	a10, 0
	bnez.n	a8, .L2976
	l16ui	a8, a4, 40
	bnez.n	a8, .L2976
	l32r	a4, .LC1266
	l32i	a14, sp, 0
	add.n	a4, a7, a4
	l32i	a12, sp, 4
	l32i	a13, sp, 8
	l32i	a11, sp, 16
	mov.n	a15, a5
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L2976
	l16ui	a10, a4, 58
	nsau	a10, a10
	srli	a10, a10, 5
.L2976:
	l32r	a9, .LC1267
	l32r	a11, .LC1268
	add.n	a9, a7, a9
	add.n	a11, a7, a11
	l32r	a8, .LC1257
	l32i	a12, a11, 0
	l32i	a13, a11, 4
	l32i	a11, a9, 0
	l32i	a9, a9, 4
	add.n	a8, a7, a8
	bltu	a13, a9, .L2978
	bne	a9, a13, .L2977
	bgeu	a12, a11, .L2977
.L2978:
	mov.n	a11, a12
	mov.n	a9, a13
.L2977:
	s32i	a9, a8, 796
	s32i	a11, a8, 792
	l32r	a9, .LC1270
	l32r	a8, .LC1269
	add.n	a9, a7, a9
	add.n	a8, a7, a8
	l32i	a11, a9, 0
	l32i	a12, a8, 4
	l32i	a9, a9, 4
	l32i	a13, a8, 0
	bltu	a12, a9, .L2980
	bne	a9, a12, .L2979
	bgeu	a13, a11, .L2979
.L2980:
	mov.n	a13, a11
	mov.n	a12, a9
.L2979:
	l32r	a8, .LC1272
	l32r	a9, .LC1271
	add.n	a8, a7, a8
	s32i	a8, sp, 24
	l32r	a8, .LC1257
	add.n	a9, a7, a9
	add.n	a4, a7, a8
	l32r	a8, .LC1273
	add.n	a8, a7, a8
	s32i	a8, sp, 20
	j	.L2981
.L2996:
	beqz.n	a10, .L2982
	l8ui	a10, a9, 0
	beqz.n	a10, .L2982
	l8ui	a8, a9, 48
	movi.n	a10, 0
	bnez.n	a8, .L2982
	l32i	a8, a9, 12
	l32i	a11, a9, 8
	l32i	a15, a9, 16
	s32i	a8, sp, 16
	l32i	a14, a9, 4
	bltu	a15, a11, .L3004
	bne	a11, a15, .L3006
	bltu	a8, a14, .L3004
.L3006:
	l32i	a10, a9, 24
	l32i	a2, sp, 8
	l32i	a3, a9, 20
	movi.n	a8, 1
	bltu	a2, a10, .L2985
	bne	a10, a2, .L2984
	l32i	a2, sp, 4
	bgeu	a2, a3, .L2984
.L2985:
	movi.n	a8, 0
.L2984:
	movi.n	a2, 1
	bltu	a10, a15, .L2987
	bne	a15, a10, .L2986
	l32i	a10, sp, 16
	bgeu	a3, a10, .L2986
.L2987:
	movi.n	a2, 0
.L2986:
	and	a8, a8, a2
	extui	a10, a8, 0, 8
	beqz.n	a10, .L2982
	l32i	a8, sp, 0
	or	a8, a8, a5
	beqz.n	a8, .L2982
	l32i	a8, sp, 8
	sub	a11, a8, a11
	l32i	a8, sp, 4
	bgeu	a8, a14, .L2989
	addi.n	a11, a11, -1
.L2989:
	l32i	a8, sp, 4
	movi.n	a10, 1
	sub	a14, a8, a14
	bltu	a11, a5, .L2990
	bne	a5, a11, .L2991
	l32i	a8, sp, 0
	bltu	a14, a8, .L2990
.L2991:
	movi.n	a10, 0
.L2990:
	extui	a10, a10, 0, 8
	j	.L2982
.L3004:
	movi.n	a10, 0
.L2982:
	l32i	a8, sp, 20
	l32i	a11, a9, 4
	l32i	a15, a8, 0
	l32i	a14, a8, 4
	l32i	a8, a9, 8
	bltu	a14, a8, .L2993
	bne	a8, a14, .L2992
	bgeu	a15, a11, .L2992
.L2993:
	mov.n	a11, a15
	mov.n	a8, a14
.L2992:
	s32i	a11, a4, 792
	s32i	a8, a4, 796
	l32i	a8, a9, 24
	l32i	a11, a9, 20
	bltu	a12, a8, .L2995
	bne	a8, a12, .L2994
	bgeu	a13, a11, .L2994
.L2995:
	mov.n	a13, a11
	mov.n	a12, a8
.L2994:
	addi	a9, a9, 120
.L2981:
	l32i	a8, sp, 24
	s32i	a13, a4, 800
	s32i	a12, a4, 804
	bne	a9, a8, .L2996
	l32r	a11, .LC1274
	l32r	a9, .LC1275
	add.n	a11, a7, a11
	add.n	a9, a7, a9
	movi.n	a12, 4
	loop	a12, .L2998_LEND
.L2998:
	beqz.n	a10, .L2997
	l16ui	a8, a9, 0
	bgeui	a8, 4, .L3005
	beqz.n	a8, .L2997
	l8ui	a10, a11, 0
	addi.n	a10, a10, -1
	nsau	a10, a10
	srli	a10, a10, 5
	j	.L2997
.L3005:
	movi.n	a10, 0
.L2997:
	addi.n	a11, a11, 1
	addi.n	a9, a9, 2
	.L2998_LEND:
	l32r	a8, .LC1257
	l32i	a9, sp, 12
	add.n	a7, a7, a8
	addmi	a8, a7, 0x300
	s8i	a10, a8, 1
	movi.n	a8, 1
	moveqz	a8, a9, a9
	addmi	a7, a7, 0x100
	and	a2, a6, a8
	s8i	a10, a7, 225
	and	a2, a10, a2
	retw.n
.LFE2194:
	.size	_ZN12_GLOBAL__N_119singleSettingPolicyERNS_3AppEy, .-_ZN12_GLOBAL__N_119singleSettingPolicyERNS_3AppEy
	.section	.rodata.str1.1
.LC1277:
	.string	"single-setting prerequisites expired"
.LC1279:
	.string	"setting binding changed during prior read"
	.text
	.literal_position
	.literal .LC1278, .LC1277
	.literal .LC1280, .LC1279
	.literal .LC1281, 101000
	.literal .LC1282, 625320
	.literal .LC1283, 101032
	.literal .LC1284, 102328
	.literal .LC1285, 103248
	.literal .LC1286, 103271
	.literal .LC1287, 105272
	.literal .LC1288, 65248
	.literal .LC1289, 53807
	.literal .LC1290, 45688
	.literal .LC1291, 45700
	.literal .LC1292, 53808
	.literal .LC1293, 53800
	.literal .LC1294, _ZN12_GLOBAL__N_14uartE
	.literal .LC1295, 626264
	.literal .LC1296, 626240
	.literal .LC1297, 772456
	.literal .LC1298, 3864
	.literal .LC1299, 3080
	.literal .LC1301, .LC12
	.literal .LC1303, -16711936
	.literal .LC1304, 16778240
	.literal .LC1306, 764516
	.literal .LC1308, 771952
	.literal .LC1310, 4280
	.literal .LC1313, 3353
	.literal .LC1314, 764508
	.literal .LC1315, 764714
	.literal .LC1316, 764771
	.literal .LC1318, 771828
	.literal .LC1319, 764768
	.literal .LC1321, 764760
	.literal .LC1325, _ZN12_GLOBAL__N_122writeResponseConfirmedE
	.literal .LC1326, 9017
	.literal .LC1330, 771816
	.literal .LC1331, 771832
	.literal .LC1332, 771836
	.literal .LC1334, 764504
	.literal .LC1335, 4284
	.literal .LC1336, 762576
	.literal .LC1337, 762600
	.literal .LC1341, 770908
	.literal .LC1342, 771920
	.literal .LC1343, 771936
	.literal .LC1344, 770859
	.literal .LC1345, 771981
	.literal .LC1346, 771982
	.literal .LC1347, 771986
	.literal .LC1348, 763056
	.literal .LC1350, 763048
	.literal .LC1354, 760208
	.literal .LC1355, 759264
	.literal .LC1356, 759736
	.literal .LC1357, 758792
	.literal .LC1358, 757972
	.literal .LC1362, 6274
	.literal .LC1363, 757960
	.literal .LC1364, 757976
	.align	4
	.type	_ZN12_GLOBAL__N_114advanceActionsERNS_3AppEy, @function
_ZN12_GLOBAL__N_114advanceActionsERNS_3AppEy:
.LFB2227:
	entry	sp, 752
.LCFI157:
	s32i	a4, sp, 656
	l32i	a12, sp, 656
	mov.n	a13, a5
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118cancelInvalidHomesERNS_3AppEy
	l32i	a12, sp, 656
	mov.n	a13, a5
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_121cancelInvalidReleasesERNS_3AppEy
	l32r	a8, .LC1282
	l32r	a7, .LC1281
	add.n	a8, a2, a8
	s32i	a8, sp, 708
	l32r	a8, .LC1283
	mov.n	a4, a5
	add.n	a8, a2, a8
	s32i	a8, sp, 680
	l32r	a8, .LC1284
	add.n	a7, a2, a7
	add.n	a8, a2, a8
	s32i	a8, sp, 676
	l32r	a8, .LC1285
	add.n	a8, a2, a8
	s32i	a8, sp, 668
	l32r	a8, .LC1286
	add.n	a8, a2, a8
	s32i	a8, sp, 672
	l32r	a8, .LC1287
	add.n	a8, a2, a8
	s32i	a8, sp, 660
	addi	a8, sp, 16
	addmi	a8, a8, 0x100
	s32i	a8, sp, 684
	l32i	a9, sp, 684
	movi	a8, 0x88
	add.n	a8, a9, a8
	s32i	a8, sp, 704
	j	.L3041
.L3243:
	l32i	a12, a7, 784
	l32i	a13, a7, 788
	or	a8, a12, a13
	beqz.n	a8, .L3043
	l32i	a8, a7, 800
	l32i	a9, a7, 804
	or	a8, a8, a9
	bnez.n	a8, .L3043
	l32r	a10, .LC1288
	add.n	a10, a2, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner14recoveryResultEy
	mov.n	a11, a10
	beqz.n	a10, .L3043
	movi	a10, 0x320
	movi.n	a12, 0x32
	add.n	a10, a7, a10
	call8	memcpy
.L3043:
	movi	a6, 0x30c
	add.n	a6, a7, a6
	l8ui	a8, a6, 0
	beqz.n	a8, .L3046
	l32r	a8, .LC1289
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3047
.L3053:
	l32r	a11, .LC1290
	movi.n	a8, 0
	s8i	a8, a6, 0
	movi.n	a12, 5
	add.n	a11, a2, a11
	addi.n	a10, a7, 12
	call8	memcpy
	l32r	a8, .LC1291
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a8, a7, 20
	l32r	a8, .LC1292
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3048
	j	.L3049
.L3047:
	l32i	a8, a7, 60
	bltu	a4, a8, .L3263
	bne	a8, a4, .L3250
	l32i	a8, a7, 56
	l32i	a9, sp, 656
	bgeu	a9, a8, .L3250
.L3263:
	l32r	a8, .LC1293
	movi.n	a12, 1
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqi	a8, 4, .L3050
	j	.L3052
.L3250:
	movi.n	a12, 3
.L3050:
	movi.n	a8, 0
	s8i	a8, a6, 0
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	addi	a11, sp, 16
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, sp, 636
	s32i	a11, sp, 640
	mov.n	a10, a2
	mov.n	a11, a7
	s32i	a12, sp, 644
	call8	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
	l8ui	a8, a6, 0
	bnez.n	a8, .L3053
	j	.L3046
.L3049:
	movi.n	a12, 1
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	addi	a11, sp, 16
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, sp, 624
	s32i	a11, sp, 628
	s32i	a12, sp, 632
	j	.L3055
.L3048:
	l32r	a10, .LC1288
	add.n	a10, a2, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L3049
	l32r	a10, .LC1294
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3049
.L3055:
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
.L3046:
	l8ui	a8, a7, 0
	addi	a8, a8, -3
	extui	a8, a8, 0, 8
	bgeui	a8, 5, .L3052
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L3052
	l32r	a8, .LC1288
	add.n	a8, a2, a8
	mov.n	a10, a8
	s32i	a8, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L3057
.L3059:
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18holdStopERNS_3AppERNS0_6RecordEy
	j	.L3058
.L3057:
	l32r	a10, .LC1294
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3059
.L3058:
	movi	a8, 0x30d
	add.n	a8, a7, a8
	l8ui	a5, a8, 0
	s32i	a8, sp, 688
	beqz.n	a5, .L3060
	l8ui	a8, a7, 71
	beqz.n	a8, .L3061
	l32i	a14, sp, 656
	mov.n	a15, a4
	movi.n	a12, 0
	movi.n	a11, 2
	j	.L3426
.L3061:
	l32i	a8, a7, 60
	bltu	a4, a8, .L3063
	bne	a8, a4, .L3264
	l32i	a8, a7, 56
	l32i	a9, sp, 656
	bltu	a9, a8, .L3063
.L3264:
	l32i	a14, sp, 656
	mov.n	a15, a4
	movi.n	a12, 0
	movi.n	a11, 3
	j	.L3426
.L3063:
	l32i	a8, a7, 784
	l32i	a9, a7, 788
	or	a10, a8, a9
	beqz.n	a10, .L3065
	l32r	a10, .LC1295
	add.n	a10, a2, a10
	l32i	a11, a10, 0
	l32i	a10, a10, 4
	or	a12, a11, a10
	beqz.n	a12, .L3065
	xor	a8, a8, a11
	xor	a9, a9, a10
	or	a8, a8, a9
	beqz.n	a8, .L3065
	j	.L3071
.L3065:
	l32r	a8, .LC1288
	add.n	a8, a2, a8
	l8ui	a8, a8, 60
	bnei	a8, 1, .L3067
	l32r	a8, .LC1295
	add.n	a8, a2, a8
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, a7, 788
	s32i	a8, a7, 784
	l32r	a8, .LC1296
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	j	.L3425
.L3067:
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L3068
.L3072:
	movi.n	a8, 0
	l32i	a9, a7, 788
	s32i	a8, sp, 16
	l32i	a8, a7, 784
	or	a8, a8, a9
	beqz.n	a8, .L3069
	j	.L3071
.L3068:
	l32r	a10, .LC1294
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	beqz.n	a10, .L3412
	j	.L3072
.L3071:
	l32i	a14, sp, 656
	mov.n	a15, a4
	movi.n	a12, -2
	j	.L3423
.L3412:
	l32r	a8, .LC1297
	addi	a6, sp, 16
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l8ui	a8, a7, 0
	beqi	a8, 5, .L3075
	j	.L3413
.L3069:
	addi	a13, sp, 16
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113startRecoveryERNS_3AppEmbRm
	bnez.n	a10, .L3071
	l32r	a8, .LC1295
	add.n	a8, a2, a8
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, a7, 788
	s32i	a8, a7, 784
	l32i	a8, sp, 16
.L3425:
	s32i	a8, a7, 792
	j	.L3196
.L3075:
	l32r	a8, .LC1298
	movi	a11, 0x1d0
	add.n	a8, a7, a8
	l32i	a12, a8, 0
	l32i	a10, a8, 4
	l32i	a8, a8, 8
	add.n	a11, a6, a11
	s32i	a12, a11, 0
	s32i	a10, a11, 4
	s32i	a8, a11, 8
	beq	a8, a9, .L3077
	l32r	a10, .LC1299
	l32i	a12, sp, 656
	s32i	a9, a11, 8
	mov.n	a13, a4
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS18rebindVelocityStopERNS0_15VelocityContextERKNS_10ReadTargetEy
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3077
	j	.L3084
.L3077:
	addi	a6, sp, 16
	movi.n	a12, 0x50
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	l32r	a10, .LC1299
	movi.n	a8, 2
	l32i	a12, sp, 656
	s8i	a8, sp, 16
	mov.n	a14, a6
	mov.n	a13, a4
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS12nextVelocityERKNS0_15VelocityContextEyRNS0_16PreparedVelocityE
	l8ui	a8, sp, 16
	s32i	a10, a6, 392
	or	a10, a10, a8
	s32i	a11, a6, 396
	s32i	a12, a6, 400
	extui	a10, a10, 0, 8
	l32i	a14, sp, 656
	mov.n	a15, a4
	beqz.n	a10, .L3080
	j	.L3436
.L3080:
	mov.n	a12, a6
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_117admitVelocityStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS16PreparedVelocityEy
	l32i	a8, sp, 688
	beqz.n	a10, .L3437
.L3081:
	addi	a10, a10, -5
	extui	a10, a10, 0, 8
	bltui	a10, 2, .L3196
	j	.L3424
.L3413:
	l32i	a10, sp, 676
	movi	a8, 0x1e8
	l32i	a11, a10, 0
	l32i	a10, a10, 4
	add.n	a8, a6, a8
	s32i	a11, a8, 0
	s32i	a10, a8, 4
	s32i	a9, a8, 8
	movi	a12, 0x188
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	movi.n	a9, 0x10
	addmi	a9, a9, 0x2700
	s32i	a9, sp, 56
	movi.n	a9, 0x14
	s8i	a9, sp, 60
	addmi	a3, a6, 0x100
	l32r	a9, .LC1301
	movi	a5, 0x88
	add.n	a5, a3, a5
	s32i	a9, sp, 204
	s32i	a9, sp, 292
	s32i	a9, sp, 380
	s32i	a9, sp, 400
	movi.n	a12, 0x40
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a9, 2
	s8i	a9, a3, 136
	movi	a9, 0x558
	add.n	a9, a7, a9
	s32i	a9, sp, 8
	l32i	a10, a7, 56
	l32i	a11, a7, 60
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	movi	a8, 0x1f8
	l32i	a14, sp, 656
	l32i	a12, a7, 4
	movi	a13, 0x540
	add.n	a11, a8, sp
	mov.n	a15, a4
	add.n	a13, a7, a13
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS13prepareActionERNS0_13ActionContextERKNS_10ReadTargetEmRKNS_13ActionRequestEyyRKNS_13ActionOptionsE
	movi	a8, 0x1d0
	add.n	a8, a6, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3084
	l32i	a12, sp, 656
	mov.n	a14, a5
	mov.n	a13, a4
	mov.n	a10, a6
	call8	_ZN14MotorControlRS6ESS_RS10nextActionERKNS0_13ActionContextEyRNS0_14PreparedActionE
	movi	a8, 0x1dc
	add.n	a8, a6, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	l8ui	a8, a3, 136
	or	a10, a10, a8
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3084
	l32i	a14, sp, 656
	mov.n	a12, a5
	mov.n	a15, a4
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115admitActionStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedActionEy
	mov.n	a5, a10
	beqz.n	a10, .L3085
	j	.L3414
.L3084:
	l32i	a14, sp, 656
	mov.n	a15, a4
.L3436:
	movi.n	a12, -3
	j	.L3423
.L3085:
	l32i	a10, sp, 676
	movi	a12, 0x184
	mov.n	a11, a6
	call8	memcpy
	l32i	a8, sp, 688
	s8i	a5, a8, 0
	j	.L3196
.L3414:
	beqi	a10, 6, .L3196
.L3424:
	l32i	a14, sp, 656
	mov.n	a15, a4
	movi.n	a12, -4
.L3423:
	movi.n	a11, 1
.L3426:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111endHeldStopERNS_3App6RecordEN14MotorControlRS13ReadEventKindEly
	j	.L3196
.L3060:
	movi.n	a8, 0x3a
	addmi	a8, a8, 0x2300
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3087
	l8ui	a8, a7, 71
	bnez.n	a8, .L3087
	j	.L3196
.L3087:
	l32i	a9, sp, 668
	movi	a8, 0x33c
	add.n	a8, a9, a8
	s32i	a8, sp, 696
	l8ui	a8, a8, 0
	s32i	a8, sp, 688
	beqz.n	a8, .L3088
	l32i	a11, a9, 816
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a6, a10
	beqz.n	a10, .L3090
	mov.n	a11, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L3090
	addmi	a8, a6, 0x800
	l8ui	a8, a8, 221
	bnei	a8, 4, .L3090
	addmi	a8, a6, 0x300
	l8ui	a8, a8, 10
	bnez.n	a8, .L3090
	l32i	a9, sp, 668
	movi	a8, 0x338
	add.n	a8, a9, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
	addmi	a8, a6, 0xc00
	s8i	a9, a8, 0
.L3090:
	l32i	a10, sp, 704
	movi.n	a12, 0x48
	movi.n	a11, 0
	call8	memset
	l32i	a9, sp, 684
	movi.n	a8, 2
	movi	a3, 0x6f0
	s8i	a8, a9, 136
	l32i	a12, sp, 656
	addi	a8, sp, 16
	add.n	a3, a7, a3
	movi	a14, 0x188
	add.n	a14, a8, a14
	mov.n	a13, a4
	mov.n	a10, a3
	call8	_ZN14MotorControlRS6ESS_RS8nextMoveERKNS0_11MoveContextEyRNS0_12PreparedMoveE
	addi	a9, sp, 16
	movi	a8, 0x1d0
	add.n	a8, a9, a8
	l8ui	a9, a7, 71
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	bnez.n	a9, .L3095
	movi.n	a8, 1
	movnez	a8, a9, a6
	bnez.n	a8, .L3095
	l32r	a8, .LC1291
	l32i	a9, a7, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L3095
	l8ui	a11, a7, 24
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111pendingStopERKNS_3AppEh
	bnez.n	a10, .L3095
	movi	a11, 0x6f8
	l32i	a12, sp, 656
	mov.n	a13, a4
	add.n	a11, a7, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_121storedPositionCurrentERKNS_3AppERKN14MotorControlRS6ESS_RS27StoredPositionQualificationEy
	beqz.n	a10, .L3095
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L3095
	l32r	a10, .LC1294
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	s32i	a10, sp, 688
.L3095:
	movi	a8, 0x1d0
	addi	a9, sp, 16
	add.n	a8, a9, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3252
	l32i	a8, sp, 688
	beqz.n	a8, .L3098
.L3100:
	movi.n	a12, 2
	j	.L3097
.L3098:
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L3099
	addmi	a8, a6, 0x800
	l32r	a9, .LC1303
	l32i	a8, a8, 220
	and	a8, a8, a9
	l32r	a9, .LC1304
	bne	a8, a9, .L3100
	j	.L3099
.L3252:
	movi.n	a12, 3
.L3097:
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	addi	a11, sp, 16
	mov.n	a10, a3
	call8	_ZN14MotorControlRS6ESS_RS11advanceMoveERNS0_11MoveContextERKNS_11ActionEventEy
	l32i	a9, sp, 696
	movi.n	a8, 0
	s8i	a8, a9, 0
	j	.L3196
.L3099:
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L3196
	l32i	a8, a6, 32
	bnez.n	a8, .L3196
	l32r	a8, .LC1288
	add.n	a8, a2, a8
	l32i	a9, a8, 52
	bnei	a9, -1, .L3196
	l32i	a8, a8, 48
	bnez.n	a8, .L3196
.L3088:
	movi.n	a8, 0x58
	addmi	a8, a8, 0x1f00
	add.n	a8, a7, a8
	s32i	a8, sp, 692
	l8ui	a8, a8, 0
	bnez.n	a8, .L3102
	j	.L3103
.L3102:
	l32i	a8, sp, 660
	l8ui	a8, a8, 32
	beqi	a8, 1, .L3104
.L3107:
	l32r	a8, .LC1306
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L3105
	j	.L3415
.L3104:
	movi.n	a8, 0x28
	addmi	a8, a8, 0x1700
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3107
	l32i	a8, a7, 32
	bnez.n	a8, .L3108
.L3111:
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_119singleSettingPolicyERNS_3AppEy
	bnez.n	a10, .L3112
	j	.L3416
.L3108:
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L3111
	j	.L3112
.L3416:
	movi.n	a9, 1
	l32i	a8, a7, 32
	s8i	a9, a7, 71
	beqz.n	a8, .L3112
	l32i	a12, sp, 656
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	mov.n	a13, a4
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L3112:
	l32i	a8, sp, 692
	l8ui	a8, a8, 0
	bnez.n	a8, .L3107
	j	.L3103
.L3415:
	l32r	a8, .LC1297
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a9, a9, 20
	l32i	a8, a8, 0
	bne	a9, a8, .L3105
	l32r	a8, .LC1291
	l32i	a9, a7, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beq	a9, a8, .L3103
.L3105:
	movi.n	a8, 1
	s8i	a8, a7, 71
	l32i	a8, a7, 32
	beqz.n	a8, .L3194
	l32i	a12, sp, 656
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	mov.n	a13, a4
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L3103:
	l32i	a8, a7, 32
	beqz.n	a8, .L3194
	l8ui	a6, a7, 0
	bnei	a6, 7, .L3116
	movi	a3, 0x309
	add.n	a3, a7, a3
	l8ui	a8, a3, 0
	bnez.n	a8, .L3118
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L3116
	movi.n	a8, 1
	movi.n	a13, 0
	s8i	a8, a3, 0
	movi.n	a12, 0
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	l32r	a8, .LC1306
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	movi	a12, 0x78
	s32i	a8, a9, 0
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a10, .LC1308
	movi.n	a8, 0x23
	movi	a12, 0x78
	addi	a11, sp, 16
	s16i	a8, sp, 36
	s16i	a6, sp, 46
	add.n	a10, a2, a10
	call8	memcpy
	l32i	a12, sp, 656
	l8ui	a11, a7, 24
	movi.n	a14, 0
	mov.n	a13, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb
.L3116:
	l8ui	a8, a7, 0
	bnei	a8, 6, .L3118
	l32i	a8, sp, 660
	l8ui	a8, a8, 32
	bnei	a8, 1, .L3118
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L3118
	addi	a6, sp, 16
	movi.n	a12, 0x30
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	movi.n	a8, 2
	s8i	a8, sp, 16
	movi.n	a8, 0x18
	addmi	a8, a8, 0x1700
	add.n	a8, a7, a8
	l32r	a10, .LC1310
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	mov.n	a14, a6
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS10nextDriverERKNS0_13DriverContextEyRNS0_14PreparedDriverE
	s32i	a10, sp, 408
	s32i	a11, sp, 412
	s32i	a12, sp, 416
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3118
	l8ui	a8, sp, 37
	beqz.n	a8, .L3118
	movi.n	a6, 0x3c
	movi	a3, 0x7c
	addmi	a6, a6, 0x1700
	addmi	a3, a3, 0x1800
	add.n	a6, a7, a6
	add.n	a3, a7, a3
	j	.L3126
.L3128:
	l8ui	a8, a6, 12
	beqz.n	a8, .L3127
	l16ui	a9, a6, 4
	l16ui	a8, sp, 38
	bne	a9, a8, .L3127
	l32i	a14, sp, 656
	l32i	a12, a6, 0
	mov.n	a15, a4
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113driverEffectsERNS_3AppERNS0_6RecordEmy
.L3127:
	addi	a6, a6, 20
.L3126:
	bne	a6, a3, .L3128
.L3118:
	l8ui	a8, a7, 0
	bnei	a8, 4, .L3129
	l32i	a8, sp, 668
	l8ui	a9, a8, 176
	l32i	a8, sp, 672
	l8ui	a8, a8, 155
	bne	a9, a8, .L3131
	j	.L3130
.L3129:
	bnei	a8, 5, .L3131
	l32r	a8, .LC1313
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnei	a8, 1, .L3131
.L3130:
	l32r	a8, .LC1314
	l8ui	a9, a7, 24
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bne	a9, a8, .L3131
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L3131
	l32r	a8, .LC1315
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC1316
	add.n	a8, a2, a8
	s8i	a9, a8, 0
.L3131:
	movi	a8, 0x309
	add.n	a8, a7, a8
	s32i	a8, sp, 688
	l8ui	a8, a8, 0
	bnez.n	a8, .L3134
	l8ui	a9, a7, 0
	beqi	a9, 4, .L3135
	beqi	a9, 5, .L3136
	beqi	a9, 3, .L3137
	j	.L3134
.L3136:
	movi.n	a9, 0x58
	addmi	a9, a9, 0xd00
	add.n	a9, a7, a9
	l8ui	a10, a9, 0
	j	.L3435
.L3135:
	l32i	a9, sp, 668
	l8ui	a11, a9, 176
	l32i	a9, sp, 672
	l8ui	a9, a9, 155
	bltu	a9, a11, .L3134
	movi	a9, 0x783
	add.n	a9, a7, a9
	l8ui	a10, a9, 0
	movi.n	a9, 1
	addi.n	a10, a10, -1
	movnez	a8, a9, a10
	bnez.n	a8, .L3140
	moveqz	a9, a8, a11
	bnez.n	a9, .L3140
	j	.L3134
.L3137:
	l32i	a9, sp, 676
	l8ui	a10, a9, 88
.L3435:
	movi.n	a9, 1
	moveqz	a8, a9, a10
	j	.L3138
.L3140:
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L3134
	l32i	a9, sp, 688
	movi.n	a8, 1
	l8ui	a6, a7, 0
	s8i	a8, a9, 0
	bnei	a6, 4, .L3141
	l32i	a8, sp, 668
	l8ui	a9, a8, 176
	l32i	a8, sp, 672
	l8ui	a8, a8, 155
	bgeu	a9, a8, .L3141
	l32r	a8, .LC1318
	movi.n	a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l8ui	a11, a7, 24
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118storedWordsChangedERNS_3AppEh
.L3141:
	l32i	a12, sp, 656
	l8ui	a11, a7, 24
	movi.n	a14, 1
	mov.n	a13, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_122invalidateObservationsERNS_3AppEhyb
	bnei	a6, 3, .L3134
	l32i	a8, sp, 676
	l8ui	a8, a8, 16
	addi.n	a9, a8, -1
	nsau	a10, a9
	srli	a10, a10, 5
	beqz.n	a9, .L3142
	addi	a8, a8, -4
	movi.n	a9, 1
	movnez	a9, a10, a8
	bnez.n	a9, .L3142
.L3144:
	l32i	a8, sp, 676
	l8ui	a8, a8, 16
	beqz.n	a8, .L3143
	j	.L3134
.L3142:
	l32r	a8, .LC1314
	add.n	a8, a2, a8
	l8ui	a9, a8, 0
	l8ui	a8, a7, 24
	bne	a9, a8, .L3134
	movi.n	a12, 0
	movi.n	a13, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	l8ui	a8, a7, 0
	beqi	a8, 3, .L3144
	j	.L3134
.L3143:
	l32r	a8, .LC1319
	l8ui	a9, a7, 24
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	movi	a8, 0x3e8
	mull	a8, a8, a8
	l32i	a9, sp, 656
	mov.n	a6, a4
	add.n	a3, a9, a8
	bgeu	a3, a8, .L3145
	addi.n	a6, a4, 1
.L3145:
	l32r	a8, .LC1321
	mov.n	a10, a2
	add.n	a8, a2, a8
	s32i	a3, a8, 0
	s32i	a6, a8, 4
	l8ui	a11, a7, 24
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L3134
	addmi	a10, a10, 0x900
	s32i	a3, a10, 96
	s32i	a6, a10, 100
.L3134:
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a6, a10
	beqz.n	a10, .L3052
	l8ui	a8, a10, 112
	movi.n	a3, 0
	beqi	a8, 1, .L3147
	movi.n	a9, 0x12
	movi.n	a3, 3
	beq	a8, a9, .L3147
	l8ui	a8, a10, 105
	beqi	a8, 6, .L3255
	beqz.n	a8, .L3255
	movi.n	a3, 1
	bnei	a8, 5, .L3147
	movi.n	a3, 2
	j	.L3147
.L3255:
	movi.n	a3, 3
.L3147:
	l32i	a10, sp, 704
	mov.n	a12, a3
	mov.n	a11, a7
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	addi	a8, sp, 16
	movi	a10, 0x188
	add.n	a10, a8, a10
	mov.n	a11, a6
	call8	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	l32i	a8, sp, 684
	l8ui	a9, a6, 142
	s8i	a9, a8, 201
	l8ui	a8, a7, 0
	bnei	a8, 4, .L3148
	l32i	a8, sp, 668
	l8ui	a10, a8, 176
	l32i	a8, sp, 672
	l8ui	a8, a8, 155
	bne	a10, a8, .L3148
	movi.n	a8, 0x3b
	addmi	a8, a8, 0x2300
	add.n	a8, a7, a8
	movi.n	a10, 0x40
	s8i	a9, a8, 0
	addmi	a10, a10, 0x2300
	l32i	a8, a6, 168
	l32i	a9, a6, 172
	add.n	a10, a7, a10
	s32i	a8, a10, 0
	movi.n	a8, 0x48
	s32i	a9, a10, 4
	addmi	a8, a8, 0x2300
	l32i	a9, a6, 184
	add.n	a8, a7, a8
	s32i	a9, a8, 0
.L3148:
	bnez.n	a3, .L3149
	l8ui	a8, a6, 105
	addi	a8, a8, -2
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L3149
	l8ui	a5, a6, 160
	beqz.n	a5, .L3149
	l8ui	a5, a6, 142
	beqz.n	a5, .L3149
	l32r	a8, .LC1325
	l8ui	a5, a8, 0
	bnez.n	a5, .L3149
	l8ui	a8, a6, 31
	movi.n	a9, 1
	addi	a8, a8, -6
	movnez	a5, a9, a8
.L3149:
	l32i	a8, sp, 684
	l32i	a12, sp, 656
	s8i	a5, a8, 200
	movi	a11, 0x188
	addi	a8, sp, 16
	mov.n	a13, a4
	add.n	a11, a8, a11
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3150
	movi.n	a12, 1
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	movi.n	a8, -1
	s32i	a8, sp, 64
	l32i	a8, sp, 684
	l32i	a12, sp, 656
	l32i	a8, a8, 188
	mov.n	a13, a4
	s32i	a8, sp, 68
	movi.n	a8, 1
	s8i	a8, sp, 72
	l32i	a8, sp, 684
	addi	a11, sp, 16
	l32i	a8, a8, 156
	mov.n	a10, a7
	s32i	a8, sp, 36
	l32i	a8, sp, 684
	l32i	a8, a8, 160
	s32i	a8, sp, 40
	l32i	a8, sp, 684
	l8ui	a8, a8, 201
	s8i	a8, sp, 81
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	movi	a8, 0x1d0
	addi	a9, sp, 16
	add.n	a8, a9, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3052
.L3150:
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE
	l8ui	a8, a7, 0
	bnei	a8, 4, .L3153
	l32r	a8, .LC1326
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3154
	l32i	a8, sp, 672
	l8ui	a8, a8, 3
	beqz.n	a8, .L3153
	l32r	a8, .LC1314
	l8ui	a9, a7, 24
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bne	a9, a8, .L3153
.L3157:
	l32r	a8, .LC1318
	movi.n	a9, 0
	add.n	a8, a2, a8
	j	.L3428
.L3154:
	l32i	a9, sp, 668
	l32i	a8, sp, 672
	l32i	a9, a9, 760
	l8ui	a8, a8, 3
	beqz.n	a9, .L3156
	l32i	a9, sp, 672
	l8ui	a9, a9, 0
	bnei	a9, 1, .L3156
	bnez.n	a8, .L3157
	l32i	a8, sp, 672
	l8ui	a8, a8, 2
	bnez.n	a8, .L3158
	l32i	a8, sp, 672
	l8ui	a8, a8, 158
	bnez.n	a8, .L3158
	movi	a8, 0x783
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnei	a8, 2, .L3159
.L3158:
	movi.n	a8, -0x1b
	addmi	a8, a8, 0xc00
	add.n	a8, a7, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
	j	.L3159
.L3156:
	bnez.n	a8, .L3157
	j	.L3159
.L3422:
	l32i	a8, sp, 672
	l8ui	a8, a8, 158
	beqz.n	a8, .L3153
.L3248:
	l32r	a8, .LC1306
	l32i	a10, sp, 668
	add.n	a8, a2, a8
	l32i	a10, a10, 0
	l32i	a8, a8, 0
	bne	a10, a8, .L3153
	l32r	a8, .LC1297
	movi	a6, 0x738
	add.n	a6, a7, a6
	add.n	a8, a2, a8
	l32i	a10, a6, 0
	l32i	a8, a8, 0
	bne	a10, a8, .L3153
	l32r	a8, .LC1291
	l32i	a10, a7, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a10, a8, .L3153
	movi.n	a11, 0x48
	addmi	a11, a11, 0x900
	bnez.n	a9, .L3427
.L3160:
	movi	a11, 0x7e
	addmi	a11, a11, 0x900
.L3427:
	l32r	a10, .LC1330
	add.n	a11, a7, a11
	movi.n	a12, 0xa
	add.n	a10, a2, a10
	call8	memcpy
	l32i	a8, sp, 668
	l32i	a9, a8, 0
	l32r	a8, .LC1318
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC1331
	l32i	a9, a6, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC1332
	l32i	a9, a7, 20
	add.n	a8, a2, a8
.L3428:
	s32i	a9, a8, 0
.L3153:
	l32i	a11, sp, 680
	l32i	a10, sp, 664
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	movi.n	a8, 0
	s32i	a8, a7, 32
	s32i	a8, a7, 36
	s32i	a8, a7, 40
	s32i	a8, a7, 44
	l32i	a8, sp, 692
	l8ui	a8, a8, 0
	beqz.n	a8, .L3163
	addmi	a8, a7, 0x1000
	l16ui	a9, a8, 208
	movi	a8, 0x200
	beq	a9, a8, .L3417
.L3163:
	l8ui	a8, a7, 0
	bnei	a8, 6, .L3194
	j	.L3418
.L3417:
	l32r	a8, .LC1291
	l32r	a5, .LC1310
	add.n	a8, a2, a8
	l32i	a9, a7, 20
	l32i	a8, a8, 0
	add.n	a5, a7, a5
	bne	a9, a8, .L3169
	l32r	a11, .LC1334
	l32r	a10, .LC1335
	add.n	a11, a2, a11
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L3169
	l32r	a8, .LC1306
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a9, a9, 28
	l32i	a8, a8, 0
	bne	a9, a8, .L3169
	l32r	a11, .LC1336
	mov.n	a10, a5
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS9getDriverERKNS0_13DriverContextERNS0_17DriverObservationE
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3169
	l32r	a8, .LC1337
	add.n	a8, a2, a8
	l16ui	a6, a8, 0
	l32i	a8, sp, 660
	l8ui	a8, a8, 8
	bnei	a8, 10, .L3171
	movi	a8, 0xb8
	addmi	a8, a8, 0xb00
	bltu	a8, a6, .L3172
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE
	beqz.n	a10, .L3173
	l32r	a8, .LC1341
	add.n	a8, a2, a8
	l16ui	a8, a8, 0
	bne	a8, a6, .L3172
.L3173:
	l32r	a8, .LC1342
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L3169
	l32r	a8, .LC1343
	add.n	a8, a2, a8
	l16ui	a8, a8, 0
	beq	a8, a6, .L3169
.L3172:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_132revokePositionStartSpeedRelationERNS_3AppE
	l32r	a8, .LC1344
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC1318
	movi.n	a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	j	.L3169
.L3171:
	l32r	a8, .LC1345
	add.n	a8, a2, a8
	l8ui	a9, a8, 0
	beqz.n	a9, .L3169
	l32r	a9, .LC1346
	add.n	a9, a2, a9
	l16ui	a9, a9, 0
	beq	a9, a6, .L3169
	s8i	a10, a8, 0
	l32r	a8, .LC1347
	add.n	a8, a2, a8
	s16i	a10, a8, 0
.L3169:
	l8ui	a8, a7, 71
	bnez.n	a8, .L3260
	l32r	a8, .LC1306
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L3260
	l32r	a8, .LC1297
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a9, a9, 20
	l32i	a8, a8, 0
	bne	a9, a8, .L3260
	l32r	a8, .LC1291
	l32i	a9, a7, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L3260
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_119singleSettingPolicyERNS_3AppEy
	l32r	a8, .LC1278
	beqz.n	a10, .L3430
	l32r	a11, .LC1348
	mov.n	a10, a5
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS9getDriverERKNS0_13DriverContextERNS0_17DriverObservationE
	addi	a6, sp, 16
	movi	a13, 0x1dc
	mov.n	a9, a11
	mov.n	a8, a12
	add.n	a13, a6, a13
	s32i	a10, a13, 0
	s32i	a9, a13, 4
	s32i	a8, a13, 8
	extui	a3, a10, 0, 8
	movi	a12, 0x88
	movi.n	a11, 0
	mov.n	a10, a6
	s32i	a9, sp, 712
	s32i	a8, sp, 700
	call8	memset
	movi.n	a10, 7
	s16i	a10, sp, 30
	movi	a10, 0x190
	l32i	a8, sp, 660
	s16i	a10, sp, 34
	movi.n	a10, 1
	s8i	a10, sp, 82
	movi.n	a10, 2
	s16i	a10, sp, 104
	l32i	a10, a8, 0
	l32i	a9, sp, 712
	s32i	a10, sp, 24
	l32i	a8, sp, 700
	bnez.n	a3, .L3174
	movi.n	a8, 0x5a
	addmi	a8, a8, 0x1f00
	add.n	a8, a7, a8
	l16ui	a11, a8, 0
	l32i	a8, sp, 660
	mov.n	a10, a6
	l8ui	a8, a8, 8
	bnei	a8, 10, .L3177
	call8	_ZN14MotorControlRS6ESS_RS25preparePositionStartSpeedERNS0_13DriverRequestEm
	j	.L3429
.L3177:
	call8	_ZN14MotorControlRS6ESS_RS22prepareHomingAuxiliaryERNS0_13DriverRequestENS0_15HomingAuxiliaryE
.L3429:
	addi	a13, sp, 16
	s32i	a10, a6, 464
	extui	a3, a10, 0, 8
	addmi	a10, a13, 0x100
	s8i	a3, a10, 208
	movi	a10, 0x1d0
	add.n	a10, a13, a10
	s32i	a11, a10, 4
	s32i	a12, a10, 8
	movi	a6, 0x1dc
	l32i	a10, a10, 0
	add.n	a6, a13, a6
	s32i	a10, a6, 0
	s32i	a11, a6, 4
	s32i	a12, a6, 8
	mov.n	a9, a11
	mov.n	a8, a12
	bnez.n	a3, .L3174
	l32i	a8, a7, 56
	l32i	a9, a7, 60
	s32i	a8, sp, 8
	l32i	a8, sp, 656
	s32i	a9, sp, 12
	s32i	a8, sp, 0
	l32r	a14, .LC1350
	l32r	a11, .LC1335
	s32i	a4, sp, 4
	l32i	a12, a7, 4
	add.n	a14, a2, a14
	add.n	a11, a7, a11
	mov.n	a10, a5
	call8	_ZN14MotorControlRS6ESS_RS21prepareDriverSettingsERNS0_13DriverContextERKNS_10ReadTargetEmRKNS0_13DriverRequestERKNS0_19DriverPrerequisitesEyy
	s32i	a10, a6, 0
	s32i	a11, a6, 4
	s32i	a12, a6, 8
	extui	a3, a10, 0, 8
	mov.n	a9, a11
	mov.n	a8, a12
	beqz.n	a3, .L3163
	j	.L3174
.L3260:
	l32r	a8, .LC1280
	j	.L3430
.L3430:
	movi.n	a9, 0
	movi.n	a3, 1
.L3174:
	movi	a10, 0xd1
	addmi	a10, a10, 0x1000
	add.n	a10, a7, a10
	movi.n	a11, 3
	s8i	a11, a10, 0
	movi	a10, 0xd2
	addmi	a10, a10, 0x1000
	add.n	a10, a7, a10
	movi.n	a11, 9
	s8i	a11, a10, 0
	addi	a10, sp, 16
	addmi	a11, a10, 0x100
	s8i	a3, a11, 220
	movi	a11, 0x1dc
	add.n	a10, a10, a11
	movi.n	a11, 0x48
	s32i	a9, a10, 4
	s32i	a8, a10, 8
	addmi	a11, a11, 0x1f00
	l32i	a10, a10, 0
	add.n	a11, a7, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	s32i	a8, a11, 8
	j	.L3163
.L3418:
	l32i	a8, sp, 660
	l8ui	a6, a8, 32
	bnez.n	a6, .L3194
	l32i	a8, sp, 692
	l8ui	a8, a8, 0
	bnez.n	a8, .L3194
	l32i	a8, sp, 660
	l8ui	a10, a8, 8
	addi	a8, a10, -2
	extui	a8, a8, 0, 8
	bltui	a8, 3, .L3194
	l32r	a8, .LC1314
	l8ui	a9, a7, 24
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bne	a9, a8, .L3194
	l32r	a8, .LC1306
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L3194
	l32r	a8, .LC1297
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a9, a9, 20
	l32i	a8, a8, 0
	bne	a9, a8, .L3194
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	l32i	a8, sp, 660
	s32i	a10, sp, 692
	l8ui	a8, a8, 8
	beqz.n	a10, .L3181
	addi	a8, a8, -6
	slli	a9, a8, 4
	sub	a9, a9, a8
	subx4	a8, a9, a8
	l32r	a9, .LC1354
	addx8	a8, a8, a9
	j	.L3431
.L3181:
	bnei	a8, 1, .L3183
	l32r	a8, .LC1355
	j	.L3431
.L3183:
	bnei	a8, 5, .L3184
	l32r	a8, .LC1356
	j	.L3431
.L3184:
	l32r	a8, .LC1357
.L3431:
	add.n	a3, a2, a8
	l32i	a10, a7, 4
	l32i	a9, a3, 16
	bgeu	a9, a10, .L3194
	l32r	a9, .LC1358
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	bgeu	a9, a10, .L3194
	movi.n	a9, 0x29
	addmi	a9, a9, 0x1700
	add.n	a8, a7, a9
	s32i	a8, sp, 712
	movi	a9, 0x1d0
	addi	a8, sp, 16
	add.n	a8, a8, a9
	movi.n	a5, 0
	s32i	a8, sp, 700
	j	.L3185
.L3193:
	l32i	a10, sp, 700
	movi.n	a12, 0xa
	movi.n	a11, 0
	call8	memset
	addx2	a9, a6, a6
	slli	a9, a9, 5
	movi	a10, 0x84
	add.n	a9, a7, a9
	addmi	a10, a10, 0x1800
	add.n	a10, a9, a10
	l16ui	a13, a10, 0
	movi.n	a11, 0
	movi	a10, 0x98
	l8ui	a12, a7, 24
	s32i	a11, sp, 492
	s32i	a11, sp, 4
	addmi	a10, a10, 0x1800
	addi	a8, sp, 16
	movi	a11, 0x1dc
	add.n	a9, a9, a10
	add.n	a11, a8, a11
	addx2	a10, a6, a6
	movi	a14, 0x88
	addmi	a14, a14, 0x1800
	s32i	a11, sp, 0
	slli	a10, a10, 5
	add.n	a10, a10, a14
	l32i	a11, a9, 0
	l32i	a14, sp, 700
	movi.n	a15, 5
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS14parseRegistersEPKhjhtPtjRjPNS0_10FrameErrorE
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3186
	l32i	a9, a3, 16
	bnez.n	a9, .L3187
	l32i	a8, sp, 688
	l8ui	a9, a8, 0
	beqz.n	a9, .L3188
.L3187:
	l32i	a8, sp, 660
	l8ui	a10, a3, 0
	l8ui	a9, a8, 8
	bne	a10, a9, .L3188
	l32r	a11, .LC1335
	addi.n	a10, a3, 4
	add.n	a11, a7, a11
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	bnez.n	a10, .L3189
.L3188:
	l32i	a8, sp, 692
	bnez.n	a8, .L3186
	j	.L3419
.L3189:
	addx2	a9, a6, a6
	l32r	a10, .LC1362
	slli	a9, a9, 5
	add.n	a9, a7, a9
	add.n	a9, a9, a10
	l32i	a13, sp, 492
	l16ui	a11, a9, 0
	movi	a12, 0x1e0
	add.n	a12, sp, a12
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_119changedDriverWindowERKN14MotorControlRS6ESS_RS17DriverObservationEtPKtj
	j	.L3432
.L3419:
	l32r	a9, .LC1358
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	bnez.n	a9, .L3192
	l32i	a8, sp, 688
	l8ui	a9, a8, 0
	beqz.n	a9, .L3186
.L3192:
	l32r	a11, .LC1335
	l32r	a10, .LC1363
	add.n	a11, a7, a11
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L3186
	addx2	a9, a6, a6
	l32r	a10, .LC1362
	slli	a9, a9, 5
	add.n	a9, a7, a9
	add.n	a9, a9, a10
	l32r	a10, .LC1364
	movi	a12, 0x1e0
	l32i	a13, sp, 492
	l16ui	a11, a9, 0
	add.n	a12, sp, a12
	add.n	a10, a2, a10
	call8	_ZN12_GLOBAL__N_119changedConfigWindowERKN14MotorControlRS6ESS_RS9RawConfigEtPKtj
.L3432:
	or	a5, a5, a10
.L3186:
	addi.n	a6, a6, 1
	extui	a6, a6, 0, 8
.L3185:
	l32i	a8, sp, 712
	l8ui	a9, a8, 0
	bltu	a6, a9, .L3193
	l32i	a8, sp, 660
	l32i	a8, a8, 4
	and	a12, a8, a5
	xor	a12, a12, a5
	beqz.n	a12, .L3194
	or	a5, a5, a8
	l32i	a8, sp, 660
	l32i	a9, sp, 688
	s32i	a5, a8, 4
	movi.n	a8, 1
	s8i	a8, a9, 0
	l32i	a8, sp, 660
	l8ui	a11, a7, 24
	l8ui	a8, a8, 8
	l32i	a14, sp, 656
	s32i	a8, sp, 4
	s32i	a7, sp, 0
	mov.n	a15, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE
	l32r	a8, .LC1306
	l32i	a9, sp, 660
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	s32i	a8, a9, 0
.L3194:
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L3196
	l8ui	a8, a7, 71
	bnez.n	a8, .L3197
	movi.n	a12, 2
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32r	a8, .LC1297
	l32i	a9, sp, 24
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L3197
	l8ui	a8, a7, 0
	bnei	a8, 4, .L3198
	movi	a8, 0x6f0
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnei	a8, 1, .L3199
	movi	a8, 0x704
	add.n	a8, a7, a8
	j	.L3433
.L3199:
	l32i	a8, sp, 668
.L3433:
	l32i	a6, a8, 0
	l32r	a8, .LC1326
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3201
	l32r	a8, .LC1306
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	j	.L3202
.L3201:
	l8ui	a11, a7, 24
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	movi.n	a8, 0
	beqz.n	a10, .L3202
	l32i	a8, a10, 20
.L3202:
	bne	a6, a8, .L3197
	j	.L3209
.L3198:
	bnei	a8, 5, .L3204
	l32r	a8, .LC1313
	add.n	a9, a7, a8
	l8ui	a9, a9, 0
	beqi	a9, 3, .L3205
	l32r	a9, .LC1306
	l32i	a10, sp, 668
	add.n	a9, a2, a9
	l32i	a10, a10, 868
	l32i	a9, a9, 0
	bne	a10, a9, .L3197
	j	.L3205
.L3204:
	beqi	a8, 7, .L3206
	beqi	a8, 3, .L3207
	j	.L3209
.L3206:
	l32r	a8, .LC1306
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L3197
	l32i	a9, sp, 660
	l32i	a9, a9, 0
	beq	a8, a9, .L3209
.L3197:
	movi.n	a12, 2
	mov.n	a11, a7
	addi	a10, sp, 16
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	addi	a11, sp, 16
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, sp, 612
	s32i	a11, sp, 616
	s32i	a12, sp, 620
	j	.L3196
.L3207:
	l32i	a8, sp, 676
	l8ui	a9, a8, 16
	bnei	a9, 3, .L3209
	j	.L3210
.L3217:
	l32r	a8, .LC1299
	l32i	a12, sp, 656
	add.n	a3, a7, a8
	addi	a5, sp, 16
	mov.n	a13, a4
	mov.n	a10, a3
	call8	_ZN14MotorControlRS6ESS_RS15serviceVelocityERNS0_15VelocityContextEy
	s32i	a10, a5, 572
	s32i	a11, a5, 576
	mov.n	a10, a2
	mov.n	a11, a7
	s32i	a12, a5, 580
	addmi	a6, a5, 0x200
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L3196
	j	.L3420
.L3247:
	l32r	a8, .LC1298
	add.n	a8, a7, a8
.L3210:
	l8ui	a8, a8, 88
	beqz.n	a8, .L3214
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L3215
.L3216:
	addi	a6, sp, 16
	movi.n	a12, 1
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, sp, 600
	s32i	a11, sp, 604
	s32i	a12, sp, 608
	j	.L3434
.L3215:
	l32r	a10, .LC1294
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3216
.L3214:
	l8ui	a8, a7, 0
	bnei	a8, 5, .L3209
	j	.L3217
.L3420:
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L3196
	l32r	a10, .LC1294
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3196
	movi.n	a12, 0x50
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a8, 2
	l32i	a12, sp, 656
	s8i	a8, sp, 16
	mov.n	a10, a3
	mov.n	a14, a5
	mov.n	a13, a4
	call8	_ZN14MotorControlRS6ESS_RS12nextVelocityERKNS0_15VelocityContextEyRNS0_16PreparedVelocityE
	l8ui	a8, sp, 16
	s32i	a10, a5, 392
	or	a10, a10, a8
	s32i	a11, a5, 396
	s32i	a12, a5, 400
	extui	a10, a10, 0, 8
	addmi	a3, a5, 0x100
	bnez.n	a10, .L3196
	l32i	a14, sp, 656
	mov.n	a15, a4
	mov.n	a12, a5
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_117admitVelocityStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS16PreparedVelocityEy
	movi	a8, 0x65
	bbs	a8, a10, .L3196
	movi	a10, 0x88
	movi.n	a12, 1
	mov.n	a11, a7
	add.n	a10, a3, a10
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	movi	a11, 0x188
	mov.n	a13, a4
	add.n	a11, a5, a11
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, a6, 48
	s32i	a11, a6, 52
	s32i	a12, a6, 56
	j	.L3196
.L3244:
	addi	a6, sp, 16
	movi.n	a12, 3
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, sp, 564
	s32i	a11, sp, 568
	s32i	a12, sp, 572
	j	.L3434
.L3246:
	l32i	a10, sp, 664
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L3196
	l32r	a10, .LC1294
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3196
	l8ui	a8, a7, 0
	beqi	a8, 6, .L3221
	bgeui	a8, 7, .L3222
	beqi	a8, 3, .L3223
	beqi	a8, 4, .L3224
	j	.L3196
.L3222:
	bnei	a8, 7, .L3196
	addi	a6, sp, 16
	addmi	a3, a6, 0x100
	movi	a5, 0x88
	add.n	a5, a3, a5
	movi.n	a12, 0x48
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi	a10, 0x60
	movi.n	a8, 2
	l32i	a12, sp, 656
	addmi	a10, a10, 0x1f00
	s8i	a8, a3, 136
	mov.n	a14, a5
	mov.n	a13, a4
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS8nextHomeERKNS0_11HomeContextEyRNS0_12PreparedHomeE
	movi	a8, 0x1d0
	add.n	a8, a6, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3226
	movi.n	a12, 3
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, a6, 536
	s32i	a11, a6, 540
	s32i	a12, a6, 544
	j	.L3434
.L3226:
	l8ui	a8, a3, 136
	bnez.n	a8, .L3196
	l32i	a14, sp, 656
	mov.n	a15, a4
	mov.n	a12, a5
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113admitHomeStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedHomeEy
	movi	a8, 0x65
	bbs	a8, a10, .L3196
	movi.n	a12, 1
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, a6, 524
	s32i	a11, a6, 528
	s32i	a12, a6, 532
	j	.L3434
.L3224:
	addi	a6, sp, 16
	movi	a14, 0x88
	addmi	a5, a6, 0x100
	add.n	a10, a5, a14
	movi.n	a12, 0x48
	movi.n	a11, 0
	call8	memset
	movi.n	a8, 2
	mov.n	a14, a10
	l32i	a12, sp, 656
	movi	a10, 0x6f0
	s8i	a8, a5, 136
	mov.n	a13, a4
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS8nextMoveERKNS0_11MoveContextEyRNS0_12PreparedMoveE
	movi	a8, 0x1d0
	add.n	a8, a6, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3231
	beqi	a11, 6, .L3232
.L3231:
	l32r	a8, .LC1326
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3233
	j	.L3234
.L3232:
	movi.n	a12, 3
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a13, a4
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	s32i	a10, a6, 512
	s32i	a11, a6, 516
	s32i	a12, a6, 520
.L3434:
	addmi	a6, a6, 0x200
	j	.L3196
.L3233:
	l32i	a8, sp, 668
	l32i	a9, sp, 672
	l8ui	a8, a8, 176
	l8ui	a9, a9, 155
	bltu	a9, a8, .L3196
.L3234:
	addi	a8, sp, 16
	addmi	a9, a8, 0x100
	l8ui	a9, a9, 136
	or	a10, a10, a9
	bnez.n	a10, .L3196
	movi	a12, 0x188
	l32i	a14, sp, 656
	mov.n	a15, a4
	add.n	a12, a8, a12
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy
	bnez.n	a10, .L3196
	l32i	a8, sp, 696
.L3437:
	s8i	a10, a8, 0
	j	.L3196
.L3221:
	addi	a6, sp, 16
	addmi	a3, a6, 0x100
	movi	a5, 0x88
	add.n	a5, a3, a5
	movi.n	a12, 0x30
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	l32r	a10, .LC1310
	movi.n	a8, 2
	l32i	a12, sp, 656
	s8i	a8, a3, 136
	mov.n	a14, a5
	mov.n	a13, a4
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS10nextDriverERKNS0_13DriverContextEyRNS0_14PreparedDriverE
	movi	a8, 0x1d0
	add.n	a8, a6, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3238
	mov.n	a10, a6
	movi.n	a12, 3
	mov.n	a11, a7
	call8	_ZN12_GLOBAL__N_111actionEventERKNS_3App6RecordEN14MotorControlRS13ReadEventKindE
	l32i	a12, sp, 656
	mov.n	a11, a6
	mov.n	a13, a4
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_116advanceOperationERNS_3App6RecordERKN14MotorControlRS11ActionEventEy
	movi	a8, 0x1f4
	add.n	a6, a6, a8
	s32i	a10, a6, 0
	s32i	a11, a6, 4
	s32i	a12, a6, 8
	j	.L3196
.L3238:
	l8ui	a8, a3, 136
	bnez.n	a8, .L3196
	l32i	a14, sp, 656
	mov.n	a15, a4
	mov.n	a12, a5
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115admitDriverStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedDriverEy
	j	.L3196
.L3223:
	addi	a6, sp, 16
	movi.n	a12, 0x40
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	movi.n	a8, 2
	l32i	a12, sp, 656
	l32i	a10, sp, 676
	s8i	a8, sp, 16
	mov.n	a14, a6
	mov.n	a13, a4
	call8	_ZN14MotorControlRS6ESS_RS10nextActionERKNS0_13ActionContextEyRNS0_14PreparedActionE
	l8ui	a8, sp, 16
	s32i	a10, sp, 408
	or	a10, a10, a8
	s32i	a11, sp, 412
	s32i	a12, sp, 416
	extui	a10, a10, 0, 8
	bnez.n	a10, .L3196
	l32i	a14, sp, 656
	mov.n	a15, a4
	mov.n	a12, a6
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115admitActionStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedActionEy
.L3196:
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_123updateActionReservationERNS_3AppERNS0_6RecordE
.L3052:
	l32i	a9, sp, 680
	movi.n	a8, 0x50
	addmi	a8, a8, 0x2300
	add.n	a9, a9, a8
	s32i	a9, sp, 680
	l32i	a9, sp, 676
	add.n	a7, a7, a8
	add.n	a9, a9, a8
	s32i	a9, sp, 676
	l32i	a9, sp, 668
	add.n	a9, a9, a8
	s32i	a9, sp, 668
	l32i	a9, sp, 672
	add.n	a9, a9, a8
	s32i	a9, sp, 672
	l32i	a9, sp, 660
	add.n	a8, a9, a8
	s32i	a8, sp, 660
.L3041:
	l32i	a8, sp, 708
	bne	a7, a8, .L3243
	j	.L3421
.L3209:
	l32i	a8, a7, 60
	bltu	a4, a8, .L3246
	bne	a8, a4, .L3244
	l32i	a8, a7, 56
	l32i	a9, sp, 656
	bltu	a9, a8, .L3246
	j	.L3244
.L3205:
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnei	a8, 3, .L3217
	j	.L3247
.L3159:
	l32i	a8, sp, 672
	l8ui	a9, a8, 2
	bnez.n	a9, .L3248
	j	.L3422
.L3138:
	beqz.n	a8, .L3134
	j	.L3140
.L3421:
	retw.n
.LFE2227:
	.size	_ZN12_GLOBAL__N_114advanceActionsERNS_3AppEy, .-_ZN12_GLOBAL__N_114advanceActionsERNS_3AppEy
	.section	.text._ZN14MotorControlRS6ESS_RS17HomePrerequisitesC2Ev,"axG",@progbits,_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC2Ev
	.type	_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC2Ev, @function
_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC2Ev:
.LFB1960:
	entry	sp, 32
.LCFI158:
	movi.n	a9, 0x23
	s32i	a9, a2, 20
	movi.n	a9, 7
	movi.n	a7, 0
	movi.n	a5, 0
	movi.n	a6, 0
	movi.n	a8, 0
	slli	a9, a9, 16
	s32i	a7, a2, 0
	s8i	a7, a2, 4
	s32i	a7, a2, 8
	s32i	a7, a2, 12
	s16i	a7, a2, 16
	s8i	a8, a2, 18
	s32i	a7, a2, 24
	s32i	a9, a2, 28
	s32i	a7, a2, 32
	s8i	a8, a2, 36
	s16i	a7, a2, 38
	s16i	a7, a2, 40
	s32i	a5, a2, 48
	s32i	a6, a2, 52
	s32i	a5, a2, 56
	s32i	a6, a2, 60
	s32i	a5, a2, 64
	s32i	a6, a2, 68
	s32i	a5, a2, 72
	s32i	a6, a2, 76
	s8i	a8, a2, 80
	movi.n	a12, 8
	movi.n	a11, 0
	addi	a10, a2, 82
	call8	memset
	s16i	a7, a2, 90
	s32i	a7, a2, 92
	s16i	a7, a2, 96
	s32i	a5, a2, 104
	s32i	a6, a2, 108
	s32i	a5, a2, 112
	s32i	a6, a2, 116
	retw.n
.LFE1960:
	.size	_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC2Ev, .-_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC2Ev
	.weak	_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC1Ev
	.set	_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC1Ev,_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC2Ev
	.text
	.literal_position
	.literal .LC1373, .LC12
	.literal .LC1382, 10000
	.literal .LC1389, 1966140
	.align	4
	.type	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE, @function
_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE:
.LFB2049:
	entry	sp, 48
.LCFI159:
	movi.n	a12, 0x50
	addmi	a12, a12, 0x2300
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	movi	a8, 0xe1
	slli	a8, a8, 9
	s32i	a8, a2, 12
	addi	a10, a2, 80
	call8	_ZN14MotorControlRS6ESS_RS11ReadContextC1Ev
	movi	a10, 0x320
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu14RecoveryResultC1Ev
	l32r	a6, .LC1373
	addmi	a8, a2, 0x300
	movi.n	a9, 1
	addmi	a10, a2, 0x400
	s8i	a9, a8, 201
	s32i	a6, a8, 296
	movi	a12, 0x100
	movi.n	a11, 0
	addi	a10, a10, 47
	call8	memset
	movi	a10, 0x530
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS13ActionContextC1Ev
	movi	a10, 0x6f0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS11MoveContextC1Ev
	movi	a9, 0xd8
	movi.n	a7, 0
	addmi	a8, a2, 0xb00
	addmi	a9, a9, 0xb00
	s32i	a7, a8, 192
	s8i	a7, a8, 196
	s32i	a7, a8, 200
	s32i	a7, a8, 204
	s32i	a7, a8, 208
	s32i	a7, a8, 212
	s32i	a7, a8, 216
	s32i	a7, a8, 220
	add.n	a9, a2, a9
	s32i	a7, a9, 8
	movi.n	a4, 0
	movi.n	a9, 0
	movi.n	a14, 1
	s16i	a14, a8, 228
	s32i	a9, a8, 232
	s32i	a9, a8, 240
	s32i	a4, a8, 236
	s32i	a4, a8, 244
	movi.n	a8, -8
	addmi	a8, a8, 0xc00
	add.n	a8, a2, a8
	s32i	a7, a8, 4
	s8i	a7, a8, 8
	s32i	a7, a8, 0
	movi	a10, 0x103
	addmi	a8, a2, 0xc00
	movi.n	a15, 0
	movi.n	a12, 1
	movi.n	a11, 0
	s16i	a10, a8, 40
	movi.n	a13, 0x48
	movi.n	a10, 0
	s32i	a15, a8, 36
	s32i	a9, a8, 24
	s32i	a12, a8, 32
	s8i	a7, a8, 4
	s32i	a7, a8, 8
	s8i	a7, a8, 12
	s32i	a7, a8, 16
	s32i	a7, a8, 20
	s8i	a7, a8, 42
	s32i	a7, a8, 44
	s8i	a7, a8, 48
	s32i.n	a10, a8, 56
	s32i.n	a11, a8, 60
	s32i	a4, a8, 28
	addmi	a13, a13, -0xc00
	s8i	a7, a8, 64
	s16i	a13, a8, 162
	movi	a13, 0xb8
	addmi	a13, a13, 0xb00
	s32i	a13, a8, 164
	movi	a13, 0xc8
	movi.n	a5, 0
	addmi	a13, a13, 0xc00
	add.n	a13, a2, a13
	s32i	a9, a8, 176
	s32i	a9, a8, 184
	s32i	a10, a8, 72
	s32i	a11, a8, 76
	s8i	a7, a8, 80
	s32i	a10, a8, 88
	s32i	a11, a8, 92
	s32i	a10, a8, 96
	s32i	a11, a8, 100
	s32i	a7, a8, 104
	s16i	a7, a8, 108
	s32i	a10, a8, 112
	s32i	a11, a8, 116
	s16i	a7, a8, 120
	s32i	a7, a8, 124
	s16i	a7, a8, 128
	s32i	a7, a8, 136
	s32i	a7, a8, 144
	s32i	a7, a8, 148
	s32i	a7, a8, 152
	s16i	a7, a8, 158
	s16i	a7, a8, 160
	s16i	a7, a8, 168
	s16i	a7, a8, 192
	s8i	a5, a8, 130
	s8i	a5, a8, 140
	s8i	a5, a8, 156
	s32i	a4, a8, 180
	s32i	a4, a8, 188
	s32i	a9, a13, 0
	s32i	a4, a13, 4
	s32i	a9, a13, 8
	s32i	a12, a13, 16
	s32i	a4, a13, 12
	s32i	a15, a13, 20
	s8i	a5, a13, 24
	s32i	a11, a8, 236
	s32i	a11, a8, 244
	s32i	a11, a8, 252
	l32r	a11, .LC1382
	s32i	a10, a8, 232
	s32i	a10, a8, 240
	s32i	a10, a8, 248
	addmi	a10, a2, 0xd00
	s32i	a11, a10, 8
	movi.n	a11, 0x14
	s8i	a14, a10, 0
	s8i	a11, a10, 12
	s32i	a7, a10, 16
	s32i	a7, a10, 20
	s32i	a7, a10, 24
	s32i	a7, a10, 28
	s32i	a7, a10, 32
	s16i	a7, a10, 36
	movi.n	a3, 8
	s32i	a9, a8, 304
	s32i	a9, a8, 312
	s32i	a9, a8, 320
	s32i	a9, a8, 328
	s32i	a9, a8, 336
	s16i	a7, a8, 294
	s16i	a7, a8, 296
	s32i	a4, a8, 308
	s32i	a4, a8, 316
	s32i	a4, a8, 324
	s32i	a4, a8, 332
	addmi	a3, a3, 0xc00
	add.n	a3, a2, a3
	s32i	a4, a8, 340
	s16i	a7, a10, 88
	movi	a10, 0x158
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x1b0
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x208
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x260
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x2b8
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x310
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS13ActionContextC1Ev
	addmi	a8, a2, 0x1000
	s32i	a7, a8, 164
	s32i	a7, a8, 176
	s32i	a7, a8, 180
	s32i	a7, a8, 188
	s32i	a7, a8, 196
	s32i	a7, a8, 200
	s32i	a7, a8, 204
	s16i	a7, a8, 208
	movi	a7, 0xb8
	addmi	a7, a7, 0x1000
	add.n	a7, a2, a7
	s8i	a5, a8, 160
	s32i	a6, a8, 168
	s8i	a5, a8, 184
	s8i	a5, a8, 192
	s8i	a5, a8, 210
	addi	a10, a7, 32
	call8	_ZN14MotorControlRS6ESS_RS13DriverRequestC1Ev
	movi	a10, 0xa8
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC1Ev
	addmi	a7, a2, 0x1700
	movi.n	a9, 0
	s32i	a9, a7, 8
	s32i	a9, a7, 16
	s32i	a9, a7, 24
	s32i	a9, a7, 32
	movi.n	a12, 0x10
	movi.n	a11, 0
	s32i	a4, a7, 12
	s32i	a4, a7, 20
	s32i	a4, a7, 28
	s32i	a4, a7, 36
	s8i	a5, a7, 40
	s8i	a5, a7, 41
	s8i	a5, a7, 42
	addi	a10, a7, 43
	call8	memset
	movi	a12, 0x140
	movi.n	a11, 0
	addi	a10, a7, 60
	call8	memset
	movi.n	a8, 0x3c
	addmi	a8, a8, 0x1700
	add.n	a8, a2, a8
	movi.n	a10, 1
	movi.n	a9, 0x10
	loop	a9, .L3445_LEND
.L3445:
	s32i	a10, a8, 0
	addi	a8, a8, 20
	.L3445_LEND:
	movi	a8, 0x80
	addmi	a10, a2, 0x1800
	add.n	a10, a10, a8
	movi	a12, 0x6c0
	movi.n	a11, 0
	call8	memset
	movi	a8, 0xd4
	addmi	a8, a8, 0x1800
	add.n	a8, a2, a8
	movi.n	a9, 0x12
	loop	a9, .L3447_LEND
.L3447:
	s32i	a6, a8, 0
	addi	a8, a8, 96
	.L3447_LEND:
	addmi	a7, a2, 0x1f00
	movi.n	a8, 0x23
	s16i	a8, a7, 112
	movi	a3, 0x60
	l32r	a8, .LC1389
	addmi	a3, a3, 0x1f00
	movi.n	a4, 0
	add.n	a3, a2, a3
	movi.n	a5, 0
	movi.n	a13, 0
	s32i	a8, a7, 120
	movi	a8, 0x64
	s32i	a13, a7, 128
	s16i	a8, a7, 124
	addi	a10, a3, 40
	s32i	a4, a7, 64
	s8i	a4, a7, 68
	s8i	a4, a7, 72
	s32i	a4, a7, 76
	s32i	a6, a7, 80
	s32i	a4, a7, 88
	s32i	a4, a7, 96
	s8i	a4, a7, 100
	s32i	a4, a7, 104
	s32i	a4, a7, 108
	s32i	a4, a7, 116
	s32i	a5, a7, 132
	call8	_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC1Ev
	l32r	a9, .LC1382
	addmi	a8, a2, 0x2000
	movi.n	a10, 0x14
	s32i	a9, a8, 0
	s8i	a10, a8, 4
	s32i	a4, a8, 8
	s32i	a4, a8, 12
	s32i	a4, a8, 16
	s32i	a4, a8, 20
	s8i	a4, a8, 24
	movi.n	a12, 0xc
	movi.n	a11, 0
	addi	a10, a8, 28
	s16i	a4, a7, 282
	s32i	a8, sp, 0
	call8	memset
	l32i	a8, sp, 0
	movi.n	a13, 0
	s32i	a4, a8, 40
	s32i	a4, a8, 44
	s32i	a13, a7, 304
	s32i	a13, a7, 312
	s32i	a13, a7, 320
	s32i	a13, a7, 328
	s32i	a13, a7, 336
	s32i	a13, a7, 344
	s32i	a5, a7, 308
	s32i	a5, a7, 316
	s32i	a5, a7, 324
	s32i	a5, a7, 332
	s32i	a5, a7, 340
	s32i	a5, a7, 348
	movi	a10, 0x108
	s16i	a4, a8, 96
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x160
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x1b8
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x210
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x268
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x2c0
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x318
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	movi	a10, 0x370
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS14ActionEvidenceC1Ev
	addmi	a2, a2, 0x2300
	movi.n	a8, 0
	movi.n	a13, 0
	s8i	a8, a2, 40
	s32i	a4, a2, 44
	s32i	a6, a2, 48
	s32i	a4, a2, 56
	s32i	a13, a2, 64
	s32i	a5, a2, 68
	s32i	a4, a2, 72
	retw.n
.LFE2049:
	.size	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE, .-_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	.align	4
	.type	_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm, @function
_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm:
.LFB2237:
	entry	sp, 32
.LCFI160:
	l32i	a11, a3, 0
	beqz.n	a11, .L3454
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a10
	bnez.n	a10, .L3455
.L3457:
	movi.n	a2, 0
	j	.L3456
.L3455:
	l8ui	a8, a10, 65
	beqz.n	a8, .L3457
	l32i	a8, a10, 32
	bnez.n	a8, .L3458
.L3459:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a8, 0
	s32i	a8, a3, 0
	j	.L3454
.L3458:
	addi	a11, a10, 32
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L3459
	j	.L3457
.L3454:
	movi.n	a2, 1
.L3456:
	retw.n
.LFE2237:
	.size	_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm, .-_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm
	.literal_position
	.literal .LC1392, 771192
	.literal .LC1393, 6553660
	.literal .LC1394, 16842852
	.literal .LC1397, .LC12
	.literal .LC1398, .LC435
	.align	4
	.type	_ZN12_GLOBAL__N_119releaseSimpleMotionERNS_3AppEb, @function
_ZN12_GLOBAL__N_119releaseSimpleMotionERNS_3AppEb:
.LFB2238:
	entry	sp, 720
.LCFI161:
	l32r	a7, .LC1392
	add.n	a5, a2, a7
	l8ui	a6, a5, 58
	beqz.n	a6, .L3467
.L3469:
	movi.n	a2, 1
	j	.L3468
.L3467:
	l8ui	a8, a5, 59
	beqz.n	a8, .L3469
	addi	a11, a5, 44
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm
	beqz.n	a10, .L3469
	beqz.n	a3, .L3470
	l32i	a11, a5, 40
	beqz.n	a11, .L3470
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L3469
	l8ui	a8, a10, 65
	beqz.n	a8, .L3469
	s8i	a6, a10, 69
	j	.L3471
.L3470:
	add.n	a11, a2, a7
	addi	a11, a11, 40
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm
	beqz.n	a10, .L3469
.L3471:
	add.n	a6, a2, a7
	l32i	a11, a6, 68
	beqz.n	a11, .L3473
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L3474
	beqz.n	a3, .L3474
	l8ui	a8, a6, 60
	bnez.n	a8, .L3474
	s8i	a8, a10, 69
	j	.L3473
.L3474:
	add.n	a11, a2, a7
	addi	a11, a11, 68
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm
	beqz.n	a10, .L3469
.L3473:
	add.n	a2, a2, a7
	addmi	a6, sp, 0x200
	movi	a8, 0xa0
	add.n	a8, a2, a8
	addi	a4, a6, 112
	mov.n	a11, a8
	movi.n	a12, 0x28
	mov.n	a10, a4
	s32i	a8, sp, 672
	call8	memcpy
	movi	a12, 0x270
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a15, .LC1393
	l32r	a14, .LC1394
	movi	a13, 0x3e8
	movi.n	a9, 0
	movi.n	a8, 1
	movi.n	a7, 1
	movi.n	a3, 0
	movi.n	a12, 0xc
	movi.n	a11, 0
	addi	a10, sp, 92
	s32i	a15, sp, 0
	s32i	a14, sp, 4
	s32i	a13, sp, 16
	s32i	a9, sp, 20
	s32i	a8, sp, 24
	s32i	a3, sp, 28
	s8i	a7, sp, 32
	s8i	a7, sp, 62
	call8	memset
	movi	a10, 0xf0
	movi.n	a12, 0xc
	movi.n	a11, 0
	add.n	a10, sp, a10
	call8	memset
	movi	a10, 0xfc
	movi.n	a12, 0xc
	movi.n	a11, 0
	add.n	a10, sp, a10
	call8	memset
	addmi	a5, sp, 0x100
	movi.n	a12, 0x13
	movi.n	a11, 0
	addi.n	a10, a5, 8
	call8	memset
	movi.n	a12, 0x40
	movi.n	a11, 0
	addi	a10, a5, 27
	call8	memset
	movi.n	a12, 8
	movi.n	a11, 0
	addi	a10, a5, 91
	call8	memset
	movi.n	a12, 0x13
	movi.n	a11, 0
	addi	a10, a5, 99
	call8	memset
	movi	a10, 0x1f2
	movi.n	a12, 8
	movi.n	a11, 0
	add.n	a10, sp, a10
	call8	memset
	l32r	a10, .LC1397
	movi.n	a8, 1
	s32i	a10, sp, 148
	l32r	a10, .LC1398
	l32r	a15, .LC1393
	l32r	a14, .LC1394
	s32i	a8, sp, 184
	s32i	a8, sp, 544
	s32i	a3, sp, 548
	movi.n	a8, 2
	movi	a13, 0x3e8
	movi.n	a9, 0
	s8i	a8, a6, 44
	s32i	a10, sp, 152
	s32i	a10, sp, 472
	movi	a12, 0x26a
	mov.n	a11, sp
	mov.n	a10, a2
	s8i	a7, a6, 42
	s8i	a7, a6, 65
	s32i	a15, sp, 160
	s32i	a14, sp, 164
	s32i	a13, sp, 176
	s32i	a9, sp, 180
	s32i	a3, sp, 188
	s8i	a7, sp, 192
	call8	memcpy
	l32i	a10, sp, 672
	movi.n	a12, 0x21
	mov.n	a11, a4
	call8	memcpy
	mov.n	a10, a2
	movi.n	a12, 0x21
	mov.n	a11, a4
	call8	memcpy
	movi.n	a2, 0
.L3468:
	retw.n
.LFE2238:
	.size	_ZN12_GLOBAL__N_119releaseSimpleMotionERNS_3AppEb, .-_ZN12_GLOBAL__N_119releaseSimpleMotionERNS_3AppEb
	.literal_position
	.literal .LC1400, 771192
	.literal .LC1401, 771352
	.literal .LC1402, .L3516
	.literal .LC1409, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1411, _ZN12_GLOBAL__N_14uartE
	.literal .LC1412, 45697
	.literal .LC1414, 53807
	.literal .LC1415, 626184
	.literal .LC1416, 764508
	.literal .LC1417, 757624
	.literal .LC1418, 101004
	.literal .LC1421, 764504
	.literal .LC1422, 757972
	.literal .LC1423, 757960
	.literal .LC1424, 758244
	.literal .LC1425, 758844
	.literal .LC1426, 772456
	.literal .LC1427, 45700
	.literal .LC1429, 757628
	.literal .LC1430, 5000000
	.literal .LC1431, 50800
	.align	4
	.type	_ZN12_GLOBAL__N_112simpleMotionEPvmPKN21MotorControlRSExample5Probe19SimpleMotionCommandERNS2_16SimpleMotionViewE, @function
_ZN12_GLOBAL__N_112simpleMotionEPvmPKN21MotorControlRSExample5Probe19SimpleMotionCommandERNS2_16SimpleMotionViewE:
.LFB2242:
	entry	sp, 48
.LCFI162:
	l32r	a6, .LC1400
	mov.n	a7, a2
	add.n	a2, a2, a6
	movi	a12, 0xa0
	mov.n	a11, a2
	mov.n	a10, a5
	s32i	a3, sp, 4
	call8	memcpy
	l32r	a3, .LC1401
	movi.n	a12, 0x21
	add.n	a11, a7, a3
	mov.n	a10, a5
	call8	memcpy
	beqz.n	a4, .L3512
	l8ui	a10, a4, 0
	beqz.n	a10, .L3512
	l8ui	a8, a2, 58
	beqz.n	a8, .L3513
.L3529:
	movi.n	a8, 1
	j	.L3514
.L3513:
	addi.n	a9, a10, -1
	extui	a9, a9, 0, 8
	movi.n	a11, 8
	movi.n	a8, 8
	bltu	a11, a9, .L3514
	l32r	a8, .LC1402
	addx4	a9, a9, a8
	l32i	a8, a9, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L3516:
	.word	.L3515
	.word	.L3520
	.word	.L3519
	.word	.L3519
	.word	.L3518
	.word	.L3517
	.word	.L3515
	.word	.L3515
	.word	.L3515
	.text
.L3520:
	movi	a10, 0xb8
	l16ui	a9, a4, 2
	addmi	a10, a10, 0xb00
	movi.n	a8, 8
	bltu	a10, a9, .L3514
	add.n	a8, a7, a6
	s16i	a9, a8, 160
	j	.L3521
.L3519:
	l16ui	a9, a4, 2
	movi	a11, 0x7d0
	movi.n	a8, 8
	bltu	a11, a9, .L3514
	add.n	a8, a7, a6
	bnei	a10, 3, .L3522
	s16i	a9, a8, 162
	movi.n	a9, 1
	s8i	a9, a8, 166
	j	.L3521
.L3522:
	s16i	a9, a8, 164
	movi.n	a9, 1
	s8i	a9, a8, 167
	j	.L3521
.L3518:
	l8ui	a9, a4, 4
	movi.n	a10, -3
	movi.n	a8, 8
	bany	a9, a10, .L3514
	add.n	a8, a7, a6
	s8i	a9, a8, 168
	j	.L3521
.L3517:
	l32i	a9, a4, 12
	l32i	a10, a4, 8
	addi.n	a8, a9, -1
	movnez	a8, a9, a10
	addi.n	a11, a10, -1
	bnez.n	a8, .L3552
	movi.n	a8, -2
	bltu	a8, a11, .L3552
	l32i	a9, a4, 20
	l32i	a10, a4, 16
	addi.n	a8, a9, -1
	movnez	a8, a9, a10
	addi.n	a11, a10, -1
	bnez.n	a8, .L3552
	movi.n	a8, -2
	bltu	a8, a11, .L3552
	l32i	a11, a4, 8
	add.n	a9, a7, a6
	movi	a8, 0xb0
	l32i	a12, a4, 12
	add.n	a8, a9, a8
	s32i	a11, a8, 0
	l32i	a11, a4, 16
	s32i	a12, a8, 4
	l32i	a10, a4, 20
	s32i	a11, a8, 8
	s32i	a10, a8, 12
	movi.n	a8, 1
	s8i	a8, a9, 192
	j	.L3521
.L3515:
	movi.n	a8, 9
	bne	a10, a8, .L3527
	l16ui	a8, a4, 2
	beqz.n	a8, .L3527
	movi	a9, -0x190
	add.n	a8, a8, a9
	l32r	a10, .LC1431
	extui	a9, a8, 0, 16
	movi.n	a8, 8
	bltu	a10, a9, .L3514
.L3527:
	add.n	a8, a7, a6
	l32i	a9, a8, 36
	beqz.n	a9, .L3528
	l8ui	a8, a8, 59
	beqz.n	a8, .L3529
.L3528:
	l32r	a8, .LC1409
	l8ui	a9, a8, 0
	movi.n	a8, 3
	beqz.n	a9, .L3514
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a2, a7, a8
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L3530
.L3531:
	movi.n	a8, 2
	j	.L3514
.L3530:
	l32r	a10, .LC1411
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3531
	l32r	a9, .LC1412
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L3531
	movi	a9, 0x165
	slli	a9, a9, 7
	add.n	a9, a7, a9
	l8ui	a8, a9, 0
	s32i	a8, sp, 0
	beqz.n	a8, .L3531
	l32i	a9, a2, 52
	bnei	a9, -1, .L3529
	l32i	a9, a2, 48
	bnez.n	a9, .L3529
	l32i	a9, a2, 152
	l32i	a10, a2, 156
	or	a9, a9, a10
	bnez.n	a9, .L3529
	l8ui	a8, a2, 137
	bnez.n	a8, .L3529
	l32r	a8, .LC1414
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3529
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L3529
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L3529
	l32r	a8, .LC1415
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3529
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L3529
	l32r	a8, .LC1416
	movi.n	a12, 1
	add.n	a8, a7, a8
	l8ui	a11, a8, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a8, 0xc
	bnez.n	a10, .L3514
	l32r	a8, .LC1417
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	movi.n	a8, 7
	beqz.n	a9, .L3514
	l32r	a8, .LC1418
	add.n	a9, a7, a6
	l8ui	a11, a9, 60
	add.n	a8, a7, a8
	movi.n	a15, 1
	movi.n	a13, 8
	loop	a13, .L3533_LEND
.L3533:
	l32i	a12, a8, 0
	movi.n	a14, 0
	moveqz	a14, a15, a12
	or	a14, a10, a14
	extui	a10, a14, 0, 8
	bnez.n	a10, .L3532
	l32i	a14, a9, 44
	beq	a14, a12, .L3557
	l32i	a14, a9, 68
	beq	a14, a12, .L3558
	beqz.n	a11, .L3532
	l32i	a14, a9, 40
	sub	a14, a14, a12
	moveqz	a10, a15, a14
	j	.L3532
.L3557:
	l32i	a10, sp, 0
	j	.L3532
.L3558:
	mov.n	a10, a11
.L3532:
	movi.n	a12, 0x50
	addmi	a12, a12, 0x2300
	add.n	a8, a8, a12
	.L3533_LEND:
	movi.n	a8, 6
	beqz.n	a10, .L3514
	add.n	a8, a7, a6
	l32i	a8, a8, 36
	bnez.n	a8, .L3534
.L3537:
	add.n	a2, a7, a6
	movi.n	a12, 0x21
	add.n	a11, a7, a3
	mov.n	a10, a2
	call8	memcpy
	addmi	a13, a2, 0x200
	movi.n	a12, 0x40
	addi.n	a11, a4, 8
	addi	a10, a13, 24
	s32i	a13, sp, 0
	call8	memcpy
	l8ui	a8, a4, 0
	l32r	a12, .LC1417
	addi	a9, a8, -7
	l32i	a13, sp, 0
	nsau	a9, a9
	srli	a9, a9, 5
	add.n	a12, a7, a12
	s8i	a9, a13, 42
	l32i	a13, a12, 0
	movi.n	a10, 0
	addi.n	a14, a13, 1
	s32i	a14, a12, 0
	l32i	a12, sp, 4
	s32i	a13, a2, 36
	s32i	a12, a2, 48
	l32r	a12, .LC1421
	movi.n	a11, 1
	add.n	a12, a7, a12
	l32i	a13, a12, 0
	s32i	a13, a2, 52
	l32r	a13, .LC1416
	add.n	a13, a7, a13
	l8ui	a13, a13, 0
	s8i	a9, a2, 62
	s8i	a13, a2, 56
	mov.n	a9, a10
	addi.n	a13, a8, -1
	moveqz	a9, a11, a13
	s8i	a9, a2, 72
	addi	a9, a8, -9
	moveqz	a10, a11, a9
	l16ui	a9, a4, 2
	s8i	a10, a2, 63
	s16i	a9, a2, 66
	movi.n	a9, -9
	s8i	a11, a2, 58
	and	a8, a8, a9
	beqi	a8, 1, .L3535
	j	.L3607
.L3534:
	movi.n	a8, 1
	xor	a11, a11, a8
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119releaseSimpleMotionERNS_3AppEb
	beqz.n	a10, .L3537
	j	.L3529
.L3535:
	movi.n	a8, 1
	j	.L3538
.L3607:
	s32i	a12, sp, 0
	call8	_Z18esp_timer_get_timev
	l32r	a8, .LC1422
	mov.n	a4, a10
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	mov.n	a2, a11
	beqz.n	a8, .L3535
	l32r	a10, .LC1423
	l32i	a11, sp, 0
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L3535
	mov.n	a12, a4
	mov.n	a13, a2
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118simpleProfileReadyERKNS_3AppEy
	beqz.n	a10, .L3535
	l32r	a8, .LC1424
	l32r	a12, .LC1425
	add.n	a8, a7, a8
	add.n	a12, a7, a12
	j	.L3539
.L3545:
	l8ui	a9, a8, 0
	beqz.n	a9, .L3535
	l8ui	a9, a8, 48
	bnez.n	a9, .L3535
	l32i	a9, a8, 16
	l32i	a11, a8, 12
	bltu	a2, a9, .L3535
	bne	a9, a2, .L3563
	bltu	a4, a11, .L3535
.L3563:
	l32i	a14, a7, 0
	movi	a10, 0x3e8
	mull	a13, a10, a14
	muluh	a10, a10, a14
	or	a14, a13, a10
	beqz.n	a14, .L3541
	sub	a9, a2, a9
	bgeu	a4, a11, .L3543
	addi.n	a9, a9, -1
.L3543:
	sub	a11, a4, a11
	bltu	a9, a10, .L3541
	bne	a10, a9, .L3535
	bgeu	a11, a13, .L3535
.L3541:
	addi	a8, a8, 120
.L3539:
	bne	a8, a12, .L3545
	movi.n	a8, 3
.L3538:
	add.n	a4, a7, a6
	s8i	a8, a4, 57
	l32r	a8, .LC1426
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a4, 600
	l32r	a8, .LC1427
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a4, 604
	call8	_Z18esp_timer_get_timev
	l32r	a8, .LC1430
	add.n	a10, a10, a8
	bgeu	a10, a8, .L3546
	addi.n	a11, a11, 1
.L3546:
	l32r	a8, .LC1429
	add.n	a9, a7, a6
	l32i	a9, a9, 36
	s32i	a10, a4, 608
	s32i	a11, a4, 612
	add.n	a8, a7, a8
	s32i	a9, a8, 0
.L3521:
	movi	a12, 0xa0
	add.n	a11, a7, a6
	mov.n	a10, a5
	call8	memcpy
	movi.n	a12, 0x21
	add.n	a11, a7, a3
	mov.n	a10, a5
	call8	memcpy
.L3512:
	movi.n	a8, 0
	j	.L3514
.L3552:
	movi.n	a8, 8
.L3514:
	mov.n	a2, a8
	retw.n
.LFE2242:
	.size	_ZN12_GLOBAL__N_112simpleMotionEPvmPKN21MotorControlRSExample5Probe19SimpleMotionCommandERNS2_16SimpleMotionViewE, .-_ZN12_GLOBAL__N_112simpleMotionEPvmPKN21MotorControlRSExample5Probe19SimpleMotionCommandERNS2_16SimpleMotionViewE
	.literal_position
	.literal .LC1433, 53807
	.literal .LC1434, 53752
	.literal .LC1435, 65248
	.literal .LC1436, 53800
	.literal .LC1437, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1438, 45697
	.literal .LC1439, 45698
	.literal .LC1440, 757624
	.literal .LC1441, _ZN12_GLOBAL__N_14uartE
	.literal .LC1443, .LC4
	.literal .LC1445, 50000
	.literal .LC1446, 764788
	.literal .LC1447, 764508
	.literal .LC1448, 764504
	.literal .LC1449, 625320
	.literal .LC1450, 772456
	.literal .LC1452, .LC12
	.literal .LC1453, 772492
	.literal .LC1454, 59009
	.literal .LC1455, 200444
	.literal .LC1456, 200464
	.literal .LC1457, 200440
	.literal .LC1458, 200505
	.literal .LC1459, 209484
	.literal .LC1460, 209504
	.literal .LC1461, 209480
	.literal .LC1462, 209545
	.literal .LC1463, 182364
	.literal .LC1464, 182384
	.literal .LC1465, 183705
	.literal .LC1466, 191404
	.literal .LC1467, 191424
	.literal .LC1468, 192745
	.literal .LC1469, 101004
	.literal .LC1471, 101000
	.literal .LC1472, 9040
	.literal .LC1473, -65281
	.literal .LC1474, 16842754
	.literal .LC1475, 757640
	.literal .LC1476, 626264
	.literal .LC1477, 626240
	.literal .LC1479, 45688
	.literal .LC1480, 53772
	.literal .LC1481, 45700
	.literal .LC1482, 53810
	.literal .LC1483, 53801
	.literal .LC1484, 58992
	.literal .LC1485, 757628
	.literal .LC1486, 772592
	.literal .LC1488, 776432
	.literal .LC1489, 813496
	.literal .LC1491, 2500000
	.literal .LC1492, 500000
	.literal .LC1493, 5500000
	.align	4
	.type	_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE, @function
_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE:
.LFB2129:
	entry	sp, 656
.LCFI163:
	l32r	a9, .LC1433
	mov.n	a8, a7
	add.n	a9, a2, a9
	extui	a8, a8, 0, 8
	l8ui	a10, a9, 0
	s32i	a6, sp, 608
	s32i	a3, sp, 604
	s32i	a4, sp, 560
	s32i	a8, sp, 576
	mov.n	a7, a2
	movi.n	a6, 0
	beqz.n	a10, .L3610
	l8ui	a9, a5, 0
	bnei	a9, 3, .L3610
	l32r	a9, .LC1434
	add.n	a9, a2, a9
	l8ui	a6, a9, 0
	sub	a6, a6, a4
	nsau	a6, a6
	srli	a6, a6, 5
.L3610:
	l32r	a9, .LC1435
	add.n	a11, a7, a9
	l32i	a8, a11, 152
	s32i	a8, sp, 584
	l32i	a8, a11, 156
	s32i	a8, sp, 588
	l32i	a11, sp, 588
	l32i	a8, sp, 584
	or	a11, a8, a11
	bnez.n	a11, .L3611
	beqz.n	a10, .L3612
	bnez.n	a6, .L3613
	j	.L3611
.L3612:
	beqz.n	a6, .L3614
.L3613:
	l32r	a10, .LC1436
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqi	a10, 4, .L3615
.L3614:
	l32r	a10, .LC1437
	l8ui	a8, a10, 0
	s32i	a8, sp, 580
	beqz.n	a8, .L3616
	l32r	a10, .LC1438
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L3617
.L3615:
	movi.n	a2, 2
	j	.L3768
.L3617:
	l32r	a10, .LC1439
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L3615
	add.n	a9, a7, a9
	l8ui	a8, a9, 137
	s32i	a8, sp, 596
	bnez.n	a8, .L3615
	l32r	a9, .LC1440
	movi.n	a2, 7
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L3768
	l32r	a10, .LC1441
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l8ui	a8, a5, 0
	s32i	a10, sp, 568
	s32i	a8, sp, 572
	l32i	a8, sp, 660
	s32i	a11, sp, 564
	beqz.n	a8, .L3619
	l32i	a8, sp, 572
	beqi	a8, 1, .L3620
.L3621:
	movi.n	a2, 0xf
	j	.L3768
.L3620:
	l32i	a11, sp, 656
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_121failedTransmittedStopERNS_3AppEm
	beqz.n	a10, .L3621
	l32i	a12, sp, 568
	l32i	a13, sp, 564
	l32i	a11, sp, 660
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_117releaseFactsValidERKNS_3AppERKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesEy
	bnez.n	a10, .L3622
	j	.L3621
.L3619:
	l32i	a8, sp, 576
	beqz.n	a8, .L3623
	l32i	a8, sp, 572
	bnei	a8, 3, .L3624
	bnez.n	a6, .L3624
	l32i	a11, sp, 560
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	bnez.n	a10, .L3625
	j	.L3624
.L3623:
	l32i	a8, sp, 572
	beqi	a8, 3, .L3625
.L3701:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	beqz.n	a10, .L3625
.L3611:
	movi.n	a2, 1
	j	.L3768
.L3625:
	movi	a10, 0x1d8
	movi.n	a12, 0x18
	mov.n	a11, a5
	add.n	a10, sp, a10
	call8	memcpy
	l32i	a8, sp, 572
	l32i	a2, sp, 584
	l32i	a10, sp, 588
	bnei	a8, 3, .L3626
	l32r	a2, .LC1491
	movi.n	a10, 0
.L3626:
	l32r	a11, .LC1492
	l32i	a8, sp, 568
	l32i	a3, sp, 564
	add.n	a9, a8, a11
	bgeu	a9, a11, .L3627
	addi.n	a3, a3, 1
.L3627:
	add.n	a2, a9, a2
	add.n	a3, a3, a10
	bgeu	a2, a9, .L3628
	addi.n	a3, a3, 1
.L3628:
	l32r	a10, .LC1443
	addi	a9, sp, 16
	l32i	a13, a10, 0
	addmi	a9, a9, 0x200
	addi.n	a11, a9, 4
	l32i	a12, a10, 4
	s32i	a13, a9, 4
	l32i	a9, a10, 8
	l32i	a8, sp, 572
	s32i	a12, a11, 4
	s32i	a9, a11, 8
	bnei	a8, 3, .L3629
	l8ui	a9, a5, 1
	bnei	a9, 1, .L3630
	l32r	a9, .LC1493
	l32i	a8, sp, 568
	l32i	a3, sp, 564
	add.n	a2, a8, a9
	bgeu	a2, a9, .L3631
	addi.n	a3, a3, 1
.L3631:
	l32r	a10, .LC1445
	addi	a9, sp, 16
	s32i	a10, sp, 532
	addmi	a9, a9, 0x200
	movi.n	a10, 0x40
	s8i	a10, a9, 8
	j	.L3630
.L3629:
	l32i	a8, sp, 572
	bnei	a8, 4, .L3630
	l32i	a9, a5, 8
	l32i	a10, a5, 12
	or	a9, a9, a10
	beqz.n	a9, .L3632
.L3645:
	movi.n	a2, 0xb
	j	.L3768
.L3632:
	l32r	a9, .LC1446
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L3621
	l32r	a9, .LC1447
	l32i	a8, sp, 560
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a8, .L3616
	l32i	a9, a7, 0
	movi	a15, 0x3e8
	mull	a4, a15, a9
	muluh	a15, a15, a9
	l32r	a9, .LC1449
	l32r	a11, .LC1448
	add.n	a9, a7, a9
	l32i	a12, sp, 568
	l32i	a13, sp, 564
	mov.n	a14, a4
	add.n	a11, a7, a11
	mov.n	a10, a9
	s32i	a15, sp, 600
	s32i	a9, sp, 592
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L3616
	l32i	a9, sp, 592
	l8ui	a10, a9, 34
	bnez.n	a10, .L3616
	l8ui	a10, a9, 36
	bnez.n	a10, .L3616
	l16ui	a10, a9, 22
	bnez.n	a10, .L3616
	l8ui	a9, a9, 35
	bnez.n	a9, .L3616
	l32i	a15, sp, 600
	movi.n	a10, -1
	or	a11, a4, a15
	movi.n	a9, -1
	beqz.n	a11, .L3636
	l32r	a9, .LC1449
	movi.n	a11, -1
	add.n	a9, a7, a9
	l32i	a10, a9, 240
	l32i	a9, a9, 244
	movi.n	a12, -1
	xor	a11, a9, a11
	xor	a12, a10, a12
	bltu	a11, a15, .L3707
	bne	a15, a11, .L3712
	bltu	a12, a4, .L3707
.L3712:
	add.n	a10, a10, a4
	add.n	a9, a9, a15
	bgeu	a10, a4, .L3636
	addi.n	a9, a9, 1
	j	.L3636
.L3707:
	movi.n	a10, -1
	movi.n	a9, -1
.L3636:
	l32i	a8, sp, 564
	bltu	a8, a9, .L3713
	bne	a9, a8, .L3616
	l32i	a8, sp, 568
	bgeu	a8, a10, .L3616
.L3713:
	bltu	a9, a3, .L3642
	bne	a3, a9, .L3641
	bgeu	a10, a2, .L3641
.L3642:
	mov.n	a2, a10
	mov.n	a3, a9
.L3641:
	movi	a9, 0x1d8
	add.n	a9, sp, a9
	movi.n	a10, 1
	s8i	a10, a9, 16
.L3630:
	l32r	a10, .LC1450
	movi	a9, 0x1f8
	addi	a8, sp, 16
	add.n	a10, a7, a10
	add.n	a4, a8, a9
	l32i	a10, a10, 0
	l32i	a8, sp, 560
	s32i	a10, a4, 8
	s32i	a8, a4, 0
	s8i	a8, a4, 4
	movi	a12, 0x188
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi.n	a10, 0x10
	addmi	a10, a10, 0x2700
	s32i	a10, sp, 56
	movi.n	a10, 0x14
	s8i	a10, sp, 60
	l32r	a10, .LC1452
	addi	a8, sp, 16
	s32i	a10, sp, 204
	s32i	a10, sp, 292
	s32i	a10, sp, 380
	s32i	a10, sp, 400
	movi	a11, 0x204
	l32r	a10, .LC1440
	add.n	a11, a8, a11
	s32i	a11, sp, 8
	add.n	a10, a7, a10
	s32i	a2, sp, 0
	s32i	a3, sp, 4
	l32i	a12, a10, 0
	l32i	a14, sp, 568
	l32i	a15, sp, 564
	movi	a13, 0x1c8
	add.n	a13, a8, a13
	mov.n	a10, a8
	mov.n	a11, a4
	call8	_ZN14MotorControlRS6ESS_RS13prepareActionERNS0_13ActionContextERKNS_10ReadTargetEmRKNS_13ActionRequestEyyRKNS_13ActionOptionsE
	movi	a9, 0x1ec
	addi	a8, sp, 16
	add.n	a9, a8, a9
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	s32i	a12, a9, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3644
	beqi	a10, 3, .L3645
.L3624:
	movi.n	a2, 8
	j	.L3768
.L3644:
	l32i	a8, sp, 572
	movi.n	a11, 1
	addi	a9, a8, -3
	moveqz	a10, a11, a9
	l32r	a9, .LC1435
	s32i	a10, sp, 600
	add.n	a8, a7, a9
	mov.n	a10, a8
	s32i	a8, sp, 592
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	beqz.n	a10, .L3646
.L3648:
	l32i	a8, sp, 572
	bnei	a8, 3, .L3615
	beqz.n	a6, .L3647
	j	.L3615
.L3646:
	l32r	a10, .LC1441
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3648
	l32i	a8, sp, 600
	movi.n	a9, 1
	xor	a9, a6, a9
	and	a9, a8, a9
	movi.n	a8, 0
	s32i	a8, sp, 580
	beqz.n	a9, .L3649
.L3647:
	l32r	a9, .LC1447
	l32i	a8, sp, 560
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	sub	a9, a9, a8
	nsau	a9, a9
	l32i	a8, sp, 576
	srli	a9, a9, 5
	or	a9, a8, a9
.L3649:
	l32i	a8, sp, 560
	l32r	a11, .LC1453
	srli	a10, a8, 3
	add.n	a10, a7, a10
	add.n	a10, a10, a11
	l8ui	a11, a10, 0
	extui	a10, a8, 0, 3
	bbs	a11, a10, .L3650
	bnez.n	a9, .L3650
	beqz.n	a6, .L3616
	l32r	a9, .LC1454
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L3616
.L3650:
	l32i	a8, sp, 572
	beqi	a8, 3, .L3651
	l32i	a8, sp, 660
	l32i	a11, sp, 560
	nsau	a12, a8
	srli	a12, a12, 5
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a2, 0xc
	beqz.n	a10, .L3801
	j	.L3768
.L3651:
	l32i	a8, sp, 576
	movi.n	a12, 0x1e
	movi.n	a11, 0xd
	bnez.n	a8, .L3804
.L3653:
	l32r	a9, .LC1455
	l8ui	a5, a5, 1
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L3655
	l32r	a9, .LC1456
	l32i	a8, sp, 560
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a8, .L3655
	l32r	a11, .LC1457
	mov.n	a10, a7
	add.n	a11, a7, a11
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L3662
	l32r	a9, .LC1458
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L3662
.L3655:
	l32r	a9, .LC1459
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	bnez.n	a9, .L3657
.L3660:
	movi.n	a12, 2
	movi.n	a11, 9
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119availableStopRecordERNS_3AppEjj
	mov.n	a4, a10
	bnez.n	a10, .L3658
	j	.L3802
.L3657:
	l32r	a9, .LC1460
	l32i	a8, sp, 560
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a8, .L3660
	l32r	a11, .LC1461
	mov.n	a10, a7
	add.n	a11, a7, a11
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L3662
	l32r	a9, .LC1462
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L3660
	j	.L3662
.L3802:
	bnei	a5, 2, .L3662
	l32r	a9, .LC1463
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L3663
	l32r	a9, .LC1464
	l32i	a8, sp, 560
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a8, .L3663
	l32r	a9, .LC1465
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	beqi	a9, 1, .L3664
.L3663:
	l32r	a9, .LC1466
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L3662
	l32r	a9, .LC1467
	l32i	a8, sp, 560
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bne	a9, a8, .L3662
	l32r	a9, .LC1468
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bnei	a9, 1, .L3662
.L3664:
	movi.n	a12, 2
	movi.n	a11, 0xb
.L3804:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119availableStopRecordERNS_3AppEjj
	mov.n	a4, a10
	j	.L3654
.L3801:
	l32r	a10, .LC1469
	l32r	a12, .LC1472
	add.n	a10, a7, a10
	movi.n	a9, 0
	movi.n	a11, 8
	loop	a11, .L3667_LEND
.L3667:
	l32i	a13, a10, 0
	bnez.n	a13, .L3666
	l32r	a10, .LC1472
	mul16u	a9, a9, a10
	l32r	a10, .LC1471
	add.n	a9, a9, a10
	add.n	a4, a7, a9
	j	.L3658
.L3666:
	addi.n	a9, a9, 1
	add.n	a10, a10, a12
	.L3667_LEND:
	j	.L3662
.L3654:
	beqz.n	a10, .L3662
.L3658:
	addi	a5, sp, 16
	addmi	a3, a5, 0x100
	movi	a14, 0x88
	add.n	a10, a3, a14
	movi.n	a12, 0x40
	movi.n	a11, 0
	call8	memset
	mov.n	a14, a10
	l32i	a12, sp, 568
	movi.n	a10, 2
	l32i	a13, sp, 564
	s8i	a10, a3, 136
	mov.n	a10, a5
	call8	_ZN14MotorControlRS6ESS_RS10nextActionERKNS0_13ActionContextEyRNS0_14PreparedActionE
	movi	a13, 0x1e0
	add.n	a13, a5, a13
	s32i	a11, a13, 4
	l8ui	a11, a3, 136
	s32i	a10, a13, 0
	or	a2, a10, a11
	s32i	a12, a13, 8
	extui	a2, a2, 0, 8
	beqz.n	a2, .L3669
.L3675:
	movi.n	a2, 4
	j	.L3768
.L3669:
	l32i	a3, a4, 4
	addmi	a10, a4, 0x500
	bnez.n	a3, .L3670
	movi	a12, 0x184
	mov.n	a11, a5
	addi	a10, a10, 48
	call8	memcpy
	j	.L3671
.L3670:
	l32r	a11, .LC1473
	l32i	a10, a10, 100
	and	a10, a10, a11
	l32r	a11, .LC1474
	sub	a10, a10, a11
	movi.n	a11, 1
	moveqz	a11, a2, a10
	s32i	a11, sp, 596
.L3671:
	bnez.n	a6, .L3672
	l32i	a8, sp, 580
	bnez.n	a8, .L3672
	l32i	a14, sp, 568
	l32i	a15, sp, 564
	movi	a12, 0x198
	add.n	a12, sp, a12
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115admitActionStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedActionEy
	mov.n	a5, a10
	beqz.n	a10, .L3673
	bnez.n	a3, .L3674
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
.L3674:
	movi	a8, 0xfd
	and	a8, a5, a8
	beqi	a8, 4, .L3662
	movi.n	a2, 5
	beqi	a5, 3, .L3768
	j	.L3675
.L3662:
	movi.n	a2, 6
	j	.L3768
.L3698:
	l32i	a8, a4, 40
	l32i	a12, a4, 32
	s32i	a8, sp, 584
	l32i	a8, a4, 44
	l32i	a5, a4, 36
	s32i	a8, sp, 588
	j	.L3699
.L3711:
	movi.n	a5, 0
	movi.n	a12, 0
.L3699:
	l32i	a8, sp, 596
	beqz.n	a8, .L3676
	l32r	a10, .LC1475
	add.n	a10, a7, a10
	l32i	a11, a10, 0
	l32i	a13, a10, 4
	addi.n	a11, a11, 1
	bnez.n	a11, .L3677
	addi.n	a13, a13, 1
.L3677:
	s32i	a11, a10, 0
	s32i	a13, a10, 4
.L3676:
	mov.n	a10, a4
	s32i	a12, sp, 596
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	l32i	a8, sp, 584
	l32i	a12, sp, 596
	s32i	a8, a4, 40
	l32i	a8, sp, 588
	addmi	a10, a4, 0x500
	s32i	a12, a4, 32
	s32i	a5, a4, 36
	s32i	a8, a4, 44
	movi	a12, 0x184
	addi	a11, sp, 16
	addi	a10, a10, 48
	call8	memcpy
.L3700:
	l32i	a8, sp, 580
	addmi	a10, a4, 0x300
	s8i	a8, a10, 13
	beqz.n	a8, .L3678
	l32r	a10, .LC1435
	add.n	a10, a7, a10
	l8ui	a10, a10, 60
	bnei	a10, 1, .L3678
	l32r	a10, .LC1476
	add.n	a10, a7, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a4, 788
	s32i	a10, a4, 784
	l32r	a10, .LC1477
	add.n	a10, a7, a10
	l32i	a10, a10, 0
	s32i	a10, a4, 792
.L3678:
	l32i	a8, sp, 576
	movi.n	a10, 1
	xor	a10, a8, a10
	l32i	a8, sp, 600
	and	a10, a8, a10
	beqz.n	a10, .L3679
	l32r	a10, .LC1457
	add.n	a10, a7, a10
	saltu	a10, a4, a10
	addi.n	a10, a10, -1
	neg	a10, a10
	extui	a10, a10, 0, 8
.L3679:
	addmi	a11, a4, 0x600
	l32i	a8, sp, 660
	s8i	a10, a11, 185
	s32i	a3, a11, 188
	beqz.n	a8, .L3680
	l32i	a8, sp, 656
	movi	a10, 0x6c8
	s32i	a8, a11, 192
	l32i	a11, sp, 660
	movi.n	a12, 0x1a
	add.n	a10, a4, a10
	call8	memcpy
.L3680:
	l32i	a8, sp, 576
	addmi	a10, a4, 0x2300
	movi	a11, 0x69
	s8i	a8, a10, 57
	slli	a11, a11, 9
	bnez.n	a6, .L3805
.L3681:
	l32r	a11, .LC1479
.L3805:
	add.n	a11, a7, a11
	movi.n	a12, 5
	addi.n	a10, a4, 12
	call8	memcpy
	l32r	a10, .LC1480
	bnez.n	a6, .L3806
.L3683:
	l32r	a10, .LC1481
.L3806:
	add.n	a10, a7, a10
	l32i	a10, a10, 0
	l32i	a8, sp, 604
	s32i	a10, a4, 20
	l32r	a10, .LC1440
	add.n	a10, a7, a10
	l32i	a11, a10, 0
	addi.n	a12, a11, 1
	s32i	a12, a10, 0
	s32i	a8, a4, 8
	l32i	a8, sp, 560
	s32i	a11, a4, 4
	s8i	a8, a4, 24
	l32i	a10, sp, 80
	l32i	a11, sp, 84
	s32i	a10, a4, 56
	movi.n	a10, 3
	s32i	a11, a4, 60
	s8i	a10, a4, 0
	movi.n	a11, 1
	addmi	a10, a4, 0x300
	s8i	a11, a10, 8
	beqz.n	a6, .L3686
	s8i	a11, a10, 12
	l32r	a10, .LC1482
	add.n	a10, a7, a10
	s8i	a11, a10, 0
	l32r	a10, .LC1483
	movi.n	a11, 8
	add.n	a10, a7, a10
	s8i	a11, a10, 0
	l32r	a11, .LC1484
	add.n	a11, a7, a11
	l32i	a10, a11, 0
	beqz.n	a10, .L3686
	l32i	a12, sp, 568
	l32i	a13, sp, 564
	l32i	a10, sp, 592
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L3686:
	l32r	a10, .LC1485
	l32i	a11, a4, 4
	l32i	a8, sp, 608
	add.n	a10, a7, a10
	s32i	a11, a10, 0
	s32i	a11, a8, 0
	l32i	a8, sp, 572
	bnei	a8, 3, .L3768
	l32i	a12, sp, 568
	l32i	a13, sp, 564
	l32i	a11, sp, 560
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_123cancelSimplePreparationERNS_3AppEhy
	addi	a5, sp, 16
	l32i	a8, sp, 560
	addmi	a10, a5, 0x200
	s8i	a8, a10, 24
	movi	a11, 0x218
	movi	a10, 0x1e0
	add.n	a10, a5, a10
	add.n	a11, a5, a11
	s32i	a11, a10, 0
	movi	a11, 0x210
	l32i	a8, sp, 568
	add.n	a11, a5, a11
	s32i	a11, a10, 8
	l32r	a11, .LC1486
	s32i	a8, sp, 544
	l32i	a8, sp, 564
	s32i	a7, a10, 4
	add.n	a11, a7, a11
	s32i	a8, sp, 548
	call8	_ZZN12_GLOBAL__N_120cancelPositionStagesERNS_3AppEhyENKUlRNS0_12StageSessionEE_clES3_
	l32r	a3, .LC1489
	movi.n	a6, 0
	add.n	a3, a7, a3
	j	.L3689
.L3690:
	movi.n	a11, 0x48
	addmi	a11, a11, 0xa00
	l32r	a10, .LC1488
	mul16u	a11, a6, a11
	addi.n	a6, a6, 1
	add.n	a11, a11, a10
	movi	a10, 0x1e0
	add.n	a11, a7, a11
	add.n	a10, a5, a10
	call8	_ZZN12_GLOBAL__N_120cancelPositionStagesERNS_3AppEhyENKUlRNS0_12StageSessionEE_clES3_
	extui	a6, a6, 0, 8
.L3689:
	l8ui	a10, a3, 0
	bltu	a6, a10, .L3690
	l32r	a14, .LC1471
	l32r	a5, .LC1449
	movi	a6, 0x1f0
	add.n	a3, a7, a14
	add.n	a5, a7, a5
	add.n	a6, sp, a6
	j	.L3691
.L3696:
	beq	a3, a4, .L3693
	l8ui	a10, a3, 0
	addi	a10, a10, -3
	extui	a10, a10, 0, 8
	bgeui	a10, 5, .L3693
	l8ui	a10, a3, 24
	l32i	a8, sp, 560
	bne	a10, a8, .L3693
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L3693
	movi.n	a10, 1
	s8i	a10, a3, 71
	l8ui	a10, a3, 0
	bnei	a10, 7, .L3695
	movi	a8, 0x60
	addmi	a8, a8, 0x1f00
	add.n	a10, a3, a8
	call8	_ZN14MotorControlRS6ESS_RS10revokeHomeERNS0_11HomeContextE
	s32i	a10, a6, 0
	s32i	a11, a6, 4
	s32i	a12, a6, 8
.L3695:
	movi	a10, 0x30a
	add.n	a10, a3, a10
	movi.n	a11, 1
	s8i	a11, a10, 0
	l32i	a10, a3, 32
	beqz.n	a10, .L3693
	l32i	a12, sp, 568
	l32i	a13, sp, 564
	l32i	a10, sp, 592
	addi	a11, a3, 32
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L3693:
	l32r	a10, .LC1472
	add.n	a3, a3, a10
.L3691:
	bne	a3, a5, .L3696
	j	.L3768
.L3616:
	movi.n	a2, 3
	j	.L3768
.L3673:
	bnez.n	a3, .L3698
	addmi	a10, a4, 0x300
	s8i	a3, a10, 13
	j	.L3678
.L3672:
	beqz.n	a3, .L3700
	j	.L3711
.L3622:
	l32i	a8, sp, 576
	beqz.n	a8, .L3701
	j	.L3624
.L3768:
	retw.n
.LFE2129:
	.size	_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE, .-_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	.align	4
	.type	_ZN12_GLOBAL__N_121startReleaseAfterStopEPvmmRm, @function
_ZN12_GLOBAL__N_121startReleaseAfterStopEPvmmRm:
.LFB2135:
	entry	sp, 112
.LCFI164:
	addi	a6, sp, 16
	movi.n	a12, 0x20
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	mov.n	a10, a2
	mov.n	a12, a6
	mov.n	a11, a4
	call8	_ZN12_GLOBAL__N_114inspectReleaseERNS_3AppEmRN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	mov.n	a7, a2
	mov.n	a2, a10
	bnez.n	a10, .L3809
	movi	a8, 0x101
	movi.n	a12, 0x18
	movi.n	a11, 0
	addi	a10, sp, 48
	s16i	a8, sp, 40
	call8	memset
	l8ui	a12, sp, 20
	movi.n	a8, 1
	s32i	a6, sp, 4
	s32i	a4, sp, 0
	movi.n	a15, 0
	mov.n	a14, a5
	addi	a13, sp, 48
	mov.n	a11, a3
	mov.n	a10, a7
	s8i	a8, sp, 48
	call8	_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	mov.n	a2, a10
.L3809:
	retw.n
.LFE2135:
	.size	_ZN12_GLOBAL__N_121startReleaseAfterStopEPvmmRm, .-_ZN12_GLOBAL__N_121startReleaseAfterStopEPvmmRm
	.align	4
	.type	_ZN12_GLOBAL__N_111startActionEPvmhRKN14MotorControlRS13ActionRequestERm, @function
_ZN12_GLOBAL__N_111startActionEPvmhRKN14MotorControlRS13ActionRequestERm:
.LFB2133:
	entry	sp, 48
.LCFI165:
	movi.n	a8, 0
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a13, a5
	mov.n	a14, a6
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	movi.n	a15, 0
	extui	a12, a4, 0, 8
	call8	_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	mov.n	a2, a10
	retw.n
.LFE2133:
	.size	_ZN12_GLOBAL__N_111startActionEPvmhRKN14MotorControlRS13ActionRequestERm, .-_ZN12_GLOBAL__N_111startActionEPvmhRKN14MotorControlRS13ActionRequestERm
	.literal_position
	.literal .LC1494, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1496, 53807
	.literal .LC1498, 45697
	.literal .LC1499, 45698
	.literal .LC1500, _ZN12_GLOBAL__N_14uartE
	.literal .LC1501, 757624
	.literal .LC1502, 45700
	.literal .LC1503, _ZN12_GLOBAL__N_122writeResponseConfirmedE
	.literal .LC1505, 101004
	.literal .LC1507, 101000
	.literal .LC1509, 102776
	.literal .LC1510, 9040
	.literal .LC1511, 101008
	.literal .LC1512, 101024
	.literal .LC1513, 101020
	.literal .LC1515, 104076
	.literal .LC1516, 101776
	.literal .LC1518, 104068
	.literal .LC1520, 757628
	.literal .LC1521, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_122admitPositionInterruptERNS_3AppEmmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm, @function
_ZN12_GLOBAL__N_122admitPositionInterruptERNS_3AppEmmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm:
.LFB2147:
	entry	sp, 208
.LCFI166:
	mov.n	a8, a7
	extui	a8, a8, 0, 8
	s32i	a8, sp, 168
	l32r	a8, .LC1494
	s32i	a3, sp, 164
	l8ui	a8, a8, 0
	s32i	a4, sp, 160
	mov.n	a7, a2
	beqz.n	a8, .L3813
	movi	a4, 0x7f7
	slli	a4, a4, 5
	add.n	a4, a2, a4
	l32i	a8, a4, 152
	l32i	a9, a4, 156
	or	a8, a8, a9
	bnez.n	a8, .L3814
	l32r	a8, .LC1496
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3814
	movi	a8, 0x165
	slli	a8, a8, 7
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3815
.L3817:
	movi.n	a14, 2
	j	.L3816
.L3815:
	l32r	a8, .LC1498
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3817
	l32r	a8, .LC1499
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3817
	l8ui	a8, a4, 137
	bnez.n	a8, .L3817
	mov.n	a10, a4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L3817
	l32r	a10, .LC1500
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3817
	l32r	a8, .LC1501
	movi.n	a14, 7
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L3816
	l32i	a11, sp, 160
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a3, a10
	beqz.n	a10, .L3818
	l8ui	a9, a10, 0
	bnei	a9, 4, .L3818
	l8ui	a9, a10, 69
	bnez.n	a9, .L3818
	addmi	a9, a10, 0x2300
	l8ui	a9, a9, 57
	bnez.n	a9, .L3818
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	beqz.n	a10, .L3819
.L3814:
	movi.n	a14, 1
	j	.L3816
.L3819:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	movi.n	a14, 9
	bnez.n	a10, .L3816
	l8ui	a9, a3, 71
	bnez.n	a9, .L3814
	addmi	a9, a3, 0xb00
	l32i	a2, a9, 248
	bnez.n	a2, .L3814
	l8ui	a11, a3, 24
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111pendingStopERKNS_3AppEh
	bnez.n	a10, .L3814
	movi	a9, 0x6f0
	add.n	a9, a3, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L3821
.L3813:
	movi.n	a14, 3
	j	.L3816
.L3821:
	movi	a9, 0x6f0
	add.n	a9, a3, a9
	addmi	a10, a9, 0x100
	l8ui	a11, a10, 239
	bnei	a11, 1, .L3813
	addmi	a11, a9, 0x200
	l8ui	a12, a11, 136
	l8ui	a11, a11, 138
	s32i	a9, sp, 152
	bgeu	a11, a12, .L3813
	l8ui	a10, a10, 242
	bnez.n	a10, .L3813
	addmi	a10, a3, 0x300
	l8ui	a10, a10, 8
	beqz.n	a10, .L3813
	l32r	a10, .LC1502
	l32i	a11, a3, 20
	add.n	a10, a7, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L3813
	l32r	a10, .LC1503
	l8ui	a10, a10, 0
	beqz.n	a10, .L3813
	l32r	a10, .LC1500
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	s32i	a11, sp, 144
	mov.n	a13, a11
	movi.n	a11, 0x2f
	slli	a11, a11, 6
	s32i	a10, sp, 148
	mov.n	a12, a10
	add.n	a11, a3, a11
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_121storedPositionCurrentERKNS_3AppERKN14MotorControlRS6ESS_RS27StoredPositionQualificationEy
	beqz.n	a10, .L3813
	l16ui	a11, a5, 36
	movi	a10, 0x102
	bne	a11, a10, .L3818
	l32i	a9, sp, 152
	l16ui	a11, a5, 16
	l16ui	a10, a9, 168
	bne	a11, a10, .L3818
	l32i	a10, a5, 20
	l32i	a9, a9, 172
	bne	a10, a9, .L3818
	movi	a9, 0x6f0
	add.n	a9, a3, a9
	l16ui	a10, a5, 24
	l16ui	a9, a9, 176
	bne	a10, a9, .L3818
	l32r	a9, .LC1505
	l32r	a11, .LC1510
	add.n	a9, a7, a9
	movi.n	a10, 8
	loop	a10, .L3827_LEND
.L3827:
	l32i	a12, a9, 0
	bnez.n	a12, .L3823
	l32r	a9, .LC1510
	l32r	a10, .LC1507
	mul16u	a9, a2, a9
	mov.n	a11, a5
	add.n	a10, a9, a10
	add.n	a8, a7, a10
	movi	a12, 0x68
	addi	a10, sp, 16
	s32i	a9, sp, 172
	s32i	a8, sp, 156
	call8	memcpy
	movi	a10, 0xc0
	addmi	a11, a3, 0xb00
	add.n	a11, a11, a10
	movi.n	a12, 0x38
	addi	a10, sp, 64
	call8	memcpy
	l32i	a8, sp, 144
	l32r	a10, .LC1521
	s32i	a8, sp, 152
	l32i	a8, sp, 148
	l32i	a9, sp, 172
	add.n	a5, a8, a10
	bgeu	a5, a10, .L3824
	l32i	a8, sp, 144
	addi.n	a8, a8, 1
	s32i	a8, sp, 152
.L3824:
	l32r	a10, .LC1509
	l32i	a8, sp, 168
	add.n	a11, a9, a10
	l32r	a9, .LC1501
	add.n	a11, a7, a11
	add.n	a9, a7, a9
	l32i	a12, a9, 0
	bnez.n	a8, .L3825
	j	.L3853
.L3823:
	addi.n	a2, a2, 1
	add.n	a9, a9, a11
	.L3827_LEND:
	movi.n	a14, 6
	j	.L3816
.L3825:
	l32i	a8, sp, 152
	l32i	a14, sp, 148
	l32i	a15, sp, 144
	s32i	a5, sp, 0
	s32i	a8, sp, 4
	mov.n	a13, a6
	addi	a10, sp, 16
	call8	_ZNK14MotorControlRS6ESS_RS15PositionCommand15prepareRelativeERNS0_11MoveContextEmmyy
	j	.L3855
.L3853:
	l32i	a8, sp, 152
	l32i	a14, sp, 148
	l32i	a15, sp, 144
	s32i	a5, sp, 0
	s32i	a8, sp, 4
	mov.n	a13, a6
	addi	a10, sp, 16
	call8	_ZNK14MotorControlRS6ESS_RS15PositionCommand15prepareAbsoluteERNS0_11MoveContextEmmyy
.L3855:
	s32i	a10, sp, 120
	l8ui	a14, sp, 120
	s32i	a11, sp, 124
	s32i	a12, sp, 128
	beqz.n	a14, .L3829
	l32i	a10, sp, 156
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
.L3818:
	movi.n	a14, 8
	j	.L3816
.L3829:
	l32r	a8, .LC1510
	l32r	a10, .LC1507
	mull	a9, a2, a8
	movi.n	a11, 4
	add.n	a9, a7, a9
	add.n	a10, a9, a10
	s8i	a11, a10, 0
	l32r	a10, .LC1501
	l32r	a6, .LC1505
	add.n	a10, a7, a10
	l32i	a13, a10, 0
	l32i	a8, sp, 164
	addi.n	a11, a13, 1
	s32i	a11, a10, 0
	add.n	a10, a9, a6
	s32i	a13, a10, 0
	l32r	a10, .LC1511
	movi.n	a12, 5
	add.n	a10, a9, a10
	s32i	a8, a10, 0
	l32r	a10, .LC1512
	l8ui	a11, a3, 24
	l32i	a8, sp, 156
	add.n	a10, a9, a10
	s8i	a11, a10, 0
	addi.n	a11, a3, 12
	addi.n	a10, a8, 12
	s32i	a14, sp, 172
	s32i	a13, sp, 168
	s32i	a9, sp, 164
	call8	memcpy
	l32i	a9, sp, 164
	l32r	a10, .LC1513
	l32i	a11, a3, 20
	add.n	a10, a9, a10
	s32i	a11, a10, 0
	movi	a10, 0x62b
	l32i	a8, sp, 152
	slli	a10, a10, 6
	add.n	a10, a9, a10
	s32i	a5, a10, 0
	s32i	a8, a10, 4
	l32r	a10, .LC1515
	movi.n	a5, 1
	add.n	a10, a9, a10
	s8i	a5, a10, 0
	l32r	a10, .LC1516
	l32i	a8, sp, 160
	add.n	a10, a9, a10
	s8i	a5, a10, 0
	movi	a10, 0x32d
	slli	a10, a10, 7
	add.n	a10, a9, a10
	s32i	a8, a10, 0
	l32r	a10, .LC1518
	l32i	a13, sp, 168
	add.n	a9, a9, a10
	l32i	a8, sp, 156
	movi.n	a10, -8
	addmi	a10, a10, 0xc00
	s32i	a13, a9, 0
	add.n	a11, a8, a10
	movi.n	a12, 9
	add.n	a10, a3, a10
	call8	memcpy
	l32i	a9, a3, 32
	s8i	a5, a3, 71
	l32i	a14, sp, 172
	beqz.n	a9, .L3830
	l32i	a12, sp, 148
	l32i	a13, sp, 144
	addi	a11, a3, 32
	mov.n	a10, a4
	s32i	a14, sp, 152
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
	l32i	a14, sp, 152
.L3830:
	l32r	a8, .LC1510
	l32r	a9, .LC1520
	mull	a2, a2, a8
	add.n	a2, a7, a2
	add.n	a2, a2, a6
	l32i	a8, a2, 0
	add.n	a7, a7, a9
	l32i	a9, sp, 208
	s32i	a8, a7, 0
	s32i	a8, a9, 0
.L3816:
	mov.n	a2, a14
	retw.n
.LFE2147:
	.size	_ZN12_GLOBAL__N_122admitPositionInterruptERNS_3AppEmmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm, .-_ZN12_GLOBAL__N_122admitPositionInterruptERNS_3AppEmmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm
	.align	4
	.type	_ZN12_GLOBAL__N_122startPositionInterruptEPvmmRm, @function
_ZN12_GLOBAL__N_122startPositionInterruptEPvmmRm:
.LFB2148:
	entry	sp, 160
.LCFI167:
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a6, a10
	movi.n	a10, 8
	beqz.n	a6, .L3857
	l8ui	a8, a6, 0
	bnei	a8, 4, .L3857
	movi.n	a12, 0x5a
	movi.n	a11, 0
	addi	a10, sp, 30
	call8	memset
	movi.n	a8, 1
	addmi	a7, a6, 0xb00
	s8i	a8, sp, 100
	movi	a8, 0xc0
	add.n	a8, a7, a8
	l32i	a10, a8, 0
	l32i	a9, a8, 4
	l32i	a8, a8, 8
	movi	a11, 0x798
	s32i	a8, sp, 24
	l32i	a8, a7, 204
	s32i	a10, sp, 16
	s32i	a8, sp, 56
	l16ui	a8, a7, 212
	movi.n	a12, 0xa
	s16i	a8, sp, 28
	l16ui	a8, a7, 214
	add.n	a11, a6, a11
	addi	a10, sp, 32
	s16i	a8, sp, 44
	s32i	a9, sp, 20
	call8	memcpy
	l16ui	a8, a7, 218
	l8ui	a15, a7, 228
	s16i	a8, sp, 46
	l32i	a8, a7, 220
	s32i	a5, sp, 0
	l32i	a14, a7, 224
	s32i	a8, sp, 48
	addi	a13, sp, 16
	movi	a8, 0x102
	mov.n	a12, a4
	mov.n	a11, a3
	mov.n	a10, a2
	s16i	a8, sp, 52
	call8	_ZN12_GLOBAL__N_122admitPositionInterruptERNS_3AppEmmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm
.L3857:
	mov.n	a2, a10
	retw.n
.LFE2148:
	.size	_ZN12_GLOBAL__N_122startPositionInterruptEPvmmRm, .-_ZN12_GLOBAL__N_122startPositionInterruptEPvmmRm
	.literal_position
	.literal .LC1523, 53807
	.literal .LC1524, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1525, 45697
	.literal .LC1526, 45698
	.literal .LC1527, _ZN12_GLOBAL__N_14uartE
	.literal .LC1528, 757624
	.literal .LC1529, 764508
	.literal .LC1530, 173324
	.literal .LC1531, 173320
	.literal .LC1532, 101004
	.literal .LC1534, 101000
	.literal .LC1535, 9040
	.literal .LC1536, 772456
	.literal .LC1537, 45688
	.literal .LC1538, 757972
	.literal .LC1539, 757960
	.literal .LC1541, 764516
	.literal .LC1542, 762568
	.literal .LC1543, 45700
	.literal .LC1544, 757628
	.literal .LC1545, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_114startTypedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERmb, @function
_ZN12_GLOBAL__N_114startTypedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERmb:
.LFB2087:
	entry	sp, 128
.LCFI168:
	movi	a9, 0x7f7
	slli	a9, a9, 5
	s32i	a6, sp, 76
	add.n	a6, a2, a9
	l32i	a10, a6, 152
	l32i	a11, a6, 156
	extui	a8, a7, 0, 8
	s32i	a4, sp, 64
	s32i	a3, sp, 72
	s32i	a8, sp, 68
	or	a10, a10, a11
	movi.n	a4, 1
	bnez.n	a10, .L3862
	l32r	a10, .LC1523
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L3862
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L3862
	l32r	a10, .LC1524
	movi.n	a4, 3
	l8ui	a10, a10, 0
	beqz.n	a10, .L3862
	l32r	a10, .LC1525
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L3863
.L3865:
	movi.n	a4, 2
	j	.L3862
.L3863:
	l32r	a10, .LC1526
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L3865
	l8ui	a10, a6, 137
	bnez.n	a10, .L3865
	l32r	a4, .LC1527
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a7, a10
	mov.n	a10, a6
	mov.n	a3, a11
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L3865
	mov.n	a10, a4
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3865
	l32r	a9, .LC1528
	movi.n	a4, 7
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L3862
	addi	a10, a5, -3
	extui	a10, a10, 0, 8
	bgeui	a10, 2, .L3866
	l32r	a10, .LC1529
	l32i	a8, sp, 64
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bne	a10, a8, .L3867
.L3866:
	l32i	a8, sp, 68
	beqz.n	a8, .L3868
	l32r	a10, .LC1530
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	bnez.n	a10, .L3869
	l32r	a6, .LC1531
	j	.L3900
.L3868:
	l32r	a10, .LC1532
	l32r	a12, .LC1535
	add.n	a10, a2, a10
	movi.n	a6, 0
	movi.n	a11, 8
	loop	a11, .L3872_LEND
.L3872:
	l32i	a13, a10, 0
	bnez.n	a13, .L3871
	l32r	a10, .LC1535
	mul16u	a6, a6, a10
	l32r	a10, .LC1534
	add.n	a6, a6, a10
.L3900:
	add.n	a6, a2, a6
	j	.L3870
.L3871:
	addi.n	a6, a6, 1
	add.n	a10, a10, a12
	.L3872_LEND:
	j	.L3869
.L3870:
	l32r	a10, .LC1536
	l32i	a8, sp, 64
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a8, sp, 40
	s8i	a8, sp, 44
	l32r	a8, .LC1537
	s32i	a10, sp, 48
	add.n	a10, a2, a8
	s32i	a9, sp, 80
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	s32i	a10, sp, 28
	l32r	a10, .LC1538
	s32i	a11, sp, 32
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a12, sp, 36
	l32i	a9, sp, 80
	movi.n	a4, 0
	beqz.n	a10, .L3873
	l32r	a12, .LC1539
	addi	a11, sp, 40
	add.n	a4, a2, a12
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	movi.n	a11, 0
	l32i	a9, sp, 80
	moveqz	a4, a11, a10
.L3873:
	l32r	a10, .LC1545
	mov.n	a11, a3
	add.n	a13, a7, a10
	bgeu	a13, a10, .L3874
	addi.n	a11, a3, 1
.L3874:
	addi	a10, a6, 80
	bnez.n	a5, .L3875
	addi	a12, sp, 28
	s32i	a12, sp, 8
	s32i	a11, sp, 4
	s32i	a13, sp, 0
	mov.n	a14, a7
	mov.n	a15, a3
	mov.n	a12, a9
	addi	a11, sp, 40
	call8	_ZN14MotorControlRS6ESS_RS15prepareIdentityERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	j	.L3901
.L3875:
	bnei	a5, 4, .L3877
	l32r	a12, .LC1541
	addi	a14, sp, 28
	add.n	a12, a2, a12
	s32i	a14, sp, 8
	s32i	a11, sp, 4
	s32i	a13, sp, 0
	l32i	a13, a12, 0
	mov.n	a14, a7
	mov.n	a15, a3
	mov.n	a12, a9
	addi	a11, sp, 40
	call8	_ZN14MotorControlRS6ESS_RS23prepareHomingParametersERNS0_11ReadContextERKNS_10ReadTargetEmmyyRKNS_17ActiveSerialTupleE
	j	.L3901
.L3877:
	bnei	a5, 3, .L3878
	l32r	a12, .LC1541
	addi	a14, sp, 28
	add.n	a12, a2, a12
	s32i	a14, sp, 8
	s32i	a11, sp, 4
	s32i	a13, sp, 0
	l32i	a13, a12, 0
	mov.n	a14, a7
	mov.n	a15, a3
	mov.n	a12, a9
	addi	a11, sp, 40
	call8	_ZN14MotorControlRS6ESS_RS25prepareVelocityParametersERNS0_11ReadContextERKNS_10ReadTargetEmmyyRKNS_17ActiveSerialTupleE
	j	.L3901
.L3878:
	bnei	a5, 2, .L3879
	addi	a12, sp, 28
	s32i	a12, sp, 8
	s32i	a11, sp, 4
	s32i	a4, sp, 12
	s32i	a13, sp, 0
	mov.n	a14, a7
	mov.n	a15, a3
	mov.n	a12, a9
	addi	a11, sp, 40
	call8	_ZN14MotorControlRS6ESS_RS12prepareStateERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleEPKNS0_17ConfigObservationE
	j	.L3901
.L3879:
	l32r	a12, .LC1529
	l32i	a8, sp, 64
	add.n	a12, a2, a12
	l8ui	a14, a12, 0
	movi.n	a12, 0
	bne	a14, a8, .L3880
	l32r	a12, .LC1542
	add.n	a12, a2, a12
.L3880:
	s32i	a12, sp, 12
	addi	a12, sp, 28
	s32i	a12, sp, 8
	s32i	a11, sp, 4
	s32i	a13, sp, 0
	mov.n	a14, a7
	mov.n	a15, a3
	mov.n	a12, a9
	addi	a11, sp, 40
	call8	_ZN14MotorControlRS6ESS_RS13prepareConfigERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleEPKNS_11InputWiringE
.L3901:
	s32i	a10, sp, 16
	l8ui	a9, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	bnez.n	a9, .L3881
	movi.n	a9, 4
	bltu	a9, a5, .L3881
	mov.n	a12, a7
	mov.n	a13, a3
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_19admitStepERNS_3AppERNS0_6RecordEy
	mov.n	a4, a10
	beqz.n	a10, .L3898
	j	.L3882
.L3881:
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
.L3867:
	movi.n	a4, 8
	j	.L3862
.L3882:
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	beqi	a4, 3, .L3892
	bnei	a4, 4, .L3893
.L3869:
	movi.n	a4, 6
	j	.L3862
.L3898:
	l32r	a8, .LC1537
	movi.n	a12, 5
	add.n	a11, a2, a8
	addi.n	a10, a6, 12
	call8	memcpy
	l32r	a9, .LC1543
	l32r	a10, .LC1528
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	add.n	a10, a2, a10
	s32i	a9, a6, 20
	l32i	a9, a10, 0
	l32i	a8, sp, 72
	addi.n	a11, a9, 1
	s32i	a11, a10, 0
	l32i	a10, a6, 112
	s32i	a8, a6, 8
	s32i	a10, a6, 56
	movi.n	a10, 2
	s8i	a10, a6, 0
	l32i	a8, sp, 64
	l32r	a10, .LC1541
	l32i	a11, a6, 116
	s8i	a8, a6, 24
	s32i	a9, a6, 4
	add.n	a10, a2, a10
	s32i	a11, a6, 60
	l32i	a11, a10, 0
	l32i	a8, sp, 68
	addmi	a10, a6, 0x1000
	s32i	a11, a10, 176
	s8i	a8, a6, 68
	l32i	a8, sp, 76
	s32i	a9, a8, 0
	l32i	a8, sp, 68
	bnez.n	a8, .L3862
	l32r	a10, .LC1544
	add.n	a8, a2, a10
	s32i	a9, a8, 0
	j	.L3862
.L3892:
	movi.n	a4, 5
	j	.L3862
.L3893:
	movi.n	a4, 4
.L3862:
	mov.n	a2, a4
	retw.n
.LFE2087:
	.size	_ZN12_GLOBAL__N_114startTypedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERmb, .-_ZN12_GLOBAL__N_114startTypedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERmb
	.align	4
	.type	_ZN12_GLOBAL__N_19typedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERm, @function
_ZN12_GLOBAL__N_19typedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERm:
.LFB2088:
	entry	sp, 32
.LCFI169:
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a14, a6
	movi.n	a15, 0
	extui	a13, a5, 0, 8
	extui	a12, a4, 0, 8
	call8	_ZN12_GLOBAL__N_114startTypedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERmb
	mov.n	a2, a10
	retw.n
.LFE2088:
	.size	_ZN12_GLOBAL__N_19typedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERm, .-_ZN12_GLOBAL__N_19typedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERm
	.literal_position
	.literal .LC1546, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1547, 45697
	.literal .LC1548, 45698
	.literal .LC1550, _ZN12_GLOBAL__N_14uartE
	.literal .LC1551, 757624
	.literal .LC1552, 772456
	.literal .LC1553, 45688
	.literal .LC1556, 45700
	.literal .LC1557, 500000
	.align	4
	.type	_ZN12_GLOBAL__N_115startMemberReadERNS_3AppERNS0_11GroupMemberEN14MotorControlRS6ESS_RS8ReadKindERm, @function
_ZN12_GLOBAL__N_115startMemberReadERNS_3AppERNS0_11GroupMemberEN14MotorControlRS6ESS_RS8ReadKindERm:
.LFB2269:
	entry	sp, 96
.LCFI170:
	l32r	a8, .LC1546
	s32i	a5, sp, 52
	l8ui	a8, a8, 0
	s32i	a4, sp, 48
	mov.n	a7, a2
	bnez.n	a8, .L3904
.L3908:
	movi.n	a5, 3
	j	.L3905
.L3904:
	l32r	a8, .LC1547
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3906
.L3907:
	movi.n	a5, 2
	j	.L3905
.L3906:
	l32r	a8, .LC1548
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L3907
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a2, a10
	l8ui	a8, a10, 137
	bnez.n	a8, .L3907
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L3907
	l32r	a6, .LC1550
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L3907
	l32r	a2, .LC1551
	movi.n	a5, 7
	add.n	a8, a7, a2
	l32i	a8, a8, 0
	beqz.n	a8, .L3905
	l32r	a8, .LC1552
	l32i	a9, a3, 16
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L3908
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110freeRecordERNS_3AppE
	mov.n	a4, a10
	beqz.n	a10, .L3909
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32r	a8, .LC1553
	mov.n	a5, a10
	add.n	a10, a7, a8
	mov.n	a6, a11
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	s32i	a10, sp, 28
	l32i	a10, a3, 372
	s32i	a11, sp, 32
	s32i	a12, sp, 36
	movi.n	a9, 0
	beqz.n	a10, .L3910
	movi	a9, 0x168
	add.n	a9, a3, a9
	addi.n	a11, a3, 8
	mov.n	a10, a9
	s32i	a9, sp, 56
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	l32i	a9, sp, 56
	movi.n	a11, 0
	moveqz	a9, a11, a10
.L3910:
	add.n	a10, a7, a2
	l32i	a12, a10, 0
	l32r	a10, .LC1557
	mov.n	a13, a6
	add.n	a14, a5, a10
	bgeu	a14, a10, .L3911
	addi.n	a13, a6, 1
.L3911:
	l32i	a8, sp, 48
	addi.n	a11, a3, 8
	addi	a10, a4, 80
	beqi	a8, 1, .L3912
	addi	a15, sp, 28
	beqi	a8, 2, .L3913
	s32i	a15, sp, 8
	s32i	a14, sp, 0
	s32i	a13, sp, 4
	mov.n	a14, a5
	mov.n	a15, a6
	call8	_ZN14MotorControlRS6ESS_RS15prepareIdentityERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleE
	j	.L3926
.L3912:
	movi.n	a9, 0x58
	addmi	a9, a9, 0x900
	add.n	a9, a3, a9
	s32i	a9, sp, 12
	addi	a9, sp, 28
	s32i	a14, sp, 0
	s32i	a9, sp, 8
	s32i	a13, sp, 4
	mov.n	a14, a5
	mov.n	a15, a6
	call8	_ZN14MotorControlRS6ESS_RS13prepareConfigERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleEPKNS_11InputWiringE
	j	.L3926
.L3913:
	s32i	a15, sp, 8
	s32i	a14, sp, 0
	s32i	a9, sp, 12
	s32i	a13, sp, 4
	mov.n	a14, a5
	mov.n	a15, a6
	call8	_ZN14MotorControlRS6ESS_RS12prepareStateERNS0_11ReadContextERKNS_10ReadTargetEmyyRKNS_17ActiveSerialTupleEPKNS0_17ConfigObservationE
.L3926:
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	beqz.n	a10, .L3915
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a5, 8
	j	.L3905
.L3915:
	addmi	a9, a4, 0x2300
	movi.n	a10, 1
	s8i	a10, a9, 57
	mov.n	a12, a5
	mov.n	a13, a6
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_19admitStepERNS_3AppERNS0_6RecordEy
	mov.n	a5, a10
	beqz.n	a10, .L3916
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	beqi	a5, 3, .L3919
	bnei	a5, 4, .L3920
.L3909:
	movi.n	a5, 6
	j	.L3905
.L3916:
	l32r	a8, .LC1553
	movi.n	a12, 5
	add.n	a11, a7, a8
	addi.n	a10, a4, 12
	call8	memcpy
	l32r	a9, .LC1556
	l32i	a11, a4, 116
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	add.n	a7, a7, a2
	s32i	a9, a4, 20
	l32i	a9, a7, 0
	addmi	a8, a4, 0x1000
	addi.n	a10, a9, 1
	s32i	a10, a7, 0
	s32i	a9, a4, 4
	l8ui	a10, a3, 0
	s32i	a11, a4, 60
	s8i	a10, a4, 24
	l32i	a10, a4, 112
	s32i	a10, a4, 56
	movi.n	a10, 2
	s8i	a10, a4, 0
	l32i	a10, a3, 20
	s32i	a10, a8, 176
	l32i	a8, sp, 52
	s32i	a9, a8, 0
	j	.L3905
.L3919:
	movi.n	a5, 5
	j	.L3905
.L3920:
	movi.n	a5, 4
.L3905:
	mov.n	a2, a5
	retw.n
.LFE2269:
	.size	_ZN12_GLOBAL__N_115startMemberReadERNS_3AppERNS0_11GroupMemberEN14MotorControlRS6ESS_RS8ReadKindERm, .-_ZN12_GLOBAL__N_115startMemberReadERNS_3AppERNS0_11GroupMemberEN14MotorControlRS6ESS_RS8ReadKindERm
	.align	4
	.type	_ZN12_GLOBAL__N_112releaseChildERNS_3AppERm, @function
_ZN12_GLOBAL__N_112releaseChildERNS_3AppERm:
.LFB2270:
	entry	sp, 32
.LCFI171:
	l32i	a11, a3, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a10
	beqz.n	a10, .L3929
	l32i	a8, a10, 32
	bnez.n	a8, .L3930
.L3931:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L3929
.L3930:
	addi	a11, a10, 32
	movi	a10, 0x7f7
	slli	a10, a10, 5
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L3931
.L3929:
	movi.n	a8, 0
	s32i	a8, a3, 0
	retw.n
.LFE2270:
	.size	_ZN12_GLOBAL__N_112releaseChildERNS_3AppERm, .-_ZN12_GLOBAL__N_112releaseChildERNS_3AppERm
	.align	4
	.type	_ZN12_GLOBAL__N_112releaseGroupERNS_3AppERNS0_14GroupOperationE, @function
_ZN12_GLOBAL__N_112releaseGroupERNS_3AppERNS0_14GroupOperationE:
.LFB2296:
	entry	sp, 48
.LCFI172:
	l8ui	a8, a3, 12
	bnez.n	a8, .L3934
	addmi	a8, a3, 0x900
	l8ui	a8, a8, 13
	movi.n	a7, 0
	bnez.n	a8, .L3935
	j	.L3934
.L3939:
	addx8	a8, a7, a7
	slli	a8, a8, 4
	add.n	a8, a3, a8
	l32i	a9, a8, 140
	l32i	a8, a8, 252
	s32i	a9, sp, 0
	s32i	a8, sp, 4
	movi.n	a6, 0
	j	.L3938
.L3949:
	movi.n	a6, 4
.L3938:
	add.n	a8, sp, a6
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a11, a10
	beqz.n	a10, .L3936
	addmi	a8, a10, 0x2300
	l8ui	a8, a8, 57
	beqz.n	a8, .L3936
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L3936
.L3934:
	movi.n	a2, 1
	j	.L3937
.L3936:
	bnei	a6, 4, .L3949
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
.L3935:
	l8ui	a8, a3, 128
	bltu	a7, a8, .L3939
	movi	a4, 0x7f7
	movi.n	a7, 0
	slli	a4, a4, 5
	j	.L3940
.L3947:
	addx8	a8, a7, a7
	slli	a8, a8, 4
	add.n	a8, a3, a8
	l32i	a9, a8, 140
	l32i	a8, a8, 252
	s32i	a9, sp, 0
	s32i	a8, sp, 4
	movi.n	a5, 0
	j	.L3946
.L3950:
	movi.n	a5, 4
.L3946:
	add.n	a8, sp, a5
	l32i	a11, a8, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a6, a10
	beqz.n	a10, .L3942
	addmi	a8, a10, 0x2300
	l8ui	a8, a8, 57
	beqz.n	a8, .L3942
	l32i	a8, a10, 32
	bnez.n	a8, .L3944
.L3945:
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L3942
.L3944:
	addi	a11, a10, 32
	add.n	a10, a2, a4
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L3945
.L3942:
	bnei	a5, 4, .L3950
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
.L3940:
	l8ui	a8, a3, 128
	bltu	a7, a8, .L3947
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE
	movi.n	a2, 0
.L3937:
	retw.n
.LFE2296:
	.size	_ZN12_GLOBAL__N_112releaseGroupERNS_3AppERNS0_14GroupOperationE, .-_ZN12_GLOBAL__N_112releaseGroupERNS_3AppERNS0_14GroupOperationE
	.literal_position
	.literal .LC1560, 771228
	.literal .LC1561, 771232
	.literal .LC1562, 771260
	.literal .LC1563, 771236
	.literal .LC1564, 626240
	.literal .LC1565, 626280
	.literal .LC1566, 626264
	.literal .LC1567, 65248
	.literal .LC1568, 115200
	.literal .LC1569, 626344
	.literal .LC1570, 626384
	.align	4
	.type	_ZN12_GLOBAL__N_17releaseEPvm, @function
_ZN12_GLOBAL__N_17releaseEPvm:
.LFB2317:
	entry	sp, 144
.LCFI173:
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm
	mov.n	a7, a2
	mov.n	a11, a10
	beqz.n	a10, .L3962
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112releaseGroupERNS_3AppERNS0_14GroupOperationE
	j	.L3993
.L3962:
	beqz.n	a3, .L3964
	l32r	a8, .LC1560
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beq	a3, a8, .L3965
	l32r	a8, .LC1561
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	beq	a3, a8, .L3965
	l32r	a8, .LC1562
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a3, a8, .L3966
.L3965:
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119releaseSimpleMotionERNS_3AppEb
.L3993:
	mov.n	a2, a10
	j	.L3963
.L3966:
	l32r	a8, .LC1563
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a3, a8, .L3967
.L3969:
	movi.n	a2, 1
	j	.L3963
.L3967:
	l32r	a6, .LC1564
	add.n	a6, a2, a6
	l32i	a8, a6, 0
	bne	a3, a8, .L3968
	l32r	a8, .LC1565
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3969
	l32r	a8, .LC1566
	l32r	a10, .LC1567
	add.n	a8, a2, a8
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner15releaseRecoveryEy
	beqz.n	a10, .L3969
	j	.L3992
.L3968:
	l32r	a6, .LC1569
	add.n	a6, a2, a6
	l32i	a8, a6, 0
	bne	a3, a8, .L3964
	l32r	a8, .LC1570
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L3969
.L3992:
	movi	a12, 0x68
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a8, .LC1568
	movi	a12, 0x68
	s32i	a8, sp, 8
	movi.n	a8, 1
	s8i	a8, sp, 96
	mov.n	a11, sp
	mov.n	a10, a6
	call8	memcpy
	j	.L3971
.L3964:
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a6, a10
	movi.n	a2, 8
	beqz.n	a10, .L3963
	addmi	a8, a10, 0xb00
	l32i	a11, a8, 248
	bne	a3, a11, .L3973
	l32i	a11, a8, 252
.L3973:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a11, a10
	bnez.n	a10, .L3974
.L3976:
	l8ui	a8, a6, 65
	bnez.n	a8, .L3975
	j	.L3969
.L3974:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L3976
	j	.L3969
.L3975:
	l32i	a8, a6, 32
	bnez.n	a8, .L3977
.L3978:
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L3971
.L3977:
	l32r	a10, .LC1567
	addi	a11, a6, 32
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L3978
	j	.L3969
.L3971:
	movi.n	a2, 0
.L3963:
	retw.n
.LFE2317:
	.size	_ZN12_GLOBAL__N_17releaseEPvm, .-_ZN12_GLOBAL__N_17releaseEPvm
	.literal_position
	.literal .LC1571, 757620
	.literal .LC1574, 35380
	.literal .LC1575, 101032
	.literal .LC1576, 103268
	.literal .LC1577, 109004
	.literal .LC1578, 625352
	.literal .LC1579, -16711936
	.literal .LC1580, 16779520
	.literal .LC1581, 16778240
	.literal .LC1582, 65248
	.literal .LC1584, .L4008
	.literal .LC1588, 818144
	.align	4
	.type	_ZN12_GLOBAL__N_125recycleInteractiveResultsEPv, @function
_ZN12_GLOBAL__N_125recycleInteractiveResultsEPv:
.LFB2379:
	entry	sp, 48
.LCFI174:
	l32r	a8, .LC1571
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L3994
	movi	a8, 0x1ff
	slli	a8, a8, 7
	movi	a9, 0x8b
	add.n	a8, a2, a8
	slli	a9, a9, 8
	add.n	a9, a8, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L3994
	l32r	a9, .LC1574
	add.n	a8, a8, a9
	l8ui	a8, a8, 0
	bnez.n	a8, .L3994
	l32r	a8, .LC1575
	l32r	a9, .LC1578
	add.n	a3, a2, a8
	add.n	a8, a2, a9
	l32r	a9, .LC1582
	l32r	a7, .LC1576
	l32r	a6, .LC1577
	s32i	a8, sp, 4
	add.n	a8, a2, a9
	add.n	a7, a2, a7
	add.n	a6, a2, a6
	s32i	a8, sp, 8
	j	.L3998
.L4018:
	addi	a9, a3, -28
	l32i	a8, a9, 0
	l32i	a9, a7, 800
	s32i	a8, sp, 0
	bne	a9, a8, .L3999
	beqz.n	a8, .L3999
	l32i	a11, a7, 796
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a4, a10
	beqz.n	a10, .L4001
	mov.n	a10, a5
	call8	_ZZN12_GLOBAL__N_120settledInterruptPairERKNS_3App6RecordES3_ENKUlS3_E_clES3_$isra$0
	beqz.n	a10, .L4001
	mov.n	a10, a4
	call8	_ZZN12_GLOBAL__N_120settledInterruptPairERKNS_3App6RecordES3_ENKUlS3_E_clES3_$isra$0
	beqz.n	a10, .L4001
	movi	a10, 0x324
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L4001
	addmi	a10, a4, 0xc00
	l8ui	a10, a10, 0
	beqz.n	a10, .L4001
	addmi	a10, a4, 0xb00
	l32i	a10, a10, 252
	l32i	a8, sp, 0
	bne	a8, a10, .L4001
	l8ui	a10, a7, 0
	bnei	a10, 2, .L4001
	l8ui	a10, a7, 6
	bnez.n	a10, .L4001
	addmi	a10, a5, 0x800
	l32i	a10, a10, 220
	l32r	a12, .LC1579
	l32r	a11, .LC1580
	and	a10, a10, a12
	bne	a10, a11, .L4001
	addmi	a11, a4, 0x800
	l32i	a10, a11, 220
	and	a10, a10, a12
	l32r	a12, .LC1581
	bne	a10, a12, .L4001
	l8ui	a10, a11, 222
	beqi	a10, 3, .L4001
	l32i	a10, a3, 0
	bnez.n	a10, .L4003
.L4006:
	l32i	a10, a4, 32
	bnez.n	a10, .L4076
	j	.L4004
.L4003:
	l32i	a10, sp, 8
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L4006
	j	.L4001
.L4004:
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L4015
.L4076:
	l32r	a10, .LC1582
	addi	a11, a4, 32
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L4004
	j	.L4001
.L3999:
	l8ui	a9, a3, 35
	beqz.n	a9, .L4001
	l8ui	a9, a3, 33
	beqz.n	a9, .L4001
	l8ui	a9, a3, 37
	bnez.n	a9, .L4001
	l8ui	a9, a3, 38
	bnez.n	a9, .L4001
	l8ui	a9, a6, 21
	bnez.n	a9, .L4001
	movi.n	a8, 0x18
	addmi	a8, a8, 0x2300
	add.n	a9, a3, a8
	l8ui	a9, a9, 0
	bnez.n	a9, .L4001
	l32i	a9, a7, 796
	bnez.n	a9, .L4001
	movi	a9, 0x2e8
	add.n	a9, a3, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4001
	movi	a9, 0x2eb
	add.n	a9, a3, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4001
	l8ui	a9, a5, 0
	addi.n	a9, a9, -1
	extui	a9, a9, 0, 8
	bgeui	a9, 7, .L4001
	l32r	a8, .LC1584
	addx4	a9, a9, a8
	l32i	a9, a9, 0
	jx	a9
	.section	.rodata
	.align	4
	.align	4
.L4008:
	.word	.L4014
	.word	.L4013
	.word	.L4012
	.word	.L4011
	.word	.L4010
	.word	.L4009
	.word	.L4007
	.text
.L4007:
	l8ui	a9, a6, 200
	bnei	a9, 2, .L4001
	l8ui	a9, a6, 207
.L4081:
	bnez.n	a9, .L4001
.L4017:
	l32i	a9, a3, 0
	bnez.n	a9, .L4077
	j	.L4015
.L4009:
	movi	a9, 0xb1
	addmi	a9, a9, 0x1000
	add.n	a9, a3, a9
	l8ui	a9, a9, 0
	bnei	a9, 2, .L4001
	l8ui	a9, a6, 0
	j	.L4081
.L4010:
	movi	a9, 0x438
	add.n	a9, a7, a9
	l8ui	a9, a9, 0
	bnei	a9, 2, .L4001
	movi.n	a9, -5
	addmi	a9, a9, 0xd00
	add.n	a9, a3, a9
	l8ui	a9, a9, 0
	j	.L4081
.L4011:
	l8ui	a9, a7, 0
	bnei	a9, 2, .L4001
	l8ui	a9, a7, 6
	j	.L4081
.L4012:
	movi	a9, 0x544
	add.n	a9, a3, a9
	l8ui	a9, a9, 0
	j	.L4079
.L4013:
	l8ui	a9, a3, 69
	j	.L4079
.L4014:
	l32r	a4, .LC1582
	mov.n	a11, a3
	add.n	a4, a2, a4
	mov.n	a10, a4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	beqz.n	a10, .L4001
	mov.n	a11, a3
	mov.n	a10, a4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	l8ui	a9, a10, 105
.L4079:
	bnei	a9, 2, .L4001
	j	.L4017
.L4015:
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L4001
.L4077:
	l32r	a10, .LC1582
	mov.n	a11, a3
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L4015
.L4001:
	movi.n	a9, 0x50
	addmi	a9, a9, 0x2300
	add.n	a3, a3, a9
	add.n	a7, a7, a9
	add.n	a6, a6, a9
.L3998:
	l32i	a8, sp, 4
	addi	a5, a3, -32
	bne	a3, a8, .L4018
	l32r	a11, .LC1588
	add.n	a11, a2, a11
	l32i	a8, a11, 4
	beqz.n	a8, .L3994
	addmi	a8, a11, 0x900
	l8ui	a9, a8, 13
	beqz.n	a9, .L3994
	l8ui	a8, a8, 15
	beqz.n	a8, .L3994
	l8ui	a8, a11, 13
	beqz.n	a8, .L3994
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112releaseGroupERNS_3AppERNS0_14GroupOperationE
.L3994:
	retw.n
.LFE2379:
	.size	_ZN12_GLOBAL__N_125recycleInteractiveResultsEPv, .-_ZN12_GLOBAL__N_125recycleInteractiveResultsEPv
	.literal_position
	.literal .LC1589, 101000
	.literal .LC1590, 625320
	.literal .LC1591, 101012
	.literal .LC1592, 101080
	.literal .LC1593, 101777
	.literal .LC1595, 626200
	.literal .LC1596, 626196
	.literal .LC1597, 65248
	.literal .LC1598, 626184
	.literal .LC1600, .LC12
	.literal .LC1601, 65408
	.literal .LC1602, .L4095
	.literal .LC1609, 45700
	.literal .LC1610, 772456
	.literal .LC1611, 757804
	.literal .LC1612, 757792
	.literal .LC1613, 764508
	.literal .LC1614, 757972
	.literal .LC1615, 758808
	.literal .LC1616, 759280
	.literal .LC1617, 759752
	.literal .LC1619, 764516
	.literal .LC1620, 757976
	.literal .LC1621, 757960
	.literal .LC1622, 764496
	.literal .LC1623, 758796
	.literal .LC1624, 758792
	.literal .LC1625, 759740
	.literal .LC1626, 758002
	.literal .LC1627, 759760
	.literal .LC1628, 758004
	.literal .LC1629, 759762
	.literal .LC1630, 16777216
	.literal .LC1632, 759268
	.literal .LC1633, 759302
	.literal .LC1634, 757994
	.literal .LC1635, 764696
	.literal .LC1636, 764771
	.literal .LC1637, 764772
	.literal .LC1638, 50000
	.literal .LC1639, 771840
	.literal .LC1642, 772072
	.literal .LC1643, 771952
	.literal .LC1644, 764788
	.literal .LC1645, 771828
	.literal .LC1646, 757632
	.literal .LC1647, 757772
	.literal .LC1648, 757768
	.literal .LC1649, 757775
	.literal .LC1650, 757776
	.literal .LC1651, 772585
	.literal .LC1652, 757773
	.literal .LC1653, 757636
	.literal .LC1654, 757774
	.literal .LC1655, 757770
	.literal .LC1656, 757769
	.literal .LC1657, 757752
	.literal .LC1658, 757736
	.literal .LC1659, 757744
	.literal .LC1661, 626240
	.literal .LC1662, 626280
	.literal .LC1663, 626264
	.literal .LC1664, 626256
	.literal .LC1665, 626248
	.literal .LC1666, 626244
	.literal .LC1667, 626344
	.literal .LC1668, 626384
	.literal .LC1669, 626360
	.literal .LC1670, 626352
	.literal .LC1671, 626392
	.literal .LC1672, 626348
	.literal .LC1673, 774016
	.literal .LC1675, 41808
	.literal .LC1677, 46448
	.align	4
	.type	_ZN12_GLOBAL__N_17deliverERNS_3AppE, @function
_ZN12_GLOBAL__N_17deliverERNS_3AppE:
.LFB2380:
	entry	sp, 544
.LCFI175:
	l32r	a10, .LC1590
	l32r	a9, .LC1589
	add.n	a8, a2, a10
	l32r	a10, .LC1591
	s32i	a8, sp, 496
	add.n	a8, a2, a10
	l32r	a10, .LC1592
	s32i	a8, sp, 480
	add.n	a8, a2, a10
	l32r	a6, .LC1593
	s32i	a8, sp, 484
	addi	a8, sp, 16
	addmi	a8, a8, 0x100
	mov.n	a3, a2
	add.n	a7, a2, a9
	add.n	a6, a2, a6
	s32i	a8, sp, 500
	j	.L4085
.L4157:
	l32i	a5, a7, 4
	beqz.n	a5, .L4156
	l8ui	a10, a7, 65
	bnez.n	a10, .L4156
	movi.n	a8, 0x39
	addmi	a8, a8, 0x2300
	add.n	a10, a7, a8
	l8ui	a10, a10, 0
	bnez.n	a10, .L4156
	movi	a10, 0x6b8
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4156
	l8ui	a10, a7, 68
	beqz.n	a10, .L4087
	mov.n	a11, a7
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L4156
	l32i	a10, a7, 32
	bnez.n	a10, .L4088
.L4090:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	l32r	a10, .LC1595
	movi.n	a11, 0
	add.n	a10, a3, a10
	s32i	a11, a10, 0
	l32r	a10, .LC1596
	add.n	a10, a3, a10
	l32i	a11, a10, 0
	beqz.n	a11, .L4089
	j	.L4156
.L4088:
	l32r	a10, .LC1597
	addi	a11, a7, 32
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	bnez.n	a10, .L4090
	j	.L4156
.L4089:
	l32r	a10, .LC1598
	add.n	a10, a3, a10
	s8i	a11, a10, 0
	j	.L4156
.L4087:
	movi	a12, 0x140
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a10, .LC1600
	movi	a8, 0xe1
	slli	a8, a8, 9
	s32i	a8, sp, 20
	s32i	a10, sp, 196
	l32i	a8, sp, 500
	movi.n	a10, 1
	s8i	a10, sp, 248
	s8i	a10, a8, 56
	addi	a12, sp, 16
	mov.n	a11, a5
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_16lookupEPvmRN21MotorControlRSExample5Probe10ResultViewE
	beqz.n	a10, .L4156
	l8ui	a10, sp, 41
	bnez.n	a10, .L4156
	l32r	a8, .LC1601
	l32i	a11, a7, 4
	add.n	a8, a3, a8
	mov.n	a10, a8
	s32i	a8, sp, 488
	call8	_ZNK21MotorControlRSExample5Probe7Console11humanResultEm
	s8i	a10, a7, 67
	l8ui	a10, a7, 0
	bgeui	a10, 8, .L4093
	l32r	a11, .LC1602
	addx4	a10, a10, a11
	l32i	a10, a10, 0
	jx	a10
	.section	.rodata
	.align	4
	.align	4
.L4095:
	.word	.L4156
	.word	.L4093
	.word	.L4100
	.word	.L4099
	.word	.L4098
	.word	.L4097
	.word	.L4096
	.word	.L4094
	.text
.L4094:
	movi.n	a10, 0x38
	addmi	a10, a10, 0x2300
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L4101
	j	.L4135
.L4101:
	l32i	a10, a7, 20
	l8ui	a14, a6, 1
	movi	a13, 0x60
	s32i	a10, sp, 0
	l32i	a15, sp, 480
	l32i	a12, a7, 4
	l32i	a11, a7, 8
	l32i	a10, sp, 488
	addmi	a13, a13, 0x1f00
	add.n	a13, a7, a13
	call8	_ZN21MotorControlRSExample5Probe7Console10reportHomeEmmRKN14MotorControlRS6ESS_RS11HomeContextEbPKNS_9HostTupleEm
	j	.L4288
.L4096:
	l8ui	a10, a7, 69
	beqz.n	a10, .L4103
	j	.L4135
.L4103:
	movi.n	a10, 0x59
	addmi	a10, a10, 0x1f00
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4135
	movi	a13, 0xb8
	l32i	a15, a7, 20
	l32i	a14, sp, 480
	l32i	a12, a7, 4
	l32i	a11, a7, 8
	l32i	a10, sp, 488
	addmi	a13, a13, 0x1000
	add.n	a13, a7, a13
	call8	_ZN21MotorControlRSExample5Probe7Console12reportDriverEmmRKN14MotorControlRS6ESS_RS13DriverContextEPKNS_9HostTupleEm
	j	.L4288
.L4097:
	l32i	a10, a7, 20
	l8ui	a14, a6, 1
	movi.n	a13, 8
	s32i	a10, sp, 0
	l32i	a15, sp, 480
	l32i	a12, a7, 4
	l32i	a11, a7, 8
	l32i	a10, sp, 488
	addmi	a13, a13, 0xc00
	add.n	a13, a7, a13
	call8	_ZN21MotorControlRSExample5Probe7Console14reportVelocityEmmRKN14MotorControlRS6ESS_RS15VelocityContextEbPKNS_9HostTupleEm
	j	.L4288
.L4098:
	movi	a10, 0x6e8
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4135
	l8ui	a10, a7, 69
	beqz.n	a10, .L4106
	j	.L4135
.L4106:
	movi.n	a10, -8
	addmi	a10, a10, 0xc00
	add.n	a10, a7, a10
	l8ui	a14, a6, 1
	s32i	a10, sp, 4
	l32i	a10, a7, 20
	l32i	a15, sp, 480
	s32i	a10, sp, 0
	l32i	a12, a7, 4
	l32i	a11, a7, 8
	l32i	a10, sp, 488
	movi	a13, 0x6f0
	add.n	a13, a7, a13
	call8	_ZN21MotorControlRSExample5Probe7Console10reportMoveEmmRKN14MotorControlRS6ESS_RS11MoveContextEbPKNS_9HostTupleEmRKNS_12MoveRelationE
	j	.L4288
.L4099:
	l32i	a10, a7, 20
	l8ui	a14, a6, 1
	s32i	a10, sp, 0
	l32i	a15, sp, 480
	l32i	a12, a7, 4
	l32i	a11, a7, 8
	l32i	a10, sp, 488
	movi	a13, 0x530
	add.n	a13, a7, a13
	call8	_ZN21MotorControlRSExample5Probe7Console12reportActionEmmRKN14MotorControlRS6ESS_RS13ActionContextEbPKNS_9HostTupleEm
	j	.L4288
.L4100:
	l8ui	a5, a7, 64
	bnez.n	a5, .L4108
	l32r	a10, .LC1609
	l32i	a11, a7, 20
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L4108
	l32r	a10, .LC1610
	l32i	a11, a7, 88
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L4108
	movi.n	a10, 1
	s8i	a10, a7, 64
	l8ui	a10, a7, 100
	bnez.n	a10, .L4110
	l32r	a10, .LC1611
	l32i	a11, a7, 4
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	bgeu	a10, a11, .L4108
	l32r	a11, .LC1612
	l32i	a10, sp, 484
	add.n	a11, a3, a11
	call8	_ZN14MotorControlRS6ESS_RS11getIdentityERKNS0_11ReadContextERNS0_19IdentityObservationE
	movi	a13, 0x1c4
	addi	a8, sp, 16
	add.n	a13, a8, a13
	s32i	a10, a13, 0
	s32i	a11, a13, 4
	s32i	a12, a13, 8
.L4110:
	l8ui	a10, a7, 100
	bnei	a10, 1, .L4108
	l32r	a10, .LC1613
	l8ui	a11, a7, 24
	add.n	a10, a3, a10
	l8ui	a10, a10, 0
	bne	a11, a10, .L4108
	l32r	a11, .LC1614
	l32i	a10, a7, 4
	add.n	a11, a3, a11
	l32i	a8, a11, 0
	s32i	a8, sp, 492
	bgeu	a8, a10, .L4108
	l32r	a11, .LC1615
	add.n	a11, a3, a11
	l32i	a11, a11, 0
	bgeu	a11, a10, .L4108
	l32r	a11, .LC1616
	add.n	a11, a3, a11
	l32i	a11, a11, 0
	bgeu	a11, a10, .L4108
	l32r	a11, .LC1617
	add.n	a11, a3, a11
	l32i	a11, a11, 0
	bgeu	a11, a10, .L4108
	l32r	a10, .LC1619
	movi	a11, 0xb0
	addmi	a11, a11, 0x1000
	add.n	a11, a7, a11
	add.n	a10, a3, a10
	l32i	a11, a11, 0
	l32i	a10, a10, 0
	bne	a11, a10, .L4108
	l32r	a10, .LC1610
	l32i	a11, a7, 88
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L4108
	l32r	a11, .LC1620
	addi	a8, sp, 16
	addmi	a10, a8, 0x100
	add.n	a11, a3, a11
	movi.n	a12, 0x1e
	addi	a10, a10, 64
	call8	memcpy
	l32r	a4, .LC1621
	add.n	a10, a3, a4
	l32i	a11, a10, 0
	beqz.n	a11, .L4111
	l32i	a11, sp, 484
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a5, a10
.L4111:
	l32i	a10, sp, 484
	add.n	a11, a3, a4
	call8	_ZN14MotorControlRS6ESS_RS9getConfigERKNS0_11ReadContextERNS0_17ConfigObservationE
	s32i	a10, sp, 456
	s32i	a11, sp, 460
	extui	a10, a10, 0, 8
	s32i	a12, sp, 464
	addi	a4, sp, 16
	bnez.n	a10, .L4108
	beqz.n	a5, .L4114
	l32r	a11, .LC1620
	l16ui	a12, a4, 336
	add.n	a11, a3, a11
	l16ui	a10, a11, 16
	bne	a12, a10, .L4114
	movi	a10, 0x152
	movi.n	a12, 8
	addi	a11, a11, 18
	add.n	a10, a4, a10
	call8	memcmp
	beqz.n	a10, .L4115
.L4114:
	l32r	a10, .LC1622
	movi.n	a11, 0
	add.n	a10, a3, a10
	s8i	a11, a10, 0
.L4115:
	l32r	a10, .LC1623
	add.n	a11, a3, a10
	l32i	a2, a11, 0
	beqz.n	a2, .L4116
	l32r	a11, .LC1615
	movi.n	a12, 1
	add.n	a11, a3, a11
	l32i	a11, a11, 0
	moveqz	a12, a11, a11
	bnez.n	a11, .L4181
	l32i	a8, sp, 492
	movi.n	a11, 1
	movnez	a11, a12, a8
	movi.n	a2, 0
	beqz.n	a11, .L4116
.L4181:
	l32i	a11, sp, 484
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	movi.n	a2, 0
	beqz.n	a10, .L4116
	l32r	a11, .LC1624
	l32r	a10, .LC1620
	add.n	a11, a3, a11
	add.n	a10, a3, a10
	call8	_ZN12_GLOBAL__N_119driverConfigEffectsERKN14MotorControlRS6ESS_RS9RawConfigERKNS1_17DriverObservationE
	mov.n	a2, a10
.L4116:
	l32r	a10, .LC1625
	add.n	a11, a3, a10
	l32i	a11, a11, 0
	beqz.n	a11, .L4118
	l32r	a11, .LC1617
	movi.n	a12, 1
	add.n	a11, a3, a11
	l32i	a11, a11, 0
	moveqz	a12, a11, a11
	bnez.n	a11, .L4182
	l32i	a8, sp, 492
	movi.n	a11, 1
	movnez	a11, a12, a8
	beqz.n	a11, .L4118
.L4182:
	l32i	a11, sp, 484
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4118
	l32r	a11, .LC1626
	l32r	a10, .LC1627
	add.n	a11, a3, a11
	add.n	a10, a3, a10
	l16ui	a10, a10, 0
	l16ui	a11, a11, 0
	l32r	a12, .LC1628
	sub	a11, a11, a10
	movi.n	a10, 1
	moveqz	a10, a11, a11
	l32r	a11, .LC1629
	add.n	a12, a3, a12
	add.n	a11, a3, a11
	l16ui	a12, a12, 0
	l16ui	a11, a11, 0
	slli	a10, a10, 23
	beq	a12, a11, .L4120
	l32r	a11, .LC1630
	or	a10, a10, a11
.L4120:
	or	a2, a2, a10
.L4118:
	beqz.n	a5, .L4121
	l32r	a10, .LC1620
	l16ui	a12, a4, 346
	add.n	a11, a3, a10
	l16ui	a11, a11, 26
	beq	a12, a11, .L4122
	movi.n	a11, 1
	slli	a11, a11, 23
	or	a2, a2, a11
.L4122:
	add.n	a10, a3, a10
	l16ui	a11, a4, 348
	l16ui	a10, a10, 28
	beq	a11, a10, .L4121
	l32r	a10, .LC1630
	or	a2, a2, a10
.L4121:
	l32r	a10, .LC1632
	add.n	a11, a3, a10
	l32i	a11, a11, 0
	beqz.n	a11, .L4123
	l32r	a11, .LC1616
	movi.n	a12, 1
	add.n	a11, a3, a11
	l32i	a11, a11, 0
	moveqz	a12, a11, a11
	bnez.n	a11, .L4183
	l32i	a8, sp, 492
	movi.n	a11, 1
	movnez	a11, a12, a8
	beqz.n	a11, .L4123
.L4183:
	l32i	a11, sp, 484
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4123
	l32r	a11, .LC1620
	l32r	a10, .LC1633
	add.n	a11, a3, a11
	add.n	a10, a3, a10
	l16ui	a11, a11, 16
	l16ui	a10, a10, 0
	beq	a11, a10, .L4125
	movi	a10, 0x200
	or	a2, a2, a10
	j	.L4125
.L4127:
	add.n	a13, a10, a15
	l16ui	a8, a10, 0
	l16ui	a13, a13, 0
	beq	a8, a13, .L4126
	ssl	a12
	sll	a13, a14
	or	a2, a2, a13
.L4126:
	addi.n	a10, a10, 2
	addi.n	a12, a12, 1
	addi.n	a11, a11, -1
	bnez.n	a11, .L4127
	j	.L4123
.L4125:
	l32r	a10, .LC1634
	movi.n	a12, 0xa
	add.n	a10, a3, a10
	movi	a15, 0x51e
	movi.n	a14, 1
	movi.n	a11, 4
	j	.L4127
.L4123:
	beqz.n	a5, .L4128
	l32r	a11, .LC1620
	l16ui	a15, a4, 320
	add.n	a11, a3, a11
	l16ui	a14, a11, 0
	l16ui	a12, a4, 322
	l16ui	a13, a11, 2
	bne	a15, a14, .L4129
	bne	a13, a12, .L4130
	l16ui	a13, a4, 334
	l16ui	a12, a11, 14
	bne	a13, a12, .L4128
	l16ui	a13, a4, 346
	l16ui	a12, a11, 26
	bne	a13, a12, .L4128
	l16ui	a13, a4, 348
	l16ui	a12, a11, 28
	bne	a13, a12, .L4128
	l16ui	a13, a4, 336
	l16ui	a12, a11, 16
	bne	a13, a12, .L4128
	l16ui	a13, a4, 330
	l16ui	a12, a11, 10
	bne	a13, a12, .L4128
	l16ui	a12, a4, 332
	l16ui	a10, a11, 12
	bne	a12, a10, .L4128
	movi	a10, 0x152
	movi.n	a12, 8
	addi	a11, a11, 18
	add.n	a10, a4, a10
	call8	memcmp
	movi.n	a5, 1
	moveqz	a5, a10, a10
	j	.L4128
.L4129:
	movi.n	a10, 1
	or	a2, a2, a10
	beq	a13, a12, .L4128
.L4130:
	movi.n	a10, 2
	or	a2, a2, a10
.L4128:
	l8ui	a11, a6, 0
	bnez.n	a11, .L4108
	movi.n	a10, 1
	moveqz	a10, a11, a2
	bnez.n	a10, .L4184
	beqz.n	a5, .L4108
.L4184:
	l8ui	a5, a7, 24
	call8	_Z18esp_timer_get_timev
	mov.n	a15, a11
	movi.n	a11, 0
	mov.n	a14, a10
	s32i	a11, sp, 4
	s32i	a11, sp, 0
	mov.n	a10, a3
	mov.n	a11, a5
	mov.n	a12, a2
	call8	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE
	l32r	a10, .LC1614
	l32i	a11, a7, 4
	add.n	a10, a3, a10
	s32i	a11, a10, 0
.L4108:
	l8ui	a10, a7, 69
	beqz.n	a10, .L4134
.L4135:
	movi.n	a10, 1
	s8i	a10, a7, 65
	call8	_Z18esp_timer_get_timev
	s32i	a10, a7, 48
	s32i	a11, a7, 52
	j	.L4156
.L4134:
	l8ui	a10, a7, 70
	bnez.n	a10, .L4135
	l32i	a15, a7, 20
	l32i	a14, sp, 480
	l32i	a13, sp, 484
	l32i	a12, a7, 4
	l32i	a11, a7, 8
	l32i	a10, sp, 488
	call8	_ZN21MotorControlRSExample5Probe7Console10reportReadEmmRKN14MotorControlRS6ESS_RS11ReadContextEPKNS_9HostTupleEm
.L4288:
	bnez.n	a10, .L4135
	j	.L4156
.L4093:
	l32r	a4, .LC1597
	add.n	a8, a3, a4
	s32i	a8, sp, 492
	l32i	a10, sp, 492
	addi	a8, a7, 32
	mov.n	a11, a8
	s32i	a8, sp, 504
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a4, a10
	l8ui	a10, a7, 64
	bnez.n	a10, .L4174
	l8ui	a12, a7, 72
	movi.n	a11, 1
	mov.n	a2, a10
	movnez	a10, a11, a12
	movnez	a2, a11, a4
	beqz.n	a10, .L4146
	bnez.n	a2, .L4137
.L4146:
	l8ui	a13, a7, 66
	bnez.n	a13, .L4174
	j	.L4284
.L4137:
	l16ui	a10, a4, 136
	s8i	a11, a7, 64
	beqz.n	a10, .L4174
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_125invalidateTargetKnowledgeERNS_3AppEy
	l32r	a10, .LC1619
	movi.n	a15, -3
	add.n	a11, a3, a10
	l32i	a12, a11, 0
	movi.n	a11, 0
	addi.n	a13, a12, -1
	bltu	a15, a13, .L4141
	addi.n	a11, a12, 1
.L4141:
	add.n	a10, a3, a10
	s32i	a11, a10, 0
	l32r	a10, .LC1635
	movi.n	a12, 0x40
	movi.n	a11, 0
	add.n	a10, a3, a10
	call8	memset
	l32r	a10, .LC1636
	movi.n	a15, 0
	add.n	a10, a3, a10
	s8i	a15, a10, 0
	addi	a13, sp, 16
	l32r	a10, .LC1637
	addmi	a13, a13, 0x100
	addi	a5, a13, 64
	add.n	a10, a3, a10
	movi.n	a11, 1
	s8i	a11, a10, 0
	movi.n	a12, 0x48
	movi.n	a11, 0
	mov.n	a10, a5
	s32i	a15, sp, 508
	s32i	a13, sp, 504
	call8	memset
	movi	a10, 0x7d0
	s16i	a10, sp, 352
	l32r	a10, .LC1638
	movi.n	a12, 0x48
	s32i	a10, sp, 356
	movi	a10, 0x64
	s16i	a10, sp, 360
	l32r	a10, .LC1639
	mov.n	a11, a5
	add.n	a10, a3, a10
	call8	memcpy
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	l32i	a13, sp, 504
	movi.n	a10, 0x48
	addmi	a10, a10, -0xc00
	s16i	a10, a13, 90
	movi	a10, 0xb8
	addmi	a10, a10, 0xb00
	s16i	a10, a13, 92
	l32r	a10, .LC1642
	movi.n	a12, 0x38
	mov.n	a11, a5
	add.n	a10, a3, a10
	call8	memcpy
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, a5
	call8	memset
	movi.n	a10, 0x23
	s16i	a10, sp, 356
	movi.n	a10, 7
	s16i	a10, sp, 366
	l32r	a10, .LC1643
	mov.n	a11, a5
	movi	a12, 0x78
	add.n	a10, a3, a10
	call8	memcpy
	l32r	a10, .LC1644
	l32i	a15, sp, 508
	add.n	a10, a3, a10
	s8i	a15, a10, 0
	l32r	a10, .LC1645
	movi.n	a11, 0
	add.n	a10, a3, a10
	s32i	a11, a10, 0
	l8ui	a10, a7, 64
	beqz.n	a10, .L4146
	j	.L4174
.L4284:
	l32r	a10, .LC1609
	l32i	a11, a7, 20
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	mov.n	a12, a13
	sub	a10, a10, a11
	movi.n	a11, 1
	moveqz	a12, a11, a10
	beqz.n	a12, .L4174
	beqz.n	a2, .L4174
	l32r	a10, .LC1610
	l32i	a12, a4, 20
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	beq	a12, a10, .L4147
.L4153:
	l32i	a10, sp, 492
	addi	a11, a7, 32
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a11, a10
	bnez.n	a10, .L4148
	j	.L4154
.L4147:
	l16ui	a10, sp, 128
	s8i	a11, a7, 64
	l8ui	a14, sp, 248
	beqz.n	a10, .L4150
	l32r	a10, .LC1646
	l32i	a12, a7, 4
	add.n	a10, a3, a10
	l32i	a15, a10, 0
	bgeu	a15, a12, .L4150
	s32i	a12, a10, 0
	l32r	a10, .LC1647
	add.n	a10, a3, a10
	s8i	a11, a10, 0
	l32r	a10, .LC1648
	l8ui	a12, a7, 24
	add.n	a10, a3, a10
	s8i	a12, a10, 0
	l32r	a10, .LC1649
	l8ui	a12, sp, 184
	add.n	a10, a3, a10
	s8i	a12, a10, 0
	movi	a12, 0xbc
	add.n	a12, sp, a12
	l32r	a10, .LC1650
	l32i	a5, a12, 0
	l32i	a15, a12, 4
	l32i	a12, a12, 8
	add.n	a10, a3, a10
	s32i	a5, a10, 0
	s32i	a12, a10, 8
	s32i	a15, a10, 4
	l32r	a10, .LC1651
	l8ui	a12, sp, 200
	add.n	a10, a3, a10
	s8i	a12, a10, 0
	l32r	a10, .LC1652
	addi	a12, a14, -2
	add.n	a10, a3, a10
	movnez	a11, a13, a12
	s8i	a11, a10, 0
.L4150:
	bnei	a14, 2, .L4174
	l32r	a10, .LC1653
	l32i	a11, a7, 4
	add.n	a10, a3, a10
	l32i	a12, a10, 0
	bgeu	a12, a11, .L4174
	l32r	a11, .LC1654
	movi.n	a12, 1
	add.n	a11, a3, a11
	s8i	a12, a11, 0
	l32r	a11, .LC1655
	l16ui	a12, sp, 202
	add.n	a11, a3, a11
	s16i	a12, a11, 0
	l32r	a11, .LC1656
	l8ui	a12, a7, 24
	add.n	a11, a3, a11
	s8i	a12, a11, 0
	l32i	a11, a7, 4
	l32r	a12, .LC1657
	s32i	a11, a10, 0
	l32i	a11, a7, 52
	l32i	a10, a7, 48
	add.n	a12, a3, a12
	l8ui	a13, sp, 220
	s32i	a11, a12, 4
	s32i	a10, a12, 0
	movi.n	a11, 0
	movi.n	a12, 0
	beqz.n	a13, .L4151
	l32i	a12, sp, 256
	l32i	a11, sp, 260
.L4151:
	l32r	a10, .LC1658
	add.n	a10, a3, a10
	s32i	a12, a10, 0
	s32i	a11, a10, 4
	movi.n	a12, 0
	movi.n	a11, 0
	beqz.n	a13, .L4152
	l32i	a12, sp, 264
	l32i	a11, sp, 268
.L4152:
	l32r	a10, .LC1659
	add.n	a10, a3, a10
	s32i	a12, a10, 0
	s32i	a11, a10, 4
.L4174:
	l32r	a10, .LC1609
	l32i	a11, a7, 20
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L4154
	j	.L4153
.L4148:
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_120observeCommunicationERNS_3AppERKN21MotorControlRSExample3Rtu10CompletionE
.L4154:
	call8	_Z18esp_timer_get_timev
	s32i	a10, sp, 272
	l32i	a10, a7, 20
	l8ui	a12, a7, 24
	s32i	a10, sp, 0
	s32i	a11, sp, 276
	l32i	a15, sp, 480
	l32i	a13, a7, 4
	l32i	a11, a7, 8
	l32i	a10, sp, 488
	addi	a14, sp, 96
	call8	_ZN21MotorControlRSExample5Probe7Console11reportProbeEmhmRKNS0_11ProbeResultEPKNS_9HostTupleEm
	beqz.n	a10, .L4156
	movi.n	a10, 1
	s8i	a10, a7, 65
	l32r	a10, .LC1654
	l32i	a12, sp, 272
	l32i	a13, sp, 276
	add.n	a10, a3, a10
	l8ui	a10, a10, 0
	s32i	a12, a7, 48
	s32i	a13, a7, 52
	beqz.n	a10, .L4156
	l32r	a10, .LC1653
	l32i	a11, a7, 4
	add.n	a10, a3, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L4156
	l32r	a10, .LC1657
	add.n	a10, a3, a10
	s32i	a12, a10, 0
	s32i	a13, a10, 4
.L4156:
	l32i	a8, sp, 480
	movi.n	a10, 0x50
	addmi	a10, a10, 0x2300
	add.n	a8, a8, a10
	s32i	a8, sp, 480
	l32i	a8, sp, 484
	add.n	a7, a7, a10
	add.n	a8, a8, a10
	s32i	a8, sp, 484
	add.n	a6, a6, a10
.L4085:
	l32i	a8, sp, 496
	bne	a7, a8, .L4157
	l32r	a6, .LC1661
	add.n	a6, a3, a6
	l32i	a9, a6, 0
	beqz.n	a9, .L4159
	l32r	a7, .LC1662
	add.n	a7, a3, a7
	l8ui	a9, a7, 0
	bnez.n	a9, .L4159
	l32r	a9, .LC1663
	l32r	a10, .LC1597
	add.n	a9, a3, a9
	l32i	a13, a9, 4
	l32i	a12, a9, 0
	add.n	a10, a3, a10
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner14recoveryResultEy
	mov.n	a13, a10
	beqz.n	a10, .L4159
	l32r	a10, .LC1664
	l32r	a9, .LC1666
	add.n	a10, a3, a10
	l32i	a15, a10, 0
	l32r	a14, .LC1665
	l32r	a10, .LC1601
	add.n	a9, a3, a9
	l32i	a12, a6, 0
	l32i	a11, a9, 0
	add.n	a14, a3, a14
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample5Probe7Console14reportRecoveryEmmRKNS_3Rtu14RecoveryResultEPKNS_9HostTupleEm
	beqz.n	a10, .L4159
	movi.n	a9, 1
	s8i	a9, a7, 0
.L4159:
	l32r	a9, .LC1667
	add.n	a9, a3, a9
	l32i	a12, a9, 0
	beqz.n	a12, .L4162
	l32r	a7, .LC1668
	add.n	a7, a3, a7
	l8ui	a9, a7, 0
	bnez.n	a9, .L4162
	l32r	a10, .LC1669
	l32r	a9, .LC1672
	add.n	a10, a3, a10
	l32i	a15, a10, 0
	l32r	a14, .LC1670
	l32r	a13, .LC1671
	l32r	a10, .LC1601
	add.n	a9, a3, a9
	l32i	a11, a9, 0
	add.n	a14, a3, a14
	add.n	a13, a3, a13
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample5Probe7Console14reportRecoveryEmmRKNS_3Rtu14RecoveryResultEPKNS_9HostTupleEm
	beqz.n	a10, .L4162
	movi.n	a9, 1
	s8i	a9, a7, 0
.L4162:
	l32r	a9, .LC1673
	movi	a10, 0x269
	add.n	a9, a3, a9
	slli	a10, a10, 6
	add.n	a10, a9, a10
	s32i	a10, sp, 16
	l32r	a10, .LC1675
	movi.n	a5, 0
	add.n	a10, a9, a10
	s32i	a10, sp, 20
	movi	a10, 0x563
	slli	a10, a10, 5
	add.n	a10, a9, a10
	s32i	a10, sp, 24
	l32r	a10, .LC1677
	addi	a4, sp, 16
	add.n	a10, a9, a10
	s32i	a10, sp, 28
	movi	a10, 0x17d
	slli	a10, a10, 7
	add.n	a9, a9, a10
	s32i	a9, sp, 32
.L4165:
	add.n	a9, a4, a5
	l32i	a7, a9, 0
	l32i	a11, a7, 4
	bnez.n	a11, .L4164
.L4167:
	addi.n	a5, a5, 4
	movi.n	a9, 0x14
	bne	a5, a9, .L4165
	j	.L4285
.L4164:
	l8ui	a9, a7, 12
	bnez.n	a9, .L4167
	addmi	a6, a7, 0x900
	l8ui	a9, a6, 13
	bnez.n	a9, .L4167
	l8ui	a9, a6, 14
	beqz.n	a9, .L4168
.L4170:
	movi.n	a9, 1
	s8i	a9, a6, 13
	movi.n	a6, 0
	j	.L4169
.L4168:
	l32r	a8, .LC1601
	add.n	a2, a3, a8
	mov.n	a10, a2
	call8	_ZNK21MotorControlRSExample5Probe7Console11humanResultEm
	movi.n	a14, -8
	addmi	a14, a14, 0x900
	l32i	a15, a6, 0
	l32i	a12, a7, 4
	l32i	a11, a7, 8
	s8i	a10, a6, 15
	add.n	a14, a7, a14
	mov.n	a13, a7
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7Console11reportGroupEmmRKNS0_11GroupResultEPKNS_9HostTupleEm
	bnez.n	a10, .L4170
	j	.L4167
.L4173:
	addx8	a9, a6, a6
	slli	a9, a9, 4
	add.n	a9, a7, a9
	l32i	a11, a9, 140
	movi	a8, 0x140
	l32i	a9, a9, 252
	add.n	a8, a4, a8
	s32i	a9, a4, 324
	s32i	a11, a4, 320
	movi.n	a9, 0
	s32i	a8, sp, 480
	j	.L4172
.L4180:
	movi.n	a9, 4
.L4172:
	l32i	a8, sp, 480
	s32i	a9, sp, 484
	add.n	a10, a8, a9
	l32i	a11, a10, 0
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	l32i	a9, sp, 484
	mov.n	a2, a10
	beqz.n	a10, .L4171
	addmi	a10, a10, 0x2300
	l8ui	a10, a10, 57
	beqz.n	a10, .L4171
	movi.n	a10, 1
	s8i	a10, a2, 65
	call8	_Z18esp_timer_get_timev
	l32i	a9, sp, 484
	s32i	a10, a2, 48
	s32i	a11, a2, 52
.L4171:
	bnei	a9, 4, .L4180
	addi.n	a6, a6, 1
	extui	a6, a6, 0, 8
.L4169:
	l8ui	a9, a7, 128
	bltu	a6, a9, .L4173
	j	.L4167
.L4285:
	retw.n
.LFE2380:
	.size	_ZN12_GLOBAL__N_17deliverERNS_3AppE, .-_ZN12_GLOBAL__N_17deliverERNS_3AppE
	.literal_position
	.literal .LC1681, 53807
	.literal .LC1682, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1683, 45697
	.literal .LC1684, 45698
	.literal .LC1685, 757624
	.literal .LC1686, _ZN12_GLOBAL__N_14uartE
	.literal .LC1687, 771952
	.literal .LC1688, 764504
	.literal .LC1689, 764516
	.literal .LC1690, 764508
	.literal .LC1691, 757972
	.literal .LC1692, 757960
	.literal .LC1693, 101004
	.literal .LC1695, 101000
	.literal .LC1696, 9040
	.literal .LC1697, .LC4
	.literal .LC1699, 500000
	.literal .LC1701, 45688
	.literal .LC1702, 45700
	.literal .LC1703, 757628
	.align	4
	.type	_ZN12_GLOBAL__N_19startHomeEPvmhRKN14MotorControlRS6ESS_RS11HomeRequestERm, @function
_ZN12_GLOBAL__N_19startHomeEPvmhRKN14MotorControlRS6ESS_RS11HomeRequestERm:
.LFB2166:
	entry	sp, 352
.LCFI176:
	s32i	a6, sp, 312
	movi	a6, 0x7f7
	slli	a6, a6, 5
	extui	a8, a4, 0, 8
	add.n	a4, a2, a6
	l32i	a9, a4, 156
	s32i	a8, sp, 288
	l32i	a8, a4, 152
	s32i	a3, sp, 308
	or	a8, a8, a9
	mov.n	a7, a2
	beqz.n	a8, .L4293
.L4296:
	movi.n	a2, 1
	j	.L4295
.L4293:
	l32r	a8, .LC1681
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L4296
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L4296
	l32r	a8, .LC1682
	l8ui	a8, a8, 0
	bnez.n	a8, .L4297
.L4304:
	movi.n	a2, 3
	j	.L4295
.L4297:
	l32r	a8, .LC1683
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L4298
.L4299:
	movi.n	a2, 2
	j	.L4295
.L4298:
	l32r	a8, .LC1684
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L4299
	l8ui	a8, a4, 137
	bnez.n	a8, .L4299
	l32i	a10, sp, 288
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	beqz.n	a10, .L4300
	l16si	a10, a5, 0
	call8	_ZN14MotorControlRS6ESS_RS10homeMethodENS0_12HomingMethodE
	beqz.n	a10, .L4300
	l8ui	a8, a10, 2
	movi.n	a2, 0xd
	beqi	a8, 2, .L4295
	movi.n	a2, 0xe
	beqi	a8, 1, .L4295
	l32i	a8, a5, 16
	l32i	a9, a5, 20
	movi.n	a2, 0xd
	or	a8, a8, a9
	bnez.n	a8, .L4295
	l32r	a8, .LC1685
	movi.n	a2, 7
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L4295
	add.n	a6, a7, a6
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L4299
	l32r	a4, .LC1686
	mov.n	a10, a4
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L4299
	l32i	a11, sp, 288
	movi.n	a12, 1
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a2, 0xc
	bnez.n	a10, .L4295
	l32i	a8, a6, 52
	bnei	a8, -1, .L4296
	l32i	a6, a6, 48
	bnez.n	a6, .L4296
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a13, a11
	l32i	a11, sp, 288
	mov.n	a12, a10
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy
	bnez.n	a10, .L4296
	l32r	a4, .LC1687
	movi.n	a2, 0xf
	add.n	a8, a7, a4
	l32i	a8, a8, 0
	beqz.n	a8, .L4295
	l32r	a3, .LC1688
	add.n	a4, a7, a4
	add.n	a3, a7, a3
	mov.n	a11, a3
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4295
	l32r	a8, .LC1689
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L4295
	l32i	a9, a4, 12
	bne	a8, a9, .L4295
	l8ui	a8, a4, 16
	beqz.n	a8, .L4295
	l8ui	a8, a4, 17
	beqz.n	a8, .L4295
	l8ui	a8, a4, 18
	beqz.n	a8, .L4295
	l8ui	a8, a4, 28
	beqz.n	a8, .L4295
	l8ui	a8, a4, 29
	beqz.n	a8, .L4295
	l8ui	a8, a4, 32
	beqz.n	a8, .L4295
	l8ui	a8, a4, 34
	beqz.n	a8, .L4295
	l32r	a8, .LC1690
	l32i	a9, sp, 288
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bne	a8, a9, .L4304
	l32r	a8, .LC1691
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L4304
	l32r	a10, .LC1692
	mov.n	a11, a3
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4304
	l32r	a8, .LC1693
	l32r	a10, .LC1696
	add.n	a8, a7, a8
	movi.n	a9, 8
	loop	a9, .L4308_LEND
.L4308:
	l32i	a11, a8, 0
	bnez.n	a11, .L4306
	l32r	a8, .LC1696
	l32r	a9, .LC1695
	mul16u	a8, a6, a8
	l32r	a10, .LC1686
	add.n	a8, a8, a9
	add.n	a4, a7, a8
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a2, a11
	l32r	a11, .LC1687
	addi	a6, sp, 32
	s32i	a10, sp, 292
	movi	a12, 0x78
	add.n	a11, a7, a11
	mov.n	a10, a6
	call8	memcpy
	l32i	a12, sp, 292
	mov.n	a13, a2
	mov.n	a11, a6
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy
	bnez.n	a10, .L4307
	j	.L4304
.L4306:
	addi.n	a6, a6, 1
	add.n	a8, a8, a10
	.L4308_LEND:
	movi.n	a2, 6
	j	.L4295
.L4307:
	movi	a10, 0xc0
	movi.n	a12, 0x18
	mov.n	a11, a5
	add.n	a10, a6, a10
	call8	memcpy
	l32i	a9, sp, 228
	bnez.n	a9, .L4309
	l32r	a9, .LC1689
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	s32i	a9, sp, 228
.L4309:
	l32i	a10, a7, 4
	movi	a5, 0x3e8
	mull	a9, a5, a10
	l32i	a8, sp, 292
	muluh	a5, a5, a10
	add.n	a8, a9, a8
	s32i	a8, sp, 300
	add.n	a5, a5, a2
	bgeu	a8, a9, .L4310
	addi.n	a5, a5, 1
.L4310:
	l32r	a10, .LC1697
	movi	a9, 0xf0
	l32i	a10, a10, 4
	add.n	a9, a6, a9
	s32i	a10, a9, 4
	movi.n	a10, 0x40
	s8i	a10, a9, 4
	movi.n	a10, 0x20
	addmi	a10, a10, 0x4e00
	s32i	a10, a9, 0
	l32r	a10, .LC1699
	movi	a8, 0x60
	s32i	a10, a9, 8
	addmi	a8, a8, 0x1f00
	l32r	a10, .LC1685
	add.n	a8, a4, a8
	s32i	a8, sp, 304
	add.n	a8, a7, a10
	s32i	a8, sp, 296
	l32i	a8, sp, 300
	s32i	a9, sp, 16
	s32i	a8, sp, 8
	l32i	a8, sp, 292
	s32i	a5, sp, 12
	s32i	a8, sp, 0
	l32i	a8, sp, 296
	s32i	a2, sp, 4
	l32i	a12, a8, 0
	l32i	a10, sp, 304
	movi	a13, 0xc0
	mov.n	a11, a3
	mov.n	a14, a6
	add.n	a13, a6, a13
	call8	_ZN14MotorControlRS6ESS_RS11prepareHomeERNS0_11HomeContextERKNS_10AxisConfigEmRKNS0_11HomeRequestERKNS0_17HomePrerequisitesEyyRKNS_13ActionOptionsE
	movi	a9, 0xe4
	add.n	a9, a6, a9
	s32i	a10, a9, 0
	s32i	a11, a9, 4
	s32i	a12, a9, 8
	extui	a3, a10, 0, 8
	beqz.n	a3, .L4311
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a2, 0xb
	beqi	a3, 3, .L4295
.L4300:
	movi.n	a2, 8
	j	.L4295
.L4311:
	addi	a3, a6, 120
	movi.n	a12, 0x48
	movi.n	a11, 0
	mov.n	a10, a3
	call8	memset
	l32i	a12, sp, 292
	l32i	a10, sp, 304
	movi.n	a9, 2
	mov.n	a14, a3
	mov.n	a13, a2
	s8i	a9, sp, 152
	call8	_ZN14MotorControlRS6ESS_RS8nextHomeERKNS0_11HomeContextEyRNS0_12PreparedHomeE
	movi	a9, 0xd8
	add.n	a6, a6, a9
	s32i	a10, a6, 0
	s32i	a11, a6, 4
	s32i	a12, a6, 8
	extui	a10, a10, 0, 8
	beqz.n	a10, .L4313
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a2, 4
	j	.L4295
.L4313:
	l32i	a14, sp, 292
	mov.n	a15, a2
	mov.n	a12, a3
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_113admitHomeStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedHomeEy
	mov.n	a2, a10
	beqz.n	a10, .L4314
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L4295
.L4314:
	l32r	a11, .LC1701
	movi.n	a12, 5
	add.n	a11, a7, a11
	addi.n	a10, a4, 12
	call8	memcpy
	l32r	a9, .LC1702
	l32i	a8, sp, 296
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	movi.n	a11, 1
	s32i	a9, a4, 20
	l32i	a10, a8, 0
	addi.n	a9, a10, 1
	s32i	a9, a8, 0
	l32i	a8, sp, 308
	movi.n	a9, 7
	s32i	a8, a4, 8
	l32i	a8, sp, 288
	s32i	a10, a4, 4
	s8i	a8, a4, 24
	l32i	a8, sp, 300
	s8i	a9, a4, 0
	s32i	a8, a4, 56
	s32i	a5, a4, 60
	addmi	a9, a4, 0x300
	s8i	a11, a9, 8
	l32r	a9, .LC1689
	addmi	a8, a4, 0x1000
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	s32i	a9, a8, 176
	l32r	a8, .LC1703
	add.n	a7, a7, a8
	l32i	a8, sp, 312
	s32i	a10, a7, 0
	s32i	a10, a8, 0
.L4295:
	retw.n
.LFE2166:
	.size	_ZN12_GLOBAL__N_19startHomeEPvmhRKN14MotorControlRS6ESS_RS11HomeRequestERm, .-_ZN12_GLOBAL__N_19startHomeEPvmhRKN14MotorControlRS6ESS_RS11HomeRequestERm
	.literal_position
	.literal .LC1705, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1706, 764508
	.literal .LC1707, 45697
	.literal .LC1708, 45698
	.literal .LC1709, 65248
	.literal .LC1710, _ZN12_GLOBAL__N_14uartE
	.literal .LC1711, 53807
	.literal .LC1712, 770856
	.literal .LC1713, 770860
	.literal .LC1714, 771168
	.literal .LC1715, 771250
	.literal .LC1716, 626184
	.literal .LC1717, 757624
	.literal .LC1718, 772492
	.literal .LC1719, 764516
	.literal .LC1720, 101004
	.literal .LC1721, 9040
	.literal .LC1723, 105280
	.literal .LC1724, 764504
	.literal .LC1726, 101000
	.literal .LC1727, 105324
	.literal .LC1728, 105326
	.literal .LC1729, 109024
	.literal .LC1730, 109026
	.literal .LC1731, 101776
	.literal .LC1732, 45688
	.literal .LC1733, 101020
	.literal .LC1734, 45700
	.literal .LC1735, 101008
	.literal .LC1736, 101024
	.literal .LC1737, 105272
	.literal .LC1738, 101056
	.literal .LC1739, 106904
	.literal .LC1740, 757628
	.literal .LC1741, 772456
	.literal .LC1742, .LC12
	.literal .LC1744, 763048
	.literal .LC1745, 760208
	.literal .LC1746, 762096
	.literal .LC1747, 759264
	.literal .LC1748, 759736
	.literal .LC1749, 758792
	.literal .LC1750, 625320
	.literal .LC1751, 764496
	.literal .LC1752, 757972
	.literal .LC1753, 757960
	.literal .LC1754, 757988
	.literal .LC1755, 758044
	.literal .LC1756, 625608
	.literal .LC1757, 625896
	.literal .LC1758, 758244
	.literal .LC1759, 758844
	.literal .LC1760, 625656
	.literal .LC1761, 757994
	.literal .LC1763, 136912
	.literal .LC1764, 763648
	.literal .LC1765, 625648
	.literal .LC1766, 762568
	.literal .LC1767, 763096
	.literal .LC1768, 762572
	.literal .LC1770, 762573
	.literal .LC1772, C$509$0
	.literal .LC1773, 757792
	.literal .LC1774, 757808
	.literal .LC1775, 2707178
	.literal .LC1776, 20261113
	.literal .LC1777, 764168
	.literal .LC1778, 757896
	.literal .LC1779, 757912
	.literal .LC1781, 759280
	.literal .LC1782, 759268
	.literal .LC1783, 759284
	.literal .LC1784, 759302
	.literal .LC1785, 759304
	.literal .LC1786, 759356
	.literal .LC1787, 759740
	.literal .LC1788, 760232
	.literal .LC1789, 771808
	.literal .LC1790, 771332
	.literal .LC1791, 3000000
	.literal .LC1792, 500000
	.literal .LC1793, 763816
	.literal .LC1794, 763304
	.align	4
	.type	_ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm, @function
_ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm:
.LFB2201:
	entry	sp, 288
.LCFI177:
	extui	a8, a4, 0, 8
	s32i	a8, sp, 208
	mov.n	a10, a2
	extui	a8, a5, 0, 8
	s32i	a3, sp, 236
	s32i	a7, sp, 240
	mov.n	a3, a6
	s32i	a8, sp, 200
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L4358
	l8ui	a9, a6, 0
	addi	a10, a9, -10
	extui	a10, a10, 0, 8
	bgeui	a10, 2, .L4359
	bnei	a9, 10, .L4360
	l16ui	a8, a6, 12
	j	.L4664
.L4360:
	l16ui	a8, a6, 14
.L4664:
	s32i	a8, sp, 196
	l32i	a8, sp, 200
	bnei	a8, 1, .L4489
	l32i	a10, a3, 4
	bnei	a10, 1, .L4489
	movi.n	a10, 0xb
	bnei	a9, 10, .L4363
	movi	a10, 0xb8
	addmi	a10, a10, 0xb00
.L4363:
	l32i	a8, sp, 196
	blt	a10, a8, .L4489
	l32r	a9, .LC1705
	l8ui	a9, a9, 0
	bnez.n	a9, .L4364
.L4369:
	movi.n	a8, 3
	j	.L4665
.L4364:
	l32r	a9, .LC1706
	l32i	a8, sp, 208
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bne	a9, a8, .L4369
	mov.n	a10, a8
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	beqz.n	a10, .L4369
	l32r	a9, .LC1707
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L4366
.L4367:
	movi.n	a8, 2
	j	.L4665
.L4366:
	l32r	a9, .LC1708
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4367
	l32r	a6, .LC1709
	add.n	a5, a2, a6
	l8ui	a9, a5, 137
	bnez.n	a9, .L4367
	mov.n	a10, a5
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L4367
	l32r	a7, .LC1710
	mov.n	a10, a7
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L4367
	l32i	a9, a5, 152
	l32i	a10, a5, 156
	or	a9, a9, a10
	bnez.n	a9, .L4362
	l32r	a9, .LC1711
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4362
	l32i	a9, a5, 52
	mov.n	a6, a5
	bnei	a9, -1, .L4362
	l32i	a5, a5, 48
	bnez.n	a5, .L4362
	l32r	a10, .LC1712
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4362
	l32r	a10, .LC1713
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4362
	l32r	a10, .LC1714
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	bnez.n	a10, .L4362
	l32r	a10, .LC1715
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4362
	l32r	a10, .LC1716
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4362
	l32i	a11, sp, 208
	movi.n	a12, 1
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a8, 0xc
	s32i	a8, sp, 200
	bnez.n	a10, .L4362
	l32r	a10, .LC1717
	movi.n	a8, 7
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a8, sp, 200
	beqz.n	a10, .L4362
	l32i	a8, sp, 208
	l32r	a11, .LC1718
	srli	a10, a8, 3
	add.n	a10, a2, a10
	add.n	a10, a10, a11
	l8ui	a11, a10, 0
	extui	a10, a8, 0, 3
	bbc	a11, a10, .L4369
	l32i	a11, a3, 8
	beqz.n	a11, .L4370
	l32r	a10, .LC1719
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	bne	a11, a10, .L4369
.L4370:
	l32r	a10, .LC1720
	l32r	a12, .LC1721
	add.n	a10, a2, a10
	movi.n	a11, 8
	loop	a11, .L4374_LEND
.L4374:
	l32i	a13, a10, 0
	bnez.n	a13, .L4372
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	s32i	a10, sp, 192
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a2
	mov.n	a6, a11
	call8	_ZN12_GLOBAL__N_119singleSettingPolicyERNS_3AppEy
	bnez.n	a10, .L4373
	j	.L4369
.L4372:
	addi.n	a5, a5, 1
	add.n	a10, a10, a12
	.L4374_LEND:
	movi.n	a8, 6
	j	.L4665
.L4373:
	l32r	a7, .LC1721
	l32r	a4, .LC1723
	mul16u	a7, a5, a7
	movi.n	a13, 1
	add.n	a4, a7, a4
	add.n	a8, a2, a4
	s32i	a13, sp, 12
	l8ui	a13, a3, 0
	l32r	a15, .LC1791
	s32i	a8, sp, 200
	l32i	a8, sp, 192
	l32r	a12, .LC1719
	l32r	a10, .LC1717
	l32r	a11, .LC1724
	s32i	a13, sp, 8
	add.n	a14, a8, a15
	add.n	a12, a2, a12
	add.n	a10, a2, a10
	add.n	a11, a2, a11
	mov.n	a13, a6
	bgeu	a14, a15, .L4375
	addi.n	a13, a6, 1
.L4375:
	s32i	a14, sp, 0
	s32i	a13, sp, 4
	l32i	a13, a12, 0
	l32i	a14, sp, 192
	l32i	a12, a10, 0
	l32i	a10, sp, 200
	mov.n	a15, a6
	call8	_ZN14MotorControlRS6ESS_RS17prepareDriverReadERNS0_13DriverContextERKNS_10ReadTargetEmmyyNS0_11DriverGroupEh
	s32i	a10, sp, 164
	s32i	a11, sp, 168
	s32i	a12, sp, 172
	extui	a10, a10, 0, 8
	beqz.n	a10, .L4376
	movi	a10, 0xa4
	add.n	a10, sp, a10
	call8	_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE
	s32i	a10, sp, 200
	j	.L4362
.L4376:
	l32r	a10, .LC1721
	l16ui	a11, a3, 12
	mull	a9, a5, a10
	l32r	a10, .LC1727
	add.n	a4, a2, a9
	add.n	a10, a4, a10
	s16i	a11, a10, 0
	l32r	a10, .LC1728
	l16ui	a11, a3, 14
	l32r	a8, .LC1726
	add.n	a10, a4, a10
	s16i	a11, a10, 0
	movi.n	a12, 0x30
	movi.n	a11, 0
	addi	a10, sp, 16
	add.n	a7, a7, a8
	call8	memset
	movi.n	a10, 2
	s8i	a10, sp, 16
	l32i	a12, sp, 192
	l32i	a10, sp, 200
	addi	a14, sp, 16
	mov.n	a13, a6
	call8	_ZN14MotorControlRS6ESS_RS10nextDriverERKNS0_13DriverContextEyRNS0_14PreparedDriverE
	s32i	a10, sp, 152
	s32i	a11, sp, 156
	s32i	a12, sp, 160
	extui	a10, a10, 0, 8
	add.n	a7, a2, a7
	beqz.n	a10, .L4378
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a8, 4
	j	.L4665
.L4378:
	l32i	a14, sp, 192
	mov.n	a15, a6
	addi	a12, sp, 16
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115admitDriverStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedDriverEy
	s32i	a10, sp, 200
	beqz.n	a10, .L4379
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L4362
.L4379:
	l32r	a8, .LC1726
	movi.n	a10, 6
	add.n	a3, a4, a8
	s8i	a10, a3, 0
	l32r	a10, .LC1729
	movi.n	a11, 1
	add.n	a10, a4, a10
	s8i	a11, a10, 0
	l32r	a10, .LC1730
	l32i	a8, sp, 196
	add.n	a10, a4, a10
	s16i	a8, a10, 0
	l32r	a10, .LC1731
	movi.n	a12, 5
	add.n	a10, a4, a10
	s8i	a11, a10, 0
	l32r	a11, .LC1732
	addi.n	a10, a7, 12
	add.n	a11, a2, a11
	call8	memcpy
	l32r	a11, .LC1734
	l32r	a10, .LC1733
	add.n	a11, a2, a11
	l32i	a11, a11, 0
	add.n	a10, a4, a10
	s32i	a11, a10, 0
	l32r	a10, .LC1717
	l32i	a8, sp, 236
	add.n	a10, a2, a10
	l32i	a12, a10, 0
	l32r	a13, .LC1738
	addi.n	a11, a12, 1
	s32i	a11, a10, 0
	l32r	a10, .LC1720
	l32r	a11, .LC1719
	add.n	a10, a4, a10
	s32i	a12, a10, 0
	l32r	a10, .LC1735
	add.n	a11, a2, a11
	add.n	a10, a4, a10
	s32i	a8, a10, 0
	l32r	a10, .LC1736
	l32i	a8, sp, 208
	add.n	a10, a4, a10
	s8i	a8, a10, 0
	l32r	a10, .LC1737
	l32i	a11, a11, 0
	add.n	a10, a4, a10
	s32i	a11, a10, 0
	l32r	a10, .LC1739
	add.n	a13, a4, a13
	add.n	a9, a4, a10
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	l32r	a9, .LC1740
	s32i	a10, a13, 0
	s32i	a11, a13, 4
	add.n	a8, a2, a9
	s32i	a12, a8, 0
	l32i	a8, sp, 240
	s32i	a12, a8, 0
	j	.L4362
.L4489:
	movi.n	a8, 8
.L4665:
	s32i	a8, sp, 200
.L4362:
	l32i	a5, sp, 200
	j	.L4380
.L4359:
	l32r	a7, .LC1709
	add.n	a10, a2, a7
	l32i	a11, a10, 152
	l32i	a12, a10, 156
	or	a11, a11, a12
	bnez.n	a11, .L4358
	l32r	a11, .LC1711
	add.n	a11, a2, a11
	l8ui	a11, a11, 0
	bnez.n	a11, .L4358
	movi.n	a11, 9
	bgeu	a11, a9, .L4381
.L4385:
	movi.n	a5, 8
	j	.L4380
.L4381:
	l32r	a9, .LC1705
	l8ui	a9, a9, 0
	beqz.n	a9, .L4382
	l32r	a9, .LC1707
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L4383
.L4384:
	movi.n	a5, 2
	j	.L4380
.L4383:
	l32r	a9, .LC1708
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4384
	l8ui	a9, a10, 137
	bnez.n	a9, .L4384
	l32i	a10, sp, 208
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	s32i	a10, sp, 216
	beqz.n	a10, .L4385
	l32r	a9, .LC1717
	movi.n	a5, 7
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L4380
	add.n	a7, a2, a7
	mov.n	a10, a7
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L4384
	l32r	a6, .LC1710
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L4384
	l32i	a11, sp, 208
	movi.n	a12, 1
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a5, 0xc
	bnez.n	a10, .L4380
	l32i	a8, sp, 200
	bnei	a8, 1, .L4386
	l32i	a9, a7, 52
	bnei	a9, -1, .L4358
	l32i	a9, a7, 48
	beqz.n	a9, .L4387
.L4358:
	movi.n	a5, 1
	j	.L4380
.L4387:
	l32r	a9, .LC1706
	l32i	a8, sp, 208
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	beq	a9, a8, .L4386
.L4382:
	movi.n	a5, 3
	j	.L4380
.L4386:
	l32r	a9, .LC1720
	movi.n	a8, 0
	l32r	a11, .LC1721
	add.n	a9, a2, a9
	s32i	a8, sp, 220
	movi.n	a10, 8
	loop	a10, .L4391_LEND
.L4391:
	l32i	a8, a9, 0
	s32i	a8, sp, 228
	bnez.n	a8, .L4388
	l32r	a9, .LC1721
	l32i	a8, sp, 220
	mov.n	a10, a6
	mul16u	a8, a8, a9
	s32i	a8, sp, 224
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32r	a9, .LC1741
	l32i	a8, sp, 208
	add.n	a9, a2, a9
	s8i	a8, sp, 180
	s32i	a8, sp, 176
	l32i	a8, a9, 0
	l32r	a9, .LC1706
	s32i	a8, sp, 204
	add.n	a9, a2, a9
	s32i	a8, sp, 184
	l8ui	a9, a9, 0
	l32i	a8, sp, 208
	s32i	a10, sp, 196
	s32i	a11, sp, 192
	bne	a9, a8, .L4390
	j	.L4389
.L4388:
	l32i	a8, sp, 220
	add.n	a9, a9, a11
	addi.n	a8, a8, 1
	s32i	a8, sp, 220
	.L4391_LEND:
	movi.n	a5, 6
	j	.L4380
.L4389:
	l32r	a9, .LC1719
	add.n	a9, a2, a9
	l32i	a8, a9, 0
	s32i	a8, sp, 204
.L4390:
	movi.n	a9, 0
	s8i	a9, sp, 164
	movi.n	a9, 0
	s32i	a9, sp, 168
	l32r	a9, .LC1742
	l32i	a8, sp, 200
	s32i	a9, sp, 172
	bnez.n	a8, .L4392
	l32r	a9, .LC1792
	l32i	a8, sp, 196
	l8ui	a10, a3, 0
	add.n	a4, a8, a9
	l32i	a5, sp, 192
	bgeu	a4, a9, .L4393
	addi.n	a5, a5, 1
.L4393:
	l32r	a7, .LC1723
	l32i	a8, sp, 224
	addi	a9, a10, -2
	add.n	a7, a8, a7
	extui	a9, a9, 0, 8
	l32r	a6, .LC1717
	add.n	a7, a2, a7
	bgeui	a9, 3, .L4394
	add.n	a6, a2, a6
	l32i	a12, a6, 0
	movi.n	a9, 0
	beqi	a10, 2, .L4395
	movi.n	a9, 2
	bnei	a10, 3, .L4395
	movi.n	a9, 1
.L4395:
	l8ui	a10, a3, 66
	l32i	a14, sp, 196
	l32i	a15, sp, 192
	l32i	a13, sp, 204
	movi	a11, 0xb0
	s32i	a10, sp, 12
	s32i	a9, sp, 8
	s32i	a4, sp, 0
	s32i	a5, sp, 4
	add.n	a11, sp, a11
	mov.n	a10, a7
	call8	_ZN14MotorControlRS6ESS_RS18prepareSegmentReadERNS0_13DriverContextERKNS_10ReadTargetEmmyyNS0_11SegmentKindEh
	j	.L4666
.L4394:
	bnei	a10, 5, .L4397
	add.n	a6, a2, a6
	s32i	a4, sp, 0
	s32i	a5, sp, 4
	l32i	a14, sp, 196
	l32i	a15, sp, 192
	l32i	a13, sp, 204
	l32i	a12, a6, 0
	movi	a11, 0xb0
	add.n	a11, sp, a11
	mov.n	a10, a7
	call8	_ZN14MotorControlRS6ESS_RS18prepareControlReadERNS0_13DriverContextERKNS_10ReadTargetEmmyy
	j	.L4666
.L4397:
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	add.n	a6, a2, a6
	l32i	a12, a6, 0
	l8ui	a11, a3, 0
	addi	a9, sp, 16
	beqz.n	a10, .L4398
	s32i	a11, sp, 8
	l32i	a14, sp, 196
	l32i	a15, sp, 192
	l32i	a13, sp, 204
	movi	a11, 0xa0
	s32i	a4, sp, 0
	s32i	a5, sp, 4
	add.n	a11, a9, a11
	mov.n	a10, a7
	call8	_ZN14MotorControlRS6ESS_RS17prepareTuningReadERNS0_13DriverContextERKNS_10ReadTargetEmmyyNS0_11DriverGroupE
	j	.L4666
.L4398:
	movi.n	a10, 1
	s32i	a11, sp, 8
	l32i	a14, sp, 196
	movi	a11, 0xa0
	l32i	a15, sp, 192
	l32i	a13, sp, 204
	s32i	a10, sp, 12
	s32i	a4, sp, 0
	s32i	a5, sp, 4
	add.n	a11, a9, a11
	mov.n	a10, a7
	call8	_ZN14MotorControlRS6ESS_RS17prepareDriverReadERNS0_13DriverContextERKNS_10ReadTargetEmmyyNS0_11DriverGroupEh
.L4666:
	s32i	a10, sp, 16
	l32i	a10, sp, 16
	movi	a9, 0xa4
	add.n	a9, sp, a9
	s32i	a11, sp, 20
	s32i	a10, a9, 0
	l32i	a10, sp, 20
	s32i	a12, sp, 24
	s32i	a10, a9, 4
	l32i	a10, sp, 24
	s32i	a10, a9, 8
	j	.L4399
.L4392:
	l32i	a8, sp, 200
	bnei	a8, 1, .L4385
	l32r	a9, .LC1744
	movi	a12, 0x5a8
	add.n	a8, a2, a9
	movi.n	a11, 0
	mov.n	a10, a8
	s32i	a8, sp, 212
	call8	memset
	l32i	a10, sp, 212
	call8	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC1Ev
	l8ui	a10, a3, 0
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	l8ui	a9, a3, 0
	beqz.n	a10, .L4401
	addi	a9, a9, -6
	slli	a11, a9, 4
	sub	a11, a11, a9
	subx4	a11, a11, a9
	l32r	a9, .LC1745
	addx8	a11, a11, a9
	j	.L4667
.L4401:
	addi	a10, a9, -2
	extui	a10, a10, 0, 8
	l32r	a11, .LC1746
	bltui	a10, 3, .L4667
.L4403:
	l32r	a11, .LC1747
	beqi	a9, 1, .L4667
.L4404:
	l32r	a11, .LC1748
	beqi	a9, 5, .L4667
.L4405:
	l32r	a11, .LC1749
.L4667:
	l32r	a7, .LC1744
	add.n	a11, a2, a11
	add.n	a7, a2, a7
	movi	a12, 0x1d8
	addi.n	a10, a7, 8
	call8	memcpy
	l32i	a8, sp, 204
	movi	a11, 0xa0
	s32i	a8, a7, 0
	addi	a8, sp, 16
	add.n	a11, a8, a11
	l32i	a10, a11, 0
	movi	a9, 0x1e4
	add.n	a9, a7, a9
	l32i	a12, a11, 4
	s32i	a10, a9, 0
	l32i	a10, a11, 8
	s32i	a12, a9, 4
	s32i	a10, a9, 8
	l32i	a9, a2, 0
	l32r	a6, .LC1750
	movi	a5, 0x3e8
	mull	a4, a5, a9
	muluh	a5, a5, a9
	add.n	a6, a2, a6
	l32i	a12, sp, 196
	l32i	a13, sp, 192
	s32i	a4, a7, 520
	s32i	a5, a7, 524
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	addmi	a9, a7, 0x100
	s8i	a10, a9, 224
	l16ui	a10, a6, 22
	l32i	a11, a6, 244
	s16i	a10, a7, 496
	l16ui	a10, a6, 24
	movi	a12, 0x88
	s16i	a10, a7, 498
	l32i	a10, a6, 240
	s32i	a11, a7, 508
	s32i	a10, a7, 504
	l32i	a10, a6, 248
	l32i	a11, a6, 252
	s32i	a10, a7, 512
	l32r	a10, .LC1751
	s32i	a11, a7, 516
	add.n	a10, a2, a10
	l8ui	a7, a10, 0
	mov.n	a11, a3
	s8i	a7, a9, 225
	addi	a10, sp, 16
	call8	memcpy
	l32i	a9, sp, 24
	bnez.n	a9, .L4406
	l32i	a8, sp, 204
	s32i	a8, sp, 24
.L4406:
	l8ui	a9, sp, 16
	bnez.n	a9, .L4407
	l32i	a9, sp, 20
	bnei	a9, 2, .L4408
	l32r	a9, .LC1752
	movi.n	a10, 0
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L4409
	l32r	a10, .LC1753
	movi	a3, 0xb0
	add.n	a3, sp, a3
	mov.n	a11, a3
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4409
	l32r	a9, .LC1754
	movi.n	a10, 0
	add.n	a9, a2, a9
	l16ui	a9, a9, 0
	bnez.n	a9, .L4409
	l32r	a9, .LC1755
	add.n	a9, a2, a9
	l16ui	a9, a9, 0
	bnez.n	a9, .L4409
	l32r	a6, .LC1756
	l32i	a12, sp, 196
	add.n	a6, a2, a6
	l32i	a13, sp, 192
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a11, a3
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L4409
	l16ui	a9, a6, 44
	movi.n	a10, 0
	bnez.n	a9, .L4409
	l32r	a6, .LC1757
	l32i	a12, sp, 196
	add.n	a6, a2, a6
	l32i	a13, sp, 192
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a11, a3
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L4409
	l16ui	a10, a6, 58
	nsau	a10, a10
	srli	a10, a10, 5
.L4409:
	l32r	a9, .LC1758
	l32r	a13, .LC1759
	add.n	a9, a2, a9
	add.n	a13, a2, a13
	j	.L4410
.L4417:
	beqz.n	a10, .L4411
	l8ui	a10, a9, 0
	beqz.n	a10, .L4411
	l8ui	a11, a9, 48
	bnez.n	a11, .L4501
	l32i	a11, a9, 16
	l32i	a8, sp, 192
	l32i	a12, a9, 12
	bltu	a8, a11, .L4501
	bne	a11, a8, .L4523
	l32i	a8, sp, 196
	bltu	a8, a12, .L4501
.L4523:
	or	a14, a4, a5
	beqz.n	a14, .L4411
	l32i	a8, sp, 192
	sub	a11, a8, a11
	l32i	a8, sp, 196
	bgeu	a8, a12, .L4414
	addi.n	a11, a11, -1
.L4414:
	l32i	a8, sp, 196
	movi.n	a10, 1
	sub	a12, a8, a12
	bltu	a11, a5, .L4415
	bne	a5, a11, .L4416
	bltu	a12, a4, .L4415
.L4416:
	movi.n	a10, 0
.L4415:
	extui	a10, a10, 0, 8
	j	.L4411
.L4501:
	movi.n	a10, 0
.L4411:
	addi	a9, a9, 120
.L4410:
	bne	a9, a13, .L4417
	l32r	a9, .LC1760
	l32r	a11, .LC1761
	l32r	a13, .LC1763
	add.n	a9, a2, a9
	add.n	a11, a2, a11
	movi.n	a12, 4
	loop	a12, .L4419_LEND
.L4419:
	beqz.n	a10, .L4418
	add.n	a14, a9, a13
	l8ui	a14, a14, 0
	bnei	a14, 1, .L4503
	l16ui	a14, a11, 0
	bgeui	a14, 4, .L4503
	beqz.n	a14, .L4418
	l8ui	a10, a9, 0
	movi.n	a14, 1
	xor	a10, a10, a14
	extui	a10, a10, 0, 8
	j	.L4418
.L4503:
	movi.n	a10, 0
.L4418:
	addi.n	a9, a9, 1
	addi.n	a11, a11, 2
	.L4419_LEND:
	l32r	a9, .LC1794
	or	a7, a7, a10
	add.n	a9, a2, a9
	s8i	a7, a9, 225
	j	.L4408
.L4407:
	bnei	a9, 1, .L4408
	l32r	a7, .LC1744
	l32r	a6, .LC1756
	add.n	a7, a2, a7
	addi	a8, sp, 16
	movi	a3, 0xa0
	add.n	a3, a8, a3
	add.n	a6, a2, a6
	l32i	a12, sp, 196
	l32i	a13, sp, 192
	addmi	a10, a7, 0x100
	s8i	a9, a10, 225
	mov.n	a14, a4
	mov.n	a15, a5
	mov.n	a11, a3
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	addmi	a9, a7, 0x200
	l32i	a11, a3, 0
	s8i	a10, a9, 70
	s32i	a11, a7, 584
	l32i	a11, a3, 8
	l32i	a12, a3, 4
	s32i	a11, a7, 592
	l32r	a11, .LC1765
	l32i	a8, sp, 204
	l32r	a10, .LC1764
	add.n	a11, a2, a11
	l32i	a11, a11, 0
	l32i	a13, a6, 244
	s32i	a12, a7, 588
	s32i	a8, a7, 596
	l32i	a12, a6, 240
	add.n	a10, a2, a10
	s32i	a11, a10, 0
	s32i	a12, a7, 608
	s32i	a13, a7, 612
	l32i	a10, a6, 248
	l32i	a11, a6, 252
	movi	a12, 0x88
	s32i	a10, a7, 616
	s32i	a11, a7, 620
	addi	a10, a9, 120
	addi	a11, sp, 16
	call8	memcpy
	l32r	a11, .LC1767
	l32r	a12, .LC1766
	add.n	a11, a2, a11
	addi	a10, sp, 16
	l32i	a9, sp, 20
	add.n	a12, a2, a12
	mov.n	a15, a10
	mov.n	a7, a11
	movi.n	a6, 0xa
	movi	a3, 0x420
	movi.n	a8, 1
	movi.n	a14, 4
	loop	a14, .L4421_LEND
.L4421:
	l8ui	a13, a12, 0
	add.n	a5, a12, a3
	s8i	a13, a5, 0
	ssl	a6
	sll	a4, a8
	bnone	a4, a9, .L4420
	bnei	a13, 1, .L4420
	l16ui	a13, a7, 0
	bgeui	a13, 4, .L4420
	l16ui	a13, a15, 48
	bgeui	a13, 4, .L4420
	l32r	a13, .LC1744
	add.n	a13, a2, a13
	l32i	a5, a13, 624
	or	a5, a5, a4
	s32i	a5, a13, 624
.L4420:
	addi.n	a12, a12, 1
	addi.n	a6, a6, 1
	addi.n	a7, a7, 2
	addi.n	a15, a15, 2
	.L4421_LEND:
	bbci	a9, 9, .L4422
	l32r	a12, .LC1744
	l16ui	a13, sp, 76
	add.n	a12, a2, a12
	l16ui	a12, a12, 46
	l32i	a14, sp, 216
	xor	a13, a13, a12
	l32r	a5, .LC1766
	extui	a13, a13, 0, 16
	movi.n	a12, 0
	movi.n	a7, 4
	loop	a7, .L4426_LEND
.L4426:
	bbc	a13, a12, .L4423
	addi.n	a15, a12, 10
	bbc	a9, a15, .L4424
	l16ui	a4, a10, 48
	j	.L4425
.L4424:
	l16ui	a4, a11, 0
.L4425:
	add.n	a15, a12, a5
	add.n	a15, a2, a15
	l8ui	a15, a15, 0
	bnei	a15, 1, .L4504
	l16ui	a6, a11, 0
	or	a6, a4, a6
	movi.n	a4, 0
	movnez	a15, a4, a6
	and	a14, a14, a15
	j	.L4423
.L4504:
	movi.n	a14, 0
.L4423:
	addi.n	a12, a12, 1
	addi.n	a11, a11, 2
	addi.n	a10, a10, 2
	.L4426_LEND:
	beqz.n	a14, .L4422
	l32r	a10, .LC1744
	movi	a12, 0x200
	add.n	a10, a2, a10
	l32i	a11, a10, 624
	or	a11, a11, a12
	s32i	a11, a10, 624
.L4422:
	l32r	a10, .LC1768
	add.n	a10, a2, a10
	l8ui	a11, a10, 0
	l32r	a10, .LC1744
	add.n	a10, a2, a10
	addmi	a12, a10, 0x200
	s8i	a11, a12, 68
	bnei	a11, 1, .L4427
	l32i	a11, a10, 624
	extui	a12, a9, 15, 1
	slli	a12, a12, 15
	or	a11, a11, a12
	s32i	a11, a10, 624
.L4427:
	l32r	a10, .LC1770
	add.n	a10, a2, a10
	l8ui	a11, a10, 0
	l32r	a10, .LC1744
	add.n	a10, a2, a10
	addmi	a12, a10, 0x200
	s8i	a11, a12, 69
	bnei	a11, 1, .L4428
	l32i	a11, a10, 624
	extui	a9, a9, 16, 1
	slli	a9, a9, 16
	or	a9, a11, a9
	s32i	a9, a10, 624
	j	.L4428
.L4434:
	add.n	a9, a6, a7
	l8ui	a3, a9, 0
	movi.n	a11, 0
	mov.n	a10, a3
	call8	_ZN14MotorControlRS6ESS_RS13driverFieldAtEhNS0_11DriverGroupE
	l16ui	a11, sp, 80
	bnei	a3, 12, .L4430
	l16ui	a11, sp, 78
.L4430:
	addx2	a3, a3, a4
	l16ui	a9, a3, 32
	xor	a11, a11, a9
	l32i	a9, sp, 216
	bbci	a11, 0, .L4431
	l8ui	a9, a5, 0
	addi.n	a9, a9, -1
	nsau	a9, a9
	srli	a9, a9, 5
.L4431:
	bbci	a11, 1, .L4432
	l32r	a11, .LC1770
	add.n	a11, a2, a11
	l8ui	a11, a11, 0
	bnei	a11, 1, .L4433
.L4432:
	beqz.n	a9, .L4433
	l32r	a9, .LC1744
	l32i	a11, sp, 20
	add.n	a9, a2, a9
	and	a10, a10, a11
	l32i	a11, a9, 624
	or	a10, a10, a11
	s32i	a10, a9, 624
.L4433:
	addi.n	a9, a6, 1
	movi.n	a6, 1
	bnei	a9, 2, .L4434
	j	.L4655
.L4428:
	l32r	a4, .LC1744
	l32r	a5, .LC1768
	l32r	a7, .LC1772
	movi.n	a6, 0
	add.n	a4, a2, a4
	add.n	a5, a2, a5
	j	.L4434
.L4655:
	l32r	a9, .LC1793
	add.n	a9, a2, a9
	s8i	a6, a9, 0
.L4408:
	l8ui	a10, sp, 16
	bnei	a10, 5, .L4436
.L4439:
	l32r	a7, .LC1744
	l32r	a11, .LC1773
	add.n	a7, a2, a7
	movi	a10, 0x3b0
	movi	a12, 0xa8
	add.n	a11, a2, a11
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a9, .LC1774
	l32r	a10, .LC1775
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	addmi	a6, a7, 0x400
	sub	a9, a9, a10
	nsau	a9, a9
	srli	a9, a9, 5
	s8i	a9, a6, 88
	l32r	a9, .LC1776
	l8ui	a8, sp, 16
	s32i	a9, a6, 92
	l32r	a9, .LC1777
	s32i	a8, sp, 232
	add.n	a9, a2, a9
	s32i	a10, a9, 0
	bnei	a8, 5, .L4656
	j	.L4437
.L4436:
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	bnez.n	a10, .L4439
	j	.L4440
.L4437:
	addi	a11, sp, 16
	movi	a12, 0x88
	addi	a10, a6, 112
	call8	memcpy
	l32r	a9, .LC1778
	addmi	a7, a7, 0x500
	add.n	a9, a2, a9
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	l32r	a9, .LC1779
	s32i	a10, a6, 248
	s32i	a11, a6, 252
	add.n	a9, a2, a9
	l32i	a10, a9, 0
	l32i	a11, a9, 4
	l32i	a9, sp, 20
	s32i	a10, a7, 0
	extui	a9, a9, 30, 1
	s32i	a11, a7, 4
	slli	a9, a9, 30
	s32i	a9, a6, 108
	j	.L4441
.L4656:
	l32i	a8, a7, 520
	l32r	a6, .LC1756
	l32i	a4, a7, 524
	s32i	a8, sp, 216
	movi	a9, 0xa0
	addi	a8, sp, 16
	add.n	a5, a8, a9
	l32i	a14, sp, 216
	l32i	a12, sp, 196
	l32i	a13, sp, 192
	add.n	a6, a2, a6
	mov.n	a15, a4
	mov.n	a11, a5
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	mov.n	a7, a10
	beqz.n	a10, .L4442
	l16ui	a9, a6, 40
	movi.n	a7, 0
	bnez.n	a9, .L4442
	l32r	a9, .LC1781
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L4442
	l32r	a9, .LC1747
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnei	a9, 1, .L4442
	l32r	a10, .LC1782
	mov.n	a11, a5
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a7, a10
	beqz.n	a10, .L4442
	l32r	a9, .LC1783
	l32i	a8, sp, 204
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	movi.n	a7, 0
	bne	a9, a8, .L4442
	l32r	a9, .LC1784
	movi.n	a7, 0xf
	add.n	a9, a2, a9
	l16ui	a9, a9, 0
	saltu	a7, a7, a9
	addi.n	a7, a7, -1
	neg	a7, a7
	extui	a7, a7, 0, 8
.L4442:
	l32r	a9, .LC1756
	l32r	a10, .LC1785
	add.n	a9, a2, a9
	l32i	a8, a9, 240
	l32i	a5, a9, 244
	l32i	a3, a9, 248
	l32i	a6, a9, 252
	l32r	a9, .LC1766
	add.n	a10, a2, a10
	add.n	a9, a2, a9
	movi.n	a11, 4
	loop	a11, .L4444_LEND
.L4444:
	beqz.n	a7, .L4443
	l8ui	a12, a9, 0
	movi.n	a7, 0
	bnei	a12, 1, .L4443
	l16ui	a12, a10, 0
	movi.n	a7, 3
	saltu	a7, a7, a12
	addi.n	a7, a7, -1
	neg	a7, a7
	extui	a7, a7, 0, 8
.L4443:
	addi.n	a10, a10, 2
	addi.n	a9, a9, 1
	.L4444_LEND:
	l32r	a9, .LC1786
	l32r	a13, .LC1787
	add.n	a9, a2, a9
	add.n	a13, a2, a13
	j	.L4445
.L4457:
	l16ui	a10, a9, 0
	beqz.n	a10, .L4446
	l32i	a11, a9, 36
	l32i	a10, a9, 40
	beqz.n	a7, .L4447
	l8ui	a7, a9, 34
	beqz.n	a7, .L4447
	l8ui	a7, a9, 33
	beqz.n	a7, .L4447
	l8ui	a12, a9, 72
	bnez.n	a12, .L4512
	l32i	a12, sp, 192
	bltu	a12, a10, .L4512
	bne	a10, a12, .L4524
	l32i	a12, sp, 196
	bltu	a12, a11, .L4512
.L4524:
	l32i	a12, sp, 216
	or	a12, a12, a4
	beqz.n	a12, .L4447
	l32i	a12, sp, 192
	l32i	a14, sp, 196
	sub	a12, a12, a10
	bgeu	a14, a11, .L4450
	addi.n	a12, a12, -1
.L4450:
	l32i	a14, sp, 196
	movi.n	a7, 1
	sub	a14, a14, a11
	bltu	a12, a4, .L4451
	bne	a4, a12, .L4452
	l32i	a12, sp, 216
	bltu	a14, a12, .L4451
.L4452:
	movi.n	a7, 0
.L4451:
	extui	a7, a7, 0, 8
	j	.L4447
.L4512:
	movi.n	a7, 0
.L4447:
	bltu	a10, a5, .L4454
	bne	a5, a10, .L4453
	bgeu	a11, a8, .L4453
.L4454:
	mov.n	a8, a11
	mov.n	a5, a10
.L4453:
	l32i	a10, a9, 56
	l32i	a11, a9, 52
	bltu	a6, a10, .L4456
	bne	a10, a6, .L4446
	bgeu	a3, a11, .L4446
.L4456:
	mov.n	a3, a11
	mov.n	a6, a10
.L4446:
	addi	a9, a9, 96
.L4445:
	bne	a9, a13, .L4457
	l32i	a9, sp, 232
	movi.n	a4, 0
	bnei	a9, 6, .L4458
	l32i	a9, sp, 20
	bnei	a9, 1, .L4458
	l16ui	a10, sp, 120
	addi	a10, a10, -2
	extui	a10, a10, 0, 16
	bgeui	a10, 2, .L4458
	l32r	a10, .LC1788
	add.n	a10, a2, a10
	l16ui	a10, a10, 0
	addi	a10, a10, -2
	extui	a10, a10, 0, 16
	saltu	a9, a9, a10
	addi.n	a9, a9, -1
	neg	a9, a9
	extui	a4, a9, 0, 8
.L4458:
	l32r	a9, .LC1744
	movi	a12, 0x88
	add.n	a10, a2, a9
	addmi	a10, a10, 0x500
	addi	a11, sp, 16
	addi	a10, a10, 16
	s32i	a8, sp, 216
	call8	memcpy
	l32r	a9, .LC1744
	l32i	a8, sp, 216
	beqz.n	a7, .L4459
	beqz.n	a4, .L4459
	l32i	a10, sp, 20
	s32i	a10, sp, 228
.L4459:
	l32i	a10, sp, 228
	add.n	a9, a2, a9
	addmi	a9, a9, 0x500
	s32i	a10, a9, 8
	s32i	a8, a9, 152
	s32i	a5, a9, 156
	s32i	a3, a9, 160
	s32i	a6, a9, 164
.L4441:
	l32r	a9, .LC1744
	movi.n	a10, 1
	add.n	a9, a2, a9
	addmi	a11, a9, 0x100
	s8i	a10, a11, 225
	addmi	a9, a9, 0x300
	s8i	a10, a9, 0
.L4440:
	l32i	a8, sp, 224
	l32r	a7, .LC1723
	l32r	a9, .LC1791
	add.n	a7, a8, a7
	add.n	a8, a2, a7
	s32i	a8, sp, 228
	l32i	a8, sp, 196
	l8ui	a10, sp, 16
	add.n	a8, a8, a9
	s32i	a8, sp, 216
	l32i	a7, sp, 192
	bgeu	a8, a9, .L4460
	addi.n	a7, a7, 1
.L4460:
	addi	a9, a10, -2
	extui	a9, a9, 0, 8
	bgeui	a9, 3, .L4461
	l32r	a9, .LC1781
	movi.n	a10, 0
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L4462
	l32r	a9, .LC1747
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnei	a9, 1, .L4462
	l32r	a10, .LC1782
	movi	a5, 0xb0
	add.n	a5, sp, a5
	mov.n	a11, a5
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4462
	l32r	a9, .LC1783
	l32i	a8, sp, 204
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	movi.n	a10, 0
	bne	a9, a8, .L4462
	l32r	a9, .LC1784
	movi.n	a11, 0xf
	add.n	a9, a2, a9
	l16ui	a9, a9, 0
	bltu	a11, a9, .L4462
	l32r	a9, .LC1744
	l32r	a6, .LC1756
	add.n	a9, a2, a9
	add.n	a6, a2, a6
	l32i	a14, a9, 520
	l32i	a15, a9, 524
	l32i	a12, sp, 196
	l32i	a13, sp, 192
	mov.n	a11, a5
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L4462
	l16ui	a10, a6, 40
	nsau	a10, a10
	srli	a10, a10, 5
.L4462:
	l32r	a9, .LC1756
	l32r	a11, .LC1787
	add.n	a9, a2, a9
	l32i	a5, a9, 240
	l32i	a14, a9, 244
	l32i	a6, a9, 248
	l32i	a13, a9, 252
	l32r	a9, .LC1786
	add.n	a8, a2, a11
	add.n	a9, a2, a9
	j	.L4463
.L4475:
	l16ui	a11, a9, 0
	beqz.n	a11, .L4464
	l32i	a12, a9, 36
	l32i	a11, a9, 40
	beqz.n	a10, .L4465
	l8ui	a10, a9, 34
	beqz.n	a10, .L4465
	l8ui	a10, a9, 33
	beqz.n	a10, .L4465
	l8ui	a15, a9, 72
	bnez.n	a15, .L4521
	l32i	a15, sp, 192
	bltu	a15, a11, .L4521
	bne	a11, a15, .L4525
	l32i	a15, sp, 196
	bltu	a15, a12, .L4521
.L4525:
	l32r	a15, .LC1744
	add.n	a15, a2, a15
	l32i	a3, a15, 520
	l32i	a4, a15, 524
	or	a15, a3, a4
	beqz.n	a15, .L4465
	l32i	a10, sp, 192
	sub	a15, a10, a11
	l32i	a10, sp, 196
	bgeu	a10, a12, .L4468
	addi.n	a15, a15, -1
.L4468:
	l32i	a10, sp, 196
	sub	a10, a10, a12
	s32i	a10, sp, 232
	movi.n	a10, 1
	bltu	a15, a4, .L4469
	bne	a4, a15, .L4470
	l32i	a15, sp, 232
	bltu	a15, a3, .L4469
.L4470:
	movi.n	a10, 0
.L4469:
	extui	a10, a10, 0, 8
	j	.L4465
.L4521:
	movi.n	a10, 0
.L4465:
	bltu	a11, a14, .L4472
	bne	a14, a11, .L4471
	bgeu	a12, a5, .L4471
.L4472:
	mov.n	a5, a12
	mov.n	a14, a11
.L4471:
	l32i	a11, a9, 56
	l32i	a12, a9, 52
	bltu	a13, a11, .L4474
	bne	a11, a13, .L4464
	bgeu	a6, a12, .L4464
.L4474:
	mov.n	a6, a12
	mov.n	a13, a11
.L4464:
	addi	a9, a9, 96
.L4463:
	bne	a8, a9, .L4475
	l32r	a11, .LC1785
	l32r	a9, .LC1766
	add.n	a11, a2, a11
	add.n	a9, a2, a9
	movi.n	a12, 4
	loop	a12, .L4477_LEND
.L4477:
	beqz.n	a10, .L4476
	l8ui	a15, a9, 0
	movi.n	a10, 0
	bnei	a15, 1, .L4476
	l16ui	a15, a11, 0
	movi.n	a10, 3
	saltu	a10, a10, a15
	addi.n	a10, a10, -1
	neg	a10, a10
	extui	a10, a10, 0, 8
.L4476:
	addi.n	a11, a11, 2
	addi.n	a9, a9, 1
	.L4477_LEND:
	l32r	a4, .LC1744
	movi	a3, 0xa0
	add.n	a4, a2, a4
	addmi	a8, a4, 0x300
	s8i	a10, a8, 1
	addi	a10, sp, 16
	add.n	a3, a10, a3
	l32i	a10, a3, 0
	l32i	a11, a3, 4
	s32i	a10, a4, 772
	l32i	a9, sp, 204
	l32i	a10, a3, 8
	s32i	a11, a4, 776
	s32i	a10, a4, 780
	s32i	a9, a4, 784
	s32i	a14, a4, 796
	s32i	a13, a4, 804
	s32i	a5, a4, 792
	s32i	a6, a4, 800
	addi	a11, sp, 16
	movi	a12, 0x88
	addi	a10, a8, 40
	s32i	a8, sp, 232
	call8	memcpy
	l32i	a8, sp, 232
	movi.n	a9, 1
	s8i	a9, a8, 0
	addmi	a4, a4, 0x100
	l32i	a8, sp, 216
	s8i	a9, a4, 225
	s32i	a8, sp, 8
	l32i	a8, sp, 196
	l32r	a9, .LC1717
	s32i	a8, sp, 0
	l32i	a8, sp, 192
	add.n	a9, a2, a9
	s32i	a7, sp, 12
	s32i	a8, sp, 4
	l32i	a14, sp, 212
	l32i	a12, a9, 0
	l32i	a10, sp, 228
	addi	a13, sp, 16
	mov.n	a11, a3
	call8	_ZN14MotorControlRS6ESS_RS22prepareSegmentSettingsERNS0_13DriverContextERKNS_10ReadTargetEmRKNS0_13DriverRequestERKNS0_19DriverPrerequisitesEyy
	j	.L4668
.L4461:
	l32r	a6, .LC1717
	bnei	a10, 5, .L4479
	l32i	a8, sp, 216
	add.n	a6, a2, a6
	s32i	a8, sp, 8
	l32i	a8, sp, 196
	s32i	a7, sp, 12
	s32i	a8, sp, 0
	l32i	a8, sp, 192
	addi	a13, sp, 16
	s32i	a8, sp, 4
	l32i	a14, sp, 212
	l32i	a12, a6, 0
	l32i	a10, sp, 228
	movi	a11, 0xa0
	add.n	a11, a13, a11
	call8	_ZN14MotorControlRS6ESS_RS22prepareControlSettingsERNS0_13DriverContextERKNS_10ReadTargetEmRKNS0_13DriverRequestERKNS0_19DriverPrerequisitesEyy
	j	.L4668
.L4479:
	call8	_ZN14MotorControlRS6ESS_RS13isTuningGroupENS0_11DriverGroupE
	l32i	a8, sp, 216
	add.n	a6, a2, a6
	l32i	a12, a6, 0
	s32i	a8, sp, 8
	l32i	a8, sp, 196
	addi	a13, sp, 16
	s32i	a8, sp, 0
	l32i	a8, sp, 192
	movi	a11, 0xa0
	s32i	a7, sp, 12
	s32i	a8, sp, 4
	l32i	a14, sp, 212
	add.n	a11, a13, a11
	beqz.n	a10, .L4480
	l32i	a10, sp, 228
	call8	_ZN14MotorControlRS6ESS_RS21prepareTuningSettingsERNS0_13DriverContextERKNS_10ReadTargetEmRKNS0_13DriverRequestERKNS0_19DriverPrerequisitesEyy
	j	.L4668
.L4480:
	l32i	a10, sp, 228
	call8	_ZN14MotorControlRS6ESS_RS21prepareDriverSettingsERNS0_13DriverContextERKNS_10ReadTargetEmRKNS0_13DriverRequestERKNS0_19DriverPrerequisitesEyy
.L4668:
	s32i	a10, sp, 152
	s32i	a11, sp, 156
	addi	a9, sp, 16
	movi	a11, 0x88
	movi	a10, 0x94
	add.n	a10, a9, a10
	s32i	a12, sp, 160
	add.n	a9, a9, a11
	l32i	a12, a9, 0
	l32i	a11, a9, 4
	l32i	a9, a9, 8
	s32i	a12, a10, 0
	s32i	a11, a10, 4
	s32i	a9, a10, 8
.L4399:
	l32r	a7, .LC1726
	l32i	a8, sp, 224
	l8ui	a9, sp, 164
	add.n	a6, a8, a7
	add.n	a6, a2, a6
	beqz.n	a9, .L4481
	l32r	a9, .LC1789
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L4482
	l32r	a9, .LC1790
	addi	a10, sp, 16
	add.n	a8, a2, a9
	movi	a9, 0x94
	add.n	a9, a10, a9
	l32i	a11, a9, 0
	l32i	a10, a9, 4
	l32i	a9, a9, 8
	s32i	a11, a8, 0
	s32i	a10, a8, 4
	s32i	a9, a8, 8
.L4482:
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	addi	a8, sp, 16
	movi	a10, 0x94
	add.n	a10, a8, a10
	call8	_ZN21MotorControlRSExample5Probe21driverAdmissionStatusERKN14MotorControlRS6StatusE
	mov.n	a5, a10
	j	.L4380
.L4481:
	movi.n	a12, 0x30
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi.n	a9, 2
	l32i	a8, sp, 224
	s8i	a9, sp, 16
	l32r	a9, .LC1723
	l32i	a12, sp, 196
	add.n	a10, a8, a9
	l32i	a13, sp, 192
	addi	a14, sp, 16
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS10nextDriverERKNS0_13DriverContextEyRNS0_14PreparedDriverE
	s32i	a10, sp, 152
	s32i	a11, sp, 156
	s32i	a12, sp, 160
	extui	a10, a10, 0, 8
	beqz.n	a10, .L4484
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a5, 4
	j	.L4380
.L4484:
	l32i	a14, sp, 196
	l32i	a15, sp, 192
	addi	a12, sp, 16
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115admitDriverStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS14PreparedDriverEy
	mov.n	a5, a10
	beqz.n	a10, .L4485
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L4380
.L4485:
	l32r	a11, .LC1732
	movi.n	a12, 5
	add.n	a11, a2, a11
	addi.n	a10, a6, 12
	call8	memcpy
	l32i	a8, sp, 220
	l32r	a9, .LC1721
	l32r	a11, .LC1734
	mull	a9, a8, a9
	l32r	a10, .LC1733
	add.n	a11, a2, a11
	l32i	a11, a11, 0
	add.n	a9, a2, a9
	add.n	a10, a9, a10
	s32i	a11, a10, 0
	l32r	a10, .LC1717
	l32i	a8, sp, 236
	add.n	a10, a2, a10
	l32i	a12, a10, 0
	l32r	a13, .LC1738
	addi.n	a11, a12, 1
	s32i	a11, a10, 0
	l32r	a10, .LC1720
	add.n	a13, a9, a13
	add.n	a10, a9, a10
	s32i	a12, a10, 0
	l32r	a10, .LC1735
	add.n	a7, a9, a7
	add.n	a10, a9, a10
	s32i	a8, a10, 0
	l32r	a10, .LC1736
	l32i	a8, sp, 208
	add.n	a10, a9, a10
	s8i	a8, a10, 0
	l32r	a10, .LC1739
	l32i	a8, sp, 204
	add.n	a10, a9, a10
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a13, 4
	s32i	a10, a13, 0
	l32r	a10, .LC1737
	add.n	a10, a9, a10
	s32i	a8, a10, 0
	movi.n	a10, 6
	s8i	a10, a7, 0
	l32i	a8, sp, 200
	l32r	a10, .LC1731
	add.n	a10, a9, a10
	extui	a9, a8, 0, 1
	s8i	a9, a10, 0
	l32r	a9, .LC1740
	add.n	a8, a2, a9
	s32i	a12, a8, 0
	l32i	a8, sp, 240
	s32i	a12, a8, 0
.L4380:
	mov.n	a2, a5
	retw.n
.LFE2201:
	.size	_ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm, .-_ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm
	.literal_position
	.literal .LC1796, 53807
	.literal .LC1797, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1798, 45697
	.literal .LC1799, 45698
	.literal .LC1800, 772492
	.literal .LC1801, 764688
	.literal .LC1802, 757624
	.literal .LC1803, _ZN12_GLOBAL__N_14uartE
	.literal .LC1804, 764508
	.literal .LC1805, 757972
	.literal .LC1806, 764504
	.literal .LC1807, 757960
	.literal .LC1808, 101004
	.literal .LC1810, 101000
	.literal .LC1811, 9040
	.literal .LC1812, 771828
	.literal .LC1813, 764516
	.literal .LC1814, 771832
	.literal .LC1815, 772456
	.literal .LC1816, 771836
	.literal .LC1817, 45700
	.literal .LC1818, 771816
	.literal .LC1819, 45688
	.literal .LC1820, 50000
	.literal .LC1821, 771808
	.literal .LC1822, 764665
	.literal .LC1823, 757628
	.literal .LC1824, 770908
	.literal .LC1827, 625848
	.literal .LC1828, 771056
	.align	4
	.type	_ZN12_GLOBAL__N_19startMoveEPvmhRKN14MotorControlRS11MoveRequestERm, @function
_ZN12_GLOBAL__N_19startMoveEPvmhRKN14MotorControlRS11MoveRequestERm:
.LFB2139:
	entry	sp, 224
.LCFI178:
	movi	a7, 0x7f7
	slli	a7, a7, 5
	s32i	a6, sp, 176
	add.n	a6, a2, a7
	l32i	a9, a6, 152
	l32i	a10, a6, 156
	s32i	a3, sp, 172
	or	a9, a9, a10
	extui	a4, a4, 0, 8
	bnez.n	a9, .L4670
	l32r	a9, .LC1796
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4670
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L4670
	l32r	a9, .LC1797
	l8ui	a9, a9, 0
	bnez.n	a9, .L4671
.L4686:
	movi.n	a15, 3
	j	.L4672
.L4671:
	l32r	a9, .LC1798
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	beqz.n	a9, .L4673
.L4674:
	movi.n	a15, 2
	j	.L4672
.L4673:
	l32r	a9, .LC1799
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4674
	l8ui	a9, a6, 137
	bnez.n	a9, .L4674
	mov.n	a10, a4
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	movi.n	a15, 8
	beqz.n	a10, .L4672
	l16ui	a9, a5, 64
	beqz.n	a9, .L4672
	l8ui	a9, a5, 66
	bnei	a9, 1, .L4672
	l32r	a10, .LC1800
	srli	a9, a4, 3
	add.n	a9, a2, a9
	add.n	a9, a9, a10
	l8ui	a10, a9, 0
	extui	a9, a4, 0, 3
	bbc	a10, a9, .L4686
	l32r	a9, .LC1801
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bnez.n	a9, .L4676
	l8ui	a9, a5, 17
	bnez.n	a9, .L4686
.L4676:
	l32r	a9, .LC1802
	movi.n	a15, 7
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L4672
	add.n	a7, a2, a7
	mov.n	a10, a7
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L4674
	l32r	a6, .LC1803
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L4674
	movi.n	a12, 1
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a15, 0xc
	bnez.n	a10, .L4672
	l32i	a9, a7, 52
	beqi	a9, -1, .L4677
.L4670:
	movi.n	a15, 1
	j	.L4672
.L4677:
	l32i	a7, a7, 48
	bnez.n	a7, .L4670
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a2
	mov.n	a11, a4
	call8	_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy
	bnez.n	a10, .L4670
	l32r	a9, .LC1804
	add.n	a9, a2, a9
	l8ui	a9, a9, 0
	bne	a9, a4, .L4686
	l32r	a9, .LC1805
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L4686
	l32r	a11, .LC1806
	l32r	a10, .LC1807
	add.n	a11, a2, a11
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4686
	l32r	a9, .LC1808
	l32r	a11, .LC1811
	add.n	a9, a2, a9
	movi.n	a10, 8
	loop	a10, .L4683_LEND
.L4683:
	l32i	a12, a9, 0
	bnez.n	a12, .L4679
	l32r	a9, .LC1811
	l32r	a10, .LC1810
	mul16u	a9, a7, a9
	movi	a7, 0x3e8
	add.n	a9, a9, a10
	mov.n	a10, a6
	add.n	a3, a2, a9
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a6, a11
	l32i	a11, a2, 4
	s32i	a10, sp, 160
	l32i	a8, sp, 160
	mull	a10, a7, a11
	muluh	a7, a7, a11
	add.n	a8, a10, a8
	s32i	a8, sp, 168
	add.n	a7, a7, a6
	bgeu	a8, a10, .L4680
	addi.n	a7, a7, 1
.L4680:
	movi	a8, 0x6f0
	add.n	a8, a3, a8
	l32i	a14, sp, 168
	l32i	a12, sp, 160
	mov.n	a15, a7
	s32i	a8, sp, 0
	mov.n	a13, a6
	mov.n	a11, a5
	mov.n	a10, a2
	s32i	a8, sp, 164
	call8	_ZN12_GLOBAL__N_119prepareSelectedMoveERNS_3AppERKN14MotorControlRS11MoveRequestEyyRNS2_6ESS_RS11MoveContextE
	mov.n	a15, a10
	beqz.n	a10, .L4727
	j	.L4729
.L4679:
	addi.n	a7, a7, 1
	add.n	a9, a9, a11
	.L4683_LEND:
	movi.n	a15, 6
	j	.L4672
.L4727:
	l8ui	a10, a5, 67
	bnei	a10, 2, .L4684
	l32r	a11, .LC1812
	l32r	a10, .LC1813
	add.n	a11, a2, a11
	add.n	a10, a2, a10
	l32i	a11, a11, 0
	l32i	a10, a10, 0
	bne	a11, a10, .L4685
	l32r	a11, .LC1814
	l32r	a10, .LC1815
	add.n	a11, a2, a11
	add.n	a10, a2, a10
	l32i	a11, a11, 0
	l32i	a10, a10, 0
	bne	a11, a10, .L4685
	l32r	a11, .LC1816
	l32r	a10, .LC1817
	add.n	a11, a2, a11
	add.n	a10, a2, a10
	l32i	a11, a11, 0
	l32i	a10, a10, 0
	bne	a11, a10, .L4685
	l32i	a8, sp, 164
	l32r	a10, .LC1818
	movi	a11, 0x258
	movi.n	a12, 0xa
	add.n	a11, a8, a11
	add.n	a10, a2, a10
	call8	memcmp
	beqz.n	a10, .L4684
.L4685:
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L4686
.L4684:
	movi.n	a12, 0x48
	movi.n	a11, 0
	addi	a10, sp, 88
	call8	memset
	movi.n	a10, 2
	s8i	a10, sp, 88
	l32i	a12, sp, 160
	l32i	a10, sp, 164
	addi	a14, sp, 88
	mov.n	a13, a6
	call8	_ZN14MotorControlRS6ESS_RS8nextMoveERKNS0_11MoveContextEyRNS0_12PreparedMoveE
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	beqz.n	a10, .L4688
	mov.n	a10, a3
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a15, 4
	j	.L4672
.L4688:
	l32i	a14, sp, 160
	mov.n	a15, a6
	addi	a12, sp, 88
	mov.n	a11, a3
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy
	mov.n	a15, a10
	beqz.n	a10, .L4689
.L4729:
	mov.n	a10, a3
	s32i	a15, sp, 160
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	l32i	a15, sp, 160
	j	.L4672
.L4689:
	l32r	a11, .LC1819
	s32i	a10, sp, 164
	movi.n	a12, 5
	add.n	a11, a2, a11
	addi.n	a10, a3, 12
	call8	memcpy
	l32r	a10, .LC1817
	l32i	a8, sp, 172
	add.n	a10, a2, a10
	l32i	a10, a10, 0
	s32i	a10, a3, 20
	l32r	a10, .LC1802
	add.n	a10, a2, a10
	l32i	a11, a10, 0
	addi.n	a12, a11, 1
	s32i	a12, a10, 0
	s32i	a8, a3, 8
	l32i	a8, sp, 168
	movi.n	a10, 4
	s32i	a11, a3, 4
	s8i	a10, a3, 0
	s8i	a4, a3, 24
	s32i	a8, a3, 56
	s32i	a7, a3, 60
	addmi	a10, a3, 0x300
	movi.n	a11, 1
	s8i	a11, a10, 8
	movi.n	a12, 0x48
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi	a10, 0x7d0
	s16i	a10, sp, 32
	l32r	a10, .LC1820
	l32i	a15, sp, 164
	s32i	a10, sp, 36
	movi	a10, 0x64
	s16i	a10, sp, 40
	l32r	a10, .LC1821
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4692
	addmi	a4, a3, 0x700
	l16ui	a10, a4, 80
	bnez.n	a10, .L4692
	l8ui	a10, a4, 83
	bnez.n	a10, .L4692
	l8ui	a10, a4, 86
	bnez.n	a10, .L4692
	movi	a5, 0x6f0
	add.n	a5, a3, a5
	l8ui	a10, a5, 242
	bnez.n	a10, .L4692
	l32r	a10, .LC1822
	add.n	a10, a2, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4692
	l32i	a12, sp, 160
	addi	a14, sp, 16
	mov.n	a13, a6
	addi	a11, a5, 80
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116moveRequirementsERKNS_3AppERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE
	l32i	a15, sp, 164
	bnez.n	a10, .L4694
.L4692:
	l32r	a9, .LC1823
	l32i	a10, a3, 4
	add.n	a8, a2, a9
	s32i	a10, a8, 0
	l32i	a8, sp, 176
	s32i	a10, a8, 0
	j	.L4672
.L4694:
	l32i	a14, a5, 64
	addmi	a7, a3, 0xb00
	movi	a13, 0xc0
	add.n	a13, a7, a13
	l32i	a12, a5, 68
	l32i	a11, a3, 4
	s32i	a14, a13, 0
	l32i	a10, a5, 72
	s32i	a12, a13, 4
	s32i	a10, a13, 8
	l32i	a10, a5, 472
	l16ui	a12, a5, 200
	s32i	a10, a7, 204
	l16ui	a10, a5, 164
	addmi	a5, a5, 0x200
	s16i	a10, a7, 212
	l8ui	a10, a4, 82
	s32i	a11, a7, 208
	s8i	a10, a7, 228
	l32r	a10, .LC1824
	s16i	a12, a7, 214
	add.n	a10, a2, a10
	l16ui	a10, a10, 0
	addi	a13, a13, 32
	s16i	a10, a7, 216
	l16ui	a10, a5, 88
	movi.n	a11, 2
	s16i	a10, a7, 218
	l16ui	a10, a5, 90
	s32i	a15, sp, 160
	s16i	a10, a7, 220
	l16ui	a10, a5, 92
	s16i	a10, a7, 222
	movi.n	a10, 0x4e
	addmi	a10, a10, 0x900
	add.n	a10, a3, a10
	call8	_ZN14MotorControlRS6ESS_RS12decodeUint32EPKtjNS0_9WordOrderERm
	l32r	a10, .LC1827
	l32r	a11, .LC1828
	add.n	a10, a2, a10
	add.n	a11, a2, a11
	l32i	a13, a11, 0
	l32i	a12, a11, 4
	l32i	a11, a10, 0
	l32i	a10, a10, 4
	l32i	a15, sp, 160
	bltu	a12, a10, .L4696
	bne	a10, a12, .L4695
	bgeu	a13, a11, .L4695
.L4696:
	mov.n	a11, a13
	mov.n	a10, a12
.L4695:
	l32i	a12, a4, 196
	l32i	a13, a4, 192
	bltu	a12, a10, .L4698
	bne	a10, a12, .L4697
	bgeu	a13, a11, .L4697
.L4698:
	mov.n	a11, a13
	mov.n	a10, a12
.L4697:
	s32i	a10, a7, 236
	movi	a10, 0x6f0
	s32i	a11, a7, 232
	add.n	a10, a3, a10
	l32i	a11, a2, 0
	l32i	a14, a10, 216
	l32i	a13, a10, 220
	movi	a10, 0x3e8
	mull	a12, a10, a11
	muluh	a10, a10, a11
	s32i	a14, a7, 240
	s32i	a13, a7, 244
	or	a11, a12, a10
	beqz.n	a11, .L4692
	addi.n	a11, a13, -1
	movnez	a11, a13, a14
	addi.n	a6, a14, -1
	bltu	a11, a10, .L4692
	bne	a10, a11, .L4707
	bltu	a6, a12, .L4692
.L4707:
	s32i	a12, a7, 240
	s32i	a10, a7, 244
	j	.L4692
.L4672:
	mov.n	a2, a15
	retw.n
.LFE2139:
	.size	_ZN12_GLOBAL__N_19startMoveEPvmhRKN14MotorControlRS11MoveRequestERm, .-_ZN12_GLOBAL__N_19startMoveEPvmhRKN14MotorControlRS11MoveRequestERm
	.section	.rodata.str1.1
.LC1830:
	.string	"Move did not complete with a definite acknowledged result"
.LC1832:
	.string	"Preparation interrupted by stop; no move was admitted"
.LC1834:
	.string	"Preparation cancelled or expired; no move was admitted"
.LC1836:
	.string	"subdivision admission"
.LC1838:
	.string	"Requested speed is below the independently qualified minimum"
.LC1840:
	.string	"Requested speed is below the drive starting speed; see settings"
.LC1842:
	.string	"Command scale is unknown; set stepsperturn to the established steps per motor turn"
.LC1844:
	.string	"Absolute host coordinates need an established axis origin; use help axis"
.LC1846:
	.string	"Stored setup does not match the checked move or motion prerequisites are unavailable"
.LC1848:
	.string	"Motion prerequisites are unavailable; check enable, inputs, limits, starting speed and position units"
.LC1856:
	.string	"missing move result"
.LC1858:
	.string	"Move result is unavailable"
.LC1867:
	.string	"preparation cancelled"
.LC1870:
	.string	"Subdivision operation failed; inspect the retained setting result"
.LC1873:
	.string	"read admission"
.LC1875:
	.string	"Preparatory read could not be admitted"
.LC1877:
	.string	"Preparatory read failed; no move was admitted"
.LC1881:
	.string	"subdivision changed after readback"
.LC1883:
	.string	"Refreshed subdivision disagrees with the setting; host scale and origin remain invalid"
.LC1885:
	.string	"profile admission"
.LC1887:
	.string	"Cannot read motion parameters; use the retained read result for details"
.LC1892:
	.string	"stationary readiness unavailable"
.LC1894:
	.string	"Fresh enabled and alarm-free state with known feedback is required"
.LC1902:
	.string	"Cannot apply steps per turn without stationary axis evidence"
.LC1912:
	.string	"Cannot establish stationary boot zero"
.LC1916:
	.string	"position encoding unresolved"
.LC1918:
	.string	"Subdivision readback succeeded, but current position cannot establish a host zero"
.LC1920:
	.string	"Position profile read could not be admitted"
.LC1922:
	.string	"profile read failed"
.LC1924:
	.string	"Position profile read failed; no move was admitted"
.LC1926:
	.string	"zero positioning speed"
.LC1928:
	.string	"Speed is zero; set speed above zero before requesting movement"
.LC1932:
	.string	"start-speed relationship unqualified"
.LC1934:
	.string	"Starting-speed relationship is unqualified; no move was admitted"
.LC1936:
	.string	"speed below drive starting speed"
.LC1939:
	.string	"Requested target already satisfied; no new motion command was sent"
.LC1941:
	.string	"move prerequisites"
	.section	.rodata
	.align	8
.LC8:
	.word	0
	.word	0
	.word	1
	.word	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.zero	1
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.byte	0
	.byte	1
	.zero	6
	.word	0
	.word	0
	.word	0
	.word	0
	.short	0
	.byte	0
	.byte	0
	.zero	4
	.text
	.literal_position
	.literal .LC1829, .LC435
	.literal .LC1831, .LC1830
	.literal .LC1833, .LC1832
	.literal .LC1835, .LC1834
	.literal .LC1837, .LC1836
	.literal .LC1839, .LC1838
	.literal .LC1841, .LC1840
	.literal .LC1843, .LC1842
	.literal .LC1845, .LC1844
	.literal .LC1847, .LC1846
	.literal .LC1849, .LC1848
	.literal .LC1850, 771192
	.literal .LC1852, 771808
	.literal .LC1853, 757960
	.literal .LC1854, 770856
	.literal .LC1855, 771332
	.literal .LC1857, .LC1856
	.literal .LC1859, .LC1858
	.literal .LC1860, 764776
	.literal .LC1861, 764784
	.literal .LC1862, 764516
	.literal .LC1863, 764771
	.literal .LC1864, 772456
	.literal .LC1865, 45700
	.literal .LC1866, 65248
	.literal .LC1868, .LC1867
	.literal .LC1869, 757628
	.literal .LC1871, .LC1870
	.literal .LC1874, .LC1873
	.literal .LC1876, .LC1875
	.literal .LC1878, .LC1877
	.literal .LC1879, 757976
	.literal .LC1880, .LC12
	.literal .LC1882, .LC1881
	.literal .LC1884, .LC1883
	.literal .LC1886, .LC1885
	.literal .LC1888, .LC1887
	.literal .LC1889, 625896
	.literal .LC1890, 764504
	.literal .LC1891, 625320
	.literal .LC1893, .LC1892
	.literal .LC1895, .LC1894
	.literal .LC1896, 764633
	.literal .LC1897, 764520
	.literal .LC1903, .LC1902
	.literal .LC1904, 764769
	.literal .LC1905, 764770
	.literal .LC1908, 536870910
	.literal .LC1910, 625560
	.literal .LC1911, 626136
	.literal .LC1913, .LC1912
	.literal .LC1914, 764696
	.literal .LC1915, 764714
	.literal .LC1917, .LC1916
	.literal .LC1919, .LC1918
	.literal .LC1921, .LC1920
	.literal .LC1923, .LC1922
	.literal .LC1925, .LC1924
	.literal .LC1927, .LC1926
	.literal .LC1929, .LC1928
	.literal .LC1930, 771912
	.literal .LC1931, 771920
	.literal .LC1933, .LC1932
	.literal .LC1935, .LC1934
	.literal .LC1937, .LC1936
	.literal .LC1938, .LC8
	.literal .LC1940, .LC1939
	.literal .LC1942, .LC1941
	.literal .LC1946, -1598689907
	.literal .LC1947, 1051772663
	.align	4
	.type	_ZN12_GLOBAL__N_119serviceSimpleMotionERNS_3AppEy, @function
_ZN12_GLOBAL__N_119serviceSimpleMotionERNS_3AppEy:
.LFB2244:
	entry	sp, 640
.LCFI179:
	l32r	a6, .LC1850
	s32i	a5, sp, 576
	add.n	a5, a2, a6
	l32i	a12, a5, 36
	s32i	a4, sp, 580
	mov.n	a7, a2
	beqz.n	a12, .L4730
	l8ui	a8, a5, 59
	bnez.n	a8, .L4730
	l8ui	a8, a5, 58
	bnez.n	a8, .L4734
	movi	a10, 0x1ff
	slli	a10, a10, 7
	l32i	a11, a5, 48
	mov.n	a13, a5
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe7Console18reportSimpleMotionEmmRKNS0_16SimpleMotionViewE
	beqz.n	a10, .L4730
	movi.n	a8, 1
	s8i	a8, a5, 59
	j	.L4730
.L4734:
	l32r	a8, .LC1852
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l8ui	a8, a5, 72
	beqz.n	a8, .L4735
	movi	a8, 0xc8
	l32r	a14, .LC1853
	add.n	a5, a5, a8
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	add.n	a14, a2, a14
	mov.n	a11, a5
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_120serviceMotionProfileERNS_3AppERNS0_18MotionProfileStateEyRKN14MotorControlRS6ESS_RS17ConfigObservationE
	j	.L4736
.L4735:
	l32r	a5, .LC1854
	add.n	a5, a2, a5
.L4736:
	add.n	a4, a7, a6
	l32i	a11, a4, 40
	beqz.n	a11, .L4737
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	bnez.n	a10, .L4738
	movi.n	a8, 5
	s8i	a8, a4, 57
	l32r	a8, .LC1855
	s8i	a10, a4, 58
	add.n	a8, a7, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
	l32r	a8, .LC1857
	s32i	a10, a4, 144
	s32i	a8, a4, 148
	l32r	a8, .LC1859
	s8i	a10, a4, 136
	s32i	a8, a4, 152
	j	.L4739
.L4738:
	movi	a8, 0x6f0
	addmi	a11, a10, 0x800
	add.n	a8, a10, a8
	s32i	a8, a4, 156
	l8ui	a8, a11, 227
	l8ui	a9, a11, 224
	s8i	a8, a4, 108
	l8ui	a8, a11, 226
	l8ui	a14, a11, 223
	s8i	a8, a4, 109
	s8i	a9, a4, 138
	addmi	a9, a10, 0x300
	l8ui	a9, a9, 10
	s8i	a14, a4, 137
	s8i	a9, a4, 110
	l8ui	a9, a10, 65
	beqz.n	a9, .L4739
	l8ui	a13, a11, 220
	movi.n	a12, 1
	addi	a13, a13, -2
	movi.n	a9, 0
	movnez	a9, a12, a13
	or	a8, a8, a9
	beqi	a8, 1, .L4854
	beqi	a14, 1, .L4741
.L4854:
	movi.n	a9, 0
	add.n	a8, a7, a6
	s8i	a9, a8, 60
	l32r	a9, .LC1831
	j	.L4743
.L4741:
	s8i	a12, a4, 60
	l8ui	a8, a11, 128
	bnez.n	a8, .L4744
.L4745:
	l32r	a9, .LC1829
	j	.L4743
.L4744:
	l32r	a13, .LC1860
	l32i	a9, a11, 140
	add.n	a13, a7, a13
	l32i	a8, a11, 136
	s32i	a9, a13, 4
	l32r	a9, .LC1862
	s32i	a8, a13, 0
	add.n	a9, a7, a9
	l32r	a8, .LC1861
	l32i	a9, a9, 0
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	l32r	a8, .LC1863
	add.n	a8, a7, a8
	s8i	a12, a8, 0
	j	.L4745
.L4743:
	add.n	a6, a7, a6
	movi.n	a8, 0
	movi	a12, 0xb0
	addmi	a10, a10, 0xb00
	l8ui	a11, a11, 221
	add.n	a10, a10, a12
	s8i	a8, a6, 58
	movi.n	a8, 5
	l32i	a13, a10, 0
	s8i	a8, a6, 57
	movi	a8, 0x8c
	add.n	a8, a6, a8
	l32i	a12, a10, 4
	s32i	a13, a8, 0
	l32i	a10, a10, 8
	s32i	a12, a8, 4
	s32i	a10, a8, 8
	s32i	a9, a6, 152
	j	.L4959
.L4737:
	l32r	a8, .LC1864
	add.n	a8, a7, a8
	l32i	a12, a8, 0
	l32i	a8, a4, 600
	bne	a8, a12, .L4746
	l32r	a8, .LC1865
	add.n	a8, a7, a8
	l32i	a11, a8, 0
	l32i	a8, a4, 604
	bne	a8, a11, .L4746
	l32i	a8, a4, 612
	l32i	a9, sp, 576
	bltu	a9, a8, .L4747
	bne	a8, a9, .L4746
	l32i	a8, a4, 608
	l32i	a9, sp, 580
	bltu	a9, a8, .L4747
.L4746:
	add.n	a8, a7, a6
	addmi	a8, a8, 0x200
	movi.n	a9, 1
	s8i	a9, a8, 105
	j	.L4749
.L4747:
	add.n	a2, a7, a6
	addmi	a8, a2, 0x200
	l8ui	a8, a8, 105
	beqz.n	a8, .L4750
.L4749:
	add.n	a8, a7, a6
	l32i	a11, a8, 68
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a4, a10
	beqz.n	a10, .L4751
	movi.n	a8, 1
	s8i	a8, a10, 71
	l32i	a8, a10, 32
	beqz.n	a8, .L4752
	addi	a11, a10, 32
	l32r	a10, .LC1866
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L4752:
	l8ui	a8, a4, 65
	beqz.n	a8, .L4739
	addmi	a4, a4, 0x1f00
	l8ui	a9, a4, 68
	add.n	a8, a7, a6
	s8i	a9, a8, 109
.L4751:
	add.n	a8, a7, a6
	l32i	a11, a8, 44
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a4, a10
	bnez.n	a10, .L4753
.L4757:
	add.n	a8, a7, a6
	l8ui	a8, a8, 57
	beqi	a8, 2, .L4754
	j	.L4755
.L4753:
	movi.n	a8, 1
	s8i	a8, a10, 71
	l32i	a8, a10, 32
	beqz.n	a8, .L4756
	addi	a11, a10, 32
	l32r	a10, .LC1866
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L4756:
	l8ui	a8, a4, 65
	bnez.n	a8, .L4757
	j	.L4739
.L4754:
	l8ui	a8, a5, 0
	beqz.n	a8, .L4755
	l32i	a8, a5, 312
	beqz.n	a8, .L4739
	l32r	a10, .LC1866
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	movi	a11, 0x138
	add.n	a11, a5, a11
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
	j	.L4739
.L4755:
	add.n	a8, a7, a6
	l8ui	a8, a8, 110
	l32r	a9, .LC1835
	beqz.n	a8, .L4758
	l32r	a9, .LC1833
.L4758:
	add.n	a6, a7, a6
	movi.n	a8, 0
	s8i	a8, a6, 58
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32r	a8, .LC1855
	movi.n	a10, 1
	add.n	a8, a7, a8
	s8i	a10, a8, 0
	movi.n	a8, 0
	s32i	a8, a6, 144
	l32r	a8, .LC1868
	s32i	a9, a6, 152
	s32i	a8, a6, 148
	movi.n	a8, 4
	j	.L4957
.L4750:
	l8ui	a9, a2, 63
	l8ui	a4, a2, 57
	beqz.n	a9, .L4759
	addi	a3, a4, -6
	extui	a9, a3, 0, 8
	bgeui	a9, 2, .L4759
	l32i	a11, a2, 68
	bnez.n	a11, .L4760
	movi	a12, 0x88
	mov.n	a10, sp
	call8	memset
	movi.n	a8, 7
	s16i	a8, sp, 14
	movi	a8, 0x190
	s16i	a8, sp, 18
	movi.n	a8, 1
	s8i	a8, sp, 66
	movi.n	a8, 2
	s16i	a8, sp, 88
	bnei	a4, 7, .L4762
	movi.n	a8, 2
	s32i	a8, sp, 4
	l16ui	a8, a2, 66
	s16i	a8, sp, 18
.L4762:
	add.n	a5, a7, a6
	l8ui	a12, a5, 56
	l32i	a11, a5, 48
	movi.n	a13, 1
	addi	a15, a5, 68
	mov.n	a14, sp
	moveqz	a13, a3, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm
	l32r	a8, .LC1869
	l32i	a9, a5, 36
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	beqz.n	a10, .L4763
	l32r	a8, .LC1855
	addmi	a11, sp, 0x100
	add.n	a8, a7, a8
	l8ui	a12, a8, 0
	bnez.n	a12, .L4764
	l32r	a9, .LC1837
	movi.n	a12, 1
	j	.L4765
.L4764:
	l32i	a10, a8, 4
	l32i	a13, a8, 0
	movi	a9, 0x80
	l32i	a8, a8, 8
	add.n	a9, a11, a9
	s32i	a10, a9, 4
	s32i	a13, a9, 0
	s32i	a8, a9, 8
	l32i	a10, a5, 144
	l32i	a9, a5, 148
.L4765:
	add.n	a6, a7, a6
	movi.n	a8, 5
	s8i	a12, a11, 128
	s8i	a8, a6, 57
	movi.n	a13, 0
	l32i	a11, a11, 128
	movi	a8, 0x8c
	s8i	a13, a6, 58
	add.n	a8, a6, a8
	s32i	a11, a8, 0
	s32i	a10, a8, 4
	s32i	a9, a8, 8
	s32i	a9, a6, 152
	s8i	a13, a6, 136
	j	.L4739
.L4763:
	l32i	a11, a5, 68
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	movi.n	a8, 1
	j	.L4955
.L4760:
	mov.n	a10, a7
	s32i	a8, sp, 576
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L4739
	l8ui	a9, a10, 65
	beqz.n	a9, .L4739
	addmi	a9, a10, 0x1000
	addmi	a10, a10, 0x1f00
	l8ui	a11, a10, 68
	l8ui	a9, a9, 209
	s8i	a11, a2, 109
	l32i	a8, sp, 576
	beqi	a9, 2, .L4767
	movi.n	a9, 5
	s8i	a9, a2, 57
	addi	a11, a10, 72
	movi	a9, 0x8c
	l32i	a10, a10, 72
	add.n	a9, a2, a9
	s8i	a8, a2, 58
	l32i	a12, a11, 4
	s32i	a10, a9, 0
	l32i	a10, a11, 8
	s32i	a12, a9, 4
	s32i	a10, a9, 8
	l32r	a9, .LC1871
	s8i	a8, a2, 136
	s32i	a9, a2, 152
	j	.L4739
.L4767:
	bnei	a4, 6, .L4768
	addi	a11, a2, 68
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm
	beqz.n	a10, .L4739
	movi.n	a8, 3
	s8i	a8, a2, 57
	j	.L4739
.L4768:
	s32i	a8, a2, 20
	movi.n	a8, 1
	s32i	a8, a2, 24
	movi.n	a8, 0
	l16ui	a9, a2, 66
	s32i	a8, a2, 28
	l32r	a8, .LC1854
	movi.n	a6, 1
	s16i	a9, a2, 80
	s32i	a9, a2, 16
	add.n	a10, a7, a8
	movi	a12, 0x150
	movi.n	a11, 0
	s8i	a6, a2, 64
	s8i	a6, a2, 32
	call8	memset
	call8	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev
	s8i	a6, a2, 57
	j	.L4739
.L4759:
	movi.n	a8, -3
	and	a8, a4, a8
	bnei	a8, 1, .L4770
	add.n	a5, a7, a6
	l32i	a11, a5, 44
	bnez.n	a11, .L4771
	l32i	a11, a5, 48
	l8ui	a12, a5, 56
	beqi	a4, 1, .L4772
	movi.n	a4, 2
.L4772:
	add.n	a6, a7, a6
	movi.n	a15, 0
	addi	a14, a6, 44
	mov.n	a13, a4
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114startTypedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERmb
	l32r	a8, .LC1869
	l32i	a9, a6, 36
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	beqz.n	a10, .L4773
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32r	a8, .LC1855
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a6, 58
	movi.n	a11, 1
	s8i	a11, a8, 0
	l32r	a8, .LC1874
	s32i	a10, a6, 144
	s32i	a8, a6, 148
	l32r	a8, .LC1876
	j	.L4961
.L4773:
	l32i	a11, a6, 44
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	movi.n	a8, 1
.L4955:
	s8i	a8, a10, 69
	j	.L4739
.L4771:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L4739
	l8ui	a8, a10, 65
	beqz.n	a8, .L4739
	l8ui	a8, a10, 101
	beqi	a8, 2, .L4777
	movi.n	a8, 0
	movi	a9, 0x84
	s8i	a8, a5, 58
	add.n	a10, a10, a9
	movi.n	a8, 5
	l32i	a9, a10, 0
	s8i	a8, a5, 57
	movi	a8, 0x8c
	add.n	a8, a5, a8
	l32i	a11, a10, 4
	s32i	a9, a8, 0
	l32i	a9, a10, 8
	s32i	a11, a8, 4
	s32i	a9, a8, 8
	l32r	a8, .LC1878
	s32i	a8, a5, 152
	movi.n	a8, 3
	s8i	a8, a5, 136
	j	.L4739
.L4777:
	addi	a11, a5, 44
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118releaseSimpleChildERNS_3AppERm
	beqz.n	a10, .L4739
	l8ui	a9, a5, 57
	bnei	a9, 1, .L4778
	l32r	a8, .LC1879
	s8i	a9, a5, 73
	add.n	a8, a7, a8
	l16ui	a11, a8, 0
	l16ui	a10, a8, 2
	s16i	a11, a5, 82
	l16ui	a11, a8, 14
	s16i	a10, a5, 80
	s16i	a11, a5, 84
	l16ui	a11, a8, 26
	s16i	a11, a5, 86
	l16ui	a11, a8, 28
	l16ui	a8, a8, 12
	s16i	a11, a5, 88
	s16i	a8, a5, 90
	l32r	a8, .LC1853
	add.n	a8, a7, a8
	l8ui	a11, a8, 46
	s8i	a11, a5, 104
	l8ui	a11, a8, 51
	s8i	a11, a5, 105
	l8ui	a11, a8, 52
	s8i	a11, a5, 106
	l8ui	a8, a8, 50
	s8i	a8, a5, 107
	l8ui	a8, a5, 63
	beqz.n	a8, .L4779
	l16ui	a8, a5, 66
	bnez.n	a8, .L4780
	movi.n	a10, 5
	s8i	a10, a5, 57
	l32r	a10, .LC1855
	s8i	a8, a5, 58
	s8i	a9, a5, 60
	add.n	a10, a7, a10
	s8i	a8, a10, 0
	s32i	a8, a5, 144
	l32r	a8, .LC1880
	s8i	a9, a5, 136
	s32i	a8, a5, 148
	l32r	a8, .LC1829
	s32i	a8, a5, 152
	j	.L4739
.L4780:
	l8ui	a9, a5, 64
	beqz.n	a9, .L4844
	movi.n	a9, 3
	beq	a10, a8, .L4782
	add.n	a6, a7, a6
	movi.n	a8, 0
	s8i	a8, a6, 58
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32r	a8, .LC1855
	movi.n	a9, 1
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	l32r	a9, .LC1882
	movi.n	a8, 0
	s32i	a9, a6, 148
	s32i	a8, a6, 144
	l32r	a9, .LC1884
	j	.L4958
.L4844:
	movi.n	a9, 6
.L4782:
	add.n	a6, a7, a6
	s8i	a9, a6, 57
	j	.L4739
.L4779:
	l8ui	a8, a5, 72
	bnez.n	a8, .L4783
	movi.n	a8, 3
	s8i	a8, a5, 57
	j	.L4739
.L4783:
	movi	a12, 0x118
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a8, .LC1829
	movi	a11, 0xc8
	add.n	a11, a5, a11
	s32i	a8, sp, 272
	s32i	a11, a5, 76
	mov.n	a13, sp
	movi.n	a12, 1
	mov.n	a10, a7
.LEHB0:
	call8	_ZN12_GLOBAL__N_122motionProfileOperationERNS_3AppERNS0_18MotionProfileStateEN21MotorControlRSExample5Probe20MotionProfileCommandERNS5_17MotionProfileViewE
	add.n	a6, a7, a6
	beqz.n	a10, .L4960
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32r	a8, .LC1855
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a6, 58
	movi.n	a11, 1
	s8i	a11, a8, 0
	l32r	a8, .LC1886
	s32i	a10, a6, 144
	s32i	a8, a6, 148
	l32r	a8, .LC1888
	j	.L4961
.L4778:
	l32r	a4, .LC1890
	movi	a15, 0x3e8
	add.n	a8, a7, a4
	s32i	a8, sp, 584
	l32i	a8, a7, 0
	l32r	a5, .LC1891
	muluh	a4, a15, a8
	mull	a14, a15, a8
	l32r	a3, .LC1889
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	l32i	a11, sp, 584
	mov.n	a15, a4
	add.n	a10, a7, a5
	add.n	a2, a7, a3
	s32i	a14, sp, 588
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L4786
	l32i	a14, sp, 588
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	l32i	a11, sp, 584
	mov.n	a15, a4
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L4786
	l8ui	a8, a2, 60
	beqz.n	a8, .L4786
	add.n	a5, a7, a5
	l16ui	a8, a5, 22
	bnez.n	a8, .L4786
	l8ui	a8, a5, 35
	bnez.n	a8, .L4786
	l8ui	a8, a5, 36
	beqz.n	a8, .L4787
.L4786:
	add.n	a6, a7, a6
	movi.n	a8, 0
	s8i	a8, a6, 58
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32r	a8, .LC1855
	movi.n	a9, 1
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	l32r	a9, .LC1893
	movi.n	a8, 0
	s32i	a9, a6, 148
	s32i	a8, a6, 144
	l32r	a9, .LC1895
	j	.L4958
.L4787:
	l8ui	a8, a5, 34
	bnez.n	a8, .L4739
	add.n	a3, a7, a3
	l16ui	a8, a3, 58
	bnez.n	a8, .L4739
	add.n	a8, a7, a6
	l8ui	a9, a8, 63
	beqz.n	a9, .L4788
	l8ui	a9, a8, 64
	bnez.n	a9, .L4788
	l16ui	a9, a8, 66
	l16ui	a12, a8, 80
	beq	a9, a12, .L4789
	movi.n	a9, 7
	s8i	a9, a8, 57
	j	.L4739
.L4789:
	l32r	a8, .LC1896
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L4790
	l32r	a8, .LC1897
	add.n	a10, a7, a8
	l32i	a10, a10, 0
	bne	a10, a9, .L4790
	add.n	a8, a7, a8
	l32i	a11, a8, 4
	bnei	a11, 1, .L4790
	l32r	a8, .LC1850
	movi.n	a9, 0
	add.n	a8, a7, a8
	s32i	a9, a8, 28
	movi.n	a10, 0
	movi.n	a13, 1
	movi	a9, 0xb0
	s32i	a12, a8, 16
	s32i	a10, a8, 20
	s32i	a13, a8, 24
	add.n	a9, a8, a9
	s32i	a12, a9, 0
	movi.n	a12, 0
	s32i	a10, a9, 4
	s32i	a13, a9, 8
	s32i	a12, a9, 12
	movi.n	a9, 5
	s8i	a9, a8, 57
	l32r	a9, .LC1855
	s8i	a11, a8, 32
	add.n	a9, a7, a9
	s8i	a11, a8, 192
	s8i	a11, a8, 60
	s8i	a10, a8, 58
	s8i	a10, a9, 0
	l32r	a9, .LC1880
	s32i	a10, a8, 144
	s32i	a9, a8, 148
	l32r	a9, .LC1829
	s8i	a11, a8, 136
	s32i	a9, a8, 152
	j	.L4739
.L4790:
	add.n	a8, a7, a6
	s16i	a9, a8, 80
	s32i	a9, a8, 16
	movi.n	a9, 0
	s32i	a9, a8, 20
	movi.n	a9, 1
	movi.n	a10, 1
	s32i	a9, a8, 24
	movi.n	a9, 0
	s32i	a9, a8, 28
	s8i	a10, a8, 64
	s8i	a10, a8, 32
	l32r	a8, .LC1854
	movi	a12, 0x150
	add.n	a10, a7, a8
	movi.n	a11, 0
	call8	memset
	call8	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev
	j	.L4792
.L4788:
	add.n	a8, a7, a6
	l8ui	a8, a8, 32
	beqz.n	a8, .L4793
.L4792:
	l32r	a8, .LC1897
	add.n	a8, a7, a8
	l32i	a10, a8, 0
	beqz.n	a10, .L4794
	add.n	a9, a7, a6
	l32i	a11, a9, 16
	bne	a10, a11, .L4794
	l32i	a10, a8, 4
	l32i	a8, a9, 24
	beq	a10, a8, .L4793
.L4794:
	addmi	a5, sp, 0x100
	movi	a3, 0x80
	add.n	a3, a5, a3
	movi.n	a11, 0
	movi	a12, 0x70
	mov.n	a10, a3
	call8	memset
	add.n	a12, a7, a6
	movi.n	a9, 1
	movi.n	a4, 1
	movi.n	a2, 0
	movi.n	a13, 2
	addi	a11, a12, 16
	movi	a10, 0x88
	l32i	a12, a12, 16
	s8i	a9, a5, 194
	s8i	a13, a5, 196
	s8i	a9, a5, 217
	s8i	a9, a5, 128
	s32i	a4, a5, 160
	s32i	a2, a5, 164
	s32i	a4, a5, 184
	s32i	a2, a5, 188
	add.n	a10, a5, a10
	s32i	a12, a10, 0
	l32i	a14, a11, 4
	l32i	a12, a11, 8
	l32i	a11, a11, 12
	s32i	a12, a10, 8
	s32i	a11, a10, 12
	s32i	a14, a10, 4
	movi	a12, 0x180
	movi.n	a11, 0
	mov.n	a10, sp
	s32i	a13, sp, 592
	s32i	a9, sp, 588
	call8	memset
	l32r	a10, .LC1946
	l32i	a9, sp, 588
	s32i	a10, sp, 104
	movi.n	a10, 0
	s32i	a10, sp, 120
	movi.n	a10, -1
	slli	a10, a10, 31
	s32i	a10, sp, 124
	movi.n	a10, -1
	l32r	a11, .LC1947
	s32i	a10, sp, 128
	l32i	a13, sp, 592
	movi.n	a10, -1
	s8i	a9, sp, 0
	srli	a10, a10, 1
	movi.n	a9, 1
	s32i	a11, sp, 108
	s32i	a10, sp, 132
	s32i	a9, sp, 20
	s32i	a9, sp, 28
	s32i	a9, sp, 40
	s32i	a9, sp, 52
	s32i	a9, sp, 64
	s32i	a9, sp, 76
	s8i	a9, sp, 92
	s8i	a9, sp, 96
	s32i	a4, sp, 200
	s32i	a2, sp, 204
	s8i	a9, sp, 210
	s8i	a13, sp, 212
	s8i	a9, sp, 233
	s32i	a4, sp, 272
	s32i	a2, sp, 276
	s8i	a9, a5, 104
	mov.n	a12, sp
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_111axisCommandEPvRKN21MotorControlRSExample5Probe11AxisCommandERNS2_8AxisViewE
	movi	a8, 0x1f0
	add.n	a8, sp, a8
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	extui	a8, a10, 0, 8
	beqz.n	a8, .L4793
	add.n	a6, a7, a6
	movi.n	a8, 5
	s8i	a8, a6, 57
	movi.n	a9, 0
	movi	a8, 0x8c
	add.n	a8, a6, a8
	s8i	a9, a6, 58
	s32i	a10, a8, 0
	s32i	a11, a8, 4
	s32i	a12, a8, 8
	l32r	a8, .LC1903
	j	.L4961
.L4793:
	add.n	a6, a7, a6
	l8ui	a8, a6, 64
	l32r	a2, .LC1904
	beqz.n	a8, .L4799
	add.n	a8, a7, a2
	movi.n	a9, 1
	s8i	a9, a8, 0
	l32r	a8, .LC1905
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a8, 0
.L4799:
	l32r	a8, .LC1889
	movi.n	a10, -1
	add.n	a8, a7, a8
	l32i	a3, a8, 64
	movi.n	a5, 0
	movi.n	a8, -1
	srli	a10, a10, 4
	movltz	a5, a8, a3
	add.n	a4, a3, a10
	mov.n	a9, a5
	bgeu	a4, a10, .L4801
	addi.n	a9, a5, 1
.L4801:
	add.n	a10, a7, a2
	l8ui	a10, a10, 0
	l32r	a6, .LC1850
	beqz.n	a10, .L4802
	l32r	a10, .LC1896
	movi.n	a11, 1
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	xor	a10, a10, a11
	extui	a10, a10, 0, 8
	beqz.n	a10, .L4803
	bnez.n	a9, .L4803
	l32r	a10, .LC1908
	bltu	a10, a4, .L4803
	mov.n	a11, a7
	mov.n	a10, sp
	s32i	a9, sp, 588
	call8	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE
	movi.n	a10, 1
	l32r	a11, .LC1911
	s8i	a10, sp, 18
	s8i	a10, sp, 33
	l32r	a10, .LC1910
	add.n	a11, a7, a11
	add.n	a10, a7, a10
	l32i	a12, a11, 0
	l32i	a13, a11, 4
	l32i	a11, a10, 0
	l32i	a10, a10, 4
	s32i	a3, sp, 24
	s32i	a5, sp, 28
	l32i	a9, sp, 588
	bltu	a13, a10, .L4807
	bne	a10, a13, .L4806
	bgeu	a12, a11, .L4806
.L4807:
	mov.n	a11, a12
	mov.n	a10, a13
.L4806:
	s32i	a10, sp, 44
	l32i	a10, sp, 584
	s32i	a11, sp, 40
	mov.n	a14, sp
	mov.n	a12, a3
	mov.n	a13, a5
	s32i	a9, sp, 588
	call8	_ZN14MotorControlRS13setAxisOriginERNS_10AxisConfigExRKNS_13AxisReferenceE
	s32i	a10, sp, 384
	s32i	a11, sp, 388
	s32i	a12, sp, 392
	extui	a10, a10, 0, 8
	l32i	a9, sp, 588
	addmi	a13, sp, 0x100
	beqz.n	a10, .L4808
	movi	a10, 0x80
	add.n	a6, a7, a6
	add.n	a13, a13, a10
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32i	a10, a13, 0
	movi.n	a9, 0
	movi	a8, 0x8c
	add.n	a8, a6, a8
	s8i	a9, a6, 58
	s32i	a10, a8, 0
	l32i	a11, a13, 4
	l32i	a10, a13, 8
	s32i	a11, a8, 4
	s32i	a10, a8, 8
	l32r	a8, .LC1913
	j	.L4961
.L4808:
	l32r	a10, .LC1905
	movi.n	a11, 1
	add.n	a10, a7, a10
	s8i	a11, a10, 0
.L4803:
	add.n	a2, a7, a2
	movi.n	a10, 0
	s8i	a10, a2, 0
.L4802:
	l32r	a10, .LC1905
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L4810
	l32r	a10, .LC1896
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	beqz.n	a10, .L4810
	bnez.n	a9, .L4855
	l32r	a9, .LC1908
	bgeu	a9, a4, .L4954
.L4855:
	movi.n	a12, 0
	movi.n	a13, 0
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	j	.L4810
.L4954:
	mov.n	a11, a7
	mov.n	a10, sp
	call8	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE
	l32r	a8, .LC1911
	l32r	a9, .LC1910
	add.n	a8, a7, a8
	add.n	a9, a7, a9
	l32i	a11, a9, 0
	l32i	a10, a9, 4
	l32i	a9, a8, 0
	l32i	a8, a8, 4
	bltu	a10, a8, .L4815
	bne	a8, a10, .L4814
	bgeu	a11, a9, .L4814
.L4815:
	mov.n	a9, a11
	mov.n	a8, a10
.L4814:
	movi.n	a10, 1
	s8i	a10, sp, 18
	s8i	a10, sp, 33
	l32r	a10, .LC1914
	s32i	a3, sp, 24
	s32i	a5, sp, 28
	s32i	a9, sp, 40
	s32i	a8, sp, 44
	movi.n	a12, 0x40
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
.L4810:
	add.n	a8, a7, a6
	l8ui	a9, a8, 64
	beqz.n	a9, .L4816
	l32r	a9, .LC1896
	add.n	a9, a7, a9
	l8ui	a10, a9, 0
	l32r	a9, .LC1855
	beqz.n	a10, .L4817
	l32r	a10, .LC1915
	add.n	a10, a7, a10
	l8ui	a10, a10, 0
	bnez.n	a10, .L4818
.L4817:
	add.n	a6, a7, a6
	movi.n	a8, 0
	s8i	a8, a6, 58
	movi.n	a8, 5
	s8i	a8, a6, 57
	add.n	a9, a7, a9
	movi.n	a8, 1
	s8i	a8, a9, 0
	l32r	a9, .LC1917
	movi.n	a8, 0
	s32i	a9, a6, 148
	s32i	a8, a6, 144
	l32r	a9, .LC1919
	j	.L4958
.L4818:
	l32i	a12, a8, 16
	movi	a10, 0xb0
	l32i	a13, a8, 20
	add.n	a10, a8, a10
	s32i	a12, a10, 0
	l32i	a12, a8, 24
	s32i	a13, a10, 4
	l32i	a11, a8, 28
	s32i	a12, a10, 8
	s32i	a11, a10, 12
	movi.n	a12, 5
	movi.n	a10, 1
	movi.n	a11, 0
	add.n	a9, a7, a9
	s8i	a10, a8, 192
	s8i	a10, a8, 60
	s8i	a11, a8, 58
	s8i	a12, a8, 57
	s8i	a11, a9, 0
	movi.n	a9, 0
	s32i	a9, a8, 144
	l32r	a9, .LC1880
	s8i	a10, a8, 136
	s32i	a9, a8, 148
	l32r	a9, .LC1829
	s32i	a9, a8, 152
	j	.L4739
.L4816:
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118simpleProfileReadyERKNS_3AppEy
	beqz.n	a10, .L4819
.L4821:
	add.n	a6, a7, a6
.L4960:
	movi.n	a8, 2
	s8i	a8, a6, 57
	j	.L4739
.L4819:
	movi	a12, 0x118
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a8, .LC1829
	mov.n	a12, sp
	s32i	a8, sp, 272
	movi.n	a11, 1
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_120motionProfileCommandEPvN21MotorControlRSExample5Probe20MotionProfileCommandERNS2_17MotionProfileViewE
	beqz.n	a10, .L4821
	add.n	a6, a7, a6
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32r	a8, .LC1855
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a6, 58
	movi.n	a11, 1
	s8i	a11, a8, 0
	l32r	a8, .LC1886
	s32i	a10, a6, 144
	s32i	a8, a6, 148
	l32r	a8, .LC1921
.L4961:
	s32i	a8, a6, 152
	j	.L4956
.L4770:
	bnei	a4, 2, .L4739
	l8ui	a3, a5, 0
	bnez.n	a3, .L4739
	l8ui	a8, a5, 3
	add.n	a6, a7, a6
	bnez.n	a8, .L4822
	l32r	a9, .LC1855
	movi.n	a10, 5
	s8i	a8, a6, 58
	s8i	a10, a6, 57
	add.n	a9, a7, a9
	s8i	a10, a9, 0
	s32i	a8, a6, 144
	l32r	a8, .LC1923
	s32i	a8, a6, 148
	l32r	a8, .LC1925
	s32i	a8, a6, 152
	movi.n	a8, 3
	j	.L4957
.L4822:
	l8ui	a10, a6, 72
	beqz.n	a10, .L4823
	movi.n	a12, 0xc
	addi	a11, a5, 52
	addi	a10, a6, 92
	call8	memcpy
	movi.n	a9, 5
	s8i	a9, a6, 57
	l32r	a9, .LC1855
	movi.n	a8, 1
	add.n	a9, a7, a9
	s8i	a8, a6, 60
	s8i	a8, a6, 74
	s8i	a3, a6, 58
	s8i	a3, a9, 0
	l32r	a9, .LC1880
	s32i	a3, a6, 144
	s32i	a9, a6, 148
	l32r	a9, .LC1829
	j	.L4958
.L4823:
	l16ui	a8, a6, 0
	bnez.n	a8, .L4824
	movi.n	a9, 5
	s8i	a9, a6, 57
	l32r	a9, .LC1855
	s8i	a8, a6, 58
	add.n	a9, a7, a9
	s8i	a4, a9, 0
	l32r	a9, .LC1927
	s32i	a8, a6, 144
	s32i	a9, a6, 148
	l32r	a9, .LC1929
	j	.L4958
.L4824:
	l32r	a13, .LC1930
	movi	a14, 0x3e8
	add.n	a13, a7, a13
	l8ui	a3, a13, 0
	l32i	a13, a7, 0
	l32r	a4, .LC1890
	mull	a15, a14, a13
	muluh	a14, a14, a13
	l32r	a13, .LC1853
	s32i	a8, sp, 588
	add.n	a13, a7, a13
	s32i	a13, sp, 4
	l32r	a13, .LC1854
	l32r	a8, .LC1891
	add.n	a13, a7, a13
	s32i	a13, sp, 8
	l32r	a13, .LC1931
	add.n	a8, a7, a8
	add.n	a13, a7, a13
	s32i	a13, sp, 20
	s32i	a12, sp, 24
	s32i	a14, sp, 36
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	addmi	a2, sp, 0x200
	add.n	a4, a7, a4
	movi	a14, 0x23c
	s16i	a10, a2, 60
	s32i	a8, sp, 12
	s32i	a10, sp, 40
	s32i	a4, sp, 0
	s8i	a3, sp, 16
	s32i	a11, sp, 28
	s32i	a15, sp, 32
	add.n	a14, sp, a14
	mov.n	a10, sp
	s32i	a8, sp, 584
	call8	_ZN12_GLOBAL__N_121positionStartingSpeedERKNS_11MotionFactsEyRt$constprop$0
	l32i	a8, sp, 588
	movi.n	a5, 0
	bnez.n	a10, .L4825
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32r	a8, .LC1855
	s8i	a5, a6, 58
	add.n	a8, a7, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
	l32r	a8, .LC1933
	s32i	a10, a6, 144
	s32i	a8, a6, 148
	l32r	a8, .LC1935
	s8i	a5, a6, 136
	s32i	a8, a6, 152
	j	.L4739
.L4825:
	l16ui	a10, a2, 60
	bgeu	a8, a10, .L4826
	l32r	a10, .LC1841
	beqz.n	a3, .L4827
	l32r	a10, .LC1839
.L4827:
	l32r	a8, .LC1850
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a8, 58
	movi.n	a9, 5
	s8i	a9, a8, 57
	l32r	a9, .LC1855
	movi.n	a11, 2
	add.n	a9, a7, a9
	s8i	a11, a9, 0
	l32r	a11, .LC1937
	movi.n	a9, 0
	s32i	a9, a8, 144
	s32i	a11, a8, 148
	s32i	a10, a8, 152
	s8i	a9, a8, 136
	j	.L4739
.L4826:
	addmi	a5, sp, 0x100
	movi	a13, 0x80
	l32r	a11, .LC1938
	add.n	a10, a5, a13
	movi.n	a12, 0x48
	s32i	a8, sp, 588
	call8	memcpy
	addmi	a11, a6, 0x200
	addi	a11, a11, 24
	movi.n	a12, 0x40
	call8	memcpy
	l32r	a3, .LC1862
	l32i	a8, sp, 588
	add.n	a10, a7, a3
	l32i	a10, a10, 0
	s16i	a8, a5, 192
	movi.n	a8, 1
	s8i	a8, a5, 194
	l8ui	a8, a6, 8
	s32i	a10, a5, 152
	movi	a10, 0x1f0
	s8i	a8, a5, 195
	mov.n	a11, a7
	add.n	a10, sp, a10
	call8	_ZN12_GLOBAL__N_113axisReferenceERKNS_3AppE
	movi	a12, 0xc0
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi.n	a12, 2
	s8i	a12, sp, 20
	movi	a12, 0x1f0
	movi.n	a10, 0
	add.n	a12, sp, a12
	movi.n	a8, 1
	s32i	a10, sp, 12
	s32i	a10, sp, 84
	l8ui	a10, a12, 18
	s8i	a8, sp, 18
	s8i	a8, sp, 41
	s8i	a8, sp, 168
	movi.n	a8, 0
	movi.n	a11, 1
	moveqz	a12, a8, a10
	movi	a10, 0x180
	s32i	a11, sp, 8
	s32i	a11, sp, 80
	mov.n	a13, sp
	mov.n	a11, a4
	add.n	a10, sp, a10
	call8	_ZN14MotorControlRS15preparePositionERKNS_15PositionRequestERKNS_10AxisConfigEPKNS_13AxisReferenceERNS_14PreparedTargetE
	s32i	a10, a2, 48
	s32i	a11, a2, 52
	s32i	a12, a2, 56
	extui	a10, a10, 0, 8
	l32r	a6, .LC1850
	beqz.n	a10, .L4830
	l8ui	a8, a5, 144
	beqz.n	a8, .L4831
	l32r	a8, .LC1897
	l32r	a10, .LC1843
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L4832
.L4831:
	l8ui	a8, a5, 146
	bnez.n	a8, .L4833
	l8ui	a8, a5, 145
	beqz.n	a8, .L4833
	l32r	a8, .LC1896
	l32r	a10, .LC1845
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L4832
.L4833:
	l32i	a10, a2, 56
.L4832:
	add.n	a6, a7, a6
	movi.n	a8, 5
	s8i	a8, a6, 57
	l32i	a9, a2, 48
	movi.n	a11, 0
	movi	a8, 0x8c
	s8i	a11, a6, 58
	add.n	a8, a6, a8
	s32i	a9, a8, 0
	l32i	a13, a2, 52
	l32i	a9, a2, 56
	s32i	a13, a8, 4
	s32i	a9, a8, 8
	s32i	a10, a6, 152
.L4959:
	s8i	a11, a6, 136
	j	.L4739
.L4830:
	add.n	a10, a7, a6
	movi.n	a8, 1
	s8i	a8, a10, 112
	l32i	a12, sp, 104
	l32i	a11, sp, 108
	l32i	a8, sp, 152
	l32i	a9, sp, 156
	s32i	a12, a10, 120
	s32i	a11, a10, 124
	s32i	a8, a10, 128
	s32i	a9, a10, 132
	l8ui	a10, a5, 146
	bnez.n	a10, .L4850
	l32r	a8, .LC1863
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L4834
	l32r	a8, .LC1861
	add.n	a3, a7, a3
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	l32i	a8, a3, 0
	bne	a9, a8, .L4834
	l32r	a8, .LC1860
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	bne	a9, a12, .L4834
	l32i	a8, a8, 4
	bne	a8, a11, .L4834
	l32i	a8, a7, 0
	movi	a14, 0x3e8
	muluh	a15, a14, a8
	l32i	a12, sp, 580
	mull	a14, a14, a8
	l32i	a13, sp, 576
	l32i	a10, sp, 584
	mov.n	a11, a4
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L4834
	l32r	a8, .LC1891
	add.n	a8, a7, a8
	l8ui	a10, a8, 32
	j	.L4834
.L4850:
	movi.n	a10, 0
.L4834:
	l8ui	a8, sp, 144
	bnez.n	a8, .L4856
	beqz.n	a10, .L4835
.L4856:
	add.n	a6, a7, a6
	movi.n	a9, 5
	s8i	a9, a6, 57
	l32r	a9, .LC1855
	movi.n	a8, 1
	movi.n	a10, 0
	add.n	a9, a7, a9
	s8i	a8, a6, 111
	s8i	a8, a6, 60
	s8i	a8, a6, 138
	s8i	a10, a6, 58
	s8i	a10, a9, 0
	movi.n	a9, 0
	s32i	a9, a6, 144
	l32r	a9, .LC1880
	s32i	a9, a6, 148
	l32r	a9, .LC1940
.L4958:
	s32i	a9, a6, 152
.L4957:
	s8i	a8, a6, 136
	j	.L4739
.L4835:
	add.n	a4, a7, a6
	l8ui	a3, a4, 56
	l32i	a12, sp, 580
	l32i	a13, sp, 576
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy
	bnez.n	a10, .L4739
	movi	a13, 0x180
	l32i	a11, a4, 48
	addi	a14, a4, 40
	add.n	a13, sp, a13
	mov.n	a12, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_19startMoveEPvmhRKN14MotorControlRS11MoveRequestERm
.LEHE0:
	l32r	a8, .LC1869
	l32i	a9, a4, 36
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	mov.n	a3, a10
	beqz.n	a10, .L4837
	l32r	a8, .LC1855
	add.n	a9, a7, a8
	l8ui	a9, a9, 0
	beqz.n	a9, .L4838
	l32i	a9, a4, 148
	movi.n	a8, 0
	movi.n	a10, 5
	s8i	a8, a4, 58
	s8i	a10, a4, 57
	s32i	a9, a4, 152
	s8i	a8, a4, 136
	j	.L4739
.L4838:
	l8ui	a9, a5, 195
	l32r	a10, .LC1849
	bnei	a9, 2, .L4839
	l32r	a10, .LC1847
.L4839:
	add.n	a6, a7, a6
	movi.n	a11, 5
	movi.n	a9, 0
	s8i	a11, a6, 57
	add.n	a8, a7, a8
	s8i	a9, a6, 58
	movi.n	a11, 1
	s8i	a11, a8, 0
	l32r	a8, .LC1942
	s32i	a3, a6, 144
	s32i	a8, a6, 148
	s32i	a10, a6, 152
.L4956:
	s8i	a9, a6, 136
	j	.L4739
.L4837:
	l32i	a11, a4, 40
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	movi.n	a9, 1
	movi	a8, 0x6f0
	s8i	a9, a10, 69
	add.n	a8, a10, a8
	s32i	a8, a4, 156
	movi.n	a8, 4
	s8i	a8, a4, 57
	l32r	a8, .LC1852
	s8i	a9, a4, 61
	add.n	a8, a7, a8
	s8i	a3, a8, 0
	j	.L4730
.L4739:
	l32r	a8, .LC1852
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	j	.L4730
.L4853:
	l32r	a8, .LC1852
	mov.n	a10, a2
	add.n	a7, a7, a8
	movi.n	a8, 0
	s8i	a8, a7, 0
.LEHB1:
	call8	_Unwind_Resume
.LEHE1:
.L4730:
	retw.n
.LFE2244:
	.section	.gcc_except_table,"a",@progbits
.LLSDA2244:
	.byte	0xff
	.byte	0xff
	.byte	0x1
	.uleb128 .LLSDACSE2244-.LLSDACSB2244
.LLSDACSB2244:
	.uleb128 .LEHB0-.LFB2244
	.uleb128 .LEHE0-.LEHB0
	.uleb128 .L4853-.LFB2244
	.uleb128 0
	.uleb128 .LEHB1-.LFB2244
	.uleb128 .LEHE1-.LEHB1
	.uleb128 0
	.uleb128 0
.LLSDACSE2244:
	.text
	.size	_ZN12_GLOBAL__N_119serviceSimpleMotionERNS_3AppEy, .-_ZN12_GLOBAL__N_119serviceSimpleMotionERNS_3AppEy
	.literal_position
	.literal .LC1951, 50000
	.literal .LC1953, 53807
	.literal .LC1954, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC1955, 45697
	.literal .LC1956, 45698
	.literal .LC1957, 999999
	.literal .LC1958, 764688
	.literal .LC1960, 757624
	.literal .LC1961, _ZN12_GLOBAL__N_14uartE
	.literal .LC1962, 772072
	.literal .LC1963, 764504
	.literal .LC1964, 764516
	.literal .LC1965, 764508
	.literal .LC1966, 757972
	.literal .LC1967, 757960
	.literal .LC1968, 101004
	.literal .LC1970, 101000
	.literal .LC1971, 625320
	.literal .LC1972, 9040
	.literal .LC1973, .LC4
	.literal .LC1975, 45688
	.literal .LC1976, 45700
	.literal .LC1977, 757628
	.literal .LC1979, 2000000
	.literal .LC1980, 3000000
	.align	4
	.type	_ZN12_GLOBAL__N_113startVelocityEPvmhRKN14MotorControlRS15VelocityRequestERm, @function
_ZN12_GLOBAL__N_113startVelocityEPvmhRKN14MotorControlRS15VelocityRequestERm:
.LFB2156:
	entry	sp, 272
.LCFI180:
	s32i	a6, sp, 232
	movi	a6, 0x7f7
	slli	a6, a6, 5
	extui	a8, a4, 0, 8
	s32i	a3, sp, 228
	mov.n	a3, a5
	add.n	a5, a2, a6
	l32i	a9, a5, 156
	s32i	a8, sp, 208
	l32i	a8, a5, 152
	mov.n	a7, a2
	or	a8, a8, a9
	beqz.n	a8, .L4963
.L4966:
	movi.n	a2, 1
	j	.L4965
.L4963:
	l32r	a8, .LC1953
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L4966
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L4966
	l32r	a8, .LC1954
	l8ui	a8, a8, 0
	bnez.n	a8, .L4967
.L4979:
	movi.n	a2, 3
	j	.L4965
.L4967:
	l32r	a8, .LC1955
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L4968
.L4969:
	movi.n	a2, 2
	j	.L4965
.L4968:
	l32r	a8, .LC1956
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L4969
	l8ui	a8, a5, 137
	bnez.n	a8, .L4969
	l32i	a10, sp, 208
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	beqz.n	a10, .L4990
	l32i	a8, a3, 100
	l32r	a9, .LC1957
	addi.n	a8, a8, -1
	bltu	a9, a8, .L4990
	l32r	a8, .LC1958
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L4971
	l8ui	a8, a3, 18
	bnez.n	a8, .L4979
.L4971:
	l8ui	a8, a3, 56
	bnei	a8, 2, .L4973
.L4974:
	movi.n	a2, 0xb
	j	.L4965
.L4973:
	movi.n	a4, 0
	movi.n	a5, 0
	l32i	a10, a3, 64
	l32i	a11, a3, 68
	mov.n	a12, a4
	mov.n	a13, a5
	call8	__nedf2
	bnez.n	a10, .L4974
	l32i	a10, a3, 72
	l32i	a11, a3, 76
	mov.n	a12, a4
	mov.n	a13, a5
	call8	__nedf2
	bnez.n	a10, .L4974
	l32i	a10, a3, 88
	l32i	a11, a3, 92
	mov.n	a12, a4
	mov.n	a13, a5
	call8	__nedf2
	bnez.n	a10, .L4974
	l8ui	a8, a3, 96
	bnez.n	a8, .L4974
	l8ui	a8, a3, 97
	bnez.n	a8, .L4974
	l32r	a8, .LC1960
	movi.n	a2, 7
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L4965
	add.n	a10, a7, a6
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L4969
	l32r	a5, .LC1961
	mov.n	a10, a5
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L4969
	l32i	a11, sp, 208
	movi.n	a12, 1
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	movi.n	a2, 0xc
	bnez.n	a10, .L4965
	add.n	a6, a7, a6
	l32i	a8, a6, 52
	bnei	a8, -1, .L4966
	l32i	a6, a6, 48
	bnez.n	a6, .L4966
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a13, a11
	l32i	a11, sp, 208
	mov.n	a12, a10
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy
	bnez.n	a10, .L4966
	l32r	a8, .LC1962
	movi.n	a2, 0xf
	add.n	a5, a7, a8
	l32i	a9, a5, 0
	beqz.n	a9, .L4965
	l32r	a4, .LC1963
	mov.n	a10, a5
	add.n	a8, a7, a4
	mov.n	a11, a8
	s32i	a8, sp, 216
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4965
	l32r	a9, .LC1964
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L4965
	l32i	a10, a5, 12
	bne	a9, a10, .L4965
	l8ui	a9, a5, 16
	beqz.n	a9, .L4965
	l8ui	a9, a5, 18
	beqz.n	a9, .L4965
	l8ui	a9, a5, 19
	beqz.n	a9, .L4965
	l8ui	a8, a5, 20
	beqz.n	a8, .L4965
	l32r	a8, .LC1965
	l32i	a9, sp, 208
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bne	a8, a9, .L4979
	l32r	a8, .LC1966
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L4979
	l32r	a10, .LC1967
	l32i	a11, sp, 216
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L4979
	l32r	a8, .LC1968
	l32r	a10, .LC1972
	add.n	a8, a7, a8
	movi.n	a9, 8
	loop	a9, .L4983_LEND
.L4983:
	l32i	a11, a8, 0
	bnez.n	a11, .L4980
	l32r	a8, .LC1972
	l32r	a9, .LC1970
	mul16u	a8, a6, a8
	l32r	a10, .LC1961
	add.n	a8, a8, a9
	add.n	a4, a7, a8
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a2, a11
	l32r	a11, .LC1962
	s32i	a10, sp, 212
	movi.n	a12, 0x38
	add.n	a11, a7, a11
	addi	a10, sp, 112
	call8	memcpy
	l16si	a9, sp, 138
	movi	a10, -0x3c
	max	a9, a9, a10
	l32r	a6, .LC1971
	s16i	a9, sp, 138
	l16si	a9, sp, 140
	movi.n	a10, 0x3c
	add.n	a6, a7, a6
	l32i	a14, sp, 160
	l32i	a15, sp, 164
	l32i	a12, sp, 212
	l32i	a11, sp, 216
	min	a9, a9, a10
	mov.n	a13, a2
	mov.n	a10, a6
	s16i	a9, sp, 140
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	bnez.n	a10, .L4981
	j	.L5030
.L4980:
	addi.n	a6, a6, 1
	add.n	a8, a8, a10
	.L4983_LEND:
	movi.n	a2, 6
	j	.L4965
.L5030:
	s8i	a10, sp, 132
	j	.L4984
.L4981:
	l16ui	a9, a6, 22
	l32i	a10, a6, 240
	l32i	a11, a6, 244
	s16i	a9, sp, 142
	l16ui	a9, a6, 24
	s32i	a10, sp, 152
	s16i	a9, sp, 144
	s32i	a11, sp, 156
.L4984:
	l32i	a9, a3, 100
	l32i	a8, sp, 212
	l8ui	a10, a3, 104
	add.n	a11, a9, a8
	mov.n	a5, a2
	bgeu	a11, a9, .L4985
	addi.n	a5, a2, 1
.L4985:
	l32r	a9, .LC1979
	bnei	a10, 1, .L4986
	l32r	a9, .LC1980
.L4986:
	add.n	a8, a11, a9
	s32i	a8, sp, 220
	bgeu	a8, a9, .L4987
	addi.n	a5, a5, 1
.L4987:
	l32r	a11, .LC1973
	movi	a9, 0xc0
	l32i	a12, a11, 4
	l32i	a11, a11, 8
	add.n	a9, sp, a9
	s32i	a12, a9, 4
	s32i	a11, a9, 8
	movi.n	a9, 0x40
	s8i	a9, sp, 196
	movi.n	a9, 0x20
	addmi	a9, a9, 0x4e00
	bnei	a10, 1, .L4988
	l32r	a9, .LC1951
.L4988:
	movi.n	a8, 8
	addmi	a8, a8, 0xc00
	add.n	a8, a4, a8
	s32i	a8, sp, 224
	s32i	a9, sp, 192
	addi	a8, sp, 32
	movi	a9, 0xa0
	add.n	a9, a8, a9
	l32i	a8, sp, 220
	l32r	a6, .LC1960
	s32i	a8, sp, 8
	l32i	a8, sp, 212
	s32i	a9, sp, 16
	s32i	a5, sp, 12
	s32i	a8, sp, 0
	s32i	a2, sp, 4
	add.n	a6, a7, a6
	l32i	a12, a6, 0
	l32i	a11, sp, 216
	l32i	a10, sp, 224
	mov.n	a13, a3
	addi	a14, sp, 112
	call8	_ZN14MotorControlRS6ESS_RS15prepareVelocityERNS0_15VelocityContextERKNS_10AxisConfigEmRKNS_15VelocityRequestERKNS0_21VelocityPrerequisitesEyyRKNS_13ActionOptionsE
	s32i	a10, sp, 180
	s32i	a11, sp, 184
	s32i	a12, sp, 188
	extui	a3, a10, 0, 8
	beqz.n	a3, .L4989
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	bnei	a3, 3, .L4990
	j	.L4974
.L4989:
	addmi	a9, a4, 0xc00
	l16ui	a9, a9, 192
	movi	a10, 0x78
	addi	a9, a9, 60
	extui	a9, a9, 0, 16
	bgeu	a10, a9, .L4991
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
.L4990:
	movi.n	a2, 8
	j	.L4965
.L4991:
	movi.n	a12, 0x50
	movi.n	a11, 0
	addi	a10, sp, 32
	call8	memset
	l32i	a12, sp, 212
	l32i	a10, sp, 224
	movi.n	a9, 2
	addi	a14, sp, 32
	mov.n	a13, a2
	s8i	a9, sp, 32
	call8	_ZN14MotorControlRS6ESS_RS12nextVelocityERKNS0_15VelocityContextEyRNS0_16PreparedVelocityE
	s32i	a10, sp, 168
	s32i	a11, sp, 172
	s32i	a12, sp, 176
	extui	a10, a10, 0, 8
	beqz.n	a10, .L4993
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	movi.n	a2, 4
	j	.L4965
.L4993:
	l32i	a14, sp, 212
	mov.n	a15, a2
	addi	a12, sp, 32
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_117admitVelocityStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS16PreparedVelocityEy
	mov.n	a2, a10
	beqz.n	a10, .L4994
	mov.n	a10, a4
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	j	.L4965
.L4994:
	l32r	a11, .LC1975
	movi.n	a12, 5
	add.n	a11, a7, a11
	addi.n	a10, a4, 12
	call8	memcpy
	l32r	a9, .LC1976
	l32i	a8, sp, 228
	add.n	a9, a7, a9
	l32i	a9, a9, 0
	s32i	a9, a4, 20
	l32i	a9, a6, 0
	addi.n	a10, a9, 1
	s32i	a10, a6, 0
	s32i	a8, a4, 8
	l32i	a8, sp, 208
	movi.n	a10, 5
	s8i	a8, a4, 24
	l32i	a8, sp, 220
	s8i	a10, a4, 0
	s32i	a8, a4, 56
	s32i	a9, a4, 4
	s32i	a5, a4, 60
	addmi	a8, a4, 0x300
	movi.n	a10, 1
	s8i	a10, a8, 8
	l32r	a8, .LC1977
	add.n	a7, a7, a8
	l32i	a8, sp, 232
	s32i	a9, a7, 0
	s32i	a9, a8, 0
.L4965:
	retw.n
.LFE2156:
	.size	_ZN12_GLOBAL__N_113startVelocityEPvmhRKN14MotorControlRS15VelocityRequestERm, .-_ZN12_GLOBAL__N_113startVelocityEPvmhRKN14MotorControlRS15VelocityRequestERm
	.section	.text._ZN21MotorControlRSExample5Probe10StateCacheC2Ev,"axG",@progbits,_ZN21MotorControlRSExample5Probe10StateCacheC5Ev,comdat
	.literal_position
	.literal .LC1981, .LC12
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe10StateCacheC2Ev
	.type	_ZN21MotorControlRSExample5Probe10StateCacheC2Ev, @function
_ZN21MotorControlRSExample5Probe10StateCacheC2Ev:
.LFB1970:
	entry	sp, 32
.LCFI181:
	movi	a12, 0x360
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	movi	a8, 0x360
	l32r	a9, .LC1981
	add.n	a8, a2, a8
	movi.n	a15, 9
	movi.n	a14, 0xa
	movi.n	a10, 7
	movi.n	a13, 5
	movi.n	a12, 8
	movi	a11, 0x120
.L5034:
	s8i	a15, a2, 69
	s8i	a14, a2, 70
	s8i	a10, a2, 71
	s8i	a13, a2, 72
	s8i	a10, a2, 73
	s8i	a12, a2, 74
	s32i	a9, a2, 188
	s32i	a9, a2, 280
	add.n	a2, a2, a11
	bne	a2, a8, .L5034
	retw.n
.LFE1970:
	.size	_ZN21MotorControlRSExample5Probe10StateCacheC2Ev, .-_ZN21MotorControlRSExample5Probe10StateCacheC2Ev
	.weak	_ZN21MotorControlRSExample5Probe10StateCacheC1Ev
	.set	_ZN21MotorControlRSExample5Probe10StateCacheC1Ev,_ZN21MotorControlRSExample5Probe10StateCacheC2Ev
	.text
	.align	4
	.type	_ZN12_GLOBAL__N_13App11GroupMemberC2Ev, @function
_ZN12_GLOBAL__N_13App11GroupMemberC2Ev:
.LFB2028:
	entry	sp, 32
.LCFI182:
	movi.n	a8, 0
	movi.n	a7, 0
	s8i	a8, a2, 0
	movi.n	a8, 1
	s32i	a8, a2, 20
	addi	a10, a2, 24
	s32i	a7, a2, 8
	s8i	a7, a2, 12
	s32i	a7, a2, 16
	call8	_ZN14MotorControlRS10UnitConfigC1Ev
	movi.n	a8, 0
	s32i	a8, a2, 120
	movi.n	a8, -1
	slli	a8, a8, 31
	s32i	a8, a2, 124
	movi.n	a8, -1
	s32i	a8, a2, 128
	movi.n	a8, -1
	srli	a8, a8, 1
	movi.n	a4, 0
	movi.n	a6, 0
	movi	a10, 0xc0
	s32i	a8, a2, 132
	add.n	a10, a2, a10
	s16i	a7, a2, 136
	s32i	a4, a2, 144
	s32i	a6, a2, 148
	s16i	a7, a2, 152
	s32i	a4, a2, 160
	s32i	a6, a2, 164
	s16i	a7, a2, 168
	s32i	a4, a2, 176
	s32i	a6, a2, 180
	s32i	a4, a2, 184
	s32i	a6, a2, 188
	call8	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev
	movi	a10, 0x168
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev
	movi	a10, 0x4a8
	add.n	a10, a2, a10
	call8	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev
	movi	a10, 0x5f8
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10StateCacheC1Ev
	movi	a10, 0x70
	addmi	a8, a2, 0x900
	movi.n	a5, 0
	addmi	a10, a10, 0x900
	add.n	a10, a2, a10
	s32i	a7, a8, 88
	s16i	a7, a8, 92
	s32i	a4, a8, 96
	s32i	a6, a8, 100
	s8i	a5, a8, 104
	call8	_ZN12_GLOBAL__N_13App12StageSessionC1Ev
	addmi	a2, a2, 0xa00
	s8i	a5, a2, 48
	movi.n	a12, 0xa
	movi.n	a11, 0
	addi	a10, a2, 50
	call8	memset
	s32i	a7, a2, 60
	s32i	a7, a2, 64
	s32i	a7, a2, 68
	retw.n
.LFE2028:
	.size	_ZN12_GLOBAL__N_13App11GroupMemberC2Ev, .-_ZN12_GLOBAL__N_13App11GroupMemberC2Ev
	.set	_ZN12_GLOBAL__N_13App11GroupMemberC1Ev,_ZN12_GLOBAL__N_13App11GroupMemberC2Ev
	.section	.text._ZN14MotorControlRS13TrafficRecordC2Ev,"axG",@progbits,_ZN14MotorControlRS13TrafficRecordC5Ev,comdat
	.align	4
	.weak	_ZN14MotorControlRS13TrafficRecordC2Ev
	.type	_ZN14MotorControlRS13TrafficRecordC2Ev, @function
_ZN14MotorControlRS13TrafficRecordC2Ev:
.LFB1995:
	entry	sp, 32
.LCFI183:
	movi.n	a8, 0
	s32i	a8, a2, 4
	s32i	a8, a2, 12
	s32i	a8, a2, 20
	s32i	a8, a2, 28
	s32i	a8, a2, 36
	s32i	a8, a2, 40
	s16i	a8, a2, 44
	s16i	a8, a2, 46
	movi.n	a8, 1
	movi.n	a9, 0
	s8i	a8, a2, 48
	movi.n	a8, 0
	s32i	a9, a2, 0
	s32i	a9, a2, 8
	s32i	a9, a2, 16
	s32i	a9, a2, 24
	s32i	a9, a2, 32
	s8i	a8, a2, 49
	movi	a12, 0x100
	movi.n	a11, 0
	addi	a10, a2, 50
	call8	memset
	retw.n
.LFE1995:
	.size	_ZN14MotorControlRS13TrafficRecordC2Ev, .-_ZN14MotorControlRS13TrafficRecordC2Ev
	.weak	_ZN14MotorControlRS13TrafficRecordC1Ev
	.set	_ZN14MotorControlRS13TrafficRecordC1Ev,_ZN14MotorControlRS13TrafficRecordC2Ev
	.section	.text._ZN21MotorControlRSExample5Probe9GroupViewC2Ev,"axG",@progbits,_ZN21MotorControlRSExample5Probe9GroupViewC5Ev,comdat
	.align	4
	.weak	_ZN21MotorControlRSExample5Probe9GroupViewC2Ev
	.type	_ZN21MotorControlRSExample5Probe9GroupViewC2Ev, @function
_ZN21MotorControlRSExample5Probe9GroupViewC2Ev:
.LFB2043:
	entry	sp, 32
.LCFI184:
	movi.n	a8, 0
	movi.n	a9, 0
	s8i	a8, a2, 0
	movi.n	a8, 0
	s32i	a8, a2, 4
	s32i	a8, a2, 8
	s32i	a9, a2, 16
	s32i	a9, a2, 20
	s8i	a8, a2, 24
	s32i	a8, a2, 28
	s32i	a8, a2, 32
	s32i	a8, a2, 36
	s32i	a8, a2, 40
	s32i	a8, a2, 44
	movi	a12, 0x5a0
	movi.n	a11, 0
	addi	a10, a2, 48
	call8	memset
	retw.n
.LFE2043:
	.size	_ZN21MotorControlRSExample5Probe9GroupViewC2Ev, .-_ZN21MotorControlRSExample5Probe9GroupViewC2Ev
	.weak	_ZN21MotorControlRSExample5Probe9GroupViewC1Ev
	.set	_ZN21MotorControlRSExample5Probe9GroupViewC1Ev,_ZN21MotorControlRSExample5Probe9GroupViewC2Ev
	.text
	.literal_position
	.literal .LC1990, 825104
	.literal .LC1991, 813496
	.literal .LC1992, 813500
	.literal .LC1993, 772456
	.literal .LC1994, 813508
	.literal .LC1995, 815828
	.literal .LC1996, 818148
	.literal .LC1997, 820468
	.literal .LC1998, 822788
	.literal .LC2000, 2632
	.literal .LC2001, 774016
	.literal .LC2002, 774036
	.literal .LC2003, 774024
	.literal .LC2004, 774220
	.literal .LC2005, 774208
	.literal .LC2006, 774228
	.literal .LC2007, 774224
	.literal .LC2008, 825176
	.literal .LC2009, 774376
	.literal .LC2010, 774388
	.literal .LC2011, 775544
	.literal .LC2012, 776424
	.literal .LC2013, 45700
	.literal .LC2014, 775208
	.literal .LC2015, _ZN12_GLOBAL__N_1L23NO_START_SPEED_RELATIONE
	.literal .LC2016, 775211
	.literal .LC2017, 775260
	.literal .LC2018, 776408
	.literal .LC2019, 776412
	.literal .LC2020, 775832
	.literal .LC2021, 776120
	.literal .LC2022, 825200
	.literal .LC2023, 825201
	.literal .LC2024, 825202
	.literal .LC2025, 775760
	.literal .LC2026, 775566
	.literal .LC2027, 825204
	.literal .LC2028, 775568
	.literal .LC2029, 825206
	.literal .LC2030, 775784
	.literal .LC2031, 776048
	.literal .LC2032, 775872
	.literal .LC2033, 825208
	.literal .LC2034, 776336
	.literal .LC2035, 776180
	.literal .LC2036, 825210
	.literal .LC2037, 776184
	.literal .LC2038, 825212
	.literal .LC2039, 776416
	.align	4
	.type	_ZN12_GLOBAL__N_114buildGroupViewERNS_3AppE, @function
_ZN12_GLOBAL__N_114buildGroupViewERNS_3AppE:
.LFB2307:
	entry	sp, 128
.LCFI185:
	l32r	a8, .LC1990
	mov.n	a7, a2
	add.n	a2, a2, a8
	movi	a12, 0x5d0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	memset
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe9GroupViewC1Ev
	call8	_Z18esp_timer_get_timev
	l32r	a8, .LC1991
	s32i	a10, sp, 52
	add.n	a8, a7, a8
	s32i	a8, sp, 72
	l8ui	a8, a8, 0
	s32i	a11, sp, 48
	s8i	a8, a2, 0
	l32r	a8, .LC1992
	movi.n	a6, 0
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 4
	l32r	a8, .LC1993
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a10, a2, 16
	s32i	a8, a2, 8
	s32i	a11, a2, 20
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	l32r	a8, .LC1994
	s8i	a10, a2, 24
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 28
	l32r	a8, .LC1995
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 32
	l32r	a8, .LC1996
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 36
	l32r	a8, .LC1997
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 40
	l32r	a8, .LC1998
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a2, 44
	j	.L5045
.L5054:
	l32r	a8, .LC2000
	l32r	a11, .LC2001
	mul16u	a5, a6, a8
	l32r	a8, .LC2000
	add.n	a3, a6, a6
	mull	a8, a6, a8
	add.n	a4, a3, a6
	add.n	a8, a7, a8
	add.n	a12, a8, a11
	l8ui	a9, a12, 0
	slli	a4, a4, 5
	add.n	a4, a2, a4
	s8i	a9, a4, 48
	l32i	a13, a12, 8
	addi.n	a10, a12, 8
	l32i	a12, a12, 12
	s32i	a13, a4, 52
	l32i	a10, a10, 8
	s32i	a9, sp, 64
	l32r	a9, .LC2002
	s32i	a10, a4, 60
	s32i	a12, a4, 56
	add.n	a9, a8, a9
	l32i	a9, a9, 0
	add.n	a11, a5, a11
	s32i	a9, a4, 64
	add.n	a11, a7, a11
	mov.n	a10, a7
	s32i	a8, sp, 56
	call8	_ZN12_GLOBAL__N_113memberCurrentERKNS_3AppERKNS0_11GroupMemberE
	l32r	a9, .LC2004
	l32i	a8, sp, 56
	s8i	a10, a4, 68
	add.n	a8, a8, a9
	l32r	a4, .LC2003
	l32i	a8, a8, 0
	add.n	a4, a5, a4
	add.n	a4, a7, a4
	movi.n	a10, 0
	beqz.n	a8, .L5046
	l32r	a10, .LC2005
	mov.n	a11, a4
	add.n	a10, a5, a10
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
.L5046:
	l32r	a8, .LC1990
	l32r	a9, .LC2000
	add.n	a3, a3, a6
	slli	a3, a3, 5
	mull	a9, a6, a9
	add.n	a8, a7, a8
	add.n	a8, a8, a3
	l32r	a11, .LC2007
	s8i	a10, a8, 69
	add.n	a9, a7, a9
	l32r	a10, .LC2006
	add.n	a11, a9, a11
	l32r	a12, .LC2008
	l32i	a11, a11, 0
	add.n	a10, a9, a10
	add.n	a3, a7, a3
	l16ui	a10, a10, 0
	add.n	a3, a3, a12
	s32i	a11, a3, 0
	s16i	a10, a8, 76
	l32r	a10, .LC2010
	l32r	a8, .LC2009
	add.n	a9, a9, a10
	l32i	a9, a9, 0
	add.n	a8, a5, a8
	add.n	a8, a7, a8
	movi.n	a10, 0
	beqz.n	a9, .L5047
	mov.n	a10, a8
	mov.n	a11, a4
	s32i	a8, sp, 56
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	l32i	a8, sp, 56
.L5047:
	l32r	a9, .LC1990
	addx2	a12, a6, a6
	add.n	a11, a7, a9
	slli	a12, a12, 5
	add.n	a11, a11, a12
	s8i	a10, a11, 70
	l32r	a3, .LC2000
	l32r	a10, .LC2011
	mull	a3, a6, a3
	add.n	a10, a5, a10
	add.n	a9, a7, a10
	l32r	a10, .LC2012
	add.n	a3, a7, a3
	add.n	a10, a3, a10
	l8ui	a14, a10, 0
	l32r	a10, .LC1993
	s32i	a8, sp, 4
	add.n	a10, a7, a10
	l32i	a13, a10, 0
	l32r	a8, .LC2014
	l32r	a10, .LC2013
	add.n	a8, a5, a8
	add.n	a10, a7, a10
	l32i	a12, a10, 0
	s32i	a9, sp, 68
	l32i	a10, a7, 0
	add.n	a8, a7, a8
	movi	a11, 0x3e8
	s32i	a8, sp, 8
	l32i	a8, sp, 68
	mull	a9, a11, a10
	s32i	a8, sp, 12
	l32r	a8, .LC2015
	s32i	a9, sp, 56
	s32i	a8, sp, 20
	l32i	a8, sp, 56
	muluh	a9, a11, a10
	s32i	a8, sp, 32
	mov.n	a10, sp
	movi.n	a8, 0
	s32i	a9, sp, 60
	s32i	a9, sp, 36
	s32i	a4, sp, 0
	s8i	a14, sp, 16
	s32i	a13, sp, 24
	s32i	a12, sp, 28
	s32i	a8, sp, 40
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_11MotionFactsE
	l32r	a9, .LC1990
	beqz.n	a10, .L5048
	l32r	a8, .LC2016
	add.n	a3, a3, a8
	l8ui	a10, a3, 0
.L5048:
	add.n	a8, a7, a9
	add.n	a9, a6, a6
	add.n	a11, a9, a6
	slli	a11, a11, 5
	add.n	a9, a8, a11
	l32r	a11, .LC2017
	addx2	a8, a6, a6
	slli	a8, a8, 5
	s8i	a10, a9, 71
	add.n	a11, a5, a11
	addi	a10, a8, 78
	movi.n	a12, 0xc
	add.n	a11, a7, a11
	add.n	a10, a2, a10
	s32i	a9, sp, 84
	s32i	a8, sp, 76
	call8	memcpy
	l32r	a10, .LC2018
	l32i	a8, sp, 76
	add.n	a10, a5, a10
	add.n	a10, a7, a10
	l8ui	a12, a10, 0
	addi	a11, a8, 90
	l8ui	a13, a10, 1
	add.n	a11, a2, a11
	s8i	a12, a11, 0
	l8ui	a12, a10, 2
	s8i	a13, a11, 1
	l8ui	a10, a10, 3
	s8i	a12, a11, 2
	s8i	a10, a11, 3
	l32r	a10, .LC2019
	addi	a11, a8, 94
	add.n	a10, a5, a10
	add.n	a10, a7, a10
	l8ui	a12, a10, 0
	l8ui	a10, a10, 1
	add.n	a11, a2, a11
	s8i	a10, a11, 1
	l32r	a3, .LC2020
	l32r	a10, .LC2021
	l32i	a14, sp, 56
	l32i	a15, sp, 60
	l32i	a13, sp, 48
	s8i	a12, a11, 0
	add.n	a3, a5, a3
	l32i	a12, sp, 52
	add.n	a5, a5, a10
	l32i	a10, sp, 68
	s32i	a8, sp, 80
	mov.n	a11, a4
	add.n	a8, a7, a3
	s32i	a8, sp, 76
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	l32i	a8, sp, 80
	l32r	a11, .LC2022
	add.n	a3, a7, a8
	add.n	a11, a3, a11
	l32i	a14, sp, 56
	l32i	a15, sp, 60
	l32i	a12, sp, 52
	l32i	a13, sp, 48
	s8i	a10, a11, 0
	l32i	a10, sp, 76
	mov.n	a11, a4
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	l32r	a11, .LC2023
	add.n	a5, a7, a5
	add.n	a11, a3, a11
	l32i	a14, sp, 56
	l32i	a15, sp, 60
	l32i	a12, sp, 52
	l32i	a13, sp, 48
	s8i	a10, a11, 0
	mov.n	a11, a4
	mov.n	a10, a5
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	l32r	a11, .LC2024
	l32r	a5, .LC2000
	add.n	a11, a3, a11
	s8i	a10, a11, 0
	mull	a10, a6, a5
	l32r	a11, .LC2025
	add.n	a10, a7, a10
	add.n	a11, a10, a11
	l8ui	a11, a11, 0
	beqz.n	a11, .L5049
	l32r	a11, .LC2026
	l32i	a9, sp, 84
	add.n	a11, a10, a11
	l16ui	a12, a11, 0
	l32r	a11, .LC2027
	add.n	a11, a3, a11
	s16i	a12, a11, 0
	l32r	a11, .LC2028
	add.n	a11, a10, a11
	l16ui	a12, a11, 0
	l32r	a11, .LC2029
	add.n	a11, a3, a11
	s16i	a12, a11, 0
	l32r	a11, .LC2030
	add.n	a10, a10, a11
	l32i	a11, a10, 4
	l32i	a10, a10, 0
	s32i	a11, a9, 116
	s32i	a10, a9, 112
.L5049:
	mull	a10, a6, a5
	l32r	a11, .LC2031
	add.n	a10, a7, a10
	add.n	a11, a10, a11
	l8ui	a11, a11, 0
	beqz.n	a11, .L5050
	l32r	a11, .LC2032
	add.n	a10, a10, a11
	l16ui	a11, a10, 0
	l32r	a10, .LC2033
	add.n	a10, a3, a10
	s16i	a11, a10, 0
.L5050:
	mull	a10, a6, a5
	l32r	a11, .LC2034
	add.n	a10, a7, a10
	add.n	a11, a10, a11
	l8ui	a11, a11, 0
	beqz.n	a11, .L5051
	l32r	a11, .LC2035
	add.n	a11, a10, a11
	l8ui	a12, a11, 0
	l32r	a11, .LC2036
	add.n	a11, a3, a11
	s8i	a12, a11, 0
	l32r	a11, .LC2037
	add.n	a10, a10, a11
	l32r	a11, .LC2038
	l32i	a10, a10, 0
	add.n	a8, a3, a11
	s32i	a10, a8, 0
.L5051:
	mull	a8, a6, a5
	l32r	a10, .LC2039
	add.n	a9, a6, a6
	l32r	a4, .LC1990
	add.n	a8, a7, a8
	add.n	a8, a8, a10
	add.n	a10, a9, a6
	l32i	a11, a8, 0
	l32i	a12, a8, 4
	slli	a10, a10, 5
	add.n	a8, a7, a4
	add.n	a8, a8, a10
	movi	a10, 0x80
	add.n	a10, a8, a10
	l32i	a9, sp, 48
	s32i	a11, a10, 0
	s32i	a12, a10, 4
	movi.n	a10, 1
	bltu	a9, a12, .L5052
	bne	a12, a9, .L5053
	l32i	a9, sp, 52
	bltu	a9, a11, .L5052
.L5053:
	movi.n	a10, 0
.L5052:
	l32i	a11, sp, 64
	s8i	a10, a8, 120
	movi.n	a12, 1
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	add.n	a9, a6, a6
	add.n	a9, a9, a6
	mull	a5, a6, a5
	slli	a9, a9, 5
	add.n	a8, a7, a4
	add.n	a8, a8, a9
	l32r	a9, .LC2012
	add.n	a5, a7, a5
	s8i	a10, a8, 136
	add.n	a5, a5, a9
	l8ui	a9, a5, 0
	addi.n	a6, a6, 1
	s8i	a9, a8, 137
	extui	a6, a6, 0, 8
.L5045:
	l32i	a8, sp, 72
	l8ui	a8, a8, 0
	bltu	a6, a8, .L5054
	retw.n
.LFE2307:
	.size	_ZN12_GLOBAL__N_114buildGroupViewERNS_3AppE, .-_ZN12_GLOBAL__N_114buildGroupViewERNS_3AppE
	.literal_position
	.literal .LC2040, .L5074
	.literal .LC2041, 774016
	.literal .LC2042, 813496
	.literal .LC2043, 2632
	.literal .LC2044, 813500
	.literal .LC2045, 2392
	.literal .LC2047, 813504
	.literal .LC2048, 826764
	.literal .LC2049, 826704
	.literal .LC2051, 813497
	.literal .LC2052, 772456
	.literal .LC2053, 764608
	.literal .LC2055, 772524
	.literal .LC2056, _ZN12_GLOBAL__N_14uartE
	.literal .LC2057, 757624
	.literal .LC2058, 815800
	.literal .LC2059, 45688
	.literal .LC2060, 45700
	.literal .LC2061, 757628
	.literal .LC2062, 813640
	.literal .LC2063, 818144
	.literal .LC2064, 489724
	.literal .LC2065, 9040
	.literal .LC2067, .LC4
	.literal .LC2069, 500000
	.literal .LC2070, 491496
	.literal .LC2071, 774024
	.literal .LC2073, _ZN12_GLOBAL__N_1L23NO_START_SPEED_RELATIONE
	.literal .LC2074, 50000
	.literal .LC2075, 489720
	.literal .LC2076, 820440
	.literal .LC2077, 818168
	.literal .LC2078, 818280
	.literal .LC2082, 820464
	.literal .LC2083, 825104
	.literal .LC2086, 826796
	.literal .LC2087, 826856
	.literal .LC2088, 757640
	.literal .LC2090, 813516
	.literal .LC2091, 815824
	.literal .LC2092, 818120
	.literal .LC2093, 815960
	.align	4
	.type	_ZN12_GLOBAL__N_112groupCommandEPvmRKN21MotorControlRSExample5Probe12GroupCommandERNS2_10GroupReplyE, @function
_ZN12_GLOBAL__N_112groupCommandEPvmRKN21MotorControlRSExample5Probe12GroupCommandERNS2_10GroupReplyE:
.LFB2308:
	entry	sp, 352
.LCFI186:
	movi.n	a8, 0
	s8i	a8, a5, 4
	mov.n	a7, a2
	l8ui	a2, a4, 0
	s32i	a3, sp, 276
	s32i	a5, sp, 256
	s32i	a8, a5, 0
	s32i	a8, a5, 8
	bgeui	a2, 8, .L5182
	l32r	a8, .LC2040
	addx4	a8, a2, a8
	l32i	a8, a8, 0
	jx	a8
	.section	.rodata
	.align	4
	.align	4
.L5074:
	.word	.L5080
	.word	.L5080
	.word	.L5079
	.word	.L5078
	.word	.L5077
	.word	.L5076
	.word	.L5075
	.word	.L5073
	.text
.L5080:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114buildGroupViewERNS_3AppE
	l32i	a8, sp, 256
	s32i	a10, a8, 8
	j	.L5248
.L5078:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE
	movi.n	a2, 1
	bnez.n	a10, .L5086
	l32r	a6, .LC2041
	l32r	a5, .LC2042
	l32r	a4, .LC2043
	add.n	a6, a7, a6
	add.n	a3, a7, a5
	j	.L5083
.L5085:
	mov.n	a12, a4
	movi.n	a11, 0
	mov.n	a10, a6
	call8	memset
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_13App11GroupMemberC1Ev
	add.n	a6, a6, a4
.L5083:
	bne	a3, a6, .L5085
	movi.n	a8, 0
	add.n	a5, a7, a5
	s16i	a8, a5, 0
	l32r	a8, .LC2044
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	addi.n	a9, a9, 1
	s32i	a9, a8, 0
	j	.L5092
.L5077:
	l8ui	a11, a4, 20
	l32i	a8, sp, 256
	mov.n	a10, a7
	s8i	a11, a8, 4
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	mov.n	a6, a10
	movi.n	a2, 3
	beqz.n	a10, .L5086
	l8ui	a5, a4, 21
	movi.n	a2, 8
	bgeui	a5, 6, .L5086
	l8ui	a8, a4, 22
	bgeui	a8, 3, .L5086
	l32r	a8, .LC2045
	l32i	a9, sp, 256
	add.n	a5, a5, a8
	movi.n	a8, 0
	s8i	a8, a9, 4
	add.n	a5, a10, a5
	l8ui	a9, a5, 0
	l8ui	a8, a4, 22
	bne	a9, a8, .L5089
.L5092:
	movi.n	a2, 0
	j	.L5086
.L5089:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE
	movi.n	a2, 1
	bnez.n	a10, .L5086
	l8ui	a8, a4, 22
	movi	a4, 0x120
	s8i	a8, a5, 0
	movi.n	a8, 0x53
	slli	a8, a8, 5
	addmi	a5, a6, 0x700
	add.n	a6, a6, a8
	j	.L5090
.L5091:
	call8	_Z18esp_timer_get_timev
	s32i	a10, a5, 0
	s32i	a11, a5, 4
	add.n	a5, a5, a4
.L5090:
	bne	a5, a6, .L5091
	j	.L5092
.L5086:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114buildGroupViewERNS_3AppE
	l32i	a8, sp, 256
	s32i	a10, a8, 8
	j	.L5081
.L5079:
	l32i	a8, a4, 16
	movi.n	a9, 0xe
	addi.n	a8, a8, -1
	bltu	a9, a8, .L5182
	mov.n	a5, a4
	mov.n	a6, a4
	j	.L5093
.L5096:
	l8ui	a10, a6, 1
	call8	_ZN14MotorControlRS6ESS_RS14isValidAddressEh
	bnez.n	a10, .L5166
	add.n	a3, a4, a3
	l8ui	a8, a3, 1
	l32i	a9, sp, 256
	s8i	a8, a9, 4
	j	.L5182
.L5095:
	l8ui	a9, a8, 1
	l8ui	a10, a6, 1
	addi.n	a8, a8, 1
	bne	a9, a10, .L5094
	l32i	a8, sp, 256
	s8i	a9, a8, 4
	j	.L5182
.L5166:
	mov.n	a8, a4
.L5094:
	bne	a8, a6, .L5095
	addi.n	a6, a6, 1
.L5093:
	l32i	a8, a4, 16
	sub	a3, a6, a4
	bltu	a3, a8, .L5096
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119groupAdmissionReadyERKNS_3AppE
	mov.n	a2, a10
	bnez.n	a10, .L5081
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE
	beqz.n	a10, .L5097
	j	.L5121
.L5097:
	l32r	a8, .LC2047
	add.n	a8, a7, a8
	s32i	a8, sp, 260
	l32i	a8, a8, 4
	beqz.n	a8, .L5098
	l32i	a8, sp, 260
	addmi	a8, a8, 0x900
	l8ui	a8, a8, 13
	bnez.n	a8, .L5098
	j	.L5124
.L5098:
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110freeRecordERNS_3AppE
	beqz.n	a10, .L5124
	l32r	a3, .LC2048
	l32r	a6, .LC2049
	l32i	a8, a4, 16
	add.n	a3, a7, a3
	add.n	a6, a7, a6
	add.n	a8, a4, a8
	mov.n	a9, a6
	mov.n	a2, a3
	j	.L5100
.L5105:
	l8ui	a11, a5, 1
	mov.n	a10, a7
	s32i	a8, sp, 268
	s32i	a9, sp, 264
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	l32r	a13, .LC2045
	l32i	a9, sp, 264
	l32i	a8, sp, 268
	add.n	a12, a10, a13
	mov.n	a14, a9
	movi.n	a11, 4
	loop	a11, .L5102_LEND
.L5102:
	movi.n	a15, 0
	beqz.n	a10, .L5101
	l8ui	a15, a12, 0
.L5101:
	s8i	a15, a14, 0
	addi.n	a12, a12, 1
	addi.n	a14, a14, 1
	.L5102_LEND:
	bnez.n	a10, .L5103
	s8i	a10, a2, 0
	j	.L5104
.L5103:
	addmi	a10, a10, 0x900
	l8ui	a11, a10, 92
	s8i	a11, a2, 0
	l8ui	a10, a10, 93
.L5104:
	s8i	a10, a2, 1
	addi.n	a9, a9, 4
	addi.n	a2, a2, 2
	addi.n	a5, a5, 1
.L5100:
	bne	a5, a8, .L5105
	l32r	a8, .LC2041
	l32r	a12, .LC2043
	add.n	a2, a7, a8
	l32r	a8, .LC2042
	mov.n	a5, a2
	add.n	a9, a7, a8
	j	.L5106
.L5108:
	movi.n	a11, 0
	mov.n	a10, a5
	s32i	a9, sp, 264
	call8	memset
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_13App11GroupMemberC1Ev
	l32r	a12, .LC2043
	l32r	a8, .LC2042
	l32i	a9, sp, 264
	add.n	a5, a5, a12
.L5106:
	bne	a9, a5, .L5108
	l32i	a9, a4, 16
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	l32r	a8, .LC2051
	movi.n	a9, 0
	add.n	a8, a7, a8
	s8i	a9, a8, 0
	l32r	a8, .LC2044
	l32r	a12, .LC2052
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	l32r	a11, .LC2053
	addi.n	a9, a9, 1
	movi.n	a5, 0x5c
	s32i	a9, a8, 0
	add.n	a12, a7, a12
	mov.n	a8, a2
	movi.n	a9, 0
	l32r	a2, .LC2045
	add.n	a11, a7, a11
	addmi	a5, a5, 0x900
	j	.L5109
.L5110:
	add.n	a9, a4, a13
	l8ui	a9, a9, 0
	l32r	a15, .LC2055
	s8i	a9, a8, 0
	s8i	a9, a8, 12
	s32i	a9, a8, 8
	l32i	a10, a12, 0
	s32i	a10, a8, 16
	movi.n	a10, 1
	s8i	a10, a8, 136
	l16ui	a10, a11, 4
	l32i	a14, a11, 0
	s16i	a10, a8, 116
	movi	a10, 0x68
	addmi	a10, a10, 0x900
	s32i	a14, a8, 112
	add.n	a14, a8, a10
	srli	a10, a9, 3
	add.n	a10, a7, a10
	add.n	a10, a10, a15
	l8ui	a10, a10, 0
	extui	a9, a9, 0, 3
	ssr	a9
	srl	a10, a10
	extui	a10, a10, 0, 1
	s8i	a10, a14, 0
	l8ui	a10, a6, 0
	l8ui	a14, a6, 1
	add.n	a9, a8, a2
	s8i	a10, a9, 0
	l8ui	a10, a6, 2
	s8i	a14, a9, 1
	l8ui	a14, a6, 3
	s8i	a10, a9, 2
	s8i	a14, a9, 3
	l8ui	a14, a3, 0
	l8ui	a10, a3, 1
	add.n	a9, a8, a5
	s8i	a14, a9, 0
	s8i	a10, a9, 1
	l32r	a9, .LC2043
	addi.n	a6, a6, 4
	add.n	a8, a8, a9
	addi.n	a3, a3, 2
	mov.n	a9, a13
.L5109:
	l32i	a10, a4, 16
	addi.n	a13, a9, 1
	bltu	a9, a10, .L5110
	l32r	a10, .LC2056
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a2, a10
	l32i	a10, sp, 260
	mov.n	a3, a11
	call8	_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE
	l32r	a8, .LC2047
	l32r	a11, .LC2059
	add.n	a6, a7, a8
	movi.n	a8, 0
	s8i	a8, a6, 0
	l32r	a8, .LC2057
	l32r	a10, .LC2058
	add.n	a8, a7, a8
	l32i	a5, a8, 0
	add.n	a11, a7, a11
	addi.n	a9, a5, 1
	s32i	a9, a8, 0
	l32i	a8, sp, 276
	s32i	a5, a6, 4
	s32i	a8, a6, 8
	movi.n	a8, 1
	s8i	a8, a6, 12
	l32r	a8, .LC2044
	movi.n	a12, 5
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	add.n	a10, a7, a10
	s32i	a8, a6, 16
	l32r	a8, .LC2052
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a2, a6, 112
	s32i	a8, a6, 20
	s32i	a3, a6, 116
	call8	memcpy
	l32r	a8, .LC2060
	addmi	a9, a6, 0x900
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	movi	a11, 0x90
	s32i	a8, a9, 0
	l32r	a8, .LC2061
	movi.n	a9, 0
	add.n	a8, a7, a8
	s32i	a5, a8, 0
	l32i	a8, a4, 16
	s8i	a8, a6, 128
	l32r	a8, .LC2062
	add.n	a8, a7, a8
	j	.L5111
.L5112:
	add.n	a10, a4, a9
	l8ui	a10, a10, 1
	addi.n	a9, a9, 1
	s8i	a10, a8, 0
	add.n	a8, a8, a11
.L5111:
	l32i	a10, a4, 16
	bltu	a9, a10, .L5112
	l32i	a8, sp, 256
	s32i	a5, a8, 0
	j	.L5248
.L5076:
	l8ui	a8, a4, 97
	movi.n	a9, 2
	s32i	a8, sp, 284
	l8ui	a8, a4, 96
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 8
	bltu	a9, a8, .L5182
	l32i	a9, sp, 284
	movi.n	a8, 1
	bltu	a8, a9, .L5182
	l8ui	a8, a4, 42
	movi.n	a2, 8
	beqz.n	a8, .L5081
	l8ui	a8, a4, 43
	bnez.n	a8, .L5081
	l8ui	a10, a4, 46
	bnez.n	a10, .L5081
	l16ui	a8, a4, 88
	beqz.n	a8, .L5081
	l8ui	a8, a4, 90
	bnei	a8, 1, .L5081
	l8ui	a9, a4, 91
	bgeui	a9, 3, .L5081
	l32i	a11, sp, 284
	bbsi	a11, 0, .L5190
	addi.n	a11, a9, -1
	movnez	a8, a10, a11
	bnez.n	a8, .L5081
.L5190:
	movi.n	a2, 0xb
	beqi	a9, 2, .L5081
	l32r	a8, .LC2051
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5116
	j	.L5154
.L5116:
	l32r	a6, .LC2042
	add.n	a6, a7, a6
	l8ui	a8, a6, 0
	beqz.n	a8, .L5154
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119groupAdmissionReadyERKNS_3AppE
	mov.n	a2, a10
	bnez.n	a10, .L5081
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_19groupBusyERKNS_3AppE
	beqz.n	a10, .L5118
.L5121:
	movi.n	a2, 1
	j	.L5081
.L5118:
	l32r	a8, .LC2063
	add.n	a8, a7, a8
	l32i	a8, a8, 4
	s32i	a8, sp, 264
	beqz.n	a8, .L5119
.L5124:
	movi.n	a2, 6
	j	.L5081
.L5119:
	l32r	a9, .LC2057
	l8ui	a5, a6, 0
	add.n	a9, a7, a9
	movi.n	a8, -1
	l32i	a9, a9, 0
	xor	a8, a5, a8
	bltu	a8, a9, .L5185
	l32r	a10, .LC2056
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32r	a8, .LC2041
	s32i	a10, sp, 268
	add.n	a8, a7, a8
	s32i	a8, sp, 272
	mov.n	a6, a8
	mov.n	a3, a11
	movi.n	a8, 0
	j	.L5247
.L5122:
	l8ui	a8, a6, 0
	l32i	a9, sp, 256
	mov.n	a11, a6
	s8i	a8, a9, 4
	mov.n	a10, a7
	s32i	a8, sp, 280
	call8	_ZN12_GLOBAL__N_113memberCurrentERKNS_3AppERKNS0_11GroupMemberE
	beqz.n	a10, .L5154
	l32i	a11, sp, 280
	movi.n	a12, 1
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L5178
	l8ui	a11, a6, 0
	l32i	a12, sp, 268
	mov.n	a13, a3
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_114enableSettlingERKNS_3AppEhy
	l32r	a8, .LC2043
	add.n	a6, a6, a8
	bnez.n	a10, .L5121
	l32i	a8, sp, 260
	addi.n	a8, a8, 1
	extui	a8, a8, 0, 8
.L5247:
	s32i	a8, sp, 260
	l32i	a8, sp, 260
	bne	a5, a8, .L5122
	l32i	a9, sp, 256
	movi.n	a8, 0
	s8i	a8, a9, 4
	l32r	a9, .LC2064
	l32r	a10, .LC2065
	add.n	a9, a7, a9
	movi.n	a8, 0
	j	.L5123
.L5125:
	add.n	a9, a9, a10
	sub	a11, a9, a10
	l32i	a11, a11, 0
	bnez.n	a11, .L5124
	addi.n	a8, a8, 1
	extui	a8, a8, 0, 8
.L5123:
	l32i	a11, sp, 260
	bne	a11, a8, .L5125
	l32i	a10, a7, 4
	movi	a8, 0x3e8
	mull	a9, a8, a10
	muluh	a8, a8, a10
	add.n	a8, a8, a3
	s32i	a8, sp, 280
	l32i	a8, sp, 268
	add.n	a8, a9, a8
	s32i	a8, sp, 288
	bgeu	a8, a9, .L5126
	l32i	a8, sp, 280
	addi.n	a8, a8, 1
	s32i	a8, sp, 280
.L5126:
	l32r	a9, .LC2067
	movi	a8, 0xec
	l32i	a9, a9, 4
	add.n	a8, sp, a8
	s32i	a9, a8, 4
	movi.n	a9, 0x40
	s8i	a9, a8, 4
	movi.n	a9, 0x20
	addmi	a9, a9, 0x4e00
	s32i	a9, a8, 0
	l32r	a9, .LC2069
	l32r	a5, .LC2071
	s32i	a9, a8, 8
	l32r	a8, .LC2070
	add.n	a5, a7, a5
	add.n	a6, a7, a8
	addi	a8, a4, 24
	s32i	a8, sp, 300
	l32r	a8, .LC2052
	add.n	a8, a7, a8
	s32i	a8, sp, 304
	j	.L5127
.L5136:
	l32i	a11, sp, 300
	movi.n	a12, 0x48
	addi	a10, sp, 104
	call8	memcpy
	l32i	a8, a5, 12
	s32i	a8, sp, 128
	l32i	a8, sp, 284
	beqi	a8, 1, .L5128
	movi.n	a8, 2
	s8i	a8, sp, 171
.L5128:
	movi.n	a8, 0x4b
	slli	a8, a8, 5
	add.n	a8, a5, a8
	l8ui	a13, a8, 0
	l32i	a8, sp, 304
	l32i	a9, a7, 0
	l32i	a12, a8, 0
	l32r	a8, .LC2060
	movi	a4, 0x5f0
	add.n	a8, a7, a8
	l32i	a11, a8, 0
	movi	a8, 0x3e8
	mull	a10, a8, a9
	muluh	a8, a8, a9
	movi	a9, 0x160
	add.n	a9, a5, a9
	s32i	a9, sp, 180
	movi	a9, 0x4a0
	add.n	a9, a5, a9
	s32i	a9, sp, 184
	l32r	a9, .LC2073
	s32i	a12, sp, 200
	s32i	a11, sp, 204
	s32i	a10, sp, 208
	s32i	a8, sp, 212
	movi.n	a12, 0x48
	movi.n	a8, 0
	movi.n	a11, 0
	add.n	a4, a5, a4
	addi	a10, sp, 32
	s8i	a13, sp, 192
	s32i	a9, sp, 196
	s32i	a8, sp, 216
	s32i	a5, sp, 176
	s32i	a4, sp, 188
	call8	memset
	movi	a8, 0x7d0
	s16i	a8, sp, 48
	l32r	a8, .LC2074
	addi	a14, sp, 32
	s32i	a8, sp, 52
	l32i	a12, sp, 268
	movi	a8, 0x64
	movi	a10, 0x90
	s16i	a8, sp, 56
	mov.n	a13, a3
	addi	a11, sp, 104
	add.n	a10, a14, a10
	call8	_ZN12_GLOBAL__N_116moveRequirementsERKNS_11MotionFactsERKN14MotorControlRS11MoveRequestEyRNS3_6ESS_RS17MovePrerequisitesE
	s32i	a10, sp, 292
	beqz.n	a10, .L5179
	l32i	a14, sp, 96
	l32i	a15, sp, 100
	l32i	a12, sp, 268
	mov.n	a13, a3
	mov.n	a11, a5
	mov.n	a10, a4
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	bnez.n	a10, .L5131
	s8i	a10, sp, 69
	j	.L5132
.L5131:
	movi	a8, 0x606
	add.n	a8, a5, a8
	l16ui	a8, a8, 0
	s16i	a8, sp, 82
	movi	a8, 0x608
	add.n	a8, a5, a8
	l16ui	a8, a8, 0
	s16i	a8, sp, 84
	movi	a8, 0x6e0
	add.n	a8, a5, a8
	l32i	a9, a8, 4
	l32i	a8, a8, 0
	s32i	a9, sp, 92
	s32i	a8, sp, 88
.L5132:
	movi	a8, 0x193
	add.n	a8, a5, a8
	l8ui	a8, a8, 0
	addi	a9, sp, 32
	s8i	a8, sp, 76
	l16ui	a8, a5, 420
	mov.n	a15, a9
	s16i	a8, sp, 80
	l16ui	a8, a5, 370
	mov.n	a11, a5
	s16i	a8, sp, 44
	l32r	a8, .LC2057
	mov.n	a10, a6
	add.n	a8, a7, a8
	l32i	a13, a8, 0
	movi	a8, 0xcc
	add.n	a8, a9, a8
	s32i	a8, sp, 16
	l32i	a8, sp, 288
	addi.n	a13, a13, 1
	s32i	a8, sp, 8
	l32i	a8, sp, 280
	s32i	a3, sp, 4
	s32i	a8, sp, 12
	l32i	a8, sp, 268
	addi	a14, sp, 104
	s32i	a8, sp, 0
	l32i	a8, sp, 264
	movi.n	a12, 0
	add.n	a13, a13, a8
	call8	_ZN14MotorControlRS6ESS_RS19prepareMoveRelativeERNS0_11MoveContextERKNS_10AxisConfigEPKNS_13AxisReferenceEmRKNS_11MoveRequestERKNS0_17MovePrerequisitesEyyRKNS_13ActionOptionsE
	l32r	a9, .LC2065
	l32i	a8, sp, 264
	add.n	a6, a6, a9
	l32r	a9, .LC2043
	s32i	a10, sp, 224
	s32i	a11, sp, 228
	s32i	a12, sp, 232
	extui	a4, a10, 0, 8
	addi.n	a8, a8, 1
	add.n	a5, a5, a9
	beqz.n	a4, .L5133
	j	.L5130
.L5179:
	movi.n	a4, 1
.L5130:
	l32r	a5, .LC2075
	l32r	a3, .LC2065
	add.n	a5, a7, a5
.L5134:
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_111clearRecordERNS_3App6RecordE
	addi.n	a2, a2, 1
	l32i	a8, sp, 296
	extui	a2, a2, 0, 8
	add.n	a5, a5, a3
	bgeu	a8, a2, .L5134
	l32i	a9, sp, 264
	l32r	a8, .LC2043
	movi.n	a2, 3
	mull	a8, a9, a8
	l32r	a9, .LC2041
	add.n	a8, a7, a8
	add.n	a8, a8, a9
	l8ui	a8, a8, 0
	l32i	a9, sp, 256
	s8i	a8, a9, 4
	l32i	a8, sp, 292
	beqz.n	a8, .L5081
	movi.n	a2, 8
	bnei	a4, 3, .L5081
	movi.n	a2, 0xb
	j	.L5081
.L5133:
	s32i	a8, sp, 264
.L5127:
	movi	a8, 0x108
	add.n	a8, a8, sp
	l8ui	a8, a8, 0
	l32i	a9, sp, 260
	s32i	a8, sp, 296
	bltu	a8, a9, .L5136
	l32r	a5, .LC2063
	add.n	a5, a7, a5
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE
	l32r	a8, .LC2057
	movi.n	a9, 1
	add.n	a8, a7, a8
	l32i	a4, a8, 0
	s8i	a9, a5, 0
	addi.n	a10, a4, 1
	s32i	a10, a8, 0
	l32i	a8, sp, 276
	s32i	a4, a5, 4
	s32i	a8, a5, 8
	l32r	a8, .LC2044
	l32r	a6, .LC2059
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	l32r	a10, .LC2076
	s32i	a8, a5, 16
	l32r	a8, .LC2052
	s8i	a9, a5, 12
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	movi.n	a12, 5
	s32i	a8, a5, 20
	l32i	a8, sp, 268
	s32i	a3, a5, 116
	s32i	a8, a5, 112
	add.n	a8, a7, a6
	mov.n	a11, a8
	add.n	a10, a7, a10
	s32i	a8, sp, 264
	call8	memcpy
	l32r	a8, .LC2060
	addmi	a9, a5, 0x900
	add.n	a6, a7, a8
	l32i	a10, a6, 0
	l32i	a11, sp, 300
	s32i	a10, a9, 0
	l32r	a9, .LC2061
	l32r	a10, .LC2077
	add.n	a9, a7, a9
	s32i	a4, a9, 0
	movi.n	a12, 0x4a
	add.n	a10, a7, a10
	call8	memcpy
	l32i	a8, sp, 260
	l32r	a4, .LC2078
	s8i	a8, a5, 128
	l32r	a5, .LC2075
	add.n	a4, a7, a4
	add.n	a5, a7, a5
	movi.n	a3, 0
	j	.L5137
.L5138:
	l32i	a11, sp, 264
	movi.n	a12, 5
	addi.n	a10, a5, 12
	call8	memcpy
	l32i	a9, a6, 0
	l32r	a10, .LC2057
	s32i	a9, a5, 20
	add.n	a10, a7, a10
	l32i	a9, a10, 0
	l32i	a8, sp, 272
	addi.n	a11, a9, 1
	s32i	a11, a10, 0
	s32i	a9, a5, 4
	l8ui	a12, a8, 0
	l32i	a8, sp, 288
	movi.n	a10, 4
	s32i	a8, a5, 56
	l32i	a8, sp, 280
	s8i	a10, a5, 0
	movi	a10, 0x308
	s8i	a12, a5, 24
	s32i	a8, a5, 60
	movi.n	a11, 1
	add.n	a10, a5, a10
	s8i	a11, a10, 0
	movi.n	a10, 0x3a
	addmi	a10, a10, 0x2300
	add.n	a10, a5, a10
	s8i	a11, a10, 0
	movi.n	a10, 0x39
	addmi	a10, a10, 0x2300
	l32i	a8, sp, 272
	add.n	a10, a5, a10
	s8i	a11, a10, 0
	movi	a10, 0xb0
	l32i	a11, a8, 20
	addmi	a10, a10, 0x1000
	add.n	a10, a5, a10
	s32i	a11, a10, 0
	s32i	a9, a4, 4
	l32r	a9, .LC2065
	addi.n	a3, a3, 1
	add.n	a5, a5, a9
	l32r	a9, .LC2043
	s8i	a12, a4, 0
	add.n	a8, a8, a9
	movi	a9, 0x90
	extui	a3, a3, 0, 8
	s32i	a8, sp, 272
	add.n	a4, a4, a9
.L5137:
	l32i	a8, sp, 260
	bne	a8, a3, .L5138
	l32r	a8, .LC2063
	l32i	a9, sp, 256
	add.n	a8, a7, a8
	l32i	a8, a8, 4
	s32i	a8, a9, 0
	j	.L5081
.L5178:
	movi.n	a2, 0xc
	j	.L5081
.L5075:
	l8ui	a3, a4, 104
	addi.n	a8, a3, -1
	extui	a8, a8, 0, 8
	bgeui	a8, 2, .L5182
	l32r	a8, .LC2051
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L5154
	l32r	a8, .LC2042
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L5154
	l32r	a9, .LC2057
	add.n	a8, a7, a9
	l32i	a4, a8, 0
	beqz.n	a4, .L5185
	l32r	a6, .LC2082
	l32r	a10, .LC2083
	movi.n	a12, 0xd
	movi.n	a13, 0x10
	add.n	a6, a7, a6
	add.n	a10, a7, a10
	movi.n	a8, 0
	addmi	a12, a12, 0x900
	addmi	a13, a13, 0x900
	j	.L5140
.L5143:
	l32i	a11, a6, 4
	beqz.n	a11, .L5141
	l8ui	a14, a6, 12
	bnez.n	a14, .L5142
	add.n	a14, a6, a12
	l8ui	a14, a14, 0
	beqz.n	a14, .L5142
	l8ui	a14, a6, 13
	bnez.n	a14, .L5141
	beqz.n	a8, .L5187
	l32i	a14, a8, 4
	bltu	a11, a14, .L5187
	j	.L5142
.L5187:
	mov.n	a8, a6
.L5142:
	add.n	a6, a6, a13
.L5140:
	bne	a10, a6, .L5143
	beqz.n	a8, .L5081
	mov.n	a6, a8
.L5141:
	add.n	a9, a7, a9
	addi.n	a8, a4, 1
	s32i	a8, a9, 0
	movi.n	a12, 0x18
	movi.n	a11, 0
	addi	a10, sp, 32
	call8	memset
	movi.n	a8, 3
	s8i	a8, sp, 32
	l32r	a8, .LC2042
	s8i	a3, sp, 33
	add.n	a8, a7, a8
	s32i	a8, sp, 260
	l32r	a8, .LC2086
	movi.n	a5, 0
	add.n	a8, a7, a8
	movi.n	a9, 0
	movi.n	a2, 0
	s32i	a8, sp, 264
	j	.L5145
.L5148:
	l32i	a8, sp, 264
	movi.n	a10, 0
	addx4	a8, a5, a8
	s32i	a10, a8, 0
	l32r	a8, .LC2086
	l32r	a11, .LC2041
	addx4	a14, a5, a8
	l32r	a8, .LC2043
	movi.n	a15, 1
	mull	a8, a5, a8
	add.n	a14, a7, a14
	add.n	a8, a7, a8
	add.n	a8, a8, a11
	l8ui	a12, a8, 0
	movi.n	a11, 0
	s32i	a10, sp, 4
	s32i	a10, sp, 0
	addi	a13, sp, 32
	mov.n	a10, a7
	s32i	a9, sp, 272
	s32i	a8, sp, 268
	call8	_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	l32r	a11, .LC2087
	l32i	a8, sp, 268
	add.n	a11, a7, a11
	add.n	a11, a11, a5
	s8i	a10, a11, 0
	l32i	a9, sp, 272
	bnez.n	a10, .L5146
	addi.n	a9, a9, 1
	j	.L5147
.L5146:
	bnez.n	a2, .L5147
	l8ui	a8, a8, 0
	l32i	a11, sp, 256
	mov.n	a2, a10
	s8i	a8, a11, 4
.L5147:
	addi.n	a5, a5, 1
	extui	a5, a5, 0, 8
.L5145:
	l32i	a8, sp, 260
	l8ui	a8, a8, 0
	bltu	a5, a8, .L5148
	beqz.n	a9, .L5081
	l32i	a8, a6, 4
	beqz.n	a8, .L5149
	l8ui	a8, a6, 13
	bnez.n	a8, .L5149
	l32r	a8, .LC2088
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L5150
	addi.n	a10, a10, 1
.L5150:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
.L5149:
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE
	movi.n	a8, 2
	s8i	a8, a6, 0
	l32i	a8, sp, 276
	s32i	a4, a6, 4
	s32i	a8, a6, 8
	movi.n	a8, 1
	s8i	a8, a6, 12
	l32r	a8, .LC2044
	s8i	a3, a6, 104
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a6, 16
	l32r	a8, .LC2052
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a8, a6, 20
	call8	_Z18esp_timer_get_timev
	l32r	a8, .LC2042
	s32i	a10, a6, 112
	s32i	a11, a6, 116
	add.n	a8, a7, a8
	l8ui	a5, a8, 0
	l32r	a11, .LC2059
	movi.n	a10, -8
	addmi	a10, a10, 0x900
	add.n	a11, a7, a11
	s8i	a5, a6, 128
	movi.n	a12, 5
	add.n	a10, a6, a10
	call8	memcpy
	l32r	a8, .LC2060
	l32r	a10, .LC2086
	add.n	a8, a7, a8
	l32i	a9, a8, 0
	addmi	a8, a6, 0x900
	s32i	a9, a8, 0
	l32r	a9, .LC2041
	movi	a8, 0x88
	l32r	a13, .LC2087
	l32r	a15, .LC2043
	add.n	a8, a6, a8
	add.n	a9, a7, a9
	add.n	a10, a7, a10
	movi.n	a11, 0
	movi	a14, 0x90
	j	.L5151
.L5153:
	l8ui	a12, a9, 0
	s8i	a12, a8, 0
	add.n	a12, a11, a13
	add.n	a12, a7, a12
	l8ui	a6, a12, 0
	movi.n	a12, 0
	s8i	a6, a8, 8
	bnez.n	a6, .L5152
	l32i	a12, a10, 0
.L5152:
	s32i	a12, a8, 4
	addi.n	a11, a11, 1
	add.n	a8, a8, a14
	add.n	a9, a9, a15
	addi.n	a10, a10, 4
.L5151:
	extui	a12, a11, 0, 8
	bltu	a12, a5, .L5153
	l32r	a8, .LC2061
	add.n	a8, a7, a8
	s32i	a4, a8, 0
	l32i	a8, sp, 256
	s32i	a4, a8, 0
.L5248:
	movi.n	a2, 0
	j	.L5081
.L5182:
	movi.n	a2, 8
	j	.L5081
.L5185:
	movi.n	a2, 7
	j	.L5081
.L5073:
	l32r	a8, .LC2051
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L5154
	l32r	a5, .LC2042
	add.n	a8, a7, a5
	l8ui	a8, a8, 0
	beqz.n	a8, .L5154
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_119groupAdmissionReadyERKNS_3AppE
	mov.n	a2, a10
	bnez.n	a10, .L5081
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L5121
	l32r	a8, .LC2090
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5121
	l32r	a6, .LC2091
	add.n	a8, a7, a6
	l32i	a9, a8, 4
	beqz.n	a9, .L5156
	addmi	a8, a8, 0x900
	l8ui	a8, a8, 13
	beqz.n	a8, .L5124
.L5156:
	add.n	a8, a7, a5
	l8ui	a12, a8, 0
	l32r	a8, .LC2041
	movi.n	a3, 0
	add.n	a4, a7, a8
	mov.n	a11, a4
	j	.L5157
.L5158:
	mov.n	a10, a7
	s32i	a12, sp, 264
	s32i	a11, sp, 260
	call8	_ZN12_GLOBAL__N_113memberCurrentERKNS_3AppERKNS0_11GroupMemberE
	l32i	a11, sp, 260
	l32r	a9, .LC2043
	l32i	a12, sp, 264
	l32r	a8, .LC2041
	addi.n	a13, a3, 1
	add.n	a11, a11, a9
	bnez.n	a10, .L5189
	mull	a3, a3, a9
	l32i	a9, sp, 256
	add.n	a3, a7, a3
	add.n	a3, a3, a8
	l8ui	a8, a3, 0
	s8i	a8, a9, 4
	j	.L5154
.L5189:
	mov.n	a3, a13
.L5157:
	extui	a10, a3, 0, 8
	bltu	a10, a12, .L5158
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110freeRecordERNS_3AppE
	beqz.n	a10, .L5124
	l32r	a10, .LC2056
	add.n	a6, a7, a6
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	s32i	a10, sp, 264
	mov.n	a10, a6
	s32i	a11, sp, 260
	call8	_ZN12_GLOBAL__N_119clearGroupOperationERNS_3App14GroupOperationE
	movi.n	a8, 3
	s8i	a8, a6, 0
	l32r	a8, .LC2057
	l32i	a11, sp, 260
	add.n	a8, a7, a8
	l32i	a3, a8, 0
	l32i	a9, sp, 264
	addi.n	a10, a3, 1
	s32i	a10, a8, 0
	l32i	a8, sp, 276
	s32i	a3, a6, 4
	s32i	a8, a6, 8
	movi.n	a8, 1
	s8i	a8, a6, 12
	l32r	a8, .LC2044
	l32r	a10, .LC2092
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	add.n	a10, a7, a10
	s32i	a8, a6, 16
	l32r	a8, .LC2052
	movi.n	a12, 5
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	s32i	a11, a6, 116
	l32r	a11, .LC2059
	s32i	a8, a6, 20
	s32i	a9, a6, 112
	add.n	a11, a7, a11
	call8	memcpy
	l32r	a8, .LC2060
	addmi	a9, a6, 0x900
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	add.n	a5, a7, a5
	s32i	a8, a9, 0
	l32r	a8, .LC2061
	l32r	a9, .LC2093
	add.n	a8, a7, a8
	s32i	a3, a8, 0
	l8ui	a8, a5, 0
	add.n	a7, a7, a9
	s8i	a8, a6, 128
	l32r	a9, .LC2043
	movi	a10, 0x90
	j	.L5159
.L5160:
	l8ui	a11, a4, 0
	addi.n	a2, a2, 1
	s8i	a11, a7, 0
	extui	a2, a2, 0, 8
	add.n	a4, a4, a9
	add.n	a7, a7, a10
.L5159:
	bne	a8, a2, .L5160
	l32i	a8, sp, 256
	s32i	a3, a8, 0
	j	.L5248
.L5154:
	movi.n	a2, 3
.L5081:
	retw.n
.LFE2308:
	.size	_ZN12_GLOBAL__N_112groupCommandEPvmRKN21MotorControlRSExample5Probe12GroupCommandERNS2_10GroupReplyE, .-_ZN12_GLOBAL__N_112groupCommandEPvmRKN21MotorControlRSExample5Probe12GroupCommandERNS2_10GroupReplyE
	.section	.rodata.str1.1
.LC2094:
	.string	"application is not started"
	.text
	.literal_position
	.literal .LC2095, .LC2094
	.literal .LC2096, .LC12
	.literal .LC2097, _ZN12_GLOBAL__N_13appE
	.align	4
	.type	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc, @function
_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc:
.LFB2416:
	entry	sp, 64
.LCFI187:
	l32r	a5, .LC2097
	nsau	a8, a2
	l32i	a10, a5, 0
	mov.n	a12, a2
	mov.n	a7, a3
	movi.n	a6, 1
	srli	a8, a8, 5
	beqz.n	a2, .L5257
	moveqz	a8, a6, a10
	beqz.n	a8, .L5250
.L5257:
	movi.n	a8, 1
	l32r	a4, .LC2095
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5252
.L5250:
	addi.n	a13, sp, 12
	movi.n	a11, 0
	call8	_ZN12_GLOBAL__N_112groupCommandEPvmRKN21MotorControlRSExample5Probe12GroupCommandERNS2_10GroupReplyE
	mov.n	a3, a10
	beqz.n	a10, .L5253
	movi.n	a9, 0xb
	movi.n	a8, 1
	bne	a10, a9, .L5254
	movi.n	a8, 3
.L5254:
	s8i	a8, sp, 0
	j	.L5252
.L5253:
	l32i	a4, sp, 12
	beqz.n	a7, .L5255
	beqz.n	a4, .L5255
	l32i	a10, a5, 0
	mov.n	a11, a4
	call8	_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm
	addmi	a10, a10, 0x900
	s8i	a6, a10, 14
	s32i	a4, a7, 0
.L5255:
	movi.n	a8, 0
	l32r	a4, .LC2096
	s8i	a8, sp, 0
	movi.n	a3, 0
.L5252:
	l32i	a2, sp, 0
	movi.n	a5, 0
	retw.n
.LFE2416:
	.size	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc, .-_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc
	.section	.rodata.str1.1
.LC2210:
	.string	"stop"
	.section	.rodata
	.align	8
.LC0:
	.word	1
	.word	0
	.word	0
	.word	0
	.word	-1
	.zero	4
	.align	4
.LC1:
	.word	9600
	.word	19200
	.word	38400
	.word	115200
	.text
	.literal_position
	.literal .LC2099, 4304
	.literal .LC2104, .LC12
	.literal .LC2105, 45648
	.literal .LC2106, .LC0
	.literal .LC2107, 45672
	.literal .LC2108, 115200
	.literal .LC2109, 45680
	.literal .LC2110, 45688
	.literal .LC2111, 45696
	.literal .LC2112, 45708
	.literal .LC2113, 200000
	.literal .LC2114, 500000
	.literal .LC2116, 46384
	.literal .LC2119, 47832
	.literal .LC2120, 47836
	.literal .LC2121, 47848
	.literal .LC2122, 47864
	.literal .LC2124, 47876
	.literal .LC2125, 47880
	.literal .LC2126, 47888
	.literal .LC2127, 50792
	.literal .LC2129, 58232
	.literal .LC2130, 58236
	.literal .LC2131, 58296
	.literal .LC2132, 58992
	.literal .LC2134, 59016
	.literal .LC2136, 61496
	.literal .LC2137, 62744
	.literal .LC2139, 62804
	.literal .LC2140, 64892
	.literal .LC2142, 64848
	.literal .LC2144, 64880
	.literal .LC2145, 64888
	.literal .LC2147, 64900
	.literal .LC2148, 64904
	.literal .LC2149, 64908
	.literal .LC2150, 64912
	.literal .LC2151, 64920
	.literal .LC2152, _ZN12_GLOBAL__N_14uartE
	.literal .LC2153, .LC3
	.literal .LC2156, _ZN12_GLOBAL__N_125recycleInteractiveResultsEPv
	.literal .LC2157, _ZN12_GLOBAL__N_14emitEPvPKcj
	.literal .LC2158, _ZN12_GLOBAL__N_18snapshotEPvRN21MotorControlRSExample5Probe8SnapshotE
	.literal .LC2159, _ZN12_GLOBAL__N_15probeEPvmhRm
	.literal .LC2160, _ZN12_GLOBAL__N_111captureReadEPvmhRm
	.literal .LC2161, _ZN12_GLOBAL__N_19typedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERm
	.literal .LC2162, _ZN12_GLOBAL__N_111startActionEPvmhRKN14MotorControlRS13ActionRequestERm
	.literal .LC2163, _ZN12_GLOBAL__N_121startReleaseAfterStopEPvmmRm
	.literal .LC2164, _ZN12_GLOBAL__N_19startMoveEPvmhRKN14MotorControlRS11MoveRequestERm
	.literal .LC2165, _ZN12_GLOBAL__N_122startPositionInterruptEPvmmRm
	.literal .LC2166, _ZN12_GLOBAL__N_112simpleMotionEPvmPKN21MotorControlRSExample5Probe19SimpleMotionCommandERNS2_16SimpleMotionViewE
	.literal .LC2167, _ZN12_GLOBAL__N_113startVelocityEPvmhRKN14MotorControlRS15VelocityRequestERm
	.literal .LC2168, _ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm
	.literal .LC2169, _ZN12_GLOBAL__N_19startHomeEPvmhRKN14MotorControlRS6ESS_RS11HomeRequestERm
	.literal .LC2170, _ZZN12_GLOBAL__N_14hostEPNS_3AppEENUlPvRN14MotorControlRS6ESS_RS17HomePrerequisitesERbE_4_FUNES2_S6_S7_
	.literal .LC2171, _ZN12_GLOBAL__N_120qualificationCommandEPvRKN21MotorControlRSExample5Probe20QualificationCommandE
	.literal .LC2172, _ZN12_GLOBAL__N_17recoverEPvmRm
	.literal .LC2173, _ZN12_GLOBAL__N_15resetEPv
	.literal .LC2174, _ZN12_GLOBAL__N_17monitorEPvPKN21MotorControlRSExample5Probe15MonitorSettingsERNS2_15MonitorSnapshotE
	.literal .LC2175, _ZN12_GLOBAL__N_110hostSerialEPvPKN21MotorControlRSExample5Probe11HostRequestERNS2_12HostSnapshotE
	.literal .LC2176, _ZN12_GLOBAL__N_112selectTargetEPvh
	.literal .LC2177, _ZN12_GLOBAL__N_16wiringEPvPKN21MotorControlRSExample5Probe13WiringRequestERNS2_14WiringSnapshotE
	.literal .LC2178, _ZN12_GLOBAL__N_113communicationEPvPKN21MotorControlRSExample5Probe20CommunicationCommandERNS2_17CommunicationViewE
	.literal .LC2179, _ZN12_GLOBAL__N_111persistenceEPvPKN21MotorControlRSExample5Probe18PersistenceCommandERNS2_15PersistenceViewE
	.literal .LC2180, _ZN12_GLOBAL__N_116discoveryCommandEPvPKN21MotorControlRSExample5Probe16DiscoveryCommandERNS2_13DiscoveryViewE
	.literal .LC2181, _ZN12_GLOBAL__N_112debugCommandEPvPKN21MotorControlRSExample5Probe9DebugModeERNS2_13DebugSnapshotE
	.literal .LC2182, _ZN12_GLOBAL__N_120motionProfileCommandEPvN21MotorControlRSExample5Probe20MotionProfileCommandERNS2_17MotionProfileViewE
	.literal .LC2183, _ZN12_GLOBAL__N_112groupCommandEPvmRKN21MotorControlRSExample5Probe12GroupCommandERNS2_10GroupReplyE
	.literal .LC2184, _ZN12_GLOBAL__N_16lookupEPvmRN21MotorControlRSExample5Probe10ResultViewE
	.literal .LC2185, _ZN12_GLOBAL__N_16cancelEPvm
	.literal .LC2186, _ZN12_GLOBAL__N_17releaseEPvm
	.literal .LC2187, _ZN12_GLOBAL__N_111axisCommandEPvRKN21MotorControlRSExample5Probe11AxisCommandERNS2_8AxisViewE
	.literal .LC2189, 65548
	.literal .LC2190, 65560
	.literal .LC2191, 16384
	.literal .LC2195, 99672
	.literal .LC2196, 99692
	.literal .LC2197, 99696
	.literal .LC2198, 99700
	.literal .LC2201, 35064
	.literal .LC2202, 100584
	.literal .LC2203, 35188
	.literal .LC2204, 35192
	.literal .LC2205, 35196
	.literal .LC2206, 35376
	.literal .LC2207, 35380
	.literal .LC2208, 100792
	.literal .LC2211, .LC2210
	.literal .LC2212, 35576
	.literal .LC2214, 101000
	.literal .LC2215, 524320
	.literal .LC2216, 101012
	.literal .LC2217, 102368
	.literal .LC2218, 103716
	.literal .LC2219, 104764
	.literal .LC2220, 106094
	.literal .LC2221, 107356
	.literal .LC2222, 108412
	.literal .LC2223, 109636
	.literal .LC2224, 101969
	.literal .LC2225, 102064
	.literal .LC2226, 10000
	.literal .LC2228, 102874
	.literal .LC2229, 102897
	.literal .LC2230, 50000
	.literal .LC2231, 103082
	.literal .LC2232, 103105
	.literal .LC2233, 103426
	.literal .LC2234, 103428
	.literal .LC2235, 103540
	.literal .LC2236, 103628
	.literal .LC2237, 104113
	.literal .LC2238, 104234
	.literal .LC2241, 105326
	.literal .LC2242, 105330
	.literal .LC2243, 105378
	.literal .LC2244, 105820
	.literal .LC2245, 105916
	.literal .LC2246, 106168
	.literal .LC2247, 106344
	.literal .LC2248, 106419
	.literal .LC2249, 106420
	.literal .LC2250, 106548
	.literal .LC2251, 106650
	.literal .LC2252, 106672
	.literal .LC2253, 106758
	.literal .LC2254, 106762
	.literal .LC2255, 106810
	.literal .LC2256, 106832
	.literal .LC2257, 106948
	.literal .LC2258, 106968
	.literal .LC2259, 109058
	.literal .LC2260, 109102
	.literal .LC2261, 109460
	.literal .LC2262, 109548
	.literal .LC2264, 625320
	.literal .LC2265, 626184
	.literal .LC2266, 626240
	.literal .LC2267, 626248
	.literal .LC2268, 626280
	.literal .LC2269, 626344
	.literal .LC2270, 626352
	.literal .LC2271, 626384
	.literal .LC2272, 642836
	.literal .LC2275, 757616
	.literal .LC2276, 757620
	.literal .LC2277, 757624
	.literal .LC2278, 757628
	.literal .LC2279, 757632
	.literal .LC2280, 757636
	.literal .LC2281, 757640
	.literal .LC2282, 757648
	.literal .LC2283, 757680
	.literal .LC2284, 757684
	.literal .LC2285, 757704
	.literal .LC2286, 757712
	.literal .LC2287, 757720
	.literal .LC2288, 757728
	.literal .LC2289, 757736
	.literal .LC2290, 757744
	.literal .LC2291, 757752
	.literal .LC2293, 757768
	.literal .LC2294, 757772
	.literal .LC2295, 757776
	.literal .LC2296, 757792
	.literal .LC2297, 757960
	.literal .LC2298, 758792
	.literal .LC2299, 759264
	.literal .LC2300, 759736
	.literal .LC2301, 760208
	.literal .LC2302, 760264
	.literal .LC2304, 762096
	.literal .LC2305, 762576
	.literal .LC2306, 763048
	.literal .LC2307, 764496
	.literal .LC2308, 764504
	.literal .LC2311, 764632
	.literal .LC2312, 764648
	.literal .LC2313, 764664
	.literal .LC2314, 764688
	.literal .LC2315, 764696
	.literal .LC2316, 764712
	.literal .LC2317, 764728
	.literal .LC2318, 764760
	.literal .LC2319, 764768
	.literal .LC2320, 764772
	.literal .LC2321, 764776
	.literal .LC2322, 764784
	.literal .LC2323, 764788
	.literal .LC2324, 764792
	.literal .LC2325, 4992
	.literal .LC2326, 764840
	.literal .LC2330, 770768
	.literal .LC2331, 770856
	.literal .LC2332, 771192
	.literal .LC2333, 6553660
	.literal .LC2334, 771196
	.literal .LC2335, 16842852
	.literal .LC2336, 771208
	.literal .LC2338, 771248
	.literal .LC2339, 771252
	.literal .LC2341, 771264
	.literal .LC2342, 771272
	.literal .LC2343, 771276
	.literal .LC2344, 771280
	.literal .LC2345, 771296
	.literal .LC2346, 771300
	.literal .LC2348, 771328
	.literal .LC2349, 771332
	.literal .LC2350, .LC435
	.literal .LC2351, 771352
	.literal .LC2352, 771356
	.literal .LC2353, 771368
	.literal .LC2354, 771808
	.literal .LC2355, 771816
	.literal .LC2356, 771828
	.literal .LC2357, 771832
	.literal .LC2358, 771836
	.literal .LC2359, 771840
	.literal .LC2360, 771856
	.literal .LC2361, 771872
	.literal .LC2362, 771876
	.literal .LC2363, 771880
	.literal .LC2364, 771884
	.literal .LC2365, 771888
	.literal .LC2366, 771912
	.literal .LC2367, 771920
	.literal .LC2368, 771936
	.literal .LC2369, 771952
	.literal .LC2370, 772072
	.literal .LC2371, 772088
	.literal .LC2374, 772100
	.literal .LC2375, 3000
	.literal .LC2376, 772128
	.literal .LC2377, 772148
	.literal .LC2378, 772152
	.literal .LC2379, 772156
	.literal .LC2380, 772280
	.literal .LC2381, 772456
	.literal .LC2382, 772460
	.literal .LC2383, 772492
	.literal .LC2384, 772524
	.literal .LC2385, 772556
	.literal .LC2386, 772568
	.literal .LC2387, 772576
	.literal .LC2388, 772584
	.literal .LC2389, 772592
	.literal .LC2390, 772784
	.literal .LC2391, 774016
	.literal .LC2392, 39480
	.literal .LC2393, 774036
	.literal .LC2394, 775076
	.literal .LC2395, 775613
	.literal .LC2396, 775901
	.literal .LC2397, 776189
	.literal .LC2402, 813496
	.literal .LC2403, 39484
	.literal .LC2405, 41808
	.literal .LC2407, 46448
	.literal .LC2409, 46480
	.literal .LC2410, 46490
	.literal .LC2411, 46492
	.literal .LC2412, 46513
	.literal .LC2413, 46608
	.literal .LC2414, 46696
	.literal .LC2416, 46840
	.literal .LC2417, 46896
	.literal .LC2418, 46984
	.literal .LC2420, 47128
	.literal .LC2421, 47184
	.literal .LC2422, 47272
	.literal .LC2424, 47416
	.literal .LC2425, 47472
	.literal .LC2426, 47560
	.literal .LC2428, 47704
	.literal .LC2429, 47760
	.literal .LC2431, 47992
	.literal .LC2432, 48048
	.literal .LC2433, 48136
	.literal .LC2435, 48280
	.literal .LC2436, 48336
	.literal .LC2437, 48424
	.literal .LC2439, 48568
	.literal .LC2440, 48624
	.literal .LC2441, 48712
	.literal .LC2442, 48744
	.literal .LC2443, 51088
	.literal .LC2445, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC2446, 45704
	.literal .LC2447, .LC1
	.literal .LC2448, 45788
	.literal .LC2449, 45772
	.literal .LC2450, 764508
	.literal .LC2451, 764512
	.literal .LC2452, 764520
	.literal .LC2453, 771384
	.literal .LC2454, 771376
	.literal .LC2455, 60232
	.literal .LC2456, 762568
	.literal .LC2457, 762569
	.literal .LC2458, 762570
	.literal .LC2459, 762571
	.literal .LC2460, 762572
	.literal .LC2461, 762573
	.literal .LC2462, -2147483648
	.literal .LC2463, 2147483647
	.literal .LC2464, -1598689907
	.literal .LC2465, 1051772663
	.align	4
	.type	_ZN12_GLOBAL__N_13AppC2ERKN21MotorControlRSExample18ApplicationOptionsE, @function
_ZN12_GLOBAL__N_13AppC2ERKN21MotorControlRSExample18ApplicationOptionsE:
.LFB2047:
	entry	sp, 272
.LCFI188:
	mov.n	a11, a3
	movi	a12, 0x68
	mov.n	a10, a2
	call8	memcpy
	addi	a8, a2, 104
	mov.n	a10, a8
	movi.n	a12, 0x20
	movi.n	a11, 0
	s32i	a8, sp, 228
	call8	memset
	movi	a10, 0x88
	movi.n	a12, 0x40
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	movi	a8, 0xc8
	movi.n	a9, 0
	add.n	a8, a2, a8
	movi.n	a12, 1
	movi	a10, 0xd0
	s32i	a9, a8, 0
	s32i	a9, a8, 4
	slli	a12, a12, 12
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a8, .LC2099
	movi	a12, 0xa0
	add.n	a10, a2, a8
	addmi	a12, a12, 0x3600
	movi.n	a11, 0
	call8	memset
	addmi	a10, a2, 0x4700
	movi.n	a12, -0x20
	addmi	a12, a12, 0x6b00
	movi.n	a11, 0
	addi	a10, a10, 112
	call8	memset
	movi	a8, 0xd9
	addmi	a8, a8, 0x4700
	l32r	a3, .LC2104
	add.n	a8, a2, a8
	movi.n	a12, 1
	movi	a10, 0x1e0
	movi.n	a9, 0x39
	loop	a9, .L5271_LEND
.L5271:
	s8i	a12, a8, 0
	addi	a11, a8, 95
	s32i	a3, a11, 0
	add.n	a8, a8, a10
	.L5271_LEND:
	l32r	a8, .LC2105
	l32r	a11, .LC2106
	movi.n	a12, 0x18
	add.n	a10, a2, a8
	call8	memcpy
	l32r	a13, .LC2107
	l32r	a9, .LC2108
	l32r	a10, .LC2109
	add.n	a6, a2, a13
	movi.n	a8, 0
	s32i	a9, a6, 0
	s8i	a8, a6, 4
	add.n	a10, a2, a10
	s32i	a9, a10, 0
	s8i	a8, a10, 4
	l32r	a10, .LC2110
	movi.n	a11, 1
	add.n	a10, a2, a10
	s32i	a9, a10, 0
	s8i	a8, a10, 4
	l32r	a10, .LC2111
	movi.n	a7, 0
	add.n	a10, a2, a10
	s16i	a11, a10, 0
	s8i	a8, a6, 26
	movi.n	a8, 1
	s32i	a8, a6, 28
	l32r	a8, .LC2112
	s32i	a7, a6, 32
	add.n	a8, a2, a8
	movi.n	a10, 0x14
	s32i	a10, a8, 40
	l32r	a10, .LC2113
	s32i	a7, a8, 0
	s32i	a10, a8, 48
	l32r	a10, .LC2114
	s32i	a7, a8, 4
	s32i	a10, a8, 52
	s32i	a7, a8, 8
	s32i	a7, a8, 12
	s32i	a7, a8, 16
	s32i	a7, a8, 20
	s32i	a7, a8, 24
	s32i	a7, a8, 28
	s32i	a7, a8, 32
	s32i	a7, a8, 36
	s32i	a7, a8, 44
	movi.n	a12, 0x10
	movi.n	a11, 0
	s32i	a10, a8, 56
	s8i	a7, a6, 96
	addi	a10, a6, 100
	call8	memset
	movi	a10, 0x597
	slli	a10, a10, 5
	s32i	a7, a6, 116
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS20CommunicationContextC1Ev
	l32r	a10, .LC2116
	movi.n	a6, 0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS20CommunicationContextC1Ev
	movi	a8, 0x16f
	slli	a8, a8, 7
	add.n	a5, a2, a8
	mov.n	a10, a5
	call8	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev
	movi	a10, 0x340
	add.n	a10, a5, a10
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	l32r	a8, .LC2119
	movi.n	a4, 0
	s32i	a6, a5, 848
	s32i	a4, a5, 852
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	l32r	a8, .LC2120
	l32r	a10, .LC2126
	add.n	a8, a2, a8
	s8i	a7, a8, 0
	s16i	a7, a8, 2
	s16i	a7, a8, 4
	s16i	a7, a8, 6
	l32r	a8, .LC2121
	movi.n	a13, 0
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	s32i	a7, a8, 4
	s32i	a6, a8, 8
	s32i	a4, a8, 12
	l32r	a8, .LC2122
	add.n	a10, a2, a10
	add.n	a8, a2, a8
	s32i	a6, a8, 0
	s32i	a4, a8, 4
	movi	a8, 0xbb
	slli	a8, a8, 8
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	l32r	a8, .LC2124
	s32i	a13, sp, 224
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	l32r	a8, .LC2125
	add.n	a8, a2, a8
	s16i	a7, a8, 0
	call8	_ZN14MotorControlRS6ESS_RS18PersistenceContextC1Ev
	l32r	a10, .LC2127
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS18PersistenceContextC1Ev
	movi	a10, 0x347
	slli	a10, a10, 6
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe13DiscoveryScanC1Ev
	l32r	a8, .LC2129
	l32i	a13, sp, 224
	l32r	a10, .LC2130
	add.n	a8, a2, a8
	s8i	a13, a8, 0
	add.n	a10, a2, a10
	s8i	a13, a10, 4
	s32i	a7, a10, 0
	s32i	a7, a10, 8
	s32i	a7, a8, 16
	addi	a10, a8, 40
	s32i	a6, a8, 24
	s32i	a4, a8, 28
	s32i	a6, a8, 32
	s32i	a4, a8, 36
	s32i	a8, sp, 224
	call8	_ZN14MotorControlRS17ActiveSerialTupleC1Ev
	l32i	a8, sp, 224
	l32r	a10, .LC2131
	s32i	a7, a8, 52
	s32i	a7, a8, 56
	s32i	a7, a8, 60
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS11ReadContextC1Ev
	l32r	a8, .LC2132
	l32r	a10, .LC2134
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	s32i	a7, a8, 4
	s32i	a6, a8, 8
	s32i	a4, a8, 12
	movi	a8, 0x1cd
	slli	a8, a8, 7
	add.n	a8, a2, a8
	s16i	a7, a8, 0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC1Ev
	movi	a10, 0x75b
	slli	a10, a10, 5
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS24PersistencePrerequisitesC1Ev
	l32r	a10, .LC2136
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS23PersistenceVerificationC1Ev
	l32r	a10, .LC2137
	movi.n	a12, 0x28
	addmi	a12, a12, 0x800
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a8, .LC2139
	l32r	a10, .LC2140
	add.n	a8, a2, a8
	add.n	a10, a2, a10
	movi.n	a12, 1
	movi	a11, 0x2b8
.L5275:
	s32i	a3, a8, 0
	s16i	a12, a8, 28
	s32i	a3, a8, 144
	s32i	a3, a8, 264
	s32i	a3, a8, 384
	s32i	a3, a8, 504
	s32i	a3, a8, 624
	add.n	a8, a8, a11
	bne	a8, a10, .L5275
	movi	a10, 0x3f5
	slli	a10, a10, 6
	movi.n	a3, 0
	add.n	a10, a2, a10
	movi.n	a12, 0
	movi.n	a11, 0
	s32i	a3, a10, 0
	s32i	a3, a10, 4
	s32i	a12, a10, 8
	s32i	a11, a10, 12
	l32r	a10, .LC2142
	l32r	a8, .LC2151
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	s32i	a3, a10, 4
	s32i	a12, a10, 8
	s32i	a11, a10, 12
	movi	a10, 0x7eb
	slli	a10, a10, 5
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	s8i	a3, a10, 4
	s32i	a3, a10, 8
	l32r	a10, .LC2144
	movi	a14, 0xc0
	add.n	a10, a2, a10
	s32i	a12, a10, 0
	s32i	a11, a10, 4
	l32r	a10, .LC2145
	add.n	a8, a2, a8
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	l32r	a10, .LC2140
	l32r	a11, .LC2152
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	movi	a10, 0x1fb
	slli	a10, a10, 7
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	l32r	a10, .LC2147
	s32i	a8, sp, 224
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	l32r	a10, .LC2148
	movi	a4, 0x8c
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	l32r	a10, .LC2149
	movi.n	a7, 0
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	l32r	a10, .LC2150
	add.n	a4, sp, a4
	add.n	a10, a2, a10
	s16i	a3, a10, 0
	add.n	a10, sp, a14
	call8	_ZN21MotorControlRSExample11Esp32S3Uart4portEv
	movi.n	a10, 0x20
	s32i	a10, sp, 172
	movi	a10, 0x88
	add.n	a10, a2, a10
	s32i	a10, sp, 176
	movi.n	a10, 0x40
	s32i	a10, sp, 180
	movi	a10, 0xd0
	add.n	a10, a2, a10
	l32i	a8, sp, 228
	l32r	a11, .LC2153
	s32i	a10, sp, 184
	movi	a10, 0x80
	movi.n	a12, 0x3c
	s32i	a10, sp, 188
	mov.n	a10, sp
	s32i	a8, sp, 168
	call8	memcpy
	l32r	a9, .LC2108
	mov.n	a11, sp
	s32i	a9, sp, 140
	mov.n	a10, a4
	s8i	a7, sp, 144
	call8	_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE
	movi.n	a12, 0x1c
	mov.n	a11, sp
	mov.n	a10, a4
	call8	memcpy
	movi	a14, 0xc0
	l32i	a10, sp, 224
	movi	a12, 0xa8
	mov.n	a13, a4
	add.n	a11, a14, sp
	add.n	a12, sp, a12
	call8	_ZN21MotorControlRSExample3Rtu6RunnerC1ERKNS0_4PortERKNS0_7StorageERKNS0_6TimingE
	movi.n	a10, 0x26
	s32i	a10, sp, 4
	movi	a10, 0x70
	addmi	a10, a10, 0x4700
	l32r	a8, .LC2099
	add.n	a10, a2, a10
	s32i	a10, sp, 8
	movi.n	a10, 0x39
	add.n	a5, a2, a8
	s32i	a10, sp, 12
	l32r	a8, .LC2105
	movi.n	a10, 0x22
	s32i	a10, sp, 28
	s32i	a10, sp, 24
	movi	a10, 0x7f7
	add.n	a6, a2, a8
	l32i	a11, sp, 224
	movi.n	a4, 1
	slli	a10, a10, 5
	s32i	a5, sp, 0
	s32i	a6, sp, 16
	mov.n	a12, sp
	add.n	a10, a2, a10
	s32i	a4, sp, 20
	call8	_ZN21MotorControlRSExample3Rtu8BusOwnerC1ERNS0_6RunnerERKNS0_10BusStorageE
	movi.n	a12, 0xc
	movi.n	a11, 0
	addi	a10, sp, 72
	call8	memset
	l32r	a10, .LC2156
	s32i	a2, sp, 0
	s32i	a10, sp, 4
	l32r	a10, .LC2157
	movi	a5, 0x1ff
	s32i	a10, sp, 8
	l32r	a10, .LC2158
	slli	a5, a5, 7
	s32i	a10, sp, 12
	l32r	a10, .LC2159
	add.n	a6, a2, a5
	s32i	a10, sp, 16
	l32r	a10, .LC2160
	movi	a12, 0x8c
	s32i	a10, sp, 20
	l32r	a10, .LC2161
	mov.n	a11, sp
	s32i	a10, sp, 24
	l32r	a10, .LC2162
	s32i	a10, sp, 28
	l32r	a10, .LC2163
	s32i	a10, sp, 32
	l32r	a10, .LC2164
	s32i	a10, sp, 36
	l32r	a10, .LC2165
	s32i	a10, sp, 40
	l32r	a10, .LC2166
	s32i	a10, sp, 44
	l32r	a10, .LC2167
	s32i	a10, sp, 48
	l32r	a10, .LC2168
	s32i	a10, sp, 52
	l32r	a10, .LC2169
	s32i	a10, sp, 56
	l32r	a10, .LC2170
	s32i	a10, sp, 60
	l32r	a10, .LC2171
	s32i	a10, sp, 64
	l32r	a10, .LC2172
	s32i	a10, sp, 68
	l32r	a10, .LC2173
	s32i	a10, sp, 76
	l32r	a10, .LC2174
	s32i	a10, sp, 84
	l32r	a10, .LC2175
	s32i	a10, sp, 88
	l32r	a10, .LC2176
	s32i	a10, sp, 92
	l32r	a10, .LC2177
	s32i	a10, sp, 96
	l32r	a10, .LC2178
	s32i	a10, sp, 100
	l32r	a10, .LC2179
	s32i	a10, sp, 104
	l32r	a10, .LC2180
	s32i	a10, sp, 108
	l32r	a10, .LC2181
	s32i	a10, sp, 112
	l32r	a10, .LC2182
	s32i	a10, sp, 116
	l32r	a10, .LC2183
	s32i	a10, sp, 120
	l32r	a10, .LC2184
	s32i	a10, sp, 124
	l32r	a10, .LC2185
	s32i	a10, sp, 128
	l32r	a10, .LC2186
	s32i	a10, sp, 132
	l32r	a10, .LC2187
	s32i	a10, sp, 136
	mov.n	a10, a6
	call8	memcpy
	l32r	a10, .LC2189
	l32r	a9, .LC2108
	add.n	a10, a2, a10
	s16i	a3, a10, 0
	l32r	a10, .LC2190
	s8i	a7, a6, 142
	s32i	a3, a6, 144
	s32i	a3, a6, 148
	add.n	a10, a2, a10
	s32i	a9, a10, 0
	s8i	a7, a10, 4
	movi	a10, 0xa4
	movi	a12, 0x80
	movi.n	a11, 0
	s32i	a3, a6, 160
	add.n	a10, a6, a10
	call8	memset
	l32r	a12, .LC2191
	addmi	a10, a6, 0x100
	movi.n	a11, 0
	addi	a10, a10, 36
	call8	memset
	l32r	a12, .LC2191
	addmi	a10, a6, 0x4100
	movi.n	a11, 0
	addi	a10, a10, 36
	call8	memset
	movi	a10, 0x228
	addmi	a10, a10, 0x7f00
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev
	movi	a10, 0x2d0
	addmi	a10, a10, 0x7f00
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev
	movi	a10, 0x610
	addmi	a10, a10, 0x7f00
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS16StateObservationC1Ev
	l32r	a10, .LC2195
	l32r	a9, .LC2196
	add.n	a10, a2, a10
	s32i	a3, a10, 0
	s8i	a7, a10, 4
	s32i	a3, a10, 8
	s32i	a3, a10, 12
	s32i	a3, a10, 16
	add.n	a9, a2, a9
	s32i	a3, a9, 0
	l32r	a9, .LC2197
	movi	a11, 0x507
	add.n	a9, a2, a9
	s32i	a3, a9, 0
	l32r	a9, .LC2198
	add.n	a9, a2, a9
	s16i	a11, a9, 0
	movi.n	a9, 5
	s8i	a9, a10, 30
	addi	a10, a10, 32
	call8	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC1Ev
	movi	a10, 0x770
	addmi	a10, a10, 0x7f00
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC1Ev
	movi	a10, 0x439
	slli	a10, a10, 5
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	l32r	a10, .LC2201
	add.n	a10, a6, a10
	call8	_ZN21MotorControlRSExample5Probe12GroupCommandC1Ev
	l32r	a9, .LC2202
	l32r	a10, .LC2205
	add.n	a9, a2, a9
	s32i	a3, a9, 0
	s8i	a7, a9, 4
	s32i	a3, a9, 8
	l32r	a9, .LC2203
	movi	a12, 0xb4
	add.n	a9, a6, a9
	s32i	a3, a9, 0
	l32r	a9, .LC2204
	movi.n	a11, 0
	add.n	a9, a6, a9
	s32i	a4, a9, 0
	add.n	a10, a6, a10
	call8	memset
	l32r	a9, .LC2206
	l32r	a10, .LC2207
	add.n	a9, a6, a9
	s32i	a3, a9, 0
	movi.n	a11, 0
	movi	a12, 0xc4
	add.n	a10, a6, a10
	call8	memset
	l32r	a8, .LC2208
	l32r	a11, .LC2211
	add.n	a8, a2, a8
	movi.n	a10, 4
	movi.n	a9, 7
	loop	a9, .L5282_LEND
.L5282:
	s32i	a11, a8, 0
	s8i	a10, a8, 19
	addi	a8, a8, 28
	.L5282_LEND:
	l32r	a8, .LC2212
	add.n	a5, a2, a5
	add.n	a5, a5, a8
	movi.n	a8, 0
	s32i	a8, a5, 0
	s32i	a8, a5, 4
	movi	a8, 0x315
	l32r	a7, .LC2215
	l32r	a10, .LC2214
	slli	a8, a8, 7
	add.n	a8, a2, a8
	movi.n	a9, 0
	s32i	a9, a8, 0
	mov.n	a12, a7
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a8, .LC2216
	l32r	a9, .LC2217
	add.n	a8, a2, a8
	s32i	a8, sp, 224
	l32r	a8, .LC2220
	l32r	a10, .LC2218
	add.n	a3, a2, a8
	l32r	a8, .LC2223
	l32r	a13, .LC2219
	add.n	a8, a2, a8
	l32r	a14, .LC2221
	l32r	a11, .LC2222
	s32i	a8, sp, 228
	add.n	a8, a2, a7
	l32r	a7, .LC2104
	s32i	a8, sp, 232
	add.n	a9, a2, a9
	add.n	a10, a2, a10
	add.n	a13, a2, a13
	add.n	a14, a2, a14
	add.n	a11, a2, a11
	mov.n	a8, a2
.L5285:
	l32i	a12, sp, 224
	l32r	a15, .LC2108
	s32i	a7, a12, 128
	s32i	a15, a12, 0
	l32i	a15, sp, 224
	movi.n	a12, 1
	l32i	a6, sp, 224
	s16i	a12, a15, 156
	s32i	a7, a15, 272
	s32i	a7, a15, 392
	s32i	a7, a15, 512
	s32i	a7, a15, 632
	s32i	a7, a15, 752
	movi	a15, 0x344
	add.n	a15, a6, a15
	s8i	a12, a15, 0
	l32r	a15, .LC2224
	movi.n	a6, 0x14
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	l32r	a15, .LC2225
	movi.n	a4, 1
	add.n	a15, a8, a15
	s32i	a7, a15, 0
	l32r	a15, .LC2226
	s8i	a6, a9, 4
	s32i	a15, a9, 0
	movi	a15, 0x1c4
	s32i	a7, a9, 148
	s32i	a7, a9, 236
	s32i	a7, a9, 324
	s32i	a7, a9, 344
	add.n	a15, a9, a15
	s8i	a12, a15, 0
	movi.n	a15, 0
	s32i	a15, a9, 500
	l32r	a15, .LC2228
	s32i	a4, a9, 496
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	movi	a15, 0x1fc
	movi.n	a6, 2
	add.n	a15, a9, a15
	s8i	a6, a15, 0
	l32r	a15, .LC2229
	movi	a5, 0x7d0
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	movi	a15, 0x240
	add.n	a15, a9, a15
	s16i	a5, a15, 0
	l32r	a15, .LC2230
	movi	a5, 0x64
	s32i	a15, a9, 580
	movi	a15, 0x248
	add.n	a15, a9, a15
	s16i	a5, a15, 0
	l32r	a15, .LC2231
	s32i	a4, a9, 704
	mov.n	a5, a4
	movi.n	a4, 0
	s32i	a4, a9, 708
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	movi	a15, 0x2cc
	add.n	a15, a9, a15
	s8i	a6, a15, 0
	l32r	a15, .LC2232
	movi.n	a6, 0x14
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	movi	a15, 0x360
	s32i	a5, a9, 776
	s32i	a4, a9, 780
	add.n	a15, a9, a15
	s8i	a12, a15, 0
	l32r	a15, .LC2226
	s32i	a15, a9, 888
	movi	a15, 0x37c
	add.n	a15, a9, a15
	s8i	a6, a15, 0
	l32r	a15, .LC2233
	s32i	a7, a9, 996
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	l32r	a15, .LC2234
	movi.n	a6, 5
	add.n	a15, a8, a15
	s8i	a6, a15, 0
	l32r	a15, .LC2235
	movi.n	a6, 3
	add.n	a15, a8, a15
	s32i	a7, a15, 0
	l32r	a15, .LC2236
	add.n	a15, a8, a15
	s32i	a7, a15, 0
	movi	a15, 0x148
	s32i	a7, a10, 0
	s32i	a7, a10, 88
	s32i	a7, a10, 176
	s32i	a7, a10, 264
	s32i	a7, a10, 284
	add.n	a15, a10, a15
	s8i	a12, a15, 0
	movi	a15, 0x18c
	s32i	a5, a10, 388
	add.n	a15, a10, a15
	s32i	a4, a10, 392
	s8i	a6, a15, 0
	l32r	a15, .LC2237
	movi.n	a6, 0x48
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	l32r	a15, .LC2238
	addmi	a6, a6, -0xc00
	add.n	a15, a8, a15
	s16i	a6, a15, 0
	l32r	a6, .LC2375
	movi	a15, 0x208
	add.n	a15, a10, a15
	s16i	a6, a15, 0
	movi	a15, 0x264
	s32i	a5, a10, 572
	s32i	a4, a10, 576
	add.n	a15, a10, a15
	s8i	a12, a15, 0
	l32r	a15, .LC2226
	movi.n	a6, 0x14
	s32i	a15, a10, 620
	movi	a15, 0x270
	add.n	a15, a10, a15
	s8i	a6, a15, 0
	l32r	a15, .LC2226
	s32i	a7, a10, 784
	s32i	a7, a10, 872
	s32i	a7, a10, 960
	s32i	a15, a13, 140
	l32r	a15, .LC2241
	movi.n	a5, 7
	s8i	a6, a13, 144
	s32i	a7, a13, 0
	s32i	a7, a13, 88
	s32i	a7, a13, 288
	s32i	a7, a13, 376
	s32i	a7, a13, 464
	s32i	a7, a13, 484
	s32i	a7, a13, 500
	add.n	a15, a8, a15
	s16i	a5, a15, 0
	l32r	a15, .LC2242
	movi	a6, 0x190
	add.n	a15, a8, a15
	s16i	a6, a15, 0
	l32r	a15, .LC2243
	movi	a4, 0x27c
	add.n	a15, a8, a15
	s8i	a12, a15, 0
	add.n	a4, a13, a4
	movi.n	a15, 2
	s16i	a15, a4, 0
	movi	a4, 0x2ec
	add.n	a4, a13, a4
	s8i	a12, a4, 0
	l32r	a4, .LC2244
	s32i	a7, a13, 864
	s32i	a7, a13, 960
	add.n	a4, a8, a4
	s32i	a7, a4, 0
	l32r	a4, .LC2245
	add.n	a4, a8, a4
	s32i	a7, a4, 0
	l32r	a4, .LC2246
	s16i	a6, a3, 4
	s8i	a12, a3, 52
	s16i	a5, a3, 0
	add.n	a4, a8, a4
	s16i	a15, a4, 0
	l32r	a4, .LC2247
	s16i	a6, a3, 180
	s8i	a12, a3, 228
	s16i	a5, a3, 176
	add.n	a4, a8, a4
	s16i	a15, a4, 0
	movi	a4, 0x144
	add.n	a4, a3, a4
	s8i	a15, a4, 0
	l32r	a4, .LC2248
	movi.n	a6, 3
	add.n	a4, a8, a4
	s8i	a6, a4, 0
	l32r	a4, .LC2249
	movi.n	a6, 4
	add.n	a4, a8, a4
	s8i	a6, a4, 0
	l32r	a4, .LC2250
	movi	a6, 0x190
	add.n	a4, a8, a4
	s32i	a7, a4, 0
	l32r	a4, .LC2251
	s16i	a6, a3, 508
	s16i	a5, a3, 504
	add.n	a4, a8, a4
	s8i	a12, a4, 0
	l32r	a4, .LC2252
	add.n	a4, a8, a4
	s16i	a15, a4, 0
	l32r	a4, .LC2253
	add.n	a4, a8, a4
	s16i	a5, a4, 0
	l32r	a5, .LC2254
	add.n	a5, a8, a5
	s16i	a6, a5, 0
	l32r	a6, .LC2255
	movi.n	a5, 1
	add.n	a6, a8, a6
	s8i	a12, a6, 0
	l32r	a12, .LC2256
	movi.n	a6, 0xf
	add.n	a12, a8, a12
	s16i	a15, a12, 0
	l32r	a12, .LC2257
	movi.n	a15, 1
	add.n	a12, a8, a12
	s32i	a15, a12, 0
	l32r	a12, .LC2258
	movi.n	a15, 0xf
	add.n	a12, a8, a12
	loop	a15, .L5284_LEND
.L5284:
	s32i	a5, a12, 0
	addi.n	a6, a6, -1
	addi	a12, a12, 20
	.L5284_LEND:
	s32i	a7, a14, 0
	s32i	a7, a14, 96
	s32i	a7, a14, 192
	s32i	a7, a14, 288
	s32i	a7, a14, 384
	s32i	a7, a14, 480
	s32i	a7, a14, 576
	s32i	a7, a14, 672
	s32i	a7, a14, 768
	s32i	a7, a14, 864
	s32i	a7, a14, 960
	movi	a12, 0x27c
	s32i	a7, a11, 0
	s32i	a7, a11, 96
	s32i	a7, a11, 192
	s32i	a7, a11, 288
	s32i	a7, a11, 384
	s32i	a7, a11, 480
	s32i	a7, a11, 576
	s32i	a7, a11, 604
	add.n	a12, a11, a12
	movi.n	a15, 0x23
	s16i	a15, a12, 0
	movi	a12, 0x284
	add.n	a12, a11, a12
	movi.n	a5, 0x3c
	s16i	a5, a12, 0
	l32r	a12, .LC2259
	movi.n	a5, 0x1e
	add.n	a12, a8, a12
	s16i	a5, a12, 0
	movi	a12, 0x288
	add.n	a12, a11, a12
	movi	a5, 0x64
	s16i	a5, a12, 0
	movi	a12, 0x2a8
	add.n	a12, a11, a12
	s16i	a15, a12, 0
	l32r	a12, .LC2260
	movi.n	a15, 7
	add.n	a12, a8, a12
	s16i	a15, a12, 0
	l32r	a12, .LC2226
	movi.n	a15, 0x14
	s32i	a12, a11, 780
	movi	a12, 0x310
	add.n	a12, a11, a12
	s8i	a15, a12, 0
	l32r	a12, .LC2261
	s32i	a7, a11, 960
	add.n	a12, a8, a12
	s32i	a7, a12, 0
	l32r	a12, .LC2262
	l32i	a15, sp, 224
	add.n	a12, a8, a12
	s32i	a7, a12, 0
	l32i	a12, sp, 228
	s32i	a7, a12, 0
	s32i	a7, a12, 88
	s32i	a7, a12, 176
	s32i	a7, a12, 264
	s32i	a7, a12, 352
	s32i	a7, a12, 372
	movi.n	a12, 0x50
	addmi	a12, a12, 0x2300
	add.n	a15, a15, a12
	s32i	a15, sp, 224
	l32i	a15, sp, 228
	add.n	a8, a8, a12
	add.n	a9, a9, a12
	add.n	a10, a10, a12
	add.n	a13, a13, a12
	add.n	a3, a3, a12
	add.n	a14, a14, a12
	add.n	a11, a11, a12
	add.n	a12, a15, a12
	s32i	a12, sp, 228
	l32i	a12, sp, 232
	bne	a8, a12, .L5285
	l32r	a10, .LC2264
	movi.n	a4, 0
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe10StateCacheC1Ev
	l32r	a8, .LC2265
	movi.n	a5, 0
	add.n	a8, a2, a8
	l32r	a10, .LC2266
	s8i	a6, a8, 0
	s32i	a6, a8, 4
	s32i	a6, a8, 8
	s32i	a6, a8, 12
	s32i	a6, a8, 16
	s32i	a4, a8, 24
	s32i	a5, a8, 28
	s32i	a4, a8, 32
	s32i	a5, a8, 36
	s32i	a4, a8, 40
	s32i	a5, a8, 44
	s32i	a4, a8, 48
	s32i	a5, a8, 52
	l32r	a8, .LC2267
	add.n	a10, a2, a10
	l32r	a9, .LC2108
	s32i	a6, a10, 0
	s32i	a6, a10, 4
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s8i	a6, a8, 4
	l32r	a8, .LC2268
	s32i	a6, a10, 16
	s32i	a4, a10, 24
	s32i	a5, a10, 28
	s32i	a4, a10, 32
	s32i	a5, a10, 36
	add.n	a8, a2, a8
	movi.n	a3, 0
	s16i	a6, a8, 0
	s8i	a3, a10, 42
	addi	a10, a10, 48
	call8	_ZN21MotorControlRSExample3Rtu14RecoveryResultC1Ev
	l32r	a10, .LC2269
	l32r	a8, .LC2270
	add.n	a10, a2, a10
	l32r	a9, .LC2108
	s32i	a6, a10, 0
	s32i	a6, a10, 4
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s8i	a3, a8, 4
	l32r	a8, .LC2271
	s32i	a6, a10, 16
	s32i	a4, a10, 24
	s32i	a5, a10, 28
	s32i	a4, a10, 32
	s32i	a5, a10, 36
	add.n	a8, a2, a8
	s16i	a6, a8, 0
	s8i	a3, a10, 42
	addi	a10, a10, 48
	call8	_ZN21MotorControlRSExample3Rtu14RecoveryResultC1Ev
	l32r	a9, .LC2272
	movi.n	a11, 0xc
	add.n	a9, a2, a9
	movi.n	a8, 0
	addmi	a11, a11, 0x4000
	movi.n	a10, 8
	loop	a10, .L5286_LEND
.L5286:
	s32i	a8, a9, 0
	s32i	a8, a9, 4
	add.n	a9, a9, a11
	.L5286_LEND:
	l32r	a9, .LC2275
	movi.n	a12, 1
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC2276
	l32r	a11, .LC2281
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC2277
	movi.n	a10, 0
	add.n	a9, a2, a9
	s32i	a12, a9, 0
	l32r	a9, .LC2278
	add.n	a11, a2, a11
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC2279
	movi.n	a13, 0
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC2280
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	movi.n	a9, 0
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	l32r	a11, .LC2282
	add.n	a11, a2, a11
	s32i	a8, a11, 24
	s32i	a8, a11, 28
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	s32i	a10, a11, 8
	s32i	a9, a11, 12
	s32i	a10, a11, 16
	s32i	a9, a11, 20
	l32r	a11, .LC2283
	add.n	a11, a2, a11
	s16i	a8, a11, 0
	l32r	a11, .LC2284
	add.n	a11, a2, a11
	s32i	a8, a11, 0
	s32i	a8, a11, 4
	s32i	a8, a11, 8
	s32i	a8, a11, 12
	s8i	a13, a11, 16
	l32r	a11, .LC2285
	add.n	a11, a2, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	l32r	a11, .LC2286
	add.n	a11, a2, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	l32r	a11, .LC2287
	add.n	a11, a2, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	l32r	a11, .LC2288
	add.n	a11, a2, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	l32r	a11, .LC2289
	add.n	a11, a2, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	l32r	a11, .LC2290
	add.n	a11, a2, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	l32r	a11, .LC2291
	add.n	a11, a2, a11
	s32i	a10, a11, 0
	s32i	a9, a11, 4
	movi	a11, 0xb9
	slli	a11, a11, 12
	add.n	a11, a2, a11
	s32i	a9, a11, 4
	l32r	a9, .LC2293
	s32i	a10, a11, 0
	add.n	a9, a2, a9
	s32i	a12, a9, 0
	l32r	a9, .LC2294
	l32r	a10, .LC2296
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC2295
	add.n	a10, a2, a10
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	s32i	a8, a9, 4
	s32i	a7, a9, 8
	call8	_ZN14MotorControlRS6ESS_RS19IdentityObservationC1Ev
	l32r	a10, .LC2297
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17ConfigObservationC1Ev
	l32r	a10, .LC2298
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	l32r	a10, .LC2299
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	l32r	a10, .LC2300
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	l32r	a10, .LC2301
	movi.n	a11, 0
	movi	a12, 0x760
	add.n	a10, a2, a10
	call8	memset
	l32r	a8, .LC2302
	movi.n	a11, 1
	add.n	a8, a2, a8
	movi	a10, 0x1d8
	movi.n	a9, 4
	loop	a9, .L5288_LEND
.L5288:
	s8i	a11, a8, 0
	s32i	a7, a8, 116
	s32i	a7, a8, 212
	s32i	a7, a8, 308
	s32i	a7, a8, 404
	add.n	a8, a8, a10
	.L5288_LEND:
	l32r	a10, .LC2304
	movi.n	a6, 0
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	l32r	a10, .LC2305
	movi.n	a5, 1
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17DriverObservationC1Ev
	l32r	a10, .LC2306
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS19DriverPrerequisitesC1Ev
	l32r	a8, .LC2307
	l32r	a7, .LC2308
	add.n	a8, a2, a8
	movi.n	a9, 0
	add.n	a7, a2, a7
	s8i	a9, a8, 0
	s32i	a6, a7, 0
	s8i	a6, a7, 4
	s32i	a6, a7, 8
	addi	a10, a7, 16
	s32i	a5, a7, 12
	call8	_ZN14MotorControlRS10UnitConfigC1Ev
	movi.n	a8, 0
	s32i	a8, a7, 112
	l32r	a8, .LC2462
	movi.n	a10, 0
	s32i	a8, a7, 116
	movi.n	a8, -1
	s32i	a8, a7, 120
	l32r	a8, .LC2463
	movi.n	a9, 0
	s32i	a8, a7, 124
	l32r	a8, .LC2311
	l32r	a12, .LC2316
	add.n	a8, a2, a8
	s16i	a6, a8, 0
	l32r	a8, .LC2312
	s32i	a10, a7, 136
	s32i	a9, a7, 140
	add.n	a8, a2, a8
	s16i	a6, a8, 0
	l32r	a8, .LC2313
	s32i	a10, a7, 152
	s32i	a9, a7, 156
	add.n	a8, a2, a8
	s16i	a6, a8, 0
	l32r	a8, .LC2314
	s32i	a10, a7, 168
	s32i	a9, a7, 172
	s32i	a10, a7, 176
	s32i	a9, a7, 180
	add.n	a8, a2, a8
	s8i	a5, a8, 0
	l32r	a8, .LC2315
	movi.n	a11, 0
	add.n	a8, a2, a8
	s32i	a6, a8, 0
	s8i	a11, a8, 4
	s32i	a6, a8, 8
	s32i	a6, a8, 12
	add.n	a12, a2, a12
	s16i	a6, a12, 0
	s8i	a11, a8, 18
	s32i	a10, a8, 24
	s32i	a9, a8, 28
	l32r	a12, .LC2317
	add.n	a12, a2, a12
	s16i	a6, a12, 0
	s32i	a10, a8, 40
	s32i	a10, a8, 48
	s32i	a10, a8, 56
	s32i	a9, a8, 44
	s32i	a9, a8, 52
	s32i	a9, a8, 60
	l32r	a8, .LC2318
	movi	a12, 0x100
	add.n	a8, a2, a8
	s32i	a10, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC2319
	add.n	a8, a2, a8
	s32i	a12, a8, 0
	l32r	a8, .LC2320
	l32r	a12, .LC2325
	add.n	a8, a2, a8
	s8i	a11, a8, 0
	l32r	a8, .LC2321
	add.n	a8, a2, a8
	s32i	a10, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC2322
	add.n	a8, a2, a8
	s32i	a6, a8, 0
	l32r	a8, .LC2323
	l32r	a6, .LC2324
	add.n	a8, a2, a8
	s8i	a11, a8, 0
	add.n	a10, a2, a6
	movi.n	a11, 0
	call8	memset
	l32r	a8, .LC2326
	movi	a11, 0x138
	add.n	a8, a2, a8
	movi.n	a10, 0x10
	loop	a10, .L5290_LEND
.L5290:
	movi.n	a9, 1
	s8i	a9, a8, 0
	add.n	a8, a8, a11
	.L5290_LEND:
	l32r	a10, .LC2325
	add.n	a6, a2, a6
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS13TrafficRecordC1Ev
	movi	a10, 0xb8
	addmi	a10, a10, 0x1400
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS13TrafficRecordC1Ev
	movi.n	a10, -0x10
	addmi	a10, a10, 0x1600
	mov.n	a11, a6
	movi.n	a12, 0x10
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS14TrafficCaptureC1EPNS_13TrafficRecordEj
	l32r	a8, .LC2330
	movi.n	a10, 0
	add.n	a8, a2, a8
	movi.n	a7, 0
	movi.n	a3, 0
	movi.n	a4, 0
	s8i	a10, a8, 0
	l32r	a10, .LC2331
	s32i	a3, a8, 8
	s32i	a3, a8, 16
	s32i	a3, a8, 24
	s32i	a3, a8, 32
	s32i	a3, a8, 40
	s32i	a3, a8, 48
	s32i	a4, a8, 12
	s32i	a4, a8, 20
	s32i	a4, a8, 28
	s32i	a4, a8, 36
	s32i	a4, a8, 44
	s32i	a4, a8, 52
	s32i	a7, a8, 56
	s32i	a7, a8, 60
	s32i	a7, a8, 64
	s32i	a7, a8, 68
	addmi	a6, a6, 0x1700
	s32i	a3, a6, 160
	s32i	a4, a6, 164
	s8i	a7, a6, 168
	add.n	a10, a2, a10
	call8	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev
	l32r	a5, .LC2332
	l32r	a15, .LC2333
	l32r	a8, .LC2334
	add.n	a5, a2, a5
	l32r	a14, .LC2335
	s32i	a15, a5, 0
	add.n	a8, a2, a8
	s32i	a14, a8, 0
	l32r	a8, .LC2336
	s8i	a7, a5, 8
	add.n	a8, a2, a8
	movi.n	a9, 0
	movi	a13, 0x3e8
	movi.n	a10, 1
	s32i	a13, a8, 0
	s32i	a9, a8, 4
	s32i	a9, a8, 12
	s32i	a10, a8, 8
	movi.n	a8, 1
	s8i	a8, a5, 32
	l32r	a8, .LC2338
	s32i	a7, a5, 36
	s32i	a7, a5, 40
	s32i	a7, a5, 44
	s32i	a7, a5, 48
	s32i	a7, a5, 52
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	l32r	a8, .LC2339
	movi.n	a10, 1
	add.n	a8, a2, a8
	slli	a10, a10, 16
	s32i	a10, a8, 0
	l32r	a10, .LC2341
	s8i	a7, a5, 64
	s16i	a7, a5, 66
	s32i	a7, a5, 68
	add.n	a10, a2, a10
	s16i	a7, a10, 0
	l32r	a10, .LC2342
	movi.n	a8, 0
	s8i	a8, a5, 74
	s32i	a7, a5, 76
	add.n	a10, a2, a10
	s32i	a8, sp, 224
	s32i	a7, a10, 0
	l32r	a10, .LC2343
	movi.n	a12, 0xc
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	l32r	a10, .LC2344
	movi.n	a11, 0
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	addi	a10, a5, 92
	call8	memset
	l32r	a10, .LC2345
	l32i	a8, sp, 224
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	l32r	a10, .LC2346
	movi.n	a11, 0
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	movi.n	a10, 0
	s32i	a10, a5, 128
	l32r	a10, .LC2348
	s8i	a8, a5, 112
	s32i	a3, a5, 120
	s32i	a11, a5, 132
	s32i	a4, a5, 124
	add.n	a10, a2, a10
	s16i	a7, a10, 0
	l32r	a10, .LC2349
	l32r	a6, .LC2104
	s8i	a8, a5, 138
	add.n	a10, a2, a10
	s8i	a8, a10, 0
	s32i	a7, a10, 4
	s32i	a6, a10, 8
	l32r	a10, .LC2350
	l32r	a11, .LC2351
	l32r	a15, .LC2333
	s32i	a10, a5, 152
	l32r	a10, .LC2352
	l32r	a14, .LC2335
	s32i	a7, a5, 156
	add.n	a11, a2, a11
	s32i	a15, a11, 0
	add.n	a10, a2, a10
	s32i	a14, a10, 0
	l32r	a10, .LC2353
	movi	a13, 0x3e8
	s8i	a8, a11, 8
	add.n	a10, a2, a10
	movi.n	a8, 1
	movi.n	a9, 0
	s32i	a13, a10, 0
	s32i	a8, a10, 8
	s32i	a9, a10, 4
	s32i	a9, a10, 12
	movi	a10, 0xc8
	s8i	a8, a11, 32
	add.n	a10, a5, a10
	call8	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev
	movi	a10, 0x218
	add.n	a10, a5, a10
	call8	_ZN14MotorControlRS15PositionRequestC1Ev
	l32r	a9, .LC2354
	l32r	a10, .LC2355
	s32i	a3, a5, 608
	s32i	a7, a5, 600
	s32i	a7, a5, 604
	s32i	a4, a5, 612
	add.n	a9, a2, a9
	movi.n	a12, 0xa
	s16i	a7, a9, 0
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a9, .LC2356
	l32i	a8, sp, 224
	add.n	a9, a2, a9
	s32i	a7, a9, 0
	l32r	a9, .LC2357
	l32r	a10, .LC2360
	add.n	a9, a2, a9
	s32i	a7, a9, 0
	l32r	a9, .LC2358
	add.n	a10, a2, a10
	add.n	a9, a2, a9
	s32i	a7, a9, 0
	l32r	a9, .LC2359
	movi	a11, 0x7d0
	add.n	a9, a2, a9
	s8i	a8, a9, 4
	s32i	a7, a9, 0
	s32i	a7, a9, 8
	s16i	a7, a9, 12
	s16i	a11, a10, 0
	l32r	a11, .LC2230
	s32i	a11, a10, 4
	movi	a11, 0x64
	s16i	a11, a10, 8
	l32r	a10, .LC2361
	s32i	a7, a9, 28
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	l32r	a10, .LC2362
	add.n	a10, a2, a10
	s16i	a7, a10, 0
	l32r	a10, .LC2363
	s8i	a8, a9, 38
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	l32r	a10, .LC2364
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	l32r	a10, .LC2365
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	s32i	a3, a9, 56
	s16i	a7, a9, 52
	s32i	a4, a9, 60
	s32i	a3, a9, 64
	s32i	a4, a9, 68
	l32r	a9, .LC2366
	l32r	a10, .LC2368
	add.n	a9, a2, a9
	s8i	a8, a9, 0
	l32r	a9, .LC2367
	add.n	a10, a2, a10
	add.n	a9, a2, a9
	s8i	a8, a9, 4
	s32i	a7, a9, 0
	s32i	a7, a9, 8
	s32i	a7, a9, 12
	s32i	a7, a10, 0
	l32r	a10, .LC2369
	s32i	a3, a9, 24
	s32i	a4, a9, 28
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17HomePrerequisitesC1Ev
	l32r	a9, .LC2370
	l32i	a8, sp, 224
	l32r	a10, .LC2371
	add.n	a9, a2, a9
	s8i	a8, a9, 4
	s32i	a7, a9, 0
	s32i	a7, a9, 8
	s32i	a7, a9, 12
	add.n	a10, a2, a10
	s32i	a7, a10, 0
	movi	a10, 0x179
	slli	a10, a10, 11
	movi	a11, -0x177
	s8i	a8, a9, 20
	s16i	a7, a9, 22
	add.n	a10, a2, a10
	slli	a11, a11, 19
	s32i	a11, a10, 0
	l32r	a10, .LC2374
	l32r	a11, .LC2375
	add.n	a10, a2, a10
	s32i	a11, a10, 0
	l32r	a10, .LC2376
	s32i	a3, a9, 40
	s32i	a3, a9, 48
	s16i	a7, a9, 32
	s32i	a4, a9, 44
	s32i	a4, a9, 52
	l32r	a9, .LC2377
	add.n	a10, a2, a10
	s8i	a8, a10, 4
	s32i	a7, a10, 0
	s32i	a7, a10, 8
	s32i	a7, a10, 12
	s32i	a7, a10, 16
	add.n	a9, a2, a9
	s32i	a7, a9, 0
	l32r	a9, .LC2378
	movi	a11, 0x507
	add.n	a9, a2, a9
	s32i	a7, a9, 0
	l32r	a9, .LC2379
	add.n	a9, a2, a9
	s16i	a11, a9, 0
	movi.n	a9, 5
	s8i	a9, a10, 30
	addi	a10, a10, 32
	call8	_ZN14MotorControlRS6ESS_RS19ReadStepObservationC1Ev
	l32r	a10, .LC2380
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS27HomingParametersObservationC1Ev
	l32r	a9, .LC2381
	movi.n	a10, 1
	add.n	a9, a2, a9
	s32i	a10, a9, 0
	l32r	a10, .LC2382
	movi.n	a12, 0x20
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a10, .LC2383
	movi.n	a12, 0x20
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a10, .LC2384
	movi.n	a12, 0x20
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a9, .LC2385
	l32i	a8, sp, 224
	add.n	a9, a2, a9
	s8i	a8, a9, 4
	l32r	a8, .LC2386
	s32i	a7, a9, 0
	s32i	a7, a9, 8
	add.n	a8, a2, a8
	s32i	a3, a8, 0
	s32i	a4, a8, 4
	l32r	a8, .LC2387
	l32r	a10, .LC2389
	add.n	a8, a2, a8
	s32i	a3, a8, 0
	s32i	a4, a8, 4
	l32r	a8, .LC2388
	add.n	a10, a2, a10
	add.n	a8, a2, a8
	s16i	a7, a8, 0
	call8	_ZN12_GLOBAL__N_13App12StageSessionC1Ev
	l32r	a10, .LC2390
	movi.n	a3, 0x48
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS11MoveContextC1Ev
	l32r	a10, .LC2391
	l32r	a12, .LC2392
	movi.n	a11, 0
	add.n	a10, a2, a10
	call8	memset
	l32r	a9, .LC2395
	l32r	a8, .LC2393
	l32r	a11, .LC2394
	l32r	a12, .LC2396
	l32r	a10, .LC2397
	add.n	a5, a2, a9
	add.n	a8, a2, a8
	add.n	a11, a2, a11
	add.n	a12, a2, a12
	add.n	a10, a2, a10
	movi.n	a9, 1
	addmi	a3, a3, 0xa00
	movi.n	a13, 0xf
.L5330:
	s32i	a13, sp, 224
	movi.n	a13, 0
	s32i	a13, a8, 100
	l32r	a13, .LC2462
	l32r	a14, .LC2464
	s32i	a13, a8, 104
	movi.n	a13, -1
	s32i	a13, a8, 108
	l32r	a13, .LC2463
	l32r	a15, .LC2465
	s32i	a13, a8, 112
	movi.n	a13, 2
	s8i	a13, a8, 198
	movi.n	a13, 3
	s8i	a13, a8, 199
	movi.n	a13, 4
	s8i	a13, a8, 200
	movi.n	a13, 4
	s32i	a13, a8, 440
	movi.n	a13, 0x40
	s32i	a13, a8, 444
	movi	a13, 0x400
	s32i	a13, a8, 448
	movi	a13, 0x100
	s32i	a13, a8, 452
	movi	a13, 0x1c8
	s32i	a14, a8, 84
	s32i	a15, a8, 88
	s32i	a9, a8, 0
	s32i	a9, a8, 8
	s32i	a9, a8, 20
	s32i	a9, a8, 32
	s32i	a9, a8, 44
	s32i	a9, a8, 56
	s8i	a9, a8, 72
	s8i	a9, a8, 76
	s32i	a6, a8, 328
	s16i	a9, a8, 410
	add.n	a13, a8, a13
	movi.n	a7, 5
	s8i	a7, a13, 0
	movi	a13, 0x1c9
	add.n	a13, a8, a13
	movi.n	a7, 6
	s8i	a7, a13, 0
	s32i	a9, a8, 464
	s32i	a9, a8, 476
	movi	a13, 0x210
	s32i	a9, a8, 488
	movi.n	a14, 1
	s32i	a9, a8, 500
	s32i	a9, a8, 512
	add.n	a13, a8, a13
	s8i	a14, a13, 0
	movi	a13, 0x214
	add.n	a13, a8, a13
	s8i	a14, a13, 0
	l32r	a15, .LC2465
	l32r	a14, .LC2464
	l32r	a13, .LC2350
	s32i	a14, a8, 540
	s32i	a15, a8, 544
	s32i	a6, a8, 680
	s32i	a6, a8, 800
	s32i	a6, a8, 920
	s32i	a13, a11, 404
	s32i	a6, a11, 0
	s32i	a6, a11, 120
	movi.n	a13, 7
	movi.n	a4, 9
	movi.n	a15, 0xa
	movi	a14, 0x21c
	s8i	a15, a5, 1
	s8i	a13, a5, 2
	s8i	a4, a5, 0
	add.n	a14, a11, a14
	movi.n	a7, 5
	s8i	a7, a14, 0
	movi.n	a7, 8
	s8i	a13, a5, 4
	s8i	a7, a5, 5
	s32i	a6, a11, 656
	s32i	a6, a11, 748
	movi	a14, 0x33c
	s8i	a15, a12, 1
	s8i	a13, a12, 2
	s8i	a4, a12, 0
	add.n	a14, a11, a14
	movi.n	a15, 5
	s8i	a15, a14, 0
	s8i	a13, a12, 4
	s8i	a7, a12, 5
	movi	a14, 0xd3
	s32i	a6, a11, 944
	add.n	a15, a12, a14
	s32i	a6, a15, 0
	s8i	a4, a10, 0
	movi.n	a15, 0xa
	s8i	a15, a10, 1
	movi.n	a15, 5
	s8i	a13, a10, 2
	s8i	a13, a10, 4
	s8i	a15, a10, 3
	s8i	a7, a10, 5
	addi	a13, a10, 119
	s32i	a6, a13, 0
	movi	a13, 0xdc
	add.n	a14, a10, a14
	addmi	a13, a13, 0x900
	add.n	a13, a8, a13
	s32i	a6, a14, 0
	s32i	a6, a13, 0
	l32i	a13, sp, 224
	add.n	a8, a8, a3
	add.n	a11, a11, a3
	add.n	a5, a5, a3
	add.n	a12, a12, a3
	add.n	a10, a10, a3
	addi.n	a13, a13, -1
	bnez.n	a13, .L5330
	l32r	a8, .LC2402
	l32r	a7, .LC2391
	add.n	a8, a2, a8
	movi.n	a9, 0
	s16i	a9, a8, 0
	l32r	a8, .LC2403
	add.n	a7, a2, a7
	movi	a10, 0x269
	movi.n	a9, 0
	add.n	a8, a7, a8
	slli	a10, a10, 6
	s32i	a9, a8, 0
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_13App14GroupOperationC1Ev
	l32r	a10, .LC2405
	movi.n	a4, 1
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_13App14GroupOperationC1Ev
	movi	a10, 0x563
	slli	a10, a10, 5
	add.n	a10, a7, a10
	call8	_ZN12_GLOBAL__N_13App14GroupOperationC1Ev
	l32r	a10, .LC2407
	movi.n	a12, 0x20
	movi.n	a11, 0
	addmi	a12, a12, 0x1200
	add.n	a10, a7, a10
	call8	memset
	l32r	a15, .LC2410
	l32r	a3, .LC2409
	l32r	a14, .LC2411
	l32r	a11, .LC2412
	movi.n	a10, 0
	movi.n	a9, 2
	movi.n	a5, 0
	j	.L5298
.L5304:
	movi.n	a9, 1
.L5298:
	addx8	a8, a10, a10
	slli	a8, a8, 4
	add.n	a8, a8, a10
	slli	a8, a8, 4
	add.n	a8, a7, a8
	add.n	a10, a8, a3
	s32i	a4, a10, 0
	s32i	a5, a10, 4
	add.n	a12, a8, a15
	movi.n	a10, 1
	s8i	a10, a12, 0
	movi.n	a13, 2
	add.n	a12, a8, a14
	s8i	a13, a12, 0
	add.n	a12, a8, a11
	s8i	a10, a12, 0
	l32r	a10, .LC2413
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2414
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	movi	a10, 0x5b5
	slli	a10, a10, 5
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2416
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2417
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2418
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	movi	a10, 0x2df
	slli	a10, a10, 6
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2420
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2421
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2422
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	movi	a10, 0x5c7
	slli	a10, a10, 5
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2424
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2425
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2426
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	movi.n	a10, 0x5d
	slli	a10, a10, 9
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2428
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2429
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2121
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	movi	a10, 0x5d9
	slli	a10, a10, 5
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2431
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2432
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2433
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	movi	a10, 0x2f1
	slli	a10, a10, 6
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2435
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2436
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2437
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	movi	a10, 0x5eb
	slli	a10, a10, 5
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2439
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2440
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2441
	add.n	a10, a8, a10
	s32i	a6, a10, 0
	l32r	a10, .LC2442
	add.n	a8, a8, a10
	l32r	a10, .LC2108
	s32i	a10, a8, 0
	movi.n	a10, 1
	bnei	a9, 1, .L5304
	l32r	a10, .LC2443
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe9GroupViewC1Ev
	movi	a10, 0x66b
	slli	a10, a10, 5
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe12GroupCommandC1Ev
	l32r	a7, .LC2110
	l32r	a11, .LC2112
	add.n	a7, a2, a7
	add.n	a11, a2, a11
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample10hostTimingERKNS_9HostTupleERNS_10HostTimingE
	l32r	a8, .LC2109
	movi.n	a12, 5
	add.n	a10, a2, a8
	mov.n	a11, a7
	call8	memcpy
	mov.n	a11, a10
	l32r	a10, .LC2107
	movi.n	a12, 5
	add.n	a10, a2, a10
	call8	memcpy
	l32r	a8, .LC2445
	movi.n	a9, 0
	l8ui	a10, a8, 0
	l32r	a8, .LC2111
	add.n	a8, a2, a8
	s8i	a10, a8, 0
	beqz.n	a10, .L5299
	l32r	a11, .LC2152
	mov.n	a10, sp
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart5statsEv
	l32i	a9, sp, 60
.L5299:
	l32r	a8, .LC2446
	l32r	a7, .LC2448
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC2447
	movi	a5, 0x8c
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	s32i	a9, sp, 0
	l32i	a9, a8, 8
	l32i	a8, a8, 12
	s32i	a10, sp, 4
	s32i	a8, sp, 12
	l32r	a8, .LC2449
	s32i	a9, sp, 8
	add.n	a7, a2, a7
	add.n	a4, a2, a8
	movi.n	a6, 0
	add.n	a5, sp, a5
	movi.n	a3, 1
.L5303:
	extui	a9, a6, 0, 16
	addx4	a9, a9, sp
	l32i	a9, a9, 0
	movi.n	a8, 0
	extui	a11, a6, 0, 8
	s8i	a8, sp, 144
	s32i	a9, sp, 140
	mov.n	a10, a5
	s32i	a11, sp, 228
	s32i	a9, sp, 224
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	l32i	a11, sp, 228
	beqz.n	a10, .L5300
	l32i	a9, sp, 224
	s32i	a9, a4, 0
.L5300:
	s8i	a3, a7, 0
	s8i	a11, sp, 144
	movi.n	a9, 0
.L5302:
	add.n	a10, sp, a9
	l32i	a10, a10, 0
	s32i	a10, sp, 140
	l8ui	a10, a7, 0
	beqz.n	a10, .L5301
	mov.n	a10, a5
	s32i	a9, sp, 224
	call8	_ZN21MotorControlRSExample17reviewedHostTupleERKNS_9HostTupleE
	l32i	a9, sp, 224
.L5301:
	s8i	a10, a7, 0
	addi.n	a9, a9, 4
	bnei	a9, 16, .L5302
	addi.n	a6, a6, 1
	addi.n	a7, a7, 1
	addi.n	a4, a4, 4
	bnei	a6, 4, .L5303
	l32r	a8, .LC2450
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC2308
	l32r	a9, .LC2381
	movi.n	a7, 1
	add.n	a8, a2, a8
	s32i	a7, a8, 0
	add.n	a9, a2, a9
	l32r	a8, .LC2451
	l32i	a9, a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC2452
	addi.n	a11, a2, 8
	add.n	a10, a2, a8
	movi.n	a12, 0x5e
	call8	memcpy
	l32i	a11, a10, 0
	movi.n	a9, 0
	mov.n	a8, a10
	l32r	a10, .LC2453
	mov.n	a12, a9
	add.n	a10, a2, a10
	movnez	a12, a7, a11
	s8i	a12, a10, 0
	l32i	a10, a8, 4
	l32r	a8, .LC2353
	add.n	a8, a2, a8
	s32i	a11, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC2454
	add.n	a8, a2, a8
	s32i	a10, a8, 0
	l32i	a10, a2, 0
	s32i	a9, a8, 4
	movi	a9, 0x3e8
	l32r	a8, .LC2455
	mull	a11, a9, a10
	muluh	a9, a9, a10
	add.n	a8, a2, a8
	s32i	a11, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC2311
	add.n	a8, a2, a8
	s8i	a7, a8, 0
	l32r	a8, .LC2456
	add.n	a8, a2, a8
	s8i	a7, a8, 0
	l32r	a8, .LC2457
	add.n	a8, a2, a8
	s8i	a7, a8, 0
	l32r	a8, .LC2458
	add.n	a8, a2, a8
	s8i	a7, a8, 0
	l32r	a8, .LC2459
	add.n	a8, a2, a8
	s8i	a7, a8, 0
	l32r	a8, .LC2460
	add.n	a8, a2, a8
	s8i	a7, a8, 0
	l32r	a8, .LC2461
	add.n	a2, a2, a8
	s8i	a7, a2, 0
	retw.n
.LFE2047:
	.size	_ZN12_GLOBAL__N_13AppC2ERKN21MotorControlRSExample18ApplicationOptionsE, .-_ZN12_GLOBAL__N_13AppC2ERKN21MotorControlRSExample18ApplicationOptionsE
	.set	_ZN12_GLOBAL__N_13AppC1ERKN21MotorControlRSExample18ApplicationOptionsE,_ZN12_GLOBAL__N_13AppC2ERKN21MotorControlRSExample18ApplicationOptionsE
	.section	.rodata.str1.1
.LC2466:
	.string	"uart_init"
.LC2468:
	.string	"owner_watchdog"
.LC2472:
	.string	"console_init"
.LC2475:
	.string	"!printErrors && !hardware.timerRunning"
.LC2477:
	.string	"bool heap_caps_check_integrity_all(bool)"
.LC2479:
	.string	"C:\\Users\\Honza\\Documents\\Projects\\MotorControl-RS\\test\\fakes\\esp32_uart/esp_heap_caps.h"
.LC2481:
	.string	"heap_integrity"
.LC2483:
	.string	"psram_allocation"
	.text
	.literal_position
	.literal .LC2467, .LC2466
	.literal .LC2469, .LC2468
	.literal .LC2470, _ZN12_GLOBAL__N_13appE
	.literal .LC2473, .LC2472
	.literal .LC2474, hardware
	.literal .LC2476, .LC2475
	.literal .LC2478, .LC2477
	.literal .LC2480, .LC2479
	.literal .LC2482, .LC2481
	.literal .LC2484, .LC2483
	.literal .LC2485, 826872
	.literal .LC2486, _ZN12_GLOBAL__N_122writeResponseConfirmedE
	.literal .LC2488, _ZN12_GLOBAL__N_14uartE
	.literal .LC2489, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC2490, 770408
	.literal .LC2491, 64920
	.align	4
	.global	_ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE
	.type	_ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE, @function
_ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE:
.LFB2381:
	entry	sp, 48
.LCFI189:
	l32r	a6, .LC2470
	extui	a3, a3, 0, 8
	l32i	a7, a6, 0
	bnez.n	a7, .L5332
	call8	_ZN21MotorControlRSExample14RuntimeWitness5beginEv
	addi.n	a10, a4, 8
	call8	_ZN14MotorControlRS18validateUnitConfigERKNS_10UnitConfigE
	extui	a10, a10, 0, 8
	bnez.n	a10, .L5332
	l32i	a8, a4, 4
	movi.n	a9, 0x2f
	addi.n	a8, a8, -1
	addmi	a9, a9, 0x7500
	bltu	a9, a8, .L5332
	call8	_ZN21MotorControlRSExample8Platform12beginConsoleEv
	bnez.n	a10, .L5335
	l32r	a10, .LC2473
.L5351:
	call8	_ZN21MotorControlRSExample8Platform11bootFailureEPKc
.L5332:
	movi.n	a2, 0
	j	.L5336
.L5335:
	l32r	a8, .LC2474
	addmi	a9, a8, 0x100
	l8ui	a10, a9, 18
	beqz.n	a10, .L5337
	l32r	a13, .LC2476
	l32r	a12, .LC2478
	l32r	a10, .LC2480
	movi.n	a11, 8
	call8	__assert_func
.L5337:
	l32i	a10, a8, 340
	addi.n	a10, a10, 1
	s32i	a10, a8, 340
	l8ui	a10, a9, 81
	bnez.n	a10, .L5338
	l32r	a10, .LC2482
	j	.L5351
.L5338:
	l32i	a10, a8, 300
	addi.n	a10, a10, 1
	s32i	a10, a8, 300
	movi.n	a10, 6
	s32i	a10, a8, 304
	l8ui	a8, a9, 40
	beqz.n	a8, .L5339
.L5340:
	l32r	a10, .LC2484
	j	.L5351
.L5339:
	l32r	a10, .LC2485
	call8	malloc
	mov.n	a5, a10
	beqz.n	a10, .L5340
	l32r	a8, .LC2486
	l32r	a10, .LC2488
	movi	a12, 0xe1
	s8i	a3, a8, 0
	slli	a12, a12, 9
	mov.n	a11, a2
	call8	_ZN21MotorControlRSExample11Esp32S3Uart5beginERKNS0_4PinsEm
	l32r	a3, .LC2489
	s8i	a10, a3, 0
	bnez.n	a10, .L5341
	l32r	a7, .LC2467
.L5341:
	mov.n	a11, a4
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_13AppC1ERKN21MotorControlRSExample18ApplicationOptionsE
	s32i	a5, a6, 0
	call8	_ZN21MotorControlRSExample13OwnerWatchdog5beginEv
	bnez.n	a10, .L5342
	l32r	a7, .LC2469
	s8i	a10, a3, 0
.L5342:
	l32i	a8, a6, 0
	l32r	a11, .LC2490
	l32r	a10, .LC2491
	add.n	a11, a8, a11
	add.n	a10, a8, a10
	call8	_ZN21MotorControlRSExample3Rtu6Runner17setTrafficCaptureEPN14MotorControlRS14TrafficCaptureE
	l32i	a10, a6, 0
	movi	a8, 0x1ff
	slli	a8, a8, 7
	add.n	a10, a10, a8
	call8	_ZN21MotorControlRSExample5Probe7Console7welcomeEv
	beqz.n	a7, .L5343
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample8Platform11bootFailureEPKc
.L5343:
	l8ui	a2, a3, 0
.L5336:
	retw.n
.LFE2381:
	.size	_ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE, .-_ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE
	.section	.rodata.str1.1
.LC2494:
	.string	"move not admitted; inspect readiness, units, limits or owner capacity"
	.text
	.literal_position
	.literal .LC2493, .LC2094
	.literal .LC2495, .LC2494
	.literal .LC2496, .LC12
	.literal .LC2497, _ZN12_GLOBAL__N_13appE
	.literal .LC2498, .LC8
	.literal .LC2499, 764508
	.align	4
	.global	_ZN21MotorControlRSExample10submitMoveERKN14MotorControlRS15PositionRequestEtRmNS0_9MoveSetupE
	.type	_ZN21MotorControlRSExample10submitMoveERKN14MotorControlRS15PositionRequestEtRmNS0_9MoveSetupE, @function
_ZN21MotorControlRSExample10submitMoveERKN14MotorControlRS15PositionRequestEtRmNS0_9MoveSetupE:
.LFB2382:
	entry	sp, 128
.LCFI190:
	l32r	a7, .LC2497
	extui	a3, a3, 0, 16
	l32i	a6, a7, 0
	extui	a5, a5, 0, 8
	bnez.n	a6, .L5353
	movi.n	a8, 1
	l32r	a4, .LC2493
	s8i	a8, sp, 72
	movi.n	a3, 0
	j	.L5354
.L5353:
	l32r	a11, .LC2498
	movi.n	a12, 0x48
	mov.n	a10, sp
	call8	memcpy
	mov.n	a11, a2
	movi.n	a12, 0x40
	mov.n	a10, sp
	call8	memcpy
	l32r	a8, .LC2499
	movi.n	a2, 1
	add.n	a8, a6, a8
	l8ui	a12, a8, 0
	mov.n	a14, a4
	mov.n	a13, sp
	movi.n	a11, 0
	mov.n	a10, a6
	s16i	a3, sp, 64
	s8i	a2, sp, 66
	s8i	a5, sp, 67
	call8	_ZN12_GLOBAL__N_19startMoveEPvmhRKN14MotorControlRS11MoveRequestERm
	mov.n	a3, a10
	beqz.n	a10, .L5355
	movi.n	a9, 0xb
	movi.n	a8, 1
	bne	a10, a9, .L5356
	movi.n	a8, 3
.L5356:
	l32r	a4, .LC2495
	s8i	a8, sp, 72
	j	.L5354
.L5355:
	l32i	a11, a4, 0
	l32i	a10, a7, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	addmi	a10, a10, 0x600
	l32r	a4, .LC2496
	s8i	a3, sp, 72
	s8i	a2, a10, 232
	movi.n	a3, 0
.L5354:
	l32i	a2, sp, 72
	movi.n	a5, 0
	retw.n
.LFE2382:
	.size	_ZN21MotorControlRSExample10submitMoveERKN14MotorControlRS15PositionRequestEtRmNS0_9MoveSetupE, .-_ZN21MotorControlRSExample10submitMoveERKN14MotorControlRS15PositionRequestEtRmNS0_9MoveSetupE
	.section	.rodata
	.align	8
.LC9:
	.word	0
	.word	0
	.word	1
	.word	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	2
	.byte	0
	.byte	0
	.zero	1
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.byte	0
	.byte	1
	.zero	6
	.word	0
	.word	0
	.word	0
	.word	0
	.text
	.literal_position
	.literal .LC2500, .LC9
	.literal .LC2502, _ZN12_GLOBAL__N_13appE
	.literal .LC2503, 764516
	.align	4
	.type	_ZN21MotorControlRSExampleL9moveValueEN14MotorControlRS8RationalENS0_12PositionUnitEbRmtNS0_9MoveSetupE, @function
_ZN21MotorControlRSExampleL9moveValueEN14MotorControlRS8RationalENS0_12PositionUnitEbRmtNS0_9MoveSetupE:
.LFB2383:
	entry	sp, 128
.LCFI191:
	l32r	a11, .LC2500
	movi.n	a12, 0x40
	mov.n	a10, sp
	s32i	a4, sp, 88
	s32i	a5, sp, 92
	l8ui	a4, sp, 136
	l16ui	a5, sp, 132
	s32i	a2, sp, 80
	s32i	a3, sp, 84
	call8	memcpy
	movi	a9, 0x1ff
	slli	a9, a9, 21
	movi.n	a8, 1
	s32i.n	a9, sp, 36
	l32i	a9, sp, 80
	s8i	a8, sp, 28
	movi.n	a8, 0
	l32i	a10, sp, 84
	s32i.n	a8, sp, 32
	s32i	a9, sp, 0
	l32i	a8, sp, 92
	l32i	a9, sp, 88
	extui	a7, a7, 0, 8
	s32i	a10, sp, 4
	s32i	a9, sp, 8
	s32i	a8, sp, 12
	s8i	a6, sp, 16
	s8i	a7, sp, 18
	beqz.n	a6, .L5359
	bnei	a6, 6, .L5361
	movi.n	a6, 2
	j	.L5359
.L5361:
	movi.n	a6, 1
.L5359:
	l32r	a8, .LC2502
	s8i	a6, sp, 17
	l32i	a8, a8, 0
	movi.n	a9, 0
	beqz.n	a8, .L5360
	l32r	a9, .LC2503
	add.n	a8, a8, a9
	l32i	a9, a8, 0
.L5360:
	l32i	a12, sp, 128
	mov.n	a13, a4
	mov.n	a11, a5
	mov.n	a10, sp
	s32i	a9, sp, 24
	call8	_ZN21MotorControlRSExample10submitMoveERKN14MotorControlRS15PositionRequestEtRmNS0_9MoveSetupE
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2383:
	.size	_ZN21MotorControlRSExampleL9moveValueEN14MotorControlRS8RationalENS0_12PositionUnitEbRmtNS0_9MoveSetupE, .-_ZN21MotorControlRSExampleL9moveValueEN14MotorControlRS8RationalENS0_12PositionUnitEbRmtNS0_9MoveSetupE
	.align	4
	.global	_ZN21MotorControlRSExample6moveByEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE
	.type	_ZN21MotorControlRSExample6moveByEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE, @function
_ZN21MotorControlRSExample6moveByEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE:
.LFB2384:
	entry	sp, 80
.LCFI192:
	l16ui	a8, sp, 80
	l8ui	a9, sp, 84
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a12, a4
	mov.n	a13, a5
	s32i	a9, sp, 8
	s32i	a8, sp, 4
	s32i	a7, sp, 0
	movi.n	a15, 1
	extui	a14, a6, 0, 8
	call8	_ZN21MotorControlRSExampleL9moveValueEN14MotorControlRS8RationalENS0_12PositionUnitEbRmtNS0_9MoveSetupE
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2384:
	.size	_ZN21MotorControlRSExample6moveByEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE, .-_ZN21MotorControlRSExample6moveByEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE
	.align	4
	.global	_ZN21MotorControlRSExample6moveToEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE
	.type	_ZN21MotorControlRSExample6moveToEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE, @function
_ZN21MotorControlRSExample6moveToEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE:
.LFB2385:
	entry	sp, 80
.LCFI193:
	l16ui	a8, sp, 80
	l8ui	a9, sp, 84
	mov.n	a10, a2
	mov.n	a11, a3
	mov.n	a12, a4
	mov.n	a13, a5
	s32i	a9, sp, 8
	s32i	a8, sp, 4
	s32i	a7, sp, 0
	movi.n	a15, 0
	extui	a14, a6, 0, 8
	call8	_ZN21MotorControlRSExampleL9moveValueEN14MotorControlRS8RationalENS0_12PositionUnitEbRmtNS0_9MoveSetupE
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2385:
	.size	_ZN21MotorControlRSExample6moveToEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE, .-_ZN21MotorControlRSExample6moveToEN14MotorControlRS8RationalENS0_12PositionUnitERmtNS0_9MoveSetupE
	.literal_position
	.literal .LC2504, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample12moveProgressEmRNS_12MoveProgressE
	.type	_ZN21MotorControlRSExample12moveProgressEmRNS_12MoveProgressE, @function
_ZN21MotorControlRSExample12moveProgressEmRNS_12MoveProgressE:
.LFB2386:
	entry	sp, 96
.LCFI194:
	l32r	a8, .LC2504
	mov.n	a11, a2
	l32i	a6, a8, 0
	movi.n	a2, 1
	movi.n	a8, 0
	movi.n	a9, 1
	movnez	a2, a8, a11
	moveqz	a8, a9, a6
	or	a2, a2, a8
	bnez.n	a2, .L5372
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a10
	beqz.n	a10, .L5370
	l8ui	a8, a10, 0
	bnei	a8, 4, .L5370
	addmi	a8, a10, 0x600
	l8ui	a2, a8, 232
	beqz.n	a2, .L5370
	movi.n	a12, 0x1b
	movi.n	a11, 0
	addi.n	a10, sp, 5
	call8	memset
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	movi	a8, 0x6f0
	add.n	a8, a7, a8
	addmi	a9, a8, 0x100
	addmi	a11, a8, 0x200
	addmi	a7, a7, 0x300
	l8ui	a5, a9, 243
	l8ui	a6, a7, 10
	l8ui	a15, a9, 244
	l8ui	a7, a9, 242
	l16ui	a14, a11, 98
	l16ui	a13, a11, 100
	l8ui	a12, a9, 237
	l8ui	a11, a9, 239
	l8ui	a9, a9, 240
	s32i	a10, sp, 56
	s32i	a9, sp, 52
	movi	a9, 0x4c0
	add.n	a9, a8, a9
	l32i	a4, a9, 4
	l32i	a10, a9, 0
	l32i	a9, a9, 8
	s32i	a11, sp, 48
	s32i	a9, sp, 24
	l32i	a9, a8, 396
	l32i	a8, a8, 392
	s32i	a9, sp, 36
	l32i	a9, sp, 56
	s32i	a8, sp, 32
	movi.n	a8, 1
	s32i	a10, sp, 16
	xor	a10, a9, a8
	l32i	a8, sp, 48
	s8i	a10, sp, 0
	s8i	a12, sp, 10
	s32i	a4, sp, 20
	s8i	a5, sp, 1
	s8i	a6, sp, 2
	s8i	a7, sp, 3
	s8i	a15, sp, 4
	s16i	a14, sp, 6
	s16i	a13, sp, 8
	s8i	a8, sp, 11
	l32i	a8, sp, 52
	movi.n	a12, 0x28
	mov.n	a11, sp
	mov.n	a10, a3
	s8i	a8, sp, 12
	call8	memcpy
	j	.L5370
.L5372:
	movi.n	a2, 0
.L5370:
	retw.n
.LFE2386:
	.size	_ZN21MotorControlRSExample12moveProgressEmRNS_12MoveProgressE, .-_ZN21MotorControlRSExample12moveProgressEmRNS_12MoveProgressE
	.literal_position
	.literal .LC2505, _ZN12_GLOBAL__N_13appE
	.literal .LC2506, 764504
	.align	4
	.global	_ZN21MotorControlRSExample21positionConfigurationERN14MotorControlRS10AxisConfigE
	.type	_ZN21MotorControlRSExample21positionConfigurationERN14MotorControlRS10AxisConfigE, @function
_ZN21MotorControlRSExample21positionConfigurationERN14MotorControlRS10AxisConfigE:
.LFB2390:
	entry	sp, 32
.LCFI195:
	l32r	a8, .LC2505
	mov.n	a10, a2
	l32i	a8, a8, 0
	movi.n	a2, 0
	beqz.n	a8, .L5380
	l32r	a11, .LC2506
	movi	a12, 0xb8
	add.n	a11, a8, a11
	call8	memcpy
	movi.n	a2, 1
.L5380:
	retw.n
.LFE2390:
	.size	_ZN21MotorControlRSExample21positionConfigurationERN14MotorControlRS10AxisConfigE, .-_ZN21MotorControlRSExample21positionConfigurationERN14MotorControlRS10AxisConfigE
	.literal_position
	.literal .LC2507, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample11releaseMoveEm
	.type	_ZN21MotorControlRSExample11releaseMoveEm, @function
_ZN21MotorControlRSExample11releaseMoveEm:
.LFB2391:
	entry	sp, 32
.LCFI196:
	l32r	a8, .LC2507
	movi.n	a10, 1
	l32i	a6, a8, 0
	movi.n	a9, 1
	movi.n	a8, 0
	movnez	a10, a8, a2
	moveqz	a8, a9, a6
	mov.n	a7, a2
	or	a2, a10, a8
	bnez.n	a2, .L5385
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L5384
	l8ui	a8, a10, 0
	bnei	a8, 4, .L5384
	addmi	a10, a10, 0x600
	l8ui	a2, a10, 232
	beqz.n	a2, .L5384
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_17releaseEPvm
	nsau	a2, a10
	srli	a2, a2, 5
	j	.L5384
.L5385:
	movi.n	a2, 0
.L5384:
	retw.n
.LFE2391:
	.size	_ZN21MotorControlRSExample11releaseMoveEm, .-_ZN21MotorControlRSExample11releaseMoveEm
	.section	.rodata.str1.1
.LC2509:
	.string	"original is not a programmatic move"
.LC2511:
	.string	"position interruption not admitted"
	.text
	.literal_position
	.literal .LC2508, .LC2094
	.literal .LC2510, .LC2509
	.literal .LC2512, .LC2511
	.literal .LC2513, .LC12
	.literal .LC2514, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample23submitPositionInterruptEmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm
	.type	_ZN21MotorControlRSExample23submitPositionInterruptEmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm, @function
_ZN21MotorControlRSExample23submitPositionInterruptEmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm:
.LFB2392:
	entry	sp, 64
.LCFI197:
	l32r	a8, .LC2514
	extui	a5, a5, 0, 8
	l32i	a7, a8, 0
	bnez.n	a7, .L5393
	movi.n	a8, 1
	l32r	a4, .LC2508
	s8i	a8, sp, 16
	movi.n	a3, 0
	j	.L5394
.L5393:
	mov.n	a11, a2
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L5395
	l8ui	a9, a10, 0
	bnei	a9, 4, .L5395
	addmi	a10, a10, 0x600
	l8ui	a9, a10, 232
	bnez.n	a9, .L5396
.L5395:
	movi.n	a8, 1
	l32r	a4, .LC2510
	s8i	a8, sp, 16
	movi.n	a3, 0
	j	.L5394
.L5396:
	mov.n	a13, a3
	s32i	a6, sp, 0
	mov.n	a15, a5
	mov.n	a14, a4
	mov.n	a12, a2
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_122admitPositionInterruptERNS_3AppEmmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm
	mov.n	a3, a10
	beqz.n	a10, .L5397
	movi.n	a8, 1
	l32r	a4, .LC2512
	s8i	a8, sp, 16
	j	.L5394
.L5397:
	l32r	a8, .LC2514
	l32i	a11, a6, 0
	l32i	a10, a8, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	addmi	a10, a10, 0x600
	movi.n	a8, 1
	l32r	a4, .LC2513
	s8i	a3, sp, 16
	s8i	a8, a10, 232
	movi.n	a3, 0
.L5394:
	l32i	a2, sp, 16
	movi.n	a5, 0
	retw.n
.LFE2392:
	.size	_ZN21MotorControlRSExample23submitPositionInterruptEmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm, .-_ZN21MotorControlRSExample23submitPositionInterruptEmRKN14MotorControlRS6ESS_RS15PositionCommandEmbRm
	.literal_position
	.literal .LC2515, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample14copyMoveResultEmRN14MotorControlRS6ESS_RS11MoveContextERNS_12MoveRelationE
	.type	_ZN21MotorControlRSExample14copyMoveResultEmRN14MotorControlRS6ESS_RS11MoveContextERNS_12MoveRelationE, @function
_ZN21MotorControlRSExample14copyMoveResultEmRN14MotorControlRS6ESS_RS11MoveContextERNS_12MoveRelationE:
.LFB2393:
	entry	sp, 32
.LCFI198:
	l32r	a8, .LC2515
	movi.n	a9, 0
	l32i	a10, a8, 0
	movi.n	a12, 1
	movi.n	a8, 1
	movnez	a8, a9, a2
	moveqz	a9, a12, a10
	mov.n	a11, a2
	or	a2, a8, a9
	bnez.n	a2, .L5403
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a10
	beqz.n	a10, .L5402
	l8ui	a8, a10, 0
	bnei	a8, 4, .L5402
	addmi	a8, a10, 0x600
	l8ui	a2, a8, 232
	beqz.n	a2, .L5402
	movi	a11, 0x6f0
	add.n	a11, a10, a11
	movi	a12, 0x4cc
	mov.n	a10, a3
	call8	memcpy
	movi.n	a11, -8
	addmi	a11, a11, 0xc00
	movi.n	a12, 9
	add.n	a11, a7, a11
	mov.n	a10, a4
	call8	memcpy
	j	.L5402
.L5403:
	movi.n	a2, 0
.L5402:
	retw.n
.LFE2393:
	.size	_ZN21MotorControlRSExample14copyMoveResultEmRN14MotorControlRS6ESS_RS11MoveContextERNS_12MoveRelationE, .-_ZN21MotorControlRSExample14copyMoveResultEmRN14MotorControlRS6ESS_RS11MoveContextERNS_12MoveRelationE
	.section	.rodata.str1.1
.LC2518:
	.string	"velocity parameter read not admitted"
	.text
	.literal_position
	.literal .LC2517, .LC2094
	.literal .LC2519, .LC2518
	.literal .LC2520, .LC12
	.literal .LC2521, _ZN12_GLOBAL__N_13appE
	.literal .LC2522, 764508
	.align	4
	.global	_ZN21MotorControlRSExample27submitVelocityParameterReadERm
	.type	_ZN21MotorControlRSExample27submitVelocityParameterReadERm, @function
_ZN21MotorControlRSExample27submitVelocityParameterReadERm:
.LFB2394:
	entry	sp, 48
.LCFI199:
	l32r	a4, .LC2521
	l32i	a10, a4, 0
	bnez.n	a10, .L5411
	movi.n	a8, 1
	l32r	a4, .LC2517
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5412
.L5411:
	l32r	a8, .LC2522
	mov.n	a14, a2
	add.n	a8, a10, a8
	l8ui	a12, a8, 0
	movi.n	a13, 3
	movi.n	a11, 0
	call8	_ZN12_GLOBAL__N_19typedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERm
	mov.n	a3, a10
	beqz.n	a10, .L5413
	movi.n	a8, 1
	l32r	a4, .LC2519
	s8i	a8, sp, 0
	j	.L5412
.L5413:
	l32i	a11, a2, 0
	l32i	a10, a4, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	movi.n	a8, 1
	l32r	a4, .LC2520
	s8i	a3, sp, 0
	s8i	a8, a10, 70
	movi.n	a3, 0
.L5412:
	l32i	a2, sp, 0
	movi.n	a5, 0
	retw.n
.LFE2394:
	.size	_ZN21MotorControlRSExample27submitVelocityParameterReadERm, .-_ZN21MotorControlRSExample27submitVelocityParameterReadERm
	.section	.rodata.str1.1
.LC2524:
	.string	"homing parameter read not admitted"
	.text
	.literal_position
	.literal .LC2523, .LC2094
	.literal .LC2525, .LC2524
	.literal .LC2526, .LC12
	.literal .LC2527, _ZN12_GLOBAL__N_13appE
	.literal .LC2528, 764508
	.align	4
	.global	_ZN21MotorControlRSExample25submitHomingParameterReadERm
	.type	_ZN21MotorControlRSExample25submitHomingParameterReadERm, @function
_ZN21MotorControlRSExample25submitHomingParameterReadERm:
.LFB2395:
	entry	sp, 48
.LCFI200:
	l32r	a4, .LC2527
	l32i	a10, a4, 0
	bnez.n	a10, .L5415
	movi.n	a8, 1
	l32r	a4, .LC2523
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5416
.L5415:
	l32r	a8, .LC2528
	mov.n	a14, a2
	add.n	a8, a10, a8
	l8ui	a12, a8, 0
	movi.n	a13, 4
	movi.n	a11, 0
	call8	_ZN12_GLOBAL__N_19typedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERm
	mov.n	a3, a10
	beqz.n	a10, .L5417
	movi.n	a8, 1
	l32r	a4, .LC2525
	s8i	a8, sp, 0
	j	.L5416
.L5417:
	l32i	a11, a2, 0
	l32i	a10, a4, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	movi.n	a8, 1
	l32r	a4, .LC2526
	s8i	a3, sp, 0
	s8i	a8, a10, 70
	movi.n	a3, 0
.L5416:
	l32i	a2, sp, 0
	movi.n	a5, 0
	retw.n
.LFE2395:
	.size	_ZN21MotorControlRSExample25submitHomingParameterReadERm, .-_ZN21MotorControlRSExample25submitHomingParameterReadERm
	.literal_position
	.literal .LC2529, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample14copyReadResultEmRN14MotorControlRS6ESS_RS11ReadContextE
	.type	_ZN21MotorControlRSExample14copyReadResultEmRN14MotorControlRS6ESS_RS11ReadContextE, @function
_ZN21MotorControlRSExample14copyReadResultEmRN14MotorControlRS6ESS_RS11ReadContextE:
.LFB2396:
	entry	sp, 32
.LCFI201:
	l32r	a8, .LC2529
	movi.n	a9, 0
	l32i	a10, a8, 0
	movi.n	a12, 1
	movi.n	a8, 1
	movnez	a8, a9, a2
	moveqz	a9, a12, a10
	mov.n	a11, a2
	or	a2, a8, a9
	bnez.n	a2, .L5420
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L5419
	l8ui	a8, a10, 0
	bnei	a8, 2, .L5419
	l8ui	a8, a10, 68
	bnez.n	a8, .L5419
	addi	a11, a10, 80
	movi	a12, 0x2b8
	mov.n	a10, a3
	call8	memcpy
	movi.n	a2, 1
	j	.L5419
.L5420:
	movi.n	a2, 0
.L5419:
	retw.n
.LFE2396:
	.size	_ZN21MotorControlRSExample14copyReadResultEmRN14MotorControlRS6ESS_RS11ReadContextE, .-_ZN21MotorControlRSExample14copyReadResultEmRN14MotorControlRS6ESS_RS11ReadContextE
	.section	.rodata.str1.1
.LC2533:
	.string	"position start-speed setting not admitted"
	.text
	.literal_position
	.literal .LC2530, _ZN12_GLOBAL__N_13appE
	.literal .LC2531, .LC2094
	.literal .LC2532, 764508
	.literal .LC2534, .LC2533
	.literal .LC2535, .LC12
	.align	4
	.global	_ZN21MotorControlRSExample24submitPositionStartSpeedEmRm
	.type	_ZN21MotorControlRSExample24submitPositionStartSpeedEmRm, @function
_ZN21MotorControlRSExample24submitPositionStartSpeedEmRm:
.LFB2397:
	entry	sp, 192
.LCFI202:
	l32r	a5, .LC2530
	l32i	a8, a5, 0
	bnez.n	a8, .L5425
	movi.n	a9, 1
	s32i	a8, sp, 140
	s8i	a9, sp, 136
	l32r	a8, .LC2531
	j	.L5430
.L5425:
	movi	a12, 0x88
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi.n	a8, 7
	s16i	a8, sp, 14
	movi	a8, 0x190
	s16i	a8, sp, 18
	movi.n	a6, 1
	movi.n	a8, 2
	mov.n	a11, a2
	mov.n	a10, sp
	s8i	a6, sp, 66
	s16i	a8, sp, 88
	call8	_ZN14MotorControlRS6ESS_RS25preparePositionStartSpeedERNS0_13DriverRequestEm
	s32i	a10, sp, 148
	s32i	a11, sp, 152
	s32i	a12, sp, 156
	extui	a10, a10, 0, 8
	beqz.n	a10, .L5428
	movi	a9, 0x94
	add.n	a9, sp, a9
	l32i	a11, a9, 0
	l32i	a10, a9, 4
	movi	a8, 0x88
	add.n	a8, sp, a8
	s32i	a11, a8, 0
	s32i	a10, a8, 4
	s32i	a12, a8, 8
	j	.L5426
.L5428:
	l32i	a10, a5, 0
	l32r	a8, .LC2532
	mov.n	a15, a3
	add.n	a8, a10, a8
	l8ui	a12, a8, 0
	mov.n	a14, sp
	movi.n	a13, 1
	movi.n	a11, 0
	call8	_ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm
	mov.n	a7, a10
	beqz.n	a10, .L5429
	l32r	a8, .LC2534
	s8i	a6, sp, 136
	s32i	a10, sp, 140
	j	.L5430
.L5429:
	l32i	a11, a3, 0
	l32i	a10, a5, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	addmi	a10, a10, 0x1f00
	l32r	a8, .LC2535
	s8i	a6, a10, 89
	s8i	a7, sp, 136
	s32i	a7, sp, 140
.L5430:
	s32i	a8, sp, 144
.L5426:
	l32i	a2, sp, 136
	l32i	a3, sp, 140
	l32i	a4, sp, 144
	movi.n	a5, 0
	retw.n
.LFE2397:
	.size	_ZN21MotorControlRSExample24submitPositionStartSpeedEmRm, .-_ZN21MotorControlRSExample24submitPositionStartSpeedEmRm
	.section	.rodata.str1.1
.LC2539:
	.string	"homing auxiliary setting not admitted"
	.text
	.literal_position
	.literal .LC2536, _ZN12_GLOBAL__N_13appE
	.literal .LC2537, .LC2094
	.literal .LC2538, 764508
	.literal .LC2540, .LC2539
	.literal .LC2541, .LC12
	.align	4
	.global	_ZN21MotorControlRSExample21submitHomingAuxiliaryEN14MotorControlRS6ESS_RS15HomingAuxiliaryERm
	.type	_ZN21MotorControlRSExample21submitHomingAuxiliaryEN14MotorControlRS6ESS_RS15HomingAuxiliaryERm, @function
_ZN21MotorControlRSExample21submitHomingAuxiliaryEN14MotorControlRS6ESS_RS15HomingAuxiliaryERm:
.LFB2398:
	entry	sp, 192
.LCFI203:
	l32r	a5, .LC2536
	extui	a2, a2, 0, 16
	l32i	a8, a5, 0
	bnez.n	a8, .L5432
	movi.n	a9, 1
	s32i	a8, sp, 140
	s8i	a9, sp, 136
	l32r	a8, .LC2537
	j	.L5437
.L5432:
	movi	a12, 0x88
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi.n	a8, 7
	s16i	a8, sp, 14
	movi	a8, 0x190
	s16i	a8, sp, 18
	movi.n	a6, 1
	movi.n	a8, 2
	mov.n	a11, a2
	mov.n	a10, sp
	s8i	a6, sp, 66
	s16i	a8, sp, 88
	call8	_ZN14MotorControlRS6ESS_RS22prepareHomingAuxiliaryERNS0_13DriverRequestENS0_15HomingAuxiliaryE
	s32i	a10, sp, 148
	s32i	a11, sp, 152
	s32i	a12, sp, 156
	extui	a10, a10, 0, 8
	beqz.n	a10, .L5435
	movi	a9, 0x94
	add.n	a9, sp, a9
	l32i	a11, a9, 0
	l32i	a10, a9, 4
	movi	a8, 0x88
	add.n	a8, sp, a8
	s32i	a11, a8, 0
	s32i	a10, a8, 4
	s32i	a12, a8, 8
	j	.L5433
.L5435:
	l32i	a10, a5, 0
	l32r	a8, .LC2538
	mov.n	a15, a3
	add.n	a8, a10, a8
	l8ui	a12, a8, 0
	mov.n	a14, sp
	movi.n	a13, 1
	movi.n	a11, 0
	call8	_ZN12_GLOBAL__N_111startDriverEPvmhN14MotorControlRS6ESS_RS10DriverKindERKNS2_13DriverRequestERm
	mov.n	a7, a10
	beqz.n	a10, .L5436
	l32r	a8, .LC2540
	s8i	a6, sp, 136
	s32i	a10, sp, 140
	j	.L5437
.L5436:
	l32i	a11, a3, 0
	l32i	a10, a5, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	addmi	a10, a10, 0x1f00
	l32r	a8, .LC2541
	s8i	a6, a10, 89
	s8i	a7, sp, 136
	s32i	a7, sp, 140
.L5437:
	s32i	a8, sp, 144
.L5433:
	l32i	a2, sp, 136
	l32i	a3, sp, 140
	l32i	a4, sp, 144
	movi.n	a5, 0
	retw.n
.LFE2398:
	.size	_ZN21MotorControlRSExample21submitHomingAuxiliaryEN14MotorControlRS6ESS_RS15HomingAuxiliaryERm, .-_ZN21MotorControlRSExample21submitHomingAuxiliaryEN14MotorControlRS6ESS_RS15HomingAuxiliaryERm
	.section	.rodata.str1.1
.LC2543:
	.string	"start-speed qualification requires idle application"
.LC2545:
	.string	"start-speed relation requires exact current binding, raw word and qualification age"
	.text
	.literal_position
	.literal .LC2542, .LC2094
	.literal .LC2544, .LC2543
	.literal .LC2546, .LC2545
	.literal .LC2547, .LC12
	.literal .LC2548, _ZN12_GLOBAL__N_13appE
	.literal .LC2550, 53807
	.literal .LC2551, 45698
	.literal .LC2552, _ZN12_GLOBAL__N_14uartE
	.literal .LC2553, 764504
	.literal .LC2554, 764516
	.literal .LC2560, 770856
	.literal .LC2561, 771920
	.literal .LC2562, 771912
	.align	4
	.global	_ZN21MotorControlRSExample33installPositionStartSpeedRelationERKNS_26PositionStartSpeedRelationE
	.type	_ZN21MotorControlRSExample33installPositionStartSpeedRelationERKNS_26PositionStartSpeedRelationE, @function
_ZN21MotorControlRSExample33installPositionStartSpeedRelationERKNS_26PositionStartSpeedRelationE:
.LFB2399:
	entry	sp, 64
.LCFI204:
	l32r	a8, .LC2548
	l32i	a7, a8, 0
	bnez.n	a7, .L5439
	movi.n	a8, 1
	l32r	a4, .LC2542
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5440
.L5439:
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a7, a8
	l32i	a9, a8, 52
	beqi	a9, -1, .L5441
.L5442:
	movi.n	a8, 1
	l32r	a4, .LC2544
	s8i	a8, sp, 0
	movi.n	a3, 1
	j	.L5440
.L5441:
	l32i	a9, a8, 48
	bnez.n	a9, .L5442
	l8ui	a9, a8, 60
	beqi	a9, 1, .L5442
	l8ui	a9, a8, 137
	bnez.n	a9, .L5442
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	or	a9, a9, a8
	bnez.n	a9, .L5442
	l32r	a8, .LC2550
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5442
	l32r	a8, .LC2551
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5442
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L5442
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L5442
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	bnez.n	a10, .L5442
	l32r	a10, .LC2552
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32i	a8, a2, 0
	mov.n	a5, a10
	mov.n	a6, a11
	beqz.n	a8, .L5443
	l32r	a11, .LC2553
	mov.n	a10, a2
	add.n	a11, a7, a11
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5443
	l32r	a8, .LC2554
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L5443
	l32i	a9, a2, 12
	bne	a8, a9, .L5443
	movi	a8, 0xb8
	l16ui	a11, a2, 16
	addmi	a8, a8, 0xb00
	bltu	a8, a11, .L5443
	l16ui	a8, a2, 18
	movi	a9, 0xb7
	addi.n	a8, a8, -1
	extui	a8, a8, 0, 16
	addmi	a9, a9, 0xb00
	bltu	a9, a8, .L5443
	l32i	a8, a2, 28
	l32i	a9, a2, 24
	bltu	a6, a8, .L5443
	bne	a8, a6, .L5454
	bltu	a5, a9, .L5443
.L5454:
	l32i	a10, a7, 0
	movi	a4, 0x3e8
	mull	a3, a4, a10
	muluh	a4, a4, a10
	or	a12, a3, a4
	beqz.n	a12, .L5445
	sub	a8, a6, a8
	bgeu	a5, a9, .L5447
	addi.n	a8, a8, -1
.L5447:
	sub	a9, a5, a9
	bltu	a8, a4, .L5445
	bne	a4, a8, .L5443
	bgeu	a9, a3, .L5443
.L5445:
	mov.n	a10, a7
	s32i	a12, sp, 20
	s32i	a11, sp, 16
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE
	beqz.n	a10, .L5443
	l32r	a9, .LC2560
	add.n	a8, a7, a9
	l8ui	a10, a8, 3
	beqz.n	a10, .L5443
	l8ui	a10, a8, 0
	bnez.n	a10, .L5443
	addmi	a10, a8, 0x100
	l8ui	a10, a10, 12
	beqz.n	a10, .L5443
	l32i	a10, a8, 200
	l32i	a8, a8, 204
	bltu	a6, a8, .L5443
	l32i	a11, sp, 16
	l32i	a12, sp, 20
	bne	a8, a6, .L5455
	bltu	a5, a10, .L5443
.L5455:
	beqz.n	a12, .L5450
	sub	a6, a6, a8
	bgeu	a5, a10, .L5452
	addi.n	a6, a6, -1
.L5452:
	sub	a5, a5, a10
	bltu	a6, a4, .L5450
	bne	a4, a6, .L5443
	bgeu	a5, a3, .L5443
.L5450:
	add.n	a9, a7, a9
	l16ui	a8, a9, 52
	bne	a8, a11, .L5443
	l32r	a10, .LC2561
	movi.n	a12, 0x20
	add.n	a10, a7, a10
	mov.n	a11, a2
	call8	memcpy
	l32r	a8, .LC2562
	l32r	a4, .LC2547
	add.n	a7, a7, a8
	movi.n	a8, 1
	s8i	a8, a7, 0
	movi.n	a8, 0
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5440
.L5443:
	movi.n	a8, 1
	l32r	a4, .LC2546
	s8i	a8, sp, 0
	movi.n	a3, 0
.L5440:
	l32i	a2, sp, 0
	movi.n	a5, 0
	retw.n
.LFE2399:
	.size	_ZN21MotorControlRSExample33installPositionStartSpeedRelationERKNS_26PositionStartSpeedRelationE, .-_ZN21MotorControlRSExample33installPositionStartSpeedRelationERKNS_26PositionStartSpeedRelationE
	.section	.rodata.str1.1
.LC2564:
	.string	"velocity qualification requires idle application"
.LC2566:
	.string	"velocity qualification requires stated facts and matching checked velocity parameters"
	.text
	.literal_position
	.literal .LC2563, .LC2094
	.literal .LC2565, .LC2564
	.literal .LC2567, .LC2566
	.literal .LC2568, .LC12
	.literal .LC2569, _ZN12_GLOBAL__N_13appE
	.literal .LC2570, 764504
	.literal .LC2571, 764516
	.literal .LC2572, 772128
	.literal .LC2573, 772072
	.align	4
	.global	_ZN21MotorControlRSExample28installVelocityQualificationERKN14MotorControlRS6ESS_RS21VelocityPrerequisitesE
	.type	_ZN21MotorControlRSExample28installVelocityQualificationERKN14MotorControlRS6ESS_RS21VelocityPrerequisitesE, @function
_ZN21MotorControlRSExample28installVelocityQualificationERKN14MotorControlRS6ESS_RS21VelocityPrerequisitesE:
.LFB2400:
	entry	sp, 48
.LCFI205:
	l32r	a8, .LC2569
	l32i	a6, a8, 0
	bnez.n	a6, .L5484
	movi.n	a8, 1
	l32r	a4, .LC2563
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5485
.L5484:
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_117qualificationIdleERKNS_3AppE
	bnez.n	a10, .L5486
	movi.n	a8, 1
	l32r	a4, .LC2565
	s8i	a8, sp, 0
	movi.n	a3, 1
	j	.L5485
.L5486:
	l32i	a8, a2, 0
	beqz.n	a8, .L5487
	l32r	a4, .LC2570
	mov.n	a10, a2
	add.n	a4, a6, a4
	mov.n	a11, a4
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5487
	l32r	a8, .LC2571
	add.n	a8, a6, a8
	l32i	a3, a8, 0
	beqz.n	a3, .L5487
	l32i	a8, a2, 12
	bne	a3, a8, .L5487
	l8ui	a8, a2, 16
	beqz.n	a8, .L5487
	l8ui	a8, a2, 18
	beqz.n	a8, .L5487
	l8ui	a8, a2, 19
	beqz.n	a8, .L5487
	l8ui	a8, a2, 20
	beqz.n	a8, .L5487
	l32r	a7, .LC2572
	add.n	a7, a6, a7
	l32i	a8, a7, 12
	beqz.n	a8, .L5487
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5487
	l32i	a8, a7, 16
	bne	a3, a8, .L5487
	l16ui	a9, a2, 22
	l16ui	a8, a7, 22
	bne	a8, a9, .L5487
	l16ui	a10, a7, 24
	l16ui	a11, a2, 24
	movi.n	a9, 1
	sub	a10, a10, a11
	movi	a7, 0x7d0
	moveqz	a9, a10, a10
	saltu	a8, a7, a8
	or	a8, a9, a8
	bnez.n	a8, .L5487
	saltu	a7, a7, a11
	beqz.n	a7, .L5488
.L5487:
	movi.n	a8, 1
	l32r	a4, .LC2567
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5485
.L5488:
	l32r	a10, .LC2573
	movi.n	a12, 0x38
	mov.n	a11, a2
	add.n	a10, a6, a10
	call8	memcpy
	l32r	a4, .LC2568
	s8i	a7, sp, 0
	movi.n	a3, 0
.L5485:
	l32i	a2, sp, 0
	movi.n	a5, 0
	retw.n
.LFE2400:
	.size	_ZN21MotorControlRSExample28installVelocityQualificationERKN14MotorControlRS6ESS_RS21VelocityPrerequisitesE, .-_ZN21MotorControlRSExample28installVelocityQualificationERKN14MotorControlRS6ESS_RS21VelocityPrerequisitesE
	.literal_position
	.literal .LC2574, .LC2094
	.literal .LC2575, .LC12
	.literal .LC2576, _ZN12_GLOBAL__N_13appE
	.literal .LC2579, 772072
	.align	4
	.global	_ZN21MotorControlRSExample27revokeVelocityQualificationEv
	.type	_ZN21MotorControlRSExample27revokeVelocityQualificationEv, @function
_ZN21MotorControlRSExample27revokeVelocityQualificationEv:
.LFB2401:
	entry	sp, 96
.LCFI206:
	l32r	a8, .LC2576
	l32i	a4, a8, 0
	bnez.n	a4, .L5518
	movi.n	a8, 1
	l32r	a4, .LC2574
	s8i	a8, sp, 0
	j	.L5519
.L5518:
	movi.n	a12, 0x38
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	movi.n	a8, 0x48
	addmi	a8, a8, -0xc00
	l32r	a10, .LC2579
	s16i	a8, sp, 26
	movi	a8, 0xb8
	addmi	a8, a8, 0xb00
	s16i	a8, sp, 28
	add.n	a10, a4, a10
	movi.n	a12, 0x38
	mov.n	a11, sp
	call8	memcpy
	movi.n	a8, 0
	l32r	a4, .LC2575
	s8i	a8, sp, 0
.L5519:
	l32i	a2, sp, 0
	movi.n	a3, 0
	movi.n	a5, 0
	retw.n
.LFE2401:
	.size	_ZN21MotorControlRSExample27revokeVelocityQualificationEv, .-_ZN21MotorControlRSExample27revokeVelocityQualificationEv
	.section	.rodata.str1.1
.LC2581:
	.string	"position-clear qualification requires idle application"
	.text
	.literal_position
	.literal .LC2580, .LC2094
	.literal .LC2582, .LC2581
	.literal .LC2583, .LC12
	.literal .LC2584, _ZN12_GLOBAL__N_13appE
	.literal .LC2585, 764788
	.align	4
	.global	_ZN21MotorControlRSExample33installPositionClearQualificationEv
	.type	_ZN21MotorControlRSExample33installPositionClearQualificationEv, @function
_ZN21MotorControlRSExample33installPositionClearQualificationEv:
.LFB2402:
	entry	sp, 48
.LCFI207:
	l32r	a4, .LC2584
	l32i	a10, a4, 0
	bnez.n	a10, .L5522
	movi.n	a8, 1
	l32r	a4, .LC2580
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5523
.L5522:
	call8	_ZN12_GLOBAL__N_117qualificationIdleERKNS_3AppE
	bnez.n	a10, .L5524
	movi.n	a8, 1
	l32r	a4, .LC2582
	s8i	a8, sp, 0
	movi.n	a3, 1
	j	.L5523
.L5524:
	l32i	a8, a4, 0
	l32r	a9, .LC2585
	l32r	a4, .LC2583
	add.n	a8, a8, a9
	movi.n	a9, 1
	s8i	a9, a8, 0
	movi.n	a8, 0
	s8i	a8, sp, 0
	movi.n	a3, 0
.L5523:
	l32i	a2, sp, 0
	movi.n	a5, 0
	retw.n
.LFE2402:
	.size	_ZN21MotorControlRSExample33installPositionClearQualificationEv, .-_ZN21MotorControlRSExample33installPositionClearQualificationEv
	.literal_position
	.literal .LC2586, .LC2094
	.literal .LC2587, .LC12
	.literal .LC2588, _ZN12_GLOBAL__N_13appE
	.literal .LC2589, 764788
	.align	4
	.global	_ZN21MotorControlRSExample32revokePositionClearQualificationEv
	.type	_ZN21MotorControlRSExample32revokePositionClearQualificationEv, @function
_ZN21MotorControlRSExample32revokePositionClearQualificationEv:
.LFB2403:
	entry	sp, 48
.LCFI208:
	l32r	a8, .LC2588
	l32i	a8, a8, 0
	bnez.n	a8, .L5526
	movi.n	a8, 1
	l32r	a4, .LC2586
	s8i	a8, sp, 0
	j	.L5527
.L5526:
	l32r	a9, .LC2589
	l32r	a4, .LC2587
	add.n	a8, a8, a9
	movi.n	a9, 0
	s8i	a9, a8, 0
	s8i	a9, sp, 0
.L5527:
	l32i	a2, sp, 0
	movi.n	a3, 0
	movi.n	a5, 0
	retw.n
.LFE2403:
	.size	_ZN21MotorControlRSExample32revokePositionClearQualificationEv, .-_ZN21MotorControlRSExample32revokePositionClearQualificationEv
	.literal_position
	.literal .LC2590, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample18copySettingsResultEmRN14MotorControlRS6ESS_RS13DriverContextE
	.type	_ZN21MotorControlRSExample18copySettingsResultEmRN14MotorControlRS6ESS_RS13DriverContextE, @function
_ZN21MotorControlRSExample18copySettingsResultEmRN14MotorControlRS6ESS_RS13DriverContextE:
.LFB2404:
	entry	sp, 32
.LCFI209:
	l32r	a8, .LC2590
	movi.n	a9, 0
	l32i	a10, a8, 0
	movi.n	a12, 1
	movi.n	a8, 1
	movnez	a8, a9, a2
	moveqz	a9, a12, a10
	mov.n	a11, a2
	or	a2, a8, a9
	bnez.n	a2, .L5530
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L5529
	l8ui	a8, a10, 0
	bnei	a8, 6, .L5529
	addmi	a10, a10, 0x1000
	movi	a12, 0x9c
	movi	a11, 0xb8
	add.n	a11, a10, a11
	addmi	a12, a12, 0xe00
	mov.n	a10, a3
	call8	memcpy
	movi.n	a2, 1
	j	.L5529
.L5530:
	movi.n	a2, 0
.L5529:
	retw.n
.LFE2404:
	.size	_ZN21MotorControlRSExample18copySettingsResultEmRN14MotorControlRS6ESS_RS13DriverContextE, .-_ZN21MotorControlRSExample18copySettingsResultEmRN14MotorControlRS6ESS_RS13DriverContextE
	.section	.rodata.str1.1
.LC2593:
	.string	"home qualification requires idle application"
.LC2595:
	.string	"home qualification requires exact supplied facts and checked configuration/state/parameters"
	.text
	.literal_position
	.literal .LC2592, .LC2094
	.literal .LC2594, .LC2593
	.literal .LC2596, .LC2595
	.literal .LC2597, .LC12
	.literal .LC2598, _ZN12_GLOBAL__N_13appE
	.literal .LC2600, 53807
	.literal .LC2601, 45698
	.literal .LC2602, 45697
	.literal .LC2603, _ZN12_GLOBAL__N_14uartE
	.literal .LC2604, 771952
	.align	4
	.global	_ZN21MotorControlRSExample24installHomeQualificationERKN14MotorControlRS6ESS_RS17HomePrerequisitesE
	.type	_ZN21MotorControlRSExample24installHomeQualificationERKN14MotorControlRS6ESS_RS17HomePrerequisitesE, @function
_ZN21MotorControlRSExample24installHomeQualificationERKN14MotorControlRS6ESS_RS17HomePrerequisitesE:
.LFB2405:
	entry	sp, 176
.LCFI210:
	l32r	a8, .LC2598
	l32i	a7, a8, 0
	bnez.n	a7, .L5535
	movi.n	a8, 1
	l32r	a4, .LC2592
	s8i	a8, sp, 120
	movi.n	a3, 0
	j	.L5536
.L5535:
	movi	a8, 0x7f7
	slli	a8, a8, 5
	add.n	a8, a7, a8
	l32i	a9, a8, 52
	beqi	a9, -1, .L5537
.L5538:
	movi.n	a8, 1
	l32r	a4, .LC2594
	s8i	a8, sp, 120
	movi.n	a3, 1
	j	.L5536
.L5537:
	l32i	a9, a8, 48
	bnez.n	a9, .L5538
	l8ui	a9, a8, 60
	beqi	a9, 1, .L5538
	l8ui	a9, a8, 137
	bnez.n	a9, .L5538
	l32i	a9, a8, 152
	l32i	a8, a8, 156
	or	a9, a9, a8
	bnez.n	a9, .L5538
	l32r	a8, .LC2600
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5538
	l32r	a8, .LC2601
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5538
	l32r	a8, .LC2602
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5538
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L5538
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_17readingERKNS_3AppE
	bnez.n	a10, .L5538
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_16actingERKNS_3AppE
	mov.n	a4, a10
	bnez.n	a10, .L5538
	movi	a12, 0x78
	mov.n	a11, a2
	mov.n	a10, sp
	call8	memcpy
	l32r	a10, .LC2603
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a7
	mov.n	a11, sp
	call8	_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy
	bnez.n	a10, .L5539
	movi.n	a8, 1
	l32r	a4, .LC2596
	s8i	a8, sp, 120
	movi.n	a3, 0
	j	.L5536
.L5539:
	l32r	a10, .LC2604
	movi	a12, 0x78
	mov.n	a11, a2
	add.n	a10, a7, a10
	call8	memcpy
	s8i	a4, sp, 120
	l32r	a4, .LC2597
	movi.n	a3, 0
.L5536:
	l32i	a2, sp, 120
	movi.n	a5, 0
	retw.n
.LFE2405:
	.size	_ZN21MotorControlRSExample24installHomeQualificationERKN14MotorControlRS6ESS_RS17HomePrerequisitesE, .-_ZN21MotorControlRSExample24installHomeQualificationERKN14MotorControlRS6ESS_RS17HomePrerequisitesE
	.literal_position
	.literal .LC2605, _ZN12_GLOBAL__N_13appE
	.literal .LC2606, 771952
	.align	4
	.global	_ZN21MotorControlRSExample24inspectHomeQualificationERN14MotorControlRS6ESS_RS17HomePrerequisitesERb
	.type	_ZN21MotorControlRSExample24inspectHomeQualificationERN14MotorControlRS6ESS_RS17HomePrerequisitesERb, @function
_ZN21MotorControlRSExample24inspectHomeQualificationERN14MotorControlRS6ESS_RS17HomePrerequisitesERb:
.LFB2406:
	entry	sp, 160
.LCFI211:
	l32r	a4, .LC2605
	mov.n	a7, a2
	l32i	a6, a4, 0
	movi.n	a2, 0
	beqz.n	a6, .L5544
	l32r	a5, .LC2606
	add.n	a11, a6, a5
	l32i	a8, a11, 0
	beqz.n	a8, .L5544
	movi	a12, 0x78
	mov.n	a10, sp
	call8	memcpy
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a6
	mov.n	a11, sp
	call8	_ZN12_GLOBAL__N_113homeReadinessERKNS_3AppERN14MotorControlRS6ESS_RS17HomePrerequisitesEy
	l32i	a11, a4, 0
	s8i	a10, a3, 0
	movi	a12, 0x78
	add.n	a11, a11, a5
	mov.n	a10, a7
	call8	memcpy
	movi.n	a2, 1
.L5544:
	retw.n
.LFE2406:
	.size	_ZN21MotorControlRSExample24inspectHomeQualificationERN14MotorControlRS6ESS_RS17HomePrerequisitesERb, .-_ZN21MotorControlRSExample24inspectHomeQualificationERN14MotorControlRS6ESS_RS17HomePrerequisitesERb
	.literal_position
	.literal .LC2607, .LC2094
	.literal .LC2608, .LC12
	.literal .LC2609, _ZN12_GLOBAL__N_13appE
	.literal .LC2610, 771952
	.literal .LC2611, _ZN12_GLOBAL__N_14uartE
	.literal .LC2612, 101032
	.literal .LC2613, 625352
	.literal .LC2618, 764714
	.align	4
	.global	_ZN21MotorControlRSExample23revokeHomeQualificationEv
	.type	_ZN21MotorControlRSExample23revokeHomeQualificationEv, @function
_ZN21MotorControlRSExample23revokeHomeQualificationEv:
.LFB2407:
	entry	sp, 176
.LCFI212:
	l32r	a8, .LC2609
	l32i	a7, a8, 0
	bnez.n	a7, .L5550
	movi.n	a8, 1
	l32r	a4, .LC2607
	s8i	a8, sp, 0
	j	.L5551
.L5550:
	movi	a12, 0x78
	movi.n	a11, 0
	mov.n	a10, sp
	call8	memset
	l32r	a10, .LC2610
	movi.n	a8, 0x23
	s16i	a8, sp, 20
	movi.n	a8, 7
	s16i	a8, sp, 30
	movi	a12, 0x78
	mov.n	a11, sp
	add.n	a10, a7, a10
	call8	memcpy
	l32r	a10, .LC2611
	movi.n	a3, -0x14
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32r	a8, .LC2612
	l32r	a6, .LC2613
	movi	a9, 0x7f7
	movi.n	a2, 0x40
	slli	a9, a9, 5
	add.n	a5, a7, a8
	add.n	a6, a7, a6
	s32i	a10, sp, 128
	s32i	a11, sp, 132
	addmi	a3, a3, 0x2000
	addmi	a2, a2, 0x1f00
	add.n	a7, a7, a9
	j	.L5553
.L5557:
	addi	a9, a5, -32
	l8ui	a9, a9, 0
	bnei	a9, 7, .L5555
	add.n	a9, a5, a3
	l8ui	a4, a9, 0
	bnei	a4, 1, .L5555
	add.n	a10, a5, a2
	call8	_ZN14MotorControlRS6ESS_RS10revokeHomeERNS0_11HomeContextE
	l32i	a9, a5, 0
	s8i	a4, a5, 39
	beqz.n	a9, .L5555
	l32i	a12, sp, 128
	l32i	a13, sp, 132
	mov.n	a11, a5
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L5555:
	movi.n	a9, 0x50
	addmi	a9, a9, 0x2300
	add.n	a5, a5, a9
.L5553:
	bne	a5, a6, .L5557
	l32r	a8, .LC2609
	l32r	a9, .LC2618
	l32i	a8, a8, 0
	l32r	a4, .LC2608
	add.n	a8, a8, a9
	movi.n	a9, 0
	s8i	a9, a8, 0
	s8i	a9, sp, 0
.L5551:
	l32i	a2, sp, 0
	movi.n	a3, 0
	movi.n	a5, 0
	retw.n
.LFE2407:
	.size	_ZN21MotorControlRSExample23revokeHomeQualificationEv, .-_ZN21MotorControlRSExample23revokeHomeQualificationEv
	.section	.rodata.str1.1
.LC2619:
	.string	"read state"
.LC2621:
	.string	"read config"
.LC2623:
	.string	"home read"
.LC2625:
	.string	"axis_configuration_unknown"
.LC2627:
	.string	"reads_required"
.LC2629:
	.string	"stored_auxiliary_differs"
.LC2631:
	.string	"stored_offset_nonzero"
.LC2633:
	.string	"drive_not_ready"
.LC2635:
	.string	"velocity read"
.LC2637:
	.string	"stored_ramp_out_of_range"
.LC2639:
	.string	"motion-profile read"
.LC2641:
	.string	"stored_word_differs"
	.text
	.literal_position
	.literal .LC2620, .LC2619
	.literal .LC2622, .LC2621
	.literal .LC2624, .LC2623
	.literal .LC2626, .LC2625
	.literal .LC2628, .LC2627
	.literal .LC2630, .LC2629
	.literal .LC2632, .LC2631
	.literal .LC2634, .LC2633
	.literal .LC2636, .LC2635
	.literal .LC2638, .LC2637
	.literal .LC2640, .LC2639
	.literal .LC2642, .LC2641
	.literal .LC2643, 764516
	.literal .LC2644, _ZN12_GLOBAL__N_14uartE
	.literal .LC2645, 757960
	.literal .LC2646, 764504
	.literal .LC2648, 758013
	.literal .LC2649, 758792
	.literal .LC2650, 625320
	.literal .LC2651, 625608
	.literal .LC2652, 772280
	.literal .LC2653, 757992
	.literal .LC2654, 757994
	.literal .LC2655, 762568
	.literal .LC2657, 757972
	.literal .LC2658, 772128
	.literal .LC2661, 770856
	.literal .LC2662, 758192
	.align	4
	.type	_ZN12_GLOBAL__N_120qualificationCommandEPvRKN21MotorControlRSExample5Probe20QualificationCommandE, @function
_ZN12_GLOBAL__N_120qualificationCommandEPvRKN21MotorControlRSExample5Probe20QualificationCommandE:
.LFB2367:
	entry	sp, 224
.LCFI213:
	l8ui	a7, a3, 1
	mov.n	a6, a2
	beqz.n	a7, .L5562
	l8ui	a8, a3, 0
	bnez.n	a8, .L5563
	call8	_ZN21MotorControlRSExample23revokeHomeQualificationEv
	j	.L5682
.L5563:
	bnei	a8, 1, .L5565
	call8	_ZN21MotorControlRSExample27revokeVelocityQualificationEv
.L5682:
	extui	a10, a10, 0, 8
	call8	_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0
	s32i	a10, sp, 0
.L5683:
	s32i	a11, sp, 4
	s32i	a12, sp, 8
	j	.L5564
.L5565:
	call8	_ZN21MotorControlRSExample32revokePositionClearQualificationEv
	j	.L5682
.L5562:
	movi.n	a12, 1
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	beqz.n	a10, .L5566
	movi.n	a8, 0xc
	s8i	a8, sp, 0
	s32i	a7, sp, 4
	s32i	a7, sp, 8
	j	.L5564
.L5566:
	s32i	a10, sp, 160
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_117qualificationIdleERKNS_3AppE
	l32i	a9, sp, 160
	bnez.n	a10, .L5567
	movi.n	a8, 1
	s8i	a8, sp, 0
	s32i	a10, sp, 4
	s32i	a10, sp, 8
	j	.L5564
.L5567:
	l8ui	a2, a3, 0
	beqi	a2, 2, .L5568
	bgeui	a2, 3, .L5569
	l32r	a4, .LC2643
	bnez.n	a2, .L5675
	j	.L5570
.L5569:
	beqi	a2, 3, .L5572
	j	.L5676
.L5570:
	add.n	a10, a6, a4
	l32i	a10, a10, 0
	beqz.n	a10, .L5606
	l32r	a10, .LC2644
	s32i	a9, sp, 172
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a5, a10
	s32i	a10, sp, 136
	l32i	a10, a6, 0
	movi	a7, 0x3e8
	mull	a8, a7, a10
	muluh	a7, a7, a10
	movi	a10, 0x88
	add.n	a10, sp, a10
	s32i	a10, sp, 0
	addi	a10, sp, 120
	s32i	a10, sp, 4
	l32r	a10, .LC2645
	s32i	a8, sp, 164
	add.n	a10, a6, a10
	s32i	a8, sp, 120
	l32i	a8, a10, 12
	s32i	a11, sp, 160
	s32i	a11, sp, 140
	s32i	a7, sp, 124
	s32i	a8, sp, 168
	l32i	a9, sp, 172
	beqz.n	a8, .L5575
	l32r	a11, .LC2646
	add.n	a11, a6, a11
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	mov.n	a9, a10
	j	.L5575
.L5578:
	l8ui	a9, a10, 0
	beqz.n	a9, .L5576
	add.n	a9, a10, a11
	l8ui	a9, a9, 0
	l8ui	a12, a10, 33
	sub	a9, a9, a12
	nsau	a9, a9
	srli	a9, a9, 5
.L5576:
	addi.n	a14, a2, 1
	extui	a2, a14, 0, 8
	addi.n	a10, a10, 1
	j	.L5577
.L5575:
	l32r	a10, .LC2648
	movi	a11, 0xcb
	add.n	a10, a6, a10
	addmi	a11, a11, 0x1100
.L5577:
	beqi	a2, 4, .L5643
	bnez.n	a9, .L5578
.L5643:
	l32r	a11, .LC2662
	l32r	a12, .LC2649
	add.n	a2, a6, a11
	add.n	a12, a6, a12
	j	.L5580
.L5582:
	beqz.n	a9, .L5581
	mov.n	a11, a2
	mov.n	a10, sp
	s32i	a12, sp, 172
	call8	_ZZN12_GLOBAL__N_113homeFirstReadERKNS_3AppEyENKUlRKN14MotorControlRS6ESS_RS19ReadStepObservationEE_clES7_
	l32i	a12, sp, 172
	mov.n	a9, a10
.L5581:
	addi	a2, a2, 120
.L5580:
	bne	a12, a2, .L5582
	beqz.n	a9, .L5607
	l32r	a8, .LC2646
	add.n	a11, a6, a8
	l32r	a8, .LC2650
	s32i	a11, sp, 172
	add.n	a2, a6, a8
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	beqz.n	a10, .L5615
	l32r	a8, .LC2651
	l32i	a11, sp, 172
	add.n	a14, a6, a8
	mov.n	a10, a14
	s32i	a11, sp, 176
	s32i	a14, sp, 172
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	beqz.n	a10, .L5615
	l32i	a10, a2, 16
	l32i	a8, sp, 168
	bne	a8, a10, .L5615
	l32i	a14, sp, 172
	l32i	a10, a14, 16
	bne	a8, a10, .L5615
	l32i	a9, a2, 244
	l32i	a8, sp, 160
	l32i	a14, a2, 240
	bltu	a8, a9, .L5615
	mov.n	a10, a8
	l32i	a11, sp, 176
	l32r	a8, .LC2651
	bne	a9, a10, .L5644
	bltu	a5, a14, .L5615
.L5644:
	l32i	a10, sp, 164
	or	a10, a10, a7
	beqz.n	a10, .L5585
	l32i	a12, sp, 160
	sub	a9, a12, a9
	bgeu	a5, a14, .L5587
	addi.n	a9, a9, -1
.L5587:
	sub	a14, a5, a14
	bltu	a9, a7, .L5585
	bne	a7, a9, .L5615
	l32i	a9, sp, 164
	bgeu	a14, a9, .L5615
.L5585:
	add.n	a12, a6, a8
	l32i	a9, a12, 244
	l32i	a8, sp, 160
	l32i	a14, a12, 240
	bltu	a8, a9, .L5615
	bne	a9, a8, .L5645
	bltu	a5, a14, .L5615
.L5645:
	beqz.n	a10, .L5590
	l32i	a8, sp, 160
	sub	a9, a8, a9
	bgeu	a5, a14, .L5592
	addi.n	a9, a9, -1
.L5592:
	sub	a14, a5, a14
	bltu	a9, a7, .L5590
	bne	a7, a9, .L5615
	l32i	a8, sp, 164
	bgeu	a14, a8, .L5615
.L5590:
	l32r	a2, .LC2652
	add.n	a2, a6, a2
	l32i	a9, a2, 12
	beqz.n	a9, .L5618
	add.n	a4, a6, a4
	l32i	a9, a4, 0
	l32i	a4, a2, 16
	bne	a4, a9, .L5618
	mov.n	a10, a2
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5618
	addi	a11, a2, 56
	mov.n	a10, sp
	call8	_ZZN12_GLOBAL__N_113homeFirstReadERKNS_3AppEyENKUlRKN14MotorControlRS6ESS_RS19ReadStepObservationEE_clES7_
	l32r	a12, .LC2624
	beqz.n	a10, .L5583
	l16ui	a14, a2, 20
	bnei	a14, 7, .L5620
	j	.L5677
.L5607:
	l32r	a12, .LC2622
	j	.L5583
.L5615:
	l32r	a12, .LC2620
	j	.L5583
.L5618:
	l32r	a12, .LC2624
.L5583:
	l32r	a11, .LC2628
	j	.L5679
.L5677:
	l16ui	a9, a2, 30
	s32i	a14, sp, 168
	bnez.n	a9, .L5622
	l16ui	a9, a2, 32
	bnez.n	a9, .L5622
	l32r	a8, .LC2650
	add.n	a9, a6, a8
	l16ui	a10, a9, 22
	bnez.n	a10, .L5624
	l16ui	a9, a9, 24
	movi	a10, 0x7c
	bany	a10, a9, .L5624
	movi	a12, 0x68
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	l32r	a8, .LC2646
	l32i	a14, sp, 168
	add.n	a9, a6, a8
	l32i	a11, a9, 0
	l32i	a10, a9, 4
	l32i	a9, a9, 8
	s32i	a10, sp, 4
	s32i	a9, sp, 8
	l16ui	a9, a3, 8
	l16ui	a10, a3, 32
	s16i	a9, sp, 20
	l16ui	a9, a3, 16
	s16i	a14, sp, 30
	s16i	a9, sp, 22
	l16ui	a9, a3, 18
	s32i	a11, sp, 0
	s16i	a9, sp, 24
	l16ui	a9, a3, 20
	s16i	a10, sp, 16
	s16i	a9, sp, 26
	l8ui	a9, a3, 34
	s32i	a4, sp, 12
	s8i	a9, sp, 18
	l8ui	a9, a3, 35
	mov.n	a14, sp
	s8i	a9, sp, 28
	l8ui	a9, a3, 36
	mov.n	a13, sp
	s8i	a9, sp, 29
	l8ui	a9, a3, 37
	movi.n	a15, 2
	s8i	a9, sp, 32
	l8ui	a9, a3, 38
	movi.n	a12, 4
	s8i	a9, sp, 33
	l8ui	a9, a3, 39
	s8i	a9, sp, 35
	movi.n	a9, 1
	s8i	a9, sp, 34
	l32r	a9, .LC2653
	l32i	a8, sp, 160
	add.n	a9, a6, a9
	l16ui	a9, a9, 0
	l32r	a11, .LC2654
	l32r	a10, .LC2655
	s32i	a8, sp, 68
	l32i	a8, sp, 164
	s32i	a7, sp, 60
	s32i	a5, sp, 64
	s32i	a8, sp, 56
	s16i	a9, sp, 90
	add.n	a11, a6, a11
	add.n	a10, a6, a10
	movi.n	a7, 1
	loop	a12, .L5597_LEND
.L5597:
	l16ui	a8, a11, 0
	l8ui	a6, a10, 0
	s16i	a8, a14, 82
	addi.n	a8, a8, -1
	extui	a9, a8, 0, 16
	saltu	a9, a15, a9
	addi.n	a9, a9, -1
	neg	a9, a9
	s8i	a6, a13, 92
	extui	a9, a9, 0, 8
	beqz.n	a9, .L5596
	bnei	a6, 2, .L5596
	l8ui	a9, sp, 36
	ssl	a8
	sll	a8, a7
	or	a8, a8, a9
	s8i	a8, sp, 36
.L5596:
	addi.n	a11, a11, 2
	addi.n	a14, a14, 2
	addi.n	a10, a10, 1
	addi.n	a13, a13, 1
	.L5597_LEND:
	mov.n	a10, sp
	call8	_ZN21MotorControlRSExample24installHomeQualificationERKN14MotorControlRS6ESS_RS17HomePrerequisitesE
	extui	a10, a10, 0, 8
	call8	_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0
	s32i	a10, sp, 148
	extui	a10, a10, 0, 8
	j	.L5574
.L5606:
	l32r	a11, .LC2626
	movi.n	a12, 0
	j	.L5679
.L5620:
	l32r	a11, .LC2630
	movi.n	a12, 0
	j	.L5679
.L5622:
	l32r	a11, .LC2632
	movi.n	a12, 0
	j	.L5679
.L5624:
	l32r	a12, .LC2620
	l32r	a11, .LC2634
.L5679:
	movi.n	a10, 3
.L5574:
	s8i	a10, sp, 148
	l32i	a8, sp, 148
	j	.L5684
.L5675:
	add.n	a4, a6, a4
	l32i	a2, a4, 0
	beqz.n	a2, .L5625
	l32r	a9, .LC2657
	add.n	a9, a6, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L5627
	l32r	a5, .LC2646
	l32r	a10, .LC2645
	add.n	a4, a6, a5
	mov.n	a11, a4
	add.n	a10, a6, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5627
	l32r	a7, .LC2658
	add.n	a9, a6, a7
	l32i	a9, a9, 12
	beqz.n	a9, .L5630
	add.n	a7, a6, a7
	l32i	a9, a7, 16
	bne	a2, a9, .L5630
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5630
	l16ui	a4, a7, 22
	movi	a9, 0x7d0
	bltu	a9, a4, .L5632
	l16ui	a7, a7, 24
	bltu	a9, a7, .L5632
	movi.n	a12, 0x1b
	movi.n	a11, 0
	addi	a10, sp, 21
	call8	memset
	movi.n	a9, 0x48
	addmi	a9, a9, -0xc00
	s16i	a9, sp, 26
	movi	a9, 0xb8
	addmi	a9, a9, 0xb00
	s16i	a9, sp, 28
	add.n	a9, a6, a5
	l32i	a10, a9, 4
	l32i	a11, a9, 0
	l32i	a9, a9, 8
	movi	a8, 0x3e8
	s32i	a9, sp, 8
	l16ui	a9, a3, 40
	s32i	a10, sp, 4
	s16i	a9, sp, 16
	l8ui	a9, a3, 34
	s32i	a11, sp, 0
	s8i	a9, sp, 18
	l8ui	a9, a3, 37
	s32i	a2, sp, 12
	s8i	a9, sp, 19
	movi.n	a9, 1
	s8i	a9, sp, 20
	l32i	a9, a6, 0
	s16i	a4, sp, 22
	mull	a10, a8, a9
	muluh	a8, a8, a9
	s32i	a10, sp, 48
	s32i	a8, sp, 52
	s16i	a7, sp, 24
	mov.n	a10, sp
	call8	_ZN21MotorControlRSExample28installVelocityQualificationERKN14MotorControlRS6ESS_RS21VelocityPrerequisitesE
	extui	a10, a10, 0, 8
	call8	_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0
	s32i	a10, sp, 136
	extui	a10, a10, 0, 8
	j	.L5598
.L5625:
	l32r	a11, .LC2626
	movi.n	a12, 0
	j	.L5680
.L5627:
	l32r	a12, .LC2622
	j	.L5685
.L5630:
	l32r	a12, .LC2636
.L5685:
	l32r	a11, .LC2628
	j	.L5680
.L5632:
	l32r	a11, .LC2638
	movi.n	a12, 0
.L5680:
	movi.n	a10, 3
.L5598:
	s8i	a10, sp, 136
	l32i	a8, sp, 136
	j	.L5684
.L5568:
	call8	_ZN21MotorControlRSExample33installPositionClearQualificationEv
	j	.L5682
.L5572:
	l32r	a8, .LC2643
	add.n	a9, a6, a8
	l32i	a9, a9, 0
	beqz.n	a9, .L5633
	l32r	a9, .LC2657
	add.n	a9, a6, a9
	l32i	a9, a9, 0
	beqz.n	a9, .L5635
	l32r	a7, .LC2646
	l32r	a10, .LC2645
	add.n	a11, a6, a7
	add.n	a10, a6, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5635
	l32r	a10, .LC2644
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a4, a10
	mov.n	a10, a6
	mov.n	a5, a11
	call8	_ZN12_GLOBAL__N_118motionProfileBoundERKNS_3AppE
	beqz.n	a10, .L5641
	l32r	a12, .LC2661
	add.n	a9, a6, a12
	l8ui	a10, a9, 3
	beqz.n	a10, .L5641
	l8ui	a10, a9, 0
	bnez.n	a10, .L5641
	addmi	a10, a9, 0x100
	l8ui	a10, a10, 12
	beqz.n	a10, .L5641
	l32i	a11, a9, 200
	l32i	a9, a9, 204
	bltu	a5, a9, .L5641
	bne	a9, a5, .L5646
	bltu	a4, a11, .L5641
.L5646:
	l32i	a8, a6, 0
	movi	a10, 0x3e8
	mull	a15, a10, a8
	muluh	a10, a10, a8
	or	a8, a15, a10
	beqz.n	a8, .L5602
	sub	a9, a5, a9
	bgeu	a4, a11, .L5604
	addi.n	a9, a9, -1
.L5604:
	sub	a11, a4, a11
	bltu	a9, a10, .L5602
	bne	a10, a9, .L5641
	bgeu	a11, a15, .L5641
.L5602:
	add.n	a12, a6, a12
	l16ui	a10, a3, 44
	l16ui	a9, a12, 52
	bne	a9, a10, .L5642
	l32r	a8, .LC2643
	add.n	a7, a6, a7
	movi.n	a10, 0
	add.n	a8, a6, a8
	l32i	a8, a8, 0
	s32i	a10, sp, 20
	l32i	a10, a7, 0
	l32i	a11, a7, 4
	s32i	a10, sp, 0
	s32i	a8, sp, 12
	l32i	a10, a7, 8
	l16ui	a8, a3, 46
	s32i	a10, sp, 8
	s16i	a9, sp, 16
	s16i	a8, sp, 18
	s32i	a11, sp, 4
	s32i	a4, sp, 24
	s32i	a5, sp, 28
	mov.n	a10, sp
	call8	_ZN21MotorControlRSExample33installPositionStartSpeedRelationERKNS_26PositionStartSpeedRelationE
	extui	a10, a10, 0, 8
	call8	_ZN12_GLOBAL__N_111statusReplyERKN14MotorControlRS6StatusE$isra$0
	s32i	a10, sp, 120
	extui	a2, a10, 0, 8
	j	.L5600
.L5633:
	l32r	a11, .LC2626
	movi.n	a12, 0
	j	.L5600
.L5635:
	l32r	a12, .LC2622
	j	.L5681
.L5641:
	l32r	a12, .LC2640
.L5681:
	l32r	a11, .LC2628
	j	.L5600
.L5642:
	l32r	a11, .LC2642
	movi.n	a12, 0
.L5600:
	s8i	a2, sp, 120
	l32i	a8, sp, 120
.L5684:
	s32i	a8, sp, 0
	j	.L5683
.L5676:
	movi.n	a8, 4
	s8i	a8, sp, 0
	s32i	a9, sp, 4
	s32i	a9, sp, 8
.L5564:
	l32i	a2, sp, 0
	l32i	a3, sp, 4
	l32i	a4, sp, 8
	movi.n	a5, 0
	retw.n
.LFE2367:
	.size	_ZN12_GLOBAL__N_120qualificationCommandEPvRKN21MotorControlRSExample5Probe20QualificationCommandE, .-_ZN12_GLOBAL__N_120qualificationCommandEPvRKN21MotorControlRSExample5Probe20QualificationCommandE
	.section	.rodata.str1.1
.LC2664:
	.string	"home not admitted"
	.text
	.literal_position
	.literal .LC2663, .LC2094
	.literal .LC2665, .LC2664
	.literal .LC2666, .LC12
	.literal .LC2667, _ZN12_GLOBAL__N_13appE
	.literal .LC2668, 764508
	.align	4
	.global	_ZN21MotorControlRSExample10submitHomeERKN14MotorControlRS6ESS_RS11HomeRequestERm
	.type	_ZN21MotorControlRSExample10submitHomeERKN14MotorControlRS6ESS_RS11HomeRequestERm, @function
_ZN21MotorControlRSExample10submitHomeERKN14MotorControlRS6ESS_RS11HomeRequestERm:
.LFB2408:
	entry	sp, 48
.LCFI214:
	l32r	a4, .LC2667
	mov.n	a13, a2
	l32i	a10, a4, 0
	bnez.n	a10, .L5687
	movi.n	a8, 1
	l32r	a4, .LC2663
	s8i	a8, sp, 0
	movi.n	a3, 0
	j	.L5688
.L5687:
	l32r	a8, .LC2668
	mov.n	a14, a3
	add.n	a8, a10, a8
	l8ui	a12, a8, 0
	movi.n	a11, 0
	call8	_ZN12_GLOBAL__N_19startHomeEPvmhRKN14MotorControlRS6ESS_RS11HomeRequestERm
	mov.n	a7, a10
	beqz.n	a10, .L5689
	movi.n	a8, 1
	l32r	a4, .LC2665
	mov.n	a3, a10
	s8i	a8, sp, 0
	j	.L5688
.L5689:
	l32i	a11, a3, 0
	l32i	a10, a4, 0
	movi.n	a3, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	addmi	a10, a10, 0x2300
	movi.n	a8, 1
	l32r	a4, .LC2666
	s8i	a8, a10, 56
	s8i	a7, sp, 0
.L5688:
	l32i	a2, sp, 0
	movi.n	a5, 0
	retw.n
.LFE2408:
	.size	_ZN21MotorControlRSExample10submitHomeERKN14MotorControlRS6ESS_RS11HomeRequestERm, .-_ZN21MotorControlRSExample10submitHomeERKN14MotorControlRS6ESS_RS11HomeRequestERm
	.literal_position
	.literal .LC2669, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample14copyHomeResultEmRN14MotorControlRS6ESS_RS11HomeContextE
	.type	_ZN21MotorControlRSExample14copyHomeResultEmRN14MotorControlRS6ESS_RS11HomeContextE, @function
_ZN21MotorControlRSExample14copyHomeResultEmRN14MotorControlRS6ESS_RS11HomeContextE:
.LFB2409:
	entry	sp, 32
.LCFI215:
	l32r	a8, .LC2669
	movi.n	a9, 0
	l32i	a10, a8, 0
	movi.n	a12, 1
	movi.n	a8, 1
	movnez	a8, a9, a2
	moveqz	a9, a12, a10
	mov.n	a11, a2
	or	a2, a8, a9
	bnez.n	a2, .L5692
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L5691
	l8ui	a8, a10, 0
	bnei	a8, 7, .L5691
	addmi	a8, a10, 0x2300
	l8ui	a2, a8, 56
	beqz.n	a2, .L5691
	addmi	a11, a10, 0x1f00
	movi	a12, 0x3d4
	addi	a11, a11, 96
	mov.n	a10, a3
	call8	memcpy
	j	.L5691
.L5692:
	movi.n	a2, 0
.L5691:
	retw.n
.LFE2409:
	.size	_ZN21MotorControlRSExample14copyHomeResultEmRN14MotorControlRS6ESS_RS11HomeContextE, .-_ZN21MotorControlRSExample14copyHomeResultEmRN14MotorControlRS6ESS_RS11HomeContextE
	.section	.rodata.str1.1
.LC2671:
	.string	"stop not admitted"
	.text
	.literal_position
	.literal .LC2670, .LC2094
	.literal .LC2672, .LC2671
	.literal .LC2673, .LC12
	.literal .LC2674, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample10submitStopEhRKN14MotorControlRS10StopPolicyERm
	.type	_ZN21MotorControlRSExample10submitStopEhRKN14MotorControlRS10StopPolicyERm, @function
_ZN21MotorControlRSExample10submitStopEhRKN14MotorControlRS10StopPolicyERm:
.LFB2410:
	entry	sp, 80
.LCFI216:
	l32r	a7, .LC2674
	extui	a2, a2, 0, 8
	l32i	a6, a7, 0
	bnez.n	a6, .L5700
	movi.n	a8, 1
	l32r	a4, .LC2670
	s8i	a8, sp, 24
	movi.n	a3, 0
	j	.L5701
.L5700:
	movi.n	a12, 0x14
	movi.n	a11, 0
	addi.n	a10, sp, 4
	call8	memset
	l8ui	a9, a3, 0
	l8ui	a10, a3, 1
	s8i	a9, sp, 1
	l8ui	a9, a3, 2
	movi.n	a8, 3
	s8i	a10, sp, 2
	mov.n	a14, a4
	mov.n	a13, sp
	mov.n	a12, a2
	movi.n	a11, 0
	mov.n	a10, a6
	s8i	a8, sp, 0
	s8i	a9, sp, 3
	call8	_ZN12_GLOBAL__N_111startActionEPvmhRKN14MotorControlRS13ActionRequestERm
	mov.n	a3, a10
	beqz.n	a10, .L5703
	movi.n	a8, 1
	l32r	a4, .LC2672
	s8i	a8, sp, 24
	j	.L5701
.L5703:
	l32i	a11, a4, 0
	l32i	a10, a7, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	addmi	a10, a10, 0x600
	movi.n	a8, 1
	l32r	a4, .LC2673
	s8i	a3, sp, 24
	s8i	a8, a10, 184
	movi.n	a3, 0
.L5701:
	l32i	a2, sp, 24
	movi.n	a5, 0
	retw.n
.LFE2410:
	.size	_ZN21MotorControlRSExample10submitStopEhRKN14MotorControlRS10StopPolicyERm, .-_ZN21MotorControlRSExample10submitStopEhRKN14MotorControlRS10StopPolicyERm
	.literal_position
	.literal .LC2675, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample16copyActionResultEmRNS_12ActionResultE
	.type	_ZN21MotorControlRSExample16copyActionResultEmRNS_12ActionResultE, @function
_ZN21MotorControlRSExample16copyActionResultEmRNS_12ActionResultE:
.LFB2411:
	entry	sp, 48
.LCFI217:
	l32r	a8, .LC2675
	mov.n	a11, a2
	l32i	a6, a8, 0
	movi.n	a8, 0
	movi.n	a5, 1
	mov.n	a2, a8
	moveqz	a2, a5, a11
	moveqz	a8, a5, a6
	or	a2, a2, a8
	bnez.n	a2, .L5707
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a7, a10
	beqz.n	a10, .L5705
	l8ui	a8, a10, 0
	bnei	a8, 3, .L5705
	addmi	a9, a10, 0x600
	l8ui	a2, a9, 184
	s32i	a9, sp, 0
	beqz.n	a2, .L5705
	addmi	a11, a10, 0x500
	movi	a12, 0x184
	addi	a11, a11, 48
	mov.n	a10, a3
	call8	memcpy
	mov.n	a11, a7
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	movi.n	a8, 1
	xor	a6, a10, a8
	extui	a6, a6, 0, 8
	addmi	a8, a3, 0x100
	s8i	a6, a8, 136
	addmi	a4, a7, 0x300
	l8ui	a10, a4, 10
	l32i	a9, sp, 0
	s8i	a10, a8, 137
	l8ui	a10, a9, 185
	l32i	a9, a9, 188
	s8i	a10, a8, 138
	s32i	a9, a3, 396
	l32i	a9, a7, 792
	movi	a10, 0x98
	s32i	a9, a3, 400
	l8ui	a9, a4, 88
	movi	a12, 0x1cf
	addi	a11, a4, 96
	s8i	a9, a8, 148
	add.n	a10, a8, a10
	call8	memcpy
	addmi	a10, a3, 0x300
	movi.n	a12, 0x32
	addi	a11, a4, 32
	addi	a10, a10, 104
	call8	memcpy
	bnez.n	a6, .L5705
	s8i	a5, a7, 65
	call8	_Z18esp_timer_get_timev
	s32i	a10, a7, 48
	s32i	a11, a7, 52
	j	.L5705
.L5707:
	movi.n	a2, 0
.L5705:
	retw.n
.LFE2411:
	.size	_ZN21MotorControlRSExample16copyActionResultEmRNS_12ActionResultE, .-_ZN21MotorControlRSExample16copyActionResultEmRNS_12ActionResultE
	.section	.rodata.str1.1
.LC2679:
	.string	"release facts unavailable"
	.text
	.literal_position
	.literal .LC2676, _ZN12_GLOBAL__N_13appE
	.literal .LC2677, .LC2094
	.literal .LC2678, .LC12
	.literal .LC2680, .LC2679
	.align	4
	.global	_ZN21MotorControlRSExample23inspectReleaseAfterStopEmRNS_29ReleaseAfterStopPrerequisitesE
	.type	_ZN21MotorControlRSExample23inspectReleaseAfterStopEmRNS_29ReleaseAfterStopPrerequisitesE, @function
_ZN21MotorControlRSExample23inspectReleaseAfterStopEmRNS_29ReleaseAfterStopPrerequisitesE:
.LFB2412:
	entry	sp, 48
.LCFI218:
	l32r	a8, .LC2676
	mov.n	a11, a2
	l32i	a10, a8, 0
	mov.n	a12, a3
	bnez.n	a10, .L5715
	movi.n	a8, 1
	s8i	a8, sp, 0
	s32i	a10, sp, 4
	l32r	a8, .LC2677
	j	.L5718
.L5715:
	call8	_ZN12_GLOBAL__N_114inspectReleaseERNS_3AppEmRN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	bnez.n	a10, .L5717
	l32r	a8, .LC2678
	s8i	a10, sp, 0
	s32i	a10, sp, 4
	j	.L5718
.L5717:
	movi.n	a8, 1
	s8i	a8, sp, 0
	l32r	a8, .LC2680
	s32i	a10, sp, 4
.L5718:
	s32i	a8, sp, 8
	l32i	a2, sp, 0
	l32i	a3, sp, 4
	l32i	a4, sp, 8
	movi.n	a5, 0
	retw.n
.LFE2412:
	.size	_ZN21MotorControlRSExample23inspectReleaseAfterStopEmRNS_29ReleaseAfterStopPrerequisitesE, .-_ZN21MotorControlRSExample23inspectReleaseAfterStopEmRNS_29ReleaseAfterStopPrerequisitesE
	.section	.rodata.str1.1
.LC2682:
	.string	"release not admitted"
	.text
	.literal_position
	.literal .LC2681, .LC2094
	.literal .LC2683, .LC2682
	.literal .LC2684, .LC12
	.literal .LC2685, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample22submitReleaseAfterStopEmRKNS_29ReleaseAfterStopPrerequisitesERm
	.type	_ZN21MotorControlRSExample22submitReleaseAfterStopEmRKNS_29ReleaseAfterStopPrerequisitesERm, @function
_ZN21MotorControlRSExample22submitReleaseAfterStopEmRKNS_29ReleaseAfterStopPrerequisitesERm:
.LFB2413:
	entry	sp, 96
.LCFI219:
	l32r	a6, .LC2685
	l32i	a5, a6, 0
	bnez.n	a5, .L5720
	movi.n	a8, 1
	l32r	a4, .LC2681
	s8i	a8, sp, 40
	movi.n	a3, 0
	j	.L5721
.L5720:
	movi.n	a12, 0x18
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	s32i	a3, sp, 4
	s32i	a2, sp, 0
	l8ui	a12, a3, 4
	movi.n	a7, 1
	movi.n	a15, 0
	mov.n	a14, a4
	addi	a13, sp, 16
	movi.n	a11, 0
	mov.n	a10, a5
	s8i	a7, sp, 16
	call8	_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	mov.n	a3, a10
	beqz.n	a10, .L5723
	l32r	a4, .LC2683
	s8i	a7, sp, 40
	j	.L5721
.L5723:
	l32i	a11, a4, 0
	l32i	a10, a6, 0
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	addmi	a10, a10, 0x600
	l32r	a4, .LC2684
	s8i	a3, sp, 40
	s8i	a7, a10, 184
	movi.n	a3, 0
.L5721:
	l32i	a2, sp, 40
	movi.n	a5, 0
	retw.n
.LFE2413:
	.size	_ZN21MotorControlRSExample22submitReleaseAfterStopEmRKNS_29ReleaseAfterStopPrerequisitesERm, .-_ZN21MotorControlRSExample22submitReleaseAfterStopEmRKNS_29ReleaseAfterStopPrerequisitesERm
	.literal_position
	.literal .LC2686, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample16releaseOperationEm
	.type	_ZN21MotorControlRSExample16releaseOperationEm, @function
_ZN21MotorControlRSExample16releaseOperationEm:
.LFB2414:
	entry	sp, 32
.LCFI220:
	l32r	a4, .LC2686
	nsau	a8, a2
	l32i	a5, a4, 0
	movi.n	a7, 1
	srli	a8, a8, 5
	beqz.n	a2, .L5729
	moveqz	a8, a7, a5
	beqz.n	a8, .L5725
.L5729:
	movi.n	a2, 0
	j	.L5727
.L5725:
	mov.n	a11, a2
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm
	mov.n	a6, a10
	beqz.n	a10, .L5728
	mov.n	a11, a10
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_112releaseGroupERNS_3AppERNS0_14GroupOperationE
	movi.n	a8, -1
	xor	a2, a10, a8
	extui	a2, a2, 0, 1
	j	.L5727
.L5728:
	mov.n	a11, a2
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a11, a10
	beqz.n	a10, .L5729
	mov.n	a10, a5
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	beqz.n	a10, .L5729
	l32i	a10, a4, 0
	mov.n	a11, a2
	call8	_ZN12_GLOBAL__N_17releaseEPvm
	moveqz	a6, a7, a10
	extui	a2, a6, 0, 8
.L5727:
	retw.n
.LFE2414:
	.size	_ZN21MotorControlRSExample16releaseOperationEm, .-_ZN21MotorControlRSExample16releaseOperationEm
	.section	.rodata.str1.1
.LC2687:
	.string	"group needs 1..15 addresses"
.LC2689:
	.string	"group declaration not admitted"
	.text
	.literal_position
	.literal .LC2688, .LC2687
	.literal .LC2690, .LC2689
	.align	4
	.global	_ZN21MotorControlRSExample12declareGroupEPKhjRm
	.type	_ZN21MotorControlRSExample12declareGroupEPKhjRm, @function
_ZN21MotorControlRSExample12declareGroupEPKhjRm:
.LFB2417:
	entry	sp, 48
.LCFI221:
	addi.n	a9, a3, -1
	movi.n	a8, 0xe
	saltu	a8, a8, a9
	bnez.n	a8, .L5741
	movi.n	a9, 1
	moveqz	a8, a9, a2
	beqz.n	a8, .L5737
.L5741:
	movi.n	a8, 1
	s8i	a8, sp, 0
	movi.n	a8, 8
	s32i	a8, sp, 4
	l32r	a8, .LC2688
	s32i	a8, sp, 8
	j	.L5739
.L5737:
	movi.n	a10, 2
	call8	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE
	mov.n	a7, a10
	beqz.n	a10, .L5740
	mov.n	a12, a3
	mov.n	a11, a2
	addi.n	a10, a10, 1
	call8	memcpy
	s32i	a3, a7, 16
.L5740:
	l32r	a12, .LC2690
	mov.n	a11, a4
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc
	s32i	a10, sp, 0
	s32i	a11, sp, 4
	s32i	a12, sp, 8
.L5739:
	l32i	a2, sp, 0
	l32i	a3, sp, 4
	l32i	a4, sp, 8
	movi.n	a5, 0
	retw.n
.LFE2417:
	.size	_ZN21MotorControlRSExample12declareGroupEPKhjRm, .-_ZN21MotorControlRSExample12declareGroupEPKhjRm
	.section	.rodata.str1.1
.LC2691:
	.string	"group clear requires an idle application"
	.text
	.literal_position
	.literal .LC2692, .LC2691
	.align	4
	.global	_ZN21MotorControlRSExample10clearGroupEv
	.type	_ZN21MotorControlRSExample10clearGroupEv, @function
_ZN21MotorControlRSExample10clearGroupEv:
.LFB2418:
	entry	sp, 48
.LCFI222:
	movi.n	a10, 3
	call8	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE
	l32r	a12, .LC2692
	movi.n	a11, 0
	call8	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2418:
	.size	_ZN21MotorControlRSExample10clearGroupEv, .-_ZN21MotorControlRSExample10clearGroupEv
	.section	.rodata.str1.1
.LC2693:
	.string	"group wiring declaration not admitted"
	.text
	.literal_position
	.literal .LC2694, .LC2693
	.align	4
	.global	_ZN21MotorControlRSExample18declareGroupWiringEhhN14MotorControlRS11InputWiringE
	.type	_ZN21MotorControlRSExample18declareGroupWiringEhhN14MotorControlRS11InputWiringE, @function
_ZN21MotorControlRSExample18declareGroupWiringEhhN14MotorControlRS11InputWiringE:
.LFB2419:
	entry	sp, 48
.LCFI223:
	movi.n	a10, 4
	extui	a2, a2, 0, 8
	extui	a3, a3, 0, 8
	extui	a4, a4, 0, 8
	call8	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE
	beqz.n	a10, .L5747
	s8i	a2, a10, 20
	s8i	a3, a10, 21
	s8i	a4, a10, 22
.L5747:
	l32r	a12, .LC2694
	movi.n	a11, 0
	call8	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2419:
	.size	_ZN21MotorControlRSExample18declareGroupWiringEhhN14MotorControlRS11InputWiringE, .-_ZN21MotorControlRSExample18declareGroupWiringEhhN14MotorControlRS11InputWiringE
	.literal_position
	.literal .LC2695, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample12inspectGroupERNS_5Probe9GroupViewE
	.type	_ZN21MotorControlRSExample12inspectGroupERNS_5Probe9GroupViewE, @function
_ZN21MotorControlRSExample12inspectGroupERNS_5Probe9GroupViewE:
.LFB2420:
	entry	sp, 32
.LCFI224:
	l32r	a8, .LC2695
	mov.n	a7, a2
	l32i	a10, a8, 0
	movi.n	a2, 0
	beqz.n	a10, .L5752
	call8	_ZN12_GLOBAL__N_114buildGroupViewERNS_3AppE
	mov.n	a11, a10
	movi	a12, 0x5d0
	mov.n	a10, a7
	call8	memcpy
	movi.n	a2, 1
.L5752:
	retw.n
.LFE2420:
	.size	_ZN21MotorControlRSExample12inspectGroupERNS_5Probe9GroupViewE, .-_ZN21MotorControlRSExample12inspectGroupERNS_5Probe9GroupViewE
	.section	.rodata.str1.1
.LC2696:
	.string	"group move not admitted; inspect member readiness, policy or capacity"
	.text
	.literal_position
	.literal .LC2697, .LC2696
	.align	4
	.global	_ZN21MotorControlRSExample15submitGroupMoveERKNS_5Probe16GroupMoveRequestERm
	.type	_ZN21MotorControlRSExample15submitGroupMoveERKNS_5Probe16GroupMoveRequestERm, @function
_ZN21MotorControlRSExample15submitGroupMoveERKNS_5Probe16GroupMoveRequestERm:
.LFB2421:
	entry	sp, 48
.LCFI225:
	movi.n	a10, 5
	call8	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE
	mov.n	a7, a10
	beqz.n	a10, .L5756
	movi.n	a12, 0x4a
	mov.n	a11, a2
	addi	a10, a10, 24
	call8	memcpy
.L5756:
	l32r	a12, .LC2697
	mov.n	a11, a3
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2421:
	.size	_ZN21MotorControlRSExample15submitGroupMoveERKNS_5Probe16GroupMoveRequestERm, .-_ZN21MotorControlRSExample15submitGroupMoveERKNS_5Probe16GroupMoveRequestERm
	.section	.rodata.str1.1
.LC2698:
	.string	"group stop not admitted"
	.text
	.literal_position
	.literal .LC2699, .LC2698
	.align	4
	.global	_ZN21MotorControlRSExample15submitGroupStopEN14MotorControlRS12StopBehaviorERm
	.type	_ZN21MotorControlRSExample15submitGroupStopEN14MotorControlRS12StopBehaviorERm, @function
_ZN21MotorControlRSExample15submitGroupStopEN14MotorControlRS12StopBehaviorERm:
.LFB2422:
	entry	sp, 48
.LCFI226:
	movi.n	a10, 6
	extui	a2, a2, 0, 8
	call8	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE
	beqz.n	a10, .L5761
	s8i	a2, a10, 104
.L5761:
	l32r	a12, .LC2699
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2422:
	.size	_ZN21MotorControlRSExample15submitGroupStopEN14MotorControlRS12StopBehaviorERm, .-_ZN21MotorControlRSExample15submitGroupStopEN14MotorControlRS12StopBehaviorERm
	.section	.rodata.str1.1
.LC2700:
	.string	"group state read not admitted"
	.text
	.literal_position
	.literal .LC2701, .LC2700
	.align	4
	.global	_ZN21MotorControlRSExample20submitGroupStateReadERm
	.type	_ZN21MotorControlRSExample20submitGroupStateReadERm, @function
_ZN21MotorControlRSExample20submitGroupStateReadERm:
.LFB2423:
	entry	sp, 48
.LCFI227:
	movi.n	a10, 7
	call8	_ZN21MotorControlRSExampleL12groupRequestENS_5Probe16GroupCommandKindE
	l32r	a12, .LC2701
	mov.n	a11, a2
	call8	_ZN21MotorControlRSExampleL11submitGroupEPKNS_5Probe12GroupCommandEPmPKc
	mov.n	a2, a10
	mov.n	a3, a11
	mov.n	a4, a12
	movi.n	a5, 0
	retw.n
.LFE2423:
	.size	_ZN21MotorControlRSExample20submitGroupStateReadERm, .-_ZN21MotorControlRSExample20submitGroupStateReadERm
	.section	.rodata.str1.1
.LC2703:
	.string	"stage not admitted; inspect readiness, units, limits or owner capacity"
	.text
	.literal_position
	.literal .LC2702, .LC2094
	.literal .LC2704, .LC2703
	.literal .LC2705, .LC12
	.literal .LC2706, _ZN12_GLOBAL__N_13appE
	.literal .LC2707, .LC8
	.literal .LC2709, 53807
	.literal .LC2710, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC2711, 45697
	.literal .LC2712, 45698
	.literal .LC2713, 764508
	.literal .LC2714, _ZN12_GLOBAL__N_14uartE
	.literal .LC2717, 772492
	.literal .LC2718, 764688
	.literal .LC2719, 757624
	.literal .LC2720, 757972
	.literal .LC2721, 764504
	.literal .LC2722, 757960
	.literal .LC2723, 772784
	.literal .LC2724, 772592
	.literal .LC2725, 773384
	.literal .LC2726, 764516
	.align	4
	.global	_ZN21MotorControlRSExample17stagePositionMoveERKN14MotorControlRS15PositionRequestEtRm
	.type	_ZN21MotorControlRSExample17stagePositionMoveERKN14MotorControlRS15PositionRequestEtRm, @function
_ZN21MotorControlRSExample17stagePositionMoveERKN14MotorControlRS15PositionRequestEtRm:
.LFB2424:
	entry	sp, 160
.LCFI228:
	l32r	a8, .LC2706
	extui	a3, a3, 0, 16
	l32i	a7, a8, 0
	bnez.n	a7, .L5767
	movi.n	a8, 1
	l32r	a4, .LC2702
	s8i	a8, sp, 88
	movi.n	a3, 0
	j	.L5768
.L5767:
	l32r	a11, .LC2707
	movi.n	a12, 0x48
	addi	a10, sp, 16
	call8	memcpy
	movi.n	a12, 0x40
	mov.n	a11, a2
	addi	a10, sp, 16
	movi	a5, 0x7f7
	call8	memcpy
	slli	a5, a5, 5
	movi.n	a8, 1
	add.n	a6, a7, a5
	l32i	a9, a6, 156
	s8i	a8, sp, 82
	l32i	a8, a6, 152
	s16i	a3, sp, 80
	or	a8, a8, a9
	bnez.n	a8, .L5778
	l32r	a8, .LC2709
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5778
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_115groupSequencingERKNS_3AppE
	bnez.n	a10, .L5778
	l32r	a8, .LC2710
	l8ui	a8, a8, 0
	beqz.n	a8, .L5774
	l32r	a8, .LC2711
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5772
	l32r	a8, .LC2712
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5772
	l8ui	a8, a6, 137
	bnez.n	a8, .L5772
	mov.n	a10, a6
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L5772
	l32r	a8, .LC2713
	l32r	a3, .LC2714
	add.n	a8, a7, a8
	mov.n	a10, a3
	l8ui	a2, a8, 0
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L5772
	l16ui	a8, sp, 80
	beqz.n	a8, .L5781
	l32i	a8, sp, 80
	movi.n	a9, 1
	extui	a8, a8, 16, 16
	slli	a8, a8, 16
	slli	a9, a9, 16
	bne	a8, a9, .L5781
	l32r	a9, .LC2717
	srli	a8, a2, 3
	add.n	a8, a7, a8
	add.n	a8, a8, a9
	l8ui	a9, a8, 0
	extui	a8, a2, 0, 3
	bbc	a9, a8, .L5774
	l32r	a8, .LC2718
	add.n	a8, a7, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5775
	l8ui	a8, sp, 33
	bnez.n	a8, .L5774
.L5775:
	l32r	a6, .LC2719
	add.n	a8, a7, a6
	l32i	a8, a8, 0
	beqz.n	a8, .L5782
	movi.n	a12, 1
	mov.n	a11, a2
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_112axisReservedERKNS_3AppEhb
	bnez.n	a10, .L5783
	add.n	a5, a7, a5
	l32i	a8, a5, 52
	bnei	a8, -1, .L5778
	l32i	a8, a5, 48
	bnez.n	a8, .L5778
	l32r	a8, .LC2720
	add.n	a8, a7, a8
	l32i	a8, a8, 0
	beqz.n	a8, .L5774
	l32r	a5, .LC2721
	l32r	a10, .LC2722
	add.n	a5, a7, a5
	mov.n	a11, a5
	add.n	a10, a7, a10
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5774
	mov.n	a10, a3
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32i	a9, a7, 4
	movi	a15, 0x3e8
	mull	a8, a15, a9
	muluh	a15, a15, a9
	add.n	a14, a8, a10
	mov.n	a12, a10
	mov.n	a2, a11
	add.n	a15, a15, a11
	bgeu	a14, a8, .L5776
	addi.n	a15, a15, 1
.L5776:
	l32r	a8, .LC2723
	mov.n	a13, a2
	add.n	a8, a7, a8
	s32i	a8, sp, 0
	addi	a11, sp, 16
	mov.n	a10, a7
	s32i	a12, sp, 112
	call8	_ZN12_GLOBAL__N_119prepareSelectedMoveERNS_3AppERKN14MotorControlRS11MoveRequestEyyRNS2_6ESS_RS11MoveContextE
	mov.n	a3, a10
	bnez.n	a10, .L5777
	l32r	a11, .LC2724
	add.n	a11, a7, a11
	l8ui	a8, a11, 24
	bnez.n	a8, .L5778
	l32i	a12, sp, 112
	l32r	a8, .LC2726
	s32i	a12, sp, 0
	s32i	a2, sp, 4
	l32r	a14, .LC2725
	add.n	a8, a7, a8
	add.n	a6, a7, a6
	l32i	a15, a6, 0
	l32i	a13, a8, 0
	add.n	a14, a7, a14
	mov.n	a12, a5
	mov.n	a10, a7
	call8	_ZN12_GLOBAL__N_118beginPositionStageERNS_3AppERNS0_12StageSessionERKN14MotorControlRS10ReadTargetEmPKtmy$part$0
	mov.n	a3, a10
	bnez.n	a10, .L5773
	l32i	a8, a6, 0
	s8i	a10, sp, 88
	addi.n	a9, a8, 1
	s32i	a9, a6, 0
	s32i	a8, a4, 0
	movi.n	a3, 0
	l32r	a4, .LC2705
	j	.L5768
.L5778:
	movi.n	a3, 1
	j	.L5773
.L5772:
	movi.n	a3, 2
	j	.L5773
.L5774:
	movi.n	a3, 3
	j	.L5773
.L5777:
	movi.n	a9, 0xb
	movi.n	a8, 3
	beq	a10, a9, .L5779
	j	.L5773
.L5781:
	movi.n	a3, 8
	j	.L5773
.L5782:
	movi.n	a3, 7
	j	.L5773
.L5783:
	movi.n	a3, 0xc
.L5773:
	movi.n	a8, 1
.L5779:
	l32r	a4, .LC2704
	s8i	a8, sp, 88
.L5768:
	l32i	a2, sp, 88
	movi.n	a5, 0
	retw.n
.LFE2424:
	.size	_ZN21MotorControlRSExample17stagePositionMoveERKN14MotorControlRS15PositionRequestEtRm, .-_ZN21MotorControlRSExample17stagePositionMoveERKN14MotorControlRS15PositionRequestEtRm
	.literal_position
	.literal .LC2727, _ZN12_GLOBAL__N_13appE
	.literal .LC2728, 772604
	.literal .LC2729, 772592
	.align	4
	.global	_ZN21MotorControlRSExample17copyPositionStageEmRNS_5Probe17PositionStageViewE
	.type	_ZN21MotorControlRSExample17copyPositionStageEmRNS_5Probe17PositionStageViewE, @function
_ZN21MotorControlRSExample17copyPositionStageEmRNS_5Probe17PositionStageViewE:
.LFB2425:
	entry	sp, 32
.LCFI229:
	l32r	a8, .LC2727
	movi.n	a12, 0
	l32i	a11, a8, 0
	movi.n	a13, 1
	movi.n	a8, 1
	movnez	a8, a12, a2
	moveqz	a12, a13, a11
	mov.n	a9, a2
	or	a2, a8, a12
	mov.n	a10, a3
	bnez.n	a2, .L5799
	l32r	a8, .LC2728
	add.n	a8, a11, a8
	l32i	a8, a8, 0
	bne	a8, a9, .L5798
	l32r	a8, .LC2729
	movi	a12, 0x84
	add.n	a11, a11, a8
	call8	memcpy
	movi.n	a2, 1
	j	.L5798
.L5799:
	movi.n	a2, 0
.L5798:
	retw.n
.LFE2425:
	.size	_ZN21MotorControlRSExample17copyPositionStageEmRNS_5Probe17PositionStageViewE, .-_ZN21MotorControlRSExample17copyPositionStageEmRNS_5Probe17PositionStageViewE
	.literal_position
	.literal .LC2730, _ZN12_GLOBAL__N_13appE
	.align	4
	.global	_ZN21MotorControlRSExample15copyGroupResultEmRNS_5Probe11GroupResultE
	.type	_ZN21MotorControlRSExample15copyGroupResultEmRNS_5Probe11GroupResultE, @function
_ZN21MotorControlRSExample15copyGroupResultEmRNS_5Probe11GroupResultE:
.LFB2426:
	entry	sp, 32
.LCFI230:
	l32r	a8, .LC2730
	movi.n	a9, 0
	l32i	a10, a8, 0
	movi.n	a12, 1
	movi.n	a8, 1
	movnez	a8, a9, a2
	moveqz	a9, a12, a10
	mov.n	a11, a2
	or	a2, a8, a9
	bnez.n	a2, .L5802
	call8	_ZN12_GLOBAL__N_114groupOperationERNS_3AppEm
	mov.n	a11, a10
	beqz.n	a10, .L5801
	movi.n	a12, -8
	addmi	a12, a12, 0x900
	mov.n	a10, a3
	call8	memcpy
	movi.n	a2, 1
	j	.L5801
.L5802:
	movi.n	a2, 0
.L5801:
	retw.n
.LFE2426:
	.size	_ZN21MotorControlRSExample15copyGroupResultEmRNS_5Probe11GroupResultE, .-_ZN21MotorControlRSExample15copyGroupResultEmRNS_5Probe11GroupResultE
	.section	.rodata.str1.1
.LC2826:
	.string	"unexpected responder identity"
.LC2846:
	.string	"position profile read failed"
.LC2855:
	.string	"member removed"
.LC2863:
	.string	"stage not admitted"
	.text
	.literal_position
	.literal .LC2732, _ZN12_GLOBAL__N_13appE
	.literal .LC2733, _ZN21MotorControlRSExample14RuntimeWitnessL8retainedE
	.literal .LC2734, _ZN12_GLOBAL__N_14uartE
	.literal .LC2735, 65248
	.literal .LC2736, 757728
	.literal .LC2737, 757620
	.literal .LC2738, 757704
	.literal .LC2739, 626272
	.literal .LC2740, 64920
	.literal .LC2741, 757760
	.literal .LC2742, 626281
	.literal .LC2743, 101000
	.literal .LC2744, 625320
	.literal .LC2745, 45700
	.literal .LC2746, 9040
	.literal .LC2748, 626264
	.literal .LC2749, 626240
	.literal .LC2750, 757632
	.literal .LC2751, 757772
	.literal .LC2752, 757774
	.literal .LC2753, 757636
	.literal .LC2754, 757752
	.literal .LC2756, 757744
	.literal .LC2757, 757736
	.literal .LC2758, 757960
	.literal .LC2759, 770856
	.literal .LC2760, 47848
	.literal .LC2761, 47880
	.literal .LC2762, 45919
	.literal .LC2764, 47881
	.literal .LC2766, 45913
	.literal .LC2767, 47876
	.literal .LC2768, 772456
	.literal .LC2769, 47872
	.literal .LC2770, 47852
	.literal .LC2771, 47856
	.literal .LC2773, 64911
	.literal .LC2774, 64900
	.literal .LC2775, 64912
	.literal .LC2776, 764508
	.literal .LC2777, 47892
	.literal .LC2778, 47900
	.literal .LC2779, _ZN12_GLOBAL__N_122writeResponseConfirmedE
	.literal .LC2780, 47888
	.literal .LC2781, 64836
	.literal .LC2782, 64840
	.literal .LC2783, 64907
	.literal .LC2784, 64904
	.literal .LC2785, 64848
	.literal .LC2786, 62756
	.literal .LC2787, 62792
	.literal .LC2788, 62744
	.literal .LC2789, 64852
	.literal .LC2790, 64856
	.literal .LC2791, 64892
	.literal .LC2793, 62765
	.literal .LC2794, 64910
	.literal .LC2795, 61496
	.literal .LC2796, 63440
	.literal .LC2797, 64136
	.literal .LC2798, 45688
	.literal .LC2799, 62696
	.literal .LC2800, 764516
	.literal .LC2801, 60232
	.literal .LC2802, 64908
	.literal .LC2804, 59016
	.literal .LC2805, 61456
	.literal .LC2806, 64909
	.literal .LC2807, 772592
	.literal .LC2808, 764504
	.literal .LC2809, 771816
	.literal .LC2810, 771828
	.literal .LC2811, 771832
	.literal .LC2812, 771836
	.literal .LC2813, 813504
	.literal .LC2815, 2308
	.literal .LC2816, 774016
	.literal .LC2817, 813656
	.literal .LC2818, 774208
	.literal .LC2819, 2632
	.literal .LC2820, 774228
	.literal .LC2821, 774224
	.literal .LC2822, 813764
	.literal .LC2823, 2707178
	.literal .LC2824, 813660
	.literal .LC2825, 813664
	.literal .LC2827, .LC2826
	.literal .LC2828, 774376
	.literal .LC2829, 774032
	.literal .LC2830, 775208
	.literal .LC2834, 775536
	.literal .LC2835, 775214
	.literal .LC2836, 775216
	.literal .LC2837, 774036
	.literal .LC2838, 775220
	.literal .LC2839, 775424
	.literal .LC2840, 775213
	.literal .LC2841, 775480
	.literal .LC2842, .LC435
	.literal .LC2843, 813648
	.literal .LC2844, 775211
	.literal .LC2845, 775388
	.literal .LC2847, .LC2846
	.literal .LC2848, 813496
	.literal .LC2849, 813516
	.literal .LC2850, 813497
	.literal .LC2851, 815824
	.literal .LC2852, 815976
	.literal .LC2853, 815980
	.literal .LC2854, 815984
	.literal .LC2856, .LC2855
	.literal .LC2858, 816092
	.literal .LC2859, 818144
	.literal .LC2860, 2416
	.literal .LC2861, 2376
	.literal .LC2862, 818384
	.literal .LC2864, .LC2863
	.literal .LC2866, 818280
	.literal .LC2867, 820456
	.literal .LC2868, _ZN12_GLOBAL__N_113platformReadyE
	.literal .LC2869, 45697
	.literal .LC2870, 45698
	.literal .LC2871, 772492
	.literal .LC2873, 9017
	.literal .LC2876, 489720
	.literal .LC2877, 820464
	.literal .LC2878, 825104
	.literal .LC2880, 764633
	.literal .LC2881, 764649
	.literal .LC2882, 764665
	.literal .LC2883, 764714
	.literal .LC2884, 764696
	.literal .LC2885, 764771
	.literal .LC2886, 764772
	.literal .LC2888, 626184
	.literal .LC2889, 173324
	.literal .LC2890, 626208
	.literal .LC2891, 626196
	.literal .LC2892, 626188
	.literal .LC2893, 626216
	.literal .LC2894, 626200
	.literal .LC2895, 626224
	.literal .LC2896, 764792
	.literal .LC2897, 757616
	.literal .LC2898, 642840
	.literal .LC2899, 642836
	.literal .LC2900, 626448
	.literal .LC2901, 757712
	.literal .LC2902, _ZN21MotorControlRSExample13OwnerWatchdogL14completedLoopsE
	.literal .LC2903, _ZN21MotorControlRSExample13OwnerWatchdogL10subscribedE
	.literal .LC2904, _ZN21MotorControlRSExample13OwnerWatchdogL5errorE
	.literal .LC2905, _ZN21MotorControlRSExample13OwnerWatchdogL10lastFeedUsE
	.literal .LC2906, 99999
	.literal .LC2907, 757720
	.literal .LC2908, 500000
	.literal .LC2909, 820448
	.literal .LC2911, 818128
	.literal .LC2912, 815808
	.literal .LC2913, 775488
	.literal .LC2914, 774392
	.literal .LC2915, 65176
	.align	4
	.global	_ZN21MotorControlRSExample18serviceApplicationEv
	.type	_ZN21MotorControlRSExample18serviceApplicationEv, @function
_ZN21MotorControlRSExample18serviceApplicationEv:
.LFB2427:
	entry	sp, 176
.LCFI231:
	l32r	a8, .LC2732
	movi.n	a10, 0xa
	l32i	a2, a8, 0
	beqz.n	a2, .L6301
.L5807:
	l32r	a5, .LC2733
	movi.n	a8, 2
	l32r	a10, .LC2734
	memw
	s32i	a8, a5, 4
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	l32r	a8, .LC2735
	movi	a12, 0x3e8
	add.n	a8, a2, a8
	l8ui	a9, a8, 60
	movi.n	a13, 0
	s32i	a9, sp, 112
	mov.n	a6, a10
	mov.n	a7, a11
	call8	__udivdi3
	l32r	a8, .LC2736
	memw
	s32i	a10, a5, 8
	add.n	a8, a2, a8
	l32i	a11, a8, 0
	l32r	a8, .LC2737
	memw
	s32i	a11, a5, 16
	add.n	a8, a2, a8
	l32i	a12, a8, 0
	l32r	a8, .LC2738
	memw
	s32i	a12, a5, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	l32i	a9, sp, 112
	memw
	s32i	a8, a5, 24
	memw
	l32i	a8, a5, 12
	l32r	a4, .LC2740
	addi.n	a8, a8, 1
	memw
	s32i	a8, a5, 12
	movi.n	a3, 1
	bnei	a9, 1, .L5809
	l32r	a8, .LC2739
	add.n	a8, a2, a8
	l32i	a9, a8, 4
	bltu	a7, a9, .L5810
	bne	a9, a7, .L5812
	l32i	a8, a8, 0
	bltu	a6, a8, .L5810
.L5812:
	movi.n	a3, 0
	j	.L5809
.L5810:
	add.n	a3, a2, a4
	mov.n	a10, a3
	call8	_ZNK21MotorControlRSExample3Rtu6Runner4busyEv
	bnez.n	a10, .L5812
	addmi	a8, a3, 0x100
	l8ui	a8, a8, 67
	bnez.n	a8, .L5812
	l32r	a8, .LC2741
	add.n	a8, a2, a8
	l32i	a9, a8, 4
	bltu	a7, a9, .L5812
	bne	a9, a7, .L6117
	l32i	a8, a8, 0
	bltu	a6, a8, .L5812
.L6117:
	l32r	a7, .LC2742
	add.n	a7, a2, a7
	l8ui	a3, a7, 0
	bnez.n	a3, .L5814
	l32r	a10, .LC2734
	call8	_ZN21MotorControlRSExample11Esp32S3Uart5clearEv
	mov.n	a3, a10
	s8i	a10, a7, 0
.L5814:
	l32r	a10, .LC2734
	call8	_ZN21MotorControlRSExample11Esp32S3Uart6sampleEv
	mov.n	a6, a10
	mov.n	a7, a11
.L5809:
	add.n	a4, a2, a4
	addmi	a4, a4, 0x100
	l8ui	a8, a4, 67
	l32r	a9, .LC2744
	s32i	a8, sp, 116
	l32r	a8, .LC2743
	add.n	a4, a2, a8
	add.n	a8, a2, a9
	s32i	a8, sp, 120
	l32r	a8, .LC2735
	l32r	a9, .LC2745
	add.n	a8, a2, a8
	s32i	a8, sp, 112
	add.n	a8, a2, a9
	s32i	a8, sp, 124
	j	.L5815
.L5821:
	l8ui	a9, a4, 0
	bnei	a9, 4, .L5817
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L5817
	movi	a9, 0x6f1
	add.n	a9, a4, a9
	l8ui	a9, a9, 0
	bnei	a9, 1, .L5817
	l32i	a9, a4, 32
	beqz.n	a9, .L5817
	addi	a8, a4, 32
	l32i	a10, sp, 112
	mov.n	a11, a8
	s32i	a8, sp, 128
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	bnez.n	a10, .L5817
	l8ui	a9, a4, 71
	beqz.n	a9, .L5819
.L5820:
	movi.n	a9, 1
	l32i	a10, sp, 112
	s8i	a9, a4, 71
	mov.n	a12, a6
	mov.n	a13, a7
	addi	a11, a4, 32
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
	j	.L5817
.L5819:
	l32i	a8, sp, 124
	l32i	a10, a4, 20
	l32i	a9, a8, 0
	bne	a10, a9, .L5820
	movi	a11, 0x6f8
	mov.n	a12, a6
	mov.n	a13, a7
	add.n	a11, a4, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_121storedPositionCurrentERKNS_3AppERKN14MotorControlRS6ESS_RS27StoredPositionQualificationEy
	beqz.n	a10, .L5820
	l8ui	a11, a4, 24
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111pendingStopERKNS_3AppEh
	bnez.n	a10, .L5820
.L5817:
	l32r	a8, .LC2746
	add.n	a4, a4, a8
.L5815:
	l32i	a8, sp, 120
	bne	a8, a4, .L5821
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118cancelInvalidHomesERNS_3AppEy
	mov.n	a12, a6
	mov.n	a13, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_121cancelInvalidReleasesERNS_3AppEy
	l32r	a8, .LC2735
	mov.n	a14, a3
	add.n	a8, a2, a8
	mov.n	a10, a8
	mov.n	a12, a6
	mov.n	a13, a7
	s32i	a8, sp, 120
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7serviceEyb
	l32i	a8, sp, 116
	beqz.n	a8, .L5822
	l32r	a8, .LC2915
	add.n	a8, a2, a8
	l8ui	a8, a8, 67
	bnez.n	a8, .L5822
	call8	_Z18esp_timer_get_timev
	l32r	a9, .LC2908
	l32r	a8, .LC2741
	add.n	a10, a10, a9
	add.n	a8, a2, a8
	bgeu	a10, a9, .L5823
	addi.n	a11, a11, 1
.L5823:
	s32i	a10, a8, 0
	s32i	a11, a8, 4
.L5822:
	l32r	a8, .LC2748
	l32i	a10, sp, 120
	add.n	a8, a2, a8
	l32i	a12, a8, 0
	l32i	a13, a8, 4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner14recoveryResultEy
	beqz.n	a10, .L5824
	l8ui	a11, a10, 48
	bnez.n	a11, .L5824
	l32r	a8, .LC2749
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32r	a8, .LC2750
	add.n	a8, a2, a8
	l32i	a10, a8, 0
	bgeu	a10, a9, .L5824
	l32r	a10, .LC2751
	add.n	a10, a2, a10
	s16i	a11, a10, 0
	l32r	a10, .LC2752
	add.n	a10, a2, a10
	s8i	a11, a10, 0
	s32i	a9, a8, 0
	l32r	a8, .LC2753
	movi.n	a10, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC2754
	movi.n	a9, 0
	add.n	a8, a2, a8
	s32i	a10, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC2756
	add.n	a8, a2, a8
	s32i	a10, a8, 0
	s32i	a9, a8, 4
	l32r	a8, .LC2757
	add.n	a8, a2, a8
	s32i	a10, a8, 0
	s32i	a9, a8, 4
.L5824:
	movi.n	a8, 3
	memw
	s32i	a8, a5, 4
	call8	_Z18esp_timer_get_timev
	mov.n	a13, a11
	l32r	a14, .LC2758
	l32r	a11, .LC2759
	mov.n	a12, a10
	add.n	a14, a2, a14
	add.n	a11, a2, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_120serviceMotionProfileERNS_3AppERNS0_18MotionProfileStateEyRKN14MotorControlRS6ESS_RS17ConfigObservationE
	call8	_Z18esp_timer_get_timev
	l32r	a7, .LC2760
	s32i	a11, sp, 112
	add.n	a11, a2, a7
	l32i	a8, a11, 0
	mov.n	a4, a10
	beqz.n	a8, .L5833
	l32r	a6, .LC2761
	add.n	a6, a2, a6
	l8ui	a8, a6, 0
	bnez.n	a8, .L5827
	l32r	a8, .LC2762
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5827
	l32i	a10, sp, 120
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L5827
	movi.n	a8, 1
	s8i	a8, a6, 0
	l32r	a8, .LC2745
	l32i	a13, sp, 112
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	mov.n	a12, a4
	addi.n	a9, a9, 1
	s32i	a9, a8, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy
.L5827:
	l32i	a10, sp, 120
	add.n	a3, a2, a7
	mov.n	a11, a3
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a5, a10
	beqz.n	a10, .L5833
	movi.n	a12, 0x48
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi	a8, 0x2cd
	slli	a8, a8, 6
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	l32r	a6, .LC2762
	s32i	a8, sp, 28
	add.n	a8, a2, a6
	l8ui	a12, a8, 0
	movi.n	a8, 0
	s8i	a12, sp, 32
	l8ui	a9, a5, 112
	beqi	a9, 1, .L5830
	l8ui	a9, a5, 105
	movi.n	a8, 1
	bnei	a9, 5, .L5830
	movi.n	a8, 2
.L5830:
	s8i	a8, sp, 33
	mov.n	a11, a5
	addi	a10, sp, 16
	s32i	a8, sp, 116
	s32i	a12, sp, 124
	call8	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	l8ui	a9, a5, 142
	l32i	a8, sp, 116
	s8i	a9, sp, 81
	movi.n	a9, 0
	bnez.n	a8, .L5831
	l32i	a12, sp, 124
	movi.n	a9, 1
	bnez.n	a12, .L5831
	l32r	a8, .LC2764
	add.n	a8, a2, a8
	l8ui	a9, a8, 0
.L5831:
	movi	a10, 0x597
	l32i	a13, sp, 112
	slli	a10, a10, 5
	s8i	a9, sp, 80
	mov.n	a12, a4
	addi	a11, sp, 16
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS20advanceCommunicationERNS0_20CommunicationContextERKNS_11ActionEventEy
	s32i	a10, sp, 88
	s32i	a11, sp, 92
	s32i	a12, sp, 96
	extui	a10, a10, 0, 8
	bnez.n	a10, .L5833
	add.n	a6, a2, a6
	l8ui	a8, a6, 0
	beqz.n	a8, .L5832
	l32r	a8, .LC2766
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L5832
	l32r	a9, .LC2767
	l32r	a8, .LC2768
	add.n	a9, a2, a9
	add.n	a8, a2, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L5832
	l32r	a9, .LC2745
	l32r	a8, .LC2769
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
.L5832:
	l32i	a10, sp, 120
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	l32r	a8, .LC2770
	movi.n	a9, 0
	add.n	a7, a2, a7
	s32i	a9, a7, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC2771
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s32i	a9, a8, 4
.L5833:
	movi	a7, 0x3f5
	call8	_Z18esp_timer_get_timev
	slli	a7, a7, 6
	mov.n	a6, a11
	add.n	a11, a2, a7
	l32i	a8, a11, 0
	mov.n	a5, a10
	beqz.n	a8, .L5835
	l32r	a4, .LC2773
	add.n	a4, a2, a4
	l8ui	a3, a4, 0
	bnez.n	a3, .L5837
	l32i	a10, sp, 120
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L5837
	movi.n	a8, 1
	s8i	a8, a4, 0
	l32r	a8, .LC2774
	add.n	a8, a2, a8
	s32i	a3, a8, 0
	l32r	a8, .LC2769
	add.n	a8, a2, a8
	s32i	a3, a8, 0
	l32r	a8, .LC2775
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L5839
	l32r	a8, .LC2776
	j	.L6292
.L5839:
	l32r	a8, .LC2777
.L6292:
	add.n	a8, a2, a8
	l8ui	a11, a8, 0
	movi.n	a8, 0
	movi.n	a12, -1
	mov.n	a10, a2
	s32i	a8, sp, 4
	s32i	a8, sp, 0
	mov.n	a14, a5
	mov.n	a15, a6
	call8	_ZN12_GLOBAL__N_127invalidateDriverAssumptionsERNS_3AppEhmyPKNS0_6RecordEN14MotorControlRS6ESS_RS11DriverGroupE
	mov.n	a12, a5
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_126invalidateSerialConfidenceERNS_3AppEy
.L5837:
	l32i	a10, sp, 120
	add.n	a4, a2, a7
	mov.n	a11, a4
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	mov.n	a3, a10
	beqz.n	a10, .L5835
	l32r	a8, .LC2778
	movi.n	a12, 0x48
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	movi.n	a11, 0
	addi	a10, sp, 16
	s32i	a8, sp, 112
	call8	memset
	l32i	a8, sp, 112
	movi.n	a9, 0
	s32i	a8, sp, 28
	l8ui	a8, a3, 112
	beqi	a8, 1, .L5843
	l8ui	a8, a3, 105
	movi.n	a9, 1
	bnei	a8, 5, .L5843
	movi.n	a9, 2
.L5843:
	s8i	a9, sp, 33
	mov.n	a11, a3
	addi	a10, sp, 16
	s32i	a9, sp, 112
	call8	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	l8ui	a8, a3, 142
	l32i	a9, sp, 112
	s8i	a8, sp, 81
	movi.n	a8, 0
	bnez.n	a9, .L5844
	l32r	a8, .LC2779
	l8ui	a8, a8, 0
.L5844:
	l32r	a10, .LC2780
	s8i	a8, sp, 80
	mov.n	a12, a5
	mov.n	a13, a6
	addi	a11, sp, 16
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS18advancePersistenceERNS0_18PersistenceContextERKNS_11ActionEventEy
	s32i	a10, sp, 88
	s32i	a11, sp, 92
	s32i	a12, sp, 96
	extui	a3, a10, 0, 8
	bnez.n	a3, .L5835
	l32i	a10, sp, 120
	mov.n	a11, a4
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	l32r	a8, .LC2781
	add.n	a7, a2, a7
	s32i	a3, a7, 0
	add.n	a8, a2, a8
	s32i	a3, a8, 0
	l32r	a8, .LC2782
	movi.n	a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s32i	a9, a8, 4
.L5835:
	l32r	a7, .LC2783
	add.n	a8, a2, a7
	l8ui	a8, a8, 0
	beqz.n	a8, .L5847
	l32r	a8, .LC2784
	add.n	a8, a2, a8
	l8ui	a4, a8, 0
	l32r	a8, .LC2785
	add.n	a3, a2, a8
	l32i	a8, a3, 0
	beqz.n	a8, .L5848
	l32i	a10, sp, 120
	mov.n	a11, a3
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner6resultERKNS0_9RequestIdE
	s32i	a10, sp, 124
	beqz.n	a10, .L5847
	movi	a8, 0x2b8
	mull	a8, a4, a8
	l32r	a10, .LC2786
	add.n	a8, a2, a8
	add.n	a10, a8, a10
	l32i	a13, a10, 0
	l32r	a10, .LC2787
	movi.n	a12, 0x48
	add.n	a8, a8, a10
	l8ui	a8, a8, 0
	movi.n	a11, 0
	addi	a10, sp, 16
	s32i	a13, sp, 116
	s32i	a8, sp, 112
	call8	memset
	l32i	a8, sp, 112
	l32i	a9, sp, 124
	s8i	a8, sp, 32
	l32i	a13, sp, 116
	l8ui	a10, a9, 112
	s32i	a13, sp, 28
	movi.n	a8, 0
	beqi	a10, 1, .L5851
	l8ui	a10, a9, 105
	movi.n	a8, 1
	bnei	a10, 5, .L5851
	movi.n	a8, 2
.L5851:
	mov.n	a11, a9
	s8i	a8, sp, 33
	addi	a10, sp, 16
	s32i	a8, sp, 116
	s32i	a9, sp, 112
	call8	_ZN12_GLOBAL__N_114copyCompletionERN14MotorControlRS9ReadEventERKN21MotorControlRSExample3Rtu10CompletionE
	l32i	a8, sp, 116
	l32i	a9, sp, 112
	nsau	a8, a8
	srli	a8, a8, 5
	movi	a10, 0x2b8
	l8ui	a9, a9, 142
	mul16u	a10, a10, a4
	s8i	a8, sp, 80
	l32r	a8, .LC2788
	s8i	a9, sp, 81
	add.n	a10, a10, a8
	mov.n	a12, a5
	mov.n	a13, a6
	addi	a11, sp, 16
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS11advanceReadERNS0_11ReadContextERKNS_9ReadEventEy
	extui	a8, a10, 0, 8
	s32i	a10, sp, 88
	s32i	a11, sp, 92
	s32i	a12, sp, 96
	s32i	a8, sp, 112
	bnez.n	a8, .L5847
	l32i	a10, sp, 120
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner7releaseERKNS0_9RequestIdE
	l32r	a9, .LC2785
	l32i	a8, sp, 112
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a9, .LC2789
	add.n	a9, a2, a9
	s32i	a8, a9, 0
	l32r	a8, .LC2790
	movi.n	a9, 0
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	s32i	a9, a8, 4
.L5848:
	l32r	a9, .LC2791
	l32r	a8, .LC2745
	add.n	a9, a2, a9
	add.n	a8, a2, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L5859
	l32r	a8, .LC2768
	movi	a9, 0x1fb
	slli	a9, a9, 7
	add.n	a9, a2, a9
	add.n	a8, a2, a8
	l32i	a9, a9, 0
	l32i	a8, a8, 0
	bne	a9, a8, .L5859
	movi	a8, 0x2b8
	mull	a4, a4, a8
	l32r	a8, .LC2793
	add.n	a4, a2, a4
	add.n	a4, a4, a8
	l8ui	a4, a4, 0
	bnei	a4, 3, .L5853
	j	.L5859
.L5853:
	bnei	a4, 1, .L5854
	mov.n	a12, a5
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_119persistenceReadStepERNS_3AppEy
	beqz.n	a10, .L5847
	movi.n	a8, 0
	add.n	a7, a2, a7
	s8i	a8, a7, 0
	l32r	a8, .LC2794
	add.n	a8, a2, a8
	s8i	a4, a8, 0
.L6302:
	l32r	a8, .LC2774
.L6303:
	add.n	a8, a2, a8
	movi.n	a9, 0
	j	.L6293
.L5854:
	l32r	a8, .LC2784
	add.n	a3, a2, a8
	l8ui	a8, a3, 0
	addi.n	a8, a8, 1
	extui	a8, a8, 0, 8
	s8i	a8, a3, 0
	bgeui	a8, 3, .L5856
	mov.n	a12, a5
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_122persistencePrepareReadERNS_3AppEy
	bnez.n	a10, .L5857
	j	.L5859
.L5857:
	mov.n	a12, a5
	mov.n	a13, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_119persistenceReadStepERNS_3AppEy
	bnez.n	a10, .L5859
	j	.L5847
.L5856:
	l32r	a4, .LC2795
	l32r	a10, .LC2788
	add.n	a4, a2, a4
	movi	a11, 0x340
	add.n	a11, a4, a11
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS11getIdentityERKNS0_11ReadContextERNS0_19IdentityObservationE
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	bnez.n	a10, .L5859
	l32r	a10, .LC2796
	mov.n	a11, a4
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS9getConfigERKNS0_11ReadContextERNS0_17ConfigObservationE
	s32i	a10, sp, 88
	s32i	a11, sp, 92
	s32i	a12, sp, 96
	extui	a10, a10, 0, 8
	bnez.n	a10, .L5859
	l32r	a10, .LC2797
	movi	a3, 0x3e8
	add.n	a8, a4, a3
	mov.n	a12, a8
	movi.n	a11, 0
	add.n	a10, a2, a10
	s32i	a8, sp, 116
	call8	_ZN14MotorControlRS6ESS_RS13getStateBlockERKNS0_11ReadContextEhRNS0_16StateObservationE
	extui	a8, a10, 0, 8
	s32i	a10, sp, 100
	s32i	a11, sp, 104
	s32i	a12, sp, 108
	s32i	a8, sp, 124
	bnez.n	a8, .L5859
	l32r	a10, .LC2798
	add.n	a10, a2, a10
	call8	_ZN12_GLOBAL__N_118communicationTupleERKN21MotorControlRSExample9HostTupleE
	l32r	a9, .LC2799
	s32i	a10, sp, 16
	add.n	a8, a2, a9
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	addi	a11, sp, 16
	movi.n	a12, 0xb
	mov.n	a10, a8
	s32i	a8, sp, 112
	call8	memcpy
	l32r	a10, .LC2801
	l32r	a9, .LC2800
	add.n	a10, a2, a10
	l32i	a11, a10, 4
	add.n	a9, a2, a9
	l32i	a10, a10, 0
	l32i	a9, a9, 0
	addmi	a12, a4, 0x400
	l32i	a8, sp, 124
	s32i	a10, a12, 192
	movi.n	a10, 0
	s8i	a8, a12, 200
	s32i	a10, a12, 208
	s32i	a10, a12, 212
	s32i	a8, a12, 216
	s32i	a9, a12, 188
	s32i	a11, a12, 196
	add.n	a10, a2, a7
	s8i	a8, a10, 0
	l32r	a8, .LC2802
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L6283
	j	.L5860
.L5859:
	movi.n	a8, 0
	add.n	a7, a2, a7
	s8i	a8, a7, 0
	l32r	a8, .LC2794
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	j	.L6302
.L5860:
	l32r	a10, .LC2780
	mov.n	a12, a5
	mov.n	a13, a6
	mov.n	a11, a4
	add.n	a10, a2, a10
	call8	_ZN14MotorControlRS6ESS_RS17verifyPersistenceERNS0_18PersistenceContextERKNS0_23PersistenceVerificationEy
	s32i	a10, sp, 16
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	extui	a10, a10, 0, 8
	l32r	a8, .LC2774
	beqz.n	a10, .L5862
	movi.n	a9, 0
	add.n	a7, a2, a7
	s8i	a9, a7, 0
	l32r	a9, .LC2794
	movi.n	a10, 1
	add.n	a9, a2, a9
	s8i	a10, a9, 0
	j	.L6303
.L5862:
	l32r	a9, .LC2745
	add.n	a8, a2, a8
	add.n	a9, a2, a9
	l32i	a9, a9, 0
.L6293:
	s32i	a9, a8, 0
	j	.L5847
.L6283:
	movi	a7, 0x75b
	l32r	a11, .LC2804
	slli	a7, a7, 5
	add.n	a7, a2, a7
	movi	a12, 0x4d4
	add.n	a11, a2, a11
	mov.n	a10, a7
	s32i	a9, sp, 124
	call8	memcpy
	addmi	a10, a7, 0x300
	addmi	a11, a4, 0x300
	movi	a12, 0xa8
	addi	a11, a11, 64
	addi	a10, a10, 64
	call8	memcpy
	movi	a12, 0x340
	mov.n	a11, a4
	mov.n	a10, a7
	call8	memcpy
	l32i	a11, sp, 116
	movi	a12, 0xc8
	add.n	a10, a7, a3
	call8	memcpy
	l32r	a10, .LC2805
	l32i	a11, sp, 112
	movi.n	a12, 0xb
	add.n	a10, a2, a10
	call8	memcpy
	l32i	a9, sp, 124
	l32r	a8, .LC2806
	addmi	a7, a7, 0x400
	s32i	a9, a7, 188
	add.n	a8, a2, a8
	movi.n	a9, 1
	s8i	a9, a8, 0
.L5847:
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116serviceDiscoveryERNS_3AppEy
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112advanceReadsERNS_3AppEy
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114advanceActionsERNS_3AppEy
	call8	_Z18esp_timer_get_timev
	l32r	a7, .LC2807
	s32i	a10, sp, 116
	add.n	a6, a2, a7
	l8ui	a8, a6, 24
	s32i	a11, sp, 112
	bnez.n	a8, .L5863
.L5866:
	add.n	a7, a2, a7
	l8ui	a8, a7, 25
	bnez.n	a8, .L5864
	j	.L5867
.L5863:
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_120servicePositionStageERNS_3AppERNS0_12StageSessionEy$part$0
	l8ui	a8, a6, 24
	bnez.n	a8, .L5867
	j	.L5866
.L5864:
	l8ui	a8, a7, 153
	bnez.n	a8, .L5867
	l32r	a11, .LC2808
	movi.n	a8, 1
	s8i	a8, a7, 153
	add.n	a11, a2, a11
	mov.n	a10, a6
	call8	_ZN21MotorControlRSExample5Probe10sameTargetERKN14MotorControlRS10ReadTargetES4_
	beqz.n	a10, .L5867
	l32r	a8, .LC2800
	l32i	a5, a7, 16
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a5, a8, .L5867
	l32r	a8, .LC2745
	l32i	a6, a7, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a6, a8, .L5867
	l32r	a10, .LC2809
	movi.n	a12, 0xa
	addi	a11, a7, 28
	add.n	a10, a2, a10
	call8	memcpy
	l32r	a8, .LC2810
	add.n	a8, a2, a8
	s32i	a5, a8, 0
	l32r	a8, .LC2811
	l32i	a9, a7, 8
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	l32r	a8, .LC2812
	add.n	a8, a2, a8
	s32i	a6, a8, 0
.L5867:
	l32r	a5, .LC2813
	add.n	a5, a2, a5
	l8ui	a8, a5, 12
	s32i	a8, sp, 124
	beqz.n	a8, .L5869
	l32r	a8, .LC2815
	add.n	a8, a5, a8
	s32i	a8, sp, 132
	j	.L5868
.L5897:
	l32r	a8, .LC2819
	l8ui	a12, a15, 9
	mul16u	a8, a7, a8
	bgeui	a12, 2, .L5870
	l32i	a11, a15, 4
	bnez.n	a11, .L5871
	l32r	a11, .LC2816
	l32r	a13, .LC2815
	add.n	a11, a8, a11
	add.n	a13, a3, a13
	add.n	a11, a2, a11
	mov.n	a10, a2
	s32i	a15, sp, 124
	call8	_ZN12_GLOBAL__N_115startMemberReadERNS_3AppERNS0_11GroupMemberEN14MotorControlRS6ESS_RS8ReadKindERm
	addi	a8, a10, -5
	extui	a8, a8, 0, 8
	bltui	a8, 2, .L5869
	addx8	a7, a7, a7
	slli	a7, a7, 4
	add.n	a7, a3, a7
	s8i	a10, a7, 144
	l32i	a15, sp, 124
	beqz.n	a10, .L5873
	movi.n	a8, 2
	s8i	a8, a7, 145
	j	.L6300
.L5873:
	l32i	a8, a15, 4
	s32i	a8, a7, 140
	j	.L5869
.L5871:
	mov.n	a10, a2
	s32i	a8, sp, 136
	s32i	a12, sp, 128
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	l32i	a12, sp, 128
	l32i	a8, sp, 136
	mov.n	a6, a10
	bnez.n	a10, .L5875
.L5878:
	l32r	a8, .LC2813
	slli	a9, a7, 3
	add.n	a11, a9, a7
	add.n	a10, a2, a8
	slli	a11, a11, 4
	add.n	a10, a10, a11
	l8ui	a10, a10, 145
	beqz.n	a10, .L5876
	j	.L5881
.L5875:
	l8ui	a11, a10, 101
	beqi	a11, 1, .L5869
	addx8	a9, a7, a7
	slli	a15, a9, 4
	add.n	a9, a3, a15
	movi	a10, 0x84
	add.n	a10, a6, a10
	s32i	a9, sp, 128
	s8i	a11, a9, 146
	l32r	a9, .LC2817
	l32i	a14, a10, 0
	add.n	a3, a2, a15
	add.n	a9, a3, a9
	l32i	a13, a10, 4
	s32i	a14, a9, 0
	l32i	a10, a10, 8
	s32i	a15, sp, 136
	s32i	a13, a9, 4
	s32i	a10, a9, 8
	bnei	a11, 2, .L5878
	addi	a10, a6, 80
	bnez.n	a12, .L5879
	l32r	a14, .LC2818
	add.n	a11, a8, a14
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS11getIdentityERKNS0_11ReadContextERNS0_19IdentityObservationE
	l32r	a8, .LC2819
	l32r	a9, .LC2820
	mull	a8, a7, a8
	s32i	a11, sp, 20
	add.n	a8, a2, a8
	add.n	a9, a8, a9
	l16ui	a11, a9, 0
	l32r	a9, .LC2821
	l32i	a15, sp, 136
	add.n	a9, a8, a9
	l32r	a13, .LC2822
	s32i	a12, sp, 24
	l32i	a12, a9, 0
	add.n	a9, a2, a15
	s32i	a10, sp, 16
	add.n	a9, a9, a13
	s32i	a12, a9, 0
	l32i	a9, sp, 128
	extui	a10, a10, 0, 8
	s16i	a11, a9, 264
	bnez.n	a10, .L5878
	l32r	a9, .LC2816
	l32r	a14, .LC2818
	add.n	a8, a8, a9
	l8ui	a8, a8, 0
	bne	a8, a11, .L5880
	l32r	a8, .LC2819
	l32r	a9, .LC2823
	mull	a8, a7, a8
	add.n	a8, a2, a8
	add.n	a8, a8, a14
	l32i	a8, a8, 16
	bne	a8, a9, .L5880
.L5882:
	l32i	a4, sp, 124
	j	.L5881
.L5880:
	l32r	a8, .LC2813
	addx8	a7, a7, a7
	add.n	a8, a2, a8
	slli	a7, a7, 4
	add.n	a8, a8, a7
	movi.n	a9, 3
	s8i	a9, a8, 145
	l32r	a8, .LC2817
	movi.n	a9, 1
	add.n	a8, a3, a8
	s8i	a9, a8, 0
	l32r	a8, .LC2824
	movi.n	a9, 0
	add.n	a8, a3, a8
	s32i	a9, a8, 0
	l32r	a8, .LC2825
	add.n	a3, a3, a8
	l32r	a8, .LC2827
	s32i	a8, a3, 0
	j	.L5881
.L5879:
	l32r	a11, .LC2828
	add.n	a11, a8, a11
	add.n	a11, a2, a11
	call8	_ZN14MotorControlRS6ESS_RS9getConfigERKNS0_11ReadContextERNS0_17ConfigObservationE
	l32i	a9, sp, 128
	movi	a8, 0x10a
	s32i	a10, sp, 16
	add.n	a14, a9, a8
	extui	a10, a10, 0, 8
	movi.n	a8, 1
	s32i	a11, sp, 20
	s32i	a12, sp, 24
	movnez	a8, a4, a10
	s8i	a8, a14, 0
	beqz.n	a10, .L5882
	j	.L5878
.L5876:
	movi.n	a10, 2
	beqz.n	a6, .L5883
	l8ui	a11, a6, 132
	movi.n	a10, 3
	beqi	a11, 6, .L5883
	movi	a10, 0xe0
	movi	a11, 0x338
	add.n	a10, a6, a10
	add.n	a6, a6, a11
	j	.L5884
.L5886:
	addi	a10, a10, 120
	addi	a11, a10, -120
	l32i	a11, a11, 0
	bnez.n	a11, .L6106
.L5884:
	bne	a10, a6, .L5886
	movi.n	a10, 0
	j	.L5885
.L6106:
	l32i	a10, sp, 124
.L5885:
	addi.n	a10, a10, 2
	extui	a10, a10, 0, 8
.L5883:
	add.n	a9, a9, a7
	add.n	a8, a2, a8
	slli	a9, a9, 4
	add.n	a8, a8, a9
	s8i	a10, a8, 145
.L5881:
	l32i	a11, sp, 132
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112releaseChildERNS_3AppERm
	bnez.n	a4, .L5887
	movi.n	a8, 1
	s8i	a8, a5, 105
	j	.L5874
.L5887:
	addmi	a8, a5, 0x900
	l8ui	a8, a8, 9
	addi.n	a8, a8, 1
	extui	a8, a8, 0, 8
	j	.L5888
.L5870:
	bnei	a12, 2, .L5889
	l32i	a10, sp, 120
	s32i	a8, sp, 124
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L5890
	l32r	a10, .LC2734
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L5890
	l32r	a4, .LC2819
	l32r	a9, .LC2829
	mull	a5, a7, a4
	l32r	a3, .LC2768
	add.n	a5, a2, a5
	add.n	a9, a5, a9
	add.n	a3, a2, a3
	l32i	a10, a9, 0
	l32i	a9, a3, 0
	l32i	a8, sp, 124
	bne	a10, a9, .L5890
	l32r	a6, .LC2830
	l32r	a10, .LC2830
	add.n	a6, a8, a6
	movi	a12, 0x150
	movi.n	a11, 0
	add.n	a10, a10, a5
	call8	memset
	add.n	a6, a2, a6
	mov.n	a10, a6
	call8	_ZN12_GLOBAL__N_13App18MotionProfileStateC1Ev
	l32r	a11, .LC2914
	l32r	a10, .LC2913
	add.n	a11, a11, a5
	add.n	a10, a10, a5
	movi.n	a12, 0x1e
	call8	memcpy
	l32r	a8, .LC2834
	l32i	a9, a3, 0
	add.n	a8, a5, a8
	s32i	a9, a8, 0
	l32r	a9, .LC2816
	l32r	a8, .LC2835
	add.n	a9, a5, a9
	l8ui	a9, a9, 0
	add.n	a8, a5, a8
	s8i	a9, a8, 0
	l32r	a9, .LC2837
	l32r	a8, .LC2836
	add.n	a9, a5, a9
	l32i	a9, a9, 0
	add.n	a8, a5, a8
	s32i	a9, a8, 0
	l32r	a9, .LC2745
	l32r	a8, .LC2838
	add.n	a9, a2, a9
	l32i	a9, a9, 0
	add.n	a8, a5, a8
	s32i	a9, a8, 0
	l32r	a10, .LC2908
	l32i	a9, sp, 116
	l32r	a8, .LC2839
	add.n	a9, a9, a10
	add.n	a5, a5, a8
	l32i	a8, sp, 112
	bgeu	a9, a10, .L5892
	addi.n	a8, a8, 1
.L5892:
	s32i	a8, a5, 4
	mull	a8, a7, a4
	s32i	a9, a5, 0
	l32r	a9, .LC2840
	add.n	a8, a2, a8
	add.n	a9, a8, a9
	movi.n	a4, 1
	s8i	a4, a9, 0
	l32r	a5, .LC2830
	l32r	a9, .LC2841
	add.n	a5, a8, a5
	add.n	a8, a8, a9
	l32r	a9, .LC2842
	s8i	a4, a5, 0
	l32i	a14, sp, 116
	l32i	a15, sp, 112
	s32i	a9, a8, 0
	movi.n	a12, 0
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_119submitMotionProfileERNS_3AppERNS0_18MotionProfileStateEby
	beqz.n	a10, .L6284
	j	.L5893
.L5890:
	addx8	a7, a7, a7
	add.n	a6, a2, a6
	slli	a7, a7, 4
	movi.n	a8, 2
	add.n	a7, a6, a7
	s8i	a8, a7, 145
	movi.n	a8, 1
	s8i	a8, a6, 105
	j	.L5874
.L6284:
	l32r	a8, .LC2735
	s8i	a10, a5, 0
	add.n	a8, a2, a8
	l32i	a9, a8, 48
	bnez.n	a9, .L5869
	l32i	a8, a8, 52
	bnei	a8, -1, .L5869
	addx8	a7, a7, a7
	l32r	a8, .LC2843
	slli	a7, a7, 4
	add.n	a7, a2, a7
	add.n	a7, a7, a8
	movi	a8, 0x204
	s16i	a8, a7, 0
	l32r	a8, .LC2813
	add.n	a8, a2, a8
	s8i	a4, a8, 105
	j	.L5874
.L5893:
	l32r	a8, .LC2912
	movi.n	a9, 3
	add.n	a8, a2, a8
	s8i	a9, a8, 9
	j	.L5869
.L5889:
	l32r	a6, .LC2830
	l32r	a14, .LC2828
	add.n	a11, a8, a6
	add.n	a14, a8, a14
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	add.n	a14, a2, a14
	add.n	a11, a2, a11
	mov.n	a10, a2
	s32i	a15, sp, 128
	call8	_ZN12_GLOBAL__N_120serviceMotionProfileERNS_3AppERNS0_18MotionProfileStateEyRKN14MotorControlRS6ESS_RS17ConfigObservationE
	l32r	a8, .LC2819
	mull	a8, a7, a8
	add.n	a8, a2, a8
	add.n	a6, a8, a6
	l8ui	a9, a6, 0
	bnez.n	a9, .L5869
	l32r	a9, .LC2844
	addx8	a10, a7, a7
	add.n	a9, a8, a9
	slli	a10, a10, 4
	l8ui	a9, a9, 0
	add.n	a10, a3, a10
	movi	a11, 0x10b
	add.n	a11, a10, a11
	s8i	a9, a11, 0
	l32i	a15, sp, 128
	bnez.n	a9, .L5895
	l32r	a11, .LC2845
	addx8	a7, a7, a7
	add.n	a8, a8, a11
	l32i	a12, a8, 0
	movi.n	a11, 3
	movi.n	a8, 2
	movnez	a8, a11, a12
	s8i	a8, a10, 145
	slli	a7, a7, 4
	l32r	a8, .LC2817
	add.n	a7, a2, a7
	add.n	a8, a7, a8
	movi.n	a10, 5
	s8i	a10, a8, 0
	l32r	a8, .LC2824
	add.n	a8, a7, a8
	s32i	a9, a8, 0
	l32r	a8, .LC2825
	add.n	a7, a7, a8
	l32r	a8, .LC2847
	s32i	a8, a7, 0
.L6300:
	movi.n	a8, 1
	s8i	a8, a3, 105
	j	.L5874
.L5895:
	movi.n	a8, 1
	s8i	a8, a10, 145
	l8ui	a8, a15, 8
	addi.n	a8, a8, 1
	s8i	a8, a15, 8
	movi.n	a8, 0
.L5888:
	l32r	a9, .LC2912
	add.n	a9, a2, a9
	s8i	a8, a9, 9
.L5868:
	l32r	a6, .LC2813
	add.n	a3, a2, a6
	l8ui	a4, a3, 105
	bnez.n	a4, .L5874
	addmi	a15, a3, 0x900
	l8ui	a7, a15, 8
	l8ui	a8, a3, 128
	bltu	a7, a8, .L5897
	j	.L6285
.L6091:
	addx8	a8, a8, a8
	add.n	a9, a2, a9
	slli	a8, a8, 4
	add.n	a8, a9, a8
	l8ui	a8, a8, 136
	movi.n	a10, 0
	s8i	a8, a9, 106
	l32r	a8, .LC2848
	add.n	a8, a2, a8
	s16i	a10, a8, 0
	l32r	a8, .LC2849
	add.n	a8, a2, a8
	s16i	a10, a8, 0
	l32i	a8, sp, 116
	s32i	a8, a9, 120
	l32i	a8, sp, 112
	s32i	a8, a9, 124
	j	.L5869
.L6285:
	l32r	a8, .LC2850
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC2849
	movi	a9, 0x100
	add.n	a8, a2, a8
	s16i	a9, a8, 0
	l32i	a8, sp, 116
	s32i	a8, a3, 120
	l32i	a8, sp, 112
	s32i	a8, a3, 124
.L5869:
	l32r	a7, .LC2851
	add.n	a7, a2, a7
	l8ui	a5, a7, 12
	beqz.n	a5, .L5900
	l32r	a4, .LC2815
	add.n	a8, a7, a4
	s32i	a8, sp, 124
	j	.L5899
.L5911:
	addx8	a6, a4, a4
	slli	a6, a6, 4
	add.n	a6, a12, a6
	l8ui	a11, a6, 136
	mov.n	a10, a2
	s32i	a14, sp, 132
	s32i	a12, sp, 128
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	l32i	a12, sp, 128
	l32i	a14, sp, 132
	mov.n	a3, a10
	bnez.n	a10, .L5901
	addx8	a9, a4, a4
	l32r	a8, .LC2852
	slli	a9, a9, 4
	add.n	a9, a2, a9
	add.n	a8, a9, a8
	movi.n	a10, 1
	s8i	a10, a8, 0
	l32r	a8, .LC2853
	add.n	a8, a9, a8
	s32i	a3, a8, 0
	l32r	a8, .LC2854
	add.n	a9, a9, a8
	l32r	a8, .LC2856
	s32i	a8, a9, 0
	j	.L6304
.L5901:
	l32i	a11, a14, 4
	bnez.n	a11, .L5903
	movi	a8, 0x8c
	add.n	a8, a6, a8
	l32i	a10, a8, 0
	bnez.n	a10, .L5903
	l32r	a13, .LC2815
	mov.n	a11, a3
	add.n	a13, a12, a13
	mov.n	a10, a2
	movi.n	a12, 2
	s32i	a14, sp, 132
	s32i	a8, sp, 128
	call8	_ZN12_GLOBAL__N_115startMemberReadERNS_3AppERNS0_11GroupMemberEN14MotorControlRS6ESS_RS8ReadKindERm
	addi	a9, a10, -5
	extui	a9, a9, 0, 8
	bltui	a9, 2, .L5900
	s8i	a10, a6, 144
	l32i	a8, sp, 128
	l32i	a14, sp, 132
	beqz.n	a10, .L5905
.L6304:
	l8ui	a8, a14, 8
	j	.L6295
.L5905:
	l32i	a9, a14, 4
	s32i	a9, a8, 0
	j	.L5900
.L5903:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L5906
	l8ui	a12, a10, 101
	beqi	a12, 1, .L5900
	l32r	a11, .LC2851
	addx8	a8, a4, a4
	add.n	a11, a2, a11
	slli	a8, a8, 4
	add.n	a8, a11, a8
	s8i	a12, a8, 146
	movi	a12, 0x84
	addi.n	a8, a4, 1
	add.n	a10, a10, a12
	addx8	a8, a8, a8
	l32i	a13, a10, 0
	slli	a8, a8, 4
	add.n	a8, a11, a8
	l32i	a12, a10, 4
	s32i	a13, a8, 8
	addi.n	a11, a8, 8
	l32i	a8, a10, 8
	s32i	a12, a11, 4
	s32i	a8, a11, 8
.L5906:
	l32r	a8, .LC2851
	addx8	a9, a4, a4
	add.n	a8, a2, a8
	slli	a9, a9, 4
	add.n	a4, a8, a9
	l8ui	a8, a4, 146
	beqi	a8, 2, .L5907
	movi	a8, 0x10c
	add.n	a8, a4, a8
	movi.n	a9, 0
	s8i	a9, a8, 0
	j	.L5908
.L5907:
	movi	a6, 0x5f8
	add.n	a6, a3, a6
	addi.n	a11, a3, 8
	mov.n	a10, a6
	s32i	a11, sp, 128
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	l32i	a11, sp, 128
	bnez.n	a10, .L5909
	j	.L6294
.L5909:
	movi	a10, 0x718
	add.n	a10, a3, a10
	s32i	a11, sp, 128
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	l32i	a11, sp, 128
	bnez.n	a10, .L5910
.L6294:
	movi	a8, 0x10c
	add.n	a8, a4, a8
	s8i	a10, a8, 0
	j	.L5908
.L5910:
	movi.n	a10, 0x38
	addmi	a10, a10, 0x800
	add.n	a10, a3, a10
	call8	_ZN21MotorControlRSExample5Probe7currentERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetE
	movi	a8, 0x10c
	add.n	a8, a4, a8
	s8i	a10, a8, 0
	beqz.n	a10, .L5908
	l16ui	a8, a6, 22
	s16i	a8, a4, 270
	l16ui	a8, a6, 24
	s16i	a8, a4, 272
	addmi	a8, a3, 0x700
	l16ui	a8, a8, 64
	addmi	a3, a3, 0x800
	l8ui	a9, a3, 116
	s16i	a8, a4, 274
	movi	a8, 0x10d
	add.n	a8, a4, a8
	s8i	a9, a8, 0
	l32i	a8, a3, 120
	s32i	a8, a4, 276
.L5908:
	l32i	a11, sp, 124
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_112releaseChildERNS_3AppERm
	addmi	a8, a7, 0x900
	l8ui	a8, a8, 8
.L6295:
	l32r	a9, .LC2911
	addi.n	a8, a8, 1
	extui	a8, a8, 0, 8
	add.n	a9, a2, a9
	s8i	a8, a9, 8
.L5899:
	l32r	a8, .LC2851
	add.n	a12, a2, a8
	addmi	a14, a12, 0x900
	l8ui	a4, a14, 8
	l8ui	a11, a12, 128
	bltu	a4, a11, .L5911
	l32r	a10, .LC2858
	movi.n	a9, 0
	add.n	a10, a2, a10
	movi	a12, 0x90
	j	.L5912
.L5914:
	beqz.n	a5, .L5913
	l8ui	a5, a10, 0
.L5913:
	addi.n	a9, a9, 1
	extui	a9, a9, 0, 8
	add.n	a10, a10, a12
.L5912:
	bne	a11, a9, .L5914
	add.n	a8, a2, a8
	movi.n	a9, 0
	s8i	a9, a8, 12
	l32i	a9, sp, 116
	s8i	a5, a8, 13
	s32i	a9, a8, 120
	l32i	a9, sp, 112
	s32i	a9, a8, 124
.L5900:
	l32r	a5, .LC2859
	add.n	a6, a2, a5
	l8ui	a8, a6, 12
	beqz.n	a8, .L5916
	l8ui	a8, a6, 97
	movi.n	a7, 0
	s32i	a8, sp, 128
	j	.L5917
.L5919:
	addx8	a8, a7, a7
	slli	a8, a8, 4
	add.n	a8, a6, a8
	l8ui	a11, a8, 136
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L5918
	addmi	a8, a10, 0x900
	l8ui	a8, a8, 136
	beqz.n	a8, .L5918
	l32r	a11, .LC2860
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	add.n	a11, a10, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_120servicePositionStageERNS_3AppERNS0_12StageSessionEy$part$0
.L5918:
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
.L5917:
	l8ui	a8, a6, 128
	bltu	a7, a8, .L5919
	movi.n	a6, 0
	add.n	a4, a2, a5
	j	.L5920
.L5928:
	slli	a7, a6, 3
	add.n	a8, a7, a6
	slli	a8, a8, 4
	add.n	a8, a4, a8
	l32i	a11, a8, 140
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a11, a10
	beqz.n	a10, .L5922
	addmi	a8, a10, 0x300
	l8ui	a8, a8, 10
	beqz.n	a8, .L5923
.L5924:
	add.n	a7, a7, a6
	movi.n	a8, 1
	slli	a7, a7, 4
	s8i	a8, a4, 105
	add.n	a7, a4, a7
	l8ui	a8, a7, 136
	s8i	a8, a4, 106
	j	.L5922
.L5923:
	l8ui	a8, a10, 71
	bnez.n	a8, .L5924
	addmi	a8, a10, 0x2300
	l8ui	a8, a8, 58
	beqz.n	a8, .L5922
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L5924
.L5922:
	addi.n	a6, a6, 1
	extui	a6, a6, 0, 8
.L5920:
	l8ui	a8, a4, 105
	bnez.n	a8, .L5929
	addmi	a8, a4, 0x900
	l8ui	a8, a8, 10
	bnez.n	a8, .L5927
	l8ui	a8, a4, 128
	bltu	a6, a8, .L5928
	j	.L5927
.L6291:
	l32i	a9, sp, 128
	bnez.n	a9, .L5931
	l8ui	a8, a8, 9
	s32i	a8, sp, 124
	bnez.n	a8, .L5931
	j	.L5932
.L5940:
	addx8	a6, a7, a7
	slli	a6, a6, 4
	add.n	a6, a5, a6
	l32i	a11, a6, 140
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	l8ui	a11, a6, 136
	s32i	a10, sp, 136
	mov.n	a10, a2
	s32i	a11, sp, 132
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	l32i	a14, sp, 136
	l32i	a11, sp, 132
	nsau	a9, a14
	movi.n	a3, 1
	srli	a9, a9, 5
	beqz.n	a14, .L6118
	moveqz	a9, a3, a10
	beqz.n	a9, .L5934
.L6118:
	l32r	a8, .LC2859
	add.n	a4, a2, a8
	movi.n	a8, 1
	s8i	a8, a4, 105
	s8i	a11, a4, 106
	j	.L5949
.L5934:
	movi	a9, 0xd8
	add.n	a6, a6, a9
	l8ui	a9, a6, 0
	addmi	a8, a10, 0x900
	bnez.n	a9, .L5937
	l8ui	a8, a8, 136
	bnez.n	a8, .L6108
	l32i	a8, sp, 116
	l32r	a11, .LC2860
	s32i	a8, sp, 0
	l32i	a8, sp, 112
	addi.n	a12, a10, 8
	s32i	a8, sp, 4
	l32r	a8, .LC2861
	l32i	a15, a14, 4
	l32i	a13, a10, 20
	add.n	a14, a14, a8
	add.n	a11, a10, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118beginPositionStageERNS_3AppERNS0_12StageSessionERKN14MotorControlRS10ReadTargetEmPKtmy$part$0
	addi	a9, a10, -5
	extui	a9, a9, 0, 8
	mov.n	a8, a10
	bltui	a9, 2, .L5931
	bnez.n	a10, .L5938
	s8i	a3, a6, 0
	j	.L5931
.L6108:
	movi.n	a8, 1
.L5938:
	l32r	a9, .LC2859
	movi.n	a10, 3
	add.n	a4, a2, a9
	addx8	a9, a7, a7
	slli	a9, a9, 4
	add.n	a9, a4, a9
	addx8	a7, a7, a7
	s8i	a10, a9, 216
	slli	a7, a7, 4
	l32r	a10, .LC2862
	add.n	a7, a2, a7
	add.n	a7, a7, a10
	movi.n	a10, 1
	s8i	a10, a7, 0
	s32i	a8, a9, 244
	l32r	a8, .LC2864
	s32i	a8, a9, 248
	s8i	a10, a4, 105
	l8ui	a8, a9, 136
	j	.L6299
.L5937:
	l8ui	a9, a8, 136
	bnez.n	a9, .L5931
	l8ui	a9, a8, 137
	bnez.n	a9, .L5939
	s8i	a3, a5, 105
	s8i	a11, a5, 106
	j	.L5949
.L5939:
	movi	a11, 0x8c
	movi.n	a9, 0x32
	addmi	a7, a10, 0xa00
	addmi	a9, a9, 0xa00
	addmi	a11, a11, 0x900
	add.n	a11, a10, a11
	s8i	a3, a7, 48
	add.n	a10, a10, a9
	movi.n	a12, 0xa
	s32i	a8, sp, 132
	call8	memcpy
	l32i	a8, sp, 132
	l32i	a9, a8, 128
	s32i	a9, a7, 60
	l32i	a9, a8, 120
	s32i	a9, a7, 64
	l32i	a9, a8, 132
	s32i	a9, a7, 68
	l8ui	a9, a4, 8
	addi.n	a9, a9, 1
	s8i	a9, a4, 8
.L5932:
	addmi	a4, a5, 0x900
	l8ui	a7, a4, 8
	l8ui	a6, a5, 128
	bltu	a7, a6, .L5940
	l32r	a7, .LC2866
	l32r	a4, .LC2861
	add.n	a7, a2, a7
	movi	a3, 0x90
	j	.L5941
.L5943:
	l32i	a11, a7, 4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	l8ui	a5, a7, 0
	s32i	a10, sp, 132
	mov.n	a11, a5
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	l32i	a12, sp, 132
	mov.n	a11, a10
	nsau	a8, a12
	srli	a8, a8, 5
	beqz.n	a12, .L5942
	movi.n	a9, 1
	moveqz	a8, a9, a10
	bnez.n	a8, .L5942
	add.n	a12, a12, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_118memberWitnessValidERKNS_3AppERKNS0_11GroupMemberEPKt
	add.n	a7, a7, a3
	beqz.n	a10, .L5942
	l32i	a8, sp, 124
	addi.n	a8, a8, 1
	extui	a8, a8, 0, 8
	s32i	a8, sp, 124
	j	.L5941
.L5942:
	l32r	a8, .LC2859
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 105
	s8i	a5, a8, 106
	j	.L5949
.L5941:
	l32i	a8, sp, 124
	bne	a6, a8, .L5943
	l32r	a8, .LC2867
	movi	a9, 0x100
	add.n	a8, a2, a8
	s16i	a9, a8, 0
.L5931:
	l32r	a8, .LC2859
	add.n	a9, a2, a8
	l8ui	a10, a9, 105
	bnez.n	a10, .L5949
	l32i	a10, sp, 128
	bnez.n	a10, .L5944
	addmi	a9, a9, 0x900
	l8ui	a9, a9, 9
	bnei	a9, 1, .L5945
.L5944:
	add.n	a3, a2, a8
	l8ui	a8, a3, 97
	s32i	a8, sp, 136
	addmi	a8, a3, 0x900
	s32i	a8, sp, 124
	j	.L5946
.L5967:
	slli	a5, a7, 3
	add.n	a4, a5, a7
	slli	a4, a4, 4
	add.n	a8, a3, a4
	l32i	a11, a8, 140
	mov.n	a10, a2
	s32i	a8, sp, 132
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a6, a10
	beqz.n	a10, .L6305
	l8ui	a4, a10, 0
	beqi	a4, 4, .L5948
	j	.L6305
.L5948:
	addmi	a10, a10, 0x2300
	l8ui	a10, a10, 58
	beqz.n	a10, .L5950
	l8ui	a8, a6, 71
	beqz.n	a8, .L5951
.L5952:
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy
.L6305:
	l32r	a8, .LC2859
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 105
	add.n	a7, a5, a7
	j	.L6298
.L5951:
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L5952
	l32r	a8, .LC2735
	add.n	a8, a2, a8
	l32i	a10, a8, 52
	bnei	a10, -1, .L5929
	l32i	a8, a8, 48
	bnez.n	a8, .L5929
	l32i	a8, sp, 132
	l8ui	a11, a8, 136
	l32i	a8, sp, 136
	bnez.n	a8, .L5953
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	mov.n	a11, a10
	beqz.n	a10, .L5954
	l32r	a12, .LC2861
	mov.n	a10, a2
	add.n	a12, a6, a12
	call8	_ZN12_GLOBAL__N_118memberWitnessValidERKNS_3AppERKNS0_11GroupMemberEPKt
	bnez.n	a10, .L5953
.L5954:
	l32r	a4, .LC2859
	add.n	a5, a5, a7
	add.n	a4, a2, a4
	slli	a5, a5, 4
	movi.n	a8, 3
	add.n	a5, a4, a5
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	s8i	a8, a5, 144
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy
	movi.n	a8, 1
	s8i	a8, a4, 105
	l8ui	a8, a5, 136
.L6299:
	s8i	a8, a4, 106
	j	.L5949
.L5953:
	movi.n	a12, 0x48
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi.n	a8, 2
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	movi	a10, 0x6f0
	s8i	a8, sp, 16
	addi	a14, sp, 16
	add.n	a10, a6, a10
	call8	_ZN14MotorControlRS6ESS_RS8nextMoveERKNS0_11MoveContextEyRNS0_12PreparedMoveE
	s32i	a10, sp, 88
	s32i	a11, sp, 92
	s32i	a12, sp, 96
	extui	a10, a10, 0, 8
	bnez.n	a10, .L5957
	l8ui	a8, sp, 16
	bnez.n	a8, .L5929
	l32r	a8, .LC2868
	l8ui	a8, a8, 0
	bnez.n	a8, .L5959
.L5962:
	movi.n	a4, 3
	j	.L5957
.L5959:
	l32r	a8, .LC2869
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L5960
.L5961:
	movi.n	a4, 2
	j	.L5957
.L5960:
	l32r	a8, .LC2870
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L5961
	l32r	a8, .LC2735
	add.n	a8, a2, a8
	l8ui	a8, a8, 137
	bnez.n	a8, .L5961
	l32i	a10, sp, 120
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L5961
	l32r	a10, .LC2734
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L5961
	l8ui	a9, sp, 24
	l32r	a10, .LC2871
	srli	a8, a9, 3
	add.n	a8, a2, a8
	add.n	a8, a8, a10
	l8ui	a8, a8, 0
	extui	a9, a9, 0, 3
	bbc	a8, a9, .L5962
	l32r	a8, .LC2768
	l32i	a9, sp, 28
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L5962
	l32r	a8, .LC2745
	l32i	a9, a6, 20
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bne	a9, a8, .L5962
	l32i	a14, sp, 116
	l32i	a15, sp, 112
	addi	a12, sp, 16
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy
	mov.n	a4, a10
	bnez.n	a10, .L5963
	addmi	a6, a6, 0x2300
	s8i	a10, a6, 58
	j	.L5929
.L5963:
	addi	a8, a10, -5
	extui	a8, a8, 0, 8
	bltui	a8, 2, .L5929
.L5957:
	l32r	a5, .LC2859
	addx8	a7, a7, a7
	add.n	a5, a2, a5
	slli	a7, a7, 4
	add.n	a7, a5, a7
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	s8i	a4, a7, 144
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy
	movi.n	a8, 1
	s8i	a8, a5, 105
	l8ui	a8, a7, 136
	s8i	a8, a5, 106
	j	.L5949
.L5950:
	mov.n	a11, a6
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L5964
	addmi	a6, a6, 0x900
	l8ui	a9, a6, 120
	l8ui	a10, a6, 122
	bgeu	a10, a9, .L5929
	addi.n	a7, a7, 1
	addx8	a7, a7, a7
	slli	a7, a7, 4
	add.n	a7, a3, a7
	movi.n	a9, 1
	s8i	a9, a7, 22
	j	.L6296
.L5964:
	movi	a10, 0x6f0
	add.n	a10, a6, a10
	call8	_ZN12_GLOBAL__N_113classifyStartERKN14MotorControlRS6ESS_RS11MoveContextE
	addi.n	a9, a7, 1
	addx8	a9, a9, a9
	slli	a9, a9, 4
	add.n	a9, a3, a9
	s8i	a10, a9, 22
	bnei	a10, 1, .L5966
	addmi	a6, a6, 0x800
	l8ui	a9, a6, 220
	bnei	a9, 2, .L5966
.L6296:
	l32i	a8, sp, 124
	l8ui	a9, a8, 8
	addi.n	a9, a9, 1
	extui	a9, a9, 0, 8
	j	.L5965
.L5966:
	l32r	a8, .LC2859
	movi.n	a9, 1
	add.n	a8, a2, a8
	s8i	a9, a8, 105
	addx8	a7, a7, a7
.L6298:
	slli	a7, a7, 4
	add.n	a7, a8, a7
	l8ui	a9, a7, 136
	s8i	a9, a8, 106
	j	.L5949
.L5965:
	l32r	a10, .LC2909
	add.n	a10, a2, a10
	s8i	a9, a10, 8
.L5946:
	l8ui	a9, a3, 105
	bnez.n	a9, .L5929
	l32i	a8, sp, 124
	l8ui	a9, a3, 128
	l8ui	a7, a8, 8
	bltu	a7, a9, .L5967
	j	.L6286
.L5929:
	l32r	a8, .LC2859
	add.n	a8, a2, a8
	l8ui	a8, a8, 105
	beqz.n	a8, .L5988
	j	.L5949
.L5983:
	add.n	a7, a2, a7
	addmi	a8, a7, 0x900
	l8ui	a8, a8, 12
	movi.n	a5, 0
	beqz.n	a8, .L5970
	j	.L5988
.L6289:
	movi.n	a9, 1
	s8i	a9, a8, 11
	movi.n	a6, 0
	j	.L5971
.L5982:
	slli	a5, a6, 3
	add.n	a8, a5, a6
	slli	a8, a8, 4
	add.n	a8, a4, a8
	l8ui	a11, a8, 136
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L5973
	addmi	a8, a10, 0x900
	l8ui	a9, a8, 136
	beqz.n	a9, .L5973
	movi.n	a9, 1
	s8i	a9, a8, 138
	l32i	a8, a8, 248
	beqz.n	a8, .L5973
	movi.n	a8, -8
	addmi	a8, a8, 0xa00
	add.n	a3, a10, a8
	l32i	a10, sp, 120
	mov.n	a11, a3
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	bnez.n	a10, .L5973
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	l32i	a10, sp, 120
	mov.n	a11, a3
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L5973:
	add.n	a5, a5, a6
	slli	a5, a5, 4
	add.n	a5, a4, a5
	l32i	a11, a5, 140
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a5, a10
	beqz.n	a10, .L5976
	addmi	a8, a10, 0x2300
	l8ui	a8, a8, 58
	beqz.n	a8, .L5977
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	mov.n	a11, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_116endWaitingMemberERNS_3AppERNS0_6RecordEy
	j	.L5976
.L5977:
	mov.n	a11, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L5976
	addmi	a8, a5, 0x900
	l8ui	a9, a8, 120
	l8ui	a8, a8, 122
	bltu	a8, a9, .L5976
	beq	a9, a8, .L5979
.L5981:
	movi.n	a8, 1
	s8i	a8, a5, 71
	l32i	a8, a5, 32
	bnez.n	a8, .L5980
	j	.L5976
.L5979:
	l32i	a8, a5, 32
	beqz.n	a8, .L5981
	l32i	a10, sp, 120
	addi	a11, a5, 32
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner10txAcceptedERKNS0_9RequestIdE
	beqz.n	a10, .L5981
	j	.L5976
.L5980:
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	l32i	a10, sp, 120
	addi	a11, a5, 32
	call8	_ZN21MotorControlRSExample3Rtu8BusOwner12cancelUnsentERKNS0_9RequestIdEy
.L5976:
	addi.n	a6, a6, 1
	extui	a6, a6, 0, 8
.L5971:
	l8ui	a8, a4, 128
	bltu	a6, a8, .L5982
	l8ui	a8, a4, 105
	bnez.n	a8, .L5983
	j	.L5988
.L5986:
	addx8	a8, a5, a5
	slli	a8, a8, 4
	add.n	a8, a7, a8
	l32i	a11, a8, 140
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERKNS_3AppEm
	mov.n	a6, a10
	bnez.n	a10, .L5984
.L5985:
	addi.n	a5, a5, 1
	extui	a5, a5, 0, 8
	j	.L5970
.L5984:
	mov.n	a11, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L5985
	addmi	a6, a6, 0x900
	l8ui	a8, a6, 120
	l8ui	a9, a6, 122
	bltu	a9, a8, .L5985
	j	.L5988
.L5970:
	l8ui	a8, a7, 128
	bltu	a5, a8, .L5986
	j	.L6287
.L6290:
	movi.n	a12, 0x18
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi.n	a8, 3
	s8i	a8, sp, 16
	beqi	a7, 2, .L5990
	movi.n	a7, 1
.L5990:
	l32r	a6, .LC2859
	s8i	a7, sp, 17
	movi.n	a5, 0
	add.n	a6, a2, a6
	j	.L5991
.L5994:
	addx8	a7, a5, a5
	slli	a7, a7, 4
	add.n	a7, a6, a7
	l32i	a11, a7, 140
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L5993
	addmi	a8, a10, 0x300
	l8ui	a4, a8, 10
	bnez.n	a4, .L5993
	movi	a8, 0x6f0
	add.n	a10, a10, a8
	call8	_ZN12_GLOBAL__N_113classifyStartERKN14MotorControlRS6ESS_RS11MoveContextE
	addi.n	a10, a10, -1
	extui	a10, a10, 0, 8
	bgeui	a10, 2, .L5993
	l8ui	a12, a7, 136
	s32i	a4, sp, 88
	s32i	a4, sp, 4
	s32i	a4, sp, 0
	movi.n	a15, 1
	addi	a14, sp, 88
	addi	a13, sp, 16
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113startActionInERNS_3AppEmhRKN14MotorControlRS13ActionRequestERmbmPKN21MotorControlRSExample29ReleaseAfterStopPrerequisitesE
	addmi	a8, a7, 0x100
	s8i	a10, a8, 0
	bnez.n	a10, .L5993
	l32i	a8, sp, 88
	s32i	a8, a7, 252
.L5993:
	addi.n	a5, a5, 1
	extui	a5, a5, 0, 8
.L5991:
	l8ui	a8, a6, 128
	bltu	a5, a8, .L5994
.L5988:
	l32i	a8, sp, 128
	bnez.n	a8, .L5996
.L5945:
	l32r	a8, .LC2909
	add.n	a8, a2, a8
	l8ui	a9, a8, 10
	bnez.n	a9, .L5996
	l8ui	a8, a8, 12
	bnez.n	a8, .L5996
	j	.L6009
.L6110:
	mov.n	a3, a7
.L6002:
	l32i	a8, a4, 4
	mov.n	a7, a4
	beqz.n	a8, .L5998
	l8ui	a8, a4, 0
	bnei	a8, 4, .L5998
	add.n	a8, a4, a12
	l8ui	a8, a8, 0
	beqz.n	a8, .L5998
	l32i	a8, a4, 32
	bnez.n	a8, .L5998
	l8ui	a8, a4, 71
	bnez.n	a8, .L5998
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	l32r	a12, .LC2873
	bnez.n	a10, .L5998
	movi	a9, 0x78
	movi	a8, 0x7a
	addmi	a9, a9, 0x900
	addmi	a8, a8, 0x900
	add.n	a9, a4, a9
	add.n	a8, a4, a8
	l8ui	a9, a9, 0
	l8ui	a8, a8, 0
	bgeu	a8, a9, .L5998
	l32r	a8, .LC2860
	l32i	a10, sp, 112
	add.n	a8, a4, a8
	l32i	a9, a8, 0
	l32i	a8, a8, 4
	bltu	a10, a8, .L5998
	bne	a8, a10, .L6119
	l32i	a10, sp, 116
	bltu	a10, a9, .L5998
.L6119:
	beqz.n	a3, .L6000
	addmi	a10, a3, 0x900
	l32i	a11, a10, 116
	bltu	a8, a11, .L6000
	bne	a11, a8, .L5998
	l32i	a8, a10, 112
	bltu	a9, a8, .L6000
.L5998:
	mov.n	a7, a3
.L6000:
	l32r	a8, .LC2746
	add.n	a4, a4, a8
	bne	a4, a5, .L6110
	beqz.n	a7, .L6009
	l32i	a10, sp, 120
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L6009
	l32r	a10, .LC2734
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L6009
	movi.n	a12, 0x48
	movi.n	a11, 0
	addi	a10, sp, 16
	call8	memset
	movi.n	a8, 2
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	movi	a10, 0x6f0
	s8i	a8, sp, 16
	addi	a14, sp, 16
	add.n	a10, a7, a10
	call8	_ZN14MotorControlRS6ESS_RS8nextMoveERKNS0_11MoveContextEyRNS0_12PreparedMoveE
	l8ui	a8, sp, 16
	s32i	a10, sp, 88
	or	a10, a10, a8
	s32i	a11, sp, 92
	s32i	a12, sp, 96
	extui	a10, a10, 0, 8
	bnez.n	a10, .L6009
	l32i	a14, sp, 116
	l32i	a15, sp, 112
	addi	a12, sp, 16
	mov.n	a11, a7
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_113admitMoveStepERNS_3AppERNS0_6RecordERKN14MotorControlRS6ESS_RS12PreparedMoveEy
	bnez.n	a10, .L6009
	addi.n	a6, a6, -1
	bnez.n	a6, .L6008
	j	.L6009
.L5996:
	l32r	a5, .LC2744
	movi.n	a6, 0xf
	add.n	a5, a2, a5
.L6008:
	l32r	a4, .LC2876
	l32r	a12, .LC2873
	add.n	a4, a2, a4
	movi.n	a3, 0
	j	.L6002
.L6018:
	addx8	a7, a3, a3
	slli	a7, a7, 4
	add.n	a7, a6, a7
	l32i	a11, a7, 140
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	l32i	a11, a7, 252
	mov.n	a4, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	l8ui	a11, a7, 136
	mov.n	a5, a10
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	mov.n	a7, a10
	bnez.n	a4, .L6010
.L6013:
	bnez.n	a5, .L6011
	j	.L6012
.L6010:
	mov.n	a11, a4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L6013
	j	.L5916
.L6012:
	bnez.n	a7, .L6015
	j	.L6016
.L6011:
	mov.n	a11, a5
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L6012
	j	.L5916
.L6015:
	addmi	a7, a7, 0x900
	l8ui	a8, a7, 136
	bnez.n	a8, .L5916
.L6016:
	addi.n	a3, a3, 1
	extui	a3, a3, 0, 8
	j	.L6017
.L6009:
	l32r	a6, .LC2859
	movi.n	a3, 0
	add.n	a6, a2, a6
.L6017:
	l8ui	a4, a6, 128
	bltu	a3, a4, .L6018
	l8ui	a7, a6, 105
	movi.n	a8, 1
	xor	a7, a7, a8
	l32r	a8, .LC2866
	extui	a7, a7, 0, 8
	add.n	a3, a2, a8
	movi.n	a6, 0
	movi	a5, 0x6f0
	j	.L6019
.L6029:
	l32i	a11, a3, 4
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a11, a10
	beqz.n	a10, .L6021
	add.n	a10, a10, a5
	addmi	a12, a10, 0x100
	l8ui	a9, a12, 236
	movi	a8, 0xc0
	s8i	a9, a3, 11
	l8ui	a9, a12, 237
	s8i	a9, a3, 12
	l8ui	a9, a12, 239
	s8i	a9, a3, 13
	l8ui	a9, a12, 238
	s8i	a9, a3, 14
	l8ui	a9, a12, 240
	s8i	a9, a3, 15
	addmi	a9, a10, 0x400
	add.n	a9, a9, a8
	l32i	a15, a9, 0
	l32i	a14, a9, 4
	s32i	a15, a3, 16
	l32i	a9, a9, 8
	s32i	a14, a3, 20
	s32i	a9, a3, 24
	l8ui	a9, a12, 242
	addmi	a12, a11, 0x300
	bnez.n	a9, .L6022
	l8ui	a9, a12, 11
.L6022:
	s8i	a9, a3, 28
	l8ui	a9, a12, 10
	s32i	a11, sp, 124
	s8i	a9, a3, 29
	call8	_ZN12_GLOBAL__N_113classifyStartERKN14MotorControlRS6ESS_RS11MoveContextE
	l32i	a11, sp, 124
	s8i	a10, a3, 30
	add.n	a9, a11, a5
	addmi	a11, a11, 0x2300
	l8ui	a10, a11, 59
	l32i	a12, a9, 392
	l32i	a13, a9, 396
	s8i	a10, a3, 40
	l32i	a10, a11, 72
	s32i	a12, a3, 32
	s32i	a13, a3, 36
	l32i	a12, a11, 64
	l32i	a13, a11, 68
	s32i	a10, a3, 56
	addmi	a10, a9, 0x100
	l8ui	a10, a10, 243
	s32i	a12, a3, 48
	s32i	a13, a3, 52
	s8i	a10, a3, 60
	beqz.n	a10, .L6021
	l32i	a10, a9, 992
	l32i	a11, a9, 996
	s32i	a10, a3, 64
	s32i	a11, a3, 68
	l32i	a10, a9, 1000
	l32i	a11, a9, 1004
	s32i	a10, a3, 72
	s32i	a11, a3, 76
.L6021:
	l8ui	a11, a3, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_111groupMemberERNS_3AppEh
	beqz.n	a10, .L6024
	l8ui	a9, a3, 80
	beqz.n	a9, .L6024
	addmi	a9, a10, 0x900
	l8ui	a11, a9, 137
	l8ui	a13, a9, 162
	addi	a11, a11, -3
	neg	a11, a11
	l8ui	a12, a9, 150
	s8i	a11, a3, 80
	s8i	a13, a3, 81
	movi.n	a11, 0
	beqz.n	a12, .L6025
	l32r	a8, .LC2860
	movi.n	a12, 0xa
	add.n	a10, a10, a8
	addi	a11, a10, 28
	addi	a10, a10, 40
	s32i	a9, sp, 128
	s32i	a13, sp, 124
	call8	memcmp
	movi.n	a11, 2
	movi.n	a8, 1
	l32i	a9, sp, 128
	l32i	a13, sp, 124
	moveqz	a11, a8, a10
.L6025:
	l8ui	a10, a9, 163
	s8i	a11, a3, 82
	s8i	a10, a3, 83
	l32i	a11, a9, 172
	l32i	a10, a9, 168
	s32i	a11, a3, 92
	s32i	a10, a3, 88
	l32i	a10, a9, 200
	l32i	a11, a9, 204
	s32i	a10, a3, 96
	l8ui	a10, a3, 104
	s32i	a11, a3, 100
	bnez.n	a10, .L6026
	movi	a8, 0xe8
	add.n	a9, a9, a8
	l32i	a12, a9, 0
	l32i	a11, a9, 4
	s32i	a12, a3, 104
	l32i	a9, a9, 8
	s32i	a11, a3, 108
	s32i	a9, a3, 112
.L6026:
	addi	a9, a13, -3
	movi.n	a10, 0
	movi.n	a8, 1
	moveqz	a10, a8, a9
	l8ui	a9, a3, 28
	or	a9, a10, a9
	s8i	a9, a3, 28
.L6024:
	l32i	a11, a3, 116
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	beqz.n	a10, .L6027
	addmi	a10, a10, 0x500
	l8ui	a9, a10, 100
	s8i	a9, a3, 121
	l8ui	a9, a10, 102
	s8i	a9, a3, 122
	l8ui	a9, a10, 103
	s8i	a9, a3, 123
.L6027:
	beqz.n	a7, .L6028
	l8ui	a9, a3, 11
	movi.n	a7, 0
	bnei	a9, 2, .L6028
	l8ui	a9, a3, 15
	bnei	a9, 1, .L6028
	l8ui	a7, a3, 28
	xor	a7, a7, a9
	extui	a7, a7, 0, 8
.L6028:
	addi.n	a6, a6, 1
	movi	a8, 0x90
	extui	a6, a6, 0, 8
	add.n	a3, a3, a8
.L6019:
	bne	a4, a6, .L6029
	l32r	a8, .LC2859
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 12
	l32i	a9, sp, 116
	s8i	a7, a8, 13
	s32i	a9, a8, 120
	l32i	a9, sp, 112
	s32i	a9, a8, 124
.L5916:
	l32r	a8, .LC2878
	l32r	a6, .LC2877
	add.n	a8, a2, a8
	add.n	a6, a2, a6
	s32i	a8, sp, 124
	j	.L6030
.L6043:
	l8ui	a3, a6, 12
	movi.n	a7, 0
	bnez.n	a3, .L6031
	j	.L6032
.L6036:
	addx8	a8, a7, a7
	slli	a8, a8, 4
	add.n	a8, a6, a8
	l32i	a11, a8, 140
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	mov.n	a11, a10
	bnez.n	a10, .L6033
.L6034:
	addi.n	a7, a7, 1
	extui	a7, a7, 0, 8
	j	.L6031
.L6033:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_18terminalERKNS_3AppERKNS0_6RecordE
	bnez.n	a10, .L6034
	j	.L6032
.L6031:
	l8ui	a15, a6, 128
	bltu	a7, a15, .L6036
	movi	a7, 0x8c
	add.n	a7, a6, a7
	mov.n	a5, a3
	movi.n	a4, 0
	j	.L6037
.L6042:
	l32i	a11, a7, 0
	mov.n	a10, a2
	s32i	a15, sp, 128
	call8	_ZN12_GLOBAL__N_110findRecordERNS_3AppEm
	l32i	a15, sp, 128
	bnez.n	a10, .L6038
.L6041:
	movi.n	a5, 0
	j	.L6039
.L6038:
	addmi	a8, a10, 0x500
	movi	a14, 0xa8
	addmi	a10, a10, 0x600
	add.n	a10, a10, a14
	l32i	a14, a10, 4
	l8ui	a9, a8, 101
	s32i	a14, sp, 128
	l32i	a14, a10, 0
	l8ui	a12, a8, 100
	l8ui	a11, a8, 102
	s8i	a9, a7, 8
	l8ui	a9, a8, 103
	s32i	a14, a7, 12
	l32i	a10, a10, 8
	l32i	a14, sp, 128
	s32i	a10, a7, 20
	s8i	a12, a7, 7
	s8i	a11, a7, 9
	s8i	a9, a7, 11
	s32i	a14, a7, 16
	mov.n	a10, a3
	beqi	a11, 3, .L6040
	addi.n	a11, a11, -1
	movi.n	a14, 1
	movi.n	a10, 0
	moveqz	a10, a14, a11
	addi.n	a13, a9, -1
	movi.n	a11, 0
	movnez	a11, a14, a13
	and	a10, a10, a11
.L6040:
	s8i	a10, a7, 24
	l8ui	a10, a8, 142
	s8i	a10, a7, 128
	l16ui	a10, a8, 144
	s16i	a10, a7, 130
	l16ui	a8, a8, 146
	s16i	a8, a7, 132
	beqz.n	a5, .L6041
	bnei	a12, 2, .L6041
	addi.n	a9, a9, -1
	nsau	a5, a9
	srli	a5, a5, 5
.L6039:
	addi.n	a4, a4, 1
	movi	a8, 0x90
	extui	a4, a4, 0, 8
	add.n	a7, a7, a8
.L6037:
	bne	a15, a4, .L6042
	movi.n	a8, 0
	s8i	a8, a6, 12
	l32i	a8, sp, 116
	s8i	a5, a6, 13
	s32i	a8, a6, 120
	l32i	a8, sp, 112
	s32i	a8, a6, 124
.L6032:
	movi.n	a8, 0x10
	addmi	a8, a8, 0x900
	add.n	a6, a6, a8
.L6030:
	l32i	a8, sp, 124
	bne	a8, a6, .L6043
	l32r	a8, .LC2880
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L6044
	l32r	a8, .LC2881
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L6044
	l32r	a8, .LC2882
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L6044
	l32r	a8, .LC2883
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	beqz.n	a8, .L6045
.L6044:
	l32r	a8, .LC2884
	l32r	a10, .LC2744
	add.n	a9, a2, a8
	l8ui	a11, a9, 18
	beqz.n	a11, .L6046
	l32i	a12, a9, 40
	l32i	a11, a9, 44
	l32i	a9, sp, 112
	bltu	a9, a11, .L6047
	bne	a11, a9, .L6120
	l32i	a9, sp, 116
	bltu	a9, a12, .L6047
.L6120:
	add.n	a8, a2, a8
	l32i	a13, a8, 56
	l32i	a9, a8, 60
	or	a8, a13, a9
	beqz.n	a8, .L6049
	l32i	a8, sp, 112
	l32i	a14, sp, 116
	sub	a8, a8, a11
	bgeu	a14, a12, .L6051
	addi.n	a8, a8, -1
.L6051:
	l32i	a14, sp, 116
	sub	a14, a14, a12
	bltu	a9, a8, .L6047
	bne	a8, a9, .L6049
	bgeu	a13, a14, .L6049
.L6047:
	l32r	a8, .LC2883
	movi.n	a9, 0
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	l32r	a8, .LC2885
	add.n	a8, a2, a8
	s8i	a9, a8, 0
	j	.L6046
.L6049:
	add.n	a8, a2, a10
	l32i	a9, a8, 252
	bltu	a9, a11, .L6045
	bne	a9, a11, .L6046
	l32i	a8, a8, 248
	bltu	a8, a12, .L6045
.L6046:
	l32i	a8, a2, 0
	movi	a14, 0x3e8
	l32r	a11, .LC2808
	muluh	a15, a14, a8
	add.n	a7, a2, a10
	mull	a14, a14, a8
	l32i	a12, sp, 116
	l32i	a13, sp, 112
	add.n	a11, a2, a11
	mov.n	a10, a7
	call8	_ZN21MotorControlRSExample5Probe5freshERKNS0_10StateCache5BlockERKN14MotorControlRS10ReadTargetEyy
	beqz.n	a10, .L6045
	l8ui	a8, a7, 36
	beqz.n	a8, .L6055
.L6056:
	movi.n	a12, 0
	movi.n	a13, 0
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114invalidateAxisERNS_3AppEPKNS0_6RecordEy
	j	.L6045
.L6055:
	l8ui	a8, a7, 34
	beqz.n	a8, .L6045
	l32r	a8, .LC2886
	add.n	a8, a2, a8
	l8ui	a8, a8, 0
	bnez.n	a8, .L6045
	l32r	a8, .LC2776
	mov.n	a10, a2
	add.n	a8, a2, a8
	l8ui	a11, a8, 0
	call8	_ZN12_GLOBAL__N_115triggeredMotionERKNS_3AppEh
	beqz.n	a10, .L6056
.L6045:
	l32r	a9, .LC2733
	movi	a6, 0x1ff
	movi.n	a8, 4
	slli	a6, a6, 7
	memw
	s32i	a8, a9, 4
	add.n	a8, a2, a6
	mov.n	a10, a8
	s32i	a8, sp, 124
	call8	_ZN21MotorControlRSExample5Probe7Console13serviceOutputEv
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_17deliverERNS_3AppE
	call8	_Z18esp_timer_get_timev
	mov.n	a12, a10
	mov.n	a13, a11
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_119serviceSimpleMotionERNS_3AppEy
	call8	_Z18esp_timer_get_timev
	l32r	a3, .LC2888
	mov.n	a7, a10
	add.n	a8, a2, a3
	l8ui	a8, a8, 0
	mov.n	a6, a11
	beqz.n	a8, .L6060
	l32r	a8, .LC2889
	add.n	a8, a2, a8
	l32i	a8, a8, 0
	bnez.n	a8, .L6060
	l32r	a5, .LC2890
	add.n	a8, a2, a5
	l32i	a9, a8, 4
	bltu	a11, a9, .L6060
	bne	a9, a11, .L6121
	l32i	a8, a8, 0
	bltu	a10, a8, .L6060
.L6121:
	l32r	a8, .LC2891
	add.n	a4, a2, a8
	l32i	a8, a4, 0
	bnez.n	a8, .L6059
.L6061:
	add.n	a3, a2, a3
	movi.n	a8, 0
	s8i	a8, a3, 0
	j	.L6060
.L6059:
	l32i	a10, sp, 120
	call8	_ZNK21MotorControlRSExample3Rtu8BusOwner13needsRecoveryEv
	bnez.n	a10, .L6061
	l32r	a10, .LC2734
	call8	_ZNK21MotorControlRSExample11Esp32S3Uart13needsRecoveryEv
	bnez.n	a10, .L6061
	l32i	a8, a4, 0
	add.n	a5, a2, a5
	addi.n	a8, a8, -1
	s32i	a8, a4, 0
	l32r	a8, .LC2892
	add.n	a8, a2, a8
	l32i	a10, a8, 0
	movi	a8, 0x3e8
	mull	a9, a8, a10
	muluh	a8, a8, a10
	add.n	a7, a9, a7
	add.n	a11, a8, a6
	bgeu	a7, a9, .L6062
	addi.n	a11, a11, 1
.L6062:
	s32i	a11, a5, 4
	s32i	a7, a5, 0
	movi.n	a8, 0
	s32i	a8, sp, 16
	l32r	a8, .LC2776
	movi.n	a15, 1
	add.n	a8, a2, a8
	l8ui	a12, a8, 0
	addi	a14, sp, 16
	movi.n	a13, 2
	movi.n	a11, 0
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114startTypedReadEPvmhN14MotorControlRS6ESS_RS8ReadKindERmb
	bnez.n	a10, .L6063
	l32r	a8, .LC2893
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L6064
	addi.n	a10, a10, 1
.L6064:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	l32r	a8, .LC2894
	l32i	a9, sp, 16
	add.n	a8, a2, a8
	s32i	a9, a8, 0
	j	.L6060
.L6063:
	l32r	a8, .LC2895
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L6065
	addi.n	a10, a10, 1
.L6065:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	l32r	a8, .LC2891
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	bnez.n	a9, .L6060
	l32r	a8, .LC2888
	add.n	a8, a2, a8
	s8i	a9, a8, 0
.L6060:
	l32r	a5, .LC2907
	l32r	a3, .LC2736
	movi.n	a7, 0x20
	add.n	a5, a2, a5
	add.n	a3, a2, a3
	j	.L6066
.L6087:
	l32i	a8, a3, 0
	l32i	a9, a3, 4
	addi.n	a8, a8, 1
	bnez.n	a8, .L6067
	addi.n	a9, a9, 1
.L6067:
	s32i	a8, a3, 0
	s32i	a9, a3, 4
.L6088:
	extui	a11, a10, 0, 8
	l32i	a10, sp, 124
	addi.n	a7, a7, -1
	call8	_ZN21MotorControlRSExample5Probe7Console4feedEc
	bnez.n	a7, .L6066
.L6071:
	l32r	a7, .LC2737
	l32r	a10, .LC2896
	add.n	a3, a2, a7
	l32i	a12, a3, 0
	l32i	a11, sp, 124
	movi.n	a5, 5
	saltu	a12, a5, a12
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample5Probe12DebugSession7serviceERNS0_7ConsoleEb
	l32i	a8, a3, 0
	bnez.n	a8, .L6288
	j	.L6068
.L6066:
	call8	_ZN21MotorControlRSExample8Platform16availableConsoleEv
	bnez.n	a10, .L6070
	j	.L6071
.L6068:
	movi.n	a11, 0
	j	.L6297
.L6288:
	l32r	a8, .LC2733
	memw
	s32i	a5, a8, 4
	call8	_ZN21MotorControlRSExample8Platform15writableConsoleEv
	bgei	a10, 1, .L6073
	l32r	a8, .LC2738
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L6074
	addi.n	a10, a10, 1
.L6074:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	j	.L6072
.L6073:
	l32r	a5, .LC2897
	l32r	a12, .LC2899
	add.n	a8, a2, a5
	l32i	a4, a8, 0
	l32r	a3, .LC2898
	slli	a6, a4, 11
	add.n	a8, a6, a4
	addx2	a8, a8, a4
	slli	a8, a8, 2
	add.n	a11, a2, a8
	add.n	a9, a11, a3
	add.n	a11, a11, a12
	l32i	a9, a9, 0
	l32i	a11, a11, 0
	movi.n	a12, 0x40
	sub	a11, a11, a9
	minu	a11, a11, a12
	l32r	a12, .LC2733
	minu	a11, a11, a10
	movi.n	a10, 6
	memw
	s32i	a10, a12, 4
	l32r	a10, .LC2900
	s32i	a11, sp, 120
	add.n	a10, a8, a10
	add.n	a10, a10, a9
	add.n	a10, a2, a10
	call8	_ZN21MotorControlRSExample8Platform12writeConsoleEPKhj
	l32i	a11, sp, 120
	bgeu	a10, a11, .L6075
	l32r	a8, .LC2901
	add.n	a8, a2, a8
	l32i	a9, a8, 0
	l32i	a11, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L6076
	addi.n	a11, a11, 1
.L6076:
	s32i	a9, a8, 0
	s32i	a11, a8, 4
.L6075:
	add.n	a6, a6, a4
	addx2	a6, a6, a4
	addx4	a6, a6, a2
	add.n	a3, a6, a3
	l32i	a8, a3, 0
	l32r	a9, .LC2899
	add.n	a8, a10, a8
	s32i	a8, a3, 0
	add.n	a6, a6, a9
	l32i	a9, a6, 0
	bne	a8, a9, .L6077
	add.n	a5, a2, a5
	l32i	a8, a5, 0
	add.n	a7, a2, a7
	addi.n	a8, a8, 1
	extui	a8, a8, 0, 3
	s32i	a8, a5, 0
	l32i	a8, a7, 0
	addi.n	a8, a8, -1
	s32i	a8, a7, 0
.L6077:
	movi.n	a11, 1
	moveqz	a11, a10, a10
.L6297:
	mov.n	a10, a2
	call8	_ZN12_GLOBAL__N_114watchUsbOutputERNS_3AppEb
.L6072:
	l32r	a8, .LC2902
	l32i	a9, a8, 0
	l32i	a10, a8, 4
	addi.n	a9, a9, 1
	bnez.n	a9, .L6078
	addi.n	a10, a10, 1
.L6078:
	s32i	a9, a8, 0
	s32i	a10, a8, 4
	l32r	a8, .LC2903
	l8ui	a8, a8, 0
	beqz.n	a8, .L6079
	l32r	a6, .LC2904
	l32i	a8, a6, 0
	bnez.n	a8, .L6079
	l32r	a7, .LC2905
	l32i	a12, sp, 112
	l32i	a8, a7, 4
	l32i	a9, a7, 0
	addi.n	a10, a8, -1
	movnez	a10, a8, a9
	addi.n	a11, a9, -1
	bltu	a10, a12, .L6122
	bne	a12, a10, .L6080
	l32i	a10, sp, 116
	bgeu	a11, a10, .L6080
.L6122:
	l32i	a10, sp, 112
	sub	a8, a10, a8
	l32i	a10, sp, 116
	bgeu	a10, a9, .L6084
	addi.n	a8, a8, -1
.L6084:
	l32i	a10, sp, 116
	sub	a9, a10, a9
	bnez.n	a8, .L6080
	l32r	a8, .LC2906
	bgeu	a8, a9, .L6089
.L6080:
	call8	_Z18esp_task_wdt_resetv
	s32i	a10, a6, 0
	bnez.n	a10, .L6079
	l32i	a8, sp, 116
	s32i	a8, a7, 0
	l32i	a8, sp, 112
	s32i	a8, a7, 4
	j	.L6089
.L6070:
	call8	_ZN21MotorControlRSExample8Platform11readConsoleEv
	l32i	a8, a5, 0
	l32i	a9, a5, 4
	addi.n	a8, a8, 1
	bnez.n	a8, .L6086
	addi.n	a9, a9, 1
.L6086:
	s32i	a8, a5, 0
	s32i	a9, a5, 4
	extui	a8, a10, 0, 8
	bnei	a8, 10, .L6088
	j	.L6087
.L6079:
	l32r	a8, .LC2868
	movi.n	a9, 0
	s8i	a9, a8, 0
.L6089:
	l32r	a9, .LC2733
	movi.n	a8, 7
	memw
	s32i	a8, a9, 4
	l32r	a8, .LC2735
	add.n	a8, a2, a8
	l32i	a8, a8, 52
	bnei	a8, -1, .L5806
	movi.n	a10, 1
.L6301:
	call8	_ZN21MotorControlRSExample8Platform4idleEj
	j	.L5806
.L5949:
	l32r	a7, .LC2859
	add.n	a4, a2, a7
	addmi	a8, a4, 0x900
	l8ui	a9, a8, 11
	bnez.n	a9, .L5983
	j	.L6289
.L5874:
	l32r	a9, .LC2813
	add.n	a10, a2, a9
	addmi	a8, a10, 0x900
	l8ui	a8, a8, 8
	l8ui	a10, a10, 128
	bltu	a8, a10, .L6091
	movi.n	a8, 0
	j	.L6091
.L6287:
	addmi	a8, a7, 0x900
	movi.n	a9, 1
	l8ui	a7, a7, 96
	s8i	a9, a8, 12
	bnei	a7, 3, .L6290
	j	.L5988
.L6286:
	l32i	a9, sp, 124
	movi.n	a8, 1
	s8i	a8, a9, 10
	j	.L5929
.L5927:
	add.n	a5, a2, a5
	addmi	a8, a5, 0x900
	l8ui	a9, a8, 10
	bnez.n	a9, .L5929
	j	.L6291
.L5806:
	retw.n
.LFE2427:
	.size	_ZN21MotorControlRSExample18serviceApplicationEv, .-_ZN21MotorControlRSExample18serviceApplicationEv
	.section	.text.exit,"ax",@progbits
	.literal_position
	.literal .LC2916, _ZN12_GLOBAL__N_14uartE
	.align	4
	.type	_GLOBAL__sub_D__ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE, @function
_GLOBAL__sub_D__ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE:
.LFB2436:
	entry	sp, 32
.LCFI232:
	l32r	a10, .LC2916
	call8	_ZN21MotorControlRSExample11Esp32S3UartD1Ev
	retw.n
.LFE2436:
	.size	_GLOBAL__sub_D__ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE, .-_GLOBAL__sub_D__ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE
	.section	.dtors,"aw",@progbits
	.align	4
	.word	_GLOBAL__sub_D__ZN21MotorControlRSExample16beginApplicationERKNS_11Esp32S3Uart4PinsEbRKNS_18ApplicationOptionsE
	.section	.rodata
	.type	CSWTCH$1256, @object
	.size	CSWTCH$1256, 9
CSWTCH$1256:
	.byte	0
	.byte	8
	.byte	8
	.byte	5
	.byte	6
	.byte	7
	.byte	6
	.byte	2
	.byte	2
	.type	C$538$3, @object
	.size	C$538$3, 4
C$538$3:
	.byte	6
	.byte	7
	.byte	8
	.byte	9
	.type	C$525$2, @object
	.size	C$525$2, 3
C$525$2:
	.byte	0
	.byte	1
	.byte	2
	.type	C$524$1, @object
	.size	C$524$1, 3
C$524$1:
	.byte	2
	.byte	3
	.byte	4
	.type	C$509$0, @object
	.size	C$509$0, 2
C$509$0:
	.byte	12
	.byte	15
	.global	measured_sizes
	.align	4
	.type	measured_sizes, @object
	.size	measured_sizes, 12
measured_sizes:
	.word	826872
	.word	9040
	.word	928
	.align	8
	.type	_ZN12_GLOBAL__N_1L23NO_START_SPEED_RELATIONE, @object
	.size	_ZN12_GLOBAL__N_1L23NO_START_SPEED_RELATIONE, 32
_ZN12_GLOBAL__N_1L23NO_START_SPEED_RELATIONE:
	.zero	32
	.type	_ZN12_GLOBAL__N_1L16BROADCAST_FRAMESE, @object
	.size	_ZN12_GLOBAL__N_1L16BROADCAST_FRAMESE, 40
_ZN12_GLOBAL__N_1L16BROADCAST_FRAMESE:
	.string	""
	.string	"\006"
	.ascii	"!\001,\330\\"
	.string	""
	.string	"\006"
	.ascii	"!\001-\031\234"
	.string	""
	.string	"\006"
	.string	"'"
	.ascii	"\001\371\320"
	.string	""
	.string	"\006"
	.string	"'\001"
	.ascii	"9\200"
	.string	""
	.string	"\006"
	.string	"'\002"
	.ascii	"9p"
	.local	_ZN12_GLOBAL__N_13appE
	.comm	_ZN12_GLOBAL__N_13appE,4,4
	.local	_ZN12_GLOBAL__N_122writeResponseConfirmedE
	.comm	_ZN12_GLOBAL__N_122writeResponseConfirmedE,1,1
	.local	_ZN12_GLOBAL__N_113platformReadyE
	.comm	_ZN12_GLOBAL__N_113platformReadyE,1,1
	.data
	.align	8
	.type	_ZN12_GLOBAL__N_14uartE, @object
	.size	_ZN12_GLOBAL__N_14uartE, 1720
_ZN12_GLOBAL__N_14uartE:
	.word	-1
	.word	-1
	.word	-1
	.byte	1
	.zero	3
	.word	115200
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.zero	3
	.word	0
	.word	0
	.word	0
	.word	0
	.zero	4
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	20
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.word	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.local	_ZN21MotorControlRSExample13OwnerWatchdogL14completedLoopsE
	.comm	_ZN21MotorControlRSExample13OwnerWatchdogL14completedLoopsE,8,8
	.local	_ZN21MotorControlRSExample13OwnerWatchdogL10lastFeedUsE
	.comm	_ZN21MotorControlRSExample13OwnerWatchdogL10lastFeedUsE,8,8
	.local	_ZN21MotorControlRSExample13OwnerWatchdogL11resetReasonE
	.comm	_ZN21MotorControlRSExample13OwnerWatchdogL11resetReasonE,4,4
	.local	_ZN21MotorControlRSExample13OwnerWatchdogL5errorE
	.comm	_ZN21MotorControlRSExample13OwnerWatchdogL5errorE,4,4
	.local	_ZN21MotorControlRSExample13OwnerWatchdogL10subscribedE
	.comm	_ZN21MotorControlRSExample13OwnerWatchdogL10subscribedE,1,1
	.local	_ZN21MotorControlRSExample14RuntimeWitnessL8previousE
	.comm	_ZN21MotorControlRSExample14RuntimeWitnessL8previousE,28,4
	.local	_ZN21MotorControlRSExample14RuntimeWitnessL8retainedE
	.comm	_ZN21MotorControlRSExample14RuntimeWitnessL8retainedE,28,4
	.section	.eh_frame,"a",@progbits
.Lframe1:
	.4byte	.LECIE1-.LSCIE1
.LSCIE1:
	.4byte	0
	.byte	0x3
	.string	"zPL"
	.uleb128 0x1
	.sleb128 -4
	.uleb128 0
	.uleb128 0x6
	.byte	0
	.4byte	__gxx_personality_v0
	.byte	0
	.byte	0xc
	.uleb128 0x1
	.uleb128 0
	.align	4
.LECIE1:
.LSFDE1:
	.4byte	.LEFDE1-.LASFDE1
.LASFDE1:
	.4byte	.LASFDE1-.Lframe1
	.4byte	.LFB2070
	.4byte	.LFE2070-.LFB2070
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI30-.LFB2070
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE1:
.LSFDE3:
	.4byte	.LEFDE3-.LASFDE3
.LASFDE3:
	.4byte	.LASFDE3-.Lframe1
	.4byte	.LFB2214
	.4byte	.LFE2214-.LFB2214
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI31-.LFB2214
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE3:
.LSFDE5:
	.4byte	.LEFDE5-.LASFDE5
.LASFDE5:
	.4byte	.LASFDE5-.Lframe1
	.4byte	.LFB2223
	.4byte	.LFE2223-.LFB2223
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI32-.LFB2223
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE5:
.LSFDE7:
	.4byte	.LEFDE7-.LASFDE7
.LASFDE7:
	.4byte	.LASFDE7-.Lframe1
	.4byte	.LFB2068
	.4byte	.LFE2068-.LFB2068
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI33-.LFB2068
	.byte	0xe
	.uleb128 0x40
	.align	4
.LEFDE7:
.LSFDE9:
	.4byte	.LEFDE9-.LASFDE9
.LASFDE9:
	.4byte	.LASFDE9-.Lframe1
	.4byte	.LFB2357
	.4byte	.LFE2357-.LFB2357
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI42-.LFB2357
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE9:
.LSFDE11:
	.4byte	.LEFDE11-.LASFDE11
.LASFDE11:
	.4byte	.LASFDE11-.Lframe1
	.4byte	.LFB2059
	.4byte	.LFE2059-.LFB2059
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI45-.LFB2059
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE11:
.LSFDE13:
	.4byte	.LEFDE13-.LASFDE13
.LASFDE13:
	.4byte	.LASFDE13-.Lframe1
	.4byte	.LFB2202
	.4byte	.LFE2202-.LFB2202
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI57-.LFB2202
	.byte	0xe
	.uleb128 0xb0
	.align	4
.LEFDE13:
.LSFDE15:
	.4byte	.LEFDE15-.LASFDE15
.LASFDE15:
	.4byte	.LASFDE15-.Lframe1
	.4byte	.LFB2203
	.4byte	.LFE2203-.LFB2203
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI58-.LFB2203
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE15:
.LSFDE17:
	.4byte	.LEFDE17-.LASFDE17
.LASFDE17:
	.4byte	.LASFDE17-.Lframe1
	.4byte	.LFB2325
	.4byte	.LFE2325-.LFB2325
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI63-.LFB2325
	.byte	0xe
	.uleb128 0xb0
	.align	4
.LEFDE17:
.LSFDE19:
	.4byte	.LEFDE19-.LASFDE19
.LASFDE19:
	.4byte	.LASFDE19-.Lframe1
	.4byte	.LFB2324
	.4byte	.LFE2324-.LFB2324
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI64-.LFB2324
	.byte	0xe
	.uleb128 0x160
	.align	4
.LEFDE19:
.LSFDE21:
	.4byte	.LEFDE21-.LASFDE21
.LASFDE21:
	.4byte	.LASFDE21-.Lframe1
	.4byte	.LFB2327
	.4byte	.LFE2327-.LFB2327
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI79-.LFB2327
	.byte	0xe
	.uleb128 0xc0
	.align	4
.LEFDE21:
.LSFDE23:
	.4byte	.LEFDE23-.LASFDE23
.LASFDE23:
	.4byte	.LASFDE23-.Lframe1
	.4byte	.LFB2328
	.4byte	.LFE2328-.LFB2328
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI80-.LFB2328
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE23:
.LSFDE25:
	.4byte	.LEFDE25-.LASFDE25
.LASFDE25:
	.4byte	.LASFDE25-.Lframe1
	.4byte	.LFB2354
	.4byte	.LFE2354-.LFB2354
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI81-.LFB2354
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE25:
.LSFDE27:
	.4byte	.LEFDE27-.LASFDE27
.LASFDE27:
	.4byte	.LASFDE27-.Lframe1
	.4byte	.LFB2075
	.4byte	.LFE2075-.LFB2075
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI85-.LFB2075
	.byte	0xe
	.uleb128 0x2d0
	.align	4
.LEFDE27:
.LSFDE29:
	.4byte	.LEFDE29-.LASFDE29
.LASFDE29:
	.4byte	.LASFDE29-.Lframe1
	.4byte	.LFB1452
	.4byte	.LFE1452-.LFB1452
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI90-.LFB1452
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE29:
.LSFDE31:
	.4byte	.LEFDE31-.LASFDE31
.LASFDE31:
	.4byte	.LASFDE31-.Lframe1
	.4byte	.LFB1454
	.4byte	.LFE1454-.LFB1454
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI91-.LFB1454
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE31:
.LSFDE33:
	.4byte	.LEFDE33-.LASFDE33
.LASFDE33:
	.4byte	.LASFDE33-.Lframe1
	.4byte	.LFB2355
	.4byte	.LFE2355-.LFB2355
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI96-.LFB2355
	.byte	0xe
	.uleb128 0x130
	.align	4
.LEFDE33:
.LSFDE35:
	.4byte	.LEFDE35-.LASFDE35
.LASFDE35:
	.4byte	.LASFDE35-.Lframe1
	.4byte	.LFB2337
	.4byte	.LFE2337-.LFB2337
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI103-.LFB2337
	.byte	0xe
	.uleb128 0x60
	.align	4
.LEFDE35:
.LSFDE37:
	.4byte	.LEFDE37-.LASFDE37
.LASFDE37:
	.4byte	.LASFDE37-.Lframe1
	.4byte	.LFB2219
	.4byte	.LFE2219-.LFB2219
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI105-.LFB2219
	.byte	0xe
	.uleb128 0x90
	.align	4
.LEFDE37:
.LSFDE39:
	.4byte	.LEFDE39-.LASFDE39
.LASFDE39:
	.4byte	.LASFDE39-.Lframe1
	.4byte	.LFB2316
	.4byte	.LFE2316-.LFB2316
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI106-.LFB2316
	.byte	0xe
	.uleb128 0x80
	.align	4
.LEFDE39:
.LSFDE41:
	.4byte	.LEFDE41-.LASFDE41
.LASFDE41:
	.4byte	.LASFDE41-.Lframe1
	.4byte	.LFB2318
	.4byte	.LFE2318-.LFB2318
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI107-.LFB2318
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE41:
.LSFDE43:
	.4byte	.LEFDE43-.LASFDE43
.LASFDE43:
	.4byte	.LASFDE43-.Lframe1
	.4byte	.LFB2277
	.4byte	.LFE2277-.LFB2277
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI108-.LFB2277
	.byte	0xe
	.uleb128 0x70
	.align	4
.LEFDE43:
.LSFDE45:
	.4byte	.LEFDE45-.LASFDE45
.LASFDE45:
	.4byte	.LASFDE45-.Lframe1
	.4byte	.LFB2465
	.4byte	.LFE2465-.LFB2465
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI109-.LFB2465
	.byte	0xe
	.uleb128 0xe0
	.align	4
.LEFDE45:
.LSFDE47:
	.4byte	.LEFDE47-.LASFDE47
.LASFDE47:
	.4byte	.LASFDE47-.Lframe1
	.4byte	.LFB2228
	.4byte	.LFE2228-.LFB2228
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI110-.LFB2228
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE47:
.LSFDE49:
	.4byte	.LEFDE49-.LASFDE49
.LASFDE49:
	.4byte	.LASFDE49-.Lframe1
	.4byte	.LFB2229
	.4byte	.LFE2229-.LFB2229
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI111-.LFB2229
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE49:
.LSFDE51:
	.4byte	.LEFDE51-.LASFDE51
.LASFDE51:
	.4byte	.LASFDE51-.Lframe1
	.4byte	.LFB2373
	.4byte	.LFE2373-.LFB2373
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI115-.LFB2373
	.byte	0xe
	.uleb128 0xa0
	.align	4
.LEFDE51:
.LSFDE53:
	.4byte	.LEFDE53-.LASFDE53
.LASFDE53:
	.4byte	.LASFDE53-.Lframe1
	.4byte	.LFB2119
	.4byte	.LFE2119-.LFB2119
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI119-.LFB2119
	.byte	0xe
	.uleb128 0x80
	.align	4
.LEFDE53:
.LSFDE55:
	.4byte	.LEFDE55-.LASFDE55
.LASFDE55:
	.4byte	.LASFDE55-.Lframe1
	.4byte	.LFB2120
	.4byte	.LFE2120-.LFB2120
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI120-.LFB2120
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE55:
.LSFDE57:
	.4byte	.LEFDE57-.LASFDE57
.LASFDE57:
	.4byte	.LASFDE57-.Lframe1
	.4byte	.LFB2348
	.4byte	.LFE2348-.LFB2348
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI122-.LFB2348
	.byte	0xe
	.uleb128 0x130
	.align	4
.LEFDE57:
.LSFDE59:
	.4byte	.LEFDE59-.LASFDE59
.LASFDE59:
	.4byte	.LASFDE59-.Lframe1
	.4byte	.LFB2116
	.4byte	.LFE2116-.LFB2116
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI123-.LFB2116
	.byte	0xe
	.uleb128 0x110
	.align	4
.LEFDE59:
.LSFDE61:
	.4byte	.LEFDE61-.LASFDE61
.LASFDE61:
	.4byte	.LASFDE61-.Lframe1
	.4byte	.LFB2073
	.4byte	.LFE2073-.LFB2073
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI124-.LFB2073
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE61:
.LSFDE63:
	.4byte	.LEFDE63-.LASFDE63
.LASFDE63:
	.4byte	.LASFDE63-.Lframe1
	.4byte	.LFB2074
	.4byte	.LFE2074-.LFB2074
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI125-.LFB2074
	.byte	0xe
	.uleb128 0x130
	.align	4
.LEFDE63:
.LSFDE65:
	.4byte	.LEFDE65-.LASFDE65
.LASFDE65:
	.4byte	.LASFDE65-.Lframe1
	.4byte	.LFB2117
	.4byte	.LFE2117-.LFB2117
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI126-.LFB2117
	.byte	0xe
	.uleb128 0xd0
	.align	4
.LEFDE65:
.LSFDE67:
	.4byte	.LEFDE67-.LASFDE67
.LASFDE67:
	.4byte	.LASFDE67-.Lframe1
	.4byte	.LFB2143
	.4byte	.LFE2143-.LFB2143
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI127-.LFB2143
	.byte	0xe
	.uleb128 0x100
	.align	4
.LEFDE67:
.LSFDE69:
	.4byte	.LEFDE69-.LASFDE69
.LASFDE69:
	.4byte	.LASFDE69-.Lframe1
	.4byte	.LFB2218
	.4byte	.LFE2218-.LFB2218
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI133-.LFB2218
	.byte	0xe
	.uleb128 0x1a0
	.align	4
.LEFDE69:
.LSFDE71:
	.4byte	.LEFDE71-.LASFDE71
.LASFDE71:
	.4byte	.LASFDE71-.Lframe1
	.4byte	.LFB2356
	.4byte	.LFE2356-.LFB2356
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI149-.LFB2356
	.byte	0xe
	.uleb128 0x90
	.align	4
.LEFDE71:
.LSFDE73:
	.4byte	.LEFDE73-.LASFDE73
.LASFDE73:
	.4byte	.LASFDE73-.Lframe1
	.4byte	.LFB2227
	.4byte	.LFE2227-.LFB2227
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI157-.LFB2227
	.byte	0xe
	.uleb128 0x2f0
	.align	4
.LEFDE73:
.LSFDE75:
	.4byte	.LEFDE75-.LASFDE75
.LASFDE75:
	.4byte	.LASFDE75-.Lframe1
	.4byte	.LFB2242
	.4byte	.LFE2242-.LFB2242
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI162-.LFB2242
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE75:
.LSFDE77:
	.4byte	.LEFDE77-.LASFDE77
.LASFDE77:
	.4byte	.LASFDE77-.Lframe1
	.4byte	.LFB2380
	.4byte	.LFE2380-.LFB2380
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI175-.LFB2380
	.byte	0xe
	.uleb128 0x220
	.align	4
.LEFDE77:
.LSFDE79:
	.4byte	.LEFDE79-.LASFDE79
.LASFDE79:
	.4byte	.LASFDE79-.Lframe1
	.4byte	.LFB2139
	.4byte	.LFE2139-.LFB2139
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI178-.LFB2139
	.byte	0xe
	.uleb128 0xe0
	.align	4
.LEFDE79:
.LSFDE81:
	.4byte	.LEFDE81-.LASFDE81
.LASFDE81:
	.4byte	.LASFDE81-.Lframe1
	.4byte	.LFB2244
	.4byte	.LFE2244-.LFB2244
	.uleb128 0x4
	.4byte	.LLSDA2244
	.byte	0x4
	.4byte	.LCFI179-.LFB2244
	.byte	0xe
	.uleb128 0x280
	.align	4
.LEFDE81:
.LSFDE83:
	.4byte	.LEFDE83-.LASFDE83
.LASFDE83:
	.4byte	.LASFDE83-.Lframe1
	.4byte	.LFB2307
	.4byte	.LFE2307-.LFB2307
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI185-.LFB2307
	.byte	0xe
	.uleb128 0x80
	.align	4
.LEFDE83:
.LSFDE85:
	.4byte	.LEFDE85-.LASFDE85
.LASFDE85:
	.4byte	.LASFDE85-.Lframe1
	.4byte	.LFB2308
	.4byte	.LFE2308-.LFB2308
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI186-.LFB2308
	.byte	0xe
	.uleb128 0x160
	.align	4
.LEFDE85:
.LSFDE87:
	.4byte	.LEFDE87-.LASFDE87
.LASFDE87:
	.4byte	.LASFDE87-.Lframe1
	.4byte	.LFB2416
	.4byte	.LFE2416-.LFB2416
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI187-.LFB2416
	.byte	0xe
	.uleb128 0x40
	.align	4
.LEFDE87:
.LSFDE89:
	.4byte	.LEFDE89-.LASFDE89
.LASFDE89:
	.4byte	.LASFDE89-.Lframe1
	.4byte	.LFB2381
	.4byte	.LFE2381-.LFB2381
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI189-.LFB2381
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE89:
.LSFDE91:
	.4byte	.LEFDE91-.LASFDE91
.LASFDE91:
	.4byte	.LASFDE91-.Lframe1
	.4byte	.LFB2382
	.4byte	.LFE2382-.LFB2382
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI190-.LFB2382
	.byte	0xe
	.uleb128 0x80
	.align	4
.LEFDE91:
.LSFDE93:
	.4byte	.LEFDE93-.LASFDE93
.LASFDE93:
	.4byte	.LASFDE93-.Lframe1
	.4byte	.LFB2383
	.4byte	.LFE2383-.LFB2383
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI191-.LFB2383
	.byte	0xe
	.uleb128 0x80
	.align	4
.LEFDE93:
.LSFDE95:
	.4byte	.LEFDE95-.LASFDE95
.LASFDE95:
	.4byte	.LASFDE95-.Lframe1
	.4byte	.LFB2384
	.4byte	.LFE2384-.LFB2384
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI192-.LFB2384
	.byte	0xe
	.uleb128 0x50
	.align	4
.LEFDE95:
.LSFDE97:
	.4byte	.LEFDE97-.LASFDE97
.LASFDE97:
	.4byte	.LASFDE97-.Lframe1
	.4byte	.LFB2385
	.4byte	.LFE2385-.LFB2385
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI193-.LFB2385
	.byte	0xe
	.uleb128 0x50
	.align	4
.LEFDE97:
.LSFDE99:
	.4byte	.LEFDE99-.LASFDE99
.LASFDE99:
	.4byte	.LASFDE99-.Lframe1
	.4byte	.LFB2406
	.4byte	.LFE2406-.LFB2406
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI211-.LFB2406
	.byte	0xe
	.uleb128 0xa0
	.align	4
.LEFDE99:
.LSFDE101:
	.4byte	.LEFDE101-.LASFDE101
.LASFDE101:
	.4byte	.LASFDE101-.Lframe1
	.4byte	.LFB2411
	.4byte	.LFE2411-.LFB2411
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI217-.LFB2411
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE101:
.LSFDE103:
	.4byte	.LEFDE103-.LASFDE103
.LASFDE103:
	.4byte	.LASFDE103-.Lframe1
	.4byte	.LFB2417
	.4byte	.LFE2417-.LFB2417
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI221-.LFB2417
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE103:
.LSFDE105:
	.4byte	.LEFDE105-.LASFDE105
.LASFDE105:
	.4byte	.LASFDE105-.Lframe1
	.4byte	.LFB2418
	.4byte	.LFE2418-.LFB2418
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI222-.LFB2418
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE105:
.LSFDE107:
	.4byte	.LEFDE107-.LASFDE107
.LASFDE107:
	.4byte	.LASFDE107-.Lframe1
	.4byte	.LFB2419
	.4byte	.LFE2419-.LFB2419
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI223-.LFB2419
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE107:
.LSFDE109:
	.4byte	.LEFDE109-.LASFDE109
.LASFDE109:
	.4byte	.LASFDE109-.Lframe1
	.4byte	.LFB2420
	.4byte	.LFE2420-.LFB2420
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI224-.LFB2420
	.byte	0xe
	.uleb128 0x20
	.align	4
.LEFDE109:
.LSFDE111:
	.4byte	.LEFDE111-.LASFDE111
.LASFDE111:
	.4byte	.LASFDE111-.Lframe1
	.4byte	.LFB2421
	.4byte	.LFE2421-.LFB2421
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI225-.LFB2421
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE111:
.LSFDE113:
	.4byte	.LEFDE113-.LASFDE113
.LASFDE113:
	.4byte	.LASFDE113-.Lframe1
	.4byte	.LFB2422
	.4byte	.LFE2422-.LFB2422
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI226-.LFB2422
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE113:
.LSFDE115:
	.4byte	.LEFDE115-.LASFDE115
.LASFDE115:
	.4byte	.LASFDE115-.Lframe1
	.4byte	.LFB2423
	.4byte	.LFE2423-.LFB2423
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI227-.LFB2423
	.byte	0xe
	.uleb128 0x30
	.align	4
.LEFDE115:
.LSFDE117:
	.4byte	.LEFDE117-.LASFDE117
.LASFDE117:
	.4byte	.LASFDE117-.Lframe1
	.4byte	.LFB2424
	.4byte	.LFE2424-.LFB2424
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI228-.LFB2424
	.byte	0xe
	.uleb128 0xa0
	.align	4
.LEFDE117:
.LSFDE119:
	.4byte	.LEFDE119-.LASFDE119
.LASFDE119:
	.4byte	.LASFDE119-.Lframe1
	.4byte	.LFB2427
	.4byte	.LFE2427-.LFB2427
	.uleb128 0x4
	.4byte	0
	.byte	0x4
	.4byte	.LCFI231-.LFB2427
	.byte	0xe
	.uleb128 0xb0
	.align	4
.LEFDE119:
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	__nedf2
	.global	__gxx_personality_v0
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	__udivdi3
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.global	memset
	.ident	"GCC: (crosstool-NG esp-14.2.0_20241119) 14.2.0"
