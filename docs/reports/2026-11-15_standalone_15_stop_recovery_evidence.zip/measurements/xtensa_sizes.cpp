#include "../../examples/probe_cli/ProbeApp.cpp"
extern "C" const size_t measured_sizes[] = {sizeof(App), sizeof(App::Record), sizeof(ActionResult)};
