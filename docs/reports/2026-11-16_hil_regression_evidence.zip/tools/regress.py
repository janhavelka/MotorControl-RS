#!/usr/bin/env python3
"""Standalone 14 bench regression of the current image, plus the missing routes.

Drives 1, 2 and 4, power and RS485 only, free shafts. Finite moves only.
Each step uses the maintained harness (bench_scenarios.py, bench_probe.py
functions); every reply is validated by its parser. A failing step stops the
run. No write is replayed; cleanup stops are new explicit stops.

Usage: regress.py OUT [STEP ...]   (default: every step in order)
"""
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
import bench_probe as bp  # noqa: E402
from bench_motion import profile_snapshot, restore_profile  # noqa: E402

FIRMWARE = ROOT / "build/multidrive3/image_baa91c9/firmware.bin"
OUT = pathlib.Path(sys.argv[1])
TERMINALS = ("x0", "x1", "x2", "x3", "y0", "y1")
TIMEOUT = 8.0


def scenario(name, *args):
    command = [sys.executable, str(ROOT / "scripts/bench_scenarios.py"), "--out", str(OUT / name),
               "--firmware", str(FIRMWARE), *args]
    with (OUT / f"{name}.stdout").open("w", encoding="utf-8") as stream:
        code = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT).returncode
    if code:
        raise SystemExit(f"{name} failed with exit {code}; see {name}.stdout")


def session(name, function, debug="raw"):
    path, attempt = OUT / f"{name}.jsonl", 1
    while path.exists():  # Keep every earlier attempt as evidence.
        attempt += 1
        path = OUT / f"{name}_try{attempt}.jsonl"
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        evidence = bp.Evidence(stream)
        port = bp.open_port("COM13", 115200, 5)
        try:
            console = bp.Console(port, on_event=evidence)
            console.drain_startup(0.3)
            console.identify(timeout_s=5)
            with bp.debug_session(console, debug, 5):
                result = function(console)
            memory = console.command("memory", timeout_s=5)
            console.emit("step_memory", step=name, memory=memory)
            return result
        finally:
            port.close()


def ok(console, command, **kwargs):
    result = console.command(command, timeout_s=kwargs.pop("timeout_s", TIMEOUT), **kwargs)
    if not result["ok"]:
        raise bp.BenchError(f"{command} {kwargs}: {result.get('result', result.get('outcome'))}")
    return result


def fresh(console, address=1):
    for read in ("read-config", "read-state"):
        ok(console, read, address=address)


def reset_controller(name):
    """RTS reset of the controller only (never the drives); retained host results start empty."""
    import serial
    import serial.tools.list_ports as list_ports
    port = serial.Serial()
    port.port, port.baudrate, port.dtr, port.rts = "COM13", 115200, False, True
    port.open()
    time.sleep(0.15)
    port.rts = False
    time.sleep(0.05)
    port.close()
    for _ in range(40):
        time.sleep(0.25)
        if any(p.device == "COM13" and p.serial_number == "3C:0F:02:CD:6B:98" for p in list_ports.comports()):
            break
    time.sleep(3.0)
    with (OUT / "resets.jsonl").open("a", encoding="utf-8") as log:
        log.write(json.dumps({"before": name, "t": time.time()}) + chr(10))


def memory(name):
    session(f"{name}_memory", lambda c: None, debug=None)


# Steps ---------------------------------------------------------------------
def s01_quick():
    scenario("s01_quick", "--scenario", "quick", "--count", "3")


def s02_typed():
    def run(c):
        bp.typed_read_campaign(c, kind="both", timeout_s=TIMEOUT, address=1)
        ok(c, "useaddr", address=1)
        ok(c, "velocity-read", address=1)
        ok(c, "home-read", address=1)
    session("s02_typed", run)


def s03_position():
    for phase in ("forward", "return", "absolute", "return"):
        scenario(f"s03_position_{phase}_{int(time.time()) % 100000}", "--scenario", "position", "--phase", phase)


def s04_stop():
    scenario("s04_stop_normal", "--scenario", "stop", "--stop-policy", "normal")
    scenario("s04_stop_fast", "--scenario", "stop", "--stop-policy", "fast")


def s05_actions():
    scenario("s05_actions", "--scenario", "actions")


def s06_interrupt():
    """Stored-profile retrigger of a running move; ACK is not arrival."""
    def run(c):
        fresh(c)
        snapshot = profile_snapshot(c, "read", TIMEOUT)
        move = c.begin("move-relative", move_args=("3000", "steps", "native", "60", "configured"),
                       address=1, timeout_s=20)
        time.sleep(1.0)
        interrupt = c.begin("position-interrupt", host_args=(str(move.operation_id),), timeout_s=8)
        interrupted = c.wait(interrupt)
        original = c.wait(move)
        c.emit("interrupt_results", interrupt=interrupted, original=original, snapshot=snapshot)
        stops = bp.cleanup_stop_attempts(c, policy="normal", address=1, timeout_s=TIMEOUT)
        state = bp.observe_stopped(c, address=1, timeout_s=TIMEOUT)
        c.emit("interrupt_cleanup", stops=stops, state=state)
        fresh(c)
        restore_profile(c, TIMEOUT)
        if interrupted.get("outcome") != "acknowledged":
            raise bp.BenchError("position interrupt was not acknowledged: " + str(interrupted.get("outcome")))
    session("s06_interrupt", run)


def s07_escalate_release():
    """stop fast escalates a running stop normal. A confirmed stop must not admit the
    failed-stop release route (R-17 is only for a stop that never confirmed standstill)."""
    def run(c):
        fresh(c)
        view = c.command("motion-profile", host_args=("inspect",), timeout_s=TIMEOUT)
        if view.get("saved") and view.get("original") != view.get("current"):
            restore_profile(c, TIMEOUT)  # Left changed by the first, stopped attempt.
            ok(c, "motion-profile", host_args=("forget",))
            fresh(c)
        profile_snapshot(c, "read", TIMEOUT)
        move = c.begin("move-relative", move_args=("6000", "steps", "native", "300", "configured"),
                       address=1, timeout_s=20)
        time.sleep(0.8)
        normal = c.begin("stop", stop_policy="normal", address=1)
        fast = c.begin("stop", stop_policy="fast", address=1)
        normal_result, fast_result = c.wait(normal), c.wait(fast)
        original = c.wait(move)
        state = bp.observe_stopped(c, address=1, timeout_s=TIMEOUT)
        c.emit("escalation", normal=normal_result, fast=fast_result, original=original, state=state)
        if not fast_result.get("ok") or normal_result.get("outcome") != "cancelled":
            raise bp.BenchError("stop fast escalation failed: " + str(fast_result.get("outcome")))
        refused = c.release_after_stop(fast.operation_id, mechanics_permit_release=True,
                                       triggers_inhibited=True, timeout_s=TIMEOUT)
        c.emit("release_after_confirmed_stop", result=refused)
        if refused["ok"] or refused.get("result") != "invalid":
            raise bp.BenchError("failed-stop release admitted a confirmed stop")
        for handle in (normal, fast, move):  # A later session cannot know these retained IDs.
            if not handle.released:
                c.command("release", operation_id=handle.operation_id, timeout_s=TIMEOUT)
        fresh(c)
        restore_profile(c, TIMEOUT)
    session("s07_escalate_release_b", run)


def s08_velocity():
    """Finite velocity with explicit stated facts, normal and fast stop endings."""
    for name, args in (("s08_velocity_60_normal", ("60", "rpm", "native", "1000", "configured", "normal")),
                       ("s08_velocity_60_fast", ("60", "rpm", "native", "1000", "configured", "fast"))):
        def run(c, args=args):
            ok(c, "useaddr", address=1)
            fresh(c)
            ok(c, "velocity-read", address=1)
            ok(c, "velocity-qualification-install", host_args=("rpm", "ramp", "inputs"))
            bp.velocity_campaign(c, velocity_args=args, cleanup_stop=args[-1], timeout_s=10, address=1)
        session(name, run)


def s09_position_clear():
    def run(c):
        fresh(c)
        before = ok(c, "read-state", address=1)
        ok(c, "position-clear-qualification-install", host_args=("clear-semantics",))
        cleared = ok(c, "position-clear", address=1)
        after = bp.observe_stopped(c, address=1, timeout_s=TIMEOUT)
        c.emit("position_clear", before=before, cleared=cleared, after=after)
    session("s09_position_clear", run)


def s10_settings():
    scenario("s10_settings_filter", "--scenario", "settings", "--setting", "input-filter", "--value", "3")
    scenario("s10_settings_delay", "--scenario", "settings", "--setting", "lock-delay", "--value", "201")


def s11_home():
    """Auxiliary 7, home 35, 34 and 33 at low rates, then auxiliary 0 restored last."""
    facts = ("mechanics", "rates", "ramp", "zero-offset", "auxiliary", "inputs")
    def aux(choice):
        def run(c):
            fresh(c)
            ok(c, "home-read", address=1)
            result = c.set_homing_auxiliary(choice, timeout_s=TIMEOUT)
            if not result["ok"]:
                raise bp.BenchError(f"home auxiliary {choice}: {result.get('outcome')}")
            fresh(c)
            ok(c, "home-read", address=1)
        return run
    session("s11_home_aux7", aux(7))
    for method, extra in (("35", ()), ("34", ("index",)), ("33", ("index",))):
        session(f"s11_home_{method}", lambda c, m=method, e=extra: bp.home_campaign(
            c, home_args=(m, "120", "60", "100", "zero"), facts=facts + e, wiring=(),
            cleanup_stop="normal", timeout_s=30, address=1))
    session("s11_home_aux0", aux(0))


def s12_drives():
    for a in (2, 4):
        scenario(f"s12_quick_a{a}", "--scenario", "quick", "--count", "2", "--address", str(a))
        for phase in ("forward", "return"):
            scenario(f"s12_position_{phase}_a{a}_{int(time.time()) % 100000}", "--scenario", "position",
                     "--phase", phase, "--address", str(a), "--declare-unconnected")
        scenario(f"s12_stop_fast_a{a}", "--scenario", "stop", "--stop-policy", "fast", "--address", str(a),
                 "--declare-unconnected")


def s13_group():
    def run(c):
        ok(c, "group-set", host_args=("1", "2", "4"), timeout_s=15)
        for a in (1, 2, 4):
            for t in TERMINALS:
                ok(c, "group-wiring", host_args=(str(a), t, "unconnected"))
        results = {}
        for mode in ("staged", "sequential"):
            ok(c, "group-read-state", timeout_s=10)
            results[mode] = ok(c, "group-move", host_args=("relative", "1000", "steps", "native", "120", "configured",
                                                           "start", mode, "on-failure", "stop", "fast"), timeout_s=30)
            time.sleep(2.0)
        ok(c, "group-read-state", timeout_s=10)
        ok(c, "group-plan-begin", host_args=("start", "staged", "on-failure", "stop", "fast"))
        ok(c, "group-plan-add", host_args=("1", "relative", "500", "steps", "native", "60", "configured"))
        ok(c, "group-plan-add", host_args=("2", "relative", "-1000", "steps", "native", "120", "configured"))
        ok(c, "group-plan-add", host_args=("4", "relative", "1500", "steps", "native", "180", "configured"))
        ok(c, "group-plan-show")
        results["plan"] = ok(c, "group-plan-submit", timeout_s=30)
        time.sleep(2.0)
        ok(c, "group-read-state", timeout_s=10)
        move = c.begin("group-move", host_args=("relative", "5000", "steps", "native", "120", "configured",
                                                "on-failure", "stop", "fast"), timeout_s=30)
        time.sleep(1.0)
        results["stop"] = ok(c, "group-stop", host_args=("fast",), timeout_s=10)
        results["stopped_move"] = c.wait(move)
        time.sleep(2.0)
        results["final"] = ok(c, "group-read-state", timeout_s=10)
        c.emit("group_results", results=results)
        ok(c, "group-clear")
    session("s13_group", run)


def s14_stress():
    out = OUT / "s14_stress_extended_10m"
    with (OUT / "s14_stress_extended_10m.stdout").open("w", encoding="utf-8") as stream:
        code = subprocess.run([sys.executable, str(ROOT / "scripts/bench_stress.py"), "--out", str(out),
                               "--duration", "600", "--seed", "81", "--mix", "extended", "--addresses", "1,2,4",
                               "--cross-reads", "--declare-unconnected"], stdout=stream, stderr=subprocess.STDOUT).returncode
    if code:
        raise SystemExit(f"s14 stress exit {code}")


def s15_candidates():
    """Equal archive stages unchanged with no write; one changed candidate, then the original."""
    wiring = tuple((t, "unconnected") for t in TERMINALS)
    archive_path, attempt = OUT / "s15_profile_archive.json", 1
    while archive_path.exists():  # Export needs a new file; keep earlier archives.
        attempt += 1
        archive_path = OUT / f"s15_profile_archive_try{attempt}.json"
    def release(result):  # One candidate slot: release each result once inspected.
        ok_release = c_ref[0].command("release", operation_id=result["operation_id"], timeout_s=TIMEOUT)
        if not ok_release["ok"]:
            raise bp.BenchError("candidate result release failed")
    c_ref = [None]
    def run(c):
        c_ref[0] = c
        ok(c, "probe", address=1)  # A checked probe establishes the known target after a reset.
        view = c.command("motion-profile", host_args=("inspect",), timeout_s=TIMEOUT)
        if view.get("saved"):
            ok(c, "motion-profile", host_args=("forget",))  # Snapshot left by an earlier attempt.
        archive = bp.profile_archive_campaign(c, action="export", path=archive_path, address=1, timeout_s=15)
        equal = bp.profile_archive_campaign(c, action="stage", path=archive_path, address=1, timeout_s=15,
                                            wiring=wiring)
        release(equal)
        changed = dict(archive)
        changed["words"] = list(archive["words"])
        accel = archive["words"][1]  # Acceleration time: one native step, kept inside 100..2000 ms.
        changed["words"][1] = accel - 1 if accel >= 2000 else accel + 1
        staged = bp.profile_archive_campaign(c, action="stage", path=archive_path, address=1, timeout_s=15,
                                             wiring=wiring, candidate=changed)
        release(staged)
        fresh(c)  # A possible candidate write expires the cached configuration.
        after_change = profile_snapshot(c, "read", TIMEOUT)
        ok(c, "motion-profile", host_args=("forget",))
        fresh(c)
        restored = bp.profile_archive_campaign(c, action="stage", path=archive_path, address=1, timeout_s=15,
                                               wiring=wiring)
        release(restored)
        fresh(c)
        final = profile_snapshot(c, "read", TIMEOUT)
        c.emit("candidate_results", archive=archive, equal=equal, changed=staged, after_change=after_change,
               restored=restored, final=final)
        if final["current"] != archive["words"]:
            raise bp.BenchError("profile not restored to the exported original")
        ok(c, "motion-profile", host_args=("forget",))
    session("s15_candidates", run)


def s16_start_speed():
    """Start speed write latches move admission until the relation is installed; restore last."""
    def run(c):
        ok(c, "probe", address=1)
        fresh(c)
        before = profile_snapshot(c, "read", TIMEOUT)
        original = before["current"][0]
        changed = c.set_position_start_speed(original + 1, timeout_s=TIMEOUT)
        fresh(c)
        profile_snapshot(c, "read", TIMEOUT)
        refused = c.command("move-relative", move_args=("100", "steps", "native", "60", "configured"),
                            address=1, timeout_s=TIMEOUT)
        relation = c.command("motion-profile-start-speed-relation", host_args=(str(original + 1), "1"),
                             timeout_s=TIMEOUT)
        restored = c.set_position_start_speed(original, timeout_s=TIMEOUT)
        fresh(c)
        final = profile_snapshot(c, "read", TIMEOUT)
        relation_final = c.command("motion-profile-start-speed-relation", host_args=(str(original), "1"),
                                   timeout_s=TIMEOUT)
        c.emit("start_speed_results", before=before, changed=changed, refused_move=refused, relation=relation,
               restored=restored, final=final, relation_final=relation_final)
        if refused.get("ok") or final["current"][0] != original:
            raise bp.BenchError("start-speed latch or restoration failed")
    session("s16_start_speed", run)


STEPS = [s01_quick, s02_typed, s03_position, s04_stop, s05_actions, s06_interrupt, s07_escalate_release,
         s08_velocity, s09_position_clear, s10_settings, s11_home, s12_drives, s13_group, s14_stress,
         s15_candidates, s16_start_speed]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    wanted = sys.argv[2:]
    with (OUT / "steps.jsonl").open("a", encoding="utf-8") as log:
        for step in STEPS:
            if wanted and step.__name__ not in wanted:
                continue
            started = time.time()
            try:
                step()
                memory(step.__name__)
                status = "pass"
            except BaseException as error:  # Record, then stop the run.
                status = f"fail: {error}"
            log.write(json.dumps({"step": step.__name__, "status": status, "seconds": round(time.time() - started, 1)}) + "\n")
            log.flush()
            print(step.__name__, status, flush=True)
            if status != "pass":
                return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
