"""Qualified position clear on drives 2 and 4 so the absolute phases' fixture window applies."""
import importlib.util, json, pathlib, sys
HERE = pathlib.Path(__file__).resolve().parent
sys.argv = [sys.argv[0], str(HERE.parent / "31_regress_fixed")]
spec = importlib.util.spec_from_file_location("regress", HERE / "regress.py"); r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
def run(c):
    for a in (2, 4):
        r.ok(c, "useaddr", address=a)
        for t in r.TERMINALS:
            r.ok(c, "wiring", host_args=(t, "unconnected"))
        r.ok(c, "probe", address=a)
        r.fresh(c, a)
        before = r.ok(c, "read-state", address=a)
        r.ok(c, "position-clear-qualification-install", host_args=("clear-semantics",))
        cleared = r.ok(c, "position-clear", address=a)
        after = r.bp.observe_stopped(c, address=a, timeout_s=r.TIMEOUT)
        pos = lambda s: [b.get("position_words") for b in s.get("state_blocks", []) if "position_words" in b]
        c.emit("position_clear", address=a, before=before, cleared=cleared, after=after)
        print(a, pos(before), "->", pos(after))
    r.ok(c, "useaddr", address=1)
r.session("clear24", run)
