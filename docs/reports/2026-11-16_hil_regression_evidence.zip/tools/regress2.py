#!/usr/bin/env python3
"""Multi-drive 06 items runnable on this bench, stack diagnostic and drive 2/4 settings.

Same rules as regress.py. Usage: regress2.py OUT [STEP ...]
"""
import importlib.util
import json
import pathlib
import statistics
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("regress", HERE / "regress.py")
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
bp, ok, session, scenario, TERMINALS = r.bp, r.ok, r.session, r.scenario, r.TERMINALS
OUT = r.OUT


def stack(c, label, log):
    memory = c.command("memory", timeout_s=5)
    log.append((label, memory.get("stack_free_bytes")))


def declare(c):
    ok(c, "group-set", host_args=("1", "2", "4"), timeout_s=15)
    for a in (1, 2, 4):
        for t in TERMINALS:
            ok(c, "group-wiring", host_args=(str(a), t, "unconnected"))


def t01_stack():
    """Stack low-water mark after each group command type, from a fresh controller reset."""
    r.reset_controller("t01_stack")
    def run(c):
        log = []
        stack(c, "after reset", log)
        for a in (1, 2, 4):
            ok(c, "probe", address=a)
        stack(c, "probes", log)
        declare(c)
        stack(c, "group set + wiring", log)
        ok(c, "group-read-state", timeout_s=10)
        stack(c, "group read state", log)
        ok(c, "group-show")
        ok(c, "group-status")
        stack(c, "group show/status", log)
        ok(c, "group-move", host_args=("relative", "200", "steps", "native", "60", "configured", "start", "sequential",
                                       "on-failure", "stop", "fast"), timeout_s=30)
        stack(c, "group move sequential", log)
        time.sleep(2.0)
        ok(c, "group-read-state", timeout_s=10)
        ok(c, "group-move", host_args=("relative", "200", "steps", "native", "60", "configured", "start", "staged",
                                       "on-failure", "stop", "fast"), timeout_s=30)
        stack(c, "group move staged", log)
        time.sleep(2.0)
        ok(c, "group-read-state", timeout_s=10)
        ok(c, "group-plan-begin", host_args=("start", "staged", "on-failure", "stop", "fast"))
        for a, v in ((1, "-200"), (2, "-200"), (4, "-200")):
            ok(c, "group-plan-add", host_args=(str(a), "relative", v, "steps", "native", "60", "configured"))
        ok(c, "group-plan-show")
        stack(c, "group plan begin/add/show", log)
        ok(c, "group-plan-submit", timeout_s=30)
        stack(c, "group plan submit", log)
        time.sleep(2.0)
        ok(c, "group-read-state", timeout_s=10)
        move = c.begin("group-move", host_args=("relative", "5000", "steps", "native", "120", "configured",
                                                "on-failure", "stop", "fast"), timeout_s=30)
        time.sleep(1.0)
        ok(c, "group-stop", host_args=("normal",), timeout_s=10)
        c.wait(move)
        stack(c, "group stop", log)
        c.emit("stack_log", log=log)
        print(json.dumps(log))
    session("t01_stack", run)


def t02_absent_member():
    """group set rejects an absent member before any write; the missing reply needs recover."""
    def run(c):
        result = c.command("group-set", host_args=("1", "2", "3"), timeout_s=15)
        c.emit("absent_member", result=result)
        if result.get("ok"):
            raise bp.BenchError("group set admitted an absent member")
        members = result.get("members") or []
        c.emit("absent_member_members", members=members)
        drv = c.command("drv", timeout_s=5)
        if drv.get("recovery_required"):
            recovered = c.command("recover", timeout_s=8)
            c.emit("recover_after_absent", result=recovered)
        shown = ok(c, "group-show")
        if shown.get("count"):
            raise bp.BenchError("a group remained after the rejected declaration")
        for a in (1, 2, 4):
            ok(c, "probe", address=a)
    session("t02_absent_member", run)


def t03_group50():
    """25 staged and 25 sequential group moves, then 5 group stops of each kind."""
    r.reset_controller("t03_group50")  # Start without results retained by earlier sessions.
    def run(c):
        for a in (1, 2, 4):
            ok(c, "probe", address=a)
        declare(c)
        rows = []
        for i in range(50):
            mode = "staged" if i % 2 == 0 else "sequential"
            steps = ("1000", "-1000")[(i // 2) % 2]
            ok(c, "group-read-state", timeout_s=10)
            g = ok(c, "group-move", host_args=("relative", steps, "steps", "native", "120", "configured", "start", mode,
                                               "on-failure", "stop", "fast"), timeout_s=30)
            members = [{k: m.get(k) for k in ("address", "start", "completion", "start_tx_end_us", "running_earliest_us",
                                               "running_latest_us", "effective_native", "stage", "stage_readback")}
                       for m in g["members"]]
            rows.append({"n": i + 1, "mode": mode, "steps": int(steps), "spread_us": g.get("start_tx_spread_us"),
                         "running_bound_spread_us": g.get("running_bound_spread_us"), "members": members})
            if g.get("operation_id"):
                c.command("release", operation_id=g["operation_id"], timeout_s=5)
            time.sleep(1.6)
        stops = []
        for policy in ("normal",) * 5 + ("fast",) * 5:
            ok(c, "group-read-state", timeout_s=10)
            before = {m["address"]: m.get("raw_position") for m in ok(c, "group-status")["members"]}
            move = c.begin("group-move", host_args=("relative", "5000", "steps", "native", "120", "configured",
                                                    "on-failure", "stop", "fast"), timeout_s=30)
            time.sleep(1.0)
            stop = ok(c, "group-stop", host_args=(policy,), timeout_s=10)
            moved = c.wait(move)
            time.sleep(2.0)
            after = ok(c, "group-read-state", timeout_s=10)
            positions = {m["address"]: m.get("raw_position") for m in after["members"]}
            stops.append({"policy": policy, "stop_ok": stop.get("ok"),
                          "members": [(m["address"], m.get("outcome"), m.get("completion")) for m in stop["members"]],
                          "move_members": [(m["address"], m.get("start"), m.get("interrupted_by_stop")) for m in moved["members"]],
                          "positions_after": positions})
            if moved.get("operation_id"):
                c.command("release", operation_id=moved["operation_id"], timeout_s=5)
        summary = {}
        for mode in ("staged", "sequential"):
            spreads = [x["spread_us"] for x in rows if x["mode"] == mode]
            summary[mode] = {"count": len(spreads), "min": min(spreads), "median": statistics.median(spreads),
                             "max": max(spreads), "all_started": all(m["start"] == "started" and m["completion"] == "observed"
                                                                    for x in rows if x["mode"] == mode for m in x["members"])}
        c.emit("group50", rows=rows, stops=stops, summary=summary)
        print(json.dumps(summary))
        print(json.dumps([(s["policy"], s["stop_ok"]) for s in stops]))
        ok(c, "group-clear")
        if not all(v["all_started"] for v in summary.values()) or not all(s["stop_ok"] for s in stops):
            raise bp.BenchError("a group move or stop did not complete on every member")
    session("t03_group50", run)


def t04_enable_wait():
    """Per drive: enable to an enabled drive, a move within 1 s is refused before TX, one after it runs."""
    def run(c):
        results = []
        for a in (1, 2, 4):
            ok(c, "useaddr", address=a)
            for t in TERMINALS:
                ok(c, "wiring", host_args=(t, "unconnected"))
            ok(c, "probe", address=a)
            r.fresh(c, a)
            r.profile_snapshot(c, "read", r.TIMEOUT)
            enabled = ok(c, "enable", address=a)
            r.fresh(c, a)
            stats_before = c.command("stats", timeout_s=5)
            early = c.command("move-relative", move_args=("100", "steps", "native", "60", "configured"), address=a,
                              timeout_s=r.TIMEOUT)
            stats_after = c.command("stats", timeout_s=5)
            time.sleep(1.2)
            r.fresh(c, a)
            late = c.command("move-relative", move_args=("100", "steps", "native", "60", "configured"), address=a,
                             timeout_s=15)
            r.fresh(c, a)
            back = c.command("move-relative", move_args=("-100", "steps", "native", "60", "configured"), address=a,
                             timeout_s=15)
            r.fresh(c, a)
            r.restore_profile(c, r.TIMEOUT)
            ok(c, "motion-profile", host_args=("forget",))
            results.append({"address": a, "enable": enabled.get("outcome"), "early": early.get("result"),
                            "early_tx_frames": (stats_after.get("started", 0) - stats_before.get("started", 0)),
                            "late": late.get("ok"), "back": back.get("ok")})
            if early.get("ok") or not late.get("ok") or not back.get("ok"):
                raise bp.BenchError(f"enable wait check failed on drive {a}: {results[-1]}")
        c.emit("enable_wait", results=results)
        print(json.dumps(results))
    session("t04_enable_wait", run)


def t05_settings_24():
    for a in (2, 4):
        r.scenario(f"t05_settings_filter_a{a}", "--scenario", "settings", "--setting", "input-filter", "--value", "3",
                   "--address", str(a), "--declare-unconnected")
        r.scenario(f"t05_settings_delay_a{a}", "--scenario", "settings", "--setting", "lock-delay", "--value", "201",
                   "--address", str(a), "--declare-unconnected")


def t06_guard_per_address():
    """Revoked drive 2 needs its own relation; unrevoked drive 1 moves freely; reselecting
    drive 2 needs the relation again. Drives 2 and 4 were revoked by their candidate
    restorations in the 30_m04 runs; drive 1 was not touched since the flash."""
    MOVE = ("100", "steps", "native", "60", "configured")
    BACK = ("-100", "steps", "native", "60", "configured")
    def select(c, a):
        ok(c, "useaddr", address=a)
        for t in TERMINALS:
            ok(c, "wiring", host_args=(t, "unconnected"))
        ok(c, "probe", address=a)
        r.fresh(c, a)
        return r.profile_snapshot(c, "read", r.TIMEOUT)["current"][0]
    def finish(c, a):
        r.fresh(c, a)
        r.restore_profile(c, r.TIMEOUT)
        ok(c, "motion-profile", host_args=("forget",))
    def run(c):
        out = {}
        word = select(c, 2)
        out["drive2_refused"] = c.command("move-relative", move_args=MOVE, address=2, timeout_s=15)
        out["drive2_relation"] = c.command("motion-profile-start-speed-relation", host_args=(str(word), "1"), timeout_s=r.TIMEOUT)
        r.fresh(c, 2)
        out["drive2_move"] = c.command("move-relative", move_args=MOVE, address=2, timeout_s=15)
        r.fresh(c, 2)
        out["drive2_back"] = c.command("move-relative", move_args=BACK, address=2, timeout_s=15)
        finish(c, 2)
        select(c, 1)
        out["drive1_move"] = c.command("move-relative", move_args=MOVE, address=1, timeout_s=15)
        r.fresh(c, 1)
        out["drive1_back"] = c.command("move-relative", move_args=BACK, address=1, timeout_s=15)
        finish(c, 1)
        select(c, 2)
        out["drive2_refused_again"] = c.command("move-relative", move_args=MOVE, address=2, timeout_s=15)
        ok(c, "motion-profile", host_args=("forget",))
        ok(c, "useaddr", address=1)
        c.emit("guard_per_address", **out)
        summary = {k: (v.get("result"), v.get("ok"), v.get("outcome")) for k, v in out.items()}
        print(json.dumps(summary))
        expected = {"drive2_refused": False, "drive2_relation": True, "drive2_move": True, "drive2_back": True,
                    "drive1_move": True, "drive1_back": True, "drive2_refused_again": False}
        if any(bool(out[k].get("ok")) != v for k, v in expected.items()):
            raise bp.BenchError("start-speed guard is not kept per address")
    session("t06_guard_per_address_b", run)


STEPS = [t01_stack, t02_absent_member, t03_group50, t04_enable_wait, t05_settings_24, t06_guard_per_address]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    wanted = sys.argv[2:]
    with (OUT / "steps.jsonl").open("a", encoding="utf-8") as log:
        for step in STEPS:
            if wanted and step.__name__ not in wanted:
                continue
            started = time.time()
            try:
                step()
                status = "pass"
            except BaseException as error:
                status = f"fail: {error}"
            log.write(json.dumps({"step": step.__name__, "status": status, "seconds": round(time.time() - started, 1)}) + "\n")
            print(step.__name__, status, flush=True)
            if status != "pass":
                return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
