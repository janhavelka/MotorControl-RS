#!/usr/bin/env python3
"""Read-only power-up snapshot of drives 1, 2 and 4 after the owner's motor power cycle.

Sends only FC03 reads (and host-only useaddr/forget). Every terminal line is
kept. No write, move, save or recovery is sent. A refused or failed read is
recorded and the next read runs; nothing is retried.
"""
import importlib.util
import json
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("broadcast_trials", HERE / "broadcast_trials.py")
trials = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trials)

READS = ["probe {a}", "read identity {a}", "read config {a}", "read state {a}", "io read {a}",
         "tuning filters read {a}", "control read {a}", "driver read {a}", "home read {a}",
         "velocity read {a}", "motion-profile read"]


def main():
    out = pathlib.Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=False)
    log = open(out / "console.jsonl", "w", encoding="utf-8")
    results = open(out / "reads.jsonl", "w", encoding="utf-8")
    c = trials.Logged("COM13", out, log)
    try:
        c.pump(0.5)
        for command in ("version", "memory", "drv", "status"):
            results.write(json.dumps({"command": command, "reply": c.send(command, 3.0)}) + "\n")
        for a in (1, 2, 4):
            view = c.send("motion-profile inspect", 2.0)
            if view.get("saved"):
                c.send("motion-profile forget", 2.0)
            results.write(json.dumps({"address": a, "command": "useaddr", "reply": c.send(f"useaddr {a}", 2.0)}) + "\n")
            for template in READS:
                command = template.format(a=a)
                reply = c.send(command, 3.0)
                item = None
                if command == "motion-profile read":
                    for _ in range(200):
                        c.pump(0.01)
                        item = c.send("motion-profile inspect", 2.0)
                        if not item.get("pending"):
                            break
                elif reply.get("ok") and reply.get("result") == "accepted":
                    item = c.terminal(reply, 4.0)
                c.release_all()
                results.write(json.dumps({"address": a, "command": command, "reply": reply, "terminal": item}) + "\n")
                results.flush()
                print(a, command, reply.get("result"), (item or {}).get("ok"), (item or {}).get("outcome"))
            view = c.send("motion-profile inspect", 2.0)
            if view.get("saved"):
                c.send("motion-profile forget", 2.0)
        results.write(json.dumps({"command": "memory", "reply": c.send("memory", 3.0)}) + "\n")
    finally:
        log.close()
        results.close()
        c.close()


if __name__ == "__main__":
    main()
