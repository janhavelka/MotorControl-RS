"""Restore homing auxiliary 0 on drives 1, 2 and 4 with checked readback."""
import importlib.util, json, pathlib, sys
HERE = pathlib.Path(__file__).resolve().parent
sys.argv = [sys.argv[0], str(HERE.parent / "41_aux_restore")]
spec = importlib.util.spec_from_file_location("regress", HERE / "regress.py"); r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
r.OUT.mkdir(parents=True, exist_ok=True)
def run(c):
    for a in (2, 4, 1):
        r.ok(c, "useaddr", address=a)
        for t in r.TERMINALS:
            r.ok(c, "wiring", host_args=(t, "unconnected"))
        r.ok(c, "probe", address=a)
        r.fresh(c, a)
        r.ok(c, "home-read", address=a)
        result = c.set_homing_auxiliary(0, timeout_s=r.TIMEOUT)
        r.fresh(c, a)
        after = r.ok(c, "home-read", address=a)
        print(a, result.get("ok"), result.get("outcome"), after["homing_parameters"]["raw_auxiliary"])
        if not result.get("ok") or after["homing_parameters"]["raw_auxiliary"] != 0:
            raise r.bp.BenchError(f"auxiliary restore failed on {a}")
r.session("aux0_all", run)
