"""Confirm the cause: with drive 4's own start-speed relation installed, its move is admitted."""
import importlib.util, json, pathlib, sys
HERE = pathlib.Path(__file__).resolve().parent
sys.argv = [sys.argv[0], str(HERE.parent / "22_diag_a4_move")]
spec = importlib.util.spec_from_file_location("regress", HERE / "regress.py"); r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
def run(c):
    out = {}
    r.ok(c, "useaddr", address=4)
    r.ok(c, "probe", address=4)
    r.fresh(c, 4)
    snap = r.profile_snapshot(c, "read", r.TIMEOUT)
    out["refused_again"] = c.command("move-relative", move_args=("100", "steps", "native", "60", "configured"), address=4, timeout_s=15)
    out["relation"] = c.command("motion-profile-start-speed-relation", host_args=(str(snap["current"][0]), "1"), timeout_s=8)
    r.fresh(c, 4)
    out["with_relation"] = c.command("move-relative", move_args=("100", "steps", "native", "60", "configured"), address=4, timeout_s=15)
    r.fresh(c, 4)
    out["back"] = c.command("move-relative", move_args=("-100", "steps", "native", "60", "configured"), address=4, timeout_s=15)
    r.fresh(c, 4)
    r.restore_profile(c, r.TIMEOUT)
    r.ok(c, "motion-profile", host_args=("forget",))
    c.emit("diag_a4_relation", start_word=snap["current"][0], **out)
    print(json.dumps({k: (v.get("result"), v.get("ok"), v.get("outcome")) for k, v in out.items()}))
r.session("diag_a4_relation", run)
