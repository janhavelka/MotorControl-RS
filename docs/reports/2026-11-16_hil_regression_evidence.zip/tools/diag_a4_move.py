"""Why was drive 4's finite move unavailable after the M04 I/O round trips? Bounded, no replay."""
import importlib.util, json, pathlib, sys, time
HERE = pathlib.Path(__file__).resolve().parent
sys.argv = [sys.argv[0], str(HERE.parent / "22_diag_a4_move")]
spec = importlib.util.spec_from_file_location("regress", HERE / "regress.py"); r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
r.OUT.mkdir(parents=True, exist_ok=True)
def run(c):
    out = {}
    out["status"] = c.command("status", timeout_s=5)
    out["health"] = c.command("health", timeout_s=5)
    view = c.command("motion-profile", host_args=("inspect",), timeout_s=5)
    if view.get("saved"):
        r.ok(c, "motion-profile", host_args=("forget",))
    r.ok(c, "useaddr", address=4)
    for t in r.TERMINALS:
        r.ok(c, "wiring", host_args=(t, "unconnected"))
    r.fresh(c, 4)
    r.profile_snapshot(c, "read", r.TIMEOUT)
    r.ok(c, "read-state", address=4)
    out["without_probe"] = c.command("move-relative", move_args=("100", "steps", "native", "60", "configured"), address=4, timeout_s=15)
    if not out["without_probe"].get("ok"):
        out["probe"] = r.ok(c, "probe", address=4)
        r.fresh(c, 4)
        out["with_probe"] = c.command("move-relative", move_args=("100", "steps", "native", "60", "configured"), address=4, timeout_s=15)
    r.fresh(c, 4)
    out["back"] = c.command("move-relative", move_args=("-100", "steps", "native", "60", "configured"), address=4, timeout_s=15)
    r.fresh(c, 4)
    r.restore_profile(c, r.TIMEOUT)
    r.ok(c, "motion-profile", host_args=("forget",))
    c.emit("diag_a4", **{k: v for k, v in out.items()})
    print(json.dumps({k: (v.get("result"), v.get("ok"), v.get("outcome")) for k, v in out.items() if isinstance(v, dict)}))
    print("health", out["health"].get("communication"), out["health"].get("probe_address"), out["health"].get("model_address"))
r.session("diag_a4_move", run)
