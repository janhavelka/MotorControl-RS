"""Pack named evidence paths with a SHA-256 manifest: pack.py TARGET MANIFEST PATH..."""
import hashlib, os, sys, zipfile
target, manifest, paths = sys.argv[1], sys.argv[2], sys.argv[3:]
members = []
for path in paths:
    if os.path.isdir(path):
        for root, _, files in os.walk(path):
            members += [os.path.join(root, f).replace(os.sep, '/') for f in files]
    else:
        members.append(path.replace(os.sep, '/'))
members = sorted(set(members))
with open(manifest, 'w', newline='\n') as m:
    for path in members:
        m.write(hashlib.sha256(open(path, 'rb').read()).hexdigest() + '  ' + path + '\n')
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in members + [manifest]:
        z.write(path)
print(len(members) + 1, os.path.getsize(target))
