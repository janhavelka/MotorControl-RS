#!/usr/bin/env python3
"""Root cause of RX_ERROR in the first broadcast silent window.

Bounded and deliberate. Competing causes: the drives answer address 0 and
collide, or the undriven, unbiased bus produces UART errors by itself.
  1. stats: UART error count after the failed trial; recover.
  2. Each drive's 0x0021: did it apply the failed broadcast (301)?
  3. Control: probe the absent address 3 three times. The bus is undriven for
     the 200 ms response timeout with no broadcast. NO_RESPONSE plus an
     unchanged UART error count means an idle bus alone stays quiet.
  4. Three deliberate repeats, 300, 301, 300 (ending on the staged value),
     each followed by stats, recover and a readback of every drive.
Nothing is resent automatically; each frame is a separate stated trial.
"""
import importlib.util
import json
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("broadcast_trials", HERE / "broadcast_trials.py")
trials = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trials)

out = pathlib.Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=False)
log = open(out / "console.jsonl", "w", encoding="utf-8")
console = trials.Logged("COM13", out, log)
run = trials.Bench(console, out)


def stats(label):
    s = console.send("stats", 2.0)
    d = console.send("drv", 2.0)
    entry = {k: s.get(k) for k in ("started", "frames", "failed", "timeouts", "rx_bytes", "capture_faults", "rx_errors")}
    entry.update(phase=d.get("phase"), recovery_required=d.get("recovery_required"))
    run.record("stats", dict(entry, label=label))
    return entry


def recover(label):
    reply = console.send("recover", 2.0)
    item = console.terminal(reply, 3.0) if reply.get("ok") else None
    console.release_all()
    run.record("recover", {"label": label, "reply": reply.get("result"),
                           "outcome": item and (item.get("outcome") or item.get("recovery_outcome"))})


def profiles(label):
    run.selected = None
    values = {a: run.profile(a) for a in trials.ADDRESSES}
    run.record("profiles", {"label": label, "accel": {a: v[1] for a, v in values.items()}, "profiles": values})
    return values


try:
    console.pump(0.3)
    run.record("setup", {"version": console.send("version", 3.0)})
    console.send("debug raw", 2.0)
    stats("after failed trial A1")
    recover("after failed trial A1")
    stats("after recover")
    profiles("after failed trial A1")
    for n in range(3):
        before = stats(f"control {n} before")
        reply = console.send("probe 3", 2.0)
        item = console.terminal(reply, 3.0) if reply.get("ok") else None
        console.release_all()
        after = stats(f"control {n} after")
        run.record("control", {"n": n, "transport": item and item.get("transport"), "outcome": item and item.get("outcome"),
                               "rx_bytes": item and item.get("rx_bytes"), "rx_errors_delta": after["rx_errors"] - before["rx_errors"]})
        if after["recovery_required"]:
            recover(f"control {n}")
    for n, value in enumerate((300, 301, 300)):
        before = stats(f"repeat {n} before")
        reply = console.send(f"broadcast accel {value}", 2.0)
        item = console.terminal(reply, 3.0) if reply.get("ok") else None
        console.release_all()
        after = stats(f"repeat {n} after")
        run.record("repeat", {"n": n, "value": value, "reply": reply.get("result"),
                              "item": {k: item.get(k) for k in ("outcome", "transport", "rx_hex", "tx_end_us", "ended_us",
                                                                 "first_rx_start_us")} if item else None,
                              "error_after_tx_end_us": item and item.get("ended_us", 0) - item.get("tx_end_us", 0),
                              "rx_errors_delta": after["rx_errors"] - before["rx_errors"]})
        if after["recovery_required"]:
            recover(f"repeat {n}")
        profiles(f"after repeat {n} ({value})")
finally:
    try:
        console.send("debug off", 2.0)
    except Exception:
        pass
    log.close()
    console.close()
