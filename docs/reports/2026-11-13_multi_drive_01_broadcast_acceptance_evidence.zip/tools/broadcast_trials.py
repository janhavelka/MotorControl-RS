#!/usr/bin/env python3
"""Multi-drive 01: does ESS firmware 0x0029 accept address-0 broadcast writes?

Bench: drives 1, 2 and 4 on one RS485 bus, power and RS485 only, free shafts.
Trial counts are fixed in advance. Each broadcast is sent once and never resent.
  state  identity (0x0002 active node, 0x0003 DIP) and config (0x0013 custom node) per drive
  A      20 RAM writes of 0x0021, alternating 301 and 300 ms, every drive read back
  B      10 relative starts; every drive repeats its staged +200-increment move
  C      10 stop normal + 10 stop fast during a unicast +5000 move; the moving drive rotates
  D      5 stop normal + 5 stop fast during a broadcast start of +5000 on all three drives
Prepared fallback: one unicast `stop fast` per drive, sent only when a drive still runs
after the stated bound. That is a new explicit stop, recorded as a failed trial.
The campaign stops at the first alarm, window byte, unexpected motion or settings loss.
Nothing is saved; all changes are RAM values.
"""
import argparse
import importlib.util
import json
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[3]
spec = importlib.util.spec_from_file_location("bench_stress", ROOT / "build/multidrive2/snap/scripts/bench_stress.py")
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)

ADDRESSES = (1, 2, 4)
RUNNING, ARRIVED = bench.RUNNING, bench.ARRIVED
SMALL, LONG, SPEED, LONG_SPEED, RAMP = 200, 5000, 60, 120, 300


class Stop(Exception):
    """Campaign stop: state is captured, nothing further is sent except restoration."""


class Logged(bench.Console):
    def __init__(self, port, out, log):
        self.log = log
        super().__init__(port, out)

    def feed(self, text):
        self.log.write(json.dumps({"t": round(time.time(), 4), "rx": text}) + "\n")
        super().feed(text)

    def send(self, command, wait=1.5):
        self.log.write(json.dumps({"t": round(time.time(), 4), "tx": f"@{self.next_id} {command}"}) + "\n")
        self.log.flush()
        return super().send(command, wait)

    def simple(self, command, wait):
        self.log.write(json.dumps({"t": round(time.time(), 4), "tx": f"@{self.next_id} {command}"}) + "\n")
        return super().simple(command, wait)


class Bench:
    def __init__(self, console, out):
        self.c, self.out, self.selected = console, out, None
        self.windows = []
        self.trials = open(out / "trials.jsonl", "a", encoding="utf-8")
        self.summary = {"started": time.time(), "parts": {}}

    def record(self, part, entry):
        entry = dict(entry, part=part, t=round(time.time(), 3))
        self.trials.write(json.dumps(entry) + "\n")
        self.trials.flush()
        print(json.dumps(entry)[:600])
        sys.stdout.flush()

    # Console helpers
    def ok(self, command, wait=2.0):
        reply = self.c.send(command, wait)
        if not reply.get("ok"):
            raise Stop(f"{command}: {reply.get('result')}")
        return reply

    def finish(self, command, wait=5.0):
        reply = self.ok(command)
        item = self.c.terminal(reply, wait)
        self.c.release_all()
        if item is None:
            raise Stop(f"{command}: no terminal")
        return item

    def select(self, address):
        if self.selected == address:
            return
        self.c.release_all()
        view = self.c.send("motion-profile inspect")
        if view.get("saved"):
            self.ok("motion-profile forget")
        self.ok(f"useaddr {address}")
        for terminal in ("x0", "x1", "x2", "x3", "y0", "y1"):
            self.ok(f"wiring {terminal} unconnected")  # Owner fact: only power and RS485 are wired.
        # A broadcast clears every known target; a checked probe re-establishes it.
        if not self.finish(f"probe {address}", 3.0).get("ok"):
            raise Stop(f"probe {address} failed")
        self.selected = address

    def state(self, address):
        item = self.finish(f"read state {address}", 2.0)
        if not item.get("ok"):
            raise Stop(f"read state {address}: {item.get('outcome')}")
        fields = bench.state_fields(item)
        fields["started_us"], fields["serviced_us"] = item.get("started_us"), item.get("serviced_us")
        return fields

    def profile(self, address):
        """0x0020/6 by unicast: start speed, accel, decel, speed, target hi, target lo."""
        self.select(address)
        self.finish("read config", 3.0)
        self.state(address)
        self.ok("motion-profile read")
        for _ in range(200):
            self.c.pump(0.01)
            view = self.c.send("motion-profile inspect")
            if not view.get("pending"):
                break
        if not view.get("session_ok", view.get("ok")) or view.get("error") not in (None, "none"):
            raise Stop(f"profile {address}: {view.get('error')}")
        self.ok("motion-profile forget")
        return view.get("current")

    def broadcast(self, frame):
        """One frame, once. Returns the terminal.

        The 13 November diagnostic showed every drive answers address 0, so the
        window is expected to fail (RX_ERROR from colliding replies, or
        UNEXPECTED_RX). That is recorded per trial, followed by an explicit
        transport recovery; the drives are then read back by unicast. Any other
        outcome stops the campaign. Nothing is resent.
        """
        reply = self.c.send(f"broadcast {frame}", 2.0)
        if not reply.get("ok"):
            raise Stop(f"broadcast {frame}: {reply.get('result')}")
        item = self.c.terminal(reply, 3.0)
        self.c.release_all()
        if item is None:
            raise Stop(f"broadcast {frame}: no terminal")
        window = {k: item.get(k) for k in ("outcome", "transport", "rx_hex", "tx_end_us", "first_rx_start_us", "ended_us")}
        self.windows.append(dict(window, frame=frame))
        if item.get("outcome") == "sent" and not item.get("rx_bytes"):
            return item
        if item.get("transport") not in ("RX_ERROR", "UNEXPECTED_RX"):
            raise Stop({"broadcast": frame, "window": window})
        recovered = self.c.send("recover", 2.0)
        result = self.c.terminal(recovered, 3.0) if recovered.get("ok") else None
        self.c.release_all()
        if not result or (result.get("outcome") or result.get("recovery_outcome")) != "recovered":
            raise Stop({"broadcast": frame, "recover": recovered.get("result"), "result": result})
        self.selected = None  # Recovery keeps the selection, but re-check it before the next write.
        return item

    def all_states(self):
        return {a: self.state(a) for a in ADDRESSES}

    def check_quiet(self, states, label):
        for a, f in states.items():
            if f.get("raw_alarm") or f.get("raw_motion", 0) & RUNNING:
                raise Stop({"label": label, "address": a, "state": f})

    def simple_move(self, address, steps, rpm):
        self.select(address)
        for command in (f"speed {rpm}", f"accel {RAMP}", f"decel {RAMP}"):
            self.ok(command)
        item = self.c.simple(f"moveby {steps}", abs(steps) / (rpm * 1000 / 60) + 6)
        self.c.release_all()
        if not item or not item.get("ok"):
            raise Stop({"moveby": steps, "address": address, "item": item})
        return item

    def wait_stopped(self, addresses, bound):
        """Poll until none runs. Returns samples and the drives still running at the bound."""
        samples, end = [], time.time() + bound
        running = set(addresses)
        while running and time.time() < end:
            for a in sorted(running):
                f = self.state(a)
                samples.append((round(time.time(), 3), a, f.get("raw_motion"), f.get("raw_speed"), f.get("position"),
                                f.get("raw_alarm"), f.get("started_us")))
                if f.get("raw_alarm"):
                    raise Stop({"alarm": a, "state": f})
                if not f.get("raw_motion", 0) & RUNNING:
                    running.discard(a)
        return samples, running

    def fallback(self, addresses):
        """Prepared unicast stop fast: a new explicit stop for a drive still running."""
        for a in addresses:
            reply = self.c.send(f"stop fast {a}", 2.0)
            item = self.c.terminal(reply, 7.0) if reply.get("ok") else None
            self.c.release_all()
            self.record("fallback", {"address": a, "reply": reply.get("result"), "outcome": item and item.get("outcome")})

    def clear_move(self, address):
        """End the unicast move record after a confirmed broadcast stop, with one checked stop."""
        reply = self.c.send(f"stop normal {address}", 2.0)
        item = self.c.terminal(reply, 7.0) if reply.get("ok") else None
        self.c.release_all()
        return {"reply": reply.get("result"), "outcome": item and item.get("outcome"),
                "completion": item and item.get("completion")}

    # Parts
    def part_state(self):
        for a in ADDRESSES:
            self.select(a)
            identity = self.finish(f"read identity {a}", 3.0)
            config = self.finish(f"read config {a}", 3.0)
            raw = (config.get("configuration") or {}).get("raw") or {}
            text = json.dumps(config)
            custom = raw.get("custom_node")
            if custom is None and '"custom_node":' in text:
                custom = int(text.split('"custom_node":', 1)[1].split(",", 1)[0].strip().strip("}"))
            ident = identity.get("identity") or identity
            self.record("state", {"address": a, "identity": ident, "custom_node": custom})

    def stage(self, steps, rpm):
        """Stage each drive by one completed unicast relative move: accel and decel 300 ms."""
        staged = {}
        for a in ADDRESSES:
            self.simple_move(a, steps, rpm)
            staged[a] = self.profile(a)
            if staged[a][1] != RAMP or staged[a][2] != RAMP:
                raise Stop({"stage": a, "profile": staged[a]})
        return staged

    def part_a(self, trials=20):
        staged = self.stage(SMALL, SPEED)
        self.record("A", {"staged": staged})
        value = RAMP
        for n in range(1, trials + 1):
            before = {a: self.profile(a) for a in ADDRESSES}
            states = self.all_states()
            self.check_quiet(states, f"A{n} before")
            if any(p[1] != value for p in before.values()):
                raise Stop({"A": n, "expected": value, "before": before})
            value = 301 if value == 300 else 300
            item = self.broadcast(f"accel {value}")
            after = {a: self.profile(a) for a in ADDRESSES}
            states = self.all_states()
            self.check_quiet(states, f"A{n} after")
            applied = {a: p[1] == value for a, p in after.items()}
            unchanged = {a: after[a][0] == before[a][0] and after[a][2:] == before[a][2:] for a in ADDRESSES}
            self.record("A", {"n": n, "value": value, "tx_end_us": item.get("tx_end_us"), "applied": applied,
                              "others_unchanged": unchanged, "after": after})
            if not all(unchanged.values()):
                raise Stop({"A": n, "settings_changed": after})
        final = {a: self.profile(a) for a in ADDRESSES}
        self.record("A", {"final": final, "restored": all(p[1] == RAMP for p in final.values())})

    def classify(self, before, after, staged):
        """Per drive: moved as staged, not started, or unexpected (campaign stop)."""
        result = {}
        for a in ADDRESSES:
            d = (after[a]["position"] - before[a]["position"]) & 0xFFFFFFFF
            d = d - 0x100000000 if d > 0x7FFFFFFF else d
            result[a] = {"delta": d, "class": "moved" if abs(d - staged) <= 20 else "not_started" if abs(d) <= 2 else
                         "partial" if 0 < d < staged else "unexpected"}
        return result

    def part_b(self, trials=10):
        """Each trial is recorded per drive; a drive that ignores the start is a measured outcome."""
        staged = {a: self.profile(a) for a in ADDRESSES}
        for a, p in staged.items():
            if p[1:4] != [RAMP, RAMP, SPEED] or ((p[4] << 16) | p[5]) != SMALL:
                raise Stop({"B": "staging", "address": a, "profile": p})
        for n in range(1, trials + 1):
            before = self.all_states()
            self.check_quiet(before, f"B{n} before")
            item = self.broadcast("start relative")
            samples, onset, end = [], {}, time.time() + 1.5
            while time.time() < end:
                for a in ADDRESSES:
                    f = self.state(a)
                    samples.append((round(time.time(), 3), a, f.get("raw_motion"), f.get("raw_speed"),
                                    f.get("position"), f.get("started_us")))
                    if f.get("raw_alarm"):
                        raise Stop({"alarm": a, "state": f})
                    if f.get("raw_motion", 0) & RUNNING:
                        onset.setdefault(a, f.get("started_us"))
            more, running = self.wait_stopped(list(ADDRESSES), 3.0)
            if running:
                self.fallback(running)
            time.sleep(1.6)  # Post-stop settling of up to one increment.
            after = self.all_states()
            result = self.classify(before, after, SMALL)
            self.record("B", {"n": n, "transport": item.get("transport"), "tx_end_us": item.get("tx_end_us"),
                              "onset_us": onset, "result": result, "fallback": sorted(running),
                              "motion_before": {a: before[a].get("raw_motion") for a in ADDRESSES},
                              "samples": samples + more})
            if any(r["class"] == "unexpected" for r in result.values()):
                raise Stop({"B": n, "result": result})

    def part_c(self, trials_each=10):
        order = [("normal", 2.5), ("fast", 1.5)]
        n = 0
        for policy, bound in order:
            for i in range(trials_each):
                n += 1
                moving = ADDRESSES[i % len(ADDRESSES)]
                self.select(moving)
                self.finish("read config", 3.0)
                self.state(moving)
                self.ok("motion-profile read")  # A configured-ramp move needs the staged profile.
                for _ in range(200):
                    self.c.pump(0.01)
                    if not self.c.send("motion-profile inspect").get("pending"):
                        break
                before = self.all_states()
                self.check_quiet(before, f"C{n} before")
                self.state(moving)  # The application keeps one state cache: the moving drive is read last.
                reply = self.ok(f"move relative {LONG} steps native {LONG_SPEED} configured", 3.0)
                started = time.time()
                time.sleep(0.9)
                item = self.broadcast(f"stop {policy}")
                sent = time.time()
                samples, running = self.wait_stopped([moving], bound)
                if running:
                    self.fallback(running)
                others = {a: self.state(a) for a in ADDRESSES if a != moving}
                self.check_quiet(others, f"C{n} others")
                cleared = self.clear_move(moving)
                move = self.c.terminal(reply, 8.0)
                self.c.release_all()
                time.sleep(1.6)
                after = self.all_states()
                delta = (after[moving]["position"] - before[moving]["position"]) & 0xFFFFFFFF
                still = {a: after[a]["position"] - before[a]["position"] for a in ADDRESSES if a != moving}
                self.record("C", {"n": n, "policy": policy, "moving": moving, "stopped_within_bound": not running,
                                  "tx_end_us": item.get("tx_end_us"), "stop_after_start_s": round(sent - started, 3),
                                  "delta": delta, "short_of_target": delta < LONG, "others_moved": still,
                                  "move_outcome": move and move.get("outcome"), "clear": cleared, "samples": samples})
                if running or delta >= LONG or any(still.values()):
                    raise Stop({"C": n, "running": sorted(running), "delta": delta, "others": still})

    def part_d(self, trials_each=5):
        """Broadcast start of +5000 on all drives, then a broadcast stop mid-move."""
        staged = self.stage(LONG, LONG_SPEED)
        self.record("D", {"staged": staged})
        n = 0
        for policy, bound in (("normal", 2.5), ("fast", 1.5)):
            for _ in range(trials_each):
                n += 1
                before = self.all_states()
                self.check_quiet(before, f"D{n} before")
                start = self.broadcast("start relative")
                running_seen = {}
                for a in ADDRESSES:
                    f = self.state(a)
                    running_seen[a] = bool(f.get("raw_motion", 0) & RUNNING)
                stop = self.broadcast(f"stop {policy}")
                stop_sent = time.time()
                samples, running = self.wait_stopped(list(ADDRESSES), bound)
                if running:
                    self.fallback(running)
                time.sleep(1.6)
                after = self.all_states()
                result = self.classify(before, after, LONG)
                self.record("D", {"n": n, "policy": policy, "start_transport": start.get("transport"),
                                  "stop_transport": stop.get("transport"), "running_before_stop": running_seen,
                                  "still_running_at_bound": sorted(running), "result": result,
                                  "start_tx_end_us": start.get("tx_end_us"), "stop_tx_end_us": stop.get("tx_end_us"),
                                  "samples": samples})
                if any(r["class"] == "unexpected" for r in result.values()):
                    raise Stop({"D": n, "result": result})
        # Leave each drive staged with a small move again.
        self.stage(SMALL, SPEED)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    parser.add_argument("--parts", default="state,A,B,C,D")
    parser.add_argument("--debug", choices=("off", "raw"), default="raw")
    args = parser.parse_args()
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=False)
    log = open(out / "console.jsonl", "w", encoding="utf-8")
    console = Logged("COM13", out, log)
    run = Bench(console, out)
    code = 0
    try:
        console.pump(0.3)
        version = console.send("version", 3.0)
        run.record("setup", {"version": version})
        run.ok(f"debug {args.debug}")
        for part in args.parts.split(","):
            run.summary["parts"][part] = "started"
            {"state": run.part_state, "A": run.part_a, "B": run.part_b,
             "C": run.part_c, "D": run.part_d}[part]()
            run.summary["parts"][part] = "passed"
    except Stop as stop:
        code = 3
        run.record("stop", {"reason": str(stop)[:3000]})
        try:
            run.record("stop", {"states": run.all_states()})
        except Exception as error:  # Capture only; never a retry.
            run.record("stop", {"capture_failed": repr(error)})
    except bench.Unresponsive as error:
        code = 4
        run.record("stop", {"unresponsive": str(error)})
    finally:
        try:
            console.send("debug off", 2.0)
        except Exception:
            pass
        run.summary["windows"] = run.windows
        run.summary["ended"] = time.time()
        run.summary["code"] = code
        (out / "summary.json").write_text(json.dumps(run.summary, indent=1))
        log.close()
        console.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
