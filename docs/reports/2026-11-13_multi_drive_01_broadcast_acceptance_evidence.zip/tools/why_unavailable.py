"""Read-only plus one finite simple move: why is a move on drive 1 unavailable after broadcasts?"""
import importlib.util, json, pathlib, sys, time
HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("bt", HERE / "broadcast_trials.py"); bt = importlib.util.module_from_spec(spec); spec.loader.exec_module(bt)
out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=False)
log = open(out / "console.jsonl", "w", encoding="utf-8")
c = bt.Logged("COM13", out, log); run = bt.Bench(c, out)
try:
    c.pump(0.3); c.send("version", 3.0)
    run.select(1); run.finish("read config", 3.0); run.state(1)
    run.ok("motion-profile read")
    for _ in range(200):
        c.pump(0.01)
        v = c.send("motion-profile inspect")
        if not v.get("pending"): break
    print("inspect", json.dumps(v)[:500])
    print("health", json.dumps(c.send("health"))[:900])
    item = c.simple("settings", 5.0); c.release_all()
    print("settings", json.dumps(item)[:1500])
    r = c.send("move relative 100 steps native 60 configured", 3.0)
    print("move", json.dumps(r)[:300])
    if r.get("ok"):
        print("move terminal", json.dumps(c.terminal(r, 8.0))[:600])
finally:
    log.close(); c.close()
