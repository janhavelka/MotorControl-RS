import copy, importlib.util, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]

sys.path.insert(0,str(ROOT/'scripts'))
def load(name):
    s=importlib.util.spec_from_file_location(name,ROOT/'test'/f'{name}_harness_test.py'); m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
comm,pers=load('communication'),load('persistence')
base=Path(__file__).resolve().parent
rows={name:[json.loads(s) for s in (base/f'{name}.jsonl').read_text().splitlines() if s.startswith('{')] for name in ('communication','persistence')}
reports=[]
def check(name,index,label,mutation=None):
    item=copy.deepcopy(rows[name][index])
    if mutation: mutation(item['context'])
    m=comm if name=='communication' else pers
    t=m.CommunicationTests() if name=='communication' else m.PersistenceTests()
    console,port=t.console(lambda tokens:copy.deepcopy(item))
    try:
        console.command(name,host_args=('inspect',),timeout_s=.1)
        accepted=True;reason=''
    except Exception as e:
        accepted=False;reason=str(e)
    reports.append(dict(name=name,label=label,accepted=accepted,reason=reason,context=item['context']))
    print(name,label,'ACCEPTED' if accepted else 'REJECTED',reason)
for name,seq in rows.items():
    for i in range(len(seq)):check(name,i,'original-'+str(i))
def late(c):
    w=c['write_evidence']['wire']; w['latest_us']=c['write_evidence']['deadline_us']+1;w['delivered_us']=w['latest_us']+1
check('communication',0,'late-exception3-claimed-rejected',late)
check('communication',2,'exception5-claimed-rejected',lambda c:c.update(execution=2,uncertain=False))
check('communication',2,'exception5-claimed-not-transmitted',lambda c:c.update(execution=0,uncertain=False))
def contradictory(c):
    e=c['confirmation_evidence'][-1]; w=e['wire']; raw=bytes.fromhex(w['raw_hex']); raw=raw[:3]+bytes([0,2]);raw+=comm.bench.wire_crc(raw).to_bytes(2,'little');w['raw_hex']=raw.hex(); e['readback']=2;c.update(readback=2,uncertain=False)
check('communication',1,'rejected-with-contradictory-readback-hidden',contradictory)
check('persistence',1,'exception5-claimed-rejected',lambda c:c.update(execution=2,uncertain=False))
check('persistence',1,'exception5-claimed-not-transmitted',lambda c:c.update(execution=0,uncertain=False))
(base/'validator_results.json').write_text(json.dumps(reports,indent=2))

