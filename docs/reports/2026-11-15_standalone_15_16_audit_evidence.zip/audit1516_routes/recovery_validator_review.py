import copy,json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'scripts'))
import _bench_evidence as e
item=json.loads((root/'build/audit1516_stop/stop_path_app_test_recovery.jsonl').read_text().splitlines()[0])
for name,mutate in [
 ('original',lambda r:None),
 ('wrong stop policy',lambda r:r['stop_recovery']['before_attempt'].update(value=0x100)),
 ('expired before deadline',lambda r:r['stop_recovery']['result'].update(ok=False,outcome='expired',transport='REQUEST_DEADLINE')),
 ('zero TX successful attempt',lambda r:r['stop_recovery']['before_attempt'].update(outcome=2,transport='FRAME',qualified=True)),
 ('arbitrary recovery transport',lambda r:r['stop_recovery']['result'].update(ok=False,outcome='read_error',transport='bogus'))]:
    damaged=copy.deepcopy(item);mutate(damaged)
    try:e.check_stop_recovery(damaged);print(name,'ACCEPTED')
    except e.BenchError as err:print(name,'REJECTED',err)
