#define main originalCommunicationMain
#include "../../../test/communication_app_test.cpp"
#undef main
#include <cstdio>
void emitInspection() {
    Serial.output.clear();
    for (char c : std::string("@999 communication inspect\n")) app->console.feed(c);
    pump(); std::puts(Serial.output.c_str());
}
int main() {
    fresh(); configuration(); begin(); reply(crc({1,0x86,3})); emitInspection();
    assert(command(Kind::CONFIRM_BEFORE)==Probe::Action::OK); reply(words({0})); emitInspection();
    fresh(); configuration(); begin(); reply(crc({1,0x86,5})); emitInspection();
    fresh(); configuration(); begin(); reply(crc({1,0x86,3}));
    assert(command(Kind::CONFIRM_BEFORE)==Probe::Action::OK); reply(words({1}));
    assert(command(Kind::CONFIRM_BEFORE)==Probe::Action::OK); reply(words({0})); emitInspection();
    fresh(); configuration(); auto address = baudRequest(); address.field=ESS::CommunicationField::ADDRESS; address.address=2;
    begin(address); reply(); emitInspection();
    fresh(); configuration(); begin(); emitInspection();
    fresh(); configuration(); begin(); reply(crc({1,0x86,3})); assert(command(Kind::CONFIRM_BEFORE)==Probe::Action::OK); emitInspection();
    return 0;
}

