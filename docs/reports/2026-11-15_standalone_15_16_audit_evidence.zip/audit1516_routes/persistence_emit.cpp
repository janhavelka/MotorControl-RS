#define main originalPersistenceMain
#include "../../../test/persistence_app_test.cpp"
#undef main
#include <cstdio>
void emitInspection() {
    Serial.output.clear();
    for (char c : std::string("@999 persistence inspect\n")) app->console.feed(c);
    pump(); std::puts(Serial.output.c_str());
}
int main() {
    fresh(); baseline(); begin(); reply(crc({1,0x86,3})); emitInspection();
    fresh(); baseline(); begin(); reply(crc({1,0x86,5})); emitInspection();
    fresh(); baseline(); begin(); emitInspection();
    return 0;
}

