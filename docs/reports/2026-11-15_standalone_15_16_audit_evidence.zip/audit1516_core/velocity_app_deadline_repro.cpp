#define main existing_velocity_app_tests
#include "../../test/velocity_app_test.cpp"
#undef main
int main() {
    fresh(); qualify();
    const auto id = admitVelocity();
    velocityStep(id); velocityStep(id);
    velocityStep(id, registers(1,{0,4}));
    hardware.txCharacterUs = 0; // The next request is accepted but does not drain.
    waitTx(id);
    const auto token = findRecord(*app,id)->requestId;
    const auto deadline = view(id).velocityContext->deadlineUs;
    advanceHardware(deadline); // Cooperative task gap; ISR capture still runs.
    app->owner.service(uart.sample());
    const auto* result = app->owner.result(token);
    assert(result);
    const auto reason = result->transport.reason;
    const auto accepted = result->transport.txAccepted;
    std::printf("owner reason=%u accepted=%u complete=%u\n", unsigned(reason), unsigned(accepted), unsigned(result->transport.txComplete));
    assert(reason == Rtu::Reason::REQUEST_DEADLINE && accepted == 8);
    serviceApplication();
    const auto& c = *view(id).velocityContext;
    std::printf("core state=%u outcome=%u detail=%d needsStop=%u failure_step=%u failure_len=%zu failure_tx=%zu failure_detail=%d writes=%u retained_owner=%u\n",
      unsigned(c.state), unsigned(c.outcome), c.status.detail, unsigned(c.needsStop),
      unsigned(c.failureEvidence.step), c.failureEvidence.length, c.failureEvidence.txAccepted,
      c.failureEvidence.transportDetail, hardware.writes, unsigned(app->owner.result(token) != nullptr));
    assert(!view(id).pending && c.state == ActionState::FAILED && c.needsStop);
    assert(!app->owner.result(token));
    return c.failureEvidence.txAccepted == accepted && c.failureEvidence.transportDetail == int(reason) ? 0 : 1;
}
