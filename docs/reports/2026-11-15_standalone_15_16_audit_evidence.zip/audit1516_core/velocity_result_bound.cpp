#define main existing_velocity_app_tests
#include "../../test/velocity_app_test.cpp"
#undef main
#include <limits>

// Synthetic type-width maxima, not a physically attainable evidence history.
void maximum(ESS::ActionEvidence& e) {
    e.step = UINT8_MAX; e.event = ReadEventKind::TRANSPORT_FAILURE;
    std::memset(e.raw, 0xFF, sizeof(e.raw)); e.length = sizeof(e.raw);
    e.receivedLength = std::numeric_limits<std::size_t>::max(); e.txAccepted = 21;
    e.txComplete = e.responseConfirmed = e.qualified = e.executionUnknown = false;
    e.earliestUs = e.latestUs = e.deliveredUs = UINT64_MAX;
    e.transportDetail = INT32_MIN; e.status = Status(Err::INVALID_CONFIG, INT32_MIN, "");
    e.frameError = static_cast<ESS::FrameError>(UINT8_MAX);
}
int main() {
    ownedStopBeforeTxRetainsSettlement(false);
    App::Record* record = nullptr;
    for (auto& candidate : app->records)
        if (candidate.kind == App::OperationKind::VELOCITY) record = &candidate;
    assert(record && record->stopBeforeRecoveryKnown);
    auto& c = record->velocity;
    record->commandId = UINT32_MAX; record->stopRecoveryOperationId = UINT32_MAX;
    c.target.id = c.target.generation = c.request.configurationGeneration = UINT32_MAX;
    c.target.address = UINT8_MAX;
    c.startedUs = c.deadlineUs = c.stopDueUs = c.servicedUs = UINT64_MAX;
    c.prerequisites.observedUs = UINT64_MAX; c.prerequisites.maximumAgeUs = UINT64_MAX;
    c.polls = UINT8_MAX; c.observationKnown = true; c.rawAlarm = c.rawMotion = UINT16_MAX;
    for (auto& word : c.words) word = UINT16_MAX;
    c.status = Status(Err::INVALID_CONFIG, INT32_MIN, "");
    c.outcome = c.stop.outcome = ActionOutcome::UNCONFIRMED_RESPONSE;
    c.execution = c.setupExecution = c.stop.execution = ActionExecution::NOT_TRANSMITTED;
    c.completion = c.stop.completion = ActionCompletion::NOT_OBSERVED;
    c.prepared.nativeRpm = INT16_MIN;
    c.request.value.numerator = INT64_MIN; c.request.value.denominator = UINT64_MAX;
    c.request.durationUs = UINT32_MAX;
    c.request.maximumQuantizationErrorRpm = c.request.maximumApproximationErrorRpm = -1.2345678901234567e-299;
    c.prepared.roundingError = c.prepared.approximationErrorBound = c.prepared.approximateRequestedRpm = -1.2345678901234567e-299;
    for (auto* e : {&c.stagingEvidence, &c.triggerEvidence, &c.activityEvidence, &c.lastObservation,
                   &c.failureEvidence, &c.stop.writeEvidence, &c.stop.lastObservation, &c.stop.failureEvidence}) maximum(*e);
    auto& r = record->stopRecoveryResult;
    r.id = r.requestedUs = r.deadlineUs = r.finishedUs = UINT64_MAX;
    r.interrupted.slot = UINT16_MAX; r.interrupted.generation = UINT64_MAX;
    r.outcome = Rtu::RecoveryOutcome::TRANSPORT_ERROR; r.reason = Rtu::Reason::TIMING_UNCERTAIN;
    auto& b = record->stopBeforeRecovery;
    b.id.slot = UINT16_MAX; b.id.generation = UINT64_MAX;
    b.expected.target = b.expected.targetGeneration = UINT32_MAX;
    b.expected.address = b.expected.function = UINT8_MAX;
    b.expected.first = b.expected.value = UINT16_MAX;
    b.admittedUs = b.deadlineUs = b.dispatchDeadlineUs = UINT64_MAX;
    b.transport.reason = Rtu::Reason::TIMING_UNCERTAIN;
    b.transport.rxLength = sizeof(b.raw); std::memset(b.raw, 0xFF, sizeof(b.raw));
    b.transport.startedUs = b.transport.endedUs = b.transport.closureEarliestUs = b.transport.closureLatestUs = UINT64_MAX;
    b.validation = Status(Err::INVALID_CONFIG, INT32_MIN, "");
    command("@4294967295 result " + std::to_string(record->operationId) + "\n"); pump(2000);
    assert(Serial.output.find("\"stop_recovery\":") != std::string::npos);
    assert(Serial.output.find("output_full") == std::string::npos);
    assert(Serial.output.size() < Probe::OUTPUT_CAPACITY);
    std::fwrite(Serial.output.data(), 1, Serial.output.size(), stdout);
}
