#define main existing_velocity_tests
#include "../../test/velocity_test.cpp"
#undef main
#include <cstdio>
int main() {
    auto c = velocity(); trigger(c); consume(c, 4);
    Ess::PreparedVelocity work;
    assert(Ess::nextVelocity(c, c.eligibleUs, work));
    assert(work.kind == Ess::ActionWork::TRANSACTION && !work.write);
    const uint8_t prefix[] = {1, 3, 4, 0};
    auto e = local(c, ReadEventKind::DEADLINE);
    e.transport.txAccepted = 8; e.txComplete = true;
    e.transport.transportDetail = 12345;
    e.transport.frame = prefix; e.transport.length = sizeof(prefix);
    assert(Ess::advanceVelocity(c, e, c.deadlineUs));
    std::printf("state=%u outcome=%u detail=%d needsStop=%u failure_step=%u failure_len=%zu failure_tx=%zu failure_detail=%d last_len=%zu\n",
      unsigned(c.state), unsigned(c.outcome), c.status.detail, unsigned(c.needsStop),
      unsigned(c.failureEvidence.step), c.failureEvidence.length, c.failureEvidence.txAccepted,
      c.failureEvidence.transportDetail, c.lastObservation.length);
    assert(c.state == ActionState::FAILED && c.needsStop);
    return c.failureEvidence.length == sizeof(prefix) && c.failureEvidence.transportDetail == 12345 ? 0 : 1;
}
