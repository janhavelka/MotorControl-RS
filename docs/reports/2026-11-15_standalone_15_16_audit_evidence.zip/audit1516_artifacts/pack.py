from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
destination = root / "docs/reports/2026-11-15_standalone_15_16_audit_evidence.zip"
sources = []
for name in ("audit1516_core", "audit1516_stop", "audit1516_routes", "audit1516_verified", "audit1516_final", "audit1516_artifacts"):
    for source in sorted((root / "build" / name).glob("*")):
        if source.is_file() and source.suffix in (".json", ".jsonl", ".log", ".cpp", ".py", ".txt", ".zip"):
            if source.name.startswith("MotorControl-RS-") or source.name == "add_captured_fixtures.py":
                continue
            sources.append(source)
manifest = {
    "baseline": "4a5d09d011edac91ec1aa78a747493aac61dc82b",
    "implementation": "599c5dd2b64e9a2546a77ab3b40f023bd21d6572",
    "fieldcore_read_only": "c40ea8341edf8d665460b902cafefbe857a7f73f",
    "hardware": "NOT RUN",
    "files": {str(p.relative_to(root / "build")).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},
}
with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
    for source in sources:
        archive.write(source, str(source.relative_to(root / "build")).replace("\\", "/"))
print(f"{destination.name}: {len(sources)} files, {destination.stat().st_size} bytes")
print(hashlib.sha256(destination.read_bytes()).hexdigest())
