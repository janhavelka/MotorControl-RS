#define main inherited_stop_suite_main
#include "../../test/stop_path_app_test.cpp"
#undef main
int main() {
    {
        const auto failed = failedStopForRelease(100);
        const auto facts = releaseFacts(failed);
        hardware.clockStep = 0;
        advanceHardware(facts.qualifiedUs + 100000);
        assert(!MotorControlRS::evidenceAgeValid(facts.qualifiedUs, hardware.time, 100000));
        uint32_t releaseId = 777;
        const auto admitted = submitReleaseAfterStop(failed, facts, releaseId);
        std::printf("AGE_BOUNDARY age=%llu common_age_valid=0 admitted=%d operation=%u\n",
            static_cast<unsigned long long>(hardware.time-facts.qualifiedUs), !!admitted, releaseId);
        assert(admitted && releaseId != 777);
        serviceApplication();
        std::printf("AGE_BOUNDARY after_service_cancel=%d request_tx=%zu\n", findRecord(*app,releaseId)->cancelContinuation,
            app->owner.txAccepted(findRecord(*app,releaseId)->requestId));
    }
    {
        fresh(); known();
        hardware.rx.push_back(1); hardware.rx.push_back(3); pump(5);
        assert(uart.needsRecovery());
        const auto stopped = apiStop();
        step();
        assert(app->owner.recovering());
        const auto recoveryId = app->recovery.operationId;
        command("@100 cancel " + std::to_string(stopped) + "\n");
        assert(app->owner.recovering());
        const auto copied = copiedAction(stopped);
        assert(!copied.pending && copied.recoveryOperationId == recoveryId && !copied.recovery.id);
        const bool released = releaseOperation(stopped);
        assert(released);
        std::printf("PENDING_RECOVERY stop=%u recovery=%u action_pending=%d recovery_result_id=%llu released=%d wire=%zu\n",
            stopped,recoveryId,copied.pending,static_cast<unsigned long long>(copied.recovery.id),released,wire.size());
        runRecovery(recoveryId);
        ActionResult missing;
        assert(!copyActionResult(stopped,missing) && !copyActionResult(recoveryId,missing));
        Probe::ResultView oldRecovery;
        assert(lookup(app,recoveryId,oldRecovery) && oldRecovery.recoveryResult.id);
        std::printf("PENDING_RECOVERY after_finish_public_stop_copy=0 public_recovery_copy=0 private_lookup=1 recovery_outcome=%d\n",
            static_cast<int>(oldRecovery.recoveryResult.outcome));
        command("@101 recover\n");
        assert(app->recovery.operationId != recoveryId);
        assert(!lookup(app,recoveryId,oldRecovery));
        std::printf("PENDING_RECOVERY after_next_recovery_old_lookup=0 wire=%zu\n",wire.size());
    }
    {
        const auto id = stopWithSettledZeroTxFault();
        untilWire(FAST_STOP);
        reply(id); reply(id,words({0,0}));
        const auto* record=findRecord(*app,id);
        assert(record->stopBeforeRecoveryKnown && record->stopRecoveryResult.id);
        command("@200 result " + std::to_string(id) + "\n");
        std::printf("CONSOLE_RECOVERY original_record=%u private_before_attempt=%d private_recovery_id=%llu\n%s\n",
            id,record->stopBeforeRecoveryKnown,static_cast<unsigned long long>(record->stopRecoveryResult.id),Serial.output.c_str());
        command("@201 recover\n");
        const auto newer=app->recovery.operationId;
        runRecovery(newer);
        command("@202 result " + std::to_string(id) + "\n");
        std::printf("CONSOLE_RECOVERY after_new_recovery=%u\n%s\n",newer,Serial.output.c_str());
    }
    return 0;
}
