#define main inherited_stop_suite_main
#include "../../test/stop_path_app_test.cpp"
#undef main
int main() { releaseQualificationExactExpiry(); }
